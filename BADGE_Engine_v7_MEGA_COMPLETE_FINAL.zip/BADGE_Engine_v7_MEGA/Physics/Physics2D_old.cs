using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.ECS;

namespace BADGE.Physics
{
    public static class Physics2D
    {
        private static bool _isActive = false;
        private static List<Rigidbody2D> _rigidbodies = new List<Rigidbody2D>();
        public static Vector2 Gravity = new Vector2(0, -9.81f);

        public static void Initialize()
        {
            Console.WriteLine("  - Physics2D initialized (idle)");
        }

        public static void Activate()
        {
            _isActive = true;
            Console.WriteLine("Physics2D activated");
        }

        public static void Update(float deltaTime)
        {
            if (!_isActive) return;

            foreach (var rb in _rigidbodies)
            {
                if (rb.IsEnabled && !rb.IsKinematic)
                {
                    rb.Velocity = new Vector2(
                        rb.Velocity.X + Gravity.X * deltaTime,
                        rb.Velocity.Y + Gravity.Y * deltaTime
                    );

                    var transform = rb.Entity.GetComponent<Transform>();
                    if (transform != null)
                    {
                        transform.Position = new Vector3(
                            transform.Position.X + rb.Velocity.X * deltaTime,
                            transform.Position.Y + rb.Velocity.Y * deltaTime,
                            transform.Position.Z
                        );
                    }
                }
            }
        }

        public static void RegisterRigidbody(Rigidbody2D rb)
        {
            _rigidbodies.Add(rb);
        }

        public static void UnregisterRigidbody(Rigidbody2D rb)
        {
            _rigidbodies.Remove(rb);
        }
    }

    public class Rigidbody2D : Component
    {
        public Vector2 Velocity { get; set; }
        public float Mass { get; set; } = 1.0f;
        public float Drag { get; set; } = 0.0f;
        public bool IsKinematic { get; set; } = false;

        public override void OnAttach()
        {
            Physics2D.RegisterRigidbody(this);
        }

        public override void OnDetach()
        {
            Physics2D.UnregisterRigidbody(this);
        }
    }

    public class Collider2D : Component
    {
        public bool IsTrigger { get; set; } = false;
        public Vector2 Size { get; set; } = new Vector2(1, 1);
    }
}
