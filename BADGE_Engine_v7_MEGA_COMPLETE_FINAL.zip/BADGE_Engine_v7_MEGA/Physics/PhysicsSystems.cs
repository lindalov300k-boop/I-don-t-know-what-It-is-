using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Physics;

// ═══════════════════════════════════════════════════════════════════════
//  RIGIDBODY 3D
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Simple 3D rigid body for non-tile-based physics.
/// Needed by Buoyancy, Ragdoll, Vehicle (when needed), grenades, etc.
/// </summary>
public class Rigidbody3D : BADGE.Core.Component
{
    public float Mass        { get; set; } = 1f;
    public float BaseDrag    { get; set; } = 0.05f;
    public float BaseAngularDrag { get; set; } = 0.05f;
    public float LinearDrag  { get; set; } = 0.05f;
    public float AngularDrag { get; set; } = 0.05f;
    public bool  UseGravity  { get; set; } = true;
    public bool  IsKinematic { get; set; } = false;
    public bool  IsFrozen    { get; set; } = false;

    private Vector3 _velocity        = Vector3.Zero;
    private Vector3 _angularVelocity = Vector3.Zero;
    private Vector3 _forceAccum      = Vector3.Zero;
    private Vector3 _torqueAccum     = Vector3.Zero;

    private static readonly Vector3 GRAVITY = new(0f, -9.81f, 0f);

    public Vector3 Velocity        { get => _velocity;        set => _velocity = value; }
    public Vector3 AngularVelocity { get => _angularVelocity; set => _angularVelocity = value; }

    public void AddForce(Vector3 force)  => _forceAccum  += force;
    public void AddTorque(Vector3 torque)=> _torqueAccum += torque;
    public void AddImpulse(Vector3 imp)  => _velocity    += imp / Mass;

    public override void Update(float dt)
    {
        if (IsKinematic || IsFrozen || Transform == null) return;

        if (UseGravity) _forceAccum += GRAVITY * Mass;

        _velocity        += _forceAccum  / Mass * dt;
        _angularVelocity += _torqueAccum / Mass * dt;

        _velocity        *= MathF.Max(0f, 1f - LinearDrag  * dt);
        _angularVelocity *= MathF.Max(0f, 1f - AngularDrag * dt);

        Transform.Position        += _velocity        * dt;
        Transform.LocalEulerAngles += _angularVelocity * dt;

        _forceAccum  = Vector3.Zero;
        _torqueAccum = Vector3.Zero;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  PHYSICS JOINT  (hinge, spring, distance, fixed)
// ═══════════════════════════════════════════════════════════════════════
public enum JointType { Hinge, Spring, Distance, Fixed, BallSocket }

public class PhysicsJoint : BADGE.Core.Component
{
    public JointType Type      { get; set; } = JointType.Hinge;
    public Rigidbody3D? Body1  { get; set; }
    public Rigidbody3D? Body2  { get; set; }
    public Vector3 Anchor1     { get; set; }   // local to Body1
    public Vector3 Anchor2     { get; set; }   // local to Body2
    public Vector3 Axis        { get; set; } = Vector3.UnitY;
    public float   MinAngle    { get; set; } = -90f;
    public float   MaxAngle    { get; set; } =  90f;
    public float   SpringK     { get; set; } = 200f;
    public float   SpringDamp  { get; set; } = 20f;
    public float   Distance    { get; set; } = 1f;     // for Distance joint
    public bool    BreakOnForce{ get; set; } = false;
    public float   BreakForce  { get; set; } = 10000f;

    public bool    IsBroken    { get; private set; }

    public override void Update(float dt)
    {
        if (IsBroken || Body1 == null || Body2 == null) return;

        switch (Type)
        {
            case JointType.Spring:   SolveSpring(dt); break;
            case JointType.Distance: SolveDistance(dt); break;
            case JointType.Fixed:    SolveFixed(dt);  break;
        }
    }

    private void SolveSpring(float dt)
    {
        var p1 = Body1.Transform?.Position ?? Vector3.Zero;
        var p2 = Body2.Transform?.Position ?? Vector3.Zero;
        var d  = p2 - p1;
        float len = d.Length;
        if (len < 0.0001f) return;

        float stretch = len - Distance;
        var force = d.Normalized() * (SpringK * stretch + SpringDamp * Vector3.Dot(Body2.Velocity - Body1.Velocity, d.Normalized()));

        Body1.AddForce( force);
        Body2.AddForce(-force);

        if (BreakOnForce && force.Length > BreakForce) IsBroken = true;
    }

    private void SolveDistance(float dt)
    {
        var p1 = Body1.Transform?.Position ?? Vector3.Zero;
        var p2 = Body2.Transform?.Position ?? Vector3.Zero;
        var d  = p2 - p1;
        float len = d.Length;
        if (len <= Distance || len < 0.0001f) return;

        float excess = (len - Distance) * 0.5f;
        var   corr   = d.Normalized() * excess;
        if (Body1.Transform != null) Body1.Transform.Position += corr;
        if (Body2.Transform != null) Body2.Transform.Position -= corr;
    }

    private void SolveFixed(float dt)
    {
        // Keep relative position constant — just snap body2 to body1+offset
        if (Body1.Transform == null || Body2.Transform == null) return;
        Body2.Transform.Position = Body1.Transform.Position + Anchor2;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  RAGDOLL
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Ragdoll controller: switches a character from animation to physics-driven bones.
/// NEEDED BY: GTA death sequences, Limbo, any physics-based death animation.
/// </summary>
public class Ragdoll : BADGE.Core.Component
{
    public bool IsActive { get; private set; }

    // Bone name → rigidbody
    private readonly Dictionary<string, Rigidbody3D> _bones = new();
    private readonly List<PhysicsJoint>               _joints = new();

    public void AddBone(string name, Rigidbody3D rb) => _bones[name] = rb;
    public void AddJoint(PhysicsJoint j) => _joints.Add(j);

    public void Activate(Vector3 impulse = default)
    {
        IsActive = true;
        foreach (var rb in _bones.Values)
        {
            rb.IsKinematic = false;
            rb.UseGravity  = true;
        }

        // Apply initial impulse to root
        if (_bones.TryGetValue("Hips", out var hips))
            hips.AddImpulse(impulse);
    }

    public void Deactivate()
    {
        IsActive = false;
        foreach (var rb in _bones.Values)
            rb.IsKinematic = true;
    }

    /// <summary>Apply an explosion force from a point.</summary>
    public void ApplyExplosion(Vector3 origin, float force, float radius)
    {
        foreach (var rb in _bones.Values)
        {
            if (rb.Transform == null) continue;
            var dir  = rb.Transform.Position - origin;
            float d  = dir.Length;
            if (d < 0.001f || d > radius) continue;
            float atten = 1f - d / radius;
            rb.AddImpulse(dir.Normalized() * force * atten);
        }
    }

    public Rigidbody3D? GetBone(string name)
        => _bones.TryGetValue(name, out var rb) ? rb : null;
}

// ═══════════════════════════════════════════════════════════════════════
//  FABRIK INVERSE KINEMATICS
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// FABRIK (Forward And Backward Reaching IK) solver.
/// NEEDED BY: Procedural animation (character feet placement), robotic arms,
///            Subnautica creature tentacles, No Man's Sky creature legs.
/// </summary>
public class IKChain
{
    public Vector3[] Joints    { get; private set; }
    public float[]   Lengths   { get; private set; }
    public float     Tolerance { get; set; } = 0.001f;
    public int       MaxIter   { get; set; } = 10;

    public IKChain(Vector3[] positions)
    {
        Joints  = (Vector3[])positions.Clone();
        Lengths = new float[positions.Length - 1];
        for (int i = 0; i < Lengths.Length; i++)
            Lengths[i] = Vector3.Distance(positions[i], positions[i + 1]);
    }

    public void Solve(Vector3 target, Vector3? rootPin = null)
    {
        int n    = Joints.Length;
        var root = Joints[0];

        float totalLen = 0f;
        foreach (var l in Lengths) totalLen += l;

        // If target is out of reach — stretch toward it
        if ((target - root).Length >= totalLen)
        {
            var dir = (target - root).Normalized();
            for (int i = 1; i < n; i++)
                Joints[i] = Joints[i - 1] + dir * Lengths[i - 1];
            return;
        }

        for (int iter = 0; iter < MaxIter; iter++)
        {
            // Forward pass
            Joints[n - 1] = target;
            for (int i = n - 2; i >= 0; i--)
            {
                var dir = (Joints[i] - Joints[i + 1]).Normalized();
                Joints[i] = Joints[i + 1] + dir * Lengths[i];
            }

            // Backward pass
            if (rootPin.HasValue) Joints[0] = rootPin.Value;
            for (int i = 1; i < n; i++)
            {
                var dir = (Joints[i] - Joints[i - 1]).Normalized();
                Joints[i] = Joints[i - 1] + dir * Lengths[i - 1];
            }

            if ((Joints[n - 1] - target).Length < Tolerance) break;
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  BALL SHOOTER  (Zuma / Puzzle Bobble)
// ═══════════════════════════════════════════════════════════════════════
public enum BallColor { Red, Blue, Green, Yellow, Purple, Orange }

public class ZumaChain
{
    private readonly List<(BallColor color, Vector2 pos)> _balls = new();
    private readonly List<Vector2> _path;
    private float _pathProgress;   // 0–1 along path
    private float _speed = 0.03f;

    public event Action? OnGoalReached;
    public event Action<int>? OnChainCleared;

    public ZumaChain(List<Vector2> pathNodes) => _path = pathNodes;

    public void AddBall(BallColor color) => _balls.Insert(0, (color, _path[0]));

    public void Update(float dt)
    {
        _pathProgress += _speed * dt;
        if (_pathProgress >= 1f) { OnGoalReached?.Invoke(); return; }

        // Advance each ball along path
        for (int i = 0; i < _balls.Count; i++)
        {
            float t = MathF.Min(_pathProgress - i * 0.02f, 1f);
            if (t < 0f) t = 0f;
            _balls[i] = (_balls[i].color, SamplePath(t));
        }

        CheckMatches();
    }

    private Vector2 SamplePath(float t)
    {
        if (_path.Count < 2) return _path[0];
        float total = t * (_path.Count - 1);
        int   idx   = (int)total;
        float frac  = total - idx;
        idx = Math.Clamp(idx, 0, _path.Count - 2);
        return Vector2.Lerp(_path[idx], _path[idx + 1], frac);
    }

    public bool ShootBall(BallColor color, Vector2 from, Vector2 direction, float speed = 12f)
    {
        // Find first ball along path within collision radius of ball trajectory
        for (int i = 0; i < _balls.Count; i++)
        {
            var (bc, pos) = _balls[i];
            if (Vector2.Distance(from, pos) < 0.5f)
            {
                _balls.Insert(i, (color, pos));
                CheckMatches();
                return true;
            }
        }
        return false;
    }

    private void CheckMatches()
    {
        if (_balls.Count < 3) return;
        int cleared = 0;

        for (int i = 0; i < _balls.Count - 2; )
        {
            var c = _balls[i].color;
            int run = 1;
            while (i + run < _balls.Count && _balls[i + run].color == c) run++;

            if (run >= 3)
            {
                _balls.RemoveRange(i, run);
                cleared += run;
            }
            else i++;
        }

        if (cleared > 0) OnChainCleared?.Invoke(cleared);
    }

    public IReadOnlyList<(BallColor, Vector2)> Balls => _balls;
}

public static class TrajectoryPredictor
{
    /// <summary>Predict arc trajectory given initial position, velocity, and gravity.</summary>
    public static List<Vector2> Predict(Vector2 pos, Vector2 vel, float gravity = -20f, int steps = 30, float stepDt = 0.05f)
    {
        var pts = new List<Vector2>(steps);
        var p   = pos;
        var v   = vel;
        for (int i = 0; i < steps; i++)
        {
            pts.Add(p);
            v.Y += gravity * stepDt;
            p   += v * stepDt;
        }
        return pts;
    }
}
