using System;
namespace BADGE.Procedural.Noise
{
    public static class FractalBrownianMotion
    {
        public static float Generate(float x, float y, int octaves = 4)
        {
            float total = 0, frequency = 1, amplitude = 1, maxValue = 0;
            for(int i = 0; i < octaves; i++) {
                total += Perlin.Generate(x * frequency, y * frequency) * amplitude;
                maxValue += amplitude;
                amplitude *= 0.5f;
                frequency *= 2.0f;
            }
            return total / maxValue;
        }
    }
}
