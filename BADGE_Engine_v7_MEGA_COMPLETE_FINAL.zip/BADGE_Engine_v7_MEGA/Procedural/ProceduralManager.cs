using System;

namespace BADGE.Procedural
{
    public static class ProceduralManager
    {
        private static bool _isIdle = true;

        public static void SetIdle(bool idle)
        {
            _isIdle = idle;
            if (idle)
            {
                Console.WriteLine("Procedural systems set to idle");
            }
        }

        public static bool IsIdle() => _isIdle;
    }
}
