using System;
namespace BADGE.AI
{
    public static class DebugAssistant
    {
        public static string AnalyzeError(string errorMessage)
        {
            return $"Analysis: {errorMessage}\nSuggestion: Check code syntax";
        }
    }
}
