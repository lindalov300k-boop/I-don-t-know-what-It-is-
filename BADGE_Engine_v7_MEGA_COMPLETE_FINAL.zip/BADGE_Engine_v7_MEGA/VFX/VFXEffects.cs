using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using OpenTK.Graphics.OpenGL4;
using BADGE.Core;

namespace BADGE.VFX
{
    // ═══════════════════════════════════════════════════════════════════════════
    //  POST-PROCESS STACK  (real OpenGL — replaces the Console.WriteLine stubs)
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Full-screen post-processing pipeline with real GLSL shaders.
    /// Add to your scene or game manager, call Render(sourceTexId, w, h) after
    /// your main scene render pass.
    ///
    /// Usage:
    ///   var pp = new PostProcessor();
    ///   pp.Bloom.Enabled = true;  pp.Bloom.Threshold = 0.7f;
    ///   pp.Vignette.Enabled = true;
    ///   pp.CRT.Enabled = true;
    ///   pp.Render(sceneColorTex, screenW, screenH);
    /// </summary>
    public sealed class PostProcessor : IDisposable
    {
        // ── Effects ───────────────────────────────────────────────────────
        public BloomEffect           Bloom           { get; } = new();
        public VignetteEffect        Vignette        { get; } = new();
        public ChromaticAberration   ChromaticAb     { get; } = new();
        public CRTEffect             CRT             { get; } = new();
        public ColorGradingEffect    ColorGrading    { get; } = new();
        public PixelateEffect        Pixelate        { get; } = new();
        public ScanlineEffect        Scanlines       { get; } = new();

        // ── Fullscreen quad ───────────────────────────────────────────────
        private int _fsVAO, _fsVBO;
        private bool _glReady;

        // ── Main entry point ──────────────────────────────────────────────
        public void Render(int sourceTexture, int screenW, int screenH)
        {
            EnsureGL();
            int tex = sourceTexture;

            GL.Disable(EnableCap.DepthTest);
            GL.BindVertexArray(_fsVAO);

            if (Bloom.Enabled)           tex = Bloom.Apply(tex, screenW, screenH, _fsVAO);
            if (ChromaticAb.Enabled)     tex = ChromaticAb.Apply(tex, screenW, screenH, _fsVAO);
            if (ColorGrading.Enabled)    tex = ColorGrading.Apply(tex, screenW, screenH, _fsVAO);
            if (Vignette.Enabled)        tex = Vignette.Apply(tex, screenW, screenH, _fsVAO);
            if (Pixelate.Enabled)        tex = Pixelate.Apply(tex, screenW, screenH, _fsVAO);
            if (CRT.Enabled)             tex = CRT.Apply(tex, screenW, screenH, _fsVAO);
            if (Scanlines.Enabled)       tex = Scanlines.Apply(tex, screenW, screenH, _fsVAO);

            // Blit final tex to backbuffer
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
            BlitToScreen(tex, screenW, screenH);

            GL.BindVertexArray(0);
            GL.Enable(EnableCap.DepthTest);
        }

        private void BlitToScreen(int tex, int w, int h)
        {
            var prog = ShaderCache.Get("blit",
                PassthroughVert,
                @"#version 330 core
in vec2 vUV; out vec4 FragColor; uniform sampler2D uTex;
void main() { FragColor = texture(uTex, vUV); }");
            GL.UseProgram(prog);
            GL.ActiveTexture(TextureUnit.Texture0);
            GL.BindTexture(TextureTarget.Texture2D, tex);
            GL.Uniform1(GL.GetUniformLocation(prog, "uTex"), 0);
            GL.DrawArrays(PrimitiveType.TriangleStrip, 0, 4);
        }

        private void EnsureGL()
        {
            if (_glReady) return; _glReady = true;
            float[] v = { -1,-1, 0,0,  1,-1, 1,0,  -1,1, 0,1,  1,1, 1,1 };
            _fsVAO = GL.GenVertexArray(); _fsVBO = GL.GenBuffer();
            GL.BindVertexArray(_fsVAO);
            GL.BindBuffer(BufferTarget.ArrayBuffer, _fsVBO);
            GL.BufferData(BufferTarget.ArrayBuffer, v.Length*4, v, BufferUsageHint.StaticDraw);
            GL.EnableVertexAttribArray(0); GL.VertexAttribPointer(0,2,VertexAttribPointerType.Float,false,16,0);
            GL.EnableVertexAttribArray(1); GL.VertexAttribPointer(1,2,VertexAttribPointerType.Float,false,16,8);
            GL.BindVertexArray(0);
        }

        public void Dispose()
        {
            GL.DeleteVertexArray(_fsVAO); GL.DeleteBuffer(_fsVBO);
            Bloom.Dispose(); ChromaticAb.Dispose(); ColorGrading.Dispose();
            Vignette.Dispose(); Pixelate.Dispose(); CRT.Dispose(); Scanlines.Dispose();
        }

        internal const string PassthroughVert = @"#version 330 core
layout(location=0) in vec2 aPos; layout(location=1) in vec2 aUV;
out vec2 vUV;
void main() { vUV = aUV; gl_Position = vec4(aPos,0,1); }";
    }

    // ── Base for all effects ───────────────────────────────────────────────────
    public abstract class FxBase : IDisposable
    {
        public bool Enabled { get; set; } = false;
        protected int _fbo, _tex;
        protected bool _fbReady;

        protected int EnsureFBO(int w, int h)
        {
            if (!_fbReady || _needsResize) { BuildFBO(w, h); _fbReady = true; _needsResize = false; }
            return _fbo;
        }
        private bool _needsResize;
        protected int _lastW, _lastH;

        private void BuildFBO(int w, int h)
        {
            if (_fbo != 0) { GL.DeleteFramebuffer(_fbo); GL.DeleteTexture(_tex); }
            _fbo = GL.GenFramebuffer(); _tex = GL.GenTexture();
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _fbo);
            GL.BindTexture(TextureTarget.Texture2D, _tex);
            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba16f, w, h, 0,
                          PixelFormat.Rgba, PixelType.Float, IntPtr.Zero);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.ClampToEdge);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.ClampToEdge);
            GL.FramebufferTexture2D(FramebufferTarget.Framebuffer, FramebufferAttachment.ColorAttachment0,
                                    TextureTarget.Texture2D, _tex, 0);
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, 0);
            _lastW = w; _lastH = h;
        }

        public virtual void Dispose()
        {
            if (_fbo != 0) { GL.DeleteFramebuffer(_fbo); GL.DeleteTexture(_tex); }
        }
    }

    // ── Bloom ──────────────────────────────────────────────────────────────────
    public sealed class BloomEffect : FxBase
    {
        public float Threshold  { get; set; } = 0.7f;
        public float Intensity  { get; set; } = 1.5f;
        public int   BlurPasses { get; set; } = 5;

        private int _fbo2, _tex2;

        public int Apply(int srcTex, int w, int h, int fsVAO)
        {
            int fbo1 = EnsureFBO(w, h);
            EnsureFBO2(w, h);

            // Pass 1: threshold bright areas
            var bright = ShaderCache.Get("bloom_bright", PostProcessor.PassthroughVert, @"
#version 330 core
in vec2 vUV; out vec4 FragColor;
uniform sampler2D uTex; uniform float uThreshold;
void main() {
    vec3 c = texture(uTex, vUV).rgb;
    float brightness = dot(c, vec3(0.2126,0.7152,0.0722));
    FragColor = brightness > uThreshold ? vec4(c,1) : vec4(0,0,0,1);
}");
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, fbo1);
            GL.Viewport(0, 0, w, h);
            GL.UseProgram(bright);
            GL.ActiveTexture(TextureUnit.Texture0); GL.BindTexture(TextureTarget.Texture2D, srcTex);
            GL.Uniform1(GL.GetUniformLocation(bright, "uTex"), 0);
            GL.Uniform1(GL.GetUniformLocation(bright, "uThreshold"), Threshold);
            GL.DrawArrays(PrimitiveType.TriangleStrip, 0, 4);

            // Pass 2: Gaussian blur (ping-pong)
            var blur = ShaderCache.Get("bloom_blur", PostProcessor.PassthroughVert, @"
#version 330 core
in vec2 vUV; out vec4 FragColor;
uniform sampler2D uTex; uniform vec2 uDir;
void main() {
    vec2 texelSize = uDir / textureSize(uTex, 0);
    vec4 result = texture(uTex, vUV) * 0.227027;
    result += texture(uTex, vUV + texelSize*1.385) * 0.316216;
    result += texture(uTex, vUV - texelSize*1.385) * 0.316216;
    result += texture(uTex, vUV + texelSize*3.231) * 0.070270;
    result += texture(uTex, vUV - texelSize*3.231) * 0.070270;
    FragColor = result;
}");
            int ping = _tex, pong = _tex2;
            for (int i = 0; i < BlurPasses; i++)
            {
                int fboDst = (i % 2 == 0) ? _fbo2 : fbo1;
                GL.BindFramebuffer(FramebufferTarget.Framebuffer, fboDst);
                GL.UseProgram(blur);
                GL.ActiveTexture(TextureUnit.Texture0);
                GL.BindTexture(TextureTarget.Texture2D, i == 0 ? _tex : (i%2==0?ping:pong));
                GL.Uniform1(GL.GetUniformLocation(blur, "uTex"), 0);
                GL.Uniform2(GL.GetUniformLocation(blur, "uDir"), i % 2 == 0 ? Vector2.UnitX : Vector2.UnitY);
                GL.DrawArrays(PrimitiveType.TriangleStrip, 0, 4);
            }

            // Pass 3: additive blend with original
            var combine = ShaderCache.Get("bloom_combine", PostProcessor.PassthroughVert, @"
#version 330 core
in vec2 vUV; out vec4 FragColor;
uniform sampler2D uScene; uniform sampler2D uBloom; uniform float uIntensity;
void main() {
    vec3 scene = texture(uScene, vUV).rgb;
    vec3 bloom = texture(uBloom, vUV).rgb;
    FragColor = vec4(scene + bloom * uIntensity, 1.0);
}");
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, fbo1);
            GL.UseProgram(combine);
            GL.ActiveTexture(TextureUnit.Texture0); GL.BindTexture(TextureTarget.Texture2D, srcTex);
            GL.Uniform1(GL.GetUniformLocation(combine, "uScene"), 0);
            GL.ActiveTexture(TextureUnit.Texture1); GL.BindTexture(TextureTarget.Texture2D, BlurPasses % 2 == 0 ? _tex : _tex2);
            GL.Uniform1(GL.GetUniformLocation(combine, "uBloom"), 1);
            GL.Uniform1(GL.GetUniformLocation(combine, "uIntensity"), Intensity);
            GL.DrawArrays(PrimitiveType.TriangleStrip, 0, 4);
            return _tex;
        }

        private void EnsureFBO2(int w, int h)
        {
            if (_fbo2 != 0) return;
            _fbo2 = GL.GenFramebuffer(); _tex2 = GL.GenTexture();
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _fbo2);
            GL.BindTexture(TextureTarget.Texture2D, _tex2);
            GL.TexImage2D(TextureTarget.Texture2D,0,PixelInternalFormat.Rgba16f,w,h,0,PixelFormat.Rgba,PixelType.Float,IntPtr.Zero);
            GL.TexParameter(TextureTarget.Texture2D,TextureParameterName.TextureMinFilter,(int)TextureMinFilter.Linear);
            GL.TexParameter(TextureTarget.Texture2D,TextureParameterName.TextureMagFilter,(int)TextureMagFilter.Linear);
            GL.FramebufferTexture2D(FramebufferTarget.Framebuffer,FramebufferAttachment.ColorAttachment0,TextureTarget.Texture2D,_tex2,0);
            GL.BindFramebuffer(FramebufferTarget.Framebuffer,0);
        }

        public override void Dispose() { base.Dispose(); if(_fbo2!=0){GL.DeleteFramebuffer(_fbo2);GL.DeleteTexture(_tex2);} }
    }

    // ── Vignette ───────────────────────────────────────────────────────────────
    public sealed class VignetteEffect : FxBase
    {
        public float Intensity  { get; set; } = 0.45f;
        public float Smoothness { get; set; } = 0.45f;
        public Color4 Color     { get; set; } = Color4.Black;

        public int Apply(int srcTex, int w, int h, int fsVAO)
        {
            EnsureFBO(w, h);
            var prog = ShaderCache.Get("vignette", PostProcessor.PassthroughVert, @"
#version 330 core
in vec2 vUV; out vec4 FragColor;
uniform sampler2D uTex; uniform float uIntensity; uniform float uSmooth; uniform vec3 uColor;
void main() {
    vec4 scene = texture(uTex, vUV);
    vec2 uv = vUV - 0.5;
    float vig = smoothstep(0.8, uSmooth * 0.799, length(uv) * (uIntensity + uSmooth));
    FragColor = vec4(mix(uColor, scene.rgb, vig), 1.0);
}");
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _fbo);
            GL.Viewport(0, 0, w, h);
            GL.UseProgram(prog);
            GL.ActiveTexture(TextureUnit.Texture0); GL.BindTexture(TextureTarget.Texture2D, srcTex);
            GL.Uniform1(GL.GetUniformLocation(prog, "uTex"), 0);
            GL.Uniform1(GL.GetUniformLocation(prog, "uIntensity"), Intensity);
            GL.Uniform1(GL.GetUniformLocation(prog, "uSmooth"), Smoothness);
            GL.Uniform3(GL.GetUniformLocation(prog, "uColor"), Color.R, Color.G, Color.B);
            GL.DrawArrays(PrimitiveType.TriangleStrip, 0, 4);
            return _tex;
        }
    }

    // ── Chromatic Aberration ───────────────────────────────────────────────────
    public sealed class ChromaticAberration : FxBase
    {
        public float Intensity { get; set; } = 0.005f;

        public int Apply(int srcTex, int w, int h, int fsVAO)
        {
            EnsureFBO(w, h);
            var prog = ShaderCache.Get("chroma", PostProcessor.PassthroughVert, @"
#version 330 core
in vec2 vUV; out vec4 FragColor;
uniform sampler2D uTex; uniform float uStrength;
void main() {
    vec2 offset = (vUV - 0.5) * uStrength;
    float r = texture(uTex, vUV - offset).r;
    float g = texture(uTex, vUV).g;
    float b = texture(uTex, vUV + offset).b;
    FragColor = vec4(r, g, b, 1.0);
}");
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _fbo);
            GL.Viewport(0,0,w,h);
            GL.UseProgram(prog);
            GL.ActiveTexture(TextureUnit.Texture0); GL.BindTexture(TextureTarget.Texture2D, srcTex);
            GL.Uniform1(GL.GetUniformLocation(prog,"uTex"),0);
            GL.Uniform1(GL.GetUniformLocation(prog,"uStrength"),Intensity);
            GL.DrawArrays(PrimitiveType.TriangleStrip,0,4);
            return _tex;
        }
    }

    // ── CRT Effect ─────────────────────────────────────────────────────────────
    public sealed class CRTEffect : FxBase
    {
        public float Curvature    { get; set; } = 0.15f;
        public float ScanlineAmt  { get; set; } = 0.8f;
        public float Brightness   { get; set; } = 1.2f;

        public int Apply(int srcTex, int w, int h, int fsVAO)
        {
            EnsureFBO(w, h);
            var prog = ShaderCache.Get("crt", PostProcessor.PassthroughVert, @"
#version 330 core
in vec2 vUV; out vec4 FragColor;
uniform sampler2D uTex; uniform float uCurve; uniform float uScan; uniform float uBright;
uniform float uTime;
void main() {
    vec2 uv = vUV - 0.5;
    uv *= 1.0 + uCurve * dot(uv, uv);
    uv += 0.5;
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) { FragColor = vec4(0,0,0,1); return; }
    vec3 col = texture(uTex, uv).rgb * uBright;
    float scan = sin(uv.y * 800.0) * 0.5 + 0.5;
    col *= mix(1.0, scan, uScan * 0.3);
    // RGB mask
    float x = mod(gl_FragCoord.x, 3.0);
    col *= (x < 1.0) ? vec3(1,0.3,0.3) : (x < 2.0) ? vec3(0.3,1,0.3) : vec3(0.3,0.3,1);
    FragColor = vec4(col, 1.0);
}");
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _fbo);
            GL.Viewport(0,0,w,h);
            GL.UseProgram(prog);
            GL.ActiveTexture(TextureUnit.Texture0); GL.BindTexture(TextureTarget.Texture2D, srcTex);
            GL.Uniform1(GL.GetUniformLocation(prog,"uTex"),0);
            GL.Uniform1(GL.GetUniformLocation(prog,"uCurve"),Curvature);
            GL.Uniform1(GL.GetUniformLocation(prog,"uScan"),ScanlineAmt);
            GL.Uniform1(GL.GetUniformLocation(prog,"uBright"),Brightness);
            GL.Uniform1(GL.GetUniformLocation(prog,"uTime"),(float)Time.ElapsedTime);
            GL.DrawArrays(PrimitiveType.TriangleStrip,0,4);
            return _tex;
        }
    }

    // ── Color Grading ──────────────────────────────────────────────────────────
    public sealed class ColorGradingEffect : FxBase
    {
        public float Saturation { get; set; } = 1f;
        public float Contrast   { get; set; } = 1f;
        public float Brightness { get; set; } = 0f;
        public Color4 Tint      { get; set; } = Color4.White;

        public int Apply(int srcTex, int w, int h, int fsVAO)
        {
            EnsureFBO(w, h);
            var prog = ShaderCache.Get("colorgrade", PostProcessor.PassthroughVert, @"
#version 330 core
in vec2 vUV; out vec4 FragColor;
uniform sampler2D uTex; uniform float uSat; uniform float uCon; uniform float uBri; uniform vec3 uTint;
void main() {
    vec3 c = texture(uTex, vUV).rgb;
    c += uBri;
    c = (c - 0.5) * uCon + 0.5;
    float lum = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(lum), c, uSat);
    c *= uTint;
    FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}");
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _fbo);
            GL.Viewport(0,0,w,h);
            GL.UseProgram(prog);
            GL.ActiveTexture(TextureUnit.Texture0); GL.BindTexture(TextureTarget.Texture2D, srcTex);
            GL.Uniform1(GL.GetUniformLocation(prog,"uTex"),0);
            GL.Uniform1(GL.GetUniformLocation(prog,"uSat"),Saturation);
            GL.Uniform1(GL.GetUniformLocation(prog,"uCon"),Contrast);
            GL.Uniform1(GL.GetUniformLocation(prog,"uBri"),Brightness);
            GL.Uniform3(GL.GetUniformLocation(prog,"uTint"),Tint.R,Tint.G,Tint.B);
            GL.DrawArrays(PrimitiveType.TriangleStrip,0,4);
            return _tex;
        }
    }

    // ── Pixelate ───────────────────────────────────────────────────────────────
    public sealed class PixelateEffect : FxBase
    {
        public float PixelSize { get; set; } = 4f;

        public int Apply(int srcTex, int w, int h, int fsVAO)
        {
            EnsureFBO(w, h);
            var prog = ShaderCache.Get("pixelate", PostProcessor.PassthroughVert, @"
#version 330 core
in vec2 vUV; out vec4 FragColor;
uniform sampler2D uTex; uniform vec2 uResolution; uniform float uSize;
void main() {
    vec2 pixel = floor(vUV * uResolution / uSize) * uSize / uResolution;
    FragColor = texture(uTex, pixel);
}");
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _fbo);
            GL.Viewport(0,0,w,h);
            GL.UseProgram(prog);
            GL.ActiveTexture(TextureUnit.Texture0); GL.BindTexture(TextureTarget.Texture2D, srcTex);
            GL.Uniform1(GL.GetUniformLocation(prog,"uTex"),0);
            GL.Uniform2(GL.GetUniformLocation(prog,"uResolution"),(float)w,(float)h);
            GL.Uniform1(GL.GetUniformLocation(prog,"uSize"),PixelSize);
            GL.DrawArrays(PrimitiveType.TriangleStrip,0,4);
            return _tex;
        }
    }

    // ── Scanlines ──────────────────────────────────────────────────────────────
    public sealed class ScanlineEffect : FxBase
    {
        public float Intensity { get; set; } = 0.15f;
        public float Count     { get; set; } = 400f;

        public int Apply(int srcTex, int w, int h, int fsVAO)
        {
            EnsureFBO(w, h);
            var prog = ShaderCache.Get("scanline", PostProcessor.PassthroughVert, @"
#version 330 core
in vec2 vUV; out vec4 FragColor;
uniform sampler2D uTex; uniform float uIntensity; uniform float uCount;
void main() {
    vec4 c = texture(uTex, vUV);
    float s = sin(vUV.y * uCount * 3.14159) * uIntensity;
    FragColor = vec4(c.rgb - s, 1.0);
}");
            GL.BindFramebuffer(FramebufferTarget.Framebuffer, _fbo);
            GL.Viewport(0,0,w,h);
            GL.UseProgram(prog);
            GL.ActiveTexture(TextureUnit.Texture0); GL.BindTexture(TextureTarget.Texture2D, srcTex);
            GL.Uniform1(GL.GetUniformLocation(prog,"uTex"),0);
            GL.Uniform1(GL.GetUniformLocation(prog,"uIntensity"),Intensity);
            GL.Uniform1(GL.GetUniformLocation(prog,"uCount"),Count);
            GL.DrawArrays(PrimitiveType.TriangleStrip,0,4);
            return _tex;
        }
    }

    // ── Internal shader cache ──────────────────────────────────────────────────
    internal static class ShaderCache
    {
        private static readonly Dictionary<string, int> _cache = new();

        public static int Get(string key, string vert, string frag)
        {
            if (_cache.TryGetValue(key, out int prog)) return prog;
            int vs = GL.CreateShader(ShaderType.VertexShader);
            GL.ShaderSource(vs, vert); GL.CompileShader(vs);
            int fs = GL.CreateShader(ShaderType.FragmentShader);
            GL.ShaderSource(fs, frag); GL.CompileShader(fs);
            prog = GL.CreateProgram();
            GL.AttachShader(prog, vs); GL.AttachShader(prog, fs);
            GL.LinkProgram(prog);
            GL.DeleteShader(vs); GL.DeleteShader(fs);
            _cache[key] = prog;
            return prog;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  SCREEN SHAKE
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Camera screen shake using trauma-based approach (better than simple sine).
    /// Higher trauma = more extreme shake. Trauma decays over time.
    ///
    /// Usage:
    ///   ScreenShake.AddTrauma(0.8f);         // big explosion
    ///   ScreenShake.AddTrauma(0.3f);         // small hit
    ///   Vector3 offset = ScreenShake.Update(dt);  // apply to camera position
    /// </summary>
    public static class ScreenShake
    {
        public static float MaxOffset   { get; set; } = 0.3f;
        public static float MaxRoll     { get; set; } = 5f;      // degrees
        public static float DecayRate   { get; set; } = 1.5f;
        public static float Frequency   { get; set; } = 25f;

        private static float   _trauma;
        private static float   _time;
        private static readonly Random _rng = new();

        private static float _seedX = (float)_rng.NextDouble() * 100;
        private static float _seedY = (float)_rng.NextDouble() * 100;
        private static float _seedR = (float)_rng.NextDouble() * 100;

        public static void AddTrauma(float amount)
            => _trauma = Math.Clamp(_trauma + amount, 0f, 1f);

        public static void SetTrauma(float value)
            => _trauma = Math.Clamp(value, 0f, 1f);

        /// <returns>
        /// (positionOffset, rollDegrees) — apply positionOffset to camera position,
        /// roll to camera z-rotation.
        /// </returns>
        public static (Vector3 offset, float roll) Update(float dt)
        {
            if (_trauma <= 0f) return (Vector3.Zero, 0f);

            _trauma = Math.Max(0f, _trauma - DecayRate * dt);
            _time   += dt * Frequency;

            float shake = _trauma * _trauma;  // trauma² for more dramatic falloff

            float x = MaxOffset * shake * Noise1D(_seedX + _time);
            float y = MaxOffset * shake * Noise1D(_seedY + _time);
            float r = MaxRoll   * shake * Noise1D(_seedR + _time);

            return (new Vector3(x, y, 0), r);
        }

        public static float Trauma => _trauma;

        // Smooth pseudo-random noise via sin hash
        private static float Noise1D(float t) =>
            MathF.Sin(t * 127.1f) * MathF.Sin(t * 311.7f) +
            MathF.Sin(t * 74.7f)  * MathF.Sin(t * 183.3f);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  TRAIL RENDERER
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Smooth trail that follows a Transform — swords, bullets, magic spells.
    ///
    /// Usage:
    ///   var trail = sword.AddComponent<TrailRenderer>();
    ///   trail.Color       = Color4.Cyan;
    ///   trail.Width       = 0.15f;
    ///   trail.LifeTime    = 0.4f;
    ///   trail.MinDistance = 0.05f;
    /// </summary>
    public sealed class TrailRenderer : Component
    {
        public Color4 StartColor  { get; set; } = Color4.White;
        public Color4 EndColor    { get; set; } = new Color4(1f, 1f, 1f, 0f);
        public float  StartWidth  { get; set; } = 0.2f;
        public float  EndWidth    { get; set; } = 0f;
        public float  LifeTime    { get; set; } = 0.5f;
        public float  MinDistance { get; set; } = 0.05f;
        public bool   WorldSpace  { get; set; } = true;

        private readonly struct TrailPoint
        {
            public readonly Vector3 Position;
            public readonly float   BirthTime;
            public TrailPoint(Vector3 p, float t) { Position = p; BirthTime = t; }
        }

        private readonly List<TrailPoint> _points = new(64);
        private int _vao, _vbo;
        private bool _glReady;
        private static int _shader;

        public override void Start() => EnsureGL();

        public override void Update(float dt)
        {
            float now = Time.ElapsedTime;

            // Add point if moved far enough
            var pos = WorldSpace ? Transform.Position : Vector3.Zero;
            if (_points.Count == 0 || (pos - _points[^1].Position).Length > MinDistance)
                _points.Add(new TrailPoint(pos, now));

            // Expire old points
            _points.RemoveAll(p => now - p.BirthTime > LifeTime);
        }

        public void Render(Matrix4 view, Matrix4 projection)
        {
            if (_points.Count < 2) return;
            EnsureGL();

            float now = Time.ElapsedTime;
            var verts = new List<float>();

            for (int i = 0; i < _points.Count; i++)
            {
                float t = i / (float)(_points.Count - 1);
                float age = (now - _points[i].BirthTime) / LifeTime;
                float w = BMath.Lerp(StartWidth, EndWidth, t) * 0.5f;

                // Perpendicular to trail direction in view space
                Vector3 dir = (i < _points.Count - 1)
                    ? Vector3.Normalize(_points[i+1].Position - _points[i].Position)
                    : Vector3.Normalize(_points[i].Position - _points[i-1].Position);
                Vector3 cam = -new Vector3(view.M13, view.M23, view.M33);
                Vector3 perp = Vector3.Normalize(Vector3.Cross(dir, cam)) * w;

                Color4 col = BMath.LerpColor(StartColor, EndColor, age);

                void AddVert(Vector3 p) {
                    verts.Add(p.X); verts.Add(p.Y); verts.Add(p.Z);
                    verts.Add(col.R); verts.Add(col.G); verts.Add(col.B); verts.Add(col.A);
                    verts.Add(t); verts.Add(i % 2);
                }

                AddVert(_points[i].Position + perp);
                AddVert(_points[i].Position - perp);
            }

            var data = verts.ToArray();
            GL.BindVertexArray(_vao);
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
            GL.BufferData(BufferTarget.ArrayBuffer, data.Length * 4, data, BufferUsageHint.DynamicDraw);

            var vp = view * projection;
            GL.UseProgram(_shader);
            GL.UniformMatrix4(GL.GetUniformLocation(_shader, "uVP"), false, ref vp);

            GL.Enable(EnableCap.Blend);
            GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
            GL.DrawArrays(PrimitiveType.TriangleStrip, 0, _points.Count * 2);
            GL.Disable(EnableCap.Blend);
            GL.BindVertexArray(0);
        }

        private void EnsureGL()
        {
            if (_glReady) return; _glReady = true;
            _vao = GL.GenVertexArray(); _vbo = GL.GenBuffer();
            GL.BindVertexArray(_vao);
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
            GL.BufferData(BufferTarget.ArrayBuffer, 1024*64, IntPtr.Zero, BufferUsageHint.DynamicDraw);
            int stride = 36;
            GL.EnableVertexAttribArray(0); GL.VertexAttribPointer(0,3,VertexAttribPointerType.Float,false,stride,0);
            GL.EnableVertexAttribArray(1); GL.VertexAttribPointer(1,4,VertexAttribPointerType.Float,false,stride,12);
            GL.EnableVertexAttribArray(2); GL.VertexAttribPointer(2,2,VertexAttribPointerType.Float,false,stride,28);
            GL.BindVertexArray(0);

            if (_shader == 0) _shader = ShaderCache.Get("trail",
                @"#version 330 core
layout(location=0) in vec3 aPos; layout(location=1) in vec4 aColor;
layout(location=2) in vec2 aUV;
out vec4 vColor; out vec2 vUV;
uniform mat4 uVP;
void main(){ vColor=aColor; vUV=aUV; gl_Position=uVP*vec4(aPos,1); }",
                @"#version 330 core
in vec4 vColor; in vec2 vUV; out vec4 FragColor;
void main(){ FragColor = vColor; }");
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  VFX PRESETS  — one-call effects for common game events
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Ready-made VFX presets. Spawn via VFXPresets.Spawn*(position).
    /// Each returns a GameObject that auto-destroys when the effect finishes.
    ///
    /// Presets: Explosion, Fire, MagicPortal, Rain, Snow, Sparks,
    ///          Shockwave, Blood, Smoke, HealBurst, ElectricArc, Confetti
    /// </summary>
    public static class VFXPresets
    {
        // ── Explosion ─────────────────────────────────────────────────────
        public static GameObject Explosion(Vector3 pos, float scale = 1f, Color4? color = null)
        {
            var go = SpawnPS(pos);
            var ps = go.GetComponent<ParticleSystem>()!;
            ps.EmissionRate    = 0f;
            ps.BurstCount      = (int)(120 * scale);
            ps.StartLifetime   = 1.2f;
            ps.StartSpeed      = 8f * scale;
            ps.StartSize       = 0.3f * scale;
            ps.StartColor      = (color ?? new Color4(1f, 0.5f, 0.1f, 1f)).ToVec3();
            ps.Looping         = false;
            ps.Shape           = EmissionShape.Sphere;
            ps.ShapeRadius     = 0.2f * scale;
            ps.GravityScale    = 0.5f;
            ps.SizeOverLifetime = AnimationCurve.EaseOut();
            ps.ColorOverLifetime = new[] { new Color4(1f,0.8f,0.2f,1f), new Color4(0.5f,0.1f,0f,0f) };
            ps.Play();
            AutoDestroy(go, 2f);
            return go;
        }

        // ── Fire ──────────────────────────────────────────────────────────
        public static GameObject Fire(Vector3 pos, float scale = 1f)
        {
            var go = SpawnPS(pos);
            var ps = go.GetComponent<ParticleSystem>()!;
            ps.EmissionRate    = 40f * scale;
            ps.StartLifetime   = 1.5f;
            ps.StartSpeed      = 2f * scale;
            ps.StartSize       = 0.25f * scale;
            ps.StartColor      = new Vector3(1f, 0.4f, 0f);
            ps.Shape           = EmissionShape.Circle;
            ps.ShapeRadius     = 0.2f * scale;
            ps.GravityScale    = -0.3f;  // rises
            ps.StartAlpha      = 0.9f;
            ps.SizeOverLifetime = AnimationCurve.EaseOut();
            ps.ColorOverLifetime = new[] { new Color4(1f,0.4f,0f,1f), new Color4(0.2f,0.1f,0f,0f) };
            ps.Play();
            return go;
        }

        // ── Magic Portal ──────────────────────────────────────────────────
        public static GameObject MagicPortal(Vector3 pos, Color4? color = null)
        {
            var col = color ?? new Color4(0.4f, 0.1f, 1f, 1f);
            var go  = SpawnPS(pos);
            var ps  = go.GetComponent<ParticleSystem>()!;
            ps.EmissionRate   = 60f;
            ps.StartLifetime  = 2f;
            ps.StartSpeed     = 1.5f;
            ps.StartSize      = 0.15f;
            ps.StartColor     = col.ToVec3();
            ps.Shape          = EmissionShape.Circle;
            ps.ShapeRadius    = 1.2f;
            ps.GravityScale   = 0f;
            ps.SizeOverLifetime = AnimationCurve.Linear();
            ps.ColorOverLifetime = new[] { col, new Color4(col.R, col.G, col.B, 0f) };
            ps.Play();
            return go;
        }

        // ── Sparks ────────────────────────────────────────────────────────
        public static GameObject Sparks(Vector3 pos, Vector3 normal)
        {
            var go = SpawnPS(pos);
            var ps = go.GetComponent<ParticleSystem>()!;
            ps.EmissionRate   = 0f;
            ps.BurstCount     = 30;
            ps.StartLifetime  = 0.6f;
            ps.StartSpeed     = 6f;
            ps.StartSize      = 0.05f;
            ps.StartColor     = new Vector3(1f, 0.9f, 0.3f);
            ps.Shape          = EmissionShape.Cone;
            ps.ShapeAngle     = normal;
            ps.GravityScale   = 2f;
            ps.Looping        = false;
            ps.Play();
            AutoDestroy(go, 1f);
            return go;
        }

        // ── Rain ──────────────────────────────────────────────────────────
        public static GameObject Rain(Vector3 pos, float areaSize = 20f)
        {
            var go = SpawnPS(pos + Vector3.UnitY * 10f);
            var ps = go.GetComponent<ParticleSystem>()!;
            ps.EmissionRate   = 300f;
            ps.StartLifetime  = 1.2f;
            ps.StartSpeed     = 12f;
            ps.StartSize      = 0.04f;
            ps.StartColor     = new Vector3(0.7f, 0.8f, 1f);
            ps.Shape          = EmissionShape.Box;
            ps.ShapeRadius    = areaSize;
            ps.GravityScale   = 3f;
            ps.StartAlpha     = 0.6f;
            ps.Play();
            return go;
        }

        // ── Snow ──────────────────────────────────────────────────────────
        public static GameObject Snow(Vector3 pos, float areaSize = 20f)
        {
            var go = SpawnPS(pos + Vector3.UnitY * 8f);
            var ps = go.GetComponent<ParticleSystem>()!;
            ps.EmissionRate   = 80f;
            ps.StartLifetime  = 4f;
            ps.StartSpeed     = 1.5f;
            ps.StartSize      = 0.12f;
            ps.StartColor     = new Vector3(1f, 1f, 1f);
            ps.Shape          = EmissionShape.Box;
            ps.ShapeRadius    = areaSize;
            ps.GravityScale   = 0.4f;
            ps.RandomSpeedVariance = 0.8f;
            ps.Play();
            return go;
        }

        // ── HealBurst ─────────────────────────────────────────────────────
        public static GameObject HealBurst(Vector3 pos)
        {
            var go = SpawnPS(pos);
            var ps = go.GetComponent<ParticleSystem>()!;
            ps.EmissionRate   = 0f;
            ps.BurstCount     = 40;
            ps.StartLifetime  = 1.5f;
            ps.StartSpeed     = 3f;
            ps.StartSize      = 0.2f;
            ps.StartColor     = new Vector3(0.2f, 1f, 0.3f);
            ps.Shape          = EmissionShape.Sphere;
            ps.ShapeRadius    = 0.5f;
            ps.GravityScale   = -1f;  // rises
            ps.Looping        = false;
            ps.ColorOverLifetime = new[] { new Color4(0.2f,1f,0.3f,1f), new Color4(0.2f,1f,0.3f,0f) };
            ps.Play();
            AutoDestroy(go, 2f);
            return go;
        }

        // ── Smoke ─────────────────────────────────────────────────────────
        public static GameObject Smoke(Vector3 pos, float scale = 1f)
        {
            var go = SpawnPS(pos);
            var ps = go.GetComponent<ParticleSystem>()!;
            ps.EmissionRate   = 15f * scale;
            ps.StartLifetime  = 4f;
            ps.StartSpeed     = 0.8f;
            ps.StartSize      = 0.4f * scale;
            ps.StartColor     = new Vector3(0.4f, 0.4f, 0.4f);
            ps.Shape          = EmissionShape.Sphere;
            ps.ShapeRadius    = 0.2f * scale;
            ps.GravityScale   = -0.2f;
            ps.StartAlpha     = 0.5f;
            ps.RandomSizeVariance = 0.3f;
            ps.SizeOverLifetime = AnimationCurve.EaseIn();
            ps.ColorOverLifetime = new[] { new Color4(0.5f,0.5f,0.5f,0.5f), new Color4(0.3f,0.3f,0.3f,0f) };
            ps.Play();
            return go;
        }

        // ── Confetti ──────────────────────────────────────────────────────
        public static GameObject Confetti(Vector3 pos)
        {
            var go = SpawnPS(pos);
            var ps = go.GetComponent<ParticleSystem>()!;
            ps.EmissionRate   = 0f;
            ps.BurstCount     = 80;
            ps.StartLifetime  = 3f;
            ps.StartSpeed     = 5f;
            ps.StartSize      = 0.12f;
            ps.StartColor     = new Vector3(1f, 0.3f, 0.8f);
            ps.Shape          = EmissionShape.Sphere;
            ps.ShapeRadius    = 0.3f;
            ps.GravityScale   = 1.5f;
            ps.Looping        = false;
            ps.Play();
            AutoDestroy(go, 4f);
            return go;
        }

        // ── Helpers ───────────────────────────────────────────────────────
        private static GameObject SpawnPS(Vector3 pos)
        {
            var go = new GameObject("VFX_Preset");
            go.Transform.Position = pos;
            go.AddComponent<ParticleSystem>();
            return go;
        }

        private static async void AutoDestroy(GameObject go, float delay)
        {
            await System.Threading.Tasks.Task.Delay((int)(delay * 1000));
            go.Destroy();
        }
    }

    // ── Extension helpers ──────────────────────────────────────────────────────
    internal static class ColorExt
    {
        public static Vector3 ToVec3(this Color4 c) => new(c.R, c.G, c.B);
    }

    // ── Stub AnimationCurve for presets ────────────────────────────────────────
    public static class AnimationCurve
    {
        public static float[] EaseOut()  => new float[] { 1f, 0.5f, 0.1f, 0f };
        public static float[] EaseIn()   => new float[] { 0f, 0.1f, 0.5f, 1f };
        public static float[] Linear()   => new float[] { 1f, 1f };
    }
}
