using System;

namespace BADGE.Editor
{
    public static class AudioTab
    {
        public static void PlayClip(Audio.AudioClip clip)
        {
            Console.WriteLine($"Playing: {clip.Name}");
        }
        
        public static void RecordAudio()
        {
            Console.WriteLine("Recording audio...");
        }
    }
}
