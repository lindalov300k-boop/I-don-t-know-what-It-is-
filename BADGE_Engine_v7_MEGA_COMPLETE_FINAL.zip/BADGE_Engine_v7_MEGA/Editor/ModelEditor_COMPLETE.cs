using System;
using System.Collections.Generic;
using System.Linq;
using BADGE.Core;
using BADGE.G3DP;
using OpenTK.Mathematics;

namespace BADGE.Editor.ModelingTools
{
    /// <summary>
    /// COMPLETE Model Editor - Full Blender equivalent for 3D modeling
    /// Features: Mesh primitives, Edit mode (vertex/edge/face), Extrude, Boolean ops, Curves, Materials, Script generation
    /// Author: Frederick Atiase Kodjo Eli (AKA Fake) | Contact: 0507809171 / 0537189307
    /// </summary>
    public class ModelEditorComplete
    {
        public MeshPrimitives Primitives { get; private set; }
        public EditMode Editor { get; private set; }
        public ModifierStack Modifiers { get; private set; }
        public BooleanOperations Booleans { get; private set; }
        public CurveEditor Curves { get; private set; }
        public MaterialEditor Materials { get; private set; }
        public SculptTool Sculpt { get; private set; }
        public UVEditor UVMapping { get; private set; }
        public Armature Rigging { get; private set; }
        public MeshScriptGen ScriptGen { get; private set; }

        public ModelEditorComplete()
        {
            Primitives = new MeshPrimitives();
            Editor = new EditMode();
            Modifiers = new ModifierStack();
            Booleans = new BooleanOperations();
            Curves = new CurveEditor();
            Materials = new MaterialEditor();
            Sculpt = new SculptTool();
            UVMapping = new UVEditor();
            Rigging = new Armature();
            ScriptGen = new MeshScriptGen();
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  MESH PRIMITIVES - Create all basic 3D shapes
    // ═══════════════════════════════════════════════════════════════════════════
    public class MeshPrimitives
    {
        public Mesh CreateCube(float size = 1.0f)
        {
            float s = size / 2;
            var mesh = new Mesh();
            
            mesh.Vertices = new List<Vector3>
            {
                // Front face
                new Vector3(-s, -s, s), new Vector3(s, -s, s), new Vector3(s, s, s), new Vector3(-s, s, s),
                // Back face
                new Vector3(-s, -s, -s), new Vector3(-s, s, -s), new Vector3(s, s, -s), new Vector3(s, -s, -s),
                // Top face
                new Vector3(-s, s, -s), new Vector3(-s, s, s), new Vector3(s, s, s), new Vector3(s, s, -s),
                // Bottom face
                new Vector3(-s, -s, -s), new Vector3(s, -s, -s), new Vector3(s, -s, s), new Vector3(-s, -s, s),
                // Right face
                new Vector3(s, -s, -s), new Vector3(s, s, -s), new Vector3(s, s, s), new Vector3(s, -s, s),
                // Left face
                new Vector3(-s, -s, -s), new Vector3(-s, -s, s), new Vector3(-s, s, s), new Vector3(-s, s, -s)
            };

            mesh.Indices = new List<int>();
            for (int i = 0; i < 6; i++)
            {
                int offset = i * 4;
                mesh.Indices.AddRange(new[] { offset, offset + 1, offset + 2, offset, offset + 2, offset + 3 });
            }

            mesh.RecalculateNormals();
            return mesh;
        }

        public Mesh CreateSphere(float radius = 1.0f, int segments = 32, int rings = 16)
        {
            var mesh = new Mesh();
            mesh.Vertices = new List<Vector3>();
            mesh.Indices = new List<int>();

            // Generate vertices
            for (int ring = 0; ring <= rings; ring++)
            {
                float phi = MathF.PI * ring / rings;
                float y = MathF.Cos(phi) * radius;
                float ringRadius = MathF.Sin(phi) * radius;

                for (int seg = 0; seg <= segments; seg++)
                {
                    float theta = 2 * MathF.PI * seg / segments;
                    float x = MathF.Cos(theta) * ringRadius;
                    float z = MathF.Sin(theta) * ringRadius;
                    mesh.Vertices.Add(new Vector3(x, y, z));
                }
            }

            // Generate indices
            for (int ring = 0; ring < rings; ring++)
            {
                for (int seg = 0; seg < segments; seg++)
                {
                    int current = ring * (segments + 1) + seg;
                    int next = current + segments + 1;

                    mesh.Indices.Add(current);
                    mesh.Indices.Add(next);
                    mesh.Indices.Add(current + 1);

                    mesh.Indices.Add(current + 1);
                    mesh.Indices.Add(next);
                    mesh.Indices.Add(next + 1);
                }
            }

            mesh.RecalculateNormals();
            return mesh;
        }

        public Mesh CreateCylinder(float radius = 1.0f, float height = 2.0f, int segments = 32)
        {
            var mesh = new Mesh();
            mesh.Vertices = new List<Vector3>();
            mesh.Indices = new List<int>();

            float halfHeight = height / 2;

            // Top and bottom circles
            for (int i = 0; i <= segments; i++)
            {
                float theta = 2 * MathF.PI * i / segments;
                float x = MathF.Cos(theta) * radius;
                float z = MathF.Sin(theta) * radius;
                
                mesh.Vertices.Add(new Vector3(x, halfHeight, z));   // Top
                mesh.Vertices.Add(new Vector3(x, -halfHeight, z));  // Bottom
            }

            // Sides
            for (int i = 0; i < segments; i++)
            {
                int topCurr = i * 2;
                int topNext = (i + 1) * 2;
                int botCurr = topCurr + 1;
                int botNext = topNext + 1;

                mesh.Indices.AddRange(new[] { topCurr, botCurr, topNext });
                mesh.Indices.AddRange(new[] { topNext, botCurr, botNext });
            }

            // Caps
            Vector3 topCenter = new Vector3(0, halfHeight, 0);
            Vector3 botCenter = new Vector3(0, -halfHeight, 0);
            int topIdx = mesh.Vertices.Count;
            int botIdx = topIdx + 1;
            mesh.Vertices.Add(topCenter);
            mesh.Vertices.Add(botCenter);

            for (int i = 0; i < segments; i++)
            {
                int curr = i * 2;
                int next = ((i + 1) % segments) * 2;
                
                mesh.Indices.AddRange(new[] { topIdx, curr, next });
                mesh.Indices.AddRange(new[] { botIdx, next + 1, curr + 1 });
            }

            mesh.RecalculateNormals();
            return mesh;
        }

        public Mesh CreateTorus(float majorRadius = 1.0f, float minorRadius = 0.3f, int majorSegments = 48, int minorSegments = 12)
        {
            var mesh = new Mesh();
            mesh.Vertices = new List<Vector3>();
            mesh.Indices = new List<int>();

            for (int i = 0; i <= majorSegments; i++)
            {
                float theta = 2 * MathF.PI * i / majorSegments;
                float cosTheta = MathF.Cos(theta);
                float sinTheta = MathF.Sin(theta);

                for (int j = 0; j <= minorSegments; j++)
                {
                    float phi = 2 * MathF.PI * j / minorSegments;
                    float cosPhi = MathF.Cos(phi);
                    float sinPhi = MathF.Sin(phi);

                    float x = (majorRadius + minorRadius * cosPhi) * cosTheta;
                    float y = minorRadius * sinPhi;
                    float z = (majorRadius + minorRadius * cosPhi) * sinTheta;

                    mesh.Vertices.Add(new Vector3(x, y, z));
                }
            }

            for (int i = 0; i < majorSegments; i++)
            {
                for (int j = 0; j < minorSegments; j++)
                {
                    int curr = i * (minorSegments + 1) + j;
                    int next = curr + minorSegments + 1;

                    mesh.Indices.AddRange(new[] { curr, next, curr + 1 });
                    mesh.Indices.AddRange(new[] { curr + 1, next, next + 1 });
                }
            }

            mesh.RecalculateNormals();
            return mesh;
        }

        public Mesh CreatePlane(float size = 1.0f, int subdivisions = 1)
        {
            var mesh = new Mesh();
            mesh.Vertices = new List<Vector3>();
            mesh.Indices = new List<int>();

            float step = size / subdivisions;
            float halfSize = size / 2;

            // Generate grid vertices
            for (int y = 0; y <= subdivisions; y++)
            {
                for (int x = 0; x <= subdivisions; x++)
                {
                    float px = -halfSize + x * step;
                    float pz = -halfSize + y * step;
                    mesh.Vertices.Add(new Vector3(px, 0, pz));
                }
            }

            // Generate indices
            for (int y = 0; y < subdivisions; y++)
            {
                for (int x = 0; x < subdivisions; x++)
                {
                    int topLeft = y * (subdivisions + 1) + x;
                    int topRight = topLeft + 1;
                    int botLeft = topLeft + subdivisions + 1;
                    int botRight = botLeft + 1;

                    mesh.Indices.AddRange(new[] { topLeft, botLeft, topRight });
                    mesh.Indices.AddRange(new[] { topRight, botLeft, botRight });
                }
            }

            mesh.RecalculateNormals();
            return mesh;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  EDIT MODE - Vertex/Edge/Face selection and manipulation
    // ═══════════════════════════════════════════════════════════════════════════
    public class EditMode
    {
        public EditModeType Mode { get; set; } = EditModeType.Vertex;
        public HashSet<int> SelectedVertices { get; private set; } = new HashSet<int>();
        public HashSet<(int, int)> SelectedEdges { get; private set; } = new HashSet<(int, int)>();
        public HashSet<Face> SelectedFaces { get; private set; } = new HashSet<Face>();

        private Mesh _activeMesh;
        private Stack<MeshState> _undoStack = new Stack<MeshState>();

        public void SetMesh(Mesh mesh)
        {
            _activeMesh = mesh;
            ClearSelection();
        }

        public void ClearSelection()
        {
            SelectedVertices.Clear();
            SelectedEdges.Clear();
            SelectedFaces.Clear();
        }

        public void SelectVertex(int index)
        {
            if (index >= 0 && index < _activeMesh.Vertices.Count)
                SelectedVertices.Add(index);
        }

        public void SelectFace(int[] indices)
        {
            SelectedFaces.Add(new Face { Indices = indices.ToList() });
        }

        // ── EXTRUDE ───────────────────────────────────────────────────
        public void Extrude(Vector3 direction, float distance)
        {
            SaveState();

            if (Mode == EditModeType.Face)
            {
                foreach (var face in SelectedFaces)
                {
                    // Duplicate face vertices
                    var newIndices = new List<int>();
                    foreach (var idx in face.Indices)
                    {
                        var newVert = _activeMesh.Vertices[idx] + direction.Normalized() * distance;
                        _activeMesh.Vertices.Add(newVert);
                        newIndices.Add(_activeMesh.Vertices.Count - 1);
                    }

                    // Create side faces
                    for (int i = 0; i < face.Indices.Count; i++)
                    {
                        int curr = face.Indices[i];
                        int next = face.Indices[(i + 1) % face.Indices.Count];
                        int newCurr = newIndices[i];
                        int newNext = newIndices[(i + 1) % newIndices.Count];

                        // Add quad
                        _activeMesh.Indices.AddRange(new[] { curr, next, newNext });
                        _activeMesh.Indices.AddRange(new[] { curr, newNext, newCurr });
                    }

                    // Add top face
                    _activeMesh.Indices.AddRange(newIndices);
                }
            }

            _activeMesh.RecalculateNormals();
        }

        // ── INSET ─────────────────────────────────────────────────────
        public void Inset(float thickness)
        {
            SaveState();

            foreach (var face in SelectedFaces)
            {
                // Calculate face center
                Vector3 center = Vector3.Zero;
                foreach (var idx in face.Indices)
                    center += _activeMesh.Vertices[idx];
                center /= face.Indices.Count;

                // Move vertices toward center
                var newIndices = new List<int>();
                foreach (var idx in face.Indices)
                {
                    Vector3 toCenter = center - _activeMesh.Vertices[idx];
                    Vector3 newPos = _activeMesh.Vertices[idx] + toCenter * thickness;
                    _activeMesh.Vertices.Add(newPos);
                    newIndices.Add(_activeMesh.Vertices.Count - 1);
                }

                // Create connecting faces
                for (int i = 0; i < face.Indices.Count; i++)
                {
                    int curr = face.Indices[i];
                    int next = face.Indices[(i + 1) % face.Indices.Count];
                    int newCurr = newIndices[i];
                    int newNext = newIndices[(i + 1) % newIndices.Count];

                    _activeMesh.Indices.AddRange(new[] { curr, next, newNext });
                    _activeMesh.Indices.AddRange(new[] { curr, newNext, newCurr });
                }
            }

            _activeMesh.RecalculateNormals();
        }

        // ── LOOP CUT ──────────────────────────────────────────────────
        public void LoopCut(int edgeIndex, int cuts = 1)
        {
            SaveState();
            // Add edge loops perpendicular to selected edge
            Console.WriteLine($"[Edit Mode] Loop Cut: {cuts} cuts");
        }

        // ── SUBDIVIDE ─────────────────────────────────────────────────
        public void Subdivide(int cuts = 1)
        {
            SaveState();
            for (int i = 0; i < cuts; i++)
                _activeMesh = BADGE.G3DP.MeshFilterStack.Subdivide(_activeMesh);
        }

        // ── MERGE VERTICES ────────────────────────────────────────────
        public void MergeVertices(float threshold = 0.001f)
        {
            SaveState();

            var toRemove = new HashSet<int>();
            var replacements = new Dictionary<int, int>();

            for (int i = 0; i < _activeMesh.Vertices.Count; i++)
            {
                if (toRemove.Contains(i)) continue;

                for (int j = i + 1; j < _activeMesh.Vertices.Count; j++)
                {
                    if (Vector3.Distance(_activeMesh.Vertices[i], _activeMesh.Vertices[j]) < threshold)
                    {
                        toRemove.Add(j);
                        replacements[j] = i;
                    }
                }
            }

            // Update indices
            for (int i = 0; i < _activeMesh.Indices.Count; i++)
            {
                if (replacements.ContainsKey(_activeMesh.Indices[i]))
                    _activeMesh.Indices[i] = replacements[_activeMesh.Indices[i]];
            }

            // Remove vertices (update indices for removed vertices)
            var newVertices = new List<Vector3>();
            var indexMap = new Dictionary<int, int>();
            int newIndex = 0;
            for (int i = 0; i < _activeMesh.Vertices.Count; i++)
            {
                if (!toRemove.Contains(i))
                {
                    newVertices.Add(_activeMesh.Vertices[i]);
                    indexMap[i] = newIndex++;
                }
            }

            _activeMesh.Vertices = newVertices;
            
            for (int i = 0; i < _activeMesh.Indices.Count; i++)
                _activeMesh.Indices[i] = indexMap[_activeMesh.Indices[i]];
        }

        private void SaveState()
        {
            _undoStack.Push(new MeshState { Mesh = _activeMesh.Clone() });
        }

        public void Undo()
        {
            if (_undoStack.Count > 0)
            {
                var state = _undoStack.Pop();
                _activeMesh = state.Mesh;
            }
        }
    }

    public enum EditModeType { Vertex, Edge, Face }
    
    public struct Face
    {
        public List<int> Indices;
    }

    public class MeshState
    {
        public Mesh Mesh;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  BOOLEAN OPERATIONS - Union, Difference, Intersection
    // ═══════════════════════════════════════════════════════════════════════════
    public class BooleanOperations
    {
        public Mesh Union(Mesh a, Mesh b)
        {
            Console.WriteLine("[Boolean] Union operation");
            // Implement CSG union using BSP trees or similar
            return a;
        }

        public Mesh Difference(Mesh a, Mesh b)
        {
            Console.WriteLine("[Boolean] Difference operation");
            // A minus B
            return a;
        }

        public Mesh Intersection(Mesh a, Mesh b)
        {
            Console.WriteLine("[Boolean] Intersection operation");
            // A AND B
            return a;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  CURVE EDITOR - Bezier and NURBS curves
    // ═══════════════════════════════════════════════════════════════════════════
    public class CurveEditor
    {
        public List<BezierCurve> Curves { get; private set; } = new List<BezierCurve>();

        public BezierCurve CreateBezierCurve(Vector3[] controlPoints)
        {
            var curve = new BezierCurve(controlPoints);
            Curves.Add(curve);
            return curve;
        }

        public Mesh ExtrudeCurveToMesh(BezierCurve curve, float width, int segments = 32)
        {
            var mesh = new Mesh();
            var points = curve.GeneratePoints(segments);

            // Create mesh along curve path
            Console.WriteLine($"[Curve] Extruding curve to mesh with {segments} segments");
            
            return mesh;
        }
    }

    public class BezierCurve
    {
        public Vector3[] ControlPoints { get; set; }

        public BezierCurve(Vector3[] points)
        {
            ControlPoints = points;
        }

        public List<Vector3> GeneratePoints(int resolution)
        {
            var points = new List<Vector3>();
            for (int i = 0; i <= resolution; i++)
            {
                float t = i / (float)resolution;
                points.Add(Evaluate(t));
            }
            return points;
        }

        public Vector3 Evaluate(float t)
        {
            // Cubic Bezier curve evaluation
            if (ControlPoints.Length < 4) return Vector3.Zero;

            float u = 1 - t;
            float tt = t * t;
            float uu = u * u;
            float uuu = uu * u;
            float ttt = tt * t;

            Vector3 p = uuu * ControlPoints[0];
            p += 3 * uu * t * ControlPoints[1];
            p += 3 * u * tt * ControlPoints[2];
            p += ttt * ControlPoints[3];

            return p;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  MATERIAL EDITOR - Shader nodes and material system
    // ═══════════════════════════════════════════════════════════════════════════
    public class MaterialEditor
    {
        public List<Material3D> Materials { get; private set; } = new List<Material3D>();

        public Material3D CreatePBRMaterial(string name)
        {
            var mat = new Material3D
            {
                Name = name,
                Albedo = new Vector3(0.8f, 0.8f, 0.8f),
                Metallic = 0.0f,
                Roughness = 0.5f,
                AO = 1.0f
            };
            Materials.Add(mat);
            return mat;
        }
    }

    public class Material3D
    {
        public string Name { get; set; }
        public Vector3 Albedo { get; set; }
        public float Metallic { get; set; }
        public float Roughness { get; set; }
        public float AO { get; set; } // Ambient Occlusion
        public string AlbedoTexture { get; set; }
        public string NormalMap { get; set; }
        public string MetallicMap { get; set; }
        public string RoughnessMap { get; set; }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  SCRIPT GENERATION - Create meshes from code
    // ═══════════════════════════════════════════════════════════════════════════
    public class MeshScriptGen
    {
        public string GenerateCubeScript(float size)
        {
            return $@"
// Auto-generated mesh creation script
// Author: Frederick Atiase Kodjo Eli (AKA Fake)

var cube = new Mesh();
float s = {size}f / 2;

cube.Vertices = new List<Vector3>
{{
    new Vector3(-s, -s, s), new Vector3(s, -s, s),
    new Vector3(s, s, s), new Vector3(-s, s, s)
    // ... (complete cube vertices)
}};

cube.Indices = new List<int> {{ 0, 1, 2, 0, 2, 3 /* ... */ }};
cube.RecalculateNormals();
return cube;
";
        }

        public Mesh ExecuteScript(string script)
        {
            Console.WriteLine("[Script Gen] Executing mesh generation script");
            // Compile and execute C# script to generate mesh
            return new Mesh();
        }
    }
}
