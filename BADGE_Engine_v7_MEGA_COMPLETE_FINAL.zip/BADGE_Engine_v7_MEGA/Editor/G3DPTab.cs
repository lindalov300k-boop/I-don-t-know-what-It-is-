using ImGuiNET;
using System.Numerics;
using BADGE.G3DP;
using BADGE.Core;

namespace BADGE.Editor;

/// <summary>
/// G3DP (3D Primitives) Tab — create and modify meshes in the editor.
/// Exposes primitive creation, modifier stack, UV controls.
/// </summary>
public static class G3DPTab
{
    private static MeshModifierState _state = new();

    public static void Render(GameObject? selected)
    {
        if (!ImGui.BeginTabItem("G3DP")) return;

        ImGui.Text("3D Geometry Tools");
        ImGui.Separator();

        // ── Primitive creation ─────────────────────────────────────────
        if (ImGui.CollapsingHeader("Create Primitive", ImGuiTreeNodeFlags.DefaultOpen))
        {
            if (ImGui.Button("Cube"))     SpawnPrimitive(PrimitiveType.Cube);
            ImGui.SameLine();
            if (ImGui.Button("Sphere"))   SpawnPrimitive(PrimitiveType.Sphere);
            ImGui.SameLine();
            if (ImGui.Button("Cylinder")) SpawnPrimitive(PrimitiveType.Cylinder);
            ImGui.SameLine();
            if (ImGui.Button("Capsule"))  SpawnPrimitive(PrimitiveType.Capsule);
            if (ImGui.Button("Plane"))    SpawnPrimitive(PrimitiveType.Plane);
            ImGui.SameLine();
            if (ImGui.Button("Quad"))     SpawnPrimitive(PrimitiveType.Quad);
        }

        // ── Modifier stack ─────────────────────────────────────────────
        if (selected != null && ImGui.CollapsingHeader("Modifier Stack"))
        {
            var mf = selected.GetComponent<MeshFilter>();
            if (mf?.Mesh != null)
            {
                ImGui.Text($"Mesh: {mf.Mesh.Name}  |  " +
                           $"Verts: {mf.Mesh.Vertices.Length}  |  " +
                           $"Tris: {mf.Mesh.Triangles.Length / 3}");

                ImGui.Separator();

                if (ImGui.Button("Subdivide (1x)"))
                    mf.Mesh = MeshFilterStack.Subdivide(mf.Mesh);

                ImGui.SameLine();
                ImGui.SetNextItemWidth(80);
                ImGui.SliderFloat("##smooth", ref _state.SmoothFactor, 0f, 1f);
                ImGui.SameLine();
                if (ImGui.Button("Smooth"))
                    mf.Mesh = MeshFilterStack.Smooth(mf.Mesh, _state.SmoothFactor);

                ImGui.Separator();
                ImGui.SetNextItemWidth(120);
                ImGui.SliderFloat("Noise Strength##nd", ref _state.NoiseStrength, 0f, 0.5f);
                ImGui.SetNextItemWidth(120);
                ImGui.SliderFloat("Noise Freq##nf", ref _state.NoiseFreq, 0.1f, 10f);
                ImGui.SameLine();
                if (ImGui.Button("Noise Deform"))
                    mf.Mesh = MeshFilterStack.NoiseDeform(mf.Mesh, _state.NoiseStrength,
                                                            _state.NoiseFreq);

                ImGui.Separator();
                if (ImGui.Button("Mirror X")) mf.Mesh = MeshFilterStack.Mirror(mf.Mesh, MeshFilterStack.MirrorAxis.X);
                ImGui.SameLine();
                if (ImGui.Button("Mirror Y")) mf.Mesh = MeshFilterStack.Mirror(mf.Mesh, MeshFilterStack.MirrorAxis.Y);
                ImGui.SameLine();
                if (ImGui.Button("Mirror Z")) mf.Mesh = MeshFilterStack.Mirror(mf.Mesh, MeshFilterStack.MirrorAxis.Z);

                // Rebuild GPU buffers after any modification
                mf.Mesh.UploadToGPU();
            }
            else
            {
                ImGui.TextDisabled("No mesh on selected GameObject.");
            }
        }

        // ── Transform nudge ────────────────────────────────────────────
        if (selected != null && ImGui.CollapsingHeader("Transform"))
        {
            var t = selected.Transform;
            var pos = new Vector3(t.Position.X, t.Position.Y, t.Position.Z);
            var rot = new Vector3(t.EulerAngles.X, t.EulerAngles.Y, t.EulerAngles.Z);
            var scl = new Vector3(t.LocalScale.X, t.LocalScale.Y, t.LocalScale.Z);

            if (ImGui.DragFloat3("Position##gpos", ref pos, 0.1f))
                t.Position = new OpenTK.Mathematics.Vector3(pos.X, pos.Y, pos.Z);
            if (ImGui.DragFloat3("Rotation##grot", ref rot, 1f))
                t.EulerAngles = new OpenTK.Mathematics.Vector3(rot.X, rot.Y, rot.Z);
            if (ImGui.DragFloat3("Scale##gscl", ref scl, 0.05f))
                t.LocalScale = new OpenTK.Mathematics.Vector3(scl.X, scl.Y, scl.Z);
        }

        ImGui.EndTabItem();
    }

    private static void SpawnPrimitive(PrimitiveType type)
    {
        var scene = SceneManager.GetActiveScene();
        if (scene == null) return;
        var go = scene.CreateGameObject(type.ToString());
        var mf = go.AddComponent<MeshFilter>();
        var mr = go.AddComponent<MeshRenderer>();
        mf.Mesh     = PrimitiveMeshFactory.CreatePrimitive(type);
        mr.Material = new Material();
    }

    private class MeshModifierState
    {
        public float SmoothFactor  = 0.5f;
        public float NoiseStrength = 0.05f;
        public float NoiseFreq     = 2f;
    }
}
