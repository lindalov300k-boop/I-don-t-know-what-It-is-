using System;
using System.Collections.Generic;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;

namespace BADGE.Editor
{
    /// <summary>
    /// Design Tab — pixel-art / texture paint canvas.
    /// Maintains an RGBA byte buffer that can be painted on pixel by pixel
    /// and flushed to a GPU texture for display.
    /// </summary>
    public static class DesignTab
    {
        public static int  CanvasWidth  { get; set; } = 64;
        public static int  CanvasHeight { get; set; } = 64;
        public static bool PixelPerfect { get; set; } = true;

        private static byte[]? _pixels;
        private static int     _textureHandle;
        private static bool    _dirty;
        private static bool    _initialized;

        // ── Initialize canvas ─────────────────────────────────────────────
        public static void Initialize(int width, int height)
        {
            CanvasWidth  = width;
            CanvasHeight = height;
            _pixels = new byte[width * height * 4]; // RGBA
            Fill(0, 0, 0, 0);   // transparent

            _textureHandle = GL.GenTexture();
            GL.BindTexture(TextureTarget.Texture2D, _textureHandle);
            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba8,
                          width, height, 0, PixelFormat.Rgba, PixelType.UnsignedByte, _pixels);
            GL.TexParameter(TextureTarget.Texture2D,
                            TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
            GL.TexParameter(TextureTarget.Texture2D,
                            TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Nearest);
            GL.BindTexture(TextureTarget.Texture2D, 0);
            _initialized = true;
        }

        // ── Draw pixel ────────────────────────────────────────────────────
        /// <summary>
        /// Paint a single pixel at (x, y) with the given RGBA colour.
        /// Coordinates are in canvas space (0,0 = top-left).
        /// </summary>
        public static void DrawPixel(int x, int y, byte r, byte g, byte b, byte a = 255)
        {
            if (_pixels == null || x < 0 || y < 0 || x >= CanvasWidth || y >= CanvasHeight)
                return;

            int idx = (y * CanvasWidth + x) * 4;
            _pixels[idx]     = r;
            _pixels[idx + 1] = g;
            _pixels[idx + 2] = b;
            _pixels[idx + 3] = a;
            _dirty = true;
        }

        // ── Draw line (Bresenham) ─────────────────────────────────────────
        public static void DrawLine(int x0, int y0, int x1, int y1,
                                     byte r, byte g, byte b, byte a = 255)
        {
            int dx = Math.Abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
            int dy = -Math.Abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
            int err = dx + dy;

            while (true)
            {
                DrawPixel(x0, y0, r, g, b, a);
                if (x0 == x1 && y0 == y1) break;
                int e2 = 2 * err;
                if (e2 >= dy) { err += dy; x0 += sx; }
                if (e2 <= dx) { err += dx; y0 += sy; }
            }
        }

        // ── Fill rect ─────────────────────────────────────────────────────
        public static void FillRect(int x, int y, int w, int h,
                                     byte r, byte g, byte b, byte a = 255)
        {
            for (int py = y; py < y + h; py++)
            for (int px = x; px < x + w; px++)
                DrawPixel(px, py, r, g, b, a);
        }

        // ── Flood fill ────────────────────────────────────────────────────
        public static void FloodFill(int x, int y, byte r, byte g, byte b, byte a = 255)
        {
            if (_pixels == null || x < 0 || y < 0 || x >= CanvasWidth || y >= CanvasHeight) return;

            int idx = (y * CanvasWidth + x) * 4;
            byte tr = _pixels[idx], tg = _pixels[idx+1], tb = _pixels[idx+2], ta = _pixels[idx+3];
            if (tr == r && tg == g && tb == b && ta == a) return;

            var stack = new Stack<(int, int)>();
            stack.Push((x, y));

            while (stack.Count > 0)
            {
                var (cx, cy) = stack.Pop();
                if (cx < 0 || cy < 0 || cx >= CanvasWidth || cy >= CanvasHeight) continue;
                int i = (cy * CanvasWidth + cx) * 4;
                if (_pixels[i] != tr || _pixels[i+1] != tg || _pixels[i+2] != tb || _pixels[i+3] != ta) continue;

                DrawPixel(cx, cy, r, g, b, a);
                stack.Push((cx-1, cy)); stack.Push((cx+1, cy));
                stack.Push((cx, cy-1)); stack.Push((cx, cy+1));
            }
        }

        // ── Canvas fill ───────────────────────────────────────────────────
        public static void Fill(byte r, byte g, byte b, byte a = 255)
        {
            if (_pixels == null) return;
            for (int i = 0; i < _pixels.Length; i += 4)
            { _pixels[i] = r; _pixels[i+1] = g; _pixels[i+2] = b; _pixels[i+3] = a; }
            _dirty = true;
        }

        // ── GPU upload ────────────────────────────────────────────────────
        /// <summary>Upload dirty pixels to the GPU texture.</summary>
        public static void Flush()
        {
            if (!_dirty || _pixels == null || !_initialized) return;
            GL.BindTexture(TextureTarget.Texture2D, _textureHandle);
            GL.TexSubImage2D(TextureTarget.Texture2D, 0, 0, 0,
                             CanvasWidth, CanvasHeight,
                             PixelFormat.Rgba, PixelType.UnsignedByte, _pixels);
            GL.BindTexture(TextureTarget.Texture2D, 0);
            _dirty = false;
        }

        public static int GetTextureHandle() => _textureHandle;
        public static byte[]? GetPixels()    => _pixels;
    }
}
