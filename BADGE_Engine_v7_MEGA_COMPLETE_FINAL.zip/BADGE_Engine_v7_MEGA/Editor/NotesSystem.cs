using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Newtonsoft.Json;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

namespace BADGE.Editor
{
    /// <summary>
    /// REAL Working Notes System with Delta Time Tracking
    /// Supports Word (.docx) and TXT export/import
    /// Author: Frederick Atiase Kodjo Eli (AKA Fake)
    /// Contact: 0507809171 / 0537189307
    /// </summary>
    public class NotesSystem
    {
        public List<Note> Notes { get; private set; } = new List<Note>();
        public List<NoteSession> Sessions { get; private set; } = new List<NoteSession>();
        public NoteSession? CurrentSession { get; private set; }
        
        private float _sessionStartTime;
        private float _totalProjectTime;
        
        public NotesSystem()
        {
            Console.WriteLine("[Notes] Notes System initialized - REAL implementation");
            StartNewSession();
        }
        
        /// <summary>
        /// Start a new note-taking session with delta time tracking
        /// </summary>
        public void StartNewSession(string sessionName = "")
        {
            if (CurrentSession != null)
            {
                CurrentSession.EndTime = DateTime.Now;
                CurrentSession.Duration = (CurrentSession.EndTime - CurrentSession.StartTime).TotalSeconds;
            }
            
            CurrentSession = new NoteSession
            {
                SessionName = string.IsNullOrEmpty(sessionName) ? 
                    $"Session {Sessions.Count + 1}" : sessionName,
                StartTime = DateTime.Now,
                DeltaTimeStart = _sessionStartTime
            };
            
            Sessions.Add(CurrentSession);
            _sessionStartTime = BADGE.Core.Time.TotalTime;
            
            Console.WriteLine($"[Notes] Started new session: {CurrentSession.SessionName}");
        }
        
        /// <summary>
        /// Add a note with automatic timestamping
        /// </summary>
        public Note AddNote(string title, string content, NoteCategory category = NoteCategory.General)
        {
            float currentDeltaTime = BADGE.Core.Time.TotalTime;
            float sessionElapsed = currentDeltaTime - _sessionStartTime;
            
            var note = new Note
            {
                Id = Guid.NewGuid().ToString(),
                Title = title,
                Content = content,
                Category = category,
                CreatedAt = DateTime.Now,
                DeltaTime = currentDeltaTime,
                SessionDeltaTime = sessionElapsed,
                SessionId = CurrentSession?.SessionName ?? "Unknown"
            };
            
            Notes.Add(note);
            CurrentSession?.Notes.Add(note);
            
            Console.WriteLine($"[Notes] Added note '{title}' at delta time {currentDeltaTime:F2}s");
            
            return note;
        }
        
        /// <summary>
        /// Quick note - just content
        /// </summary>
        public Note QuickNote(string content)
        {
            return AddNote($"Note {DateTime.Now:HH:mm:ss}", content);
        }
        
        /// <summary>
        /// Update existing note
        /// </summary>
        public void UpdateNote(string noteId, string newContent)
        {
            var note = Notes.Find(n => n.Id == noteId);
            if (note != null)
            {
                note.Content = newContent;
                note.ModifiedAt = DateTime.Now;
                note.ModifiedDeltaTime = BADGE.Core.Time.TotalTime;
            }
        }
        
        /// <summary>
        /// Export all notes to Word document
        /// </summary>
        public void ExportToWord(string filepath)
        {
            try
            {
                using (WordprocessingDocument doc = WordprocessingDocument.Create(filepath, WordprocessingDocumentType.Document))
                {
                    MainDocumentPart mainPart = doc.AddMainDocumentPart();
                    mainPart.Document = new Document();
                    Body body = mainPart.Document.AppendChild(new Body());
                    
                    // Title
                    Paragraph titlePara = body.AppendChild(new Paragraph());
                    Run titleRun = titlePara.AppendChild(new Run());
                    titleRun.AppendChild(new Text($"BADGE Engine v7 - Project Notes"));
                    RunProperties titleProps = titleRun.AppendChild(new RunProperties());
                    titleProps.AppendChild(new Bold());
                    titleProps.AppendChild(new FontSize { Val = "32" });
                    
                    // Metadata
                    AddParagraph(body, $"Author: Frederick Atiase Kodjo Eli (AKA Fake)", true);
                    AddParagraph(body, $"Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                    AddParagraph(body, $"Total Project Time: {FormatDeltaTime(_totalProjectTime)}");
                    AddParagraph(body, $"Total Notes: {Notes.Count}");
                    AddParagraph(body, "");
                    
                    // Sessions
                    foreach (var session in Sessions)
                    {
                        AddParagraph(body, $"=== {session.SessionName} ===", true);
                        AddParagraph(body, $"Start: {session.StartTime:yyyy-MM-dd HH:mm:ss}");
                        if (session.EndTime != DateTime.MinValue)
                        {
                            AddParagraph(body, $"End: {session.EndTime:yyyy-MM-dd HH:mm:ss}");
                            AddParagraph(body, $"Duration: {FormatDeltaTime((float)session.Duration)}");
                        }
                        AddParagraph(body, "");
                        
                        foreach (var note in session.Notes)
                        {
                            AddParagraph(body, $"[{note.Category}] {note.Title}", true);
                            AddParagraph(body, $"Time: {note.CreatedAt:HH:mm:ss} (Delta: {FormatDeltaTime(note.SessionDeltaTime)})");
                            AddParagraph(body, note.Content);
                            AddParagraph(body, "");
                        }
                    }
                    
                    mainPart.Document.Save();
                }
                
                Console.WriteLine($"[Notes] Exported to Word: {filepath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Notes] Export to Word failed: {ex.Message}");
            }
        }
        
        /// <summary>
        /// Export all notes to plain text
        /// </summary>
        public void ExportToTxt(string filepath)
        {
            try
            {
                var sb = new StringBuilder();
                
                sb.AppendLine("═══════════════════════════════════════════════════════════");
                sb.AppendLine("BADGE ENGINE v7 - PROJECT NOTES");
                sb.AppendLine("═══════════════════════════════════════════════════════════");
                sb.AppendLine($"Author: Frederick Atiase Kodjo Eli (AKA Fake)");
                sb.AppendLine($"Contact: 0507809171 / 0537189307");
                sb.AppendLine($"Generated: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                sb.AppendLine($"Total Project Time: {FormatDeltaTime(_totalProjectTime)}");
                sb.AppendLine($"Total Notes: {Notes.Count}");
                sb.AppendLine("═══════════════════════════════════════════════════════════");
                sb.AppendLine();
                
                foreach (var session in Sessions)
                {
                    sb.AppendLine($"┌─────────────────────────────────────────────────────────┐");
                    sb.AppendLine($"│ {session.SessionName,-55} │");
                    sb.AppendLine($"└─────────────────────────────────────────────────────────┘");
                    sb.AppendLine($"Start: {session.StartTime:yyyy-MM-dd HH:mm:ss}");
                    if (session.EndTime != DateTime.MinValue)
                    {
                        sb.AppendLine($"End: {session.EndTime:yyyy-MM-dd HH:mm:ss}");
                        sb.AppendLine($"Duration: {FormatDeltaTime((float)session.Duration)}");
                    }
                    sb.AppendLine();
                    
                    foreach (var note in session.Notes)
                    {
                        sb.AppendLine($"  [{note.Category}] {note.Title}");
                        sb.AppendLine($"  Time: {note.CreatedAt:HH:mm:ss} | Delta: {FormatDeltaTime(note.SessionDeltaTime)}");
                        sb.AppendLine($"  {note.Content}");
                        sb.AppendLine();
                    }
                }
                
                File.WriteAllText(filepath, sb.ToString());
                Console.WriteLine($"[Notes] Exported to TXT: {filepath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Notes] Export to TXT failed: {ex.Message}");
            }
        }
        
        /// <summary>
        /// Import notes from TXT file
        /// </summary>
        public void ImportFromTxt(string filepath)
        {
            try
            {
                if (!File.Exists(filepath))
                {
                    Console.WriteLine($"[Notes] File not found: {filepath}");
                    return;
                }
                
                var lines = File.ReadAllLines(filepath);
                // Simple import - add each non-empty line as a note
                foreach (var line in lines)
                {
                    if (!string.IsNullOrWhiteSpace(line) && 
                        !line.StartsWith("═") && 
                        !line.StartsWith("┌") &&
                        !line.StartsWith("│") &&
                        !line.StartsWith("└"))
                    {
                        AddNote("Imported Note", line.Trim());
                    }
                }
                
                Console.WriteLine($"[Notes] Imported from TXT: {filepath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Notes] Import from TXT failed: {ex.Message}");
            }
        }
        
        /// <summary>
        /// Save notes to JSON
        /// </summary>
        public void SaveToJson(string filepath)
        {
            try
            {
                var data = new
                {
                    Notes,
                    Sessions,
                    TotalProjectTime = _totalProjectTime
                };
                
                string json = JsonConvert.SerializeObject(data, Formatting.Indented);
                File.WriteAllText(filepath, json);
                
                Console.WriteLine($"[Notes] Saved to JSON: {filepath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Notes] Save to JSON failed: {ex.Message}");
            }
        }
        
        /// <summary>
        /// Load notes from JSON
        /// </summary>
        public void LoadFromJson(string filepath)
        {
            try
            {
                if (!File.Exists(filepath))
                {
                    Console.WriteLine($"[Notes] File not found: {filepath}");
                    return;
                }
                
                string json = File.ReadAllText(filepath);
                var data = JsonConvert.DeserializeAnonymousType(json, new
                {
                    Notes = new List<Note>(),
                    Sessions = new List<NoteSession>(),
                    TotalProjectTime = 0f
                });
                
                if (data != null)
                {
                    Notes = data.Notes;
                    Sessions = data.Sessions;
                    _totalProjectTime = data.TotalProjectTime;
                }
                
                Console.WriteLine($"[Notes] Loaded from JSON: {filepath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Notes] Load from JSON failed: {ex.Message}");
            }
        }
        
        /// <summary>
        /// Get notes by category
        /// </summary>
        public List<Note> GetNotesByCategory(NoteCategory category)
        {
            return Notes.FindAll(n => n.Category == category);
        }
        
        /// <summary>
        /// Search notes
        /// </summary>
        public List<Note> SearchNotes(string query)
        {
            query = query.ToLower();
            return Notes.FindAll(n => 
                n.Title.ToLower().Contains(query) || 
                n.Content.ToLower().Contains(query));
        }
        
        private void AddParagraph(Body body, string text, bool bold = false)
        {
            Paragraph para = body.AppendChild(new Paragraph());
            Run run = para.AppendChild(new Run());
            run.AppendChild(new Text(text));
            
            if (bold)
            {
                RunProperties props = run.AppendChild(new RunProperties());
                props.AppendChild(new Bold());
            }
        }
        
        private string FormatDeltaTime(float seconds)
        {
            TimeSpan ts = TimeSpan.FromSeconds(seconds);
            if (ts.TotalHours >= 1)
                return $"{(int)ts.TotalHours}h {ts.Minutes}m {ts.Seconds}s";
            else if (ts.TotalMinutes >= 1)
                return $"{(int)ts.TotalMinutes}m {ts.Seconds}s";
            else
                return $"{ts.Seconds}s";
        }
    }
    
    public class Note
    {
        public string Id { get; set; } = "";
        public string Title { get; set; } = "";
        public string Content { get; set; } = "";
        public NoteCategory Category { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime ModifiedAt { get; set; }
        public float DeltaTime { get; set; } // Total delta time when created
        public float SessionDeltaTime { get; set; } // Delta time within session
        public float ModifiedDeltaTime { get; set; }
        public string SessionId { get; set; } = "";
    }
    
    public class NoteSession
    {
        public string SessionName { get; set; } = "";
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public double Duration { get; set; }
        public float DeltaTimeStart { get; set; }
        public List<Note> Notes { get; set; } = new List<Note>();
    }
    
    public enum NoteCategory
    {
        General,
        TODO,
        Bug,
        Feature,
        Idea,
        Design,
        Code,
        Art,
        Audio,
        Performance,
        Documentation
    }
}

namespace BADGE.Core
{
    /// <summary>
    /// Time management for delta time tracking
    /// </summary>
    public static class Time
    {
        public static float DeltaTime { get; private set; }
        public static float TotalTime { get; private set; }
        public static int FrameCount { get; private set; }
        
        public static void Update(float deltaTime)
        {
            DeltaTime = deltaTime;
            TotalTime += deltaTime;
            FrameCount++;
        }
    }
}
