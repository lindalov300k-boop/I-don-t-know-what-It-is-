using ImGuiNET;

namespace BADGE.Editor;

public class ConsolePanel
{
    private List<string> _logs = new();
    
    public void Log(string message)
    {
        _logs.Add($"[{DateTime.Now:HH:mm:ss}] {message}");
    }
    
    public void Render()
    {
        ImGui.Begin("Console");
        
        if (ImGui.Button("Clear"))
        {
            _logs.Clear();
        }
        
        ImGui.Separator();
        
        foreach (var log in _logs)
        {
            ImGui.Text(log);
        }
        
        ImGui.End();
    }
}
