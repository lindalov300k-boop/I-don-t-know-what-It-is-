using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using OpenTK.Windowing.GraphicsLibraryFramework;
using BADGE.Core;

namespace BADGE.Editor
{
    /// <summary>
    /// Drag-and-drop operation types
    /// </summary>
    public enum DragDropType
    {
        File,
        GameObject,
        Asset,
        Component,
        Script,
        Material,
        Texture,
        AudioClip,
        Prefab,
        Scene
    }

    /// <summary>
    /// Drag-and-drop data payload
    /// </summary>
    public class DragDropPayload
    {
        public DragDropType Type { get; set; }
        public object Data { get; set; }
        public string DisplayName { get; set; }
        public string SourcePath { get; set; }
        public Dictionary<string, object> Metadata { get; set; } = new Dictionary<string, object>();

        public T GetData<T>() where T : class
        {
            return Data as T;
        }
    }

    /// <summary>
    /// Drag-and-drop operation state
    /// </summary>
    public class DragDropOperation
    {
        public bool IsActive { get; set; }
        public DragDropPayload Payload { get; set; }
        public System.Numerics.Vector2 StartPosition { get; set; }
        public System.Numerics.Vector2 CurrentPosition { get; set; }
        public string SourceWindowId { get; set; }
        public string TargetWindowId { get; set; }
        public bool IsValidDrop { get; set; }

        public float DragDistance => System.Numerics.Vector2.Distance(StartPosition, CurrentPosition);
    }

    /// <summary>
    /// Advanced drag-and-drop manager with multi-file support
    /// </summary>
    public class DragDropManager
    {
        private static DragDropManager _instance;
        public static DragDropManager Instance => _instance ?? (_instance = new DragDropManager());

        private DragDropOperation _currentOperation;
        private Dictionary<string, List<Action<DragDropPayload>>> _dropTargets;
        private const float DRAG_THRESHOLD = 5.0f;

        public DragDropOperation CurrentOperation => _currentOperation;
        public bool IsDragging => _currentOperation?.IsActive ?? false;

        private DragDropManager()
        {
            _dropTargets = new Dictionary<string, List<Action<DragDropPayload>>>();
        }

        /// <summary>
        /// Begin a drag operation
        /// </summary>
        public void BeginDrag(DragDropPayload payload, System.Numerics.Vector2 position, string sourceWindowId)
        {
            _currentOperation = new DragDropOperation
            {
                IsActive = true,
                Payload = payload,
                StartPosition = position,
                CurrentPosition = position,
                SourceWindowId = sourceWindowId,
                IsValidDrop = false
            };

            Console.WriteLine($"[DragDrop] Started dragging {payload.Type}: {payload.DisplayName}");
        }

        /// <summary>
        /// Update drag operation position
        /// </summary>
        public void UpdateDrag(System.Numerics.Vector2 position)
        {
            if (_currentOperation == null || !_currentOperation.IsActive) return;

            _currentOperation.CurrentPosition = position;

            // Only activate drag if moved beyond threshold
            if (_currentOperation.DragDistance < DRAG_THRESHOLD)
                return;
        }

        /// <summary>
        /// Check if current position is over a valid drop target
        /// </summary>
        public bool IsOverValidDropTarget(string targetWindowId)
        {
            if (_currentOperation == null || !_currentOperation.IsActive) return false;

            _currentOperation.TargetWindowId = targetWindowId;
            _currentOperation.IsValidDrop = _dropTargets.ContainsKey(targetWindowId);
            return _currentOperation.IsValidDrop;
        }

        /// <summary>
        /// Complete the drag operation (drop)
        /// </summary>
        public bool EndDrag()
        {
            if (_currentOperation == null || !_currentOperation.IsActive) return false;

            bool success = false;

            if (_currentOperation.IsValidDrop && _currentOperation.TargetWindowId != null)
            {
                if (_dropTargets.TryGetValue(_currentOperation.TargetWindowId, out var handlers))
                {
                    foreach (var handler in handlers)
                    {
                        handler?.Invoke(_currentOperation.Payload);
                    }
                    success = true;
                    Console.WriteLine($"[DragDrop] Dropped {_currentOperation.Payload.Type} to {_currentOperation.TargetWindowId}");
                }
            }

            _currentOperation = null;
            return success;
        }

        /// <summary>
        /// Cancel the current drag operation
        /// </summary>
        public void CancelDrag()
        {
            if (_currentOperation != null)
            {
                Console.WriteLine($"[DragDrop] Cancelled drag operation");
                _currentOperation = null;
            }
        }

        /// <summary>
        /// Register a drop target
        /// </summary>
        public void RegisterDropTarget(string windowId, Action<DragDropPayload> onDrop)
        {
            if (!_dropTargets.ContainsKey(windowId))
                _dropTargets[windowId] = new List<Action<DragDropPayload>>();

            _dropTargets[windowId].Add(onDrop);
        }

        /// <summary>
        /// Unregister a drop target
        /// </summary>
        public void UnregisterDropTarget(string windowId)
        {
            _dropTargets.Remove(windowId);
        }
    }

    /// <summary>
    /// File attachment and management system
    /// </summary>
    public class FileAttachmentManager
    {
        private static FileAttachmentManager _instance;
        public static FileAttachmentManager Instance => _instance ?? (_instance = new FileAttachmentManager());

        private Dictionary<string, List<string>> _attachedFiles;
        private Dictionary<string, FileMetadata> _fileMetadata;
        private const long MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB per file

        public class FileMetadata
        {
            public string Path { get; set; }
            public long Size { get; set; }
            public DateTime AttachedDate { get; set; }
            public string Type { get; set; }
            public Dictionary<string, object> CustomData { get; set; } = new Dictionary<string, object>();
        }

        private FileAttachmentManager()
        {
            _attachedFiles = new Dictionary<string, List<string>>();
            _fileMetadata = new Dictionary<string, FileMetadata>();
        }

        /// <summary>
        /// Attach files to a game object or asset
        /// </summary>
        public bool AttachFiles(string targetId, string[] filePaths)
        {
            if (filePaths == null || filePaths.Length == 0) return false;

            if (!_attachedFiles.ContainsKey(targetId))
                _attachedFiles[targetId] = new List<string>();

            foreach (var filePath in filePaths)
            {
                if (!File.Exists(filePath))
                {
                    Console.WriteLine($"[FileAttachment] File not found: {filePath}");
                    continue;
                }

                var fileInfo = new FileInfo(filePath);
                if (fileInfo.Length > MAX_FILE_SIZE)
                {
                    Console.WriteLine($"[FileAttachment] File too large: {filePath} ({fileInfo.Length} bytes)");
                    continue;
                }

                // Copy file to project assets
                string assetPath = CopyToAssets(filePath);
                
                if (!string.IsNullOrEmpty(assetPath))
                {
                    _attachedFiles[targetId].Add(assetPath);
                    _fileMetadata[assetPath] = new FileMetadata
                    {
                        Path = assetPath,
                        Size = fileInfo.Length,
                        AttachedDate = DateTime.Now,
                        Type = fileInfo.Extension.ToLower()
                    };

                    Console.WriteLine($"[FileAttachment] Attached: {Path.GetFileName(filePath)} to {targetId}");
                }
            }

            return true;
        }

        /// <summary>
        /// Get all files attached to a target
        /// </summary>
        public List<string> GetAttachedFiles(string targetId)
        {
            return _attachedFiles.TryGetValue(targetId, out var files) ? files : new List<string>();
        }

        /// <summary>
        /// Detach a file from a target
        /// </summary>
        public bool DetachFile(string targetId, string filePath)
        {
            if (_attachedFiles.TryGetValue(targetId, out var files))
            {
                bool removed = files.Remove(filePath);
                if (removed)
                {
                    Console.WriteLine($"[FileAttachment] Detached: {filePath} from {targetId}");
                }
                return removed;
            }
            return false;
        }

        /// <summary>
        /// Get metadata for an attached file
        /// </summary>
        public FileMetadata GetFileMetadata(string filePath)
        {
            return _fileMetadata.TryGetValue(filePath, out var metadata) ? metadata : null;
        }

        /// <summary>
        /// Copy file to appropriate assets folder
        /// </summary>
        private string CopyToAssets(string sourcePath)
        {
            try
            {
                string ext = Path.GetExtension(sourcePath).ToLower();
                string targetFolder = GetAssetFolder(ext);
                string fileName = Path.GetFileName(sourcePath);
                string targetPath = Path.Combine(targetFolder, fileName);

                // Handle duplicate names
                int counter = 1;
                while (File.Exists(targetPath))
                {
                    string nameWithoutExt = Path.GetFileNameWithoutExtension(fileName);
                    targetPath = Path.Combine(targetFolder, $"{nameWithoutExt}_{counter}{ext}");
                    counter++;
                }

                Directory.CreateDirectory(targetFolder);
                File.Copy(sourcePath, targetPath, true);
                return targetPath;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[FileAttachment] Error copying file: {ex.Message}");
                return null;
            }
        }

        /// <summary>
        /// Determine appropriate asset folder based on file type
        /// </summary>
        private string GetAssetFolder(string extension)
        {
            switch (extension)
            {
                case ".png":
                case ".jpg":
                case ".jpeg":
                case ".bmp":
                case ".gif":
                case ".tga":
                    return "Assets/Textures";

                case ".wav":
                case ".mp3":
                case ".ogg":
                    return "Assets/Audio";

                case ".obj":
                case ".fbx":
                case ".dae":
                case ".blend":
                    return "Assets/Models";

                case ".cs":
                case ".js":
                case ".py":
                    return "Assets/Scripts";

                case ".mat":
                    return "Assets/Materials";

                case ".shader":
                case ".glsl":
                case ".hlsl":
                    return "Assets/Shaders";

                case ".ttf":
                case ".otf":
                    return "Assets/Fonts";

                case ".prefab":
                    return "Assets/Prefabs";

                case ".scene":
                    return "Assets/Scenes";

                default:
                    return "Assets/Other";
            }
        }
    }

    /// <summary>
    /// Advanced file browser with search, filters, and sorting
    /// </summary>
    public class AdvancedFileBrowser
    {
        private string _currentPath;
        private List<string> _searchPaths;
        private Dictionary<string, bool> _expandedFolders;
        private string _searchQuery;
        private List<string> _fileTypeFilters;
        private FileSortMode _sortMode;

        public enum FileSortMode
        {
            Name,
            Type,
            Size,
            DateModified,
            DateCreated
        }

        public AdvancedFileBrowser()
        {
            _currentPath = "Assets";
            _searchPaths = new List<string>();
            _expandedFolders = new Dictionary<string, bool>();
            _fileTypeFilters = new List<string>();
            _sortMode = FileSortMode.Name;
        }

        public void SetPath(string path)
        {
            if (Directory.Exists(path))
            {
                _currentPath = path;
                RefreshContent();
            }
        }

        public void AddSearchPath(string path)
        {
            if (Directory.Exists(path) && !_searchPaths.Contains(path))
            {
                _searchPaths.Add(path);
            }
        }

        public void SetSearchQuery(string query)
        {
            _searchQuery = query;
            RefreshContent();
        }

        public void AddFileTypeFilter(string extension)
        {
            if (!_fileTypeFilters.Contains(extension.ToLower()))
            {
                _fileTypeFilters.Add(extension.ToLower());
            }
        }

        public void ClearFileTypeFilters()
        {
            _fileTypeFilters.Clear();
        }

        public void SetSortMode(FileSortMode mode)
        {
            _sortMode = mode;
            RefreshContent();
        }

        public List<string> GetFiles()
        {
            var files = Directory.GetFiles(_currentPath, "*.*", SearchOption.TopDirectoryOnly).ToList();

            // Apply search filter
            if (!string.IsNullOrWhiteSpace(_searchQuery))
            {
                files = files.Where(f => Path.GetFileName(f).ToLower().Contains(_searchQuery.ToLower())).ToList();
            }

            // Apply file type filter
            if (_fileTypeFilters.Count > 0)
            {
                files = files.Where(f => _fileTypeFilters.Contains(Path.GetExtension(f).ToLower())).ToList();
            }

            // Apply sorting
            files = SortFiles(files);

            return files;
        }

        public List<string> GetDirectories()
        {
            var dirs = Directory.GetDirectories(_currentPath).ToList();

            // Apply search filter to directories
            if (!string.IsNullOrWhiteSpace(_searchQuery))
            {
                dirs = dirs.Where(d => Path.GetFileName(d).ToLower().Contains(_searchQuery.ToLower())).ToList();
            }

            dirs.Sort();
            return dirs;
        }

        private List<string> SortFiles(List<string> files)
        {
            switch (_sortMode)
            {
                case FileSortMode.Name:
                    return files.OrderBy(f => Path.GetFileName(f)).ToList();

                case FileSortMode.Type:
                    return files.OrderBy(f => Path.GetExtension(f)).ThenBy(f => Path.GetFileName(f)).ToList();

                case FileSortMode.Size:
                    return files.OrderBy(f => new FileInfo(f).Length).ToList();

                case FileSortMode.DateModified:
                    return files.OrderByDescending(f => new FileInfo(f).LastWriteTime).ToList();

                case FileSortMode.DateCreated:
                    return files.OrderByDescending(f => new FileInfo(f).CreationTime).ToList();

                default:
                    return files;
            }
        }

        private void RefreshContent()
        {
            // Trigger UI refresh
        }

        public bool ToggleFolderExpanded(string path)
        {
            if (!_expandedFolders.ContainsKey(path))
                _expandedFolders[path] = true;
            else
                _expandedFolders[path] = !_expandedFolders[path];

            return _expandedFolders[path];
        }

        public bool IsFolderExpanded(string path)
        {
            return _expandedFolders.TryGetValue(path, out bool expanded) && expanded;
        }
    }

    /// <summary>
    /// Batch file operations utility
    /// </summary>
    public static class BatchFileOperations
    {
        public static void BatchImport(string folderPath, Action<string> onFileImported = null)
        {
            if (!Directory.Exists(folderPath)) return;

            var files = Directory.GetFiles(folderPath, "*.*", SearchOption.AllDirectories);
            Console.WriteLine($"[BatchImport] Found {files.Length} files in {folderPath}");

            foreach (var file in files)
            {
                try
                {
                    ImportFile(file);
                    onFileImported?.Invoke(file);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[BatchImport] Error importing {file}: {ex.Message}");
                }
            }

            Console.WriteLine($"[BatchImport] Completed");
        }

        public static void BatchExport(List<string> filePaths, string outputFolder)
        {
            if (!Directory.Exists(outputFolder))
                Directory.CreateDirectory(outputFolder);

            foreach (var file in filePaths)
            {
                try
                {
                    string fileName = Path.GetFileName(file);
                    string outputPath = Path.Combine(outputFolder, fileName);
                    File.Copy(file, outputPath, true);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[BatchExport] Error exporting {file}: {ex.Message}");
                }
            }

            Console.WriteLine($"[BatchExport] Exported {filePaths.Count} files to {outputFolder}");
        }

        public static void BatchRename(List<string> filePaths, string prefix, string suffix)
        {
            foreach (var file in filePaths)
            {
                try
                {
                    string directory = Path.GetDirectoryName(file);
                    string fileName = Path.GetFileNameWithoutExtension(file);
                    string extension = Path.GetExtension(file);
                    string newName = $"{prefix}{fileName}{suffix}{extension}";
                    string newPath = Path.Combine(directory, newName);

                    File.Move(file, newPath);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[BatchRename] Error renaming {file}: {ex.Message}");
                }
            }
        }

        private static void ImportFile(string filePath)
        {
            string ext = Path.GetExtension(filePath).ToLower();

            // Route to appropriate importer
            switch (ext)
            {
                case ".png":
                case ".jpg":
                case ".jpeg":
                case ".bmp":
                case ".gif":
                    // Import as texture/sprite
                    break;

                case ".obj":
                case ".fbx":
                    // Import as 3D model
                    break;

                case ".wav":
                case ".mp3":
                case ".ogg":
                    // Import as audio clip
                    break;

                default:
                    // Copy as generic asset
                    break;
            }
        }
    }
}
