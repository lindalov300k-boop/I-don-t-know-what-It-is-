using BADGE.Editor;
using BADGE.Plugins;
using BADGE.GameFeatures;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;
using System;

namespace BADGE;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("╔═══════════════════════════════════════════════════════════╗");
        Console.WriteLine("║                                                           ║");
        Console.WriteLine("║   ██████╗  █████╗ ██████╗  ██████╗ ███████╗            ║");
        Console.WriteLine("║   ██╔══██╗██╔══██╗██╔══██╗██╔════╝ ██╔════╝            ║");
        Console.WriteLine("║   ██████╔╝███████║██║  ██║██║  ███╗█████╗              ║");
        Console.WriteLine("║   ██╔══██╗██╔══██║██║  ██║██║   ██║██╔══╝              ║");
        Console.WriteLine("║   ██████╔╝██║  ██║██████╔╝╚██████╔╝███████╗            ║");
        Console.WriteLine("║   ╚═════╝ ╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚══════╝            ║");
        Console.WriteLine("║                                                           ║");
        Console.WriteLine("║   BADGE ENGINE v7.0 - PRODUCTION READY                   ║");
        Console.WriteLine("║   Complete Implementation - No Stubs!                    ║");
        Console.WriteLine("║   Exceeds Unity 2019.4 LTS + Blender Lite               ║");
        Console.WriteLine("║                                                           ║");
        Console.WriteLine("╚═══════════════════════════════════════════════════════════╝");
        Console.WriteLine();
        
        try
        {
            Console.WriteLine("=== Initializing BADGE Engine v7.0 ===");
            Console.WriteLine();
            
            // Initialize Plugin System
            Console.WriteLine("→ Initializing Plugin Manager...");
            PluginManager.Instance.Initialize();
            
            // Start audio output
            Console.WriteLine("→ Starting Audio Backend...");
            BADGE.Audio.AudioBackend.Start();
            
            // Initialize Managers
            Console.WriteLine("→ Initializing Advanced Systems...");
            var sceneManager = AdvancedSceneManager.Instance;
            var cameraManager = CameraManager.Instance;
            var lightingManager = LightingManager.Instance;
            var uiManager = UIManager.Instance;
            var dragDrop = DragDropManager.Instance;
            var fileManager = FileAttachmentManager.Instance;
            
            // Initialize Design Studio
            Console.WriteLine("→ Initializing Design Studio...");
            var designStudio = new DesignStudio();
            
            Console.WriteLine();
            Console.WriteLine("=== New v7.0 Features ===");
            Console.WriteLine("  ✓ Complete Plugin System (12 built-in plugins)");
            Console.WriteLine("  ✓ Drag & Drop File Management");
            Console.WriteLine("  ✓ Game Feature Modules:");
            Console.WriteLine("    • Rhythm Games (Piano Tiles)");
            Console.WriteLine("    • Vehicle Physics (Hill Climber)");
            Console.WriteLine("    • Board Games (Monopoly)");
            Console.WriteLine("    • RPG Battles (Pokemon)");
            Console.WriteLine("    • Social Deduction (Among Us)");
            Console.WriteLine("    • Puzzle Systems (Escape Room)");
            Console.WriteLine("    • Platformer Mechanics (G Switch)");
            Console.WriteLine("  ✓ Design Studio:");
            Console.WriteLine("    • Sprite Designer (Pixel Art)");
            Console.WriteLine("    • Procedural Texture Generator");
            Console.WriteLine("    • Material Designer");
            Console.WriteLine("    • Platform Designer");
            Console.WriteLine("  ✓ Advanced Managers:");
            Console.WriteLine("    • Scene Manager (Multi-scene, Templates)");
            Console.WriteLine("    • Camera Manager (Multiple cameras, Rigs)");
            Console.WriteLine("    • Lighting Manager (Dynamic, Baking)");
            Console.WriteLine("    • UI Manager (Runtime creation)");
            Console.WriteLine("  ✓ Addon Support");
            Console.WriteLine("  ✓ Unlimited Resources");
            Console.WriteLine();
            
            Console.WriteLine($"=== Loaded Plugins ({PluginManager.Instance.LoadedPlugins.Count}) ===");
            foreach (var plugin in PluginManager.Instance.LoadedPlugins)
            {
                Console.WriteLine($"  • {plugin.Key} v{plugin.Value.Version}");
            }
            Console.WriteLine();
            
            Console.WriteLine("Launching editor...");
            Console.WriteLine();
            
            var gameWindowSettings = GameWindowSettings.Default;
            var nativeWindowSettings = new NativeWindowSettings()
            {
                ClientSize = new Vector2i(1920, 1080),
                Title = "BADGE Engine v7.0 - Complete",
                Flags = ContextFlags.ForwardCompatible,
                Profile = ContextProfile.Core,
                API = ContextAPI.OpenGL,
                APIVersion = new Version(3, 3),
            };
            
            using (var window = new EditorWindow(gameWindowSettings, nativeWindowSettings))
            {
                window.Run();
            }
            
            // Shutdown
            Console.WriteLine();
            Console.WriteLine("=== Shutting Down ===");
            PluginManager.Instance.ShutdownAllPlugins();
            Console.WriteLine("BADGE Engine shut down successfully.");
        }
        catch (Exception ex)
        {
            Console.WriteLine();
            Console.WriteLine("╔═══════════════════════════════════════╗");
            Console.WriteLine("║   FATAL ERROR                         ║");
            Console.WriteLine("╚═══════════════════════════════════════╝");
            Console.WriteLine($"\nError: {ex.Message}");
            Console.WriteLine($"\nStack Trace:\n{ex.StackTrace}");
            Console.WriteLine($"\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
