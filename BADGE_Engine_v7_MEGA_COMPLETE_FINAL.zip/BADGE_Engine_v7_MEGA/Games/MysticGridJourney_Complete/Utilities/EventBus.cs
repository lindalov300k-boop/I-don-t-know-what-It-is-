using UnityEngine;
using System;
using System.Collections.Generic;

/// <summary>
/// Event bus system for decoupled communication between systems
/// </summary>
public static class EventBus
{
    private static Dictionary<string, Delegate> eventDictionary = new Dictionary<string, Delegate>();

    /// <summary>
    /// Subscribe to an event with a typed parameter
    /// </summary>
    public static void Subscribe<T>(string eventName, Action<T> listener)
    {
        if (eventDictionary.ContainsKey(eventName))
        {
            eventDictionary[eventName] = Delegate.Combine(eventDictionary[eventName], listener);
        }
        else
        {
            eventDictionary[eventName] = listener;
        }
    }

    /// <summary>
    /// Subscribe to an event with no parameters
    /// </summary>
    public static void Subscribe(string eventName, Action listener)
    {
        if (eventDictionary.ContainsKey(eventName))
        {
            eventDictionary[eventName] = Delegate.Combine(eventDictionary[eventName], listener);
        }
        else
        {
            eventDictionary[eventName] = listener;
        }
    }

    /// <summary>
    /// Unsubscribe from an event with a typed parameter
    /// </summary>
    public static void Unsubscribe<T>(string eventName, Action<T> listener)
    {
        if (eventDictionary.ContainsKey(eventName))
        {
            eventDictionary[eventName] = Delegate.Remove(eventDictionary[eventName], listener);
            if (eventDictionary[eventName] == null)
            {
                eventDictionary.Remove(eventName);
            }
        }
    }

    /// <summary>
    /// Unsubscribe from an event with no parameters
    /// </summary>
    public static void Unsubscribe(string eventName, Action listener)
    {
        if (eventDictionary.ContainsKey(eventName))
        {
            eventDictionary[eventName] = Delegate.Remove(eventDictionary[eventName], listener);
            if (eventDictionary[eventName] == null)
            {
                eventDictionary.Remove(eventName);
            }
        }
    }

    /// <summary>
    /// Publish an event with a typed parameter
    /// </summary>
    public static void Publish<T>(string eventName, T parameter)
    {
        if (eventDictionary.TryGetValue(eventName, out Delegate d))
        {
            Action<T> callback = d as Action<T>;
            callback?.Invoke(parameter);
        }
    }

    /// <summary>
    /// Publish an event with no parameters
    /// </summary>
    public static void Publish(string eventName)
    {
        if (eventDictionary.TryGetValue(eventName, out Delegate d))
        {
            Action callback = d as Action;
            callback?.Invoke();
        }
    }

    /// <summary>
    /// Clears all event subscriptions
    /// </summary>
    public static void Clear()
    {
        eventDictionary.Clear();
    }
}
