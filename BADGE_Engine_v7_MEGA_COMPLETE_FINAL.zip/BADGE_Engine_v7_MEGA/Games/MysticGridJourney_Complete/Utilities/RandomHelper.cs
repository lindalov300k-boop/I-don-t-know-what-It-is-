using UnityEngine;

/// <summary>
/// Utility functions for random number generation and weighted choices
/// </summary>
public static class RandomHelper
{
    /// <summary>
    /// Returns a random enum value
    /// </summary>
    public static T GetRandomEnum<T>() where T : System.Enum
    {
        System.Array values = System.Enum.GetValues(typeof(T));
        return (T)values.GetValue(Random.Range(0, values.Length));
    }

    /// <summary>
    /// Returns true based on probability (0.0 to 1.0)
    /// </summary>
    public static bool RollChance(float probability)
    {
        return Random.value < probability;
    }

    /// <summary>
    /// Returns an index based on weighted probabilities
    /// </summary>
    /// <param name="weights">Array of weights for each option</param>
    /// <returns>Selected index</returns>
    public static int WeightedRandom(float[] weights)
    {
        float total = 0f;
        foreach (float weight in weights)
        {
            total += weight;
        }

        float randomValue = Random.value * total;
        float cumulative = 0f;

        for (int i = 0; i < weights.Length; i++)
        {
            cumulative += weights[i];
            if (randomValue < cumulative)
            {
                return i;
            }
        }

        return weights.Length - 1;
    }
}
