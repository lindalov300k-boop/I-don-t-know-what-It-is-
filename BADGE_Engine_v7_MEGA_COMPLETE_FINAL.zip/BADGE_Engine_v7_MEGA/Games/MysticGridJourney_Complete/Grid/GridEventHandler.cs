using UnityEngine;

/// <summary>
/// Handles all events that occur when a player lands on a grid cell
/// </summary>
public class GridEventHandler : MonoBehaviour
{
    /// <summary>
    /// Main entry point for handling cell events
    /// </summary>
    public void HandleCellEvent(GridCell cell, PlayerController player)
    {
        switch (cell.cellType)
        {
            case CellType.Coin:
                HandleCoinEvent(cell, player);
                break;
            case CellType.Trap:
                HandleTrapEvent(cell, player);
                break;
            case CellType.Power:
                HandlePowerEvent(cell, player);
                break;
            case CellType.Animal:
                HandleAnimalEvent(cell, player);
                break;
            case CellType.Checkpoint:
                HandleCheckpointEvent(cell, player);
                break;
        }
        
        EventBus.Publish("CellEventTriggered", cell, player);
    }

    private void HandleCoinEvent(GridCell cell, PlayerController player)
    {
        player.PlayerData.AddCoins(cell.coinValue);
        Debug.Log($"{player.PlayerData.playerName} collected {cell.coinValue} coins!");
        
        // Change cell to empty after collection
        cell.cellType = CellType.Empty;
        cell.coinValue = 0;
    }

    private void HandleTrapEvent(GridCell cell, PlayerController player)
    {
        // Trap: skip next turn
        Debug.Log($"{player.PlayerData.playerName} fell into a trap!");
        player.PlayerData.skipNextTurn = true;
    }

    private void HandlePowerEvent(GridCell cell, PlayerController player)
    {
        // Add power to inventory
        player.PlayerData.AddPower(cell.powerType);
        Debug.Log($"{player.PlayerData.playerName} gained {cell.powerType} power!");
        
        cell.cellType = CellType.Empty;
    }

    private void HandleAnimalEvent(GridCell cell, PlayerController player)
    {
        // Random effect from mystical animal
        int effect = Random.Range(0, 3);
        
        switch (effect)
        {
            case 0:
                player.PlayerData.AddCoins(5);
                Debug.Log($"{cell.animalName} blessed {player.PlayerData.playerName} with 5 coins!");
                break;
            case 1:
                player.PlayerData.extraStepsNextTurn = Random.Range(1, 4);
                Debug.Log($"{cell.animalName} grants {player.PlayerData.playerName} extra steps!");
                break;
            case 2:
                Debug.Log($"{cell.animalName} does nothing special.");
                break;
        }
    }

    private void HandleCheckpointEvent(GridCell cell, PlayerController player)
    {
        Debug.Log($"{player.PlayerData.playerName} reached a checkpoint!");
        player.PlayerData.lastCheckpointIndex = cell.cellIndex;
        
        // Save progress
        GameManager.Instance.SaveGame();
    }
}
