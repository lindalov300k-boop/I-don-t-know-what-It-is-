using UnityEngine;

/// <summary>
/// Represents different types of grid cells
/// </summary>
public enum CellType
{
    Empty,
    Coin,
    Trap,
    Power,
    Animal,
    Checkpoint
}

/// <summary>
/// Individual grid cell component that holds cell data and visual representation
/// </summary>
public class GridCell : MonoBehaviour
{
    [Header("Cell Properties")]
    public int cellIndex;
    public CellType cellType = CellType.Empty;
    public int coinValue = 0;
    public PowerType powerType = PowerType.None;
    public string animalName = "";
    public bool isCheckpoint = false;

    [Header("Visual")]
    public MeshRenderer meshRenderer;
    public Material defaultMaterial;
    
    private Color originalColor;

    private void Awake()
    {
        if (meshRenderer == null)
            meshRenderer = GetComponent<MeshRenderer>();
        
        originalColor = meshRenderer.material.color;
    }

    /// <summary>
    /// Initializes the cell with a specific type and properties
    /// </summary>
    public void Initialize(int index, CellType type, GameConfig config)
    {
        cellIndex = index;
        cellType = type;
        
        ApplyVisualEffect();
        
        // Set specific properties based on type
        switch (cellType)
        {
            case CellType.Coin:
                coinValue = Random.Range(1, 6);
                break;
            case CellType.Power:
                powerType = (PowerType)Random.Range(1, System.Enum.GetValues(typeof(PowerType)).Length);
                break;
            case CellType.Animal:
                animalName = GenerateAnimalName();
                break;
            case CellType.Checkpoint:
                isCheckpoint = true;
                break;
        }
    }

    /// <summary>
    /// Applies visual color based on cell type
    /// </summary>
    private void ApplyVisualEffect()
    {
        switch (cellType)
        {
            case CellType.Coin:
                meshRenderer.material.color = Color.yellow;
                break;
            case CellType.Trap:
                meshRenderer.material.color = Color.red;
                break;
            case CellType.Power:
                meshRenderer.material.color = Color.cyan;
                break;
            case CellType.Animal:
                meshRenderer.material.color = Color.green;
                break;
            case CellType.Checkpoint:
                meshRenderer.material.color = Color.magenta;
                break;
            default:
                meshRenderer.material.color = Color.white;
                break;
        }
    }

    private string GenerateAnimalName()
    {
        string[] animals = { "Phoenix", "Dragon", "Griffin", "Unicorn", "Basilisk" };
        return animals[Random.Range(0, animals.Length)];
    }

    /// <summary>
    /// Highlights or unhighlights the cell
    /// </summary>
    public void Highlight(bool enable)
    {
        if (enable)
        {
            meshRenderer.material.color = Color.Lerp(meshRenderer.material.color, Color.white, 0.5f);
        }
        else
        {
            ApplyVisualEffect();
        }
    }

    // Serialization methods
    public GridCellData Serialize()
    {
        return new GridCellData
        {
            cellIndex = cellIndex,
            cellType = cellType,
            coinValue = coinValue,
            powerType = powerType,
            animalName = animalName,
            isCheckpoint = isCheckpoint
        };
    }

    public void Deserialize(GridCellData data)
    {
        cellIndex = data.cellIndex;
        cellType = data.cellType;
        coinValue = data.coinValue;
        powerType = data.powerType;
        animalName = data.animalName;
        isCheckpoint = data.isCheckpoint;
        
        ApplyVisualEffect();
    }
}

/// <summary>
/// Serializable data structure for grid cells
/// </summary>
[System.Serializable]
public class GridCellData
{
    public int cellIndex;
    public CellType cellType;
    public int coinValue;
    public PowerType powerType;
    public string animalName;
    public bool isCheckpoint;
}
