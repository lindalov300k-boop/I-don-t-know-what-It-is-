using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

/// <summary>
/// Manages scene loading and transitions throughout the game.
/// Provides async loading with progress tracking.
/// </summary>
public class SceneTransitionManager : MonoBehaviour
{
    public static SceneTransitionManager Instance { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    /// <summary>
    /// Loads a scene asynchronously by name
    /// </summary>
    public void LoadScene(string sceneName)
    {
        StartCoroutine(LoadSceneAsync(sceneName));
    }

    private IEnumerator LoadSceneAsync(string sceneName)
    {
        AsyncOperation operation = SceneManager.LoadSceneAsync(sceneName);
        
        while (!operation.isDone)
        {
            float progress = Mathf.Clamp01(operation.progress / 0.9f);
            EventBus.Publish("SceneLoadProgress", progress);
            yield return null;
        }
        
        EventBus.Publish("SceneLoaded", sceneName);
    }

    // Convenience methods for common scene loads
    public void LoadInventoryScene() => LoadScene("InventoryScene");
    public void LoadGameScene() => LoadScene("GameScene");
    public void LoadStartScene() => LoadScene("StartScene");
}
