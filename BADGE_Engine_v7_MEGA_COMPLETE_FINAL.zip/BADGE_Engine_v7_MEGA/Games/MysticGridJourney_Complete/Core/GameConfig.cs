using UnityEngine;

/// <summary>
/// ScriptableObject that stores all game configuration settings.
/// Create via: Assets > Create > MysticGrid > GameConfig
/// </summary>
[CreateAssetMenu(fileName = "GameConfig", menuName = "MysticGrid/GameConfig")]
public class GameConfig : ScriptableObject
{
    [Header("Grid Settings")]
    public int minGridCount = 50;
    public int maxGridCount = 200;
    public float gridSpacing = 2f;
    public float gridHeight = 10f;

    [Header("Player Settings")]
    public int maxPlayers = 8;
    public float moveSpeed = 3f;
    public int startingCoins = 0;

    [Header("Dice Settings")]
    public int minDiceRoll = 0;
    public int maxDiceRoll = 6;
    public float diceRollDelay = 1f;

    [Header("Fog Settings")]
    public float fogDensity = 0.5f;
    public float fogRegenerationRate = 0.1f;
    public Color fogColor = new Color(1f, 1f, 1f, 0.11f); // RGB 255,255,255,28

    [Header("Procedural Generation")]
    public int characterMeshResolution = 50;
    public int audioSampleRate = 44100;
    
    [Header("Event Probabilities")]
    [Range(0f, 1f)] public float coinSpawnChance = 0.3f;
    [Range(0f, 1f)] public float trapSpawnChance = 0.15f;
    [Range(0f, 1f)] public float powerSpawnChance = 0.1f;
    [Range(0f, 1f)] public float animalSpawnChance = 0.05f;
    [Range(0f, 1f)] public float checkpointSpawnChance = 0.08f;
}
