using UnityEngine;

/// <summary>
/// Power types available in the game
/// </summary>
public enum PowerType
{
    None,
    Freeze,
    Teleport,
    MultiplySteps,
    StealCoins,
    Shield
}

/// <summary>
/// Executes power effects on target players
/// </summary>
public class PowerSystem : MonoBehaviour
{
    /// <summary>
    /// Executes a specific power on a target player
    /// </summary>
    public void ExecutePower(PowerType power, PlayerController target)
    {
        switch (power)
        {
            case PowerType.Freeze:
                FreezePower(target);
                break;
            case PowerType.Teleport:
                TeleportPower(target);
                break;
            case PowerType.MultiplySteps:
                MultiplyStepsPower(target);
                break;
            case PowerType.StealCoins:
                StealCoinsPower(target);
                break;
            case PowerType.Shield:
                ShieldPower(target);
                break;
        }
    }

    private void FreezePower(PlayerController target)
    {
        target.PlayerData.skipNextTurn = true;
        Debug.Log($"{target.PlayerData.playerName} has been frozen!");
    }

    private void TeleportPower(PlayerController target)
    {
        // Teleport to a random cell
        GridManager gridManager = GameManager.Instance.gridManager;
        int randomIndex = Random.Range(0, gridManager.GridCells.Count);
        target.movement.TeleportToCell(randomIndex);
        Debug.Log($"{target.PlayerData.playerName} was teleported!");
    }

    private void MultiplyStepsPower(PlayerController target)
    {
        target.PlayerData.extraStepsNextTurn = 3;
        Debug.Log($"{target.PlayerData.playerName} will get +3 steps next turn!");
    }

    private void StealCoinsPower(PlayerController target)
    {
        int stolenAmount = Mathf.Min(5, target.PlayerData.coins);
        target.PlayerData.coins -= stolenAmount;
        Debug.Log($"Stole {stolenAmount} coins from {target.PlayerData.playerName}!");
    }

    private void ShieldPower(PlayerController target)
    {
        // Protect from next negative effect (implement as needed)
        Debug.Log($"{target.PlayerData.playerName} is shielded!");
    }
}
