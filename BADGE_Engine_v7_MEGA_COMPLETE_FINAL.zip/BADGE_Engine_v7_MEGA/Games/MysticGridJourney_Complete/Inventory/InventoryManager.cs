using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Manages inventory system for all players, including item usage and purchases
/// </summary>
public class InventoryManager : MonoBehaviour
{
    [Header("Systems")]
    public PowerSystem powerSystem;
    public InventoryUI inventoryUI;

    private Dictionary<string, PlayerData> playerInventories = new Dictionary<string, PlayerData>();

    /// <summary>
    /// Registers a player to the inventory system
    /// </summary>
    public void RegisterPlayer(PlayerController player)
    {
        if (!playerInventories.ContainsKey(player.PlayerData.playerName))
        {
            playerInventories.Add(player.PlayerData.playerName, player.PlayerData);
        }
    }

    /// <summary>
    /// Opens the inventory UI for a specific player
    /// </summary>
    public void OpenInventoryForPlayer(string playerName)
    {
        if (playerInventories.TryGetValue(playerName, out PlayerData data))
        {
            inventoryUI.DisplayInventory(data);
        }
    }

    /// <summary>
    /// Uses a power from a player's inventory on a target
    /// </summary>
    public void UsePower(string playerName, PowerType power, PlayerController target)
    {
        if (playerInventories.TryGetValue(playerName, out PlayerData data))
        {
            if (data.UsePower(power))
            {
                powerSystem.ExecutePower(power, target);
            }
        }
    }

    /// <summary>
    /// Checks if a player can afford an item
    /// </summary>
    public bool CanAffordItem(string playerName, int cost)
    {
        if (playerInventories.TryGetValue(playerName, out PlayerData data))
        {
            return data.coins >= cost;
        }
        return false;
    }

    /// <summary>
    /// Handles item purchase transaction
    /// </summary>
    public void PurchaseItem(string playerName, PowerType power, int cost)
    {
        if (playerInventories.TryGetValue(playerName, out PlayerData data))
        {
            if (data.SpendCoins(cost))
            {
                data.AddPower(power);
                Debug.Log($"{playerName} purchased {power}");
            }
        }
    }
}
