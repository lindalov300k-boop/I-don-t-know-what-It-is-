using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

/// <summary>
/// Manages the visual inventory interface
/// NOTE: Requires TextMeshPro. If not installed, replace TextMeshProUGUI with Text
/// </summary>
public class InventoryUI : MonoBehaviour
{
    [Header("UI References")]
    public GameObject inventoryPanel;
    public Transform powerListParent;
    public GameObject powerItemPrefab;
    public TextMeshProUGUI coinsText;
    public Button closeButton;

    private PlayerData currentPlayerData;

    private void Start()
    {
        closeButton.onClick.AddListener(CloseInventory);
    }

    /// <summary>
    /// Displays the inventory for a specific player
    /// </summary>
    public void DisplayInventory(PlayerData playerData)
    {
        currentPlayerData = playerData;
        inventoryPanel.SetActive(true);
        
        // Display coins
        coinsText.text = $"Coins: {playerData.coins}";
        
        // Clear previous items
        foreach (Transform child in powerListParent)
        {
            Destroy(child.gameObject);
        }
        
        // Display powers
        foreach (PowerType power in playerData.powers)
        {
            GameObject item = Instantiate(powerItemPrefab, powerListParent);
            TextMeshProUGUI itemText = item.GetComponentInChildren<TextMeshProUGUI>();
            itemText.text = power.ToString();
            
            Button useButton = item.GetComponentInChildren<Button>();
            useButton.onClick.AddListener(() => OnUsePowerClicked(power));
        }
    }

    private void OnUsePowerClicked(PowerType power)
    {
        Debug.Log($"Selected power: {power}");
        // Open target selection UI
        // For now, just close inventory
        CloseInventory();
    }

    public void CloseInventory()
    {
        inventoryPanel.SetActive(false);
    }
}
