using UnityEngine;

/// <summary>
/// Manages dynamic fog system that follows the player
/// </summary>
public class FogSystem : MonoBehaviour
{
    [Header("Fog Settings")]
    public GameConfig config;
    public Material fogMaterial;
    public Transform player;

    [Header("Fog Plane")]
    public GameObject fogPlane;
    
    private float currentFogAlpha;

    private void Start()
    {
        InitializeFog();
    }

    /// <summary>
    /// Creates and initializes the fog plane
    /// </summary>
    private void InitializeFog()
    {
        // Create fog plane
        fogPlane = GameObject.CreatePrimitive(PrimitiveType.Plane);
        fogPlane.name = "FogPlane";
        fogPlane.transform.localScale = new Vector3(50, 1, 50);
        
        // Create and apply fog material
        fogMaterial = new Material(Shader.Find("Unlit/Transparent"));
        Color fogColor = config.fogColor;
        fogMaterial.color = fogColor;
        currentFogAlpha = fogColor.a;
        
        fogPlane.GetComponent<MeshRenderer>().material = fogMaterial;
    }

    private void Update()
    {
        if (player != null)
        {
            UpdateFogAroundPlayer();
        }
    }

    /// <summary>
    /// Updates fog position and regeneration
    /// </summary>
    private void UpdateFogAroundPlayer()
    {
        // Position fog plane at player's y level
        Vector3 fogPosition = player.position;
        fogPosition.y = config.gridHeight - 0.5f;
        fogPlane.transform.position = fogPosition;
        
        // Regenerate fog over time
        currentFogAlpha = Mathf.MoveTowards(
            currentFogAlpha, 
            config.fogColor.a, 
            config.fogRegenerationRate * Time.deltaTime
        );
        
        Color newColor = fogMaterial.color;
        newColor.a = currentFogAlpha;
        fogMaterial.color = newColor;
    }

    /// <summary>
    /// Dissipates fog at a specific position
    /// </summary>
    public void DissipiateFogAtPosition(Vector3 position, float radius)
    {
        // Temporarily reduce fog alpha
        currentFogAlpha = Mathf.Max(0, currentFogAlpha - 0.2f);
    }

    /// <summary>
    /// Sets the player transform to follow
    /// </summary>
    public void SetPlayer(Transform playerTransform)
    {
        player = playerTransform;
    }
}
