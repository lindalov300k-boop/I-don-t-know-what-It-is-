using UnityEngine;

/// <summary>
/// Handles dice rolling logic for player movement
/// </summary>
public class DiceRoller : MonoBehaviour
{
    public GameConfig config;

    /// <summary>
    /// Rolls the dice and returns a random value based on game config
    /// </summary>
    public int Roll()
    {
        return Random.Range(config.minDiceRoll, config.maxDiceRoll + 1);
    }

    /// <summary>
    /// Rolls the dice with custom min/max values
    /// </summary>
    public int Roll(int min, int max)
    {
        return Random.Range(min, max + 1);
    }
}
