using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Manages multiplayer functionality including player slots and AI filling
/// </summary>
public class MultiplayerManager : MonoBehaviour
{
    [Header("Prefabs")]
    public GameObject playerPrefab;

    [Header("Runtime")]
    private List<PlayerSlot> playerSlots = new List<PlayerSlot>();
    private List<PlayerController> activePlayers = new List<PlayerController>();

    /// <summary>
    /// Initializes all players (human + AI) for a game session
    /// </summary>
    public void InitializePlayers(int humanPlayerCount, int aiCount)
    {
        ClearPlayers();
        
        int totalPlayers = humanPlayerCount + aiCount;
        
        // Create human players
        for (int i = 0; i < humanPlayerCount; i++)
        {
            CreatePlayer($"Player_{i + 1}", false, i);
        }
        
        // Create AI players
        for (int i = 0; i < aiCount; i++)
        {
            string aiName = AINameGenerator.GenerateRandomName();
            CreatePlayer(aiName, true, humanPlayerCount + i);
        }
        
        EventBus.Publish("PlayersInitialized", activePlayers);
    }

    /// <summary>
    /// Creates a player or AI with specified parameters
    /// </summary>
    private void CreatePlayer(string playerName, bool isAI, int startIndex)
    {
        GameObject playerObj = Instantiate(playerPrefab);
        PlayerController controller = playerObj.GetComponent<PlayerController>();
        
        controller.Initialize(playerName, isAI, startIndex);
        
        if (isAI)
        {
            AIController aiController = playerObj.AddComponent<AIController>();
            controller.aiController = aiController;
            
            // Assign random personality
            aiController.SetPersonality(GetRandomAIPersonality());
        }
        
        activePlayers.Add(controller);
        
        // Apply procedural character
        ProceduralCharacter procChar = playerObj.GetComponent<ProceduralCharacter>();
        if (procChar != null)
        {
            procChar.GenerateCharacter(controller.PlayerData.customization);
        }
        
        // Register with inventory system
        GameManager.Instance.inventoryManager.RegisterPlayer(controller);
    }

    private AIPersonality GetRandomAIPersonality()
    {
        // Load from Resources or create default
        return ScriptableObject.CreateInstance<AIPersonality>();
    }

    /// <summary>
    /// Returns all active players
    /// </summary>
    public List<PlayerController> GetAllPlayers()
    {
        return activePlayers;
    }

    /// <summary>
    /// Finds a player by name
    /// </summary>
    public PlayerController GetPlayerByName(string name)
    {
        return activePlayers.Find(p => p.PlayerData.playerName == name);
    }

    private void ClearPlayers()
    {
        foreach (PlayerController player in activePlayers)
        {
            if (player != null)
                Destroy(player.gameObject);
        }
        activePlayers.Clear();
        playerSlots.Clear();
    }

    // Serialization for save system
    public List<PlayerData> SerializePlayers()
    {
        List<PlayerData> data = new List<PlayerData>();
        foreach (PlayerController player in activePlayers)
        {
            data.Add(player.PlayerData);
        }
        return data;
    }

    public void DeserializePlayers(List<PlayerData> data)
    {
        ClearPlayers();
        
        for (int i = 0; i < data.Count; i++)
        {
            PlayerData playerData = data[i];
            CreatePlayer(playerData.playerName, false, playerData.currentGridIndex);
            activePlayers[i].PlayerData = playerData;
        }
    }
}
