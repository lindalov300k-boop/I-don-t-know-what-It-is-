using UnityEngine;
using System.Collections;

/// <summary>
/// Handles player movement along the grid
/// </summary>
public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 3f;
    private PlayerController controller;

    private void Awake()
    {
        controller = GetComponent<PlayerController>();
    }

    /// <summary>
    /// Moves the player a specified number of steps along the grid
    /// </summary>
    public IEnumerator MoveSteps(int steps)
    {
        GridManager gridManager = GameManager.Instance.gridManager;
        
        int targetIndex = Mathf.Min(
            controller.PlayerData.currentGridIndex + steps,
            gridManager.GridCells.Count - 1
        );

        // Move step by step
        while (controller.PlayerData.currentGridIndex < targetIndex)
        {
            controller.PlayerData.currentGridIndex++;
            GridCell targetCell = gridManager.GetCellAtIndex(controller.PlayerData.currentGridIndex);
            
            if (targetCell != null)
            {
                Vector3 targetPos = targetCell.transform.position + Vector3.up * 0.5f;
                
                // Smooth movement
                while (Vector3.Distance(transform.position, targetPos) > 0.1f)
                {
                    transform.position = Vector3.MoveTowards(transform.position, targetPos, moveSpeed * Time.deltaTime);
                    yield return null;
                }
                
                transform.position = targetPos;
            }
            
            yield return new WaitForSeconds(0.2f);
        }
    }

    /// <summary>
    /// Instantly teleports the player to a specific cell
    /// </summary>
    public void TeleportToCell(int cellIndex)
    {
        GridManager gridManager = GameManager.Instance.gridManager;
        GridCell cell = gridManager.GetCellAtIndex(cellIndex);
        
        if (cell != null)
        {
            controller.PlayerData.currentGridIndex = cellIndex;
            transform.position = cell.transform.position + Vector3.up * 0.5f;
        }
    }
}
