using UnityEngine;
using System.Collections;

/// <summary>
/// Main controller for player entities (both human and AI)
/// </summary>
public class PlayerController : MonoBehaviour
{
    [Header("Data")]
    public PlayerData PlayerData;
    public bool IsAI = false;

    [Header("Components")]
    public PlayerMovement movement;
    public AIController aiController;

    private void Awake()
    {
        if (movement == null)
            movement = GetComponent<PlayerMovement>();
        
        if (IsAI && aiController == null)
            aiController = GetComponent<AIController>();
    }

    /// <summary>
    /// Executes a player turn: movement and event handling
    /// </summary>
    public IEnumerator ExecutePlayerTurn(int steps)
    {
        // Move player
        yield return StartCoroutine(movement.MoveSteps(steps));
        
        // Trigger cell event
        GridManager gridManager = GameManager.Instance.gridManager;
        GridCell currentCell = gridManager.GetCellAtIndex(PlayerData.currentGridIndex);
        
        if (currentCell != null)
        {
            gridManager.TriggerCellEvent(currentCell, this);
        }
    }

    /// <summary>
    /// Executes an AI turn: decision making, then movement
    /// </summary>
    public IEnumerator ExecuteAITurn(int steps)
    {
        // AI makes decision before moving
        aiController.MakeDecision();
        
        // Then execute movement like player
        yield return StartCoroutine(ExecutePlayerTurn(steps));
    }

    /// <summary>
    /// Initializes player data and position
    /// </summary>
    public void Initialize(string name, bool isAI, int startIndex)
    {
        PlayerData = new PlayerData
        {
            playerName = name,
            currentGridIndex = startIndex,
            coins = GameManager.Instance.gameConfig.startingCoins
        };
        
        IsAI = isAI;
        
        // Position on grid
        GridManager gridManager = GameManager.Instance.gridManager;
        GridCell startCell = gridManager.GetCellAtIndex(startIndex);
        if (startCell != null)
        {
            transform.position = startCell.transform.position + Vector3.up * 0.5f;
        }
    }
}
