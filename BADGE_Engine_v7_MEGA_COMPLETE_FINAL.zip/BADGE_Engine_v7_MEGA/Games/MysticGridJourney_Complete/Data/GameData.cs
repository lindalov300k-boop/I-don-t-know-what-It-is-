using System.Collections.Generic;

/// <summary>
/// Serializable container for all game state data
/// </summary>
[System.Serializable]
public class GameData
{
    public List<GridCellData> gridCells;
    public List<PlayerData> players;
    public int currentTurn;
    public string timestamp;

    public GameData()
    {
        timestamp = System.DateTime.Now.ToString();
    }
}
