using UnityEngine;

/// <summary>
/// Generates procedural low-poly meshes for characters
/// </summary>
public class ProceduralMesh : MonoBehaviour
{
    /// <summary>
    /// Generates a simple character mesh based on gender
    /// </summary>
    public Mesh GenerateCharacterMesh(Gender gender)
    {
        Mesh mesh = new Mesh();
        
        // Simple low-poly humanoid (can be expanded)
        Vector3[] vertices = GenerateVertices(gender);
        int[] triangles = GenerateTriangles();
        Vector2[] uvs = GenerateUVs(vertices.Length);
        
        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.uv = uvs;
        mesh.RecalculateNormals();
        
        return mesh;
    }

    /// <summary>
    /// Generates vertices for a simple cube character (placeholder)
    /// TODO: Expand to proper humanoid shape
    /// </summary>
    private Vector3[] GenerateVertices(Gender gender)
    {
        // Simple cube representation (8 vertices)
        float height = gender == Gender.Male ? 2f : 1.8f;
        float width = 0.5f;
        
        return new Vector3[]
        {
            new Vector3(-width, 0, -width),
            new Vector3(width, 0, -width),
            new Vector3(width, 0, width),
            new Vector3(-width, 0, width),
            new Vector3(-width, height, -width),
            new Vector3(width, height, -width),
            new Vector3(width, height, width),
            new Vector3(-width, height, width)
        };
    }

    private int[] GenerateTriangles()
    {
        // Cube triangles (12 triangles, 36 indices)
        return new int[]
        {
            0, 2, 1, 0, 3, 2, // Bottom
            4, 5, 6, 4, 6, 7, // Top
            0, 1, 5, 0, 5, 4, // Front
            2, 3, 7, 2, 7, 6, // Back
            1, 2, 6, 1, 6, 5, // Right
            3, 0, 4, 3, 4, 7  // Left
        };
    }

    private Vector2[] GenerateUVs(int vertexCount)
    {
        Vector2[] uvs = new Vector2[vertexCount];
        for (int i = 0; i < vertexCount; i++)
        {
            uvs[i] = new Vector2(i % 2, i / 2 % 2);
        }
        return uvs;
    }
}
