using UnityEngine;

/// <summary>
/// Generates procedural audio effects for mystical sounds
/// </summary>
public class ProceduralAudio : MonoBehaviour
{
    public int sampleRate = 44100;
    public float duration = 0.5f;

    /// <summary>
    /// Generates a mystical sound effect using sine waves
    /// </summary>
    public AudioClip GenerateMysticalSound(float frequency = 440f)
    {
        int sampleCount = Mathf.RoundToInt(sampleRate * duration);
        float[] samples = new float[sampleCount];
        
        for (int i = 0; i < sampleCount; i++)
        {
            float t = (float)i / sampleRate;
            
            // Combine multiple sine waves for mystical effect
            samples[i] = Mathf.Sin(2 * Mathf.PI * frequency * t) * 0.3f;
            samples[i] += Mathf.Sin(2 * Mathf.PI * frequency * 1.5f * t) * 0.2f;
            samples[i] += Mathf.Sin(2 * Mathf.PI * frequency * 2f * t) * 0.1f;
            
            // Apply envelope (fade in/out)
            float envelope = Mathf.Sin(Mathf.PI * t / duration);
            samples[i] *= envelope;
        }
        
        AudioClip clip = AudioClip.Create("MysticalSound", sampleCount, 1, sampleRate, false);
        clip.SetData(samples, 0);
        
        return clip;
    }

    /// <summary>
    /// Plays a randomly generated mystical sound at camera position
    /// </summary>
    public void PlayMysticalSound()
    {
        AudioClip clip = GenerateMysticalSound(Random.Range(300f, 600f));
        AudioSource.PlayClipAtPoint(clip, Camera.main.transform.position);
    }
}
