using UnityEngine;

/// <summary>
/// Generates procedural textures for characters
/// </summary>
public class ProceduralTexture : MonoBehaviour
{
    /// <summary>
    /// Generates a texture based on character customization
    /// </summary>
    public Texture2D GenerateCharacterTexture(CharacterCustomization customization)
    {
        int width = 64;
        int height = 64;
        Texture2D texture = new Texture2D(width, height);
        
        Color skinColor = GetSkinColor(customization.skinColorIndex);
        
        // Fill with skin color
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                texture.SetPixel(x, y, skinColor);
            }
        }
        
        texture.Apply();
        return texture;
    }

    /// <summary>
    /// Returns a skin color based on index
    /// </summary>
    private Color GetSkinColor(int index)
    {
        Color[] skinTones = new Color[]
        {
            new Color(1f, 0.8f, 0.6f),      // Light
            new Color(0.9f, 0.7f, 0.5f),    // Medium-Light
            new Color(0.7f, 0.5f, 0.3f),    // Medium
            new Color(0.5f, 0.3f, 0.2f),    // Dark
            new Color(0.3f, 0.2f, 0.15f)    // Very Dark
        };
        
        return skinTones[Mathf.Clamp(index, 0, skinTones.Length - 1)];
    }
}
