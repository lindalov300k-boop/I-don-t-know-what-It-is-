using UnityEngine;

/// <summary>
/// ScriptableObject defining AI behavior patterns and decision weights.
/// Create via: Assets > Create > MysticGrid > AIPersonality
/// </summary>
[CreateAssetMenu(fileName = "AIPersonality", menuName = "MysticGrid/AIPersonality")]
public class AIPersonality : ScriptableObject
{
    [Header("Behavior Weights")]
    [Range(0f, 1f)] public float betrayalChance = 0.3f;
    [Range(0f, 1f)] public float helpfulChance = 0.2f;
    [Range(0f, 1f)] public float powerUsageChance = 0.5f;
    [Range(0f, 1f)] public float riskTakingLevel = 0.5f;

    [Header("Strategy")]
    public bool preferForwardProgress = true;
    public bool targetLeadingPlayer = true;
}
