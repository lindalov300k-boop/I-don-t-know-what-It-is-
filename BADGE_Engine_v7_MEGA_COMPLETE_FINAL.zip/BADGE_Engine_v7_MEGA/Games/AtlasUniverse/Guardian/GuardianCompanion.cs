using UnityEngine;

public class GuardianCompanion : MonoBehaviour
{
    public Transform playerTransform;
    public float followDistance = 1.8f;
    public float followHeight = 1.5f;
    public float followSpeed = 3f;
    public float bobSpeed = 1.5f;
    public float bobAmount = 0.2f;

    private Light guardianLight;
    private Renderer rend;
    private float baseGlow = 1.5f;
    private float glowPulse = 0f;
    private bool isHidden = false;
    private Vector3 targetPos;

    void Start()
    {
        BuildGuardianMesh();
        if (playerTransform == null)
        {
            var pc = FindObjectOfType<PlayerController>();
            if (pc) playerTransform = pc.transform;
        }
    }

    void BuildGuardianMesh()
    {
        // Orb shape (sphere)
        GameObject orb = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        orb.transform.SetParent(transform);
        orb.transform.localPosition = Vector3.zero;
        orb.transform.localScale = Vector3.one * 0.35f;

        Material mat = new Material(Shader.Find("Standard"));
        mat.color = new Color(0.4f, 0.8f, 1f, 0.9f);
        mat.SetFloat("_Glossiness", 0.9f);
        mat.SetFloat("_Metallic", 0.3f);
        mat.EnableKeyword("_EMISSION");
        mat.SetColor("_EmissionColor", new Color(0.4f, 0.8f, 1f) * 2f);
        orb.GetComponent<Renderer>().material = mat;
        rend = orb.GetComponent<Renderer>();
        Destroy(orb.GetComponent<Collider>());

        // Rings
        for (int i = 0; i < 3; i++)
        {
            GameObject ring = CreateRing(i);
            ring.transform.SetParent(transform);
            ring.transform.localPosition = Vector3.zero;
        }

        // Light
        guardianLight = new GameObject("GuardianLight").AddComponent<Light>();
        guardianLight.transform.SetParent(transform);
        guardianLight.transform.localPosition = Vector3.zero;
        guardianLight.type = LightType.Point;
        guardianLight.color = new Color(0.5f, 0.9f, 1f);
        guardianLight.range = 6f;
        guardianLight.intensity = baseGlow;
    }

    GameObject CreateRing(int index)
    {
        int segments = 24;
        float radius = 0.28f + index * 0.07f;
        GameObject ring = new GameObject("Ring_" + index);
        Mesh mesh = new Mesh();

        Vector3[] verts = new Vector3[segments * 2];
        int[] tris = new int[segments * 6];
        float thickness = 0.025f;

        for (int i = 0; i < segments; i++)
        {
            float angle = (i / (float)segments) * Mathf.PI * 2f;
            float x = Mathf.Cos(angle) * radius;
            float y = Mathf.Sin(angle) * radius;
            verts[i] = new Vector3(x, y, -thickness);
            verts[i + segments] = new Vector3(x, y, thickness);
        }

        for (int i = 0; i < segments; i++)
        {
            int next = (i + 1) % segments;
            int ti = i * 6;
            tris[ti] = i; tris[ti + 1] = next; tris[ti + 2] = i + segments;
            tris[ti + 3] = next; tris[ti + 4] = next + segments; tris[ti + 5] = i + segments;
        }

        mesh.vertices = verts;
        mesh.triangles = tris;
        mesh.RecalculateNormals();

        MeshFilter mf = ring.AddComponent<MeshFilter>();
        mf.mesh = mesh;
        MeshRenderer mr = ring.AddComponent<MeshRenderer>();
        Material mat = new Material(Shader.Find("Standard"));
        mat.color = new Color(0.6f, 0.9f, 1f, 0.7f);
        mat.EnableKeyword("_EMISSION");
        mat.SetColor("_EmissionColor", new Color(0.4f, 0.8f, 1f) * 1.5f);
        mr.material = mat;

        // Random rotation axis per ring
        ring.GetComponent<Transform>().Rotate(new Vector3(Random.value, Random.value, Random.value).normalized, Random.Range(0f, 360f));

        ring.AddComponent<RingSpinner>().Init(index);
        return ring;
    }

    void Update()
    {
        if (isHidden) return;

        if (playerTransform != null)
        {
            Vector3 behind = playerTransform.position - playerTransform.forward * followDistance + Vector3.up * followHeight;
            float bob = Mathf.Sin(Time.time * bobSpeed) * bobAmount;
            targetPos = behind + Vector3.up * bob;
            transform.position = Vector3.Lerp(transform.position, targetPos, Time.deltaTime * followSpeed);
            transform.LookAt(playerTransform);
        }

        // Glow pulse
        glowPulse = Mathf.Sin(Time.time * 2f) * 0.3f;
        if (guardianLight) guardianLight.intensity = baseGlow + glowPulse;
    }

    public void SetGlow(float intensity)
    {
        baseGlow = intensity;
    }

    public void Hide()
    {
        isHidden = true;
        gameObject.SetActive(false);
    }

    public void React(float intensity)
    {
        // Brief flash reaction
        if (guardianLight) StartCoroutine(FlashGlow(intensity));
    }

    System.Collections.IEnumerator FlashGlow(float peak)
    {
        float t = 0;
        while (t < 0.5f)
        {
            t += Time.deltaTime;
            if (guardianLight) guardianLight.intensity = Mathf.Lerp(baseGlow, peak, Mathf.Sin(t * Mathf.PI * 2));
            yield return null;
        }
        if (guardianLight) guardianLight.intensity = baseGlow;
    }
}

// Helper component for ring spinning
public class RingSpinner : MonoBehaviour
{
    private Vector3 axis;
    private float speed;

    public void Init(int index)
    {
        Vector3[] axes = { Vector3.up, Vector3.right, new Vector3(1, 1, 0).normalized };
        axis = axes[index % axes.Length];
        speed = 30f + index * 15f;
    }

    void Update()
    {
        transform.Rotate(axis, speed * Time.deltaTime, Space.World);
    }
}
