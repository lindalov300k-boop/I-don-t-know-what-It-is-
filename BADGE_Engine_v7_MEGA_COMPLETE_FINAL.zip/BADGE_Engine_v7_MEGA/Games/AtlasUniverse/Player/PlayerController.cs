using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float walkSpeed = 4f;
    public float runSpeed = 8f;
    public float jumpHeight = 1.5f;
    public float gravity = -20f;
    public float stepOffset = 0.6f;

    [Header("Camera")]
    public float mouseSensitivity = 2f;
    public float cameraDistance = 5f;
    public float cameraHeight = 2f;
    public float cameraSmoothTime = 0.1f;

    [Header("Growth")]
    public float glowIntensity = 0f;

    private CharacterController cc;
    private Camera cam;
    private Vector3 velocity;
    private float yaw = 0f;
    private float pitch = 20f;
    private Vector3 camVelocity;

    // Procedural mesh parts
    private GameObject body;
    private GameObject head;
    private GameObject[] arms = new GameObject[2];
    private GameObject[] legs = new GameObject[2];
    private Light glowLight;

    // Animation state
    private float legSwing = 0f;
    private float armSwing = 0f;
    private bool isMoving = false;

    void Start()
    {
        cc = GetComponent<CharacterController>();
        cc.stepOffset = stepOffset;
        cc.slopeLimit = 50f;

        BuildPlayerMesh();
        SetupCamera();

        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        if (GameManager.Instance != null)
        {
            glowIntensity = GameManager.Instance.PlayerGlowIntensity;
            float scale = GameManager.Instance.PlayerGrowthScale;
            transform.localScale = Vector3.one * scale;
        }
    }

    void BuildPlayerMesh()
    {
        // Body
        body = CreateBlock(transform, new Vector3(0, 0.8f, 0), new Vector3(0.5f, 0.7f, 0.3f), new Color(0.3f, 0.5f, 0.9f));
        // Head
        head = CreateBlock(transform, new Vector3(0, 1.45f, 0), new Vector3(0.4f, 0.4f, 0.4f), new Color(0.9f, 0.75f, 0.6f));
        // Arms
        arms[0] = CreateBlock(transform, new Vector3(-0.45f, 0.85f, 0), new Vector3(0.2f, 0.6f, 0.2f), new Color(0.3f, 0.5f, 0.9f));
        arms[1] = CreateBlock(transform, new Vector3(0.45f, 0.85f, 0), new Vector3(0.2f, 0.6f, 0.2f), new Color(0.3f, 0.5f, 0.9f));
        // Legs
        legs[0] = CreateBlock(transform, new Vector3(-0.15f, 0.2f, 0), new Vector3(0.22f, 0.55f, 0.22f), new Color(0.15f, 0.2f, 0.5f));
        legs[1] = CreateBlock(transform, new Vector3(0.15f, 0.2f, 0), new Vector3(0.22f, 0.55f, 0.22f), new Color(0.15f, 0.2f, 0.5f));

        // Glow light
        GameObject glowObj = new GameObject("PlayerGlow");
        glowObj.transform.SetParent(transform);
        glowObj.transform.localPosition = new Vector3(0, 1f, 0);
        glowLight = glowObj.AddComponent<Light>();
        glowLight.type = LightType.Point;
        glowLight.color = new Color(0.5f, 0.8f, 1f);
        glowLight.range = 5f;
        glowLight.intensity = glowIntensity;
    }

    GameObject CreateBlock(Transform parent, Vector3 localPos, Vector3 size, Color color)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.transform.SetParent(parent);
        go.transform.localPosition = localPos;
        go.transform.localScale = size;
        go.GetComponent<Renderer>().material = CreateMaterial(color);
        Destroy(go.GetComponent<BoxCollider>());
        return go;
    }

    Material CreateMaterial(Color color)
    {
        Material mat = new Material(Shader.Find("Standard"));
        mat.color = color;
        mat.SetFloat("_Glossiness", 0.1f);
        return mat;
    }

    void SetupCamera()
    {
        GameObject camObj = new GameObject("PlayerCamera");
        cam = camObj.AddComponent<Camera>();
        cam.fieldOfView = 70f;
        cam.nearClipPlane = 0.1f;
    }

    void Update()
    {
        HandleMouseLook();
        HandleMovement();
        AnimateLimbs();
        UpdateGlow();
    }

    void LateUpdate()
    {
        FollowCamera();
    }

    void HandleMouseLook()
    {
        yaw += Input.GetAxis("Mouse X") * mouseSensitivity;
        pitch -= Input.GetAxis("Mouse Y") * mouseSensitivity;
        pitch = Mathf.Clamp(pitch, -10f, 60f);
        transform.rotation = Quaternion.Euler(0, yaw, 0);
    }

    void HandleMovement()
    {
        bool grounded = cc.isGrounded;
        if (grounded && velocity.y < 0) velocity.y = -2f;

        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        bool running = Input.GetKey(KeyCode.LeftShift);
        float speed = running ? runSpeed : walkSpeed;

        Vector3 move = transform.right * h + transform.forward * v;
        isMoving = move.magnitude > 0.1f;

        if (move.magnitude > 1f) move.Normalize();
        cc.Move(move * speed * Time.deltaTime);

        if (Input.GetButtonDown("Jump") && grounded)
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);

        velocity.y += gravity * Time.deltaTime;
        cc.Move(velocity * Time.deltaTime);
    }

    void AnimateLimbs()
    {
        float swingSpeed = isMoving ? 4f : 0f;
        legSwing += Time.deltaTime * swingSpeed;
        armSwing += Time.deltaTime * swingSpeed;

        float legAngle = Mathf.Sin(legSwing) * 30f;
        float armAngle = Mathf.Sin(armSwing) * 25f;

        if (legs[0]) legs[0].transform.localRotation = Quaternion.Euler(legAngle, 0, 0);
        if (legs[1]) legs[1].transform.localRotation = Quaternion.Euler(-legAngle, 0, 0);
        if (arms[0]) arms[0].transform.localRotation = Quaternion.Euler(-armAngle, 0, 0);
        if (arms[1]) arms[1].transform.localRotation = Quaternion.Euler(armAngle, 0, 0);

        // Idle bob
        if (!isMoving && body)
        {
            float bob = Mathf.Sin(Time.time * 1.5f) * 0.03f;
            body.transform.localPosition = new Vector3(0, 0.8f + bob, 0);
            head.transform.localPosition = new Vector3(0, 1.45f + bob, 0);
        }
    }

    void UpdateGlow()
    {
        if (glowLight) glowLight.intensity = glowIntensity;
    }

    void FollowCamera()
    {
        if (!cam) return;
        float pitch_rad = pitch * Mathf.Deg2Rad;
        float yaw_rad = yaw * Mathf.Deg2Rad;

        Vector3 offset = new Vector3(
            Mathf.Sin(yaw_rad) * cameraDistance * Mathf.Cos(pitch_rad),
            cameraDistance * Mathf.Sin(pitch_rad) + cameraHeight,
            Mathf.Cos(yaw_rad) * cameraDistance * Mathf.Cos(pitch_rad)
        );
        // Invert for behind-player view
        offset = new Vector3(-offset.x, offset.y, -offset.z);

        Vector3 targetPos = transform.position + offset;
        cam.transform.position = Vector3.SmoothDamp(cam.transform.position, targetPos, ref camVelocity, cameraSmoothTime);
        cam.transform.LookAt(transform.position + Vector3.up * 1f);
    }

    public void AddGlow(float amount)
    {
        glowIntensity = Mathf.Clamp(glowIntensity + amount, 0f, 3f);
        if (GameManager.Instance) GameManager.Instance.PlayerGlowIntensity = glowIntensity;
    }

    public void Grow(float amount)
    {
        float newScale = Mathf.Clamp(transform.localScale.x + amount, 0.8f, 1.5f);
        transform.localScale = Vector3.one * newScale;
        if (GameManager.Instance) GameManager.Instance.PlayerGrowthScale = newScale;
    }
}
