/*
 * ATLAS UNIVERSE — UNITY 2019.4 LTS SCENE SETUP GUIDE
 * ======================================================
 * This file is NOT a script. It is a setup reference document embedded as a C# comment.
 *
 * ──────────────────────────────────────────────────────
 * BUILD SETTINGS — SCENE ORDER (File > Build Settings)
 * ──────────────────────────────────────────────────────
 * Scene Index  |  Scene Name          |  Script to Attach
 * ─────────────────────────────────────────────────────────
 *     0        |  StartScene          |  StartScene.cs       → Empty GameObject
 *     1        |  AlphaWorld          |  AlphaWorld.cs       → Empty GameObject
 *     2        |  WorldI_Greed        |  WorldI_Greed.cs     → Empty GameObject
 *     3        |  WorldII_Shadow      |  WorldII_Shadow.cs   → Empty GameObject
 *     4        |  WorldIII_Glow       |  WorldIII_Glow.cs    → Empty GameObject
 *     5        |  WorldIV_Broken      |  WorldIV_Broken.cs   → Empty GameObject
 *     6        |  WorldV_Envy         |  WorldV_Envy.cs      → Empty GameObject
 *     7        |  WorldVI_Sloth       |  WorldVI_Sloth.cs    → Empty GameObject
 *     8        |  CoreWorld           |  CoreWorld.cs        → Empty GameObject
 *
 * ──────────────────────────────────────────────────────
 * HOW TO SET UP EACH SCENE
 * ──────────────────────────────────────────────────────
 * 1. Create a new empty scene (File > New Scene)
 * 2. Delete the default Main Camera and Directional Light (all worlds create these in code)
 * 3. Create an empty GameObject, name it "SceneManager"
 * 4. Attach the corresponding world script from the table above
 * 5. Save the scene with the correct name (must match build settings)
 * 6. Add the scene to Build Settings in the correct order (0–8)
 *
 * ──────────────────────────────────────────────────────
 * GAMEMANAGER PERSISTENT OBJECT
 * ──────────────────────────────────────────────────────
 * Add a GameObject to the StartScene ONLY (Scene 0) with GameManager.cs attached.
 * The GameManager uses DontDestroyOnLoad, so it persists across all scenes.
 *
 * ──────────────────────────────────────────────────────
 * PLAYER SETUP NOTES
 * ──────────────────────────────────────────────────────
 * The PlayerController automatically creates its camera at runtime.
 * Do NOT add a camera to the scene manually (except in StartScene which has no player).
 * The CharacterController is added automatically via WorldBase.SpawnPlayer().
 *
 * ──────────────────────────────────────────────────────
 * CONTROLS
 * ──────────────────────────────────────────────────────
 * WASD / Arrow Keys   → Move (forward, back, left, right)
 * Left Shift          → Run
 * Space               → Jump
 * Mouse               → Look / Camera rotation
 * Escape              → Pause Menu (Resume / Exit)
 *
 * ──────────────────────────────────────────────────────
 * PORTAL ACTIVATION
 * ──────────────────────────────────────────────────────
 * Portals activate after the player has spent the required time in a world.
 * Default times per world:
 *   Alpha World    → 40 seconds
 *   World I        → 50 seconds
 *   World II       → 55 seconds
 *   World III      → 50 seconds
 *   World IV       → 60 seconds
 *   World V        → 55 seconds
 *   World VI       → 35 seconds
 *   Core World     → No portal (choice-based ending)
 *
 * ──────────────────────────────────────────────────────
 * UNITY VERSION NOTE
 * ──────────────────────────────────────────────────────
 * All scripts target Unity 2019.4 LTS.
 * No external packages required.
 * All rendering uses the Standard shader (built-in render pipeline).
 * No TextMeshPro required — all UI uses OnGUI (immediate mode).
 * No animations or asset imports — everything is code-generated.
 */

// This file can be deleted before building. It serves as documentation only.
public class SceneSetupGuide { }
