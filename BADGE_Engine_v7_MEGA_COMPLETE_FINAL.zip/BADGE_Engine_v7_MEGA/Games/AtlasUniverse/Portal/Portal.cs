using UnityEngine;
using System.Collections;

public class Portal : MonoBehaviour
{
    public bool isActive = false;
    public float activationDelay = 5f;

    // Condition tracking
    public float timeRequired = 30f; // seconds player has spent in world
    private float worldTime = 0f;
    private bool triggered = false;

    private GameObject portalVisual;
    private Light portalLight;
    private float spinAngle = 0f;
    private Renderer[] rings;

    void Start()
    {
        BuildPortalVisual();
        SetVisible(false);
    }

    void Update()
    {
        if (!triggered)
        {
            worldTime += Time.deltaTime;
            if (worldTime >= timeRequired)
            {
                ActivatePortal();
            }
        }

        if (isActive)
        {
            AnimatePortal();
            CheckPlayerEntry();
        }
    }

    void BuildPortalVisual()
    {
        portalVisual = new GameObject("PortalVisual");
        portalVisual.transform.SetParent(transform);
        portalVisual.transform.localPosition = Vector3.zero;

        // Central orb
        GameObject orb = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        orb.transform.SetParent(portalVisual.transform);
        orb.transform.localPosition = Vector3.zero;
        orb.transform.localScale = Vector3.one * 0.8f;
        Material orbMat = new Material(Shader.Find("Standard"));
        orbMat.color = new Color(0.5f, 0.3f, 1f);
        orbMat.EnableKeyword("_EMISSION");
        orbMat.SetColor("_EmissionColor", new Color(0.5f, 0.3f, 1f) * 4f);
        orb.GetComponent<Renderer>().material = orbMat;
        Destroy(orb.GetComponent<Collider>());

        // Rings
        rings = new Renderer[4];
        for (int i = 0; i < 4; i++)
        {
            GameObject ring = CreateRing(portalVisual.transform, 0.9f + i * 0.35f, i);
            rings[i] = ring.GetComponent<Renderer>();
        }

        // Particles (manual - small cubes orbiting)
        for (int i = 0; i < 12; i++)
        {
            GameObject particle = GameObject.CreatePrimitive(PrimitiveType.Cube);
            particle.transform.SetParent(portalVisual.transform);
            particle.transform.localScale = Vector3.one * 0.1f;
            Material pMat = new Material(Shader.Find("Standard"));
            pMat.color = new Color(0.7f, 0.5f, 1f);
            pMat.EnableKeyword("_EMISSION");
            pMat.SetColor("_EmissionColor", new Color(0.7f, 0.5f, 1f) * 3f);
            particle.GetComponent<Renderer>().material = pMat;
            Destroy(particle.GetComponent<Collider>());
            particle.AddComponent<PortalParticle>().Init(i, 12);
        }

        // Light
        GameObject lightObj = new GameObject("PortalLight");
        lightObj.transform.SetParent(transform);
        portalLight = lightObj.AddComponent<Light>();
        portalLight.type = LightType.Point;
        portalLight.color = new Color(0.6f, 0.4f, 1f);
        portalLight.range = 12f;
        portalLight.intensity = 3f;
    }

    GameObject CreateRing(Transform parent, float radius, int index)
    {
        int segs = 32;
        GameObject ring = new GameObject("PortalRing_" + index);
        ring.transform.SetParent(parent);
        ring.transform.localPosition = Vector3.zero;

        Mesh mesh = new Mesh();
        Vector3[] verts = new Vector3[segs * 2];
        int[] tris = new int[segs * 6];
        float thick = 0.06f;

        for (int i = 0; i < segs; i++)
        {
            float a = (i / (float)segs) * Mathf.PI * 2f;
            verts[i] = new Vector3(Mathf.Cos(a) * radius, Mathf.Sin(a) * radius, -thick);
            verts[i + segs] = new Vector3(Mathf.Cos(a) * radius, Mathf.Sin(a) * radius, thick);
        }
        for (int i = 0; i < segs; i++)
        {
            int n = (i + 1) % segs;
            int t = i * 6;
            tris[t] = i; tris[t + 1] = n; tris[t + 2] = i + segs;
            tris[t + 3] = n; tris[t + 4] = n + segs; tris[t + 5] = i + segs;
        }
        mesh.vertices = verts; mesh.triangles = tris; mesh.RecalculateNormals();

        MeshFilter mf = ring.AddComponent<MeshFilter>(); mf.mesh = mesh;
        MeshRenderer mr = ring.AddComponent<MeshRenderer>();
        Material mat = new Material(Shader.Find("Standard"));
        Color c = new Color(0.6f + index * 0.1f, 0.3f, 1f - index * 0.1f);
        mat.color = c;
        mat.EnableKeyword("_EMISSION");
        mat.SetColor("_EmissionColor", c * 3f);
        mr.material = mat;

        // Rotation axis varies
        Vector3[] axes = { Vector3.up, Vector3.right, new Vector3(1, 1, 0).normalized, new Vector3(0, 1, 1).normalized };
        ring.AddComponent<RingSpinner>().Init(index);
        ring.transform.Rotate(axes[index % axes.Length], index * 45f);

        return ring;
    }

    void AnimatePortal()
    {
        spinAngle += Time.deltaTime * 60f;
        if (portalVisual) portalVisual.transform.rotation = Quaternion.Euler(0, spinAngle, 0);
        if (portalLight) portalLight.intensity = 3f + Mathf.Sin(Time.time * 2f) * 1f;
    }

    void CheckPlayerEntry()
    {
        var player = FindObjectOfType<PlayerController>();
        if (!player) return;
        float dist = Vector3.Distance(transform.position, player.transform.position);
        if (dist < 1.5f)
        {
            TriggerTransition();
        }
    }

    void ActivatePortal()
    {
        triggered = true;
        isActive = true;
        SetVisible(true);
    }

    void SetVisible(bool v)
    {
        if (portalVisual) portalVisual.SetActive(v);
        if (portalLight) portalLight.enabled = v;
    }

    void TriggerTransition()
    {
        isActive = false;
        if (GameManager.Instance)
        {
            GameManager.Instance.PlayerGrowthScale = Mathf.Min(GameManager.Instance.PlayerGrowthScale + 0.05f, 1.5f);
            GameManager.Instance.PlayerGlowIntensity = Mathf.Min(GameManager.Instance.PlayerGlowIntensity + 0.3f, 3f);
            GameManager.Instance.NextWorld();
        }
    }
}

public class PortalParticle : MonoBehaviour
{
    private float angle;
    private float radius = 1.5f;
    private float speed;
    private float yOffset;

    public void Init(int index, int total)
    {
        angle = (index / (float)total) * 360f;
        speed = Random.Range(60f, 120f);
        yOffset = Random.Range(-0.5f, 0.5f);
        radius = Random.Range(1.2f, 2f);
    }

    void Update()
    {
        angle += speed * Time.deltaTime;
        float r = angle * Mathf.Deg2Rad;
        transform.localPosition = new Vector3(Mathf.Cos(r) * radius, yOffset + Mathf.Sin(Time.time * 2f) * 0.2f, Mathf.Sin(r) * radius);
    }
}
