using UnityEngine;

/// <summary>
/// Base class for all world scene managers.
/// Each world inherits this, overrides Setup() and UpdateWorld().
/// </summary>
public abstract class WorldBase : MonoBehaviour
{
    [Header("World Identity")]
    public string worldName = "World";
    public Color skyColor = new Color(0.4f, 0.6f, 0.9f);
    public Color fogColor = new Color(0.5f, 0.6f, 0.8f);
    public float fogDensity = 0.01f;
    public bool hasDayNightCycle = true;

    [Header("Lighting")]
    public Color sunColor = Color.white;
    public float sunIntensity = 1f;

    protected GameObject playerObj;
    protected GuardianCompanion guardian;
    protected Portal portal;
    protected Light sunLight;
    protected float dayTime = 0f;
    protected float daySpeed = 0.02f;

    void Awake()
    {
        SetupSky();
        Setup();
    }

    void Start()
    {
        SpawnPlayer();
        SpawnGuardian();
        SpawnPortal();
        PostStart();
    }

    void Update()
    {
        if (hasDayNightCycle) UpdateDayNight();
        UpdateWorld();
    }

    protected virtual void Setup() { }
    protected virtual void PostStart() { }
    protected virtual void UpdateWorld() { }

    void SetupSky()
    {
        Camera.main?.gameObject.GetComponent<Camera>()?.gameObject.SetActive(false);

        Camera cam = new GameObject("WorldCamera").AddComponent<Camera>();
        cam.tag = "MainCamera";
        cam.backgroundColor = skyColor;
        cam.clearFlags = CameraClearFlags.SolidColor;

        RenderSettings.ambientLight = skyColor * 0.3f;
        RenderSettings.fog = true;
        RenderSettings.fogColor = fogColor;
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = fogDensity;

        // Sun/directional light
        GameObject sunObj = new GameObject("Sun");
        sunLight = sunObj.AddComponent<Light>();
        sunLight.type = LightType.Directional;
        sunLight.color = sunColor;
        sunLight.intensity = sunIntensity;
        sunObj.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
    }

    void SpawnPlayer()
    {
        playerObj = new GameObject("Player");
        playerObj.transform.position = new Vector3(0, 3f, 0);
        playerObj.AddComponent<CharacterController>();
        playerObj.AddComponent<PlayerController>();
        playerObj.AddComponent<PauseMenu>();
    }

    void SpawnGuardian()
    {
        GameObject guardianObj = new GameObject("Guardian");
        guardianObj.transform.position = new Vector3(0, 3f, -2f);
        guardian = guardianObj.AddComponent<GuardianCompanion>();
        guardian.playerTransform = playerObj.transform;
        if (GameManager.Instance)
            guardian.SetGlow(GameManager.Instance.PlayerGlowIntensity * 0.5f + 1f);
    }

    void SpawnPortal()
    {
        GameObject portalObj = new GameObject("WorldPortal");
        // Place portal at a distant location; it will activate after time requirement
        portalObj.transform.position = new Vector3(20f, 1f, 20f);
        portal = portalObj.AddComponent<Portal>();
        portal.timeRequired = GetPortalTimeRequirement();
    }

    protected virtual float GetPortalTimeRequirement()
    {
        return 45f; // Default 45 seconds of exploration
    }

    void UpdateDayNight()
    {
        dayTime += Time.deltaTime * daySpeed;
        float sunAngle = dayTime * 360f;
        if (sunLight) sunLight.transform.rotation = Quaternion.Euler(sunAngle, -30f, 0f);
        float t = Mathf.Sin(dayTime * Mathf.PI);
        if (sunLight) sunLight.intensity = Mathf.Lerp(0.1f, sunIntensity, t);

        Color nightSky = skyColor * 0.1f;
        Camera.main.backgroundColor = Color.Lerp(nightSky, skyColor, t);
        RenderSettings.ambientLight = Color.Lerp(new Color(0.02f, 0.02f, 0.05f), skyColor * 0.3f, t);
    }

    protected void AddWorldIntro()
    {
        gameObject.AddComponent<WorldIntroUI>();
    }
}
