using UnityEngine;
using System.Collections.Generic;

public class WorldI_Greed : WorldBase
{
    private List<GameObject> collectibles = new List<GameObject>();
    private int collectedCount = 0;
    private int totalCollectibles = 20;
    private bool greedTriggered = false;
    private float greedTimer = 0f;
    private GUIStyle hintStyle;

    protected override void Setup()
    {
        worldName = "World I – The Voxel Path";
        skyColor = new Color(0.7f, 0.65f, 0.4f);
        fogColor = new Color(0.8f, 0.75f, 0.5f);
        fogDensity = 0.008f;
        sunColor = new Color(1f, 0.85f, 0.5f);
        sunIntensity = 1f;
        hasDayNightCycle = false;

        AddWorldIntro();
        BuildVoxelPaths();
        SpawnCollectibles();
        SpawnNPCsWorld1();
    }

    void BuildVoxelPaths()
    {
        GameObject terrain = new GameObject("VoxelTerrain");
        var gen = terrain.AddComponent<ProceduralChunkTerrain>();
        gen.terrainType = ProceduralChunkTerrain.TerrainType.Voxel;
        gen.chunkSize = 16;
        gen.viewDistance = 3;
        gen.noiseScale = 0.06f;
        gen.chunkHeight = 5;
        gen.voxelColor = new Color(0.6f, 0.55f, 0.35f);
        gen.groundColor = new Color(0.5f, 0.45f, 0.3f);
        gen.spawnTrees = true;
        gen.spawnHouses = false;
        gen.treesPerChunk = 2;

        // Flat path corridors
        BuildRoads();
    }

    void BuildRoads()
    {
        // Build a cross-shaped road
        Material roadMat = new Material(Shader.Find("Standard"));
        roadMat.color = new Color(0.55f, 0.5f, 0.4f);

        for (int i = -10; i <= 10; i++)
        {
            SpawnRoadBlock(new Vector3(i * 2f, 0f, 0f), roadMat);
            SpawnRoadBlock(new Vector3(0f, 0f, i * 2f), roadMat);
        }
    }

    void SpawnRoadBlock(Vector3 pos, Material mat)
    {
        GameObject b = GameObject.CreatePrimitive(PrimitiveType.Cube);
        b.transform.position = pos;
        b.transform.localScale = new Vector3(2f, 0.2f, 2f);
        b.GetComponent<Renderer>().material = mat;
    }

    void SpawnCollectibles()
    {
        for (int i = 0; i < totalCollectibles; i++)
        {
            Vector3 pos = new Vector3(Random.Range(-18f, 18f), 1.5f, Random.Range(-18f, 18f));
            GameObject col = CreateCollectible(pos, i);
            collectibles.Add(col);
        }
    }

    GameObject CreateCollectible(Vector3 pos, int index)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = "Collectible_" + index;
        go.transform.position = pos;
        go.transform.localScale = Vector3.one * 0.4f;

        Material mat = new Material(Shader.Find("Standard"));
        mat.color = new Color(1f, 0.85f, 0.2f);
        mat.EnableKeyword("_EMISSION");
        mat.SetColor("_EmissionColor", new Color(1f, 0.7f, 0f) * 2f);
        go.GetComponent<Renderer>().material = mat;

        go.GetComponent<BoxCollider>().isTrigger = true;
        go.AddComponent<CollectibleBehavior>().OnCollected += OnItemCollected;
        go.AddComponent<CollectibleSpin>();

        Light l = new GameObject("CLight").AddComponent<Light>();
        l.transform.SetParent(go.transform);
        l.type = LightType.Point;
        l.color = new Color(1f, 0.8f, 0f);
        l.range = 2f;
        l.intensity = 0.8f;

        return go;
    }

    void OnItemCollected(int count)
    {
        collectedCount++;

        if (collectedCount > totalCollectibles / 2)
        {
            greedTriggered = true;
            greedTimer = 5f;
        }

        // Reward player glow for each collect
        var player = FindObjectOfType<PlayerController>();
        if (player) player.AddGlow(0.05f);
    }

    void SpawnNPCsWorld1()
    {
        GameObject so = new GameObject("NPCSpawner");
        var sp = so.AddComponent<NPCSpawner>();
        sp.passiveCount = 6;
        sp.correctorCount = 5;
        sp.specialCount = 0;
        sp.spawnRadius = 25f;
    }

    protected override float GetPortalTimeRequirement() => 50f;

    protected override void UpdateWorld()
    {
        if (greedTriggered)
        {
            greedTimer -= Time.deltaTime;
        }
    }

    void OnGUI()
    {
        if (hintStyle == null)
        {
            hintStyle = new GUIStyle(GUI.skin.label);
            hintStyle.fontSize = 16;
            hintStyle.alignment = TextAnchor.UpperCenter;
            hintStyle.normal.textColor = new Color(1f, 0.8f, 0.3f);
        }

        if (greedTriggered && greedTimer > 0f)
        {
            GUI.Label(new Rect(0, Screen.height * 0.12f, Screen.width, 30),
                "The Correctors call to you... Listen, do not hoard.", hintStyle);
        }

        // Collectible counter
        GUIStyle counter = new GUIStyle(GUI.skin.label);
        counter.fontSize = 14;
        counter.normal.textColor = new Color(1f, 0.85f, 0.3f, 0.7f);
        GUI.Label(new Rect(10, 10, 200, 30), $"Fragments: {collectedCount} / {totalCollectibles}", counter);
    }
}

public class CollectibleBehavior : MonoBehaviour
{
    public System.Action<int> OnCollected;
    private static int globalCount = 0;

    void OnTriggerEnter(Collider other)
    {
        if (other.GetComponent<PlayerController>() != null)
        {
            globalCount++;
            OnCollected?.Invoke(globalCount);
            Destroy(gameObject);
        }
    }
}

public class CollectibleSpin : MonoBehaviour
{
    private float bobTime;
    private Vector3 origin;
    void Start() { origin = transform.position; bobTime = Random.Range(0f, Mathf.PI * 2f); }
    void Update()
    {
        transform.Rotate(0, 90f * Time.deltaTime, 0);
        transform.position = origin + Vector3.up * Mathf.Sin(Time.time + bobTime) * 0.2f;
    }
}
