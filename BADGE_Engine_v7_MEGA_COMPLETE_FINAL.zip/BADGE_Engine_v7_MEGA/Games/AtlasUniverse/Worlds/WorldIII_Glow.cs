using UnityEngine;

public class WorldIII_Glow : WorldBase
{
    protected override void Setup()
    {
        worldName = "World III – The Lost Glow";
        skyColor = new Color(0.05f, 0.08f, 0.05f);
        fogColor = new Color(0.08f, 0.12f, 0.08f);
        fogDensity = 0.018f;
        sunColor = new Color(0.3f, 0.7f, 0.4f);
        sunIntensity = 0.15f;
        hasDayNightCycle = false;

        AddWorldIntro();
        BuildGlowTerrain();
        SpawnGlowingCreatures();
        SpawnLostSouls();
        SpawnGlowTrees();
    }

    void BuildGlowTerrain()
    {
        GameObject terrain = new GameObject("GlowTerrain");
        var gen = terrain.AddComponent<ProceduralChunkTerrain>();
        gen.terrainType = ProceduralChunkTerrain.TerrainType.Voxel;
        gen.chunkSize = 16;
        gen.viewDistance = 3;
        gen.noiseScale = 0.05f;
        gen.chunkHeight = 5;
        gen.voxelColor = new Color(0.1f, 0.2f, 0.12f);
        gen.groundColor = new Color(0.08f, 0.15f, 0.08f);
        gen.spawnTrees = false;
        gen.spawnHouses = false;
    }

    void SpawnGlowingCreatures()
    {
        for (int i = 0; i < 12; i++)
        {
            Vector3 pos = new Vector3(Random.Range(-25f, 25f), 1f, Random.Range(-25f, 25f));
            RaycastHit hit;
            if (Physics.Raycast(pos + Vector3.up * 40f, Vector3.down, out hit, 80f))
                pos.y = hit.point.y + 0.6f;

            GameObject creature = CreateGlowCreature(pos, i);
        }
    }

    GameObject CreateGlowCreature(Vector3 pos, int index)
    {
        GameObject go = new GameObject("GlowCreature_" + index);
        go.transform.position = pos;

        Color[] colors = {
            new Color(0.3f, 1f, 0.5f),
            new Color(0.5f, 0.9f, 0.3f),
            new Color(0.2f, 1f, 0.7f),
            new Color(0.6f, 1f, 0.4f)
        };
        Color c = colors[index % colors.Length];

        // Body
        GameObject body = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        body.transform.SetParent(go.transform);
        body.transform.localPosition = new Vector3(0, 0.3f, 0);
        body.transform.localScale = new Vector3(0.6f, 0.4f, 0.8f);
        Material mat = new Material(Shader.Find("Standard"));
        mat.color = c;
        mat.EnableKeyword("_EMISSION");
        mat.SetColor("_EmissionColor", c * 2.5f);
        body.GetComponent<Renderer>().material = mat;
        Destroy(body.GetComponent<Collider>());

        // Glow light
        Light l = new GameObject("CL").AddComponent<Light>();
        l.transform.SetParent(go.transform);
        l.type = LightType.Point;
        l.color = c;
        l.range = 6f;
        l.intensity = 1.5f;

        go.AddComponent<GlowCreatureBehavior>().glowColor = c;
        return go;
    }

    void SpawnLostSouls()
    {
        GameObject so = new GameObject("LostSoulSpawner");
        var sp = so.AddComponent<NPCSpawner>();
        sp.passiveCount = 2;
        sp.correctorCount = 3;
        sp.specialCount = 8;
        sp.specialType = NPCBase.NPCType.LostSoul;
        sp.spawnRadius = 30f;
    }

    void SpawnGlowTrees()
    {
        for (int i = 0; i < 20; i++)
        {
            Vector3 pos = new Vector3(Random.Range(-30f, 30f), 0f, Random.Range(-30f, 30f));
            RaycastHit hit;
            if (Physics.Raycast(pos + Vector3.up * 40f, Vector3.down, out hit, 80f))
                pos.y = hit.point.y;

            CreateGlowTree(pos, i);
        }
    }

    void CreateGlowTree(Vector3 pos, int index)
    {
        GameObject tree = new GameObject("GlowTree_" + index);
        tree.transform.position = pos;

        Color treeColor = new Color(Random.Range(0.2f, 0.5f), Random.Range(0.6f, 1f), Random.Range(0.2f, 0.5f));

        // Trunk
        GameObject trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        trunk.transform.SetParent(tree.transform);
        trunk.transform.localPosition = Vector3.up * 0.8f;
        trunk.transform.localScale = new Vector3(0.15f, 0.8f, 0.15f);
        Material tm = new Material(Shader.Find("Standard"));
        tm.color = new Color(0.1f, 0.25f, 0.1f);
        tm.EnableKeyword("_EMISSION");
        tm.SetColor("_EmissionColor", new Color(0f, 0.15f, 0f));
        trunk.GetComponent<Renderer>().material = tm;
        Destroy(trunk.GetComponent<Collider>());

        // Canopy
        GameObject canopy = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        canopy.transform.SetParent(tree.transform);
        canopy.transform.localPosition = Vector3.up * 2f;
        canopy.transform.localScale = Vector3.one * Random.Range(0.8f, 1.5f);
        Material cm = new Material(Shader.Find("Standard"));
        cm.color = treeColor;
        cm.EnableKeyword("_EMISSION");
        cm.SetColor("_EmissionColor", treeColor * 1.5f);
        canopy.GetComponent<Renderer>().material = cm;
        Destroy(canopy.GetComponent<Collider>());

        Light tl = new GameObject("TL").AddComponent<Light>();
        tl.transform.SetParent(tree.transform);
        tl.transform.localPosition = Vector3.up * 2f;
        tl.type = LightType.Point;
        tl.color = treeColor;
        tl.range = 5f;
        tl.intensity = 0.8f;
    }

    protected override float GetPortalTimeRequirement() => 50f;
}

public class GlowCreatureBehavior : MonoBehaviour
{
    public Color glowColor;
    private Vector3 origin;
    private float speed;
    private float radius;
    private float angle;
    private Light gl;

    void Start()
    {
        origin = transform.position;
        speed = Random.Range(0.3f, 0.8f);
        radius = Random.Range(2f, 5f);
        angle = Random.Range(0f, 360f);
        gl = GetComponentInChildren<Light>();
    }

    void Update()
    {
        angle += speed * Time.deltaTime * 30f;
        float r = angle * Mathf.Deg2Rad;
        transform.position = origin + new Vector3(Mathf.Cos(r) * radius, Mathf.Sin(Time.time * 0.5f) * 0.4f, Mathf.Sin(r) * radius);
        if (gl) gl.intensity = 1.2f + Mathf.Sin(Time.time * 2f) * 0.5f;
    }
}
