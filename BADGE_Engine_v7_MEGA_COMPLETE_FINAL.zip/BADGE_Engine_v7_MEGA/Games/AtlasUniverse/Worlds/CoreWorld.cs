using UnityEngine;
using UnityEngine.SceneManagement;

public class CoreWorld : MonoBehaviour
{
    private enum CoreState { Intro, Exploring, Choosing, Terminated, Imprisoned }

    private CoreState state = CoreState.Intro;
    private bool introShown = false;
    private float introAlpha = 0f;
    private bool introFadingIn = true;

    private GameObject cageObj;
    private GameObject orbObj;
    private Light orbLight;
    private Light cageLight;
    private GuardianCompanion guardian;
    private PlayerController player;

    private bool playerNearOrb = false;
    private bool playerNearCage = false;
    private float terminatedTimer = 0f;
    private float fadeAlpha = 0f;
    private bool fadingOut = false;

    private GUIStyle titleStyle;
    private GUIStyle bodyStyle;
    private GUIStyle choiceStyle;
    private GUIStyle terminatedStyle;

    void Start()
    {
        Time.timeScale = 0f; // Pause during intro

        SetupEnvironment();
        SpawnPlayer();
        SpawnGuardian();
        SpawnCage();
        SpawnOrb();
    }

    void SetupEnvironment()
    {
        // Camera
        Camera cam = new GameObject("CoreCamera").AddComponent<Camera>();
        cam.tag = "MainCamera";
        cam.backgroundColor = new Color(0.01f, 0.01f, 0.02f);
        cam.clearFlags = CameraClearFlags.SolidColor;

        // Minimal ambient
        RenderSettings.ambientLight = new Color(0.02f, 0.02f, 0.04f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(0.02f, 0.01f, 0.03f);
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = 0.04f;

        // Ground
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.transform.position = Vector3.zero;
        ground.transform.localScale = Vector3.one * 5f;
        Material gm = new Material(Shader.Find("Standard"));
        gm.color = new Color(0.04f, 0.03f, 0.06f);
        ground.GetComponent<Renderer>().material = gm;

        // Directional light (very dim)
        Light dl = new GameObject("DimLight").AddComponent<Light>();
        dl.type = LightType.Directional;
        dl.color = new Color(0.3f, 0.2f, 0.5f);
        dl.intensity = 0.15f;
        dl.transform.rotation = Quaternion.Euler(45f, 0f, 0f);
    }

    void SpawnPlayer()
    {
        GameObject playerObj = new GameObject("Player");
        playerObj.transform.position = new Vector3(0, 1f, -8f);
        playerObj.AddComponent<CharacterController>();
        player = playerObj.AddComponent<PlayerController>();
        playerObj.AddComponent<PauseMenu>();
    }

    void SpawnGuardian()
    {
        if (GameManager.Instance) { }
        GameObject go = new GameObject("Guardian");
        go.transform.position = new Vector3(0, 2f, -6f);
        guardian = go.AddComponent<GuardianCompanion>();
        if (player) guardian.playerTransform = player.transform;
    }

    void SpawnCage()
    {
        cageObj = new GameObject("TheCage");
        cageObj.transform.position = new Vector3(-6f, 0f, 5f);

        // Build cage from bars
        int bars = 8;
        float radius = 1.2f;
        float height = 2.5f;

        Material barMat = new Material(Shader.Find("Standard"));
        barMat.color = new Color(0.4f, 0.35f, 0.3f);

        for (int i = 0; i < bars; i++)
        {
            float angle = (i / (float)bars) * Mathf.PI * 2f;
            GameObject bar = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            bar.transform.SetParent(cageObj.transform);
            bar.transform.localPosition = new Vector3(Mathf.Cos(angle) * radius, height / 2f, Mathf.Sin(angle) * radius);
            bar.transform.localScale = new Vector3(0.08f, height / 2f, 0.08f);
            bar.GetComponent<Renderer>().material = barMat;
            Destroy(bar.GetComponent<Collider>());
        }

        // Top ring
        GameObject topRing = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        topRing.transform.SetParent(cageObj.transform);
        topRing.transform.localPosition = new Vector3(0, height, 0);
        topRing.transform.localScale = new Vector3(radius * 2.2f, 0.05f, radius * 2.2f);
        topRing.GetComponent<Renderer>().material = barMat;
        Destroy(topRing.GetComponent<Collider>());

        // Bottom ring
        GameObject bottomRing = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        bottomRing.transform.SetParent(cageObj.transform);
        bottomRing.transform.localPosition = Vector3.zero;
        bottomRing.transform.localScale = new Vector3(radius * 2.2f, 0.05f, radius * 2.2f);
        bottomRing.GetComponent<Renderer>().material = barMat;
        Destroy(bottomRing.GetComponent<Collider>());

        // Cage interaction trigger
        GameObject trigger = new GameObject("CageTrigger");
        trigger.transform.SetParent(cageObj.transform);
        trigger.transform.localPosition = new Vector3(0, height / 2f, 0);
        SphereCollider sc = trigger.AddComponent<SphereCollider>();
        sc.radius = 1.8f;
        sc.isTrigger = true;
        trigger.AddComponent<CageZone>();

        // Cage light
        cageLight = new GameObject("CageLight").AddComponent<Light>();
        cageLight.transform.SetParent(cageObj.transform);
        cageLight.transform.localPosition = new Vector3(0, height, 0);
        cageLight.type = LightType.Point;
        cageLight.color = new Color(0.6f, 0.5f, 0.3f);
        cageLight.range = 6f;
        cageLight.intensity = 1f;

        // Label
        cageObj.AddComponent<CageLabel>();
    }

    void SpawnOrb()
    {
        orbObj = new GameObject("TheOrb");
        orbObj.transform.position = new Vector3(6f, 1.5f, 5f);

        // Central sphere
        GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        sphere.transform.SetParent(orbObj.transform);
        sphere.transform.localPosition = Vector3.zero;
        sphere.transform.localScale = Vector3.one * 0.7f;
        Material orbMat = new Material(Shader.Find("Standard"));
        orbMat.color = new Color(0.9f, 0.9f, 1f);
        orbMat.EnableKeyword("_EMISSION");
        orbMat.SetColor("_EmissionColor", Color.white * 3f);
        sphere.GetComponent<Renderer>().material = orbMat;
        Destroy(sphere.GetComponent<Collider>());

        // Orbiting rings
        for (int i = 0; i < 3; i++)
        {
            GameObject ring = new GameObject("OrbRing_" + i);
            ring.transform.SetParent(orbObj.transform);
            ring.AddComponent<RingSpinner>().Init(i);
        }

        // Trigger zone
        SphereCollider sc = orbObj.AddComponent<SphereCollider>();
        sc.radius = 2f;
        sc.isTrigger = true;
        orbObj.AddComponent<OrbZone>();

        // Orb light
        orbLight = new GameObject("OrbLight").AddComponent<Light>();
        orbLight.transform.SetParent(orbObj.transform);
        orbLight.type = LightType.Point;
        orbLight.color = new Color(0.8f, 0.9f, 1f);
        orbLight.range = 10f;
        orbLight.intensity = 2f;

        orbObj.AddComponent<OrbLabel>();
    }

    void Update()
    {
        switch (state)
        {
            case CoreState.Intro: UpdateIntro(); break;
            case CoreState.Exploring: UpdateExploring(); break;
            case CoreState.Terminated: UpdateTerminated(); break;
            case CoreState.Imprisoned: UpdateImprisoned(); break;
        }

        // Pulse lights
        if (orbLight) orbLight.intensity = 2f + Mathf.Sin(Time.time * 2f) * 0.5f;
        if (cageLight) cageLight.intensity = 0.8f + Mathf.Sin(Time.time * 1.5f + 1f) * 0.3f;
    }

    void UpdateIntro()
    {
        if (introFadingIn)
        {
            introAlpha += Time.unscaledDeltaTime * 0.8f;
            if (introAlpha >= 1f) { introAlpha = 1f; introFadingIn = false; }
        }
        if (!introFadingIn && Input.anyKeyDown)
        {
            state = CoreState.Exploring;
            Time.timeScale = 1f;
        }
    }

    void UpdateExploring()
    {
        // Check proximity to choices
        if (player != null)
        {
            float orbDist = Vector3.Distance(player.transform.position, orbObj.transform.position);
            float cageDist = Vector3.Distance(player.transform.position, cageObj.transform.position);

            if (orbDist < 2.5f)
            {
                state = CoreState.Terminated;
                TriggerTermination();
            }
            else if (cageDist < 2f)
            {
                state = CoreState.Imprisoned;
                TriggerImprisonment();
            }
        }
    }

    void TriggerTermination()
    {
        if (GameManager.Instance) GameManager.Instance.TerminateExistence();
        if (guardian) guardian.Hide();
        fadingOut = true;
    }

    void TriggerImprisonment()
    {
        // Cage closes around player
        if (player) player.enabled = false;
        if (guardian) guardian.SetGlow(0.3f);
    }

    void UpdateTerminated()
    {
        terminatedTimer += Time.deltaTime;
        fadeAlpha = Mathf.Min(fadeAlpha + Time.deltaTime * 1.5f, 1f);

        if (terminatedTimer > 5f)
        {
            // Return to start scene - locked
            SceneManager.LoadScene(0);
        }
    }

    void UpdateImprisoned()
    {
        // Player is trapped - show imprisonment message
        if (orbObj) orbObj.SetActive(false);
    }

    void OnGUI()
    {
        switch (state)
        {
            case CoreState.Intro: DrawIntro(); break;
            case CoreState.Exploring: DrawChoiceHint(); break;
            case CoreState.Terminated: DrawTerminated(); break;
            case CoreState.Imprisoned: DrawImprisoned(); break;
        }
    }

    void DrawIntro()
    {
        GUI.color = new Color(0, 0, 0, introAlpha * 0.85f);
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
        GUI.color = Color.white;

        GUIStyle ts = GetTitleStyle();
        ts.normal.textColor = new Color(0.8f, 0.7f, 1f, introAlpha);
        GUI.Label(new Rect(0, Screen.height * 0.2f, Screen.width, 70), "THE CORE", ts);

        GUIStyle bs = GetBodyStyle();
        bs.normal.textColor = new Color(0.7f, 0.65f, 0.9f, introAlpha);
        string introText =
            "You have traversed all seven realms.\n" +
            "Pride. Greed. Lust. Gluttony. Wrath. Envy. Sloth.\n\n" +
            "Your Guardian has walked beside you through every darkness.\n" +
            "Now you stand at the center of existence itself.\n\n" +
            "Two objects await you.\n" +
            "One is a Cage. One is a Glowing Orb.\n\n" +
            "Choose your fate.\n\n" +
            "Press any key to proceed.";
        GUI.Label(new Rect(Screen.width * 0.2f, Screen.height * 0.32f, Screen.width * 0.6f, Screen.height * 0.6f), introText, bs);
    }

    void DrawChoiceHint()
    {
        GUIStyle cs = GetChoiceStyle();

        // Cage label
        Vector3 cageScreen = Camera.main ? Camera.main.WorldToScreenPoint(cageObj.transform.position + Vector3.up * 3f) : Vector3.zero;
        if (cageScreen.z > 0)
        {
            cs.normal.textColor = new Color(0.8f, 0.7f, 0.5f, 1f);
            GUI.Label(new Rect(cageScreen.x - 60, Screen.height - cageScreen.y - 40, 120, 30), "THE CAGE", cs);
        }

        // Orb label
        Vector3 orbScreen = Camera.main ? Camera.main.WorldToScreenPoint(orbObj.transform.position + Vector3.up * 2f) : Vector3.zero;
        if (orbScreen.z > 0)
        {
            cs.normal.textColor = new Color(0.9f, 0.9f, 1f, 1f);
            GUI.Label(new Rect(orbScreen.x - 60, Screen.height - orbScreen.y - 40, 120, 30), "THE ORB", cs);
        }

        // Center text
        GUIStyle hs = new GUIStyle(GUI.skin.label);
        hs.fontSize = 18;
        hs.alignment = TextAnchor.UpperCenter;
        hs.normal.textColor = new Color(0.6f, 0.55f, 0.8f, 0.7f + Mathf.Sin(Time.time * 2f) * 0.2f);
        GUI.Label(new Rect(0, Screen.height * 0.88f, Screen.width, 30), "Choose your fate", hs);
    }

    void DrawTerminated()
    {
        GUI.color = new Color(0, 0, 0, fadeAlpha);
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
        GUI.color = Color.white;

        if (fadeAlpha > 0.6f)
        {
            GUIStyle ts = GetTerminatedStyle();
            ts.normal.textColor = new Color(0.6f, 0.1f, 0.1f, (fadeAlpha - 0.6f) / 0.4f);
            GUI.Label(new Rect(0, Screen.height * 0.38f, Screen.width, 60), "YOUR EXISTENCE HAS BEEN", ts);
            GUI.Label(new Rect(0, Screen.height * 0.49f, Screen.width, 60), "TERMINATED PERMANENTLY", ts);
        }
    }

    void DrawImprisoned()
    {
        GUIStyle ts = GetBodyStyle();
        ts.normal.textColor = new Color(0.6f, 0.5f, 0.3f, 1f);
        ts.fontSize = 22;
        GUI.Label(new Rect(0, Screen.height * 0.3f, Screen.width, 50), "You have chosen the Cage.", ts);
        GUI.Label(new Rect(0, Screen.height * 0.42f, Screen.width, 40), "Existence continues — in stillness.", ts);
        GUI.Label(new Rect(0, Screen.height * 0.53f, Screen.width, 40), "You are not free. But you are here.", ts);

        if (GUI.Button(new Rect((Screen.width - 200) / 2, Screen.height * 0.68f, 200, 40), "Accept Your Fate"))
        {
            if (GameManager.Instance) GameManager.Instance.ResetGame();
            else { PlayerPrefs.DeleteAll(); SceneManager.LoadScene(0); }
        }
    }

    GUIStyle GetTitleStyle()
    {
        if (titleStyle == null)
        {
            titleStyle = new GUIStyle(GUI.skin.label);
            titleStyle.fontSize = 48;
            titleStyle.fontStyle = FontStyle.Bold;
            titleStyle.alignment = TextAnchor.MiddleCenter;
        }
        return titleStyle;
    }

    GUIStyle GetBodyStyle()
    {
        if (bodyStyle == null)
        {
            bodyStyle = new GUIStyle(GUI.skin.label);
            bodyStyle.fontSize = 18;
            bodyStyle.alignment = TextAnchor.UpperCenter;
            bodyStyle.wordWrap = true;
        }
        return bodyStyle;
    }

    GUIStyle GetChoiceStyle()
    {
        if (choiceStyle == null)
        {
            choiceStyle = new GUIStyle(GUI.skin.label);
            choiceStyle.fontSize = 15;
            choiceStyle.fontStyle = FontStyle.Bold;
            choiceStyle.alignment = TextAnchor.MiddleCenter;
        }
        return choiceStyle;
    }

    GUIStyle GetTerminatedStyle()
    {
        if (terminatedStyle == null)
        {
            terminatedStyle = new GUIStyle(GUI.skin.label);
            terminatedStyle.fontSize = 36;
            terminatedStyle.fontStyle = FontStyle.Bold;
            terminatedStyle.alignment = TextAnchor.MiddleCenter;
        }
        return terminatedStyle;
    }
}

// Zone triggers
public class CageZone : MonoBehaviour { }
public class OrbZone : MonoBehaviour { }

// World labels (float in 3D)
public class CageLabel : MonoBehaviour
{
    void Update() { transform.Rotate(0, 20f * Time.deltaTime, 0); }
}
public class OrbLabel : MonoBehaviour
{
    void Update()
    {
        transform.Rotate(0, 30f * Time.deltaTime, 0);
        transform.position += Vector3.up * Mathf.Sin(Time.time * 2f) * 0.003f;
    }
}
