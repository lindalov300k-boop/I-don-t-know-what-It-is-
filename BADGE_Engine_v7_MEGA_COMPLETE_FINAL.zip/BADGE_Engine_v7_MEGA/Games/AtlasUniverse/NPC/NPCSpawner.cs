using UnityEngine;

public class NPCSpawner : MonoBehaviour
{
    public int passiveCount = 8;
    public int correctorCount = 3;
    public int specialCount = 5;
    public float spawnRadius = 30f;
    public NPCBase.NPCType specialType = NPCBase.NPCType.Passive;

    void Start()
    {
        SpawnNPCs();
    }

    void SpawnNPCs()
    {
        // Passive NPCs
        for (int i = 0; i < passiveCount; i++)
            SpawnNPC(NPCBase.NPCType.Passive, RandomGroundPos());

        // Glowing Correctors
        for (int i = 0; i < correctorCount; i++)
            SpawnNPC(NPCBase.NPCType.GlowingCorrector, RandomGroundPos());

        // Special type
        for (int i = 0; i < specialCount; i++)
            SpawnNPC(specialType, RandomGroundPos());
    }

    void SpawnNPC(NPCBase.NPCType type, Vector3 pos)
    {
        GameObject npcObj = new GameObject("NPC_" + type.ToString());
        npcObj.transform.position = pos;
        NPCBase npc = npcObj.AddComponent<NPCBase>();
        npc.npcType = type;
        npc.skinColor = new Color(Random.Range(0.5f, 0.9f), Random.Range(0.5f, 0.8f), Random.Range(0.4f, 0.7f));
        npc.clothColor = new Color(Random.Range(0.2f, 0.8f), Random.Range(0.2f, 0.8f), Random.Range(0.2f, 0.8f));

        // Add capsule collider for physics
        CapsuleCollider cap = npcObj.AddComponent<CapsuleCollider>();
        cap.height = 1.8f;
        cap.radius = 0.3f;
        cap.center = new Vector3(0, 0.9f, 0);
    }

    Vector3 RandomGroundPos()
    {
        Vector3 offset = new Vector3(Random.Range(-spawnRadius, spawnRadius), 0, Random.Range(-spawnRadius, spawnRadius));
        Vector3 pos = transform.position + offset;

        // Raycast down to find ground
        RaycastHit hit;
        if (Physics.Raycast(pos + Vector3.up * 50f, Vector3.down, out hit, 100f))
            pos.y = hit.point.y;

        return pos;
    }
}
