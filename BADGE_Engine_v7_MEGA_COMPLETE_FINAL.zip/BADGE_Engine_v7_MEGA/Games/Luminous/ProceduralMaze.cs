using UnityEngine;
using System.Collections.Generic;

/// <summary>
/// Generates a 3D maze using dual-octave Perlin noise.
/// Every cube mesh is built from scratch — no primitives, no assets.
/// Pure darkness: no directional light, no ambient beyond near-black.
/// </summary>
public class ProceduralMaze : MonoBehaviour
{
    public static ProceduralMaze Instance;

    // ── Config ────────────────────────────────────────────────────
    public int   Width          = 32;
    public int   Height         = 32;
    public float WallThreshold  = 0.50f;
    public float NoiseScale     = 0.16f;
    public float BlockSize      = 2f;
    public float WallHeight     = 3.2f;

    // ── State ─────────────────────────────────────────────────────
    public Vector3 PlayerSpawnPos { get; private set; }
    public Vector3 OrbSpawnPos    { get; private set; }

    bool[,] grid;    // true = wall

    float seedX, seedY;

    List<GameObject> blocks = new List<GameObject>();

    Material wallMat;
    Material floorMat;

    // ─────────────────────────────────────────────────────────────
    void Awake()
    {
        Instance = this;
        MakeMaterials();
    }

    void Start() => GenerateNewMaze();

    // ── Public ────────────────────────────────────────────────────
    public void GenerateNewMaze()
    {
        ClearAll();
        seedX = Random.Range(0f, 99999f);
        seedY = Random.Range(0f, 99999f);
        SampleGrid();
        BuildFloor();
        BuildWalls();
        FindSpawns();
        if (UIManager.Instance) UIManager.Instance.FlashNewMaze();
        // Tell enemy spawner to re-spawn
        EnemySpawner sp = FindObjectOfType<EnemySpawner>();
        if (sp) sp.RespawnEnemies();
    }

    public bool IsWall(int gx, int gy)
    {
        if (gx < 0 || gx >= Width || gy < 0 || gy >= Height) return true;
        return grid[gx, gy];
    }

    public Vector3 GridToWorld(int gx, int gy) =>
        new Vector3(gx * BlockSize, 0f, gy * BlockSize);

    // ── Materials ─────────────────────────────────────────────────
    void MakeMaterials()
    {
        // Unity 2019.4 built-in standard shader
        wallMat       = new Material(Shader.Find("Standard"));
        wallMat.color = new Color(0.03f, 0.02f, 0.04f);
        wallMat.SetFloat("_Metallic",   0f);
        wallMat.SetFloat("_Smoothness", 0.05f);

        floorMat       = new Material(Shader.Find("Standard"));
        floorMat.color = new Color(0.02f, 0.01f, 0.03f);
        floorMat.SetFloat("_Metallic",   0f);
        floorMat.SetFloat("_Smoothness", 0.02f);
    }

    // ── Grid Sampling ─────────────────────────────────────────────
    void SampleGrid()
    {
        grid = new bool[Width, Height];
        for (int x = 0; x < Width; x++)
        for (int y = 0; y < Height; y++)
        {
            if (x == 0 || y == 0 || x == Width - 1 || y == Height - 1)
            { grid[x, y] = true; continue; }

            float nx = seedX + x * NoiseScale;
            float ny = seedY + y * NoiseScale;

            // Dual-octave Perlin
            float n  = Mathf.PerlinNoise(nx, ny);
            n       += 0.45f * Mathf.PerlinNoise(nx * 2.3f + 17f, ny * 2.3f + 5f);
            n       /= 1.45f;

            grid[x, y] = n > WallThreshold;
        }

        // Guarantee open spawn ring at center
        int cx = Width / 2, cy = Height / 2;
        for (int dx = -3; dx <= 3; dx++)
        for (int dy = -3; dy <= 3; dy++)
        {
            int nx2 = cx + dx, ny2 = cy + dy;
            if (nx2 > 0 && nx2 < Width - 1 && ny2 > 0 && ny2 < Height - 1)
                grid[nx2, ny2] = false;
        }
    }

    // ── Mesh Building ─────────────────────────────────────────────
    void BuildFloor()
    {
        float fw = Width  * BlockSize;
        float fh = Height * BlockSize;
        GameObject go = new GameObject("Floor");
        go.transform.SetParent(transform);
        go.transform.position   = new Vector3(fw * 0.5f - BlockSize * 0.5f,
                                              -0.3f,
                                              fh * 0.5f - BlockSize * 0.5f);
        go.transform.localScale = new Vector3(fw, 0.6f, fh);

        go.AddComponent<MeshFilter>().mesh    = MakeCubeMesh();
        go.AddComponent<MeshRenderer>().material = floorMat;
        go.AddComponent<BoxCollider>();
        blocks.Add(go);
    }

    void BuildWalls()
    {
        for (int x = 0; x < Width;  x++)
        for (int y = 0; y < Height; y++)
        {
            if (!grid[x, y]) continue;

            GameObject go = new GameObject("W_" + x + "_" + y);
            go.transform.SetParent(transform);
            go.transform.position   = new Vector3(x * BlockSize,
                                                   WallHeight * 0.5f,
                                                   y * BlockSize);
            go.transform.localScale = new Vector3(BlockSize, WallHeight, BlockSize);

            go.AddComponent<MeshFilter>().mesh       = MakeCubeMesh();
            go.AddComponent<MeshRenderer>().material = wallMat;
            go.AddComponent<BoxCollider>();
            blocks.Add(go);
        }
    }

    // Hand-built cube — 6 faces, correct normals, no imports
    Mesh MakeCubeMesh()
    {
        Vector3[] verts = new Vector3[]
        {
            // Front  (-Z)
            new Vector3(-0.5f,-0.5f,-0.5f), new Vector3( 0.5f,-0.5f,-0.5f),
            new Vector3( 0.5f, 0.5f,-0.5f), new Vector3(-0.5f, 0.5f,-0.5f),
            // Back   (+Z)
            new Vector3( 0.5f,-0.5f, 0.5f), new Vector3(-0.5f,-0.5f, 0.5f),
            new Vector3(-0.5f, 0.5f, 0.5f), new Vector3( 0.5f, 0.5f, 0.5f),
            // Left   (-X)
            new Vector3(-0.5f,-0.5f, 0.5f), new Vector3(-0.5f,-0.5f,-0.5f),
            new Vector3(-0.5f, 0.5f,-0.5f), new Vector3(-0.5f, 0.5f, 0.5f),
            // Right  (+X)
            new Vector3( 0.5f,-0.5f,-0.5f), new Vector3( 0.5f,-0.5f, 0.5f),
            new Vector3( 0.5f, 0.5f, 0.5f), new Vector3( 0.5f, 0.5f,-0.5f),
            // Top    (+Y)
            new Vector3(-0.5f, 0.5f,-0.5f), new Vector3( 0.5f, 0.5f,-0.5f),
            new Vector3( 0.5f, 0.5f, 0.5f), new Vector3(-0.5f, 0.5f, 0.5f),
            // Bottom (-Y)
            new Vector3(-0.5f,-0.5f, 0.5f), new Vector3( 0.5f,-0.5f, 0.5f),
            new Vector3( 0.5f,-0.5f,-0.5f), new Vector3(-0.5f,-0.5f,-0.5f),
        };

        int[] tris = new int[36];
        for (int f = 0; f < 6; f++)
        {
            int v = f * 4, t = f * 6;
            tris[t]=v; tris[t+1]=v+1; tris[t+2]=v+2;
            tris[t+3]=v; tris[t+4]=v+2; tris[t+5]=v+3;
        }

        Mesh m = new Mesh();
        m.vertices  = verts;
        m.triangles = tris;
        m.RecalculateNormals();
        m.RecalculateBounds();
        return m;
    }

    // ── Spawn Detection ───────────────────────────────────────────
    void FindSpawns()
    {
        PlayerSpawnPos = GridToWorld(Width / 2, Height / 2);
        PlayerSpawnPos.y = 0.6f;

        // Orb: farthest reachable open cell from center
        for (int radius = Mathf.Max(Width, Height) / 2; radius > 3; radius--)
        {
            int ox = Width / 2 + radius;
            int oy = Height / 2 + radius;
            if (ox < Width - 1 && oy < Height - 1 && !grid[ox, oy])
            {
                OrbSpawnPos = GridToWorld(ox, oy);
                OrbSpawnPos.y = 1f;
                return;
            }
            // Try other quadrants
            int ox2 = Width / 2 - radius;
            int oy2 = Height / 2 - radius;
            if (ox2 > 0 && oy2 > 0 && !grid[ox2, oy2])
            {
                OrbSpawnPos = GridToWorld(ox2, oy2);
                OrbSpawnPos.y = 1f;
                return;
            }
        }
        // Fallback
        OrbSpawnPos = GridToWorld(Width - 4, Height - 4);
        OrbSpawnPos.y = 1f;
    }

    void ClearAll()
    {
        foreach (var b in blocks) if (b) Destroy(b);
        blocks.Clear();
    }
}
