using UnityEngine;

/// <summary>
/// Collectible glowing blue orb.
/// On collection:
///   - Increments global orb count (respects tier system).
///   - Saves to JSON.
///   - Triggers maze regeneration.
///   - Repositions player and itself.
///   - If orb count is MAX, orb still appears but collection only shows MAX.
/// </summary>
public class OrbController : MonoBehaviour
{
    Light  orbLight;
    Material orbMat;
    float pulseT;

    // Orbit visual
    float orbitT;
    Transform ring;

    void Awake()
    {
        BuildOrbMesh();
        BuildOrbLight();
        BuildRingDecal();
    }

    // ── Mesh ──────────────────────────────────────────────────────
    void BuildOrbMesh()
    {
        // Core sphere
        GameObject core = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        core.name = "OrbCore";
        core.transform.SetParent(transform);
        core.transform.localPosition = Vector3.zero;
        core.transform.localScale    = Vector3.one * 0.38f;
        Object.Destroy(core.GetComponent<SphereCollider>());

        orbMat = new Material(Shader.Find("Standard"));
        orbMat.color = new Color(0.15f, 0.45f, 1f);
        orbMat.EnableKeyword("_EMISSION");
        orbMat.SetColor("_EmissionColor", new Color(0f, 0.35f, 1.4f));
        orbMat.SetFloat("_Glossiness", 0.9f);
        core.GetComponent<MeshRenderer>().material = orbMat;

        // Trigger collider on root
        SphereCollider sc = gameObject.AddComponent<SphereCollider>();
        sc.isTrigger = true;
        sc.radius    = 0.65f;
    }

    // ── Light ─────────────────────────────────────────────────────
    void BuildOrbLight()
    {
        GameObject lg = new GameObject("OrbLight");
        lg.transform.SetParent(transform);
        lg.transform.localPosition = Vector3.zero;

        orbLight           = lg.AddComponent<Light>();
        orbLight.type      = LightType.Point;
        orbLight.color     = new Color(0.25f, 0.55f, 1f);
        orbLight.range     = 6f;
        orbLight.intensity = 1.8f;
        orbLight.shadows   = LightShadows.None;
    }

    // ── Orbiting ring (visual interest) ──────────────────────────
    void BuildRingDecal()
    {
        ring = new GameObject("Ring").transform;
        ring.SetParent(transform);
        ring.localPosition = Vector3.zero;

        // Build a thin torus-like ring from stretched spheres
        Material rm = new Material(Shader.Find("Standard"));
        rm.color = new Color(0.1f, 0.35f, 0.9f, 0.6f);
        rm.EnableKeyword("_EMISSION");
        rm.SetColor("_EmissionColor", new Color(0f, 0.2f, 0.8f));

        int segments = 12;
        float radius = 0.4f;
        for (int i = 0; i < segments; i++)
        {
            float angle = i / (float)segments * Mathf.PI * 2f;
            GameObject bead = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            bead.transform.SetParent(ring);
            bead.transform.localPosition = new Vector3(
                Mathf.Cos(angle) * radius, 0f, Mathf.Sin(angle) * radius);
            bead.transform.localScale = Vector3.one * 0.07f;
            bead.GetComponent<MeshRenderer>().material = rm;
            Object.Destroy(bead.GetComponent<SphereCollider>());
        }
    }

    // ── Update ────────────────────────────────────────────────────
    void Update()
    {
        pulseT += Time.deltaTime * 2.0f;
        orbitT += Time.deltaTime * 55f;    // ring spin speed

        float pulse = (Mathf.Sin(pulseT) + 1f) * 0.5f;

        // Pulse light
        orbLight.intensity = Mathf.Lerp(1.0f, 2.6f, pulse);
        orbLight.color     = Color.Lerp(
            new Color(0.15f, 0.4f, 1f),
            new Color(0.35f, 0.7f, 1f), pulse);

        // Pulse emission
        Color ec = Color.Lerp(
            new Color(0f, 0.2f, 0.9f),
            new Color(0.1f, 0.55f, 1.6f), pulse);
        orbMat.SetColor("_EmissionColor", ec);

        // Float up/down
        float floatY = Mathf.Sin(pulseT * 0.85f) * 0.12f;
        Vector3 p    = transform.position;
        transform.position = new Vector3(p.x, _baseY + floatY, p.z);

        // Spin ring
        if (ring) ring.localEulerAngles = new Vector3(20f, orbitT, 0f);
    }

    float _baseY;
    void Start() { _baseY = transform.position.y; }

    // ── Collection ────────────────────────────────────────────────
    void OnTriggerEnter(Collider other)
    {
        if (!other.GetComponent<PlayerController>()) return;

        // Count orb
        if (GameManager.Instance) GameManager.Instance.AddOrb();

        // Update HUD
        if (UIManager.Instance && GameManager.Instance)
            UIManager.Instance.SetOrbs(GameManager.Instance.TotalOrbs,
                                        GameManager.Instance.GetTierProgress(),
                                        GameManager.Instance.GetTierLabel());

        // New maze
        if (ProceduralMaze.Instance)
        {
            ProceduralMaze.Instance.GenerateNewMaze();

            // Move player to new spawn
            PlayerController pc = other.GetComponent<PlayerController>();
            if (pc) pc.transform.position = ProceduralMaze.Instance.PlayerSpawnPos;

            // Move orb to new position
            _baseY = ProceduralMaze.Instance.OrbSpawnPos.y;
            transform.position = ProceduralMaze.Instance.OrbSpawnPos;
        }
    }
}
