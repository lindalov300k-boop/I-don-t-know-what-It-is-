using UnityEngine;

/// <summary>
/// Low-poly black creature. No face. Asymmetric limbs.
/// Idles with a jitter. Chases player ONLY when player glows.
/// Plays procedural distortion audio when nearby.
/// Unity 2019.4 LTS compatible — no external assets.
/// </summary>
public class EnemyController : MonoBehaviour
{
    // ── Config ────────────────────────────────────────────────────
    public float ChaseSpeed    = 3.4f;
    public float DamagePerSec  = 14f;
    public float DetectRange   = 22f;
    public float AttackRadius  = 1.0f;

    // ── Private ───────────────────────────────────────────────────
    PlayerController player;
    CharacterController cc;

    // Limb bones
    Transform[] limbs;
    float[]     limbPhases;
    float[]     limbSpeeds;

    // Jitter
    float jitterT;

    // Audio
    AudioSource distSrc;
    float       audioCooldown;
    float       audioInterval;

    // ── Awake ─────────────────────────────────────────────────────
    void Awake()
    {
        cc        = gameObject.AddComponent<CharacterController>();
        cc.height = 1.5f;
        cc.radius = 0.32f;
        cc.center = Vector3.up * 0.75f;

        BuildCreature();
        BuildDistortionAudio();
        audioInterval = Random.Range(1.8f, 3.5f);
    }

    void Start()
    {
        player = FindObjectOfType<PlayerController>();
    }

    // ══════════════════════════════════════════════════════════════
    //  PROCEDURAL CREATURE — asymmetric, no face
    // ══════════════════════════════════════════════════════════════
    void BuildCreature()
    {
        Material m = new Material(Shader.Find("Standard"));
        m.color = new Color(0.015f, 0.008f, 0.020f);
        m.SetFloat("_Glossiness", 0.08f);
        m.SetFloat("_Metallic",   0f);

        // Body — elongated blob
        Part("Body",     new Vector3( 0.00f, 0.70f, 0.00f), new Vector3(0.35f, 0.78f, 0.28f), m);
        // Head — featureless oval, no eyes
        Part("Head",     new Vector3( 0.02f, 1.55f, 0.04f), new Vector3(0.32f, 0.42f, 0.30f), m);
        // Asymmetric limbs at odd angles
        Transform l1 = Part("LimbA", new Vector3(-0.30f, 0.60f,  0.02f), new Vector3(0.11f, 0.52f, 0.11f), m);
        Transform l2 = Part("LimbB", new Vector3( 0.28f, 0.52f, -0.04f), new Vector3(0.09f, 0.60f, 0.09f), m);
        Transform l3 = Part("LimbC", new Vector3(-0.14f, 0.08f,  0.06f), new Vector3(0.13f, 0.44f, 0.13f), m);
        Transform l4 = Part("LimbD", new Vector3( 0.16f, 0.10f, -0.06f), new Vector3(0.10f, 0.40f, 0.10f), m);
        // Extra tendril on head
        Transform l5 = Part("Tendril",new Vector3( 0.00f, 1.88f,  0.00f), new Vector3(0.06f, 0.38f, 0.06f), m);
        // Stubby side nub
        Transform l6 = Part("Nub",   new Vector3(-0.38f, 0.90f,  0.00f), new Vector3(0.20f, 0.09f, 0.09f), m);

        limbs      = new Transform[] { l1, l2, l3, l4, l5, l6 };
        limbPhases = new float[limbs.Length];
        limbSpeeds = new float[limbs.Length];
        for (int i = 0; i < limbs.Length; i++)
        {
            limbPhases[i] = Random.Range(0f, Mathf.PI * 2f);
            limbSpeeds[i] = Random.Range(3f, 9f);
        }
    }

    Transform Part(string n, Vector3 lp, Vector3 s, Material m)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = n;
        go.transform.SetParent(transform);
        go.transform.localPosition = lp;
        go.transform.localScale    = s;
        go.GetComponent<MeshRenderer>().material = m;
        Object.Destroy(go.GetComponent<SphereCollider>());
        return go.transform;
    }

    // ── Distortion Audio (PCM) ────────────────────────────────────
    void BuildDistortionAudio()
    {
        int   sr  = 44100;
        float dur = 2.2f;
        int   n   = Mathf.RoundToInt(sr * dur);
        float[] d = new float[n];

        float f1 = Random.Range(55f, 130f);
        float f2 = Random.Range(180f, 350f);
        float f3 = Random.Range(900f, 1400f);   // high scratchy component

        for (int i = 0; i < n; i++)
        {
            float t   = i / (float)sr;
            float env = Mathf.Exp(-t * 1.1f) * Mathf.Sin(Mathf.PI * t / dur);

            float s1  = Mathf.Sin(2f * Mathf.PI * f1 * t);
            s1 = Mathf.Sign(s1) * Mathf.Pow(Mathf.Abs(s1), 0.28f);   // hard distort

            float s2  = Mathf.Sin(2f * Mathf.PI * f2 * t * (1f + 0.3f * Mathf.Sin(t * 2.5f)));
            float s3  = Mathf.Sin(2f * Mathf.PI * f3 * t) * 0.12f;
            float nz  = (Random.value * 2f - 1f) * 0.18f;

            d[i] = (s1 * 0.45f + s2 * 0.28f + s3 + nz) * env * 0.55f;
        }

        AudioClip clip = AudioClip.Create("EnemyDistortion", n, 1, sr, false);
        clip.SetData(d, 0);

        distSrc              = gameObject.AddComponent<AudioSource>();
        distSrc.clip         = clip;
        distSrc.volume       = 0.32f;
        distSrc.spatialBlend = 1f;
        distSrc.maxDistance  = 18f;
        distSrc.rolloffMode  = AudioRolloffMode.Linear;
        distSrc.playOnAwake  = false;
        distSrc.loop         = false;
    }

    // ══════════════════════════════════════════════════════════════
    //  UPDATE
    // ══════════════════════════════════════════════════════════════
    void Update()
    {
        if (player == null) { player = FindObjectOfType<PlayerController>(); return; }

        float dist         = Vector3.Distance(transform.position, player.transform.position);
        bool  shouldChase  = player.IsGlowing && dist < DetectRange;

        // Audio: play periodically when close and player glowing
        audioCooldown -= Time.deltaTime;
        if (shouldChase && audioCooldown <= 0f)
        {
            distSrc.pitch    = Random.Range(0.75f, 1.25f);
            distSrc.Play();
            audioCooldown = audioInterval;
            audioInterval = Random.Range(1.5f, 3.8f);
        }

        if (shouldChase)
            Chase();
        else
            IdleJitter();

        AnimateLimbs(shouldChase);

        // Attack
        if (dist < AttackRadius)
            player.TakeDamage(DamagePerSec * Time.deltaTime);
    }

    // ── Chase AI ──────────────────────────────────────────────────
    void Chase()
    {
        Vector3 raw = player.transform.position - transform.position;
        raw.y = 0f;

        // Simple wall probe: cast forward; if blocked try 45° turns
        Vector3 dir = raw.normalized;
        Vector3 testOrigin = transform.position + Vector3.up * 0.8f;

        if (Physics.Raycast(testOrigin, dir, 1.6f))
        {
            // Try right then left
            Vector3 right = Quaternion.Euler(0, 45, 0) * dir;
            Vector3 left  = Quaternion.Euler(0,-45, 0) * dir;
            if (!Physics.Raycast(testOrigin, right, 1.6f)) dir = right;
            else if (!Physics.Raycast(testOrigin, left,  1.6f)) dir = left;
        }

        cc.Move(dir * ChaseSpeed * Time.deltaTime);
        if (dir.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.Slerp(transform.rotation,
                Quaternion.LookRotation(dir), 7f * Time.deltaTime);
    }

    // ── Idle Jitter ───────────────────────────────────────────────
    void IdleJitter()
    {
        jitterT += Time.deltaTime * 9f;
        Vector3 jitter = new Vector3(
            Mathf.Sin(jitterT * 1.4f),
            Mathf.Sin(jitterT * 2.7f) * 0.3f,
            Mathf.Cos(jitterT * 1.9f)) * 0.05f;
        cc.Move(jitter * Time.deltaTime);
    }

    // ── Limb Animation ────────────────────────────────────────────
    void AnimateLimbs(bool chasing)
    {
        float speedMult = chasing ? 3f : 1f;
        float ampMult   = chasing ? 2.5f : 1f;

        for (int i = 0; i < limbs.Length; i++)
        {
            if (!limbs[i]) continue;
            limbPhases[i] += Time.deltaTime * limbSpeeds[i] * speedMult;
            float angle = Mathf.Sin(limbPhases[i]) * 28f * ampMult;
            // Each limb on a different rotation axis for alien weirdness
            Vector3 e = Vector3.zero;
            e[i % 3] = angle;
            limbs[i].localEulerAngles = e;
        }
    }
}
