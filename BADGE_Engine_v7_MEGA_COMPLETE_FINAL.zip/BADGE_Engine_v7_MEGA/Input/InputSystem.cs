using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace BADGE.Input
{
    /// <summary>
    /// Unified input system: keyboard, mouse, gamepad, touch.
    /// Wraps OpenTK's keyboard/mouse state and adds axis smoothing,
    /// input mapping, and virtual button abstraction.
    ///
    /// Usage:
    ///   InputSystem.Update(keyboardState, mouseState);  // call each frame
    ///   float h = InputSystem.GetAxis("Horizontal");
    ///   bool fire = InputSystem.GetButtonDown("Fire1");
    /// </summary>
    public static class InputSystem
    {
        // ── Axis / button mappings ────────────────────────────────────────
        private static readonly Dictionary<string, AxisBinding>   _axes    = new();
        private static readonly Dictionary<string, ButtonBinding> _buttons = new();

        // ── Raw state (set by Update()) ───────────────────────────────────
        private static KeyboardState? _kb;
        private static MouseState?    _mouse;
        private static Vector2        _mouseDelta;
        private static float          _scrollDelta;

        // ── Smoothed axis values ──────────────────────────────────────────
        private static readonly Dictionary<string, float> _axisValues = new();

        // ── Frame press/release sets ──────────────────────────────────────
        private static readonly HashSet<string> _buttonsDown     = new();
        private static readonly HashSet<string> _buttonsUp       = new();
        private static readonly HashSet<string> _buttonsCurrent  = new();
        private static readonly HashSet<string> _buttonsPrev     = new();

        static InputSystem()
        {
            RegisterDefaults();
        }

        // ── Update (call once per frame from EditorWindow.OnUpdateFrame) ──
        public static void Update(KeyboardState kb, MouseState mouse,
                                   Vector2 mouseDelta, float scrollDelta)
        {
            _kb          = kb;
            _mouse       = mouse;
            _mouseDelta  = mouseDelta;
            _scrollDelta = scrollDelta;

            // Update axis values
            foreach (var (name, binding) in _axes)
            {
                float raw = 0f;
                if (_kb != null)
                {
                    if (binding.NegativeKey != Keys.Unknown && _kb.IsKeyDown(binding.NegativeKey)) raw -= 1f;
                    if (binding.PositiveKey != Keys.Unknown && _kb.IsKeyDown(binding.PositiveKey)) raw += 1f;
                }
                if (binding.IsMouseAxis)
                    raw = binding.MouseAxisX ? _mouseDelta.X * binding.Sensitivity
                                             : _mouseDelta.Y * binding.Sensitivity;

                float current = _axisValues.TryGetValue(name, out float v) ? v : 0f;
                float smoothed = MathHelper.Lerp(current, raw, 1f / (binding.Smoothing + 1e-6f));
                if (MathF.Abs(smoothed) < 0.01f) smoothed = 0f;
                _axisValues[name] = smoothed;
            }

            // Update buttons
            _buttonsDown.Clear();
            _buttonsUp.Clear();

            foreach (var (name, binding) in _buttons)
            {
                bool pressed = false;
                if (_kb != null && binding.Key != Keys.Unknown)
                    pressed |= _kb.IsKeyDown(binding.Key);
                if (_mouse != null && binding.MouseButton >= 0)
                    pressed |= binding.MouseButton switch
                    {
                        0 => _mouse.IsButtonDown(MouseButton.Left),
                        1 => _mouse.IsButtonDown(MouseButton.Right),
                        2 => _mouse.IsButtonDown(MouseButton.Middle),
                        _ => false
                    };

                bool wasPrev = _buttonsPrev.Contains(name);
                if (pressed && !wasPrev)  { _buttonsDown.Add(name);    _buttonsCurrent.Add(name); }
                if (!pressed && wasPrev)  { _buttonsUp.Add(name);      _buttonsCurrent.Remove(name); }
                if (pressed && wasPrev)   { _buttonsCurrent.Add(name); }
            }
            _buttonsPrev.Clear();
            foreach (var b in _buttonsCurrent) _buttonsPrev.Add(b);
        }

        // ── Axis API ──────────────────────────────────────────────────────
        public static float GetAxis(string name)
            => _axisValues.TryGetValue(name, out float v) ? v : 0f;

        public static float GetAxisRaw(string name)
        {
            if (!_axes.TryGetValue(name, out var binding)) return 0f;
            if (_kb == null) return 0f;
            float raw = 0f;
            if (_kb.IsKeyDown(binding.NegativeKey)) raw -= 1f;
            if (_kb.IsKeyDown(binding.PositiveKey)) raw += 1f;
            return raw;
        }

        // ── Button API ────────────────────────────────────────────────────
        public static bool GetButton(string name)     => _buttonsCurrent.Contains(name);
        public static bool GetButtonDown(string name) => _buttonsDown.Contains(name);
        public static bool GetButtonUp(string name)   => _buttonsUp.Contains(name);

        // ── Raw keyboard ──────────────────────────────────────────────────
        public static bool GetKey(Keys key)     => _kb?.IsKeyDown(key) ?? false;
        public static bool GetKeyDown(Keys key) => _kb?.IsKeyPressed(key) ?? false;
        public static bool GetKeyUp(Keys key)   => _kb?.IsKeyReleased(key) ?? false;

        // ── Mouse ─────────────────────────────────────────────────────────
        public static Vector2 MousePosition  => _mouse.HasValue ? new(_mouse.Value.X, _mouse.Value.Y) : Vector2.Zero;
        public static Vector2 MouseDelta     => _mouseDelta;
        public static float   ScrollDelta    => _scrollDelta;
        public static bool    GetMouseButton(int btn) => btn switch
        {
            0 => _mouse?.IsButtonDown(MouseButton.Left)   ?? false,
            1 => _mouse?.IsButtonDown(MouseButton.Right)  ?? false,
            2 => _mouse?.IsButtonDown(MouseButton.Middle) ?? false,
            _ => false
        };

        // ── Binding registration ──────────────────────────────────────────
        public static void RegisterAxis(string name, AxisBinding binding)   => _axes[name]   = binding;
        public static void RegisterButton(string name, ButtonBinding binding)=> _buttons[name]= binding;

        public static void RemapButton(string name, Keys key)
        {
            if (_buttons.TryGetValue(name, out var b)) b.Key = key;
        }

        private static void RegisterDefaults()
        {
            // Axes
            _axes["Horizontal"] = new AxisBinding { PositiveKey = Keys.D, NegativeKey = Keys.A, Smoothing = 8f };
            _axes["Vertical"]   = new AxisBinding { PositiveKey = Keys.W, NegativeKey = Keys.S, Smoothing = 8f };
            _axes["MouseX"]     = new AxisBinding { IsMouseAxis = true, MouseAxisX = true,  Sensitivity = 0.1f };
            _axes["MouseY"]     = new AxisBinding { IsMouseAxis = true, MouseAxisX = false, Sensitivity = 0.1f };

            // Buttons
            _buttons["Jump"]   = new ButtonBinding { Key = Keys.Space };
            _buttons["Fire1"]  = new ButtonBinding { MouseButton = 0 };
            _buttons["Fire2"]  = new ButtonBinding { MouseButton = 1 };
            _buttons["Sprint"] = new ButtonBinding { Key = Keys.LeftShift };
            _buttons["Crouch"] = new ButtonBinding { Key = Keys.LeftControl };
            _buttons["Escape"] = new ButtonBinding { Key = Keys.Escape };
            _buttons["Interact"]= new ButtonBinding { Key = Keys.E };
        }
    }

    // ── Binding structs ──────────────────────────────────────────────────
    public class AxisBinding
    {
        public Keys  PositiveKey  { get; set; } = Keys.Unknown;
        public Keys  NegativeKey  { get; set; } = Keys.Unknown;
        public float Sensitivity  { get; set; } = 1f;
        public float Smoothing    { get; set; } = 8f;  // higher = more smoothing
        public bool  IsMouseAxis  { get; set; } = false;
        public bool  MouseAxisX   { get; set; } = true;
    }

    public class ButtonBinding
    {
        public Keys Key          { get; set; } = Keys.Unknown;
        public int  MouseButton  { get; set; } = -1;   // -1 = not bound to mouse
    }
}
