using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Input.Mobile;

// ═══════════════════════════════════════════════════════════════════════
//  TOUCH INPUT  (multi-touch, gestures, swipe detection)
//  Subway Surfers: swipe left/right/up/down
//  Zumba: tap on beat, swipe patterns
// ═══════════════════════════════════════════════════════════════════════
public static class TouchInput
{
    public const int MAX_TOUCHES = 10;

    private static readonly TouchPoint[] _points   = new TouchPoint[MAX_TOUCHES];
    private static int                   _count     = 0;
    public  static int                   TouchCount => _count;

    public static TouchPoint GetTouch(int index) => index < _count ? _points[index] : default;

    // ── Engine feed ───────────────────────────────────────────────
    public static void BeginFrame()
    {
        for (int i = 0; i < _count; i++)
        {
            _points[i].DeltaPosition = Vector2.Zero;
            if (_points[i].Phase == TouchPhase.Began)   _points[i].Phase = TouchPhase.Stationary;
            if (_points[i].Phase == TouchPhase.Ended)  { ShiftLeft(i); _count--; i--; }
            if (_points[i].Phase == TouchPhase.Cancelled) { ShiftLeft(i); _count--; i--; }
        }
    }

    public static void RegisterTouch(int fingerId, TouchPhase phase, Vector2 position)
    {
        for (int i = 0; i < _count; i++)
        {
            if (_points[i].FingerId == fingerId)
            {
                _points[i].DeltaPosition = position - _points[i].Position;
                _points[i].Position      = position;
                _points[i].Phase         = phase;
                return;
            }
        }
        if (_count < MAX_TOUCHES && phase == TouchPhase.Began)
        {
            _points[_count++] = new TouchPoint
            {
                FingerId        = fingerId,
                Position        = position,
                StartPosition   = position,
                DeltaPosition   = Vector2.Zero,
                Phase           = TouchPhase.Began,
                Time            = 0f
            };
        }
    }

    private static void ShiftLeft(int from)
    {
        for (int i = from; i < _count - 1; i++) _points[i] = _points[i + 1];
    }

    // ── Gesture detection ─────────────────────────────────────────
    public static SwipeResult DetectSwipe(int touchIndex, float minDist = 50f)
    {
        if (touchIndex >= _count) return new SwipeResult(SwipeDirection.None, 0f);
        var t = _points[touchIndex];
        if (t.Phase != TouchPhase.Ended) return new SwipeResult(SwipeDirection.None, 0f);

        var delta = t.Position - t.StartPosition;
        float dist = delta.Length;
        if (dist < minDist) return new SwipeResult(SwipeDirection.None, dist);

        bool horiz = MathF.Abs(delta.X) > MathF.Abs(delta.Y);
        SwipeDirection dir;
        if (horiz) dir = delta.X > 0 ? SwipeDirection.Right : SwipeDirection.Left;
        else       dir = delta.Y > 0 ? SwipeDirection.Down  : SwipeDirection.Up;
        return new SwipeResult(dir, dist);
    }

    public static bool IsTap(int touchIndex, float maxDist = 20f, float maxTime = 0.3f)
    {
        if (touchIndex >= _count) return false;
        var t = _points[touchIndex];
        return t.Phase == TouchPhase.Ended
            && (t.Position - t.StartPosition).Length < maxDist
            && t.Time < maxTime;
    }

    public static float PinchDelta()
    {
        if (_count < 2) return 0f;
        float cur  = (_points[0].Position - _points[1].Position).Length;
        float prev = (((_points[0].Position - _points[0].DeltaPosition)
                      - (_points[1].Position - _points[1].DeltaPosition))).Length;
        return cur - prev;
    }
}

public struct TouchPoint
{
    public int         FingerId;
    public Vector2     Position;
    public Vector2     StartPosition;
    public Vector2     DeltaPosition;
    public TouchPhase  Phase;
    public float       Time;
    public float       Pressure;    // 0-1
}

public enum TouchPhase    { Began, Stationary, Moved, Ended, Cancelled }
public enum SwipeDirection { None, Left, Right, Up, Down }
public record SwipeResult(SwipeDirection Direction, float Distance)
{
    public bool IsSwipe => Direction != SwipeDirection.None;
}

// ═══════════════════════════════════════════════════════════════════════
//  VIRTUAL JOYSTICK  (on-screen thumbstick for mobile games)
// ═══════════════════════════════════════════════════════════════════════
public class VirtualJoystick
{
    public Vector2 Center     { get; set; }   // screen position
    public float   Radius     { get; set; } = 80f;
    public float   DeadZone   { get; set; } = 0.1f;

    public Vector2 Value      { get; private set; }  // -1..1 normalized
    public bool    IsActive   { get; private set; }

    private int  _touchId   = -1;
    private bool _floating;    // joystick follows initial touch

    public VirtualJoystick(Vector2 center, bool floating = false)
    { Center = center; _floating = floating; }

    public void Update()
    {
        Value    = Vector2.Zero;
        IsActive = false;

        for (int i = 0; i < TouchInput.TouchCount; i++)
        {
            var t = TouchInput.GetTouch(i);

            if (t.Phase == TouchPhase.Began && _touchId < 0)
            {
                if (!_floating && (t.Position - Center).Length > Radius * 1.5f) continue;
                _touchId  = t.FingerId;
                if (_floating) Center = t.Position;
            }

            if (t.FingerId != _touchId) continue;

            if (t.Phase == TouchPhase.Ended || t.Phase == TouchPhase.Cancelled)
            { _touchId = -1; Value = Vector2.Zero; return; }

            var delta = t.Position - Center;
            float dist = delta.Length;
            if (dist > Radius) delta = delta.Normalized() * Radius;

            var raw = delta / Radius;
            float mag = raw.Length;
            if (mag < DeadZone) raw = Vector2.Zero;
            else raw = raw.Normalized() * ((mag - DeadZone) / (1f - DeadZone));

            Value    = raw;
            IsActive = true;
        }
    }

    public float   Horizontal => Value.X;
    public float   Vertical   => Value.Y;
    public Vector3 AsVector3XZ => new Vector3(Value.X, 0f, Value.Y);
}

// ═══════════════════════════════════════════════════════════════════════
//  VIRTUAL BUTTON  (on-screen tap button)
// ═══════════════════════════════════════════════════════════════════════
public class VirtualButton
{
    public Vector2 Center   { get; set; }
    public float   Radius   { get; set; } = 50f;
    public bool    IsDown   { get; private set; }
    public bool    WasPressed { get; private set; }

    private bool _prevDown = false;

    public VirtualButton(Vector2 center, float radius = 50f) { Center = center; Radius = radius; }

    public void Update()
    {
        _prevDown = IsDown;
        IsDown    = false;
        for (int i = 0; i < TouchInput.TouchCount; i++)
        {
            var t = TouchInput.GetTouch(i);
            if (t.Phase == TouchPhase.Ended || t.Phase == TouchPhase.Cancelled) continue;
            if ((t.Position - Center).Length <= Radius) { IsDown = true; break; }
        }
        WasPressed = IsDown && !_prevDown;
    }
}
