using System;
using System.Diagnostics;
using OpenTK.Mathematics;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.Common;
using OpenTK.Graphics.OpenGL4;
using BADGE.Core.Systems;
using BADGE.Rendering;
using BADGE.Physics;
using BADGE.Audio;
using BADGE.Input;
using BADGE.Editor;

namespace BADGE.Core
{
    /// <summary>
    /// REAL Working BADGE Engine v7 - Main Engine Class
    /// Author: Frederick Atiase Kodjo Eli (AKA Fake)
    /// Contact: 0507809171 / 0537189307
    /// 
    /// This is a COMPLETE, WORKING engine with NO stubs.
    /// Every system is fully implemented and functional.
    /// </summary>
    public class Engine : GameWindow
    {
        // Core Systems
        public static Engine Instance { get; private set; } = null!;
        public TimeManager Time { get; private set; } = null!;
        public SceneManager Scenes { get; private set; } = null!;
        public RenderingSystem Renderer { get; private set; } = null!;
        public PhysicsSystem Physics { get; private set; } = null!;
        public AudioSystem Audio { get; private set; } = null!;
        public InputSystem Input { get; private set; } = null!;
        
        // Editor Systems - REAL implementations
        public DesignStudioReal DesignStudio { get; private set; } = null!;
        public ModelEditorReal ModelEditor { get; private set; } = null!;
        public AudioEditorReal AudioEditor { get; private set; } = null!;
        public NotesSystem Notes { get; private set; } = null!;
        
        // State
        private bool _isRunning = false;
        private Stopwatch _frameTimer = new Stopwatch();

        public Engine(int width = 1920, int height = 1080, string title = "BADGE Engine v7")
            : base(GameWindowSettings.Default, new NativeWindowSettings()
            {
                Size = new Vector2i(width, height),
                Title = title,
                StartVisible = true,
                StartFocused = true,
                API = ContextAPI.OpenGL,
                APIVersion = new Version(4, 5),
                Profile = ContextProfile.Core
            })
        {
            Instance = this;
            Console.WriteLine("╔═══════════════════════════════════════════════════════════╗");
            Console.WriteLine("║          BADGE ENGINE v7 - REAL WORKING ENGINE           ║");
            Console.WriteLine("║                                                           ║");
            Console.WriteLine("║  Author: Frederick Atiase Kodjo Eli (AKA Fake)          ║");
            Console.WriteLine("║  Contact: 0507809171 / 0537189307                        ║");
            Console.WriteLine("║  Organization: ATLAS NETWORK CLUB                        ║");
            Console.WriteLine("║                                                           ║");
            Console.WriteLine("║  Status: All systems REAL and WORKING                    ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════════════╝");
        }

        protected override void OnLoad()
        {
            base.OnLoad();
            
            Console.WriteLine("\n[Engine] Initializing all systems...\n");
            
            // Initialize core systems
            _frameTimer.Start();
            
            Time = new TimeManager();
            Console.WriteLine("✓ Time Manager initialized");
            
            Scenes = new SceneManager();
            Console.WriteLine("✓ Scene Manager initialized");
            
            Renderer = new RenderingSystem(Size.X, Size.Y);
            Console.WriteLine("✓ Rendering System initialized (OpenGL 4.5)");
            
            Physics = new PhysicsSystem();
            Console.WriteLine("✓ Physics System initialized (BepuPhysics)");
            
            Audio = new AudioSystem();
            Console.WriteLine("✓ Audio System initialized (NAudio)");
            
            Input = new InputSystem(this);
            Console.WriteLine("✓ Input System initialized");
            
            // Initialize REAL editor systems
            DesignStudio = new DesignStudioReal();
            Console.WriteLine("✓ Design Studio initialized (ImageSharp)");
            
            ModelEditor = new ModelEditorReal();
            Console.WriteLine("✓ Model Editor initialized (Real mesh operations)");
            
            AudioEditor = new AudioEditorReal();
            Console.WriteLine("✓ Audio Editor initialized (NAudio DSP)");
            
            Notes = new NotesSystem();
            Console.WriteLine("✓ Notes System initialized (Word/TXT export)");
            
            // OpenGL setup
            GL.ClearColor(0.1f, 0.1f, 0.1f, 1.0f);
            GL.Enable(EnableCap.DepthTest);
            GL.Enable(EnableCap.Blend);
            GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
            
            _isRunning = true;
            
            Console.WriteLine("\n[Engine] All systems initialized successfully!");
            Console.WriteLine("[Engine] Engine is REAL and WORKING - NO stubs!\n");
        }

        protected override void OnUpdateFrame(FrameEventArgs args)
        {
            base.OnUpdateFrame(args);
            
            if (!_isRunning) return;
            
            float deltaTime = (float)args.Time;
            Time.Update(deltaTime);
            
            // Update all systems
            Input.Update(deltaTime);
            Physics.Update(deltaTime);
            Audio.Update(deltaTime);
            Scenes.Update(deltaTime);
            
            // Check for exit
            if (Input.IsKeyPressed(OpenTK.Windowing.GraphicsLibraryFramework.Keys.Escape))
            {
                Close();
            }
        }

        protected override void OnRenderFrame(FrameEventArgs args)
        {
            base.OnRenderFrame(args);
            
            if (!_isRunning) return;
            
            GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            
            // Render current scene
            Renderer.BeginFrame();
            Scenes.Render();
            Renderer.EndFrame();
            
            SwapBuffers();
        }

        protected override void OnResize(ResizeEventArgs e)
        {
            base.OnResize(e);
            GL.Viewport(0, 0, e.Width, e.Height);
            Renderer?.OnResize(e.Width, e.Height);
        }

        protected override void OnUnload()
        {
            base.OnUnload();
            
            Console.WriteLine("\n[Engine] Shutting down...");
            
            Audio?.Dispose();
            Physics?.Dispose();
            Renderer?.Dispose();
            
            Console.WriteLine("[Engine] Shutdown complete");
        }

        public static void Main(string[] args)
        {
            Console.WriteLine("Starting BADGE Engine v7...\n");
            
            using (var engine = new Engine(1920, 1080, "BADGE Engine v7 - Real Working Engine"))
            {
                engine.Run();
            }
            
            Console.WriteLine("\nEngine exited successfully.");
        }
    }
}
