// Core/EventBusSaveSystems.cs
// EventBus and SaveSystem live in Core/GameSystems/EventBus.cs and Core/GameSystems/SaveSystem.cs.
// This file is kept for source-compatibility but contains no new type definitions.
