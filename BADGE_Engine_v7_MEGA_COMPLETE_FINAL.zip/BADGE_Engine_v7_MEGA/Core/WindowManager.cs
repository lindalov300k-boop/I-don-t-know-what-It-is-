using System;

namespace BADGE.Core
{
    /// <summary>
    /// Manages the application window and display settings
    /// </summary>
    public class WindowManager
    {
        public int Width { get; private set; }
        public int Height { get; private set; }
        public string Title { get; private set; }
        public bool IsFullscreen { get; private set; }
        
        // Resolution port settings
        public ResolutionMode Mode { get; set; }
        public bool PixelPerfect { get; set; }
        
        public WindowManager()
        {
            Width = 1280;
            Height = 720;
            Title = "BADGE - Basic Atlas Dimensional Game Engine";
            IsFullscreen = false;
            Mode = ResolutionMode.Windowed;
            PixelPerfect = false;
            
            InitializeWindow();
        }

        private void InitializeWindow()
        {
            Console.WriteLine($"  - Window: {Width}x{Height} ({Mode})");
            // Window creation would integrate with OpenGL/SDL2 here
        }

        public void SetResolution(int width, int height, bool fullscreen = false)
        {
            Width = width;
            Height = height;
            IsFullscreen = fullscreen;
            
            Console.WriteLine($"Resolution changed to: {Width}x{Height}");
        }

        public void SetRetroResolution(int pixelWidth, int pixelHeight)
        {
            // Retro pixel scaling
            Width = pixelWidth;
            Height = pixelHeight;
            PixelPerfect = true;
            
            Console.WriteLine($"Retro mode: {pixelWidth}x{pixelHeight} (Pixel Perfect)");
        }

        public void Close()
        {
            Console.WriteLine("  - Window closed");
        }
    }

    public enum ResolutionMode
    {
        Windowed,
        Fullscreen,
        Borderless,
        RetroPixelPerfect
    }
}
