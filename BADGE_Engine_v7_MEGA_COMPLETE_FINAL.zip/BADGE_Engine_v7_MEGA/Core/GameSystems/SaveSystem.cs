using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace BADGE.Core.GameSystems;

/// <summary>
/// Slot-based save system with JSON persistence.
/// Supports versioned saves, auto-save, multiple slots, metadata previews.
/// Used by every game: Terraria (world+player), GTA (mission+wanted),
/// Subnautica (base+inventory), simulators (state+money), etc.
/// </summary>
public static class SaveSystem
{
    private static string _saveDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
        "BADGE", "Saves");

    private static readonly JsonSerializerOptions _opts = new JsonSerializerOptions
    {
        WriteIndented          = true,
        PropertyNameCaseInsensitive = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        NumberHandling         = JsonNumberHandling.AllowNamedFloatingPointLiterals
    };

    // ── Configuration ─────────────────────────────────────────────
    public static string GameName    { get; set; } = "BADGE_Game";
    public static int    MaxSlots    { get; set; } = 20;
    public static bool   AutoEncrypt { get; set; } = false;

    // ── Path helpers ──────────────────────────────────────────────
    private static string SlotDir(int slot)
    {
        var dir = Path.Combine(_saveDir, GameName, $"Slot_{slot:D2}");
        Directory.CreateDirectory(dir);
        return dir;
    }

    private static string DataPath(int slot, string key)
        => Path.Combine(SlotDir(slot), $"{SanitizeKey(key)}.save.json");

    private static string MetaPath(int slot)
        => Path.Combine(SlotDir(slot), "_meta.json");

    private static string SanitizeKey(string key) => string.Concat(key.Split(Path.GetInvalidFileNameChars()));

    // ── Save ──────────────────────────────────────────────────────
    /// <summary>Save any serializable object to a named key in a save slot.</summary>
    public static void Save<T>(int slot, string key, T data)
    {
        try
        {
            var json = JsonSerializer.Serialize(data, _opts);
            File.WriteAllText(DataPath(slot, key), json);
            UpdateMeta(slot, key);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[SaveSystem] Save failed: {ex.Message}");
        }
    }

    /// <summary>Save multiple keys atomically (all or nothing).</summary>
    public static void SaveBatch(int slot, Dictionary<string, object> batch)
    {
        var tmpPaths = new List<(string tmp, string final)>();
        try
        {
            foreach (var (key, value) in batch)
            {
                var final = DataPath(slot, key);
                var tmp   = final + ".tmp";
                File.WriteAllText(tmp, JsonSerializer.Serialize(value, _opts));
                tmpPaths.Add((tmp, final));
            }
            // Commit all
            foreach (var (tmp, final) in tmpPaths) File.Move(tmp, final, overwrite: true);
            UpdateMeta(slot, string.Join(",", batch.Keys));
        }
        catch
        {
            foreach (var (tmp, _) in tmpPaths)
                if (File.Exists(tmp)) File.Delete(tmp);
        }
    }

    // ── Load ──────────────────────────────────────────────────────
    /// <summary>Load a named key from a save slot. Returns default if missing.</summary>
    public static T? Load<T>(int slot, string key)
    {
        var path = DataPath(slot, key);
        if (!File.Exists(path)) return default;
        try { return JsonSerializer.Deserialize<T>(File.ReadAllText(path), _opts); }
        catch (Exception ex) { Console.WriteLine($"[SaveSystem] Load failed: {ex.Message}"); return default; }
    }

    public static bool Exists(int slot, string key) => File.Exists(DataPath(slot, key));
    public static bool SlotExists(int slot)         => Directory.Exists(SlotDir(slot));

    // ── Delete ────────────────────────────────────────────────────
    public static void Delete(int slot, string key)
    {
        var path = DataPath(slot, key);
        if (File.Exists(path)) File.Delete(path);
    }

    public static void DeleteSlot(int slot)
    {
        var dir = Path.Combine(_saveDir, GameName, $"Slot_{slot:D2}");
        if (Directory.Exists(dir)) Directory.Delete(dir, recursive: true);
    }

    // ── Metadata ──────────────────────────────────────────────────
    private static void UpdateMeta(int slot, string lastKey)
    {
        var meta = LoadMeta(slot) ?? new SaveMeta();
        meta.LastSaved  = DateTime.UtcNow.ToString("O");
        meta.SlotIndex  = slot;
        meta.LastKey    = lastKey;
        meta.SaveCount++;
        File.WriteAllText(MetaPath(slot), JsonSerializer.Serialize(meta, _opts));
    }

    public static SaveMeta? LoadMeta(int slot)
    {
        var path = MetaPath(slot);
        if (!File.Exists(path)) return null;
        try { return JsonSerializer.Deserialize<SaveMeta>(File.ReadAllText(path), _opts); }
        catch { return null; }
    }

    public static List<SaveMeta> GetAllSlots()
    {
        var slots = new List<SaveMeta>();
        for (int i = 0; i < MaxSlots; i++)
        {
            var meta = LoadMeta(i);
            if (meta != null) slots.Add(meta);
        }
        return slots;
    }

    // ── Auto-save ─────────────────────────────────────────────────
    private static float _autoSaveTimer = 0f;
    private static float _autoSaveInterval = 300f;  // 5 min default
    private static int   _autoSaveSlot = 0;
    private static Action? _autoSaveCallback;

    public static void ConfigureAutoSave(float intervalSeconds, int slot, Action saveCallback)
    {
        _autoSaveInterval  = intervalSeconds;
        _autoSaveSlot      = slot;
        _autoSaveCallback  = saveCallback;
        _autoSaveTimer     = 0f;
    }

    public static void TickAutoSave(float dt)
    {
        if (_autoSaveCallback == null) return;
        _autoSaveTimer += dt;
        if (_autoSaveTimer >= _autoSaveInterval)
        {
            _autoSaveTimer = 0f;
            _autoSaveCallback();
            Console.WriteLine($"[SaveSystem] Auto-saved to slot {_autoSaveSlot}");
        }
    }
}

public class SaveMeta
{
    public int    SlotIndex  { get; set; }
    public string LastSaved  { get; set; } = "";
    public string LastKey    { get; set; } = "";
    public int    SaveCount  { get; set; }
    public string GameName   { get; set; } = "";
    public string PlayerName { get; set; } = "";
    public string SceneName  { get; set; } = "";
    public float  PlayTime   { get; set; }  // seconds
    public string Thumbnail  { get; set; } = "";  // base64 or path
}
