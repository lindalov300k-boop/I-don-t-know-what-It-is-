// UIComponents.cs — Backward-compatibility re-export layer.
//
// REPLACES: The old UIComponents.cs which had Canvas, UIText, UIImage, UIButton
//           as near-empty stubs with no builder API.
//
// All real implementation is in Core/UI/UISystem.cs.
// This file re-exports the types so old code continues to compile.

using BADGE.Core.UI;

namespace BADGE.Core;

// RenderMode alias kept for legacy code
public enum RenderMode      { ScreenSpaceOverlay = 0, ScreenSpaceCamera = 1, WorldSpace = 2 }
public enum TextAlignment   { Left, Center, Right }
