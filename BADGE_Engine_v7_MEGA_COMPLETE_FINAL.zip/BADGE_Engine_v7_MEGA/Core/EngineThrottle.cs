using System;
using System.Diagnostics;
using System.Threading;

namespace BADGE.Core
{
    /// <summary>
    /// EngineThrottle — the single authority over how fast the engine runs.
    ///
    /// Replaces the scattered _isIdle booleans that existed in AudioMixer,
    /// ScriptGenerator, FreeAIService, MeshFilterStack etc.
    ///
    /// ┌──────────────────────────────────────────────────────────────┐
    /// │  Mode          │ Target FPS │ Physics │ AI  │ Audio         │
    /// ├──────────────────────────────────────────────────────────────┤
    /// │  Active        │    60      │  full   │ on  │ full          │
    /// │  Unfocused     │    15      │  off    │ off │ reduced       │
    /// │  Idle (30 s)   │     5      │  off    │ off │ off           │
    /// │  Background    │     1      │  off    │ off │ off           │
    /// └──────────────────────────────────────────────────────────────┘
    ///
    /// The engine loop calls <see cref="BeginFrame"/> at the TOP and
    /// <see cref="EndFrame"/> at the BOTTOM of every iteration.
    /// EndFrame blocks (Thread.Sleep) for the remainder of the frame budget,
    /// keeping CPU near 0% when idle.
    /// </summary>
    public sealed class EngineThrottle
    {
        // ── Singleton ─────────────────────────────────────────────────────
        private static readonly Lazy<EngineThrottle> _lazy =
            new(() => new EngineThrottle());
        public static EngineThrottle Instance => _lazy.Value;

        // ── Mode ──────────────────────────────────────────────────────────
        public enum ThrottleMode
        {
            Active      = 0,   // window focused, user is interacting
            Unfocused   = 1,   // window visible but not focused
            Idle        = 2,   // focused but no activity for IdleTimeoutSeconds
            Background  = 3,   // window minimised or hidden
        }

        public ThrottleMode Mode { get; private set; } = ThrottleMode.Active;

        // ── Configuration ─────────────────────────────────────────────────
        public int  ActiveFPS        { get; set; } = 60;
        public int  UnfocusedFPS     { get; set; } = 15;
        public int  IdleFPS          { get; set; } = 5;
        public int  BackgroundFPS    { get; set; } = 1;
        public float IdleTimeoutSecs { get; set; } = 30f;

        // ── State ─────────────────────────────────────────────────────────
        private readonly Stopwatch _frameWatch  = new();
        private readonly Stopwatch _idleWatch   = new();
        private bool  _hasFocus    = true;
        private bool  _minimised   = false;

        // ── Derived capabilities (read by Engine subsystems) ──────────────
        public bool PhysicsActive  => Mode == ThrottleMode.Active;
        public bool AIActive       => Mode == ThrottleMode.Active;
        public bool AudioActive    => Mode <= ThrottleMode.Unfocused;
        public bool RenderingActive => Mode <= ThrottleMode.Idle;
        public bool IsIdle         => Mode >= ThrottleMode.Idle;

        // ── Current metrics ───────────────────────────────────────────────
        public float TargetFPS   => ModeToFPS(Mode);
        public float ActualFPS   { get; private set; }
        public float ActualDelta { get; private set; }

        // ── Private ───────────────────────────────────────────────────────
        private EngineThrottle()
        {
            _frameWatch.Start();
            _idleWatch.Start();
        }

        // ── API called by the window / OS event hooks ─────────────────────

        /// <summary>Call when the OS reports window focus gained.</summary>
        public void NotifyFocusGained()
        {
            _hasFocus = true;
            NotifyActivity();
        }

        /// <summary>Call when the OS reports window focus lost.</summary>
        public void NotifyFocusLost()  => _hasFocus = false;

        /// <summary>Call when the window is minimised/hidden.</summary>
        public void NotifyMinimised()  => _minimised = true;

        /// <summary>Call when the window is restored.</summary>
        public void NotifyRestored()   { _minimised = false; NotifyActivity(); }

        /// <summary>
        /// Call whenever meaningful user activity occurs:
        /// mouse move, key press, scene edit, asset change, etc.
        /// Resets the idle timeout.
        /// </summary>
        public void NotifyActivity()   => _idleWatch.Restart();

        // ── Frame lifecycle ───────────────────────────────────────────────

        /// <summary>Call at the very start of the engine loop iteration.</summary>
        public void BeginFrame() => _frameWatch.Restart();

        /// <summary>
        /// Call at the very end of the engine loop iteration.
        /// Sleeps the thread for the remaining frame budget, then updates Mode.
        /// Returns the actual delta time for this frame.
        /// </summary>
        public float EndFrame()
        {
            _frameWatch.Stop();
            double elapsed = _frameWatch.Elapsed.TotalSeconds;

            // Recalculate mode BEFORE deciding sleep duration
            UpdateMode();

            double budget = 1.0 / TargetFPS;
            double remaining = budget - elapsed;

            if (remaining > 0.001)   // > 1 ms — worth sleeping
            {
                // Use high-precision sleep: Sleep(N-1ms) + spin for the last ms
                int sleepMs = (int)((remaining - 0.001) * 1000);
                if (sleepMs > 0) Thread.Sleep(sleepMs);

                // Spin-wait for the final fraction
                var spin = Stopwatch.StartNew();
                while (spin.Elapsed.TotalSeconds < remaining - elapsed) { /* spin */ }
            }

            // Measure true elapsed including sleep
            double total = _frameWatch.Elapsed.TotalSeconds;
            ActualDelta = (float)(total > 0 ? total : budget);
            ActualFPS   = ActualDelta > 0 ? 1f / ActualDelta : TargetFPS;

            return ActualDelta;
        }

        // ── Mode calculation ──────────────────────────────────────────────
        private void UpdateMode()
        {
            if (_minimised)
            {
                Mode = ThrottleMode.Background;
                return;
            }

            if (!_hasFocus)
            {
                Mode = ThrottleMode.Unfocused;
                return;
            }

            bool timedOut = _idleWatch.Elapsed.TotalSeconds > IdleTimeoutSecs;
            Mode = timedOut ? ThrottleMode.Idle : ThrottleMode.Active;
        }

        private float ModeToFPS(ThrottleMode m) => m switch
        {
            ThrottleMode.Active     => ActiveFPS,
            ThrottleMode.Unfocused  => UnfocusedFPS,
            ThrottleMode.Idle       => IdleFPS,
            ThrottleMode.Background => BackgroundFPS,
            _                       => IdleFPS
        };

        // ── Summary for diagnostics ───────────────────────────────────────
        public override string ToString()
            => $"[Throttle] Mode={Mode} Target={TargetFPS}fps " +
               $"Actual={ActualFPS:F1}fps Physics={PhysicsActive} AI={AIActive}";
    }
}
