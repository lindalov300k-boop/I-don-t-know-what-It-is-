using System.Collections.Generic;
using OpenTK.Windowing.GraphicsLibraryFramework;
using OpenTK.Mathematics;

namespace BADGE.Core;

/// <summary>
/// Static input polling class — Unity-API-compatible.
/// Feed raw OpenTK events into ProcessKeyDown/Up/Mouse each frame
/// from the WindowManager or GameWindow.
///
/// REPLACES: InputManager.cs (which used a disconnected custom KeyCode enum).
/// NOW: Uses OpenTK.Windowing.GraphicsLibraryFramework.Keys directly.
/// </summary>
public static class Input
{
    // ── Per-frame key state ───────────────────────────────────────
    private static readonly HashSet<Keys> _held      = new();
    private static readonly HashSet<Keys> _pressed   = new();  // down this frame
    private static readonly HashSet<Keys> _released  = new();  // up   this frame

    // ── Mouse ─────────────────────────────────────────────────────
    private static Vector2 _mousePos     = Vector2.Zero;
    private static Vector2 _mouseDelta   = Vector2.Zero;
    private static Vector2 _lastMousePos = Vector2.Zero;
    private static float   _scrollDelta  = 0f;

    private static readonly HashSet<MouseButton> _mouseHeld     = new();
    private static readonly HashSet<MouseButton> _mousePressed  = new();
    private static readonly HashSet<MouseButton> _mouseReleased = new();

    // ── Cursor state ──────────────────────────────────────────────
    public static bool CursorLocked { get; private set; }
    public static bool CursorVisible { get; set; } = true;

    // ── Engine feeds these ────────────────────────────────────────
    /// <summary>Call at start of each frame to clear frame-specific state.</summary>
    public static void BeginFrame()
    {
        _pressed.Clear();
        _released.Clear();
        _mousePressed.Clear();
        _mouseReleased.Clear();
        _mouseDelta   = Vector2.Zero;
        _scrollDelta  = 0f;
    }

    public static void ProcessKeyDown(Keys key)
    {
        if (!_held.Contains(key)) _pressed.Add(key);
        _held.Add(key);
    }

    public static void ProcessKeyUp(Keys key)
    {
        _held.Remove(key);
        _released.Add(key);
    }

    public static void ProcessMouseMove(Vector2 pos)
    {
        _mouseDelta   = pos - _lastMousePos;
        _mousePos     = pos;
        _lastMousePos = pos;
    }

    public static void ProcessMouseButton(MouseButton btn, bool down)
    {
        if (down)
        {
            if (!_mouseHeld.Contains(btn)) _mousePressed.Add(btn);
            _mouseHeld.Add(btn);
        }
        else
        {
            _mouseHeld.Remove(btn);
            _mouseReleased.Add(btn);
        }
    }

    public static void ProcessScroll(float delta) => _scrollDelta += delta;

    public static void SetCursorLock(bool locked)
    {
        CursorLocked  = locked;
        CursorVisible = !locked;
    }

    // ── Keyboard API ──────────────────────────────────────────────
    /// <summary>True every frame the key is held down.</summary>
    public static bool GetKey(Keys key)     => _held.Contains(key);

    /// <summary>True only on the frame the key was first pressed.</summary>
    public static bool GetKeyDown(Keys key) => _pressed.Contains(key);

    /// <summary>True only on the frame the key was released.</summary>
    public static bool GetKeyUp(Keys key)   => _released.Contains(key);

    // ── Axis helpers (WASD / arrows → float) ─────────────────────
    /// <summary>Returns –1, 0, or +1 for horizontal axis (A/D or Left/Right).</summary>
    public static float GetAxisHorizontal()
    {
        float v = 0f;
        if (GetKey(Keys.A) || GetKey(Keys.Left))  v -= 1f;
        if (GetKey(Keys.D) || GetKey(Keys.Right)) v += 1f;
        return v;
    }

    /// <summary>Returns –1, 0, or +1 for vertical axis (S/W or Down/Up).</summary>
    public static float GetAxisVertical()
    {
        float v = 0f;
        if (GetKey(Keys.S) || GetKey(Keys.Down)) v -= 1f;
        if (GetKey(Keys.W) || GetKey(Keys.Up))   v += 1f;
        return v;
    }

    // ── Mouse API ─────────────────────────────────────────────────
    public static Vector2 MousePosition  => _mousePos;
    public static Vector2 MouseDelta     => _mouseDelta;
    public static float   MouseScrollDelta => _scrollDelta;

    public static bool GetMouseButton(MouseButton btn)        => _mouseHeld.Contains(btn);
    public static bool GetMouseButtonDown(MouseButton btn)    => _mousePressed.Contains(btn);
    public static bool GetMouseButtonUp(MouseButton btn)      => _mouseReleased.Contains(btn);

    // Convenience overloads for int (0 = left, 1 = right, 2 = middle)
    public static bool GetMouseButton(int btn)     => GetMouseButton(IntToMouseButton(btn));
    public static bool GetMouseButtonDown(int btn) => GetMouseButtonDown(IntToMouseButton(btn));
    public static bool GetMouseButtonUp(int btn)   => GetMouseButtonUp(IntToMouseButton(btn));

    private static MouseButton IntToMouseButton(int btn) => btn switch
    {
        0 => MouseButton.Left,
        1 => MouseButton.Right,
        2 => MouseButton.Middle,
        _ => MouseButton.Left
    };

    // ── Action binding system ─────────────────────────────────────
    private static readonly Dictionary<string, List<Keys>> _actions = new();

    public static void BindAction(string name, params Keys[] keys)
    {
        if (!_actions.ContainsKey(name)) _actions[name] = new();
        _actions[name].AddRange(keys);
    }

    public static bool GetAction(string name)
    {
        if (!_actions.TryGetValue(name, out var keys)) return false;
        foreach (var k in keys) if (GetKey(k)) return true;
        return false;
    }

    public static bool GetActionDown(string name)
    {
        if (!_actions.TryGetValue(name, out var keys)) return false;
        foreach (var k in keys) if (GetKeyDown(k)) return true;
        return false;
    }
}
