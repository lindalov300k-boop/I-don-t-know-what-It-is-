using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Diagnostics;
using System.Text;

namespace BADGE.BuildPipeline
{
    /// <summary>
    /// BADGE build pipeline.  Supported targets: Windows x64, Linux x64, WebGL (WASM).
    /// macOS, Android, iOS, and console exports have been removed.
    /// </summary>
    public class PlatformExporter
    {
        private readonly string      _projectPath;
        private readonly BuildSettings _settings;

        public PlatformExporter(string projectPath, BuildSettings? settings = null)
        {
            _projectPath = projectPath;
            _settings    = settings ?? new BuildSettings();
        }

        // ── Windows ───────────────────────────────────────────────────────
        /// <summary>Build a self-contained Windows x64 executable.</summary>
        public BuildResult ExportToWindows(string outputPath)
        {
            string buildPath = Path.Combine(outputPath, "Windows");
            Directory.CreateDirectory(buildPath);

            var result = RunDotnetPublish(buildPath, "win-x64");
            if (!result.Success) return result;

            CopyAssets(buildPath);

            if (_settings.CreateInstaller)
                CreateWindowsInstaller(buildPath);

            if (_settings.CreateZip)
                ZipBuild(buildPath, Path.Combine(outputPath, "BADGE_Win64.zip"));

            return BuildResult.Ok($"Windows build → {buildPath}");
        }

        // ── Linux ─────────────────────────────────────────────────────────
        /// <summary>Build a self-contained Linux x64 AppImage-ready binary.</summary>
        public BuildResult ExportToLinux(string outputPath)
        {
            string buildPath = Path.Combine(outputPath, "Linux");
            Directory.CreateDirectory(buildPath);

            var result = RunDotnetPublish(buildPath, "linux-x64");
            if (!result.Success) return result;

            CopyAssets(buildPath);
            SetExecutable(buildPath);

            if (_settings.CreateAppImage)
                CreateLinuxAppImage(buildPath);

            if (_settings.CreateZip)
                ZipBuild(buildPath, Path.Combine(outputPath, "BADGE_Linux64.zip"));

            return BuildResult.Ok($"Linux build → {buildPath}");
        }

        // ── WebGL ─────────────────────────────────────────────────────────
        /// <summary>
        /// Build a WebGL (HTML5 + WebAssembly) bundle using Blazor WASM / Uno Platform.
        /// Outputs an index.html entry point and supporting .wasm/.js files.
        /// </summary>
        public BuildResult ExportToWebGL(string outputPath)
        {
            string buildPath = Path.Combine(outputPath, "WebGL");
            Directory.CreateDirectory(buildPath);

            // .NET 8 WASM publish target
            var result = RunDotnetPublish(buildPath, "browser-wasm",
                                          extraArgs: "-p:WasmBuildNative=true");
            if (!result.Success) return result;

            // Generate a wrapper index.html
            GenerateWebGLIndex(buildPath);

            CopyAssets(Path.Combine(buildPath, "wwwroot"));

            if (_settings.CreateZip)
                ZipBuild(buildPath, Path.Combine(outputPath, "BADGE_WebGL.zip"));

            return BuildResult.Ok($"WebGL build → {buildPath}");
        }

        // ── Convenience: build all ─────────────────────────────────────────
        public List<BuildResult> ExportAll(string outputPath)
        {
            return new List<BuildResult>
            {
                ExportToWindows(outputPath),
                ExportToLinux(outputPath),
                ExportToWebGL(outputPath),
            };
        }

        // ── Internal helpers ───────────────────────────────────────────────
        private BuildResult RunDotnetPublish(string buildPath, string rid,
                                              string extraArgs = "")
        {
            // Compose the dotnet publish command
            string args = $"publish \"{_projectPath}\" " +
                          $"-c Release " +
                          $"-r {rid} " +
                          $"--self-contained true " +
                          $"-p:PublishSingleFile=true " +
                          $"-o \"{buildPath}\" " +
                          $"{extraArgs}";

            Console.WriteLine($"[Build] dotnet {args}");

            try
            {
                var psi = new ProcessStartInfo("dotnet", args)
                {
                    RedirectStandardOutput = true,
                    RedirectStandardError  = true,
                    UseShellExecute        = false,
                    CreateNoWindow         = true,
                };
                using var proc = Process.Start(psi)!;
                string stdout = proc.StandardOutput.ReadToEnd();
                string stderr = proc.StandardError.ReadToEnd();
                proc.WaitForExit();

                if (proc.ExitCode != 0)
                    return BuildResult.Fail($"dotnet publish failed (exit {proc.ExitCode}):\n{stderr}");

                return BuildResult.Ok("Compiled successfully.");
            }
            catch (Exception ex)
            {
                return BuildResult.Fail($"Failed to run dotnet: {ex.Message}");
            }
        }

        private void CopyAssets(string targetDir)
        {
            string assetsDir = Path.Combine(_projectPath, "Assets");
            if (!Directory.Exists(assetsDir)) return;

            string dst = Path.Combine(targetDir, "Assets");
            Directory.CreateDirectory(dst);
            foreach (var file in Directory.GetFiles(assetsDir, "*", SearchOption.AllDirectories))
            {
                string rel  = Path.GetRelativePath(assetsDir, file);
                string dest = Path.Combine(dst, rel);
                Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                File.Copy(file, dest, overwrite: true);
            }
        }

        private static void SetExecutable(string buildPath)
        {
            // Set execute bit on Linux binaries
            foreach (var file in Directory.GetFiles(buildPath, "BADGE_Engine*"))
            {
                try
                {
                    var chmod = Process.Start(new ProcessStartInfo("chmod", $"+x \"{file}\"")
                                { UseShellExecute = false });
                    chmod?.WaitForExit();
                }
                catch { /* non-Linux host; skip */ }
            }
        }

        private static void ZipBuild(string sourceDir, string zipPath)
        {
            if (File.Exists(zipPath)) File.Delete(zipPath);
            ZipFile.CreateFromDirectory(sourceDir, zipPath,
                                         CompressionLevel.Optimal, includeBaseDirectory: false);
            Console.WriteLine($"[Build] Zipped → {zipPath}");
        }

        private void CreateWindowsInstaller(string buildPath)
        {
            // Write an NSIS-style installer script stub
            string script = $@"; NSIS installer stub for BADGE game
Name ""{_settings.ProductName}""
OutFile ""{buildPath}\\{_settings.ProductName}_Setup.exe""
InstallDir ""$PROGRAMFILES64\\{_settings.ProductName}""

Section ""Main""
  SetOutPath $INSTDIR
  File /r ""{buildPath}\\*.*""
  CreateShortcut ""$DESKTOP\\{_settings.ProductName}.lnk"" ""$INSTDIR\\BADGE_Engine.exe""
SectionEnd
";
            File.WriteAllText(Path.Combine(buildPath, "installer.nsi"), script);
            Console.WriteLine("[Build] Windows installer script written (requires NSIS to compile).");
        }

        private void CreateLinuxAppImage(string buildPath)
        {
            // Write AppDir skeleton
            string appDir = Path.Combine(buildPath, $"{_settings.ProductName}.AppDir");
            Directory.CreateDirectory(Path.Combine(appDir, "usr", "bin"));

            string desktop = $@"[Desktop Entry]
Name={_settings.ProductName}
Exec=BADGE_Engine
Icon={_settings.ProductName}
Type=Application
Categories=Game;
";
            File.WriteAllText(Path.Combine(appDir, $"{_settings.ProductName}.desktop"), desktop);
            Console.WriteLine("[Build] AppDir skeleton written (requires appimagetool to package).");
        }

        private void GenerateWebGLIndex(string buildPath)
        {
            string html = $@"<!DOCTYPE html>
<html lang=""en"">
<head>
  <meta charset=""utf-8""/>
  <meta name=""viewport"" content=""width=device-width,initial-scale=1""/>
  <title>{_settings.ProductName}</title>
  <style>
    body {{ margin:0; background:#111; display:flex;
            justify-content:center; align-items:center; height:100vh; }}
    canvas {{ width:960px; height:540px; }}
  </style>
</head>
<body>
  <canvas id=""canvas"" oncontextmenu=""event.preventDefault()""></canvas>
  <script src=""wwwroot/BADGE_Engine.js""></script>
</body>
</html>
";
            File.WriteAllText(Path.Combine(buildPath, "index.html"), html);
        }
    }

    // ── Supporting types ─────────────────────────────────────────────────
    public class BuildSettings
    {
        public string ProductName    { get; set; } = "BADGEGame";
        public string Version        { get; set; } = "1.0.0";
        public bool   CreateInstaller{ get; set; } = false;
        public bool   CreateAppImage { get; set; } = false;
        public bool   CreateZip      { get; set; } = true;
        public bool   Development    { get; set; } = false;
    }

    public class BuildResult
    {
        public bool   Success { get; init; }
        public string Message { get; init; } = "";

        public static BuildResult Ok(string msg)   => new() { Success = true,  Message = msg };
        public static BuildResult Fail(string msg) => new() { Success = false, Message = msg };

        public override string ToString() => $"[{(Success ? "OK" : "FAIL")}] {Message}";
    }
}
