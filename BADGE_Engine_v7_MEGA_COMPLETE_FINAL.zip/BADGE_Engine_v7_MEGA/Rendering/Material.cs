// Rendering/Material.cs
// Thin facade kept for source-compatibility with old BADGE.Rendering.Material references.
// The real implementations live in Core/MaterialSystem.cs (Shader, Texture, ShaderLibrary)
// and Core/MaterialSystem.cs (Material).
// This file re-exports them into the BADGE.Rendering namespace via using aliases.

using BADGE.Core;

namespace BADGE.Rendering
{
    // Forward the types so code that does `using BADGE.Rendering;` still compiles.
    using Material = BADGE.Core.Material;
    using Shader   = BADGE.Core.Shader;
    using Texture  = BADGE.Core.Texture;
}
