using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Rendering;

/// <summary>
/// 2D camera with smooth follow, zoom, parallax layers, screen shake, bounds clamping.
/// Limbo: slow cinematic parallax.
/// Terraria: zoom in/out, scroll to edge reveals more world.
/// Subway Surfers: locked X, follow Y, screen shake on crash.
/// </summary>
public class Camera2D : Core.Component
{
    // ── Position / Zoom ───────────────────────────────────────────
    public Vector2 Position    { get; set; } = Vector2.Zero;
    public float   Zoom        { get; set; } = 1f;
    public float   MinZoom     { get; set; } = 0.1f;
    public float   MaxZoom     { get; set; } = 10f;
    public float   Rotation    { get; set; } = 0f;  // degrees

    // ── Follow ────────────────────────────────────────────────────
    public Core.Transform? Target        { get; set; }
    public float           FollowSpeed   { get; set; } = 5f;
    public bool            LockX         { get; set; } = false;
    public bool            LockY         { get; set; } = false;
    public Vector2         FollowOffset  { get; set; } = Vector2.Zero;
    public float           LookAheadDist { get; set; } = 2f;   // leads ahead of target velocity

    private Vector2 _velocity = Vector2.Zero;   // for smoothdamp

    // ── Bounds ────────────────────────────────────────────────────
    public bool    UseBounds { get; set; } = false;
    public float   BoundsMinX { get; set; } = -1000f;
    public float   BoundsMinY { get; set; } = -1000f;
    public float   BoundsMaxX { get; set; } =  1000f;
    public float   BoundsMaxY { get; set; } =  1000f;

    // ── Screen Shake ──────────────────────────────────────────────
    private float   _shakeDuration  = 0f;
    private float   _shakeMagnitude = 0f;
    private float   _shakeTimer     = 0f;
    private Random  _shakeRng       = new();
    private Vector2 _shakeOffset    = Vector2.Zero;

    // ── Pixel perfect ─────────────────────────────────────────────
    public bool  PixelPerfect    { get; set; } = false;
    public float PixelsPerUnit   { get; set; } = 32f;

    // ── Parallax layers ───────────────────────────────────────────
    private readonly List<ParallaxLayer> _parallaxLayers = new();

    public void AddParallaxLayer(string name, float speedX, float speedY, float depth = 0f)
        => _parallaxLayers.Add(new ParallaxLayer(name, speedX, speedY, depth));

    public Vector2 GetParallaxOffset(string name)
    {
        var layer = _parallaxLayers.Find(l => l.Name == name);
        if (layer == null) return Vector2.Zero;
        return new Vector2(Position.X * layer.SpeedX, Position.Y * layer.SpeedY);
    }

    // ── Update ────────────────────────────────────────────────────
    public override void LateUpdate(float dt)
    {
        if (Target != null)
        {
            var targetPos = new Vector2(Target.Position.X, Target.Position.Y) + FollowOffset;
            float sx = LockX ? Position.X : SmoothDamp(Position.X, targetPos.X, ref _velocity.X, 1f / FollowSpeed, dt);
            float sy = LockY ? Position.Y : SmoothDamp(Position.Y, targetPos.Y, ref _velocity.Y, 1f / FollowSpeed, dt);
            Position = new Vector2(sx, sy);
        }

        // Screen shake
        if (_shakeTimer < _shakeDuration)
        {
            _shakeTimer += dt;
            float t = 1f - _shakeTimer / _shakeDuration;
            float mag = _shakeMagnitude * t;
            _shakeOffset = new Vector2(
                (float)(_shakeRng.NextDouble() * 2 - 1) * mag,
                (float)(_shakeRng.NextDouble() * 2 - 1) * mag);
        }
        else _shakeOffset = Vector2.Zero;

        // Clamp
        if (UseBounds)
            Position = new Vector2(
                Math.Clamp(Position.X, BoundsMinX, BoundsMaxX),
                Math.Clamp(Position.Y, BoundsMinY, BoundsMaxY));

        // Pixel-perfect snap
        if (PixelPerfect)
            Position = new Vector2(
                MathF.Round(Position.X * PixelsPerUnit) / PixelsPerUnit,
                MathF.Round(Position.Y * PixelsPerUnit) / PixelsPerUnit);
    }

    // ── Screen shake ─────────────────────────────────────────────
    public void Shake(float duration, float magnitude)
    {
        _shakeDuration  = duration;
        _shakeMagnitude = magnitude;
        _shakeTimer     = 0f;
    }

    // ── View matrix ───────────────────────────────────────────────
    public Matrix4 GetViewMatrix()
    {
        var effectivePos = Position + _shakeOffset;
        return Matrix4.CreateTranslation(-effectivePos.X, -effectivePos.Y, 0f)
             * Matrix4.CreateRotationZ(-MathHelper.DegreesToRadians(Rotation))
             * Matrix4.CreateScale(Zoom, Zoom, 1f);
    }

    public Matrix4 GetProjectionMatrix(float screenW, float screenH)
    {
        float hw = (screenW * 0.5f) / Zoom;
        float hh = (screenH * 0.5f) / Zoom;
        return Matrix4.CreateOrthographic(screenW / Zoom, screenH / Zoom, -1f, 1f);
    }

    // ── World / Screen conversion ─────────────────────────────────
    public Vector2 ScreenToWorld(Vector2 screenPos, float screenW, float screenH)
    {
        float wx = (screenPos.X - screenW * 0.5f) / Zoom + Position.X;
        float wy = (screenPos.Y - screenH * 0.5f) / Zoom + Position.Y;
        return new Vector2(wx, wy);
    }

    public Vector2 WorldToScreen(Vector2 worldPos, float screenW, float screenH)
    {
        float sx = (worldPos.X - Position.X) * Zoom + screenW * 0.5f;
        float sy = (worldPos.Y - Position.Y) * Zoom + screenH * 0.5f;
        return new Vector2(sx, sy);
    }

    // ── Smooth damp ───────────────────────────────────────────────
    private static float SmoothDamp(float current, float target, ref float vel, float smoothTime, float dt)
    {
        float omega = 2f / smoothTime;
        float x     = omega * dt;
        float exp   = 1f / (1f + x + 0.48f * x * x + 0.235f * x * x * x);
        float delta = current - target;
        float temp  = (vel + omega * delta) * dt;
        vel         = (vel - omega * temp) * exp;
        return target + (delta + temp) * exp;
    }

    private record ParallaxLayer(string Name, float SpeedX, float SpeedY, float Depth);
}

// ═══════════════════════════════════════════════════════════════════════
//  SPRITE RENDERER  (upgraded from Renderer2D stub)
// ═══════════════════════════════════════════════════════════════════════
public class SpriteRenderer : Core.Component
{
    public object?  Sprite      { get; set; }   // Texture2D ref
    public Color4   Color       { get; set; } = Color4.White;
    public Vector2  Offset      { get; set; } = Vector2.Zero;
    public Vector2  Size        { get; set; } = Vector2.One;
    public bool     FlipX       { get; set; } = false;
    public bool     FlipY       { get; set; } = false;
    public int      SortingLayer{ get; set; } = 0;
    public int      OrderInLayer{ get; set; } = 0;
    public bool     PixelSnap   { get; set; } = false;
}

// ═══════════════════════════════════════════════════════════════════════
//  SPRITE ANIMATOR
// ═══════════════════════════════════════════════════════════════════════
public class SpriteAnimator : Core.Component
{
    public class AnimClip
    {
        public string  Name    { get; set; } = "";
        public int[]   Frames  { get; set; } = Array.Empty<int>();
        public float   FPS     { get; set; } = 12f;
        public bool    Loop    { get; set; } = true;
    }

    private readonly Dictionary<string, AnimClip> _clips = new();
    private AnimClip? _current;
    private float     _timer = 0f;
    private int       _frameIdx = 0;
    public  int       CurrentFrame { get; private set; }
    public  bool      IsPlaying    { get; private set; }
    public event Action<string>? OnAnimationEnd;

    public void AddClip(AnimClip clip)          => _clips[clip.Name] = clip;
    public void Play(string name, bool restart = false)
    {
        if (!_clips.TryGetValue(name, out var clip)) return;
        if (_current?.Name == name && !restart) return;
        _current  = clip;
        _frameIdx = 0;
        _timer    = 0f;
        IsPlaying = true;
    }
    public void Stop() => IsPlaying = false;

    public override void Update(float dt)
    {
        if (!IsPlaying || _current == null) return;
        _timer += dt;
        float frameDuration = 1f / _current.FPS;
        if (_timer >= frameDuration)
        {
            _timer    -= frameDuration;
            _frameIdx += 1;
            if (_frameIdx >= _current.Frames.Length)
            {
                if (_current.Loop) _frameIdx = 0;
                else { _frameIdx = _current.Frames.Length - 1; IsPlaying = false; OnAnimationEnd?.Invoke(_current.Name); }
            }
            CurrentFrame = _current.Frames[_frameIdx];
        }
    }
}
