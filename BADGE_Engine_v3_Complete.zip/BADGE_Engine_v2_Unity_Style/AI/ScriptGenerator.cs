using System;
namespace BADGE.AI
{
    public static class ScriptGenerator
    {
        private static bool _isIdle = true;
        public static void SetIdle(bool idle) { _isIdle = idle; }
        public static string GenerateScript(string prompt) 
        { 
            return "// AI-generated C# script\nusing BADGE.Core;\nusing BADGE.Core.ECS;\n\npublic class AIGenerated : ScriptComponent\n{\n    public override void OnStart() { }\n    public override void OnUpdate(float deltaTime) { }\n}"; 
        }
    }
}
