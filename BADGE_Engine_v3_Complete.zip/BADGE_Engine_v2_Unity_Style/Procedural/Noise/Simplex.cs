using System;
namespace BADGE.Procedural.Noise
{
    public static class Simplex
    {
        public static float Generate(float x, float y) { return Perlin.Generate(x, y); }
    }
}
