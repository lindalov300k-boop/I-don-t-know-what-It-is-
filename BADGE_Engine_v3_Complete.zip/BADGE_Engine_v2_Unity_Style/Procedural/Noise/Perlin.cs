using System;
namespace BADGE.Procedural.Noise
{
    public static class Perlin
    {
        private static int[] _perm = new int[512];
        static Perlin() { for(int i=0;i<512;i++) _perm[i] = i % 256; }
        public static float Generate(float x, float y) { return (float)Math.Sin(x * 12.9898 + y * 78.233) * 43758.5453f % 1.0f; }
    }
}
