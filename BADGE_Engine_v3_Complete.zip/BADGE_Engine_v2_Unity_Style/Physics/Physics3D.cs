using System;
using BADGE.Core;
using BADGE.Core.ECS;

namespace BADGE.Physics
{
    public static class Physics3D
    {
        public static Vector3 Gravity = new Vector3(0, -9.81f, 0);

        public static bool Raycast(Vector3 origin, Vector3 direction, out RaycastHit hit, float maxDistance = 100f)
        {
            hit = new RaycastHit();
            return false;
        }
    }

    public class Rigidbody3D : Component
    {
        public Vector3 Velocity { get; set; }
        public float Mass { get; set; } = 1.0f;
        public bool UseGravity { get; set; } = true;
    }

    public class Collider3D : Component
    {
        public ColliderType Type { get; set; } = ColliderType.Box;
        public Vector3 Size { get; set; } = new Vector3(1, 1, 1);
    }

    public enum ColliderType
    {
        Box,
        Sphere,
        Capsule
    }

    public struct RaycastHit
    {
        public Entity HitEntity;
        public Vector3 Point;
        public float Distance;
    }
}
