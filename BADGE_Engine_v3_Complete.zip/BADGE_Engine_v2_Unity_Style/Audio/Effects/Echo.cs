using System;

namespace BADGE.Audio.Effects
{
    public class Echo
    {
        public float DelayTime { get; set; } = 0.5f;
        public float Feedback { get; set; } = 0.5f;
        
        public float[] Process(float[] input)
        {
            // Simplified echo effect
            return input;
        }
    }
}
