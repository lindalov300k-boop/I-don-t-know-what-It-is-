using System;

namespace BADGE.Audio.Effects
{
    public class Reverb
    {
        public float RoomSize { get; set; } = 0.5f;
        public float Damping { get; set; } = 0.5f;
        public float WetLevel { get; set; } = 0.3f;
        
        public float[] Process(float[] input)
        {
            // Simplified reverb effect
            return input;
        }
    }
}
