using System;
using System.Collections.Generic;
namespace BADGE.Audio
{
    public static class AudioMixer
    {
        private static bool _isIdle = true;
        private static List<Channel> _channels = new List<Channel>();
        public static void SetIdle(bool idle) { _isIdle = idle; }
        public static void Play(AudioClip clip, float volume = 1.0f) { }
    }
    public class AudioClip { public string Name; public float[] Samples; }
    public class Channel { public float Volume = 1.0f; public bool Mute = false; }
}
