using System;
using BADGE.Core;
namespace BADGE.FileSystem
{
    public static class AssetManager
    {
        public static void SaveScene(Scene scene, string filename) { Console.WriteLine($"Saved: {filename}"); }
        public static Scene LoadScene(string filename) { return new Scene(filename); }
        public static void ExportBuild(string outputPath) { Console.WriteLine($"Build exported to: {outputPath}"); }
    }
}
