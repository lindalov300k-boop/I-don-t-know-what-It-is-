using BADGE.Editor;
using OpenTK.Mathematics;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.Desktop;

namespace BADGE;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("╔═══════════════════════════════════════════════════════════╗");
        Console.WriteLine("║                                                           ║");
        Console.WriteLine("║   ██████╗  █████╗ ██████╗  ██████╗ ███████╗            ║");
        Console.WriteLine("║   ██╔══██╗██╔══██╗██╔══██╗██╔════╝ ██╔════╝            ║");
        Console.WriteLine("║   ██████╔╝███████║██║  ██║██║  ███╗█████╗              ║");
        Console.WriteLine("║   ██╔══██╗██╔══██║██║  ██║██║   ██║██╔══╝              ║");
        Console.WriteLine("║   ██████╔╝██║  ██║██████╔╝╚██████╔╝███████╗            ║");
        Console.WriteLine("║   ╚═════╝ ╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚══════╝            ║");
        Console.WriteLine("║                                                           ║");
        Console.WriteLine("║   Basic Atlas Dimensional Game Engine v2.0               ║");
        Console.WriteLine("║   Unity-Style Editor Edition                              ║");
        Console.WriteLine("║                                                           ║");
        Console.WriteLine("╚═══════════════════════════════════════════════════════════╝");
        Console.WriteLine();
        Console.WriteLine("Features:");
        Console.WriteLine("  ✓ Unity-style visual editor with dockable panels");
        Console.WriteLine("  ✓ Right-click context menus for GameObject/Asset creation");
        Console.WriteLine("  ✓ VSCode integration for C# scripting");
        Console.WriteLine("  ✓ OpenGL rendering with OpenTK");
        Console.WriteLine("  ✓ ImGui-based editor UI");
        Console.WriteLine("  ✓ Multi-scene support");
        Console.WriteLine("  ✓ Component-based architecture");
        Console.WriteLine("  ✓ Material system");
        Console.WriteLine("  ✓ UI Canvas system");
        Console.WriteLine();
        Console.WriteLine("Launching editor...");
        Console.WriteLine();
        
        var gameWindowSettings = GameWindowSettings.Default;
        var nativeWindowSettings = new NativeWindowSettings()
        {
            ClientSize = new Vector2i(1920, 1080),
            Title = "BADGE Engine - Unity-Style Editor",
            Flags = ContextFlags.ForwardCompatible,
            Profile = ContextProfile.Core,
            API = ContextAPI.OpenGL,
            APIVersion = new Version(3, 3),
        };
        
        using (var window = new EditorWindow(gameWindowSettings, nativeWindowSettings))
        {
            window.Run();
        }
    }
}
