using System;
namespace BADGE.Editor
{
    public static class DesignTab
    {
        public static int CanvasWidth = 1024;
        public static int CanvasHeight = 1024;
        public static bool PixelPerfect = false;
        public static void DrawPixel(int x, int y, byte r, byte g, byte b) { }
    }
}
