using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace BADGE.Editor;

public class EditorCamera
{
    public Vector3 Position = new Vector3(0, 5, -10);
    public Vector3 Forward = Vector3.UnitZ;
    public Vector3 Up = Vector3.UnitY;
    public float Speed = 5.0f;
    public float Sensitivity = 0.1f;
    
    private float _pitch = 0f;
    private float _yaw = -90f;
    
    public void Update(EditorWindow window, float deltaTime)
    {
        var input = window.KeyboardState;
        var mouse = window.MouseState;
        
        // Movement
        if (input.IsKeyDown(Keys.W)) Position += Forward * Speed * deltaTime;
        if (input.IsKeyDown(Keys.S)) Position -= Forward * Speed * deltaTime;
        if (input.IsKeyDown(Keys.A)) Position -= Vector3.Normalize(Vector3.Cross(Forward, Up)) * Speed * deltaTime;
        if (input.IsKeyDown(Keys.D)) Position += Vector3.Normalize(Vector3.Cross(Forward, Up)) * Speed * deltaTime;
        if (input.IsKeyDown(Keys.E)) Position += Up * Speed * deltaTime;
        if (input.IsKeyDown(Keys.Q)) Position -= Up * Speed * deltaTime;
        
        // Rotation (when right mouse button is held)
        if (mouse.IsButtonDown(MouseButton.Right))
        {
            _yaw += mouse.Delta.X * Sensitivity;
            _pitch -= mouse.Delta.Y * Sensitivity;
            _pitch = Math.Clamp(_pitch, -89f, 89f);
            
            Forward.X = MathF.Cos(MathHelper.DegreesToRadians(_pitch)) * MathF.Cos(MathHelper.DegreesToRadians(_yaw));
            Forward.Y = MathF.Sin(MathHelper.DegreesToRadians(_pitch));
            Forward.Z = MathF.Cos(MathHelper.DegreesToRadians(_pitch)) * MathF.Sin(MathHelper.DegreesToRadians(_yaw));
            Forward = Vector3.Normalize(Forward);
        }
    }
}
