using System;
namespace BADGE.Editor
{
    public static class SceneTab
    {
        private static bool _isActive = true;
        public static void Update(float deltaTime) { }
        public static void RenderGizmos() { }
        public static void SetActive(bool active) { _isActive = active; }
    }
}
