using ImGuiNET;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.GraphicsLibraryFramework;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace BADGE.Editor;

/// <summary>
/// Main editor window - Unity-style interface with dockable panels
/// </summary>
public class EditorWindow : GameWindow
{
    private ImGuiController _imGuiController = null!;
    private Scene _activeScene = null!;
    private GameObject? _selectedGameObject;
    
    // Editor panels
    private HierarchyPanel _hierarchyPanel = null!;
    private InspectorPanel _inspectorPanel = null!;
    private ProjectPanel _projectPanel = null!;
    private SceneViewPanel _sceneViewPanel = null!;
    private ConsolePanel _consolePanel = null!;
    
    // Editor state
    private bool _isPlaying = false;
    private float _deltaTime = 0f;
    private float _lastFrameTime = 0f;
    
    // Camera
    private EditorCamera _editorCamera = null!;
    
    public EditorWindow(GameWindowSettings gameWindowSettings, NativeWindowSettings nativeWindowSettings)
        : base(gameWindowSettings, nativeWindowSettings)
    {
    }
    
    protected override void OnLoad()
    {
        base.OnLoad();
        
        GL.ClearColor(0.2f, 0.2f, 0.2f, 1.0f);
        GL.Enable(EnableCap.DepthTest);
        GL.Enable(EnableCap.Blend);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);
        
        // Initialize ImGui
        _imGuiController = new ImGuiController(ClientSize.X, ClientSize.Y);
        
        // Setup ImGui style (Unity-like dark theme)
        SetupImGuiStyle();
        
        // Initialize shader library
        BADGE.Core.ShaderLibrary.Initialize();
        
        // Create default scene
        _activeScene = new Scene("SampleScene");
        CreateDefaultScene();
        
        // Initialize editor camera
        _editorCamera = new EditorCamera();
        
        // Initialize panels
        _hierarchyPanel = new HierarchyPanel(this);
        _inspectorPanel = new InspectorPanel(this);
        _projectPanel = new ProjectPanel(this);
        _sceneViewPanel = new SceneViewPanel(this);
        _consolePanel = new ConsolePanel();
        
        Console.WriteLine("BADGE Engine Editor Initialized");
        Console.WriteLine("Press Play to start, or start creating your scene!");
    }
    
    private void CreateDefaultScene()
    {
        // Create Main Camera
        var cameraGO = _activeScene.CreateGameObject("Main Camera");
        cameraGO.Tag = "MainCamera";
        var camera = cameraGO.AddComponent<BADGE.Core.Camera>();
        cameraGO.Transform.Position = new Vector3(0, 1, -10);
        
        // Create Directional Light
        var lightGO = _activeScene.CreateGameObject("Directional Light");
        var light = lightGO.AddComponent<BADGE.Core.Light>();
        light.Type = BADGE.Core.LightType.Directional;
        lightGO.Transform.Rotation = Quaternion.FromEulerAngles(new Vector3(50, -30, 0) * (MathF.PI / 180f));
    }
    
    private void SetupImGuiStyle()
    {
        var style = ImGui.GetStyle();
        var colors = style.Colors;
        
        // Unity-like dark theme
        colors[(int)ImGuiCol.WindowBg] = new Vector4(0.15f, 0.15f, 0.15f, 1.0f);
        colors[(int)ImGuiCol.ChildBg] = new Vector4(0.15f, 0.15f, 0.15f, 1.0f);
        colors[(int)ImGuiCol.TitleBg] = new Vector4(0.12f, 0.12f, 0.12f, 1.0f);
        colors[(int)ImGuiCol.TitleBgActive] = new Vector4(0.20f, 0.20f, 0.20f, 1.0f);
        colors[(int)ImGuiCol.MenuBarBg] = new Vector4(0.12f, 0.12f, 0.12f, 1.0f);
        colors[(int)ImGuiCol.Header] = new Vector4(0.25f, 0.25f, 0.25f, 1.0f);
        colors[(int)ImGuiCol.HeaderHovered] = new Vector4(0.30f, 0.30f, 0.30f, 1.0f);
        colors[(int)ImGuiCol.HeaderActive] = new Vector4(0.35f, 0.35f, 0.35f, 1.0f);
        colors[(int)ImGuiCol.Button] = new Vector4(0.25f, 0.25f, 0.25f, 1.0f);
        colors[(int)ImGuiCol.ButtonHovered] = new Vector4(0.30f, 0.30f, 0.30f, 1.0f);
        colors[(int)ImGuiCol.ButtonActive] = new Vector4(0.35f, 0.35f, 0.35f, 1.0f);
        colors[(int)ImGuiCol.FrameBg] = new Vector4(0.20f, 0.20f, 0.20f, 1.0f);
        colors[(int)ImGuiCol.FrameBgHovered] = new Vector4(0.25f, 0.25f, 0.25f, 1.0f);
        colors[(int)ImGuiCol.FrameBgActive] = new Vector4(0.30f, 0.30f, 0.30f, 1.0f);
        colors[(int)ImGuiCol.Tab] = new Vector4(0.15f, 0.15f, 0.15f, 1.0f);
        colors[(int)ImGuiCol.TabHovered] = new Vector4(0.30f, 0.30f, 0.30f, 1.0f);
        colors[(int)ImGuiCol.TabActive] = new Vector4(0.22f, 0.22f, 0.22f, 1.0f);
        colors[(int)ImGuiCol.TabUnfocused] = new Vector4(0.12f, 0.12f, 0.12f, 1.0f);
        colors[(int)ImGuiCol.TabUnfocusedActive] = new Vector4(0.18f, 0.18f, 0.18f, 1.0f);
        
        style.WindowRounding = 0.0f;
        style.ChildRounding = 0.0f;
        style.FrameRounding = 2.0f;
        style.GrabRounding = 2.0f;
        style.TabRounding = 2.0f;
        style.ScrollbarRounding = 3.0f;
        
        // Enable docking
        ImGui.GetIO().ConfigFlags |= ImGuiConfigFlags.DockingEnable;
    }
    
    protected override void OnResize(ResizeEventArgs e)
    {
        base.OnResize(e);
        GL.Viewport(0, 0, ClientSize.X, ClientSize.Y);
        _imGuiController?.WindowResized(ClientSize.X, ClientSize.Y);
    }
    
    protected override void OnUpdateFrame(FrameEventArgs args)
    {
        base.OnUpdateFrame(args);
        
        _deltaTime = (float)args.Time;
        _lastFrameTime += _deltaTime;
        
        if (_isPlaying)
        {
            _activeScene.Update(_deltaTime);
            _activeScene.FixedUpdate(_deltaTime);
            _activeScene.LateUpdate(_deltaTime);
        }
        
        // Update editor camera
        _editorCamera.Update(this, _deltaTime);
    }
    
    protected override void OnRenderFrame(FrameEventArgs args)
    {
        base.OnRenderFrame(args);
        
        GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
        
        _imGuiController.Update(this, (float)args.Time);
        
        // Render editor UI
        RenderEditorUI();
        
        // Render ImGui
        _imGuiController.Render();
        
        SwapBuffers();
    }
    
    private void RenderEditorUI()
    {
        // Create dockspace
        ImGui.DockSpaceOverViewport(ImGui.GetMainViewport(), ImGuiDockNodeFlags.PassthruCentralNode);
        
        // Main menu bar
        RenderMenuBar();
        
        // Toolbar
        RenderToolbar();
        
        // Editor panels
        _hierarchyPanel.Render();
        _inspectorPanel.Render();
        _projectPanel.Render();
        _sceneViewPanel.Render(_editorCamera, _activeScene);
        _consolePanel.Render();
    }
    
    private void RenderMenuBar()
    {
        if (ImGui.BeginMainMenuBar())
        {
            if (ImGui.BeginMenu("File"))
            {
                if (ImGui.MenuItem("New Scene", "Ctrl+N")) CreateNewScene();
                if (ImGui.MenuItem("Open Scene", "Ctrl+O")) OpenScene();
                if (ImGui.MenuItem("Save Scene", "Ctrl+S")) SaveScene();
                if (ImGui.MenuItem("Save Scene As...", "Ctrl+Shift+S")) SaveSceneAs();
                ImGui.Separator();
                if (ImGui.MenuItem("New Project")) { }
                if (ImGui.MenuItem("Open Project")) { }
                ImGui.Separator();
                if (ImGui.MenuItem("Build Settings", "Ctrl+Shift+B")) { }
                ImGui.Separator();
                if (ImGui.MenuItem("Exit", "Alt+F4")) Close();
                ImGui.EndMenu();
            }
            
            if (ImGui.BeginMenu("Edit"))
            {
                if (ImGui.MenuItem("Undo", "Ctrl+Z")) { }
                if (ImGui.MenuItem("Redo", "Ctrl+Y")) { }
                ImGui.Separator();
                if (ImGui.MenuItem("Cut", "Ctrl+X")) { }
                if (ImGui.MenuItem("Copy", "Ctrl+C")) { }
                if (ImGui.MenuItem("Paste", "Ctrl+V")) { }
                if (ImGui.MenuItem("Duplicate", "Ctrl+D")) DuplicateSelected();
                if (ImGui.MenuItem("Delete", "Delete")) DeleteSelected();
                ImGui.Separator();
                if (ImGui.MenuItem("Project Settings")) { }
                if (ImGui.MenuItem("Preferences")) { }
                ImGui.EndMenu();
            }
            
            if (ImGui.BeginMenu("GameObject"))
            {
                if (ImGui.MenuItem("Create Empty", "Ctrl+Shift+N")) CreateEmptyGameObject();
                ImGui.Separator();
                
                if (ImGui.BeginMenu("3D Object"))
                {
                    if (ImGui.MenuItem("Cube")) CreatePrimitive(PrimitiveType.Cube);
                    if (ImGui.MenuItem("Sphere")) CreatePrimitive(PrimitiveType.Sphere);
                    if (ImGui.MenuItem("Capsule")) CreatePrimitive(PrimitiveType.Capsule);
                    if (ImGui.MenuItem("Cylinder")) CreatePrimitive(PrimitiveType.Cylinder);
                    if (ImGui.MenuItem("Plane")) CreatePrimitive(PrimitiveType.Plane);
                    if (ImGui.MenuItem("Quad")) CreatePrimitive(PrimitiveType.Quad);
                    ImGui.EndMenu();
                }
                
                if (ImGui.BeginMenu("Light"))
                {
                    if (ImGui.MenuItem("Directional Light")) CreateLight(BADGE.Core.LightType.Directional);
                    if (ImGui.MenuItem("Point Light")) CreateLight(BADGE.Core.LightType.Point);
                    if (ImGui.MenuItem("Spot Light")) CreateLight(BADGE.Core.LightType.Spot);
                    ImGui.EndMenu();
                }
                
                if (ImGui.MenuItem("Camera")) CreateCamera();
                
                ImGui.EndMenu();
            }
            
            if (ImGui.BeginMenu("Window"))
            {
                if (ImGui.MenuItem("Scene")) { }
                if (ImGui.MenuItem("Game")) { }
                if (ImGui.MenuItem("Hierarchy")) { }
                if (ImGui.MenuItem("Project")) { }
                if (ImGui.MenuItem("Inspector")) { }
                if (ImGui.MenuItem("Console")) { }
                ImGui.EndMenu();
            }
            
            if (ImGui.BeginMenu("Assets"))
            {
                if (ImGui.MenuItem("Create Folder")) _projectPanel.CreateFolder();
                if (ImGui.MenuItem("Create C# Script")) _projectPanel.CreateScript();
                if (ImGui.MenuItem("Create Material")) _projectPanel.CreateMaterial();
                if (ImGui.MenuItem("Create Scene")) _projectPanel.CreateScene();
                ImGui.Separator();
                if (ImGui.MenuItem("Import New Asset...")) { }
                if (ImGui.MenuItem("Import Package")) { }
                ImGui.EndMenu();
            }
            
            if (ImGui.BeginMenu("Help"))
            {
                if (ImGui.MenuItem("About BADGE Engine")) { }
                if (ImGui.MenuItem("Documentation")) { }
                if (ImGui.MenuItem("Report a Bug")) { }
                ImGui.EndMenu();
            }
            
            ImGui.EndMainMenuBar();
        }
    }
    
    private void RenderToolbar()
    {
        ImGui.Begin("##Toolbar", ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoResize | 
            ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoScrollbar | ImGuiWindowFlags.NoSavedSettings);
        
        ImGui.SetWindowPos(new Vector2(0, ImGui.GetFrameHeight()));
        ImGui.SetWindowSize(new Vector2(ClientSize.X, 40));
        
        // Play/Pause/Step buttons
        ImGui.SetCursorPosX(ClientSize.X / 2 - 60);
        
        if (ImGui.Button(_isPlaying ? "Pause ■" : "Play ▶", new Vector2(50, 30)))
        {
            TogglePlayMode();
        }
        
        ImGui.SameLine();
        if (ImGui.Button("Step ▶|", new Vector2(50, 30)))
        {
            StepFrame();
        }
        
        ImGui.End();
    }
    
    // GameObject creation methods
    private void CreateEmptyGameObject()
    {
        var go = _activeScene.CreateGameObject("GameObject");
        _selectedGameObject = go;
        _consolePanel.Log($"Created: {go.Name}");
    }
    
    private void CreatePrimitive(PrimitiveType type)
    {
        var go = GameObject.CreatePrimitive(type);
        _activeScene.AddGameObject(go);
        _selectedGameObject = go;
        _consolePanel.Log($"Created: {type}");
    }
    
    private void CreateLight(BADGE.Core.LightType type)
    {
        var go = _activeScene.CreateGameObject($"{type} Light");
        var light = go.AddComponent<BADGE.Core.Light>();
        light.Type = type;
        _selectedGameObject = go;
        _consolePanel.Log($"Created: {type} Light");
    }
    
    private void CreateCamera()
    {
        var go = _activeScene.CreateGameObject("Camera");
        go.AddComponent<BADGE.Core.Camera>();
        _selectedGameObject = go;
        _consolePanel.Log("Created: Camera");
    }
    
    // Scene management
    private void CreateNewScene()
    {
        _activeScene = new Scene("New Scene");
        CreateDefaultScene();
        _selectedGameObject = null;
        _consolePanel.Log("New scene created");
    }
    
    private void OpenScene()
    {
        // TODO: Implement scene loading dialog
        _consolePanel.Log("Open scene not yet implemented");
    }
    
    private void SaveScene()
    {
        if (string.IsNullOrEmpty(_activeScene.Path))
        {
            SaveSceneAs();
            return;
        }
        
        string json = _activeScene.SerializeToJson();
        File.WriteAllText(_activeScene.Path, json);
        _activeScene.IsDirty = false;
        _consolePanel.Log($"Scene saved: {_activeScene.Path}");
    }
    
    private void SaveSceneAs()
    {
        // TODO: Implement save dialog
        string path = $"Assets/Scenes/{_activeScene.Name}.scene";
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        
        string json = _activeScene.SerializeToJson();
        File.WriteAllText(path, json);
        _activeScene.Path = path;
        _activeScene.IsDirty = false;
        _consolePanel.Log($"Scene saved as: {path}");
    }
    
    // Selection management
    private void DuplicateSelected()
    {
        if (_selectedGameObject != null)
        {
            // TODO: Implement GameObject duplication
            _consolePanel.Log("Duplicate not yet implemented");
        }
    }
    
    private void DeleteSelected()
    {
        if (_selectedGameObject != null)
        {
            GameObject.Destroy(_selectedGameObject);
            _selectedGameObject = null;
            _consolePanel.Log("GameObject deleted");
        }
    }
    
    // Play mode
    private void TogglePlayMode()
    {
        _isPlaying = !_isPlaying;
        
        if (_isPlaying)
        {
            _activeScene.Start();
            _consolePanel.Log("▶ Entering Play Mode");
        }
        else
        {
            _consolePanel.Log("■ Exiting Play Mode");
        }
    }
    
    private void StepFrame()
    {
        if (!_isPlaying)
        {
            _activeScene.Update(0.016f);
            _consolePanel.Log("Frame stepped");
        }
    }
    
    // Public accessors for panels
    public Scene ActiveScene => _activeScene;
    public GameObject? SelectedGameObject
    {
        get => _selectedGameObject;
        set => _selectedGameObject = value;
    }
    
    protected override void OnTextInput(TextInputEventArgs e)
    {
        base.OnTextInput(e);
        _imGuiController.PressChar((char)e.Unicode);
    }
    
    protected override void OnMouseWheel(MouseWheelEventArgs e)
    {
        base.OnMouseWheel(e);
        _imGuiController.MouseScroll(e.Offset);
    }
    
    protected override void OnUnload()
    {
        BADGE.Core.ShaderLibrary.Cleanup();
        _imGuiController.Dispose();
        base.OnUnload();
    }
}
