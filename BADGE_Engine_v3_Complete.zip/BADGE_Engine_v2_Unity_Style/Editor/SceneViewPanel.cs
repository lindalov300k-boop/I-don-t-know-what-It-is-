using ImGuiNET;

namespace BADGE.Editor;

public class SceneViewPanel
{
    private EditorWindow _editor;
    
    public SceneViewPanel(EditorWindow editor)
    {
        _editor = editor;
    }
    
    public void Render(EditorCamera camera, Scene scene)
    {
        ImGui.Begin("Scene");
        
        // TODO: Render 3D scene view with gizmos
        var windowSize = ImGui.GetContentRegionAvail();
        ImGui.Text($"Scene View ({windowSize.X}x{windowSize.Y})");
        ImGui.Text("Camera controls: WASD + Right Mouse Button");
        
        ImGui.End();
    }
}
