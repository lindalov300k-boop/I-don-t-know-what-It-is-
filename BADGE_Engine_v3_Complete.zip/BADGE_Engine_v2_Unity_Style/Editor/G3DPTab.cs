using System;
using BADGE.G3DP;

namespace BADGE.Editor
{
    public static class G3DPTab
    {
        public static SelectionMode Mode = SelectionMode.Vertex;
        public static Mesh ActiveMesh { get; set; }
        
        public static void Extrude(float distance)
        {
            if (ActiveMesh != null)
                Console.WriteLine($"Extruding selected by {distance}");
        }
        
        public static void Subdivide()
        {
            if (ActiveMesh != null)
                ActiveMesh = MeshFilterStack.Subdivide(ActiveMesh);
        }
        
        public static void ApplyNoiseDeform(float strength)
        {
            if (ActiveMesh != null)
                ActiveMesh = MeshFilterStack.NoiseDeform(ActiveMesh, strength);
        }
    }
    
    public enum SelectionMode
    {
        Vertex,
        Edge,
        Face
    }
}
