using System;
using System.Collections.Generic;
using BADGE.Core;
namespace BADGE.G3DP
{
    public class Mesh
    {
        public List<Vector3> Vertices { get; set; } = new List<Vector3>();
        public List<int> Triangles { get; set; } = new List<int>();
        public List<Vector2> UVs { get; set; } = new List<Vector2>();
        public List<Vector3> Normals { get; set; } = new List<Vector3>();
        public int TriangleCount => Triangles.Count / 3;
        
        public void RecalculateNormals()
        {
            Normals.Clear();
            for(int i = 0; i < Vertices.Count; i++) Normals.Add(new Vector3(0,1,0));
        }
        
        public static Mesh CreateCube(float size = 1.0f)
        {
            Mesh mesh = new Mesh();
            float h = size / 2;
            mesh.Vertices.AddRange(new[] {
                new Vector3(-h,-h,-h), new Vector3(h,-h,-h), new Vector3(h,h,-h), new Vector3(-h,h,-h),
                new Vector3(-h,-h,h), new Vector3(h,-h,h), new Vector3(h,h,h), new Vector3(-h,h,h)
            });
            mesh.Triangles.AddRange(new[] { 0,2,1, 0,3,2, 1,6,5, 1,2,6, 5,7,4, 5,6,7, 4,3,0, 4,7,3, 3,6,2, 3,7,6, 4,1,5, 4,0,1 });
            mesh.RecalculateNormals();
            return mesh;
        }
    }
}
