using System;
namespace BADGE.G3DP
{
    public static class MeshFilterStack
    {
        private static bool _isIdle = true;
        public static void SetIdle(bool idle) { _isIdle = idle; }
        
        public static Mesh Subdivide(Mesh mesh) { return mesh; }
        public static Mesh Smooth(Mesh mesh) { return mesh; }
        public static Mesh NoiseDeform(Mesh mesh, float strength) { return mesh; }
    }
}
