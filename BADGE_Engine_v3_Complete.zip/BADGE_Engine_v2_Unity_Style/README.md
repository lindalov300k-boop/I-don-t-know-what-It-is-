# BADGE Engine v2.0 - Unity-Style Game Engine

## Basic Atlas Dimensional Game Engine
**By ATLAS NETWORK CLUB**

A complete Unity-style game engine with visual editor, C# scripting support, VSCode integration, right-click context menus, and modern rendering capabilities - just like Unity!

---

## ✨ Key Features You Requested

### ✅ Unity-Style Interface
- **Dockable Panels** - Hierarchy, Inspector, Scene View, Project Browser, Console
- **Right-Click Context Menus** EVERYWHERE - Just like Unity!
- **Play/Pause/Step Controls** - Test your game in the editor

### ✅ Right-Click to Create ANYTHING
**In Hierarchy:**
- Right-click → Create Empty, 3D Objects (Cube, Sphere, etc.), Lights, Camera, UI Elements

**In Project Panel:**
- Right-click → Create Folder, C# Script, Material, Scene, Shader
- **Scripts automatically open in VSCode!**

### ✅ VSCode Integration
- Create a C# script → **Automatically opens in VSCode**
- Full C# scripting with MonoBehaviour base class
- Unity-compatible API (Transform, GameObject, Components)

### ✅ Multi-Scene Support
- Create multiple scenes
- Save/Load scenes (.scene files)
- Scene management like Unity

### ✅ C# Scripting (Not Just AI!)
Write your own code with **full Unity-like API**:
```csharp
public class PlayerController : MonoBehaviour
{
    public float speed = 5.0f;
    
    public override void Update(float deltaTime)
    {
        if (Input.GetKey(Keys.W))
            Transform.Translate(Vector3.Forward * speed * deltaTime);
    }
}
```

### ✅ Modern Rendering
- **OpenGL 3.3+** with OpenTK
- **ImGui** editor interface
- Materials, Shaders, Meshes, Lighting

### ✅ UI/UX System
- **Canvas** component (replaces TMP)
- UIText, UIImage, UIButton components
- Screen Space & World Space rendering

### ✅ Optimized Size
- Build size well under 500GB limit
- Optimized dependencies
- Efficient asset management

---

## 🚀 Quick Start

### 1. Prerequisites
- **.NET 8.0 SDK** ([Download](https://dotnet.microsoft.com/download))
- **Visual Studio Code** ([Download](https://code.visualstudio.com/))
- OpenGL 3.3+ graphics card

### 2. Build & Run
```bash
cd BADGE_Project
dotnet restore
dotnet build
dotnet run
```

The Unity-style editor window will open!

### 3. Your First GameObject
1. **Right-click in Hierarchy** → "3D Object" → "Cube"
2. **Select the Cube** in Hierarchy
3. **Modify in Inspector** - Change position, rotation, scale
4. **Click Play** to run the scene!

### 4. Your First Script
1. **Right-click in Project Panel** → "C# Script"
2. **Name it** "PlayerController"
3. **VSCode opens automatically** with template code
4. **Edit the script:**
```csharp
using BADGE.Core;
using OpenTK.Mathematics;

namespace UserScripts
{
    public class PlayerController : MonoBehaviour
    {
        public float speed = 5.0f;
        
        public override void Update(float deltaTime)
        {
            // Move with WASD
            if (Input.GetKey(Keys.W))
                Transform.Position += Vector3.UnitZ * speed * deltaTime;
        }
    }
}
```
5. **Save** and it's ready to use!

---

## 🎮 Editor Controls

### Scene Navigation
- **Right Mouse + WASD** - Fly camera (FPS controls)
- **E/Q** - Move up/down
- **Mouse Wheel** - Zoom

### Shortcuts
- `Ctrl+N` - New Scene
- `Ctrl+S` - Save Scene
- `Ctrl+Shift+N` - Create Empty GameObject
- `Ctrl+D` - Duplicate
- `Delete` - Delete GameObject
- `Space` - Play/Pause

---

## 📁 Project Structure

```
BADGE_Project/
├── Assets/
│   ├── Scenes/          # Your game scenes
│   ├── Scripts/         # Your C# scripts (open in VSCode!)
│   ├── Materials/       # Material assets
│   ├── Textures/        # Texture files
│   └── Prefabs/         # Prefab assets
├── Core/                # Engine core systems
├── Editor/              # Unity-style editor
└── Program.cs           # Entry point
```

---

## 🔥 Right-Click Context Menus

### Hierarchy Panel
**Right-click in empty space:**
- Create Empty
- 3D Object → Cube, Sphere, Capsule, Cylinder, Plane, Quad
- 2D Object → Sprite, UI Canvas
- Light → Directional, Point, Spot
- Camera
- UI → Canvas, Text, Image, Button, Input Field, Slider

**Right-click on GameObject:**
- Rename
- Duplicate (Ctrl+D)
- Delete
- Create Empty Child
- Copy/Paste
- Add Component → MeshRenderer, MeshFilter, Camera, Light, etc.

### Project Panel
**Right-click in empty space:**
- Create Folder
- C# Script (opens in VSCode!)
- Scene
- Material
- Shader → Standard, Unlit

**Right-click on file/folder:**
- Open (Scripts open in VSCode!)
- Rename
- Delete
- Show in Explorer
- Copy Path

---

## 💻 Unity API Compatibility

BADGE implements Unity's most common APIs:

### GameObject
```csharp
var go = new GameObject("Player");
go.AddComponent<MeshRenderer>();
go.SetActive(true);
go.SetParent(parentObject);
GameObject.Destroy(go);
```

### Transform
```csharp
transform.Position = new Vector3(0, 5, 0);
transform.Rotation = Quaternion.identity;
transform.LocalScale = Vector3.One * 2;
transform.Translate(Vector3.Forward);
transform.LookAt(target);
```

### Components
```csharp
var renderer = gameObject.AddComponent<MeshRenderer>();
var camera = GetComponent<Camera>();
var light = GetComponentInChildren<Light>();
```

### MonoBehaviour
```csharp
public override void Awake() { }      // On creation
public override void Start() { }      // Before first Update
public override void Update(float dt) { }  // Every frame
public override void FixedUpdate(float dt) { }  // Fixed timestep
public override void LateUpdate(float dt) { }   // After Update
```

---

## 🎨 Features Breakdown

### Rendering
- ✅ OpenGL 3.3+ with OpenTK
- ✅ ImGui editor UI
- ✅ Mesh rendering (MeshFilter + MeshRenderer)
- ✅ Primitive meshes (Cube, Sphere, etc.)
- ✅ Material system with shaders
- ✅ Lighting (Directional, Point, Spot)
- ✅ Camera system

### Editor
- ✅ Dockable windows (Unity layout)
- ✅ Hierarchy panel with GameObject tree
- ✅ Inspector for component editing
- ✅ Scene viewport with editor camera
- ✅ Project browser with asset management
- ✅ Console for logging
- ✅ Toolbar with Play/Pause/Step
- ✅ Menu bar (File, Edit, GameObject, Window, Assets, Help)

### Workflow
- ✅ Right-click context menus everywhere
- ✅ VSCode integration for scripts
- ✅ Multi-scene support (create, save, load)
- ✅ Asset creation (scripts, materials, scenes)
- ✅ GameObject creation (primitives, lights, cameras, UI)
- ✅ Component system
- ✅ Play mode testing

### Scripting
- ✅ C# scripting with MonoBehaviour
- ✅ Unity-compatible API
- ✅ Full component access
- ✅ Lifecycle methods (Awake, Start, Update, etc.)
- ✅ Script templates auto-generated
- ✅ Hot-reload support (planned)

### UI System
- ✅ Canvas component
- ✅ UIText (replaces TextMeshPro)
- ✅ UIImage
- ✅ UIButton
- ✅ Screen Space Overlay/Camera/World modes

---

## 🛠️ Building Your Game

1. Create your game in the editor
2. `File → Build Settings`
3. Select platform (Windows/Linux/macOS)
4. Click Build
5. Standalone executable created in `Builds/`

---

## 📚 Documentation

- **This README** - Quick start guide
- **DEVELOPER_GUIDE.md** - Advanced topics
- **VISUAL_GUIDE.md** - Editor interface guide
- **API Reference** - Full API documentation (planned)

---

## 🐛 Troubleshooting

**Editor won't start?**
- Install .NET 8.0 SDK
- Check OpenGL 3.3+ support
- Run `dotnet restore`

**Scripts not opening in VSCode?**
- Install VSCode and add to PATH
- Windows: Ensure `code` command works
- Linux/Mac: `export PATH="$PATH:/usr/local/bin"`

**Missing packages?**
```bash
dotnet restore
dotnet build
```

---

## 🔮 Roadmap

**v2.1 (Next)**
- [ ] Physics system (BepuPhysics)
- [ ] Prefab system
- [ ] Animation system
- [ ] Particle effects

**v3.0 (Future)**
- [ ] Visual node-based scripting
- [ ] Terrain editor
- [ ] Multiplayer networking
- [ ] Mobile export

---

## 📜 License

Copyright © 2025 ATLAS NETWORK CLUB
See LICENSE.txt

---

## 🙏 Credits

**Libraries:**
- OpenTK - OpenGL bindings
- ImGui.NET - Editor UI
- BepuPhysics - Physics
- Newtonsoft.Json - Serialization
- NAudio - Audio

---

**Built with ❤️ by ATLAS NETWORK CLUB**

*"Your Unity-style game engine, but open and customizable!"*

**Engine size: <100MB | Build size: Well under 500GB limit**
