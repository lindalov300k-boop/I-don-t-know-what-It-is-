using System;
using System.Collections.Generic;

namespace BADGE.Rendering
{
    /// <summary>
    /// Material system for rendering
    /// </summary>
    public class Material
    {
        public string Name { get; set; }
        public Shader Shader { get; set; }
        public Dictionary<string, object> Properties { get; private set; }

        public Material(string name = "DefaultMaterial")
        {
            Name = name;
            Properties = new Dictionary<string, object>();
        }

        public void SetFloat(string name, float value)
        {
            Properties[name] = value;
        }

        public void SetColor(string name, Color value)
        {
            Properties[name] = value;
        }

        public void SetTexture(string name, Texture texture)
        {
            Properties[name] = texture;
        }
    }

    /// <summary>
    /// Shader representation
    /// </summary>
    public class Shader
    {
        public string Name { get; set; }
        public string VertexSource { get; set; }
        public string FragmentSource { get; set; }

        public Shader(string name)
        {
            Name = name;
        }
    }

    /// <summary>
    /// Texture representation
    /// </summary>
    public class Texture
    {
        public int Width { get; set; }
        public int Height { get; set; }
        public byte[] Data { get; set; }

        public Texture(int width, int height)
        {
            Width = width;
            Height = height;
            Data = new byte[width * height * 4]; // RGBA
        }
    }

    /// <summary>
    /// Node-based shader graph system (idle until used)
    /// </summary>
    public static class ShaderGraph
    {
        private static bool _isActive = false;
        private static List<ShaderNode> _nodes;

        public static void Initialize()
        {
            _nodes = new List<ShaderNode>();
            Console.WriteLine("  - ShaderGraph initialized (idle)");
        }

        public static void SetActive(bool active)
        {
            _isActive = active;
            if (active)
            {
                Console.WriteLine("ShaderGraph activated");
            }
        }

        public static ShaderNode CreateNode(ShaderNodeType type)
        {
            var node = new ShaderNode(type);
            _nodes.Add(node);
            return node;
        }

        public static Shader CompileToShader(string name)
        {
            // Compile node graph to GLSL shader
            var shader = new Shader(name);
            // Compilation logic would go here
            return shader;
        }
    }

    public enum ShaderNodeType
    {
        Input,
        Output,
        Math,
        Color,
        Texture,
        Noise,
        Mix
    }

    public class ShaderNode
    {
        public Guid Id { get; private set; }
        public ShaderNodeType Type { get; private set; }
        public List<ShaderNode> Inputs { get; private set; }
        public Dictionary<string, object> Parameters { get; private set; }

        public ShaderNode(ShaderNodeType type)
        {
            Id = Guid.NewGuid();
            Type = type;
            Inputs = new List<ShaderNode>();
            Parameters = new Dictionary<string, object>();
        }

        public void ConnectInput(ShaderNode inputNode)
        {
            Inputs.Add(inputNode);
        }
    }
}
