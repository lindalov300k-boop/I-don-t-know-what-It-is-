using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.ECS;

namespace BADGE.Rendering
{
    /// <summary>
    /// 2D rendering system - lightweight and optimized
    /// Supports sprite batching to minimize draw calls
    /// </summary>
    public static class Renderer2D
    {
        private static bool _isInitialized = false;
        private static List<SpriteRenderer> _spriteQueue;
        private static int _drawCalls;

        public static void Initialize()
        {
            if (_isInitialized) return;

            _spriteQueue = new List<SpriteRenderer>();
            Console.WriteLine("  - Renderer2D initialized");
            _isInitialized = true;
        }

        public static void BeginFrame()
        {
            _spriteQueue.Clear();
            _drawCalls = 0;
        }

        public static void RenderScene(Scene scene)
        {
            if (scene == null) return;

            // Collect all sprite renderers
            foreach (var entity in scene.Entities)
            {
                var spriteRenderer = entity.GetComponent<SpriteRenderer>();
                if (spriteRenderer != null && spriteRenderer.IsEnabled)
                {
                    _spriteQueue.Add(spriteRenderer);
                }
            }

            // Batch and render sprites
            BatchRender();
        }

        private static void BatchRender()
        {
            // Sort by material/texture for batching
            // Actual OpenGL rendering would happen here
            _drawCalls = _spriteQueue.Count;
        }

        public static void EndFrame()
        {
            // Finalize frame
            // Swap buffers would happen here
        }

        public static int GetDrawCallCount() => _drawCalls;
    }

    /// <summary>
    /// Sprite renderer component
    /// </summary>
    public class SpriteRenderer : Component
    {
        public Color Color { get; set; } = Color.White;
        public Material Material { get; set; }
        public int SortingOrder { get; set; } = 0;
        public bool FlipX { get; set; } = false;
        public bool FlipY { get; set; } = false;
    }

    public struct Color
    {
        public float R, G, B, A;

        public Color(float r, float g, float b, float a = 1.0f)
        {
            R = r; G = g; B = b; A = a;
        }

        public static Color White => new Color(1, 1, 1, 1);
        public static Color Black => new Color(0, 0, 0, 1);
        public static Color Red => new Color(1, 0, 0, 1);
        public static Color Green => new Color(0, 1, 0, 1);
        public static Color Blue => new Color(0, 0, 1, 1);
    }
}
