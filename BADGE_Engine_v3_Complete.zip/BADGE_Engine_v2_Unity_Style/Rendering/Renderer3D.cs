using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.ECS;

namespace BADGE.Rendering
{
    /// <summary>
    /// 3D rendering system - optimized for low-end hardware
    /// Supports basic mesh rendering with LOD
    /// </summary>
    public static class Renderer3D
    {
        private static bool _isInitialized = false;
        private static List<MeshRenderer> _meshQueue;
        private static int _triangleCount;
        
        // Vertex warning for low-end PC
        private const int MAX_SAFE_VERTICES = 50000;

        public static void Initialize()
        {
            if (_isInitialized) return;

            _meshQueue = new List<MeshRenderer>();
            Console.WriteLine("  - Renderer3D initialized");
            _isInitialized = true;
        }

        public static void RenderScene(Scene scene, Camera camera)
        {
            if (scene == null) return;

            _meshQueue.Clear();
            _triangleCount = 0;

            // Collect mesh renderers
            foreach (var entity in scene.Entities)
            {
                var meshRenderer = entity.GetComponent<MeshRenderer>();
                if (meshRenderer != null && meshRenderer.IsEnabled)
                {
                    // Frustum culling would happen here
                    _meshQueue.Add(meshRenderer);
                    
                    if (meshRenderer.Mesh != null)
                    {
                        _triangleCount += meshRenderer.Mesh.TriangleCount;
                    }
                }
            }

            // Warn if vertex count is too high
            int totalVerts = _triangleCount * 3;
            if (totalVerts > MAX_SAFE_VERTICES)
            {
                Console.WriteLine($"WARNING: High vertex count ({totalVerts}), consider using LOD");
            }

            // Render meshes
            foreach (var meshRenderer in _meshQueue)
            {
                RenderMesh(meshRenderer);
            }
        }

        private static void RenderMesh(MeshRenderer renderer)
        {
            // Actual mesh rendering would use OpenGL here
            // Apply material, bind textures, draw triangles
        }

        public static int GetTriangleCount() => _triangleCount;
    }

    /// <summary>
    /// Mesh renderer component
    /// </summary>
    public class MeshRenderer : Component
    {
        public G3DP.Mesh Mesh { get; set; }
        public Material Material { get; set; }
        public bool CastShadows { get; set; } = true;
        public bool ReceiveShadows { get; set; } = true;
    }

    /// <summary>
    /// Camera component for 3D rendering
    /// </summary>
    public class Camera : Component
    {
        public float FieldOfView { get; set; } = 60.0f;
        public float NearClip { get; set; } = 0.1f;
        public float FarClip { get; set; } = 1000.0f;
        public bool IsOrthographic { get; set; } = false;
    }
}
