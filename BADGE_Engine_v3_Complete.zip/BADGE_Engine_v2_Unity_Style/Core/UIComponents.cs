using OpenTK.Mathematics;

namespace BADGE.Core;

// Canvas component for UI rendering
public class Canvas : Component
{
    public RenderMode RenderMode { get; set; } = RenderMode.ScreenSpaceOverlay;
    public int SortingOrder { get; set; } = 0;
}

public enum RenderMode
{
    ScreenSpaceOverlay,
    ScreenSpaceCamera,
    WorldSpace
}

// UI Text component
public class UIText : Component
{
    public string Text { get; set; } = "New Text";
    public int FontSize { get; set; } = 14;
    public Color4 Color { get; set; } = Color4.White;
    public TextAlignment Alignment { get; set; } = TextAlignment.Center;
}

public enum TextAlignment
{
    Left,
    Center,
    Right
}

// UI Image component
public class UIImage : Component
{
    public Texture? Sprite { get; set; }
    public Color4 Color { get; set; } = Color4.White;
}

// UI Button component
public class UIButton : Component
{
    public string Text { get; set; } = "Button";
    public Action? OnClick { get; set; }
}
