using System;
using System.Diagnostics;

namespace BADGE.Core
{
    /// <summary>
    /// Main engine class - coordinates all systems and enforces idle-safe operation
    /// </summary>
    public class Engine
    {
        private static Engine _instance;
        public static Engine Instance => _instance ?? (_instance = new Engine());

        public bool IsRunning { get; private set; }
        public bool IsPlayMode { get; private set; }
        public float DeltaTime { get; private set; }
        
        private Stopwatch _frameTimer;
        private WindowManager _windowManager;
        private SceneManager _sceneManager;
        private InputManager _inputManager;
        
        // Performance monitoring
        private PerformanceMonitor _perfMonitor;
        
        // Enhanced systems
        private PerformanceManager _perfManager;
        
        private Engine()
        {
            _frameTimer = new Stopwatch();
            _perfManager = PerformanceManager.Instance;
        }

        // Public accessors for subsystems
        public Scene GetCurrentScene() => _sceneManager?.CurrentScene;
        public InputManager GetInputManager() => _inputManager;
        public PerformanceManager GetPerformanceManager() => _perfManager;

        /// <summary>
        /// Boot sequence as per specification
        /// </summary>
        public void Initialize()
        {
            Console.WriteLine("=== BADGE Engine Initialization ===");
            Console.WriteLine("Basic Atlas Dimensional Game Engine");
            Console.WriteLine("By ATLAS NETWORK CLUB");
            Console.WriteLine("Creator Alias: Fake");
            Console.WriteLine("====================================\n");

            // Step 1: Initialize Core
            Console.WriteLine("[1/7] Initializing Core Systems...");
            _windowManager = new WindowManager();
            _sceneManager = new SceneManager();
            _inputManager = new InputManager();
            ECS.EntityManager.Initialize();
            
            // Step 2: Load Editor Tabs
            Console.WriteLine("[2/7] Loading Editor Tabs...");
            // Editor tabs initialized in Editor namespace
            
            // Step 3: Load runtime systems (idle until needed)
            Console.WriteLine("[3/7] Preparing Runtime Systems (Idle)...");
            Rendering.Renderer2D.Initialize();
            Physics.Physics2D.Initialize();
            
            // Step 4: Enforce idle behavior
            Console.WriteLine("[4/7] Enforcing Idle Behavior...");
            EnforceIdleState();
            
            // Step 5: Load Scene
            Console.WriteLine("[5/7] Loading Default Scene...");
            _sceneManager.LoadScene("DefaultScene");
            
            Console.WriteLine("[6/7] Engine Ready - Entering Editor Mode");
            Console.WriteLine("[7/7] Idle-Safe Mode Active\n");
            
            // Initialize crash recovery
            CrashRecovery.Initialize();
            
            IsRunning = true;
            _perfManager.StartFrame();
        }

        private void EnforceIdleState()
        {
            // Ensure all heavy modules are inactive
            // CPU should be <10%, RAM stable
            Procedural.ProceduralManager.SetIdle(true);
            G3DP.MeshFilterStack.SetIdle(true);
            Audio.AudioMixer.SetIdle(true);
            AI.ScriptGenerator.SetIdle(true);
        }

        /// <summary>
        /// Main game loop
        /// </summary>
        public void Run()
        {
            while (IsRunning)
            {
                _perfManager.StartFrame();
                
                // Update systems
                Update();
                Render();
                
                _perfManager.EndFrame();
                DeltaTime = 1.0f / _perfManager.CurrentFPS;
                
                // Display performance report periodically
                if (_frameTimer.Elapsed.TotalSeconds > 5.0)
                {
                    var report = _perfManager.GetReport();
                    if (report.Status != PerformanceStatus.Excellent)
                    {
                        report.Print();
                    }
                    _frameTimer.Restart();
                }
            }
        }

        private void Update()
        {
            _inputManager.Update();
            
            if (IsPlayMode)
            {
                // Runtime-only updates
                ECS.EntityManager.Update(DeltaTime);
                Physics.Physics2D.Update(DeltaTime);
            }
            else
            {
                // Editor-only updates
                Editor.SceneTab.Update(DeltaTime);
            }
        }

        private void Render()
        {
            Rendering.Renderer2D.BeginFrame();
            
            if (IsPlayMode)
            {
                // Render game view
                Rendering.Renderer2D.RenderScene(_sceneManager.CurrentScene);
            }
            else
            {
                // Render editor view
                Rendering.Renderer2D.RenderScene(_sceneManager.CurrentScene);
                Editor.SceneTab.RenderGizmos();
            }
            
            Rendering.Renderer2D.EndFrame();
        }

        public void EnterPlayMode()
        {
            Console.WriteLine("\n=== Entering Play Mode ===");
            IsPlayMode = true;
            
            // Activate runtime modules
            Physics.Physics2D.Activate();
            
            // Deactivate editor tools
            Editor.SceneTab.SetActive(false);
        }

        public void ExitPlayMode()
        {
            Console.WriteLine("\n=== Exiting Play Mode ===");
            IsPlayMode = false;
            
            // Reactivate editor tools
            Editor.SceneTab.SetActive(true);
            
            // Return to idle state
            EnforceIdleState();
        }

        public void Shutdown()
        {
            Console.WriteLine("\n=== BADGE Engine Shutdown ===");
            IsRunning = false;
            
            CrashRecovery.Shutdown();
            _sceneManager.UnloadAll();
            _windowManager.Close();
            
            // Print final performance report
            var finalReport = _perfManager.GetReport();
            finalReport.Print();
            
            Console.WriteLine("Engine shutdown complete.");
        }
    }
}
