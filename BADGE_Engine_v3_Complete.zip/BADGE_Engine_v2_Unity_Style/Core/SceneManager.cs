using System;
using System.Collections.Generic;

namespace BADGE.Core
{
    /// <summary>
    /// Manages scene loading, unloading, and transitions
    /// </summary>
    public class SceneManager
    {
        public Scene CurrentScene { get; private set; }
        private Dictionary<string, Scene> _loadedScenes;
        
        public SceneManager()
        {
            _loadedScenes = new Dictionary<string, Scene>();
        }

        public void LoadScene(string sceneName)
        {
            Console.WriteLine($"  - Loading scene: {sceneName}");
            
            if (_loadedScenes.ContainsKey(sceneName))
            {
                CurrentScene = _loadedScenes[sceneName];
            }
            else
            {
                // Create new empty scene
                CurrentScene = new Scene(sceneName);
                _loadedScenes[sceneName] = CurrentScene;
            }
            
            CurrentScene.OnLoad();
        }

        public void SaveScene(string sceneName)
        {
            if (CurrentScene != null)
            {
                Console.WriteLine($"Saving scene: {sceneName}.atlasscene");
                // Serialization would happen here
                FileSystem.AssetManager.SaveScene(CurrentScene, $"{sceneName}.atlasscene");
            }
        }

        public void UnloadAll()
        {
            Console.WriteLine("  - Unloading all scenes");
            foreach (var scene in _loadedScenes.Values)
            {
                scene.OnUnload();
            }
            _loadedScenes.Clear();
            CurrentScene = null;
        }
    }

    /// <summary>
    /// Represents a game scene with entities
    /// </summary>
    public class Scene
    {
        public string Name { get; private set; }
        public List<ECS.Entity> Entities { get; private set; }
        
        public Scene(string name)
        {
            Name = name;
            Entities = new List<ECS.Entity>();
        }

        public void OnLoad()
        {
            Console.WriteLine($"    Scene '{Name}' loaded with {Entities.Count} entities");
        }

        public void OnUnload()
        {
            // Cleanup
            foreach (var entity in Entities)
            {
                entity.Destroy();
            }
            Entities.Clear();
        }

        public void AddEntity(ECS.Entity entity)
        {
            Entities.Add(entity);
        }

        public void RemoveEntity(ECS.Entity entity)
        {
            Entities.Remove(entity);
            entity.Destroy();
        }
    }
}
