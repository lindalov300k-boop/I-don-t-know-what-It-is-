using OpenTK.Mathematics;
using System.Collections.Generic;
using System.Linq;

namespace BADGE.Core;

/// <summary>
/// Base class for all entities in BADGE scenes (Unity-compatible API)
/// </summary>
public class GameObject
{
    private static int _nextId = 0;
    
    public int InstanceId { get; private set; }
    public string Name { get; set; }
    public string Tag { get; set; } = "Untagged";
    public int Layer { get; set; } = 0;
    public bool ActiveSelf { get; private set; } = true;
    public bool ActiveInHierarchy => ActiveSelf && (Transform.Parent == null || Transform.Parent.GameObject.ActiveInHierarchy);
    
    public Transform Transform { get; private set; }
    public Scene? Scene { get; internal set; }
    
    private List<Component> _components = new();
    private GameObject? _parent;
    private List<GameObject> _children = new();
    
    public GameObject(string name = "GameObject")
    {
        InstanceId = _nextId++;
        Name = name;
        Transform = new Transform(this);
        _components.Add(Transform);
    }
    
    // Component Management (Unity API)
    public T AddComponent<T>() where T : Component, new()
    {
        var component = new T();
        component.GameObject = this;
        component.Transform = Transform;
        _components.Add(component);
        component.Awake();
        return component;
    }
    
    public T? GetComponent<T>() where T : Component
    {
        return _components.OfType<T>().FirstOrDefault();
    }
    
    public T[] GetComponents<T>() where T : Component
    {
        return _components.OfType<T>().ToArray();
    }
    
    public T? GetComponentInChildren<T>() where T : Component
    {
        var comp = GetComponent<T>();
        if (comp != null) return comp;
        
        foreach (var child in _children)
        {
            comp = child.GetComponentInChildren<T>();
            if (comp != null) return comp;
        }
        
        return null;
    }
    
    public T? GetComponentInParent<T>() where T : Component
    {
        var comp = GetComponent<T>();
        if (comp != null) return comp;
        
        return _parent?.GetComponentInParent<T>();
    }
    
    public bool TryGetComponent<T>(out T? component) where T : Component
    {
        component = GetComponent<T>();
        return component != null;
    }
    
    // Hierarchy Management
    public void SetParent(GameObject? parent, bool worldPositionStays = true)
    {
        if (_parent != null)
        {
            _parent._children.Remove(this);
        }
        
        _parent = parent;
        
        if (_parent != null)
        {
            _parent._children.Add(this);
            Transform.Parent = _parent.Transform;
        }
        else
        {
            Transform.Parent = null;
        }
    }
    
    public GameObject? GetParent() => _parent;
    public GameObject[] GetChildren() => _children.ToArray();
    public int GetChildCount() => _children.Count;
    public GameObject? GetChild(int index) => index >= 0 && index < _children.Count ? _children[index] : null;
    
    // Activation
    public void SetActive(bool active)
    {
        if (ActiveSelf == active) return;
        
        ActiveSelf = active;
        
        if (active)
        {
            foreach (var component in _components)
                component.OnEnable();
        }
        else
        {
            foreach (var component in _components)
                component.OnDisable();
        }
    }
    
    // Lifecycle
    public void Start()
    {
        if (!ActiveInHierarchy) return;
        
        foreach (var component in _components)
        {
            if (component.Enabled)
                component.Start();
        }
        
        foreach (var child in _children)
            child.Start();
    }
    
    public void Update(float deltaTime)
    {
        if (!ActiveInHierarchy) return;
        
        foreach (var component in _components)
        {
            if (component.Enabled)
                component.Update(deltaTime);
        }
        
        foreach (var child in _children)
            child.Update(deltaTime);
    }
    
    public void FixedUpdate(float fixedDeltaTime)
    {
        if (!ActiveInHierarchy) return;
        
        foreach (var component in _components)
        {
            if (component.Enabled)
                component.FixedUpdate(fixedDeltaTime);
        }
        
        foreach (var child in _children)
            child.FixedUpdate(fixedDeltaTime);
    }
    
    public void LateUpdate(float deltaTime)
    {
        if (!ActiveInHierarchy) return;
        
        foreach (var component in _components)
        {
            if (component.Enabled)
                component.LateUpdate(deltaTime);
        }
        
        foreach (var child in _children)
            child.LateUpdate(deltaTime);
    }
    
    public void OnDestroy()
    {
        foreach (var component in _components)
            component.OnDestroy();
            
        foreach (var child in _children.ToArray())
            Destroy(child);
    }
    
    // Static Methods (Unity API)
    public static GameObject? Find(string name)
    {
        // TODO: Implement scene-wide search
        return null;
    }
    
    public static GameObject[] FindGameObjectsWithTag(string tag)
    {
        // TODO: Implement tag-based search
        return Array.Empty<GameObject>();
    }
    
    public static GameObject CreatePrimitive(PrimitiveType type)
    {
        var go = new GameObject($"{type}");
        
        // Add MeshFilter and MeshRenderer
        var meshFilter = go.AddComponent<MeshFilter>();
        var meshRenderer = go.AddComponent<MeshRenderer>();
        
        // Create primitive mesh based on type
        meshFilter.Mesh = PrimitiveMeshFactory.CreatePrimitive(type);
        
        return go;
    }
    
    public static void Destroy(GameObject obj)
    {
        obj.OnDestroy();
        obj.Scene?.RemoveGameObject(obj);
    }
    
    public static void DontDestroyOnLoad(GameObject obj)
    {
        // TODO: Implement persistent objects across scenes
    }
}

public enum PrimitiveType
{
    Cube,
    Sphere,
    Cylinder,
    Capsule,
    Plane,
    Quad
}
