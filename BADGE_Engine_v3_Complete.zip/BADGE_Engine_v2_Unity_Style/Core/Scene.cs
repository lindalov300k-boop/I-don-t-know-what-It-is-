using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace BADGE.Core;

/// <summary>
/// Represents a scene in the BADGE engine (Unity-compatible API)
/// </summary>
public class Scene
{
    private static int _sceneCount = 0;
    
    public string Name { get; set; }
    public string Path { get; set; }
    public int BuildIndex { get; set; }
    public bool IsLoaded { get; internal set; }
    public bool IsDirty { get; set; }
    
    private List<GameObject> _rootGameObjects = new();
    private Dictionary<int, GameObject> _gameObjectsById = new();
    
    public Scene(string name = "Untitled")
    {
        Name = name;
        Path = "";
        BuildIndex = _sceneCount++;
        IsLoaded = false;
    }
    
    // GameObject Management
    public GameObject CreateGameObject(string name = "GameObject")
    {
        var go = new GameObject(name);
        go.Scene = this;
        _rootGameObjects.Add(go);
        _gameObjectsById[go.InstanceId] = go;
        IsDirty = true;
        return go;
    }
    
    public void AddGameObject(GameObject go)
    {
        if (go.Scene != null && go.Scene != this)
        {
            go.Scene.RemoveGameObject(go);
        }
        
        go.Scene = this;
        
        if (go.GetParent() == null && !_rootGameObjects.Contains(go))
        {
            _rootGameObjects.Add(go);
        }
        
        _gameObjectsById[go.InstanceId] = go;
        IsDirty = true;
    }
    
    public void RemoveGameObject(GameObject go)
    {
        _rootGameObjects.Remove(go);
        _gameObjectsById.Remove(go.InstanceId);
        go.Scene = null;
        IsDirty = true;
    }
    
    public GameObject[] GetRootGameObjects() => _rootGameObjects.ToArray();
    public GameObject[] GetAllGameObjects()
    {
        var allObjects = new List<GameObject>();
        foreach (var root in _rootGameObjects)
        {
            CollectGameObjectsRecursive(root, allObjects);
        }
        return allObjects.ToArray();
    }
    
    private void CollectGameObjectsRecursive(GameObject go, List<GameObject> list)
    {
        list.Add(go);
        foreach (var child in go.GetChildren())
        {
            CollectGameObjectsRecursive(child, list);
        }
    }
    
    public GameObject? FindGameObject(string name)
    {
        return GetAllGameObjects().FirstOrDefault(go => go.Name == name);
    }
    
    public GameObject? GetGameObjectById(int instanceId)
    {
        return _gameObjectsById.GetValueOrDefault(instanceId);
    }
    
    // Lifecycle
    public void Start()
    {
        foreach (var go in _rootGameObjects.ToArray())
        {
            go.Start();
        }
    }
    
    public void Update(float deltaTime)
    {
        foreach (var go in _rootGameObjects.ToArray())
        {
            go.Update(deltaTime);
        }
    }
    
    public void FixedUpdate(float fixedDeltaTime)
    {
        foreach (var go in _rootGameObjects.ToArray())
        {
            go.FixedUpdate(fixedDeltaTime);
        }
    }
    
    public void LateUpdate(float deltaTime)
    {
        foreach (var go in _rootGameObjects.ToArray())
        {
            go.LateUpdate(deltaTime);
        }
    }
    
    // Scene Management Static Methods
    public static Scene? GetActiveScene()
    {
        return SceneManager.GetActiveScene();
    }
    
    public static void LoadScene(string sceneName)
    {
        SceneManager.LoadScene(sceneName);
    }
    
    public static void LoadScene(int buildIndex)
    {
        SceneManager.LoadScene(buildIndex);
    }
    
    public static void LoadSceneAsync(string sceneName)
    {
        // TODO: Implement async loading
        SceneManager.LoadScene(sceneName);
    }
    
    // Serialization
    public string SerializeToJson()
    {
        var sceneData = new SceneData
        {
            Name = Name,
            RootObjects = _rootGameObjects.Select(SerializeGameObject).ToList()
        };
        
        return JsonConvert.SerializeObject(sceneData, Formatting.Indented);
    }
    
    private GameObjectData SerializeGameObject(GameObject go)
    {
        var data = new GameObjectData
        {
            Name = go.Name,
            Tag = go.Tag,
            Layer = go.Layer,
            Active = go.ActiveSelf,
            Components = new List<ComponentData>(),
            Children = go.GetChildren().Select(SerializeGameObject).ToList()
        };
        
        // Serialize Transform
        data.Components.Add(new ComponentData
        {
            Type = "Transform",
            Data = JsonConvert.SerializeObject(new
            {
                Position = go.Transform.LocalPosition,
                Rotation = go.Transform.LocalEulerAngles,
                Scale = go.Transform.LocalScale
            })
        });
        
        return data;
    }
    
    public static Scene? DeserializeFromJson(string json)
    {
        try
        {
            var sceneData = JsonConvert.DeserializeObject<SceneData>(json);
            if (sceneData == null) return null;
            
            var scene = new Scene(sceneData.Name);
            
            foreach (var objData in sceneData.RootObjects)
            {
                DeserializeGameObject(objData, scene, null);
            }
            
            return scene;
        }
        catch
        {
            return null;
        }
    }
    
    private static void DeserializeGameObject(GameObjectData data, Scene scene, GameObject? parent)
    {
        var go = scene.CreateGameObject(data.Name);
        go.Tag = data.Tag;
        go.Layer = data.Layer;
        go.SetActive(data.Active);
        
        if (parent != null)
        {
            go.SetParent(parent);
        }
        
        // Deserialize Transform
        var transformData = data.Components.FirstOrDefault(c => c.Type == "Transform");
        if (transformData != null)
        {
            dynamic? transform = JsonConvert.DeserializeObject(transformData.Data);
            if (transform != null)
            {
                go.Transform.LocalPosition = new OpenTK.Mathematics.Vector3(
                    (float)transform.Position.X,
                    (float)transform.Position.Y,
                    (float)transform.Position.Z
                );
                go.Transform.LocalEulerAngles = new OpenTK.Mathematics.Vector3(
                    (float)transform.Rotation.X,
                    (float)transform.Rotation.Y,
                    (float)transform.Rotation.Z
                );
                go.Transform.LocalScale = new OpenTK.Mathematics.Vector3(
                    (float)transform.Scale.X,
                    (float)transform.Scale.Y,
                    (float)transform.Scale.Z
                );
            }
        }
        
        // Deserialize children
        foreach (var childData in data.Children)
        {
            DeserializeGameObject(childData, scene, go);
        }
    }
}

// Serialization data structures
public class SceneData
{
    public string Name { get; set; } = "";
    public List<GameObjectData> RootObjects { get; set; } = new();
}

public class GameObjectData
{
    public string Name { get; set; } = "";
    public string Tag { get; set; } = "Untagged";
    public int Layer { get; set; }
    public bool Active { get; set; } = true;
    public List<ComponentData> Components { get; set; } = new();
    public List<GameObjectData> Children { get; set; } = new();
}

public class ComponentData
{
    public string Type { get; set; } = "";
    public string Data { get; set; } = "";
}
