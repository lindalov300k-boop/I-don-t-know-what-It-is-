namespace BADGE.Core;

/// <summary>
/// Base class for user scripts (Unity API compatible)
/// </summary>
public abstract class MonoBehaviour : Component
{
    // MonoBehaviour uses the same lifecycle as Component
    // Unity API compatible
}
