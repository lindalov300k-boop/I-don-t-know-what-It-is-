using System;
using BADGE.Core;

namespace BADGE.Editor
{
    public static class ResolutionPort
    {
        public static void SetCustomResolution(int width, int height, bool pixelPerfect)
        {
            Console.WriteLine($"Resolution: {width}x{height} (Pixel Perfect: {pixelPerfect})");
        }
        
        public static void SetRetroMode(RetroResolution preset)
        {
            switch(preset)
            {
                case RetroResolution.NES:
                    SetCustomResolution(256, 240, true);
                    break;
                case RetroResolution.GameBoy:
                    SetCustomResolution(160, 144, true);
                    break;
                case RetroResolution.SNES:
                    SetCustomResolution(256, 224, true);
                    break;
            }
        }
    }
    
    public enum RetroResolution
    {
        NES,
        GameBoy,
        SNES,
        Genesis
    }
}
