using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Editor.VideoEditor;

// ═══════════════════════════════════════════════════════════════════════
//  VIDEO CLIP
// ═══════════════════════════════════════════════════════════════════════
public class VideoClip
{
    public string Name       { get; set; } = "Clip";
    public string FilePath   { get; set; } = "";
    public float  SourceFps  { get; set; } = 24f;
    public int    FrameCount { get; set; }
    public int    Width      { get; set; }
    public int    Height     { get; set; }
    public float  Duration   => FrameCount / SourceFps;

    // Trim points (source frames)
    public int InPoint  { get; set; } = 0;
    public int OutPoint { get; set; }

    // Color grade applied to this clip
    public ClipColorGrade ColorGrade { get; } = new();

    public VideoClip() { OutPoint = FrameCount; }
}

// ═══════════════════════════════════════════════════════════════════════
//  COLOR GRADING
// ═══════════════════════════════════════════════════════════════════════
public class ClipColorGrade
{
    // Lift/Gamma/Gain (shadow/midtone/highlight) colour wheels
    public Vector4 Lift    { get; set; } = Vector4.One * 0f;
    public Vector4 Gamma   { get; set; } = Vector4.One;
    public Vector4 Gain    { get; set; } = Vector4.One;

    // HSL
    public float Hue       { get; set; } = 0f;    // -180 to 180
    public float Saturation{ get; set; } = 1f;
    public float Luminance { get; set; } = 0f;    // -1 to 1

    // Contrast / Brightness / Exposure
    public float Contrast  { get; set; } = 1f;
    public float Brightness{ get; set; } = 0f;
    public float Exposure  { get; set; } = 0f;    // EV stops

    // Temperature / Tint (Kelvin offset)
    public float Temperature { get; set; } = 0f;
    public float Tint        { get; set; } = 0f;

    // Vignette
    public float VignetteStrength { get; set; } = 0f;
    public float VignetteRadius   { get; set; } = 0.7f;

    // LUT
    public string? LutPath  { get; set; }
    public float   LutMix   { get; set; } = 1f;

    // Curves (list of (x, y) control points, x/y in 0–1)
    public List<Vector2> LuminanceCurve { get; } = new() { new(0,0), new(1,1) };
    public List<Vector2> RedCurve       { get; } = new() { new(0,0), new(1,1) };
    public List<Vector2> GreenCurve     { get; } = new() { new(0,0), new(1,1) };
    public List<Vector2> BlueCurve      { get; } = new() { new(0,0), new(1,1) };

    public void AddLuminanceCurvePoint(Vector2 p)
    {
        LuminanceCurve.Add(p);
        LuminanceCurve.Sort((a, b) => a.X.CompareTo(b.X));
    }

    public void Reset()
    {
        Lift = Vector4.Zero; Gamma = Vector4.One; Gain = Vector4.One;
        Hue = 0f; Saturation = 1f; Luminance = 0f;
        Contrast = 1f; Brightness = 0f; Exposure = 0f;
        Temperature = 0f; Tint = 0f;
        VignetteStrength = 0f;
    }

    /// <summary>Sample a curve at x (0–1) using catmull-rom interpolation.</summary>
    public static float SampleCurve(List<Vector2> pts, float x)
    {
        if (pts.Count == 0) return x;
        if (pts.Count == 1) return pts[0].Y;
        for (int i = 0; i < pts.Count - 1; i++)
        {
            if (x >= pts[i].X && x <= pts[i + 1].X)
            {
                float t = (x - pts[i].X) / (pts[i + 1].X - pts[i].X);
                return MathHelper.Lerp(pts[i].Y, pts[i + 1].Y, t);
            }
        }
        return pts[^1].Y;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  TRANSITIONS
// ═══════════════════════════════════════════════════════════════════════
public enum TransitionType { Cut, Dissolve, Fade, Wipe, DipToBlack, DipToWhite, Push, Slide }

public class Transition
{
    public TransitionType Type     { get; set; } = TransitionType.Cut;
    public float          Duration { get; set; } = 0.5f;  // seconds
    public string         Direction{ get; set; } = "Right"; // for wipe/push
}

// ═══════════════════════════════════════════════════════════════════════
//  TIMELINE CLIP  (placed clip on a track)
// ═══════════════════════════════════════════════════════════════════════
public class TimelineClip
{
    public VideoClip   Source     { get; set; }
    public float       StartSec   { get; set; }   // position on timeline
    public float       Duration   => (Source.OutPoint - Source.InPoint) / Source.SourceFps;
    public float       EndSec     => StartSec + Duration;
    public Transition? TransIn    { get; set; }
    public Transition? TransOut   { get; set; }

    public TimelineClip(VideoClip src, float at)
    {
        Source   = src;
        StartSec = at;
    }

    public bool ContainsTime(float t) => t >= StartSec && t < EndSec;

    public float GetLocalTime(float globalTime) => globalTime - StartSec;

    public float GetProgress(float globalTime)
        => Duration > 0f ? GetLocalTime(globalTime) / Duration : 0f;
}

// ═══════════════════════════════════════════════════════════════════════
//  TIMELINE TRACK
// ═══════════════════════════════════════════════════════════════════════
public enum TrackType { Video, Audio, Subtitle, Effect }

public class TimelineTrack
{
    public string     Name   { get; set; } = "V1";
    public TrackType  Type   { get; set; } = TrackType.Video;
    public bool       Locked { get; set; }
    public bool       Muted  { get; set; }
    public float      Height { get; set; } = 60f;  // UI height in px

    public List<TimelineClip> Clips { get; } = new();

    public void AddClip(TimelineClip c) => Clips.Add(c);
    public void RemoveClip(TimelineClip c) => Clips.Remove(c);

    public TimelineClip? GetClipAt(float time)
        => Clips.Find(c => c.ContainsTime(time));

    public float GetDuration()
    {
        float max = 0f;
        foreach (var c in Clips) max = MathF.Max(max, c.EndSec);
        return max;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  VIDEO TIMELINE  (DaVinci-style)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Full non-linear video editor timeline model.
/// Tracks, clips, colour grading, transitions, subtitles, playhead.
/// </summary>
public class VideoTimeline
{
    public float  TimelineScale { get; set; } = 100f;  // px per second
    public float  PlayHead      { get; private set; }
    public bool   IsPlaying     { get; private set; }
    public float  LoopStart     { get; set; }
    public float  LoopEnd       { get; set; } = 60f;
    public bool   LoopEnabled   { get; set; }
    public float  ProjectFps    { get; set; } = 24f;

    public List<TimelineTrack>  Tracks     { get; } = new();
    public List<SubtitleEntry>  Subtitles  { get; } = new();
    public ClipColorGrade       GlobalGrade{ get; } = new();

    public event Action<float>? OnPlayHeadMoved;

    public VideoTimeline()
    {
        Tracks.Add(new TimelineTrack { Name="V1", Type=TrackType.Video });
        Tracks.Add(new TimelineTrack { Name="V2", Type=TrackType.Video });
        Tracks.Add(new TimelineTrack { Name="A1", Type=TrackType.Audio });
        Tracks.Add(new TimelineTrack { Name="A2", Type=TrackType.Audio });
    }

    // ── Transport ─────────────────────────────────────────────────
    public void Play()  => IsPlaying = true;
    public void Pause() => IsPlaying = false;
    public void Stop()  { IsPlaying = false; SeekTo(0f); }

    public void SeekTo(float time)
    {
        PlayHead = Math.Clamp(time, 0f, GetDuration());
        OnPlayHeadMoved?.Invoke(PlayHead);
    }

    public void Tick(float dt)
    {
        if (!IsPlaying) return;
        PlayHead += dt;
        if (LoopEnabled && PlayHead >= LoopEnd) PlayHead = LoopStart;
        OnPlayHeadMoved?.Invoke(PlayHead);
    }

    // ── Editing ───────────────────────────────────────────────────
    public TimelineClip AddClip(VideoClip source, int trackIdx, float atTime)
    {
        if (trackIdx < 0 || trackIdx >= Tracks.Count)
            Tracks.Add(new TimelineTrack { Name=$"V{trackIdx+1}" });

        var c = new TimelineClip(source, atTime);
        Tracks[trackIdx].AddClip(c);
        return c;
    }

    public void Cut(int trackIdx, float time)
    {
        if (trackIdx >= Tracks.Count) return;
        var clip = Tracks[trackIdx].GetClipAt(time);
        if (clip == null) return;

        // Split at time
        float localTime = clip.GetLocalTime(time);
        int   cutFrame  = (int)(localTime * clip.Source.SourceFps);

        var after = new TimelineClip(clip.Source, time)
        {
            Source = { InPoint = clip.Source.InPoint + cutFrame }
        };
        clip.Source.OutPoint = clip.Source.InPoint + cutFrame;
        Tracks[trackIdx].AddClip(after);
    }

    public void Delete(int trackIdx, TimelineClip clip)
    {
        if (trackIdx < Tracks.Count)
            Tracks[trackIdx].RemoveClip(clip);
    }

    // ── Subtitles ─────────────────────────────────────────────────
    public void AddSubtitle(float start, float end, string text)
        => Subtitles.Add(new SubtitleEntry { StartSec=start, EndSec=end, Text=text });

    public SubtitleEntry? GetSubtitleAt(float t)
        => Subtitles.Find(s => t >= s.StartSec && t <= s.EndSec);

    // ── Query ─────────────────────────────────────────────────────
    public float GetDuration()
    {
        float max = 0f;
        foreach (var t in Tracks) max = MathF.Max(max, t.GetDuration());
        return max;
    }

    public List<TimelineClip> GetActiveClips(float time)
    {
        var active = new List<TimelineClip>();
        foreach (var t in Tracks) if (!t.Muted)
        {
            var c = t.GetClipAt(time);
            if (c != null) active.Add(c);
        }
        return active;
    }

    // ── Export stub ───────────────────────────────────────────────
    public VideoExportSettings ExportSettings { get; } = new();

    public void Export(string path)
    {
        Console.WriteLine($"[VideoTimeline] Exporting to {path}...");
        Console.WriteLine($"  Resolution: {ExportSettings.Width}×{ExportSettings.Height}");
        Console.WriteLine($"  FPS: {ExportSettings.Fps}  Codec: {ExportSettings.Codec}");
        Console.WriteLine($"  Duration: {GetDuration():0.00}s");
        Console.WriteLine($"[VideoTimeline] Export complete (stub — integrate with ffmpeg for actual encoding)");
    }
}

public class SubtitleEntry
{
    public float  StartSec { get; set; }
    public float  EndSec   { get; set; }
    public string Text     { get; set; } = "";
    public string Font     { get; set; } = "Arial";
    public float  FontSize { get; set; } = 36f;
    public Vector4 Color   { get; set; } = Vector4.One;
}

public class VideoExportSettings
{
    public int    Width     { get; set; } = 1920;
    public int    Height    { get; set; } = 1080;
    public float  Fps       { get; set; } = 24f;
    public string Codec     { get; set; } = "H.264";
    public int    Bitrate   { get; set; } = 8000;  // kbps
    public string Container { get; set; } = "MP4";
    public string AudioCodec{ get; set; } = "AAC";
}

// ═══════════════════════════════════════════════════════════════════════
//  FRAME CAPTURE
// ═══════════════════════════════════════════════════════════════════════
/// <summary>Captures frames from the engine's OpenGL framebuffer for video export.</summary>
public static class FrameCapture
{
    private static bool _isCapturing;
    private static float _fps;
    private static string _outputPath = "";
    private static List<byte[]> _frames = new();

    public static bool IsCapturing => _isCapturing;

    public static void BeginCapture(string outputPath, float fps = 24f)
    {
        _outputPath = outputPath;
        _fps        = fps;
        _frames.Clear();
        _isCapturing = true;
        Console.WriteLine($"[FrameCapture] Recording at {fps} FPS → {outputPath}");
    }

    public static void CaptureFrame(int width, int height)
    {
        if (!_isCapturing) return;
        // In a real implementation: GL.ReadPixels → byte[] and store/stream
        var frame = new byte[width * height * 3];
        _frames.Add(frame);
    }

    public static void EndCapture()
    {
        _isCapturing = false;
        Console.WriteLine($"[FrameCapture] Captured {_frames.Count} frames. Write to {_outputPath} (pipe to ffmpeg).");
        _frames.Clear();
    }
}
