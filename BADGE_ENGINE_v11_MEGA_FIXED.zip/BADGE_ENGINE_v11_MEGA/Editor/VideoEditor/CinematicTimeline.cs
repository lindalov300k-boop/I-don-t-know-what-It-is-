using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Editor.VideoEditor;

// ═══════════════════════════════════════════════════════════════════════
//  CAMERA SHOT
// ═══════════════════════════════════════════════════════════════════════
public enum ShotType { Static, Pan, Tilt, Dolly, Orbit, Handheld, FollowTarget }

public class CameraShot
{
    public string     Name        { get; set; } = "Shot";
    public ShotType   Type        { get; set; } = ShotType.Static;
    public float      StartTime   { get; set; }
    public float      Duration    { get; set; } = 3f;
    public float      EndTime     => StartTime + Duration;

    // Camera position keyframes
    public List<CameraKeyframe> Keyframes { get; } = new();

    public float FieldOfView     { get; set; } = 60f;
    public float NearFOV         { get; set; } = 0.3f;
    public float FarFOV          { get; set; } = 1000f;

    // Focus
    public float FocusDistance   { get; set; } = 10f;
    public float Aperture        { get; set; } = 2.8f;   // f-stop

    // Handheld shake
    public float ShakeAmplitude  { get; set; } = 0.02f;
    public float ShakeFrequency  { get; set; } = 5f;

    // Target tracking (for FollowTarget)
    public string? TargetName    { get; set; }
    public Vector3 TargetOffset  { get; set; } = new(0f, 1.6f, 0f);

    public CameraKeyframe? GetKeyframeAtTime(float t)
    {
        if (Keyframes.Count == 0) return null;
        foreach (var kf in Keyframes)
            if (MathF.Abs(kf.Time - (t - StartTime)) < 0.05f) return kf;
        return null;
    }

    public (Vector3 pos, Quaternion rot) EvaluateAt(float t)
    {
        float localT = t - StartTime;
        if (Keyframes.Count == 0)
            return (Vector3.Zero, Quaternion.Identity);

        if (Keyframes.Count == 1)
            return (Keyframes[0].Position, Keyframes[0].Rotation);

        // Find surrounding keyframes
        CameraKeyframe? prev = null, next = null;
        foreach (var kf in Keyframes)
        {
            if (kf.Time <= localT) prev = kf;
            else if (next == null && kf.Time > localT) next = kf;
        }

        if (prev == null) return (Keyframes[0].Position, Keyframes[0].Rotation);
        if (next == null) return (Keyframes[^1].Position, Keyframes[^1].Rotation);

        float span = next.Time - prev.Time;
        float frac = span > 0f ? (localT - prev.Time) / span : 0f;
        frac       = Core.EaseFunc.Evaluate(frac, prev.EaseOut);

        var pos = Vector3.Lerp(prev.Position, next.Position, frac);
        var rot = Quaternion.Slerp(prev.Rotation, next.Rotation, frac);

        // Handheld shake
        if (Type == ShotType.Handheld)
        {
            float shake = ShakeAmplitude;
            pos += new Vector3(
                MathF.Sin(t * ShakeFrequency * 1.1f) * shake,
                MathF.Sin(t * ShakeFrequency * 0.8f) * shake,
                MathF.Sin(t * ShakeFrequency * 1.3f) * shake * 0.3f);
        }

        return (pos, rot);
    }
}

public class CameraKeyframe
{
    public float     Time     { get; set; }
    public Vector3   Position { get; set; }
    public Quaternion Rotation { get; set; } = Quaternion.Identity;
    public Core.Ease EaseOut  { get; set; } = Core.Ease.Linear;
}

// ═══════════════════════════════════════════════════════════════════════
//  CUTSCENE EVENT
// ═══════════════════════════════════════════════════════════════════════
public enum CutsceneEventType
{
    DialogueLine, SoundEffect, Music, Letterbox, FadeIn, FadeOut,
    SubtitleOn, SubtitleOff, CameraShake, SlowMotion, GameplayResume
}

public class CutsceneEvent
{
    public float           Time     { get; set; }
    public CutsceneEventType Type   { get; set; }
    public string          Data     { get; set; } = "";    // event-specific payload (JSON or string)
    public float           Duration { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════
//  CINEMATIC TIMELINE
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Sequences camera shots and events for in-engine cutscenes.
/// NEEDED BY: GTA SA mission briefings, Limbo story moments,
///            any game with cinematics.
/// </summary>
public class CinematicTimeline
{
    public string            Name          { get; set; } = "Cutscene";
    public float             Duration      { get; set; }
    public bool              SkippableByPlayer { get; set; } = true;
    public bool              HideHUD       { get; set; } = true;
    public bool              DisableInput  { get; set; } = true;

    public List<CameraShot>   Shots  { get; } = new();
    public List<CutsceneEvent> Events { get; } = new();

    // Playback state
    public float  PlayHead    { get; private set; }
    public bool   IsPlaying   { get; private set; }
    public bool   IsComplete  => PlayHead >= Duration;

    public event Action?            OnComplete;
    public event Action<CutsceneEvent>? OnEventFired;

    private readonly HashSet<CutsceneEvent> _firedEvents = new();

    // ── Authoring ─────────────────────────────────────────────────
    public CameraShot AddShot(string name, float start, float duration, ShotType type = ShotType.Static)
    {
        var shot = new CameraShot { Name=name, StartTime=start, Duration=duration, Type=type };
        Shots.Add(shot);
        Duration = MathF.Max(Duration, shot.EndTime);
        return shot;
    }

    public void AddEvent(float time, CutsceneEventType type, string data = "", float dur = 0f)
        => Events.Add(new CutsceneEvent { Time=time, Type=type, Data=data, Duration=dur });

    // ── Playback ──────────────────────────────────────────────────
    public void Play()   { IsPlaying = true; _firedEvents.Clear(); }
    public void Pause()  => IsPlaying = false;
    public void Stop()   { IsPlaying = false; PlayHead = 0f; }
    public void Skip()   { PlayHead = Duration; Finish(); }

    public void Tick(float dt)
    {
        if (!IsPlaying) return;
        PlayHead += dt;

        // Fire events
        foreach (var evt in Events)
        {
            if (evt.Time <= PlayHead && !_firedEvents.Contains(evt))
            {
                _firedEvents.Add(evt);
                OnEventFired?.Invoke(evt);
            }
        }

        if (PlayHead >= Duration) Finish();
    }

    private void Finish()
    {
        IsPlaying = false;
        OnComplete?.Invoke();
    }

    // ── Query ─────────────────────────────────────────────────────
    public CameraShot? GetActiveShot()
        => Shots.Find(s => PlayHead >= s.StartTime && PlayHead < s.EndTime);

    public (Vector3 pos, Quaternion rot) GetCameraTransform()
    {
        var shot = GetActiveShot();
        return shot != null ? shot.EvaluateAt(PlayHead) : (Vector3.Zero, Quaternion.Identity);
    }

    public float GetLetterboxAmount()
    {
        // Check for letterbox events
        foreach (var evt in Events)
        {
            if (evt.Type == CutsceneEventType.Letterbox &&
                PlayHead >= evt.Time && PlayHead <= evt.Time + evt.Duration)
                return 1f;
        }
        return HideHUD ? 1f : 0f;
    }

    // ── Fade ──────────────────────────────────────────────────────
    public float GetFadeAmount()
    {
        foreach (var evt in Events)
        {
            float t = PlayHead - evt.Time;
            if (t < 0f || t > evt.Duration) continue;
            float frac = t / (evt.Duration + 0.001f);
            if (evt.Type == CutsceneEventType.FadeIn)  return 1f - frac;
            if (evt.Type == CutsceneEventType.FadeOut) return frac;
        }
        return 0f;
    }
}
