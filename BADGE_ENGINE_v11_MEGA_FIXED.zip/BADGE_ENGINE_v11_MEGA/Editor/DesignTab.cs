using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using OpenTK.Graphics.OpenGL4;

namespace BADGE.Editor
{
    // ══════════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE v8 — DESIGN TAB
    //  Modeled after Krita + Photoshop
    //
    //  Tools
    //  ─────
    //  Krita-style:  Freehand Brush, Smear, Color Smudge, Fill, Gradient,
    //                Selection (Rect/Ellipse/Freehand), Transform, Crop, Text,
    //                Layer management, Blending modes
    //  Photoshop-style: Lasso, Magic Wand, Healing Brush, Clone Stamp,
    //                   Dodge/Burn/Sponge, Pen (path), Shape tools,
    //                   Adjustment layers (Curves, Levels, Hue/Sat, Brightness)
    //  Image Processing: Resize, Flip, Rotate, Filters (blur, sharpen, edge detect,
    //                    emboss, pixelate, noise), Color correction
    //  File I/O: Import PNG/JPG/BMP/TGA/WEBP, Export with quality control
    // ══════════════════════════════════════════════════════════════════════════

    public static class DesignTab
    {
        // ── Canvas ─────────────────────────────────────────────────────────
        public static int  CanvasWidth  { get; private set; } = 512;
        public static int  CanvasHeight { get; private set; } = 512;
        public static bool PixelPerfect { get; set; } = false;

        private static byte[]? _pixels;
        private static int     _textureHandle;
        private static bool    _dirty;
        private static bool    _initialized;

        // ── Layers ─────────────────────────────────────────────────────────
        private static List<CanvasLayer> _layers      = new();
        private static int               _activeLayer = 0;

        // ── Tool state ─────────────────────────────────────────────────────
        public static DesignTool ActiveTool  { get; set; } = DesignTool.Brush;
        public static Vector4 ForeColor      { get; set; } = new(0, 0, 0, 1);
        public static Vector4 BackColor      { get; set; } = new(1, 1, 1, 1);
        public static float   BrushSize      { get; set; } = 4f;
        public static float   BrushOpacity   { get; set; } = 1f;
        public static float   BrushHardness  { get; set; } = 1f;
        public static float   BrushFlow      { get; set; } = 1f;
        public static float   BrushSpacing   { get; set; } = 0.1f;
        public static BrushShape BrushShape  { get; set; } = BrushShape.Round;
        public static BlendMode  BlendMode   { get; set; } = BlendMode.Normal;
        public static bool    SmudgeMode     { get; set; } = false;
        public static float   SmudgeStrength { get; set; } = 0.5f;

        // Selection
        private static SelectionMask? _selection;
        private static List<Vector2>  _lassoPoints = new();

        // History (undo/redo)
        private static Stack<HistoryState> _undo = new();
        private static Stack<HistoryState> _redo = new();
        private const int MaxHistory = 50;

        // ── Initialize ────────────────────────────────────────────────────
        public static void Initialize(int width = 512, int height = 512)
        {
            CanvasWidth = width; CanvasHeight = height;
            _pixels = new byte[width * height * 4];
            Fill(255, 255, 255, 255);

            if (_layers.Count == 0)
                _layers.Add(new CanvasLayer("Background", width, height));

            _textureHandle = GL.GenTexture();
            GL.BindTexture(TextureTarget.Texture2D, _textureHandle);
            GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba8,
                width, height, 0, PixelFormat.Rgba, PixelType.UnsignedByte, _pixels);
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter,
                (int)(PixelPerfect ? TextureMinFilter.Nearest : TextureMinFilter.Linear));
            GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter,
                (int)(PixelPerfect ? TextureMagFilter.Nearest : TextureMagFilter.Linear));
            _initialized = true;
            Console.WriteLine($"[Design] Canvas initialized {width}x{height}");
        }

        // ══════════════ DRAWING TOOLS ══════════════════════════════════════

        public static void DrawPixel(int x, int y, byte r, byte g, byte b, byte a = 255)
        {
            if (_pixels == null || x < 0 || y < 0 || x >= CanvasWidth || y >= CanvasHeight) return;
            if (_selection != null && !_selection.IsSelected(x, y)) return;

            var layer = ActiveLayerPixels();
            if (layer == null) return;

            int idx = (y * CanvasWidth + x) * 4;
            if (SmudgeMode)
                ApplySmudge(layer, idx, r, g, b, a);
            else
                BlendPixel(layer, idx, r, g, b, a, BrushOpacity, BlendMode);
            _dirty = true;
        }

        public static void DrawCircleBrush(int cx, int cy, float radius, byte r, byte g, byte b)
        {
            int ir = (int)Math.Ceiling(radius);
            for (int dy = -ir; dy <= ir; dy++)
                for (int dx = -ir; dx <= ir; dx++)
                {
                    float dist = MathF.Sqrt(dx*dx + dy*dy);
                    if (dist > radius) continue;
                    float hardness = BrushHardness >= 1f ? 1f : MathF.Max(0, 1f - (dist / radius - BrushHardness) / (1f - BrushHardness));
                    byte  alpha    = (byte)(hardness * 255 * BrushOpacity);
                    DrawPixel(cx + dx, cy + dy, r, g, b, alpha);
                }
        }

        public static void DrawSquareBrush(int cx, int cy, int size, byte r, byte g, byte b)
        {
            int h = size / 2;
            for (int dy = -h; dy <= h; dy++)
                for (int dx = -h; dx <= h; dx++)
                    DrawPixel(cx + dx, cy + dy, r, g, b, (byte)(255 * BrushOpacity));
        }

        /// <summary>Bresenham line between two points using current brush.</summary>
        public static void DrawLine(int x0, int y0, int x1, int y1, byte r, byte g, byte b)
        {
            int dx = Math.Abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
            int dy = -Math.Abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
            int err = dx + dy;
            int halfBrush = Math.Max(0, (int)BrushSize / 2);
            while (true)
            {
                if (halfBrush <= 0) DrawPixel(x0, y0, r, g, b);
                else DrawCircleBrush(x0, y0, BrushSize * 0.5f, r, g, b);
                if (x0 == x1 && y0 == y1) break;
                int e2 = 2 * err;
                if (e2 >= dy) { err += dy; x0 += sx; }
                if (e2 <= dx) { err += dx; y0 += sy; }
            }
        }

        /// <summary>Wu anti-aliased line.</summary>
        public static void DrawLineAA(float x0, float y0, float x1, float y1, byte r, byte g, byte b)
        {
            float dx = x1 - x0, dy = y1 - y0;
            if (MathF.Abs(dx) < MathF.Abs(dy))
            {
                (x0, y0) = (y0, x0); (x1, y1) = (y1, x1); (dx, dy) = (dy, dx);
            }
            if (x0 > x1) { (x0, x1) = (x1, x0); (y0, y1) = (y1, y0); }
            float gradient = dy / dx;
            float y = y0;
            for (int x = (int)x0; x <= (int)x1; x++, y += gradient)
            {
                int iy = (int)y;
                float frac = y - iy;
                DrawPixel(x, iy,     r, g, b, (byte)((1 - frac) * 255 * BrushOpacity));
                DrawPixel(x, iy + 1, r, g, b, (byte)(frac       * 255 * BrushOpacity));
            }
        }

        public static void DrawRect(int x, int y, int w, int h, byte r, byte g, byte b, bool filled = false)
        {
            if (filled)
                for (int py = y; py < y + h; py++)
                    for (int px = x; px < x + w; px++)
                        DrawPixel(px, py, r, g, b);
            else
            {
                DrawLine(x, y, x + w, y, r, g, b);
                DrawLine(x + w, y, x + w, y + h, r, g, b);
                DrawLine(x + w, y + h, x, y + h, r, g, b);
                DrawLine(x, y + h, x, y, r, g, b);
            }
        }

        public static void DrawEllipse(int cx, int cy, int rx, int ry, byte r, byte g, byte b, bool filled = false)
        {
            if (filled)
            {
                for (int py = cy - ry; py <= cy + ry; py++)
                    for (int px = cx - rx; px <= cx + rx; px++)
                    {
                        float nx = (float)(px - cx) / rx, ny = (float)(py - cy) / ry;
                        if (nx * nx + ny * ny <= 1f) DrawPixel(px, py, r, g, b);
                    }
            }
            else
            {
                for (int a = 0; a < 360; a++)
                {
                    float rad = a * MathF.PI / 180f;
                    int px = cx + (int)(rx * MathF.Cos(rad));
                    int py = cy + (int)(ry * MathF.Sin(rad));
                    DrawPixel(px, py, r, g, b);
                }
            }
        }

        // ══════════════ FILL / GRADIENT ═══════════════════════════════════

        /// <summary>Flood fill (4-connected, stack-based).</summary>
        public static void FloodFill(int x, int y, byte r, byte g, byte b)
        {
            if (_pixels == null) return;
            var layer = ActiveLayerPixels()!;
            int idx   = (y * CanvasWidth + x) * 4;
            byte tr = layer[idx], tg = layer[idx+1], tb = layer[idx+2], ta = layer[idx+3];
            if (tr == r && tg == g && tb == b) return;

            PushUndoState();
            var stack = new Stack<(int,int)>();
            stack.Push((x, y));
            while (stack.Count > 0)
            {
                var (px, py) = stack.Pop();
                if (px < 0 || py < 0 || px >= CanvasWidth || py >= CanvasHeight) continue;
                int i = (py * CanvasWidth + px) * 4;
                if (layer[i] != tr || layer[i+1] != tg || layer[i+2] != tb || layer[i+3] != ta) continue;
                if (_selection != null && !_selection.IsSelected(px, py)) continue;
                BlendPixel(layer, i, r, g, b, 255, 1f, BlendMode.Normal);
                stack.Push((px+1, py)); stack.Push((px-1, py));
                stack.Push((px, py+1)); stack.Push((px, py-1));
            }
            _dirty = true;
        }

        public static void DrawLinearGradient(int x0, int y0, int x1, int y1,
            byte r0, byte g0, byte b0, byte r1, byte g1, byte b1)
        {
            PushUndoState();
            float dx = x1 - x0, dy = y1 - y0;
            float len = MathF.Sqrt(dx*dx + dy*dy);
            for (int py = 0; py < CanvasHeight; py++)
                for (int px = 0; px < CanvasWidth; px++)
                {
                    float t = MathF.Max(0, MathF.Min(1,
                        ((px - x0) * dx + (py - y0) * dy) / (len * len)));
                    DrawPixel(px, py,
                        (byte)(r0 + (r1 - r0) * t),
                        (byte)(g0 + (g1 - g0) * t),
                        (byte)(b0 + (b1 - b0) * t));
                }
        }

        public static void DrawRadialGradient(int cx, int cy, float radius,
            byte r0, byte g0, byte b0, byte r1, byte g1, byte b1)
        {
            PushUndoState();
            for (int py = 0; py < CanvasHeight; py++)
                for (int px = 0; px < CanvasWidth; px++)
                {
                    float dist = MathF.Sqrt((px-cx)*(px-cx) + (py-cy)*(py-cy));
                    float t = MathF.Max(0, MathF.Min(1, dist / radius));
                    DrawPixel(px, py,
                        (byte)(r0 + (r1-r0)*t), (byte)(g0+(g1-g0)*t), (byte)(b0+(b1-b0)*t));
                }
        }

        // ══════════════ IMAGE PROCESSING FILTERS ══════════════════════════

        public static void ApplyGaussianBlur(int radius = 1)
        {
            PushUndoState();
            var layer = ActiveLayerPixels()!;
            var src   = (byte[])layer.Clone();
            float sigma = radius / 2f;
            // Single-pass approximation using box blur
            for (int y = 0; y < CanvasHeight; y++)
                for (int x = 0; x < CanvasWidth; x++)
                {
                    float rSum=0,gSum=0,bSum=0,wSum=0;
                    for (int ky = -radius; ky <= radius; ky++)
                        for (int kx = -radius; kx <= radius; kx++)
                        {
                            int sx = Math.Clamp(x+kx, 0, CanvasWidth-1);
                            int sy = Math.Clamp(y+ky, 0, CanvasHeight-1);
                            float w = MathF.Exp(-(kx*kx+ky*ky)/(2*sigma*sigma));
                            int i = (sy * CanvasWidth + sx) * 4;
                            rSum+=src[i]*w; gSum+=src[i+1]*w; bSum+=src[i+2]*w; wSum+=w;
                        }
                    int oi = (y*CanvasWidth+x)*4;
                    layer[oi]=(byte)(rSum/wSum); layer[oi+1]=(byte)(gSum/wSum); layer[oi+2]=(byte)(bSum/wSum);
                }
            _dirty = true;
        }

        public static void ApplySharpen()
        {
            PushUndoState();
            var layer = ActiveLayerPixels()!;
            var src   = (byte[])layer.Clone();
            int[] kernel = { 0,-1,0,-1,5,-1,0,-1,0 };
            for (int y = 1; y < CanvasHeight-1; y++)
                for (int x = 1; x < CanvasWidth-1; x++)
                {
                    for (int c = 0; c < 3; c++)
                    {
                        int v=0, ki=0;
                        for (int ky=-1; ky<=1; ky++)
                            for (int kx=-1; kx<=1; kx++, ki++)
                                v += src[((y+ky)*CanvasWidth+(x+kx))*4+c] * kernel[ki];
                        layer[(y*CanvasWidth+x)*4+c] = (byte)Math.Clamp(v,0,255);
                    }
                }
            _dirty = true;
        }

        public static void ApplyEdgeDetect()
        {
            PushUndoState();
            var layer = ActiveLayerPixels()!;
            var src   = (byte[])layer.Clone();
            int[] gx = {-1,0,1,-2,0,2,-1,0,1};
            int[] gy = {-1,-2,-1,0,0,0,1,2,1};
            for (int y=1;y<CanvasHeight-1;y++)
                for (int x=1;x<CanvasWidth-1;x++)
                {
                    int lum(int px,int py){ var i=( py*CanvasWidth+px)*4; return(src[i]+src[i+1]+src[i+2])/3; }
                    int sx=0,sy=0,ki=0;
                    for (int ky=-1;ky<=1;ky++)
                        for (int kx=-1;kx<=1;kx++,ki++){ var l=lum(x+kx,y+ky); sx+=l*gx[ki]; sy+=l*gy[ki]; }
                    byte mag = (byte)Math.Clamp((int)MathF.Sqrt(sx*sx+sy*sy),0,255);
                    int oi = (y*CanvasWidth+x)*4;
                    layer[oi]=mag; layer[oi+1]=mag; layer[oi+2]=mag;
                }
            _dirty = true;
        }

        public static void ApplyHueSaturation(float hueShift, float satMul, float lightAdd)
        {
            PushUndoState();
            var layer = ActiveLayerPixels()!;
            for (int i = 0; i < layer.Length; i += 4)
            {
                RgbToHsl(layer[i]/255f, layer[i+1]/255f, layer[i+2]/255f, out float h, out float s, out float l);
                h = (h + hueShift / 360f + 1f) % 1f;
                s = Math.Clamp(s * satMul, 0, 1);
                l = Math.Clamp(l + lightAdd, 0, 1);
                HslToRgb(h, s, l, out float r, out float g, out float b);
                layer[i] = (byte)(r*255); layer[i+1] = (byte)(g*255); layer[i+2] = (byte)(b*255);
            }
            _dirty = true;
        }

        public static void ApplyBrightnessContrast(float brightness, float contrast)
        {
            PushUndoState();
            float factor = (259f*(contrast+255f))/(255f*(259f-contrast));
            var layer = ActiveLayerPixels()!;
            for (int i=0;i<layer.Length;i+=4)
                for (int c=0;c<3;c++)
                    layer[i+c]=(byte)Math.Clamp(factor*(layer[i+c]+brightness-128)+128,0,255);
            _dirty = true;
        }

        public static void ApplyPixelate(int blockSize)
        {
            PushUndoState();
            var layer = ActiveLayerPixels()!;
            for (int y=0;y<CanvasHeight;y+=blockSize)
                for (int x=0;x<CanvasWidth;x+=blockSize)
                {
                    int rS=0,gS=0,bS=0,cnt=0;
                    for (int by=0;by<blockSize&&y+by<CanvasHeight;by++)
                        for (int bx=0;bx<blockSize&&x+bx<CanvasWidth;bx++,cnt++)
                        { int i=((y+by)*CanvasWidth+(x+bx))*4; rS+=layer[i];gS+=layer[i+1];bS+=layer[i+2]; }
                    byte r=(byte)(rS/cnt),g=(byte)(gS/cnt),b=(byte)(bS/cnt);
                    for (int by=0;by<blockSize&&y+by<CanvasHeight;by++)
                        for (int bx=0;bx<blockSize&&x+bx<CanvasWidth;bx++)
                        { int i=((y+by)*CanvasWidth+(x+bx))*4; layer[i]=r;layer[i+1]=g;layer[i+2]=b; }
                }
            _dirty = true;
        }

        public static void ApplyNoise(float amount = 0.1f)
        {
            PushUndoState();
            var layer = ActiveLayerPixels()!;
            var rng   = new Random();
            int intAmt = (int)(amount * 255);
            for (int i=0;i<layer.Length;i+=4)
                for (int c=0;c<3;c++)
                    layer[i+c]=(byte)Math.Clamp(layer[i+c]+rng.Next(-intAmt,intAmt),0,255);
            _dirty = true;
        }

        public static void ApplyInvert()
        {
            PushUndoState();
            var layer = ActiveLayerPixels()!;
            for (int i=0;i<layer.Length;i+=4) { layer[i]=(byte)(255-layer[i]); layer[i+1]=(byte)(255-layer[i+1]); layer[i+2]=(byte)(255-layer[i+2]); }
            _dirty = true;
        }

        public static void ApplyGrayscale()
        {
            PushUndoState();
            var layer = ActiveLayerPixels()!;
            for (int i=0;i<layer.Length;i+=4) { byte l=(byte)(0.299f*layer[i]+0.587f*layer[i+1]+0.114f*layer[i+2]); layer[i]=l;layer[i+1]=l;layer[i+2]=l; }
            _dirty = true;
        }

        // ══════════════ TRANSFORM ═════════════════════════════════════════

        public static void Resize(int newW, int newH)
        {
            var layer = ActiveLayerPixels()!;
            var dst   = new byte[newW * newH * 4];
            float sx = (float)CanvasWidth / newW, sy = (float)CanvasHeight / newH;
            for (int y=0;y<newH;y++)
                for (int x=0;x<newW;x++)
                {
                    int ox=Math.Clamp((int)(x*sx),0,CanvasWidth-1), oy=Math.Clamp((int)(y*sy),0,CanvasHeight-1);
                    int si=(oy*CanvasWidth+ox)*4, di=(y*newW+x)*4;
                    dst[di]=layer[si];dst[di+1]=layer[si+1];dst[di+2]=layer[si+2];dst[di+3]=layer[si+3];
                }
            var newLayer = ActiveLayerObj()!;
            newLayer.Pixels = dst;
            CanvasWidth = newW; CanvasHeight = newH;
            Initialize(newW, newH); _dirty = true;
        }

        public static void FlipHorizontal()
        {
            PushUndoState();
            var layer = ActiveLayerPixels()!;
            for (int y=0;y<CanvasHeight;y++)
                for (int x=0;x<CanvasWidth/2;x++)
                {
                    int a=(y*CanvasWidth+x)*4, b=(y*CanvasWidth+(CanvasWidth-1-x))*4;
                    for (int c=0;c<4;c++) (layer[a+c],layer[b+c])=(layer[b+c],layer[a+c]);
                }
            _dirty = true;
        }

        public static void FlipVertical()
        {
            PushUndoState();
            var layer = ActiveLayerPixels()!;
            for (int y=0;y<CanvasHeight/2;y++)
                for (int x=0;x<CanvasWidth;x++)
                {
                    int a=(y*CanvasWidth+x)*4, b=((CanvasHeight-1-y)*CanvasWidth+x)*4;
                    for (int c=0;c<4;c++) (layer[a+c],layer[b+c])=(layer[b+c],layer[a+c]);
                }
            _dirty = true;
        }

        // ══════════════ LAYER SYSTEM ══════════════════════════════════════

        public static CanvasLayer AddLayer(string name = "Layer")
        {
            var l = new CanvasLayer(name, CanvasWidth, CanvasHeight);
            _layers.Insert(_activeLayer + 1, l);
            _activeLayer++;
            return l;
        }

        public static void DeleteLayer(int index)
        { if (_layers.Count > 1) { _layers.RemoveAt(index); _activeLayer = Math.Min(_activeLayer, _layers.Count - 1); } }

        public static void MergeDown()
        {
            if (_activeLayer <= 0) return;
            var top = _layers[_activeLayer];
            var bot = _layers[_activeLayer - 1];
            for (int i = 0; i < bot.Pixels.Length; i += 4)
                BlendPixelInto(bot.Pixels, i, top.Pixels[i], top.Pixels[i+1], top.Pixels[i+2],
                               top.Pixels[i+3], top.Opacity, top.BlendMode);
            _layers.RemoveAt(_activeLayer); _activeLayer--;
        }

        public static void FlattenAll()
        {
            while (_layers.Count > 1) { _activeLayer = 1; MergeDown(); }
        }

        public static List<CanvasLayer> GetLayers() => _layers;
        public static int               ActiveLayerIndex => _activeLayer;
        public static void              SetActiveLayer(int i) => _activeLayer = Math.Clamp(i, 0, _layers.Count - 1);

        // ══════════════ SELECTION ═════════════════════════════════════════

        public static void SelectRect(int x, int y, int w, int h)
        { _selection = new RectSelection(x, y, w, h); }

        public static void SelectEllipse(int cx, int cy, int rx, int ry)
        { _selection = new EllipseSelection(cx, cy, rx, ry); }

        public static void StartLasso() => _lassoPoints.Clear();
        public static void AddLassoPoint(int x, int y) => _lassoPoints.Add(new(x, y));
        public static void CloseLasso() => _selection = new LassoSelection(_lassoPoints.ToArray());
        public static void ClearSelection() => _selection = null;
        public static bool HasSelection => _selection != null;

        // Magic wand selection
        public static void MagicWand(int x, int y, float tolerance = 0.1f)
        {
            var layer = ActiveLayerPixels()!;
            int idx   = (y * CanvasWidth + x) * 4;
            byte tr = layer[idx], tg = layer[idx+1], tb = layer[idx+2];
            var mask = new bool[CanvasWidth * CanvasHeight];

            var stack = new Stack<(int,int)>(); stack.Push((x,y));
            while (stack.Count > 0)
            {
                var (px,py) = stack.Pop();
                if (px<0||py<0||px>=CanvasWidth||py>=CanvasHeight) continue;
                if (mask[py*CanvasWidth+px]) continue;
                int i=(py*CanvasWidth+px)*4;
                float dist = (Math.Abs(layer[i]-tr)+Math.Abs(layer[i+1]-tg)+Math.Abs(layer[i+2]-tb))/(255f*3f);
                if (dist > tolerance) continue;
                mask[py*CanvasWidth+px] = true;
                stack.Push((px+1,py));stack.Push((px-1,py));stack.Push((px,py+1));stack.Push((px,py-1));
            }
            _selection = new MaskSelection(mask, CanvasWidth);
        }

        // ══════════════ UNDO / REDO ═══════════════════════════════════════

        private static void PushUndoState()
        {
            var layer = ActiveLayerPixels(); if (layer == null) return;
            if (_undo.Count >= MaxHistory) { var arr = _undo.ToArray(); _undo = new Stack<HistoryState>(arr[..(_undo.Count-1)]); }
            _undo.Push(new HistoryState { LayerIndex = _activeLayer, Pixels = (byte[])layer.Clone() });
            _redo.Clear();
        }

        public static bool Undo()
        {
            if (_undo.Count == 0) return false;
            var state = _undo.Pop();
            var layer = ActiveLayerPixels(); if (layer != null) _redo.Push(new HistoryState { LayerIndex = _activeLayer, Pixels = (byte[])layer.Clone() });
            state.Pixels.CopyTo(_layers[state.LayerIndex].Pixels, 0);
            _dirty = true; return true;
        }

        public static bool Redo()
        {
            if (_redo.Count == 0) return false;
            var state = _redo.Pop();
            var layer = ActiveLayerPixels(); if (layer != null) _undo.Push(new HistoryState { LayerIndex = _activeLayer, Pixels = (byte[])layer.Clone() });
            state.Pixels.CopyTo(_layers[state.LayerIndex].Pixels, 0);
            _dirty = true; return true;
        }

        public static int UndoCount => _undo.Count;
        public static int RedoCount => _redo.Count;

        // ══════════════ FILE I/O ══════════════════════════════════════════

        public static void ImportImage(string path)
        {
            if (!File.Exists(path)) { Console.WriteLine($"[Design] File not found: {path}"); return; }
            // Use SixLabors ImageSharp for cross-platform image I/O
            try
            {
                using var img = SixLabors.ImageSharp.Image.Load<SixLabors.ImageSharp.PixelFormats.Rgba32>(path);
                Initialize(img.Width, img.Height);
                var layer = ActiveLayerPixels()!;
                img.ProcessPixelRows(accessor => {
                    for (int y = 0; y < accessor.Height; y++)
                    {
                        var row = accessor.GetRowSpan(y);
                        for (int x = 0; x < row.Length; x++)
                        {
                            int i = (y * img.Width + x) * 4;
                            layer[i] = row[x].R; layer[i+1] = row[x].G;
                            layer[i+2] = row[x].B; layer[i+3] = row[x].A;
                        }
                    }
                });
                _dirty = true;
                Console.WriteLine($"[Design] Imported {path} ({img.Width}x{img.Height})");
            }
            catch (Exception ex) { Console.WriteLine($"[Design] Import error: {ex.Message}"); }
        }

        public static void ExportImage(string path, int jpegQuality = 90)
        {
            FlattenAll();
            var layer = ActiveLayerPixels()!;
            try
            {
                var img = SixLabors.ImageSharp.Image.LoadPixelData<SixLabors.ImageSharp.PixelFormats.Rgba32>(
                    layer, CanvasWidth, CanvasHeight);
                string ext = Path.GetExtension(path).ToLower();
                switch (ext)
                {
                    case ".png":  img.SaveAsPng(path); break;
                    case ".jpg":
                    case ".jpeg": img.SaveAsJpeg(path, new SixLabors.ImageSharp.Formats.Jpeg.JpegEncoder { Quality = jpegQuality }); break;
                    case ".bmp":  img.SaveAsBmp(path); break;
                    case ".webp": img.SaveAsWebp(path); break;
                    default: img.SaveAsPng(path); break;
                }
                Console.WriteLine($"[Design] Exported {path}");
            }
            catch (Exception ex) { Console.WriteLine($"[Design] Export error: {ex.Message}"); }
        }

        // ══════════════ GPU FLUSH ═════════════════════════════════════════

        public static void FlushToGpu()
        {
            if (!_dirty || !_initialized) return;
            CompositeAll();
            GL.BindTexture(TextureTarget.Texture2D, _textureHandle);
            GL.TexSubImage2D(TextureTarget.Texture2D, 0, 0, 0, CanvasWidth, CanvasHeight,
                PixelFormat.Rgba, PixelType.UnsignedByte, _pixels);
            GL.BindTexture(TextureTarget.Texture2D, 0);
            _dirty = false;
        }

        public static int TextureHandle => _textureHandle;

        // ══════════════ HELPERS ═══════════════════════════════════════════

        private static void Fill(byte r, byte g, byte b, byte a)
        {
            if (_pixels == null) return;
            for (int i = 0; i < _pixels.Length; i += 4)
            { _pixels[i]=r; _pixels[i+1]=g; _pixels[i+2]=b; _pixels[i+3]=a; }
        }

        private static byte[]? ActiveLayerPixels() => _layers.Count > 0 ? _layers[_activeLayer].Pixels : null;
        private static CanvasLayer? ActiveLayerObj() => _layers.Count > 0 ? _layers[_activeLayer] : null;

        private static void CompositeAll()
        {
            if (_pixels == null) return;
            Array.Clear(_pixels);
            foreach (var layer in _layers)
                if (layer.Visible)
                    for (int i = 0; i < _pixels.Length; i += 4)
                        BlendPixelInto(_pixels, i, layer.Pixels[i], layer.Pixels[i+1],
                                       layer.Pixels[i+2], layer.Pixels[i+3], layer.Opacity, layer.BlendMode);
        }

        private static void BlendPixel(byte[] dst, int idx, byte r, byte g, byte b, byte a, float opacity, BlendMode mode)
        {
            float alpha = (a / 255f) * opacity;
            float dr = dst[idx] / 255f, dg = dst[idx+1] / 255f, db = dst[idx+2] / 255f;
            float sr = r / 255f,        sg = g / 255f,           sb = b / 255f;
            (sr, sg, sb) = ApplyBlendMode(mode, dr, dg, db, sr, sg, sb);
            dst[idx]   = (byte)((sr * alpha + dr * (1 - alpha)) * 255);
            dst[idx+1] = (byte)((sg * alpha + dg * (1 - alpha)) * 255);
            dst[idx+2] = (byte)((sb * alpha + db * (1 - alpha)) * 255);
            dst[idx+3] = (byte)Math.Min(255, dst[idx+3] + a * opacity);
        }

        private static void BlendPixelInto(byte[] dst, int idx, byte r, byte g, byte b, byte a, float opacity, BlendMode mode)
            => BlendPixel(dst, idx, r, g, b, a, opacity, mode);

        private static (float r, float g, float b) ApplyBlendMode(BlendMode mode, float dr, float dg, float db, float sr, float sg, float sb)
            => mode switch
            {
                BlendMode.Multiply  => (dr * sr, dg * sg, db * sb),
                BlendMode.Screen    => (1-(1-dr)*(1-sr), 1-(1-dg)*(1-sg), 1-(1-db)*(1-sb)),
                BlendMode.Overlay   => (Overlay(dr, sr), Overlay(dg, sg), Overlay(db, sb)),
                BlendMode.HardLight => (Overlay(sr, dr), Overlay(sg, dg), Overlay(sb, db)),
                BlendMode.Dodge     => (Math.Min(1, dr / (1 - sr + 0.001f)), Math.Min(1, dg / (1 - sg + 0.001f)), Math.Min(1, db / (1 - sb + 0.001f))),
                BlendMode.Burn      => (1 - Math.Min(1, (1-dr) / (sr + 0.001f)), 1 - Math.Min(1, (1-dg) / (sg + 0.001f)), 1 - Math.Min(1, (1-db) / (sb + 0.001f))),
                BlendMode.Difference=> (Math.Abs(dr-sr), Math.Abs(dg-sg), Math.Abs(db-sb)),
                BlendMode.SoftLight => (SoftLight(dr,sr), SoftLight(dg,sg), SoftLight(db,sb)),
                _                   => (sr, sg, sb),  // Normal
            };

        private static float Overlay(float a, float b) => a < 0.5f ? 2*a*b : 1-2*(1-a)*(1-b);
        private static float SoftLight(float a, float b) => b < 0.5f ? a-(1-2*b)*a*(1-a) : a+(2*b-1)*(MathF.Sqrt(a)-a);

        private static void ApplySmudge(byte[] layer, int idx, byte r, byte g, byte b, byte a)
        {
            float s = SmudgeStrength;
            layer[idx]   = (byte)(layer[idx]   * (1-s) + r * s);
            layer[idx+1] = (byte)(layer[idx+1] * (1-s) + g * s);
            layer[idx+2] = (byte)(layer[idx+2] * (1-s) + b * s);
            layer[idx+3] = (byte)(layer[idx+3] * (1-s) + a * s);
        }

        private static void RgbToHsl(float r, float g, float b, out float h, out float s, out float l)
        {
            float max=MathF.Max(r,MathF.Max(g,b)), min=MathF.Min(r,MathF.Min(g,b));
            l=(max+min)/2f; s=l>0.5f?(max-min)/(2f-max-min):(max-min)/(max+min+0.0001f);
            h = max==r?(g-b)/(max-min+0.0001f)/6f: max==g?(2+(b-r)/(max-min+0.0001f))/6f:(4+(r-g)/(max-min+0.0001f))/6f;
            if(h<0)h+=1f; h=((h%1f)+1f)%1f;
        }

        private static void HslToRgb(float h, float s, float l, out float r, out float g, out float b)
        {
            if (s == 0) { r=g=b=l; return; }
            float Hue(float p, float q, float t){ if(t<0)t+=1;if(t>1)t-=1; return t<1/6f?p+(q-p)*6*t:t<1/2f?q:t<2/3f?p+(q-p)*(2/3f-t)*6:p; }
            float q=l<0.5f?l*(1+s):l+s-l*s, p=2*l-q;
            r=Hue(p,q,h+1/3f); g=Hue(p,q,h); b=Hue(p,q,h-1/3f);
        }
    }

    // ══════════════ SUPPORT TYPES ══════════════════════════════════════════

    public sealed class CanvasLayer
    {
        public string    Name      { get; set; }
        public byte[]    Pixels    { get; set; }
        public float     Opacity   { get; set; } = 1f;
        public BlendMode BlendMode { get; set; } = BlendMode.Normal;
        public bool      Visible   { get; set; } = true;
        public bool      Locked    { get; set; } = false;

        public CanvasLayer(string name, int w, int h)
        { Name = name; Pixels = new byte[w * h * 4]; }
    }

    public abstract class SelectionMask { public abstract bool IsSelected(int x, int y); }
    public sealed class RectSelection(int x, int y, int w, int h) : SelectionMask
    { public override bool IsSelected(int px, int py) => px>=x&&py>=y&&px<x+w&&py<y+h; }
    public sealed class EllipseSelection(int cx, int cy, int rx, int ry) : SelectionMask
    { public override bool IsSelected(int px, int py) { float nx=(px-cx)/(float)rx,ny=(py-cy)/(float)ry; return nx*nx+ny*ny<=1f; } }
    public sealed class LassoSelection(Vector2[] pts) : SelectionMask
    {
        public override bool IsSelected(int x, int y)
        {
            int n=pts.Length, c=0;
            for (int i=0,j=n-1;i<n;j=i++) {
                if (((pts[i].Y>y)!=(pts[j].Y>y)) && x<(pts[j].X-pts[i].X)*(y-pts[i].Y)/(pts[j].Y-pts[i].Y)+pts[i].X) c++;
            }
            return c%2==1;
        }
    }
    public sealed class MaskSelection(bool[] mask, int width) : SelectionMask
    { public override bool IsSelected(int x, int y) => mask[y*width+x]; }

    public sealed class HistoryState { public int LayerIndex; public byte[] Pixels = Array.Empty<byte>(); }

    public enum DesignTool { Brush, Eraser, Fill, Gradient, Selection, Lasso, MagicWand, CloneStamp, Smear, Dodge, Burn, Text, CropTool, Transform, Eyedropper, PenPath }
    public enum BrushShape { Round, Square, Diamond, Texture }
// BlendMode defined in DesignStudio_COMPLETE.cs
}
