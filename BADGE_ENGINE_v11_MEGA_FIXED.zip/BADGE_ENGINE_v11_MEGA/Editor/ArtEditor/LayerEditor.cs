using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Editor.ArtEditor;

// ═══════════════════════════════════════════════════════════════════════
//  BLEND MODES  (Krita / Photoshop standard set)
// ═══════════════════════════════════════════════════════════════════════
public enum BlendMode
{
    Normal, Multiply, Screen, Overlay, SoftLight, HardLight,
    ColorDodge, ColorBurn, Darken, Lighten, Difference, Exclusion,
    Hue, Saturation, Color, Luminosity, Dissolve, HardMix
}

public static class BlendMath
{
    public static Vector3 Blend(Vector3 src, Vector3 dst, BlendMode mode, float opacity)
    {
        var blended = mode switch
        {
            BlendMode.Multiply   => src * dst,
            BlendMode.Screen     => Vector3.One - (Vector3.One - src) * (Vector3.One - dst),
            BlendMode.Overlay    => new Vector3(
                dst.X < 0.5f ? 2f*src.X*dst.X : 1f-2f*(1f-src.X)*(1f-dst.X),
                dst.Y < 0.5f ? 2f*src.Y*dst.Y : 1f-2f*(1f-src.Y)*(1f-dst.Y),
                dst.Z < 0.5f ? 2f*src.Z*dst.Z : 1f-2f*(1f-src.Z)*(1f-dst.Z)),
            BlendMode.SoftLight  => new Vector3(
                dst.X < 0.5f ? 2f*src.X*dst.X+src.X*src.X*(1f-2f*dst.X) : 2f*src.X*(1f-dst.X)+MathF.Sqrt(src.X)*( 2f*dst.X-1f),
                dst.Y < 0.5f ? 2f*src.Y*dst.Y+src.Y*src.Y*(1f-2f*dst.Y) : 2f*src.Y*(1f-dst.Y)+MathF.Sqrt(src.Y)*( 2f*dst.Y-1f),
                dst.Z < 0.5f ? 2f*src.Z*dst.Z+src.Z*src.Z*(1f-2f*dst.Z) : 2f*src.Z*(1f-dst.Z)+MathF.Sqrt(src.Z)*( 2f*dst.Z-1f)),
            BlendMode.Difference => new Vector3(MathF.Abs(src.X-dst.X), MathF.Abs(src.Y-dst.Y), MathF.Abs(src.Z-dst.Z)),
            BlendMode.ColorDodge => new Vector3(
                dst.X == 1f ? 1f : Math.Clamp(src.X/(1f-dst.X), 0f, 1f),
                dst.Y == 1f ? 1f : Math.Clamp(src.Y/(1f-dst.Y), 0f, 1f),
                dst.Z == 1f ? 1f : Math.Clamp(src.Z/(1f-dst.Z), 0f, 1f)),
            BlendMode.ColorBurn  => new Vector3(
                dst.X == 0f ? 0f : Math.Clamp(1f-(1f-src.X)/dst.X, 0f, 1f),
                dst.Y == 0f ? 0f : Math.Clamp(1f-(1f-src.Y)/dst.Y, 0f, 1f),
                dst.Z == 0f ? 0f : Math.Clamp(1f-(1f-src.Z)/dst.Z, 0f, 1f)),
            BlendMode.Darken     => new Vector3(MathF.Min(src.X,dst.X), MathF.Min(src.Y,dst.Y), MathF.Min(src.Z,dst.Z)),
            BlendMode.Lighten    => new Vector3(MathF.Max(src.X,dst.X), MathF.Max(src.Y,dst.Y), MathF.Max(src.Z,dst.Z)),
            BlendMode.Exclusion  => src + dst - 2f * src * dst,
            _                    => src  // Normal, fallback
        };

        return Vector3.Lerp(src, blended, opacity);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  CANVAS LAYER
// ═══════════════════════════════════════════════════════════════════════
public enum LayerType { Pixel, Vector, Fill, Adjustment, Group, Text, Mask }

public class CanvasLayer
{
    public string    Name      { get; set; } = "Layer";
    public LayerType Type      { get; set; } = LayerType.Pixel;
    public BlendMode BlendMode { get; set; } = BlendMode.Normal;
    public float     Opacity   { get; set; } = 1f;
    public bool      Visible   { get; set; } = true;
    public bool      Locked    { get; set; } = false;
    public bool      Clipped   { get; set; } = false;   // clip to layer below

    // Pixel data
    public int   Width  { get; private set; }
    public int   Height { get; private set; }
    public byte[]? Pixels{ get; private set; }  // RGBA, 4 bytes per pixel

    // Children (for group layers)
    public List<CanvasLayer> Children { get; } = new();

    // Adjustment layer settings (for Adjustment type)
    public ClipAdjustment? Adjustment { get; set; }

    public CanvasLayer(int w, int h)
    {
        Width  = w;
        Height = h;
        Pixels = new byte[w * h * 4];
        // Fill transparent
        for (int i = 3; i < Pixels.Length; i += 4) Pixels[i] = 255;
    }

    public CanvasLayer() { }  // for group/adjustment

    // ── Pixel access ──────────────────────────────────────────────
    public Color4 GetPixel(int x, int y)
    {
        if (Pixels == null || x < 0 || y < 0 || x >= Width || y >= Height)
            return Color4.Transparent;
        int idx = (y * Width + x) * 4;
        return new Color4(Pixels[idx]/255f, Pixels[idx+1]/255f, Pixels[idx+2]/255f, Pixels[idx+3]/255f);
    }

    public void SetPixel(int x, int y, Color4 color)
    {
        if (Pixels == null || Locked || x < 0 || y < 0 || x >= Width || y >= Height) return;
        int idx = (y * Width + x) * 4;
        Pixels[idx  ] = (byte)(color.R * 255);
        Pixels[idx+1] = (byte)(color.G * 255);
        Pixels[idx+2] = (byte)(color.B * 255);
        Pixels[idx+3] = (byte)(color.A * 255);
    }

    // ── Fill ──────────────────────────────────────────────────────
    public void Fill(Color4 color)
    {
        if (Pixels == null || Locked) return;
        byte r=(byte)(color.R*255), g=(byte)(color.G*255), b=(byte)(color.B*255), a=(byte)(color.A*255);
        for (int i = 0; i < Pixels.Length; i+=4)
        {
            Pixels[i]=r; Pixels[i+1]=g; Pixels[i+2]=b; Pixels[i+3]=a;
        }
    }

    // ── Flood fill ────────────────────────────────────────────────
    public void FloodFill(int startX, int startY, Color4 fillColor, float tolerance = 0.02f)
    {
        if (Pixels == null || Locked) return;
        var target = GetPixel(startX, startY);
        if (ColorDistance(target, fillColor) < tolerance) return;

        var queue   = new Queue<(int, int)>();
        var visited = new HashSet<(int, int)>();
        queue.Enqueue((startX, startY));

        while (queue.Count > 0)
        {
            var (x, y) = queue.Dequeue();
            if (!visited.Add((x, y))) continue;
            if (x < 0 || y < 0 || x >= Width || y >= Height) continue;
            if (ColorDistance(GetPixel(x, y), target) > tolerance) continue;

            SetPixel(x, y, fillColor);
            queue.Enqueue((x+1, y)); queue.Enqueue((x-1, y));
            queue.Enqueue((x, y+1)); queue.Enqueue((x, y-1));
        }
    }

    private static float ColorDistance(Color4 a, Color4 b)
        => MathF.Abs(a.R-b.R) + MathF.Abs(a.G-b.G) + MathF.Abs(a.B-b.B);

    public void Clear() { Fill(Color4.Transparent); }

    public CanvasLayer Clone()
    {
        var l = new CanvasLayer(Width, Height)
        {
            Name = Name + " copy", BlendMode = BlendMode, Opacity = Opacity,
            Visible = Visible, Locked = false
        };
        if (Pixels != null && l.Pixels != null)
            Array.Copy(Pixels, l.Pixels, Pixels.Length);
        return l;
    }
}

public class ClipAdjustment
{
    public float Brightness  { get; set; }
    public float Contrast    { get; set; } = 1f;
    public float Hue         { get; set; }
    public float Saturation  { get; set; } = 1f;
    public float Lightness   { get; set; }
}

// ═══════════════════════════════════════════════════════════════════════
//  LAYER STACK EDITOR
// ═══════════════════════════════════════════════════════════════════════
public class LayerStack
{
    public List<CanvasLayer> Layers  { get; } = new();
    public CanvasLayer?      Active  { get; private set; }
    public int               Width   { get; private set; }
    public int               Height  { get; private set; }

    public event Action? OnChanged;

    public LayerStack(int w, int h)
    {
        Width  = w;
        Height = h;
        var bg = new CanvasLayer(w, h) { Name = "Background" };
        bg.Fill(Color4.White);
        Layers.Add(bg);
        Active = bg;
    }

    public CanvasLayer AddLayer(string name = "New Layer", LayerType type = LayerType.Pixel)
    {
        var l = type == LayerType.Group ? new CanvasLayer() : new CanvasLayer(Width, Height);
        l.Name = name;
        l.Type = type;
        int idx = Active != null ? Layers.IndexOf(Active) + 1 : Layers.Count;
        Layers.Insert(Math.Clamp(idx, 0, Layers.Count), l);
        Active = l;
        OnChanged?.Invoke();
        return l;
    }

    public void DeleteLayer(CanvasLayer l)
    {
        if (Layers.Count <= 1) return;
        int idx = Layers.IndexOf(l);
        Layers.Remove(l);
        Active = Layers[Math.Max(0, idx - 1)];
        OnChanged?.Invoke();
    }

    public void MoveLayer(CanvasLayer l, int newIdx)
    {
        Layers.Remove(l);
        Layers.Insert(Math.Clamp(newIdx, 0, Layers.Count), l);
        OnChanged?.Invoke();
    }

    public void SetActive(CanvasLayer l) => Active = Layers.Contains(l) ? l : Active;
    public void DuplicateActive()        { if (Active != null) { var c = Active.Clone(); Layers.Insert(Layers.IndexOf(Active)+1, c); Active = c; OnChanged?.Invoke(); } }
    public void MergeDown()
    {
        if (Active == null) return;
        int idx = Layers.IndexOf(Active);
        if (idx <= 0) return;
        var below = Layers[idx - 1];
        // Composite Active onto below
        if (Active.Pixels != null && below.Pixels != null)
        {
            for (int y = 0; y < Height; y++)
            for (int x = 0; x < Width;  x++)
            {
                var src = Active.GetPixel(x, y);
                var dst = below.GetPixel(x, y);
                if (src.A < 0.01f) continue;
                var blended = BlendMath.Blend(
                    new Vector3(src.R, src.G, src.B),
                    new Vector3(dst.R, dst.G, dst.B),
                    Active.BlendMode, Active.Opacity * src.A);
                below.SetPixel(x, y, new Color4(blended.X, blended.Y, blended.Z, MathF.Max(src.A, dst.A)));
            }
        }
        Layers.RemoveAt(idx);
        Active = below;
        OnChanged?.Invoke();
    }

    // ── Flatten composite ─────────────────────────────────────────
    public CanvasLayer Flatten()
    {
        var result = new CanvasLayer(Width, Height);
        result.Fill(Color4.White);
        foreach (var l in Layers)
        {
            if (!l.Visible || l.Pixels == null) continue;
            for (int y = 0; y < Height; y++)
            for (int x = 0; x < Width;  x++)
            {
                var src = l.GetPixel(x, y);
                if (src.A < 0.001f) continue;
                var dst = result.GetPixel(x, y);
                var blended = BlendMath.Blend(
                    new Vector3(src.R, src.G, src.B),
                    new Vector3(dst.R, dst.G, dst.B),
                    l.BlendMode, l.Opacity * src.A);
                result.SetPixel(x, y, new Color4(blended.X, blended.Y, blended.Z, 1f));
            }
        }
        return result;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  BRUSH ENGINE
// ═══════════════════════════════════════════════════════════════════════
public enum BrushType { Round, Flat, Fan, Smudge, Eraser, Clone, PaintBucket }

public class Brush
{
    public BrushType Type      { get; set; } = BrushType.Round;
    public float     Size      { get; set; } = 20f;
    public float     Hardness  { get; set; } = 0.8f;   // 0=feathered, 1=hard edge
    public float     Opacity   { get; set; } = 1f;
    public float     Flow      { get; set; } = 1f;
    public float     Spacing   { get; set; } = 0.1f;   // fraction of size between stamps
    public float     Angle     { get; set; } = 0f;     // brush rotation
    public float     Roundness { get; set; } = 1f;     // 1=round, 0=flat
    public bool      PressureSize    { get; set; } = true;
    public bool      PressureOpacity { get; set; } = false;
    public float     Scatter   { get; set; } = 0f;     // position randomness
    public float     Jitter    { get; set; } = 0f;     // size randomness

    private static readonly Random _rng = new();

    /// <summary>Paint a dab at (px, py) with given pressure onto the active layer.</summary>
    public void Paint(CanvasLayer layer, float px, float py, Color4 color, float pressure = 1f)
    {
        if (layer.Locked) return;

        float size = Size * (PressureSize ? pressure : 1f);
        float opa  = Opacity * (PressureOpacity ? pressure : 1f) * Flow;

        if (Type == BrushType.Eraser)
        {
            color = Color4.Transparent;
            opa   = Opacity;
        }

        float scatter = Scatter * size;
        px += (_rng.NextSingle() - 0.5f) * scatter;
        py += (_rng.NextSingle() - 0.5f) * scatter;

        float effectiveSize = size * (1f + (_rng.NextSingle() - 0.5f) * Jitter);
        int   radius        = (int)(effectiveSize * 0.5f);

        for (int dy = -radius; dy <= radius; dy++)
        for (int dx = -radius; dx <= radius; dx++)
        {
            int ix = (int)px + dx;
            int iy = (int)py + dy;

            float d = MathF.Sqrt(dx * dx + dy * dy) / radius;
            if (d > 1f) continue;

            // Hardness-based falloff
            float alpha = d < Hardness ? 1f : 1f - (d - Hardness) / (1f - Hardness + 0.001f);
            alpha = Math.Clamp(alpha * opa, 0f, 1f);

            if (Type == BrushType.Eraser)
            {
                var existing = layer.GetPixel(ix, iy);
                layer.SetPixel(ix, iy, new Color4(existing.R, existing.G, existing.B, existing.A * (1f - alpha)));
            }
            else
            {
                var existing = layer.GetPixel(ix, iy);
                // Alpha-over composite
                float sa = color.A * alpha;
                float da = existing.A * (1f - sa);
                float oa = sa + da;
                if (oa < 0.001f) continue;
                layer.SetPixel(ix, iy, new Color4(
                    (color.R * sa + existing.R * da) / oa,
                    (color.G * sa + existing.G * da) / oa,
                    (color.B * sa + existing.B * da) / oa,
                    oa));
            }
        }
    }

    /// <summary>Paint a stroke from last position to current (with spacing control).</summary>
    private Vector2 _lastPos = new(-1, -1);
    private float   _distAccum;

    public void StrokeTo(CanvasLayer layer, Vector2 pos, Color4 color, float pressure = 1f)
    {
        if (_lastPos.X < 0) { _lastPos = pos; Paint(layer, pos.X, pos.Y, color, pressure); return; }

        float dist = Vector2.Distance(_lastPos, pos);
        _distAccum += dist;
        float step  = Size * Spacing;

        while (_distAccum >= step)
        {
            _distAccum -= step;
            float t = (_distAccum) / (dist + 0.001f);
            var p   = Vector2.Lerp(_lastPos, pos, 1f - t);
            Paint(layer, p.X, p.Y, color, pressure);
        }
        _lastPos = pos;
    }

    public void EndStroke() { _lastPos = new(-1, -1); _distAccum = 0f; }
}

// ═══════════════════════════════════════════════════════════════════════
//  COLOR PICKER  (HSL wheel + hex)
// ═══════════════════════════════════════════════════════════════════════
public class ColorPicker
{
    public float Hue        { get; private set; }  // 0–360
    public float Saturation { get; private set; }  // 0–1
    public float Lightness  { get; private set; }  // 0–1
    public float Alpha      { get; set; } = 1f;

    public Color4 CurrentColor => HslToRgb(Hue, Saturation, Lightness, Alpha);

    public void SetHSL(float h, float s, float l)  { Hue = h % 360f; Saturation = Math.Clamp(s,0f,1f); Lightness = Math.Clamp(l,0f,1f); }
    public void SetColor(Color4 c)
    {
        RgbToHsl(c.R, c.G, c.B, out float h, out float s, out float l);
        Hue = h; Saturation = s; Lightness = l; Alpha = c.A;
    }
    public void SetHex(string hex)
    {
        hex = hex.TrimStart('#');
        if (hex.Length >= 6)
        {
            float r = Convert.ToInt32(hex[..2], 16) / 255f;
            float g = Convert.ToInt32(hex[2..4], 16) / 255f;
            float b = Convert.ToInt32(hex[4..6], 16) / 255f;
            SetColor(new Color4(r, g, b, 1f));
        }
    }
    public string ToHex()
    {
        var c = CurrentColor;
        return $"#{(int)(c.R*255):X2}{(int)(c.G*255):X2}{(int)(c.B*255):X2}";
    }

    public static Color4 HslToRgb(float h, float s, float l, float a = 1f)
    {
        h /= 360f;
        float q = l < 0.5f ? l * (1f + s) : l + s - l * s;
        float p = 2f * l - q;
        float r = HueToRgb(p, q, h + 1f/3f);
        float g = HueToRgb(p, q, h);
        float b = HueToRgb(p, q, h - 1f/3f);
        return new Color4(r, g, b, a);
    }

    private static float HueToRgb(float p, float q, float t)
    {
        if (t < 0f) t += 1f;
        if (t > 1f) t -= 1f;
        if (t < 1f/6f) return p + (q - p) * 6f * t;
        if (t < 1f/2f) return q;
        if (t < 2f/3f) return p + (q - p) * (2f/3f - t) * 6f;
        return p;
    }

    public static void RgbToHsl(float r, float g, float b, out float h, out float s, out float l)
    {
        float max = MathF.Max(r, MathF.Max(g, b));
        float min = MathF.Min(r, MathF.Min(g, b));
        l = (max + min) * 0.5f;
        if (max == min) { h = s = 0f; return; }
        float d = max - min;
        s = l > 0.5f ? d / (2f - max - min) : d / (max + min);
        h = max == r ? (g - b) / d + (g < b ? 6f : 0f)
          : max == g ? (b - r) / d + 2f
          :             (r - g) / d + 4f;
        h *= 60f;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  COLOUR PALETTE
// ═══════════════════════════════════════════════════════════════════════
public class ColorPalette
{
    public string       Name    { get; set; } = "Palette";
    public List<Color4> Swatches{ get; } = new();
    public int          Columns { get; set; } = 8;

    public void Add(Color4 c)    => Swatches.Add(c);
    public void Remove(Color4 c) => Swatches.Remove(c);

    public static ColorPalette DefaultPalette()
    {
        var p = new ColorPalette { Name = "Basic" };
        Color4[] cols = {
            Color4.White, Color4.LightGray, Color4.Gray, Color4.DarkGray, Color4.Black,
            Color4.Red, Color4.Green, Color4.Blue, Color4.Yellow, Color4.Cyan, Color4.Magenta,
            Color4.Orange, new(0.5f,0,0.5f,1), new(0,0.5f,0,1), new(0,0,0.5f,1),
            new(1,0.75f,0.8f,1), new(0.6f,0.4f,0.2f,1), new(0.1f,0.7f,0.5f,1)
        };
        foreach (var c in cols) p.Add(c);
        return p;
    }
}
