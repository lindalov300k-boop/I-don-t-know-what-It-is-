using ImGuiNET;
using System.Numerics;
using System;
using BADGE.Core;
using BADGE.Rendering;
using BADGE.Physics;
using BADGE.Audio;

namespace BADGE.Editor;

/// <summary>
/// Full Inspector Panel — displays and edits every known component type.
/// v11: Expanded to cover all 30+ component categories.
/// </summary>
public class InspectorPanel
{
    private EditorWindow _editor;
    private string _addComponentSearch = "";

    public InspectorPanel(EditorWindow editor)
    {
        _editor = editor;
    }

    public void Render()
    {
        ImGui.Begin("Inspector");

        var selected = _editor.SelectedGameObject;
        if (selected == null)
        {
            ImGui.TextDisabled("No GameObject selected.");
            ImGui.End();
            return;
        }

        // ── GameObject header ──────────────────────────────────────────────
        bool active = selected.IsActive;
        if (ImGui.Checkbox("##active", ref active)) selected.IsActive = active;
        ImGui.SameLine();
        var name = selected.Name;
        if (ImGui.InputText("##goname", ref name, 128)) selected.Name = name;
        ImGui.SameLine();
        ImGui.TextDisabled($"ID:{selected.InstanceId}");

        var tag = selected.Tag ?? "";
        ImGui.SetNextItemWidth(120);
        if (ImGui.InputText("Tag", ref tag, 64)) selected.Tag = tag;
        ImGui.SameLine();
        int layer = selected.Layer;
        ImGui.SetNextItemWidth(80);
        if (ImGui.InputInt("Layer", ref layer)) selected.Layer = layer;

        ImGui.Separator();

        // ── Transform ─────────────────────────────────────────────────────
        if (ImGui.CollapsingHeader("Transform", ImGuiTreeNodeFlags.DefaultOpen))
        {
            var pos   = ToV3(selected.Transform.LocalPosition);
            var rot   = ToV3(selected.Transform.LocalEulerAngles);
            var scale = ToV3(selected.Transform.LocalScale);

            if (ImGui.DragFloat3("Position", ref pos,   0.1f))  selected.Transform.LocalPosition    = FromV3(pos);
            if (ImGui.DragFloat3("Rotation", ref rot,   1.0f))  selected.Transform.LocalEulerAngles  = FromV3(rot);
            if (ImGui.DragFloat3("Scale",    ref scale, 0.01f)) selected.Transform.LocalScale        = FromV3(scale);
            ImGui.TextDisabled($"World pos: {selected.Transform.Position}");
        }

        // ── All components ─────────────────────────────────────────────────
        foreach (var comp in selected.GetComponents<Component>())
        {
            DrawComponent(comp, selected);
        }

        ImGui.Separator();

        // ── Add Component ─────────────────────────────────────────────────
        if (ImGui.Button("+ Add Component", new Vector2(-1, 0)))
            ImGui.OpenPopup("##AddComp");

        if (ImGui.BeginPopup("##AddComp"))
        {
            ImGui.InputText("Search", ref _addComponentSearch, 64);
            ImGui.Separator();

            void CompItem<T>(string label) where T : Component, new()
            {
                if (_addComponentSearch.Length > 0 &&
                    !label.Contains(_addComponentSearch, StringComparison.OrdinalIgnoreCase)) return;
                if (ImGui.MenuItem(label)) selected.AddComponent<T>();
            }

            // Rendering
            if (ImGui.BeginMenu("Rendering"))
            {
                CompItem<MeshFilter>("Mesh Filter");
                CompItem<MeshRenderer>("Mesh Renderer");
                CompItem<SpriteRenderer>("Sprite Renderer");
                CompItem<Camera>("Camera");
                CompItem<Light>("Light");
                ImGui.EndMenu();
            }
            // Physics
            if (ImGui.BeginMenu("Physics"))
            {
                CompItem<Rigidbody3D>("Rigidbody 3D");
                CompItem<BoxCollider3D>("Box Collider 3D");
                CompItem<SphereCollider3D>("Sphere Collider 3D");
                CompItem<CapsuleCollider3D>("Capsule Collider 3D");
                ImGui.EndMenu();
            }
            // Audio
            if (ImGui.BeginMenu("Audio"))
            {
                CompItem<AudioSource>("Audio Source");
                ImGui.EndMenu();
            }
            // Camera Controllers
            if (ImGui.BeginMenu("Camera Controllers"))
            {
                CompItem<BADGE.Core.Cameras.FPSCamera>("FPS Camera");
                CompItem<BADGE.Core.Cameras.TopDownCamera>("Top Down Camera");
                CompItem<BADGE.Core.Cameras.PlatformerCamera>("Platformer Camera");
                CompItem<BADGE.Core.Cameras.OrbitCamera>("Orbit Camera");
                CompItem<BADGE.Core.Cameras.FollowCamera>("Follow Camera");
                CompItem<BADGE.Core.Cameras.CinematicCamera>("Cinematic Camera");
                ImGui.EndMenu();
            }
            // UI
            if (ImGui.BeginMenu("UI"))
            {
                CompItem<BADGE.Core.UICanvas>("UI Canvas");
                CompItem<BADGE.Core.UIComponents.UIText>("UI Text");
                CompItem<BADGE.Core.UIComponents.UIButton>("UI Button");
                CompItem<BADGE.Core.UIComponents.UISlider>("UI Slider");
                CompItem<BADGE.Core.UIComponents.UIImage>("UI Image");
                ImGui.EndMenu();
            }
            // AI
            if (ImGui.BeginMenu("AI"))
            {
                CompItem<BADGE.Core.AI.BehaviorTreeRunner>("Behavior Tree Runner");
                CompItem<BADGE.Core.MissingSystemsIntegration.NavMeshAgent>("NavMesh Agent");
                ImGui.EndMenu();
            }
            // Gameplay
            if (ImGui.BeginMenu("Gameplay"))
            {
                CompItem<BADGE.Gameplay.SurvivalStats>("Survival Stats");
                CompItem<BADGE.Gameplay.Buoyancy>("Buoyancy");
                CompItem<BADGE.Gameplay.DayNightCycle>("Day Night Cycle");
                CompItem<BADGE.Gameplay.ChunkStreamer>("Chunk Streamer");
                ImGui.EndMenu();
            }

            ImGui.EndPopup();
        }

        ImGui.End();
    }

    // ── Component drawers ──────────────────────────────────────────────────
    private void DrawComponent(Component comp, GameObject go)
    {
        string label = comp.GetType().Name;
        bool open = ImGui.CollapsingHeader(label, ImGuiTreeNodeFlags.DefaultOpen);

        // Right-click context menu per component
        if (ImGui.IsItemClicked(ImGuiMouseButton.Right))
            ImGui.OpenPopup($"##ctx_{comp.GetType().Name}_{comp.GetHashCode()}");

        if (ImGui.BeginPopup($"##ctx_{comp.GetType().Name}_{comp.GetHashCode()}"))
        {
            if (ImGui.MenuItem("Remove Component")) go.RemoveComponent(comp);
            if (ImGui.MenuItem("Copy Values"))      { /* TODO: clipboard */ }
            ImGui.EndPopup();
        }

        if (!open) return;

        switch (comp)
        {
            // ── Transform (skip — already rendered above) ──────────────────
            case BADGE.Core.Transform: break;

            // ── MeshRenderer ───────────────────────────────────────────────
            case MeshRenderer mr:
                bool cs = mr.CastShadows;
                bool rs = mr.ReceiveShadows;
                if (ImGui.Checkbox("Cast Shadows",    ref cs)) mr.CastShadows    = cs;
                if (ImGui.Checkbox("Receive Shadows", ref rs)) mr.ReceiveShadows = rs;
                ImGui.Text($"Material: {mr.Material?.Name ?? "(none)"}");
                break;

            // ── MeshFilter ────────────────────────────────────────────────
            case MeshFilter mf:
                ImGui.Text($"Mesh: {mf.Mesh?.Name ?? "(none)"}");
                ImGui.Text($"Vertices: {mf.Mesh?.Vertices?.Length ?? 0}  Tris: {(mf.Mesh?.Triangles?.Length ?? 0) / 3}");
                break;

            // ── SpriteRenderer ─────────────────────────────────────────────
            case SpriteRenderer sr:
                var sc = ToV4(sr.Color);
                if (ImGui.ColorEdit4("Color", ref sc)) sr.Color = FromV4Color(sc);
                bool fx = sr.FlipX, fy = sr.FlipY;
                if (ImGui.Checkbox("Flip X", ref fx)) sr.FlipX = fx;
                ImGui.SameLine();
                if (ImGui.Checkbox("Flip Y", ref fy)) sr.FlipY = fy;
                int so = sr.SortingOrder;
                if (ImGui.InputInt("Sorting Order", ref so)) sr.SortingOrder = so;
                break;

            // ── Camera ────────────────────────────────────────────────────
            case Camera cam:
                float fov = cam.FOV;
                if (ImGui.SliderFloat("FOV", ref fov, 10f, 170f)) cam.FOV = fov;
                float near = cam.Near, far = cam.Far;
                if (ImGui.DragFloat("Near Clip", ref near, 0.01f, 0.001f, 10f)) cam.Near = near;
                if (ImGui.DragFloat("Far Clip",  ref far,  1f,   1f,    10000f)) cam.Far  = far;
                bool ortho = cam.Orthographic;
                if (ImGui.Checkbox("Orthographic", ref ortho)) cam.Orthographic = ortho;
                if (ortho)
                {
                    float os = cam.OrthographicSize;
                    if (ImGui.DragFloat("Ortho Size", ref os, 0.1f)) cam.OrthographicSize = os;
                }
                int depth = cam.Depth;
                if (ImGui.InputInt("Depth", ref depth)) cam.Depth = depth;
                break;

            // ── Light ─────────────────────────────────────────────────────
            case Light lt:
                var lc = ToV4(lt.Color);
                if (ImGui.ColorEdit4("Color",     ref lc)) lt.Color = FromV4Color(lc);
                float li = lt.Intensity, lr = lt.Range;
                if (ImGui.DragFloat("Intensity",  ref li, 0.05f, 0f, 100f)) lt.Intensity = li;
                if (ImGui.DragFloat("Range",      ref lr, 0.1f,  0f, 1000f)) lt.Range = lr;
                break;

            // ── AudioSource ───────────────────────────────────────────────
            case AudioSource aus:
                float vol = aus.Volume, pit = aus.Pitch;
                bool loop = aus.Loop;
                float sb  = aus.SpatialBlend;
                if (ImGui.SliderFloat("Volume",       ref vol, 0f, 1f))  aus.Volume = vol;
                if (ImGui.SliderFloat("Pitch",        ref pit, 0.1f, 3f)) aus.Pitch  = pit;
                if (ImGui.Checkbox("Loop",            ref loop))           aus.Loop   = loop;
                if (ImGui.SliderFloat("Spatial Blend",ref sb,  0f, 1f))   aus.SpatialBlend = sb;
                float mind = aus.MinDistance, maxd = aus.MaxDistance;
                if (ImGui.DragFloat("Min Distance",   ref mind, 0.1f)) aus.MinDistance = mind;
                if (ImGui.DragFloat("Max Distance",   ref maxd, 1f))   aus.MaxDistance = maxd;
                if (ImGui.Button("Play"))  aus.Play();
                ImGui.SameLine();
                if (ImGui.Button("Stop"))  aus.Stop();
                break;

            // ── Rigidbody3D ───────────────────────────────────────────────
            case Rigidbody3D rb:
                float mass = rb.Mass, drag = rb.BaseDrag, adrag = rb.AngularDrag;
                bool kin = rb.IsKinematic, grav = rb.UseGravity;
                if (ImGui.DragFloat("Mass",         ref mass,  0.1f, 0.01f, 10000f)) rb.Mass = mass;
                if (ImGui.DragFloat("Drag",         ref drag,  0.01f)) rb.BaseDrag = drag;
                if (ImGui.DragFloat("Angular Drag", ref adrag, 0.01f)) rb.AngularDrag = adrag;
                if (ImGui.Checkbox("Is Kinematic",  ref kin))  rb.IsKinematic = kin;
                if (ImGui.Checkbox("Use Gravity",   ref grav)) rb.UseGravity  = grav;
                ImGui.Text($"Velocity: {rb.Velocity}");
                break;

            // ── NavMeshAgent ──────────────────────────────────────────────
            case BADGE.Core.MissingSystemsIntegration.NavMeshAgent agent:
                float speed = agent.Speed, stopDist = agent.StoppingDistance;
                if (ImGui.DragFloat("Speed",            ref speed,    0.1f)) agent.Speed = speed;
                if (ImGui.DragFloat("Stopping Distance",ref stopDist, 0.05f)) agent.StoppingDistance = stopDist;
                ImGui.TextDisabled($"Has Path: {agent.HasPath}");
                if (ImGui.Button("Stop")) agent.Stop();
                break;

            // ── BehaviorTreeRunner ────────────────────────────────────────
            case BADGE.Core.AI.BehaviorTreeRunner btr:
                ImGui.TextDisabled("BehaviorTreeRunner attached");
                if (ImGui.Button("Tick Once")) btr.Tick(0.016f);
                break;

            // ── SurvivalStats ─────────────────────────────────────────────
            case BADGE.Gameplay.SurvivalStats ss:
                ImGui.Text($"Health:      {ss.Health:F1} / {ss.MaxHealth:F0}");
                ImGui.Text($"Hunger:      {ss.Hunger:F1} / {ss.MaxHunger:F0}");
                ImGui.Text($"Thirst:      {ss.Thirst:F1} / {ss.MaxThirst:F0}");
                ImGui.Text($"Temperature: {ss.Temperature:F1}°C");
                float hd = ss.HungerDrain, td = ss.ThirstDrain;
                if (ImGui.DragFloat("Hunger Drain/s",  ref hd, 0.001f, 0f, 1f)) ss.HungerDrain = hd;
                if (ImGui.DragFloat("Thirst Drain/s",  ref td, 0.001f, 0f, 1f)) ss.ThirstDrain = td;
                break;

            // ── DayNightCycle (Component) ─────────────────────────────────
            case BADGE.Gameplay.DayNightCycle dnc:
                float todShow = dnc.TimeOfDay;
                ImGui.SliderFloat("Time of Day (r/o)", ref todShow, 0f, 1f);
                float dayLen = dnc.DayDuration;
                if (ImGui.DragFloat("Day Length (s)", ref dayLen, 1f, 10f, 3600f)) dnc.DayDuration = dayLen;
                ImGui.Text($"Time: {dnc.GetTimeString()}  IsDay: {dnc.IsDay}");
float spd = dnc.SpeedScale;
if (ImGui.DragFloat("Speed Scale", ref spd, 0.01f, 0f, 100f)) dnc.SpeedScale = spd;
                break;

            // ── Buoyancy ──────────────────────────────────────────────────
            case BADGE.Gameplay.Buoyancy buoy:
                float bf = buoy.Volume;
                float wl = buoy.WaterLevel;
                if (ImGui.DragFloat("Volume (m³)", ref bf, 0.05f, 0.01f, 1000f)) buoy.Volume = bf;
                if (ImGui.DragFloat("Water Level",    ref wl, 0.1f)) buoy.WaterLevel = wl;
                break;

            // ── ChunkStreamer ─────────────────────────────────────────────
            case BADGE.Gameplay.ChunkStreamer cs2:
                int lr = cs2.LoadRadius;
                if (ImGui.InputInt("Load Radius", ref lr)) cs2.LoadRadius = Math.Max(1, lr);
                ImGui.Text($"Loaded: {cs2.LoadedCount} chunks  Chunk Size: {cs2.ChunkSize}");
                break;

            // ── TerrainSystem ─────────────────────────────────────────────
            case BADGE.Core.MissingSystemsIntegration.TerrainSystem ts:
                ImGui.Text($"Width: {ts.Width}  Height: {ts.Height}");
                if (ImGui.Button("Regenerate")) ts.Generate();
                break;

            // ── FPS Camera ────────────────────────────────────────────────
            case BADGE.Core.Cameras.FPSCamera fps:
                float mspeed = fps.MoveSpeed;
                if (ImGui.DragFloat("Move Speed", ref mspeed, 0.1f)) fps.MoveSpeed = mspeed;
                break;

            // ── Fallback: generic property display ────────────────────────
            default:
                ImGui.TextDisabled($"({comp.GetType().FullName})");
                ImGui.TextWrapped("Properties editable via script. See API Reference.");
                break;
        }
    }

    // ── Conversion helpers ─────────────────────────────────────────────────
    private static Vector3 ToV3(OpenTK.Mathematics.Vector3 v) => new(v.X, v.Y, v.Z);
    private static OpenTK.Mathematics.Vector3 FromV3(Vector3 v) => new(v.X, v.Y, v.Z);
    private static Vector4 ToV4(OpenTK.Mathematics.Vector4 v) => new(v.X, v.Y, v.Z, v.W);
    private static Vector4 ToV4(OpenTK.Graphics.Color4 c)     => new(c.R, c.G, c.B, c.A);
    private static OpenTK.Graphics.Color4 FromV4Color(Vector4 v) => new(v.X, v.Y, v.Z, v.W);
}
