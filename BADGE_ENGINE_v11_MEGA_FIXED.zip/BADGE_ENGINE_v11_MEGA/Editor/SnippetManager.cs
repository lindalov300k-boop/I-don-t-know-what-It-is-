using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ImGuiNET;
using Newtonsoft.Json;

namespace BADGE.Editor
{
    /// <summary>
    /// Snippet Manager — stores, searches, and copies code snippets.
    /// Persists to Config/Snippets/snippets.json.
    /// Renders an ImGui panel with search, list, and preview.
    /// </summary>
    public static class SnippetManager
    {
        private static readonly string SnippetDir =
            Path.Combine("Config", "Snippets");

        private static readonly List<CodeSnippet> _snippets = new();
        private static string  _searchQuery = "";
        private static int     _selectedIdx = -1;
        private static bool    _initialized;

        public static void Initialize()
        {
            if (_initialized) return;
            Directory.CreateDirectory(SnippetDir);
            LoadAll();
            if (_snippets.Count == 0) SeedDefaults();
            _initialized = true;
        }

        // ── ImGui Panel ───────────────────────────────────────────────────
        public static void RenderPanel()
        {
            if (!ImGui.Begin("Snippet Library")) { ImGui.End(); return; }

            // Search bar + New button
            ImGui.SetNextItemWidth(ImGui.GetContentRegionAvail().X - 120);
            ImGui.InputText("##search", ref _searchQuery, 256);
            ImGui.SameLine();
            if (ImGui.Button("New"))    CreateNew();
            ImGui.SameLine();
            if (ImGui.Button("Import")) ImportFromFile();

            ImGui.Separator();

            // Filtered list
            var filtered = string.IsNullOrWhiteSpace(_searchQuery)
                ? _snippets
                : _snippets.Where(s =>
                    s.Title.Contains(_searchQuery, StringComparison.OrdinalIgnoreCase) ||
                    s.Tags.Any(t => t.Contains(_searchQuery, StringComparison.OrdinalIgnoreCase))
                  ).ToList();

            for (int i = 0; i < filtered.Count; i++)
            {
                var s = filtered[i];
                bool selected = _selectedIdx == _snippets.IndexOf(s);
                string tag    = s.Tags.Count > 0 ? $"  [{string.Join(", ", s.Tags)}]" : "";

                if (ImGui.Selectable($"{s.Title}{tag}##snip{i}", selected))
                    _selectedIdx = _snippets.IndexOf(s);

                if (ImGui.BeginPopupContextItem($"ctx{i}"))
                {
                    if (ImGui.MenuItem("Copy to Clipboard")) ImGui.SetClipboardText(s.Code);
                    if (ImGui.MenuItem("Delete"))
                    {
                        _snippets.Remove(s);
                        SaveAll();
                        _selectedIdx = -1;
                    }
                    ImGui.EndPopup();
                }
            }

            ImGui.Separator();

            // Preview pane
            if (_selectedIdx >= 0 && _selectedIdx < _snippets.Count)
            {
                var s = _snippets[_selectedIdx];
                ImGui.Text($"Title: {s.Title}");
                ImGui.Text($"Lang : {s.Language}");
                ImGui.Text($"Tags : {string.Join(", ", s.Tags)}");
                ImGui.Separator();
                ImGui.InputTextMultiline("##code", ref s.Code, 8192,
                    new System.Numerics.Vector2(-1, 200),
                    ImGuiInputTextFlags.ReadOnly);
                if (ImGui.Button("Copy##copy")) ImGui.SetClipboardText(s.Code);
                ImGui.SameLine();
                if (ImGui.Button("Save##save")) { SaveSnippet(s); SaveAll(); }
            }

            ImGui.End();
        }

        // ── CRUD ──────────────────────────────────────────────────────────
        public static CodeSnippet Add(string title, string code,
                                       string language = "csharp",
                                       params string[] tags)
        {
            var snippet = new CodeSnippet
            {
                Id        = Guid.NewGuid().ToString("N"),
                Title     = title,
                Code      = code,
                Language  = language,
                Tags      = new List<string>(tags),
                CreatedAt = DateTime.UtcNow
            };
            _snippets.Add(snippet);
            SaveAll();
            return snippet;
        }

        public static bool Remove(string id)
        {
            int idx = _snippets.FindIndex(s => s.Id == id);
            if (idx < 0) return false;
            _snippets.RemoveAt(idx);
            SaveAll();
            return true;
        }

        public static IEnumerable<CodeSnippet> Search(string query)
            => _snippets.Where(s =>
                s.Title.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                s.Code.Contains(query, StringComparison.OrdinalIgnoreCase)  ||
                s.Tags.Any(t => t.Contains(query, StringComparison.OrdinalIgnoreCase)));

        public static CodeSnippet? Get(string id)
            => _snippets.FirstOrDefault(s => s.Id == id);

        // ── Persistence ───────────────────────────────────────────────────
        public static void SaveAll()
        {
            File.WriteAllText(
                Path.Combine(SnippetDir, "snippets.json"),
                JsonConvert.SerializeObject(_snippets, Formatting.Indented));
        }

        private static void LoadAll()
        {
            string path = Path.Combine(SnippetDir, "snippets.json");
            if (!File.Exists(path)) return;
            try
            {
                var list = JsonConvert.DeserializeObject<List<CodeSnippet>>(
                    File.ReadAllText(path));
                if (list != null) _snippets.AddRange(list);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[SnippetManager] Failed to load snippets: {ex.Message}");
            }
        }

        private static void SaveSnippet(CodeSnippet s)
            => File.WriteAllText(Path.Combine(SnippetDir, s.Id + ".cs"), s.Code);

        private static void CreateNew()
            => Add("New Snippet", "// Write your snippet here\n");

        private static void ImportFromFile()
            => Console.WriteLine("[SnippetManager] Drag a .cs file into Config/Snippets/ to import.");

        // ── Default snippets ──────────────────────────────────────────────
        private static void SeedDefaults()
        {
            Add("Move with WASD", @"void Update(float dt) {
    float h = InputSystem.GetAxis(""Horizontal"");
    float v = InputSystem.GetAxis(""Vertical"");
    Transform.Translate(new Vector3(h, 0, v) * Speed * dt);
}", "csharp", "input", "movement");

            Add("Destroy on trigger", @"public override void Awake() {
    var col = GetComponent<SphereCollider>();
    col.IsTrigger = true;
    col.TriggerEnter += other => GameObject.Destroy(other.GameObject);
}", "csharp", "physics", "trigger");

            Add("Play audio on start", @"public override void Start() {
    var src = GetComponent<AudioSource>();
    src.Clip = Resources.Load<AudioClip>(""SFX/Jump"");
    src.Play();
}", "csharp", "audio");

            Add("Lerp camera follow", @"void LateUpdate(float dt) {
    var target = _target.Transform.Position + Offset;
    Transform.Position = Vector3.Lerp(Transform.Position, target, SmoothSpeed * dt);
}", "csharp", "camera");

            Add("Spawn from object pool", @"var pool = new ObjectPool<Bullet>();
var bullet = pool.Get();
bullet.Transform.Position = spawnPoint;
bullet.Initialize(direction, speed);
// When done: pool.Return(bullet);", "csharp", "pool", "spawn");

            SaveAll();
        }
    }

    // ── Data model ────────────────────────────────────────────────────────
    public class CodeSnippet
    {
        public string       Id        { get; set; } = "";
        public string       Title     { get; set; } = "";
        public string       Code      { get; set; } = "";
        public string       Language  { get; set; } = "csharp";
        public List<string> Tags      { get; set; } = new();
        public DateTime     CreatedAt { get; set; }
        public string       Source    { get; set; } = "local";
    }
}
