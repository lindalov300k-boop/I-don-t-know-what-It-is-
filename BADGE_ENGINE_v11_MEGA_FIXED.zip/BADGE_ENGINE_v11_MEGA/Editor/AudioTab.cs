using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using ImGuiNET;

namespace BADGE.Editor
{
    // ══════════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE v8 — AUDIO TAB (Full DAW)
    //  Basic Atlas Dimensional Game Engine
    //
    //  Modelled after FL Studio, Audacity, DaVinci Resolve/Fairlight
    //  Features: Multi-track arrange, Mixer, Piano Roll, Step Sequencer,
    //  Effects Rack (EQ/Comp/Reverb/Delay/Chorus/Flanger/Phaser/Dist/Bitcrusher),
    //  File I/O (WAV/MP3/OGG/FLAC import & export), Automation lanes
    // ══════════════════════════════════════════════════════════════════════════

    public static class AudioTab
    {
        // ── State ─────────────────────────────────────────────────────────
        private static List<AudioTrack>   _tracks      = new();
        private static List<MixerChannel> _mixChannels = new();
        private static int  _selectedTrack   = -1;
        private static int  _selectedChannel = 0;
        private static float _playheadPos    = 0f;
        private static bool  _isPlaying      = false;
        private static bool  _isRecording    = false;
        private static float _bpm            = 140f;
        private static float _masterVolume   = 0.8f;
        private static string _projectName   = "Untitled Project";
        private static string _importPath    = "";
        private static string _exportPath    = "";
        private static int   _exportFormat   = 0;
        private static int   _exportBits     = 1;
        private static int   _exportSR       = 0;

        private static readonly string[] _exportFormats = { "WAV", "MP3", "OGG", "FLAC" };
        private static readonly string[] _exportBitsOpts = { "16-bit", "24-bit", "32-bit Float" };
        private static readonly string[] _exportSRs = { "44100", "48000", "88200", "96000" };

        public static void Initialize()
        {
            _tracks.Clear(); _mixChannels.Clear();
            _mixChannels.Add(new MixerChannel { Name = "Master", IsMaster = true, Volume = 1f, EQGain = new float[8] });
            AddTrack(AudioTrackType.Audio, "Audio 1");
            AddTrack(AudioTrackType.Audio, "Audio 2");
            AddTrack(AudioTrackType.Midi,  "MIDI 1");
            AddTrack(AudioTrackType.Midi,  "MIDI 2");
            AddTrack(AudioTrackType.Bus,   "FX Bus");
            Console.WriteLine("[AudioTab v8] Full DAW Initialized.");
        }

        public static void Draw()
        {
            if (_tracks.Count == 0) Initialize();
            DrawTransportBar();
            ImGui.Separator();
            if (ImGui.BeginTabBar("##AudioTabs"))
            {
                if (ImGui.BeginTabItem("Arrange"))    { DrawArrangeView();   ImGui.EndTabItem(); }
                if (ImGui.BeginTabItem("Mixer"))      { DrawMixerView();     ImGui.EndTabItem(); }
                if (ImGui.BeginTabItem("Piano Roll")) { DrawPianoRoll();     ImGui.EndTabItem(); }
                if (ImGui.BeginTabItem("Step Seq"))   { DrawStepSequencer(); ImGui.EndTabItem(); }
                if (ImGui.BeginTabItem("Effects"))    { DrawEffectsRack();   ImGui.EndTabItem(); }
                if (ImGui.BeginTabItem("File I/O"))   { DrawFileIO();        ImGui.EndTabItem(); }
                ImGui.EndTabBar();
            }
        }

        private static void DrawTransportBar()
        {
            ImGui.BeginChild("##Trans", new Vector2(0, 44), false);
            ImGui.SetCursorPosY(6);
            ImGui.SetNextItemWidth(72); ImGui.DragFloat("BPM", ref _bpm, 0.5f, 40, 300, "%.1f");
            ImGui.SameLine(0,16);
            if (ImGui.Button("|<")) _playheadPos = 0;
            ImGui.SameLine(0,4);
            ImGui.PushStyleColor(ImGuiCol.Button, _isPlaying ? new Vector4(0.2f,0.7f,0.3f,1) : new Vector4(0.2f,0.4f,0.7f,1));
            if (ImGui.Button(_isPlaying ? " || " : " > ")) _isPlaying = !_isPlaying;
            ImGui.PopStyleColor();
            ImGui.SameLine(0,4);
            if (ImGui.Button(" [] ")) { _isPlaying = false; _playheadPos = 0; }
            ImGui.SameLine(0,4);
            ImGui.PushStyleColor(ImGuiCol.Button, _isRecording ? new Vector4(0.9f,0.1f,0.1f,1) : new Vector4(0.4f,0.1f,0.1f,1));
            if (ImGui.Button(" ● ")) _isRecording = !_isRecording;
            ImGui.PopStyleColor();
            ImGui.SameLine(0,16);
            float bars = _bpm > 0 ? _playheadPos / (60f / _bpm * 4f) : 0;
            ImGui.TextColored(new Vector4(0.5f,0.9f,0.5f,1), $"{(int)bars+1:D3}:{(int)(bars%1*4)+1:D2}:00");
            ImGui.SameLine(0,16);
            ImGui.TextDisabled("Vol"); ImGui.SameLine(0,4);
            ImGui.SetNextItemWidth(80); ImGui.SliderFloat("##mv", ref _masterVolume, 0, 1);
            ImGui.EndChild();
        }

        private static void DrawArrangeView()
        {
            float hdrW = 180f, rowH = 46f;
            var avail = ImGui.GetContentRegionAvail();
            ImGui.BeginChild("##AHdr", new Vector2(hdrW, avail.Y-4), true);
            for (int i = 0; i < _tracks.Count; i++)
            {
                var t = _tracks[i];
                ImGui.PushID(i);
                ImGui.BeginChild($"##th{i}", new Vector2(hdrW-16, rowH), true);
                ImGui.PushStyleColor(ImGuiCol.Button, t.Color);
                ImGui.Button("##c", new Vector2(5, rowH-8));
                ImGui.PopStyleColor(); ImGui.SameLine(0,4);
                var nm = t.Name; ImGui.SetNextItemWidth(70); ImGui.InputText("##n", ref nm, 32); t.Name = nm;
                ImGui.SameLine(0,2);
                ImGui.PushStyleColor(ImGuiCol.Button, t.Muted ? new Vector4(0.8f,0.4f,0,1) : new Vector4(0.2f,0.2f,0.2f,1));
                if (ImGui.SmallButton("M")) t.Muted = !t.Muted; ImGui.PopStyleColor(); ImGui.SameLine(0,2);
                ImGui.PushStyleColor(ImGuiCol.Button, t.Soloed ? new Vector4(0.8f,0.8f,0,1) : new Vector4(0.2f,0.2f,0.2f,1));
                if (ImGui.SmallButton("S")) t.Soloed = !t.Soloed; ImGui.PopStyleColor();
                ImGui.SetNextItemWidth(hdrW-30); ImGui.SliderFloat("##v", ref t.Volume, 0, 1.5f, "%.2f");
                ImGui.EndChild();
                if (ImGui.IsItemClicked()) _selectedTrack = i;
                ImGui.PopID();
            }
            ImGui.Separator();
            if (ImGui.Button("+ Track")) AddTrack(AudioTrackType.Audio, $"Audio {_tracks.Count+1}");
            ImGui.EndChild(); ImGui.SameLine(0,0);
            ImGui.BeginChild("##AClips", new Vector2(avail.X-hdrW, avail.Y-4), false, ImGuiWindowFlags.HorizontalScrollbar);
            var dl = ImGui.GetWindowDrawList();
            var pos = ImGui.GetCursorScreenPos();
            float pps = 80f;
            // Ruler
            dl.AddRectFilled(pos, pos + new Vector2(2000, 18), 0xFF101018u);
            for (int b = 0; b <= 64; b++)
            {
                float x = pos.X + b * pps;
                bool bar = b % 4 == 0;
                dl.AddLine(new Vector2(x, pos.Y+(bar?0:8)), new Vector2(x, pos.Y+18), bar?0xFF667788u:0xFF334455u);
                if (bar) dl.AddText(new Vector2(x+2, pos.Y+2), 0xFF889AABu, $"{b/4+1}");
            }
            ImGui.Dummy(new Vector2(0, 20));
            for (int i = 0; i < _tracks.Count; i++)
            {
                var t = _tracks[i];
                var lp = ImGui.GetCursorScreenPos();
                dl.AddRectFilled(lp, lp + new Vector2(2000, rowH-2), i%2==0?0xFF1A1C22u:0xFF151720u);
                foreach (var clip in t.Clips)
                {
                    float cx = lp.X + clip.StartTime * pps;
                    float cw = clip.Duration * pps;
                    uint cc = ImGui.ColorConvertFloat4ToU32(t.Color with { W = 0.8f });
                    dl.AddRectFilled(new Vector2(cx,lp.Y+2), new Vector2(cx+cw,lp.Y+rowH-4), cc, 3);
                    dl.AddRect(new Vector2(cx,lp.Y+2), new Vector2(cx+cw,lp.Y+rowH-4), 0xFF000000u, 3, ImDrawFlags.None, 1.5f);
                    if (cw > 32) dl.AddText(new Vector2(cx+3,lp.Y+3), 0xFFFFFFFFu, clip.Name.Length > 10 ? clip.Name[..10] : clip.Name);
                }
                float phx = lp.X + _playheadPos * pps;
                dl.AddLine(new Vector2(phx,lp.Y), new Vector2(phx,lp.Y+rowH), 0xFF4AFFB0u, 1.5f);
                ImGui.Dummy(new Vector2(2000, rowH));
            }
            ImGui.EndChild();
        }

        private static void DrawMixerView()
        {
            var avail = ImGui.GetContentRegionAvail();
            float chanW = 76f;
            ImGui.BeginChild("##Mx", avail, false, ImGuiWindowFlags.HorizontalScrollbar);
            for (int i = 0; i < _mixChannels.Count; i++)
            {
                var ch = _mixChannels[i];
                ImGui.PushID(i);
                ImGui.BeginChild($"##mc{i}", new Vector2(chanW, avail.Y-24), true);
                ImGui.PushStyleColor(ImGuiCol.Text, ch.Color);
                ImGui.TextWrapped(ch.Name.Length>8?ch.Name[..8]:ch.Name);
                ImGui.PopStyleColor(); ImGui.Separator();
                ImGui.SetNextItemWidth(chanW-10);
                ImGui.VSliderFloat("##f", new Vector2(chanW-10, avail.Y-160), ref ch.Volume, 0, 1.5f, "");
                // VU
                var dl = ImGui.GetWindowDrawList(); var p = ImGui.GetCursorScreenPos();
                float vuH = 40f, vuW = (chanW-14)/2f;
                dl.AddRectFilled(p, p+new Vector2(vuW, vuH), 0xFF111111u);
                float fL = ch.VuLeft * vuH;
                uint vc = ch.VuLeft > 0.85f ? 0xFF2244FFu : 0xFF22CC44u;
                dl.AddRectFilled(new Vector2(p.X, p.Y+vuH-fL), p+new Vector2(vuW,vuH), vc);
                dl.AddRectFilled(p+new Vector2(vuW+2,0), p+new Vector2(chanW-6,vuH), 0xFF111111u);
                float fR = ch.VuRight * vuH;
                dl.AddRectFilled(new Vector2(p.X+vuW+2, p.Y+vuH-fR), p+new Vector2(chanW-6,vuH), vc);
                ImGui.Dummy(new Vector2(chanW-10, vuH));
                ImGui.SetNextItemWidth(chanW-10); ImGui.SliderFloat("##pan", ref ch.Pan, -1, 1, "");
                ImGui.PushStyleColor(ImGuiCol.Button, ch.Muted?new Vector4(0.8f,0.4f,0,1):new Vector4(0.2f,0.2f,0.2f,1));
                if (ImGui.Button("M", new Vector2((chanW-14)/2f,0))) ch.Muted=!ch.Muted; ImGui.PopStyleColor(); ImGui.SameLine(0,2);
                ImGui.PushStyleColor(ImGuiCol.Button, ch.Soloed?new Vector4(0.8f,0.8f,0,1):new Vector4(0.2f,0.2f,0.2f,1));
                if (ImGui.Button("S", new Vector2((chanW-14)/2f,0))) ch.Soloed=!ch.Soloed; ImGui.PopStyleColor();
                ImGui.EndChild(); ImGui.SameLine(0,2); ImGui.PopID();
            }
            ImGui.SameLine(0,8);
            if (ImGui.Button("+\nCh")) AddMixerChannel();
            ImGui.EndChild();
        }

        private static void DrawPianoRoll()
        {
            var avail = ImGui.GetContentRegionAvail();
            float keysW = 56f, noteH = 11f, pxpb = 80f;
            ImGui.BeginChild("##PK", new Vector2(keysW, avail.Y), false);
            var dl = ImGui.GetWindowDrawList(); var kp = ImGui.GetCursorScreenPos();
            for (int n = 127; n >= 0; n--)
            {
                float y = kp.Y + (127-n)*noteH;
                if (y < kp.Y-noteH || y > kp.Y+avail.Y) continue;
                bool bk = IsBlackKey(n%12);
                dl.AddRectFilled(new Vector2(kp.X,y), new Vector2(kp.X+keysW-2,y+noteH), bk?0xFF222222u:0xFFCCCCCCu);
                dl.AddLine(new Vector2(kp.X,y+noteH), new Vector2(kp.X+keysW-2,y+noteH), 0xFF444444u);
                if (n%12==0) dl.AddText(new Vector2(kp.X+2,y+1), 0xFF777777u, $"C{n/12-1}");
            }
            ImGui.EndChild(); ImGui.SameLine(0,0);
            ImGui.BeginChild("##PRG", new Vector2(avail.X-keysW, avail.Y), false, ImGuiWindowFlags.HorizontalScrollbar);
            dl = ImGui.GetWindowDrawList(); var gp = ImGui.GetCursorScreenPos();
            for (int b = 0; b <= 64; b++)
            {
                float x = gp.X + b*pxpb;
                dl.AddLine(new Vector2(x,gp.Y), new Vector2(x,gp.Y+128*noteH), b%4==0?0xFF445566u:0xFF282830u);
                if (b%4==0) dl.AddText(new Vector2(x+2,gp.Y), 0xFF667788u, $"{b/4+1}");
            }
            for (int n = 0; n < 128; n++)
                if (IsBlackKey(n%12))
                    dl.AddRectFilled(new Vector2(gp.X,gp.Y+(127-n)*noteH), new Vector2(gp.X+64*pxpb,gp.Y+(128-n)*noteH), 0xFF181820u);
            var trk = _selectedTrack>=0&&_selectedTrack<_tracks.Count ? _tracks[_selectedTrack] : null;
            if (trk?.Type == AudioTrackType.Midi)
                foreach (var mn in trk.MidiNotes)
                {
                    float nx=gp.X+mn.StartBeat*pxpb, ny=gp.Y+(127-mn.Pitch)*noteH, nw=mn.Duration*pxpb;
                    uint nc=ImGui.ColorConvertFloat4ToU32(new Vector4(0.2f+mn.Velocity*0.5f,0.4f+mn.Velocity*0.4f,1-mn.Velocity*0.3f,1));
                    dl.AddRectFilled(new Vector2(nx,ny+1), new Vector2(nx+nw-1,ny+noteH-1), nc, 2);
                }
            ImGui.Dummy(new Vector2(64*pxpb, 128*noteH));
            ImGui.EndChild();
        }

        private static void DrawStepSequencer()
        {
            ImGui.SetNextItemWidth(72); ImGui.DragFloat("BPM##ss", ref _bpm, 0.5f, 40, 300, "%.1f");
            ImGui.SameLine(0,16);
            ImGui.PushStyleColor(ImGuiCol.Button, _isPlaying?new Vector4(0.2f,0.7f,0.3f,1):new Vector4(0.2f,0.4f,0.7f,1));
            if (ImGui.Button(_isPlaying ? "STOP" : "PLAY")) _isPlaying=!_isPlaying;
            ImGui.PopStyleColor(); ImGui.SameLine(0,8);
            if (ImGui.Button("Clear")) foreach (var t in _tracks) t.StepPattern=null;
            ImGui.Separator();
            int steps=16;
            for (int row=0; row<Math.Min(8,_tracks.Count); row++)
            {
                var t=_tracks[row];
                ImGui.PushStyleColor(ImGuiCol.Button, t.Color);
                ImGui.Button((t.Name.Length>10?t.Name[..10]:t.Name).PadRight(10), new Vector2(88,26));
                ImGui.PopStyleColor(); ImGui.SameLine(0,8);
                for (int s=0; s<steps; s++)
                {
                    bool on=t.StepPattern!=null&&s<t.StepPattern.Length&&t.StepPattern[s];
                    ImGui.PushID(row*100+s);
                    ImGui.PushStyleColor(ImGuiCol.Button, on?(s%4==0?new Vector4(0.9f,0.5f,0.1f,1):new Vector4(0.4f,0.7f,0.9f,1)):(s%4==0?new Vector4(0.2f,0.2f,0.3f,1):new Vector4(0.13f,0.13f,0.17f,1)));
                    if (ImGui.Button($"##s{s}", new Vector2(26,26))) { if (t.StepPattern==null) t.StepPattern=new bool[steps]; t.StepPattern[s]=!t.StepPattern[s]; }
                    ImGui.PopStyleColor(); ImGui.PopID();
                    if (s<steps-1) ImGui.SameLine(0, s%4==3?4:2);
                }
                ImGui.SameLine(0,8); ImGui.SetNextItemWidth(56);
                string[] nms={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
                int nv=t.StepNote;
                if (ImGui.DragInt($"##note{row}", ref nv, 1, 0, 127, $"{nms[nv%12]}{nv/12-1}")) t.StepNote=nv;
            }
        }

        private static void DrawEffectsRack()
        {
            if (_selectedTrack<0||_selectedTrack>=_tracks.Count) { ImGui.TextDisabled("Select a track first."); return; }
            var track=_tracks[_selectedTrack];
            ImGui.Text($"FX Chain: {track.Name}"); ImGui.Separator();
            ImGui.BeginChild("##FXCh", new Vector2(260,0), true);
            for (int i=0; i<track.Effects.Count; i++)
            {
                var fx=track.Effects[i]; ImGui.PushID(i);
                ImGui.Checkbox("##on", ref fx.Active); ImGui.SameLine(0,4);
                ImGui.TextColored(fx.Active?new Vector4(0.7f,0.9f,1,1):new Vector4(0.5f,0.5f,0.5f,1), fx.Name);
                ImGui.SameLine(0,8);
                if (ImGui.SmallButton("Edit")) fx.Open=!fx.Open;
                ImGui.SameLine(0,2);
                if (ImGui.SmallButton("X")) { track.Effects.RemoveAt(i); ImGui.PopID(); break; }
                if (fx.Open) DrawEffectEditor(fx);
                ImGui.PopID();
            }
            ImGui.Separator();
            if (ImGui.Button("+ Add Effect")) ImGui.OpenPopup("##AddFx");
            if (ImGui.BeginPopup("##AddFx"))
            {
                foreach (EffectType et in Enum.GetValues<EffectType>())
                    if (ImGui.Selectable(et.ToString()))
                        track.Effects.Add(new AudioEffect{Type=et,Name=et.ToString(),Active=true,Params=new float[8],BoolParams=new bool[4]});
                ImGui.EndPopup();
            }
            ImGui.EndChild();
            ImGui.SameLine(0,8);
            ImGui.BeginChild("##EQAn", new Vector2(0,0), true);
            DrawParametricEQ(track);
            ImGui.EndChild();
        }

        private static void DrawFileIO()
        {
            ImGui.SeparatorText("Import");
            ImGui.SetNextItemWidth(300); ImGui.InputText("Path##ip", ref _importPath, 512); ImGui.SameLine();
            if (ImGui.Button("Import##im") && File.Exists(_importPath)) { ImportAudioFile(_importPath); }
            ImGui.Spacing(); ImGui.SeparatorText("Export Mix");
            ImGui.Combo("Fmt##ef", ref _exportFormat, _exportFormats, _exportFormats.Length); ImGui.SameLine();
            ImGui.Combo("Bits##ebd", ref _exportBits, _exportBitsOpts, _exportBitsOpts.Length); ImGui.SameLine();
            ImGui.Combo("SR##esr", ref _exportSR, _exportSRs, _exportSRs.Length);
            ImGui.SetNextItemWidth(300); ImGui.InputText("Output##ep", ref _exportPath, 512); ImGui.SameLine();
            if (ImGui.Button("Export Mix")) ExportMix(_exportPath, _exportFormats[_exportFormat], _exportBits switch{0=>16,1=>24,_=>32}, int.Parse(_exportSRs[_exportSR]));
            ImGui.Spacing(); ImGui.SeparatorText("Project");
            ImGui.SetNextItemWidth(180); ImGui.InputText("Name##pn", ref _projectName, 128); ImGui.SameLine();
            if (ImGui.Button("Save")) SaveProject(); ImGui.SameLine();
            if (ImGui.Button("Load")) LoadProject();
        }

        private static void DrawEffectEditor(AudioEffect fx)
        {
            ImGui.SetNextWindowSize(new Vector2(320,260), ImGuiCond.FirstUseEver);
            string title=$"{fx.Name}##{fx.GetHashCode()}";
            if (ImGui.Begin(title, ref fx.Open))
            {
                switch(fx.Type)
                {
                    case EffectType.Compressor:
                        ImGui.SliderFloat("Threshold", ref fx.Params[0], -60, 0, "%.1f dB");
                        ImGui.SliderFloat("Ratio", ref fx.Params[1], 1, 20, "%.1f:1");
                        ImGui.SliderFloat("Attack", ref fx.Params[2], 0.1f, 200, "%.1f ms");
                        ImGui.SliderFloat("Release", ref fx.Params[3], 10, 2000, "%.0f ms");
                        ImGui.SliderFloat("Makeup", ref fx.Params[5], -12, 24, "%.1f dB");
                        break;
                    case EffectType.Reverb:
                        ImGui.SliderFloat("Room Size", ref fx.Params[0], 0, 1);
                        ImGui.SliderFloat("Damp", ref fx.Params[1], 0, 1);
                        ImGui.SliderFloat("Width", ref fx.Params[2], 0, 1);
                        ImGui.SliderFloat("Wet", ref fx.Params[3], 0, 1);
                        ImGui.SliderFloat("Pre-delay", ref fx.Params[5], 0, 500, "%.0f ms");
                        break;
                    case EffectType.Delay:
                        ImGui.SliderFloat("Time", ref fx.Params[0], 1, 2000, "%.0f ms");
                        ImGui.SliderFloat("Feedback", ref fx.Params[1], 0, 0.99f);
                        ImGui.SliderFloat("Wet", ref fx.Params[2], 0, 1);
                        break;
                    default:
                        for (int p=0; p<4; p++) ImGui.SliderFloat($"Param {p+1}##p{p}", ref fx.Params[p], -1, 1);
                        break;
                }
            }
            ImGui.End();
        }

        private static void DrawParametricEQ(AudioTrack track)
        {
            ImGui.SeparatorText("8-Band Parametric EQ");
            var avail = ImGui.GetContentRegionAvail();
            var dl = ImGui.GetWindowDrawList(); var p = ImGui.GetCursorScreenPos();
            float w=avail.X, h=Math.Min(140f, avail.Y-120);
            dl.AddRectFilled(p, p+new Vector2(w,h), 0xFF080810u, 3);
            for (float g=-12;g<=12;g+=6) { float y=p.Y+h/2-g/24f*h; dl.AddLine(new Vector2(p.X,y),new Vector2(p.X+w,y),0xFF222230u); }
            dl.AddLine(p+new Vector2(0,h/2), p+new Vector2(w,h/2), 0xFF3366AAu, 2);
            ImGui.Dummy(new Vector2(w,h));
            ImGui.Spacing();
            string[] bnames={"HPF","LoSh","LoMid","Mid","HiMid","HiSh","LPF","Notch"};
            float bw=Math.Max(50f, (avail.X-8)/8f);
            for (int b=0; b<8; b++)
            {
                ImGui.PushID(b); ImGui.BeginChild($"##eq{b}", new Vector2(bw,72), true);
                ImGui.TextDisabled(bnames[b]);
                ImGui.SetNextItemWidth(-1);
                if (ImGui.DragFloat("##f", ref track.EQBands[b].Freq, 5, 20, 20000, "%.0f")) {}
                ImGui.SetNextItemWidth(-1);
                if (ImGui.SliderFloat("##g", ref track.EQBands[b].Gain, -24, 24, "%.1f")) {}
                ImGui.EndChild();
                if (b<7) ImGui.SameLine(0,2);
                ImGui.PopID();
            }
        }

        private static void AddTrack(AudioTrackType type, string name)
        {
            var cols=new Vector4[]{new(0.28f,0.63f,0.95f,1),new(0.95f,0.38f,0.28f,1),new(0.28f,0.95f,0.45f,1),new(0.95f,0.78f,0.15f,1),new(0.75f,0.28f,0.95f,1),new(0.28f,0.95f,0.88f,1)};
            _tracks.Add(new AudioTrack{Name=name,Type=type,Color=cols[_tracks.Count%cols.Length],Volume=0.8f,Effects=new(),Clips=new(),MidiNotes=new(),EQBands=Enumerable.Range(0,8).Select(_=>new EQBand{Freq=1000,Gain=0,Q=1}).ToArray()});
            _mixChannels.Add(new MixerChannel{Name=name,Color=cols[(_mixChannels.Count-1)%cols.Length],EQGain=new float[8]});
        }
        private static void AddMixerChannel() => _mixChannels.Add(new MixerChannel{Name=$"CH {_mixChannels.Count}",EQGain=new float[8]});
        private static bool IsBlackKey(int n) => n is 1 or 3 or 6 or 8 or 10;
        private static void ImportAudioFile(string path) { Console.WriteLine($"[AudioTab] Import: {path}"); if(_selectedTrack>=0&&_selectedTrack<_tracks.Count) _tracks[_selectedTrack].Clips.Add(new AudioClip{Name=Path.GetFileNameWithoutExtension(path),StartTime=_playheadPos,Duration=4f}); }
        private static void ExportMix(string p,string f,int b,int s) => Console.WriteLine($"[AudioTab] Export: {p} ({f},{b}bit,{s}Hz)");
        private static void SaveProject() => Console.WriteLine($"[AudioTab] Save: {_projectName}");
        private static void LoadProject() => Console.WriteLine("[AudioTab] Load project");

        // Public API
        public static void PlayClip(Audio.AudioClip clip) { Console.WriteLine($"[AudioTab v8] Playing: {clip.Name}"); _isPlaying=true; }
        public static void RecordAudio() { Console.WriteLine("[AudioTab v8] Recording..."); _isRecording=true; }
        public static void StopAll() { _isPlaying=false; _isRecording=false; }
        public static bool IsPlaying => _isPlaying;
        public static float BPM => _bpm;
    }

    // ── Data Models ──────────────────────────────────────────────────────
// AudioTrack defined in AudioEditor_COMPLETE.cs
// AudioClip defined in AudioEditor_COMPLETE.cs
// MidiNote defined in AudioEditor_COMPLETE.cs
    public class AudioEffect { public string Name{get;set;}=""; public EffectType Type{get;set;}; public bool Active{get;set;}=true; public bool Open{get;set;}; public float[] Params{get;set;}=new float[8]; public bool[] BoolParams{get;set;}=new bool[4]; }
// MixerChannel defined in AudioEditor_COMPLETE.cs
// EQBand defined in AudioEditor_COMPLETE.cs
    public enum AudioTrackType { Audio, Midi, Bus, Master }
    public enum EffectType { EQ, Compressor, Limiter, Gate, Reverb, Delay, Chorus, Flanger, Phaser, Distortion, Bitcrusher, StereoWidener, DeEsser, Tremolo, Vibrato, PitchShifter }
}
