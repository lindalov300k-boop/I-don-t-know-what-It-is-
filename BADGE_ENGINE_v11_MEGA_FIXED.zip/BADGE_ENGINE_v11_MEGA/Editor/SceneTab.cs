using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using OpenTK.Graphics.OpenGL4;
using BADGE.Core;
using BADGE.Rendering;

namespace BADGE.Editor
{
    /// <summary>
    /// SceneTab: legacy entry point for gizmo rendering.
    /// The main 3D view is now owned by SceneViewPanel (FBO-based).
    /// RenderGizmos() is called by Engine.Render() when in editor mode;
    /// it draws selection outlines and transform handles into the active context.
    /// </summary>
    public static class SceneTab
    {
        private static bool _isActive = true;

        public static void SetActive(bool active) => _isActive = active;

        public static void Update(float deltaTime)
        {
            // Editor-mode update: keep selection highlight alive
        }

        public static void RenderGizmos()
        {
            if (!_isActive) return;

            var scene = SceneManager.GetActiveScene();
            if (scene == null) return;

            var shader = ShaderLibrary.GetShader("Gizmo");
            if (shader == null) return;

            shader.Use();

            // Draw world-origin axes (X = red, Y = green, Z = blue)
            DrawAxis(shader, Vector3.Zero, Vector3.UnitX, new Vector4(1, 0, 0, 1), 1f);
            DrawAxis(shader, Vector3.Zero, Vector3.UnitY, new Vector4(0, 1, 0, 1), 1f);
            DrawAxis(shader, Vector3.Zero, Vector3.UnitZ, new Vector4(0, 0, 1, 1), 1f);

            shader.Unuse();
        }

        private static void DrawAxis(Shader shader, Vector3 origin, Vector3 dir,
                                      Vector4 color, float length)
        {
            // Draw a single line from origin along dir * length
            var verts = new float[]
            {
                origin.X, origin.Y, origin.Z,
                origin.X + dir.X * length,
                origin.Y + dir.Y * length,
                origin.Z + dir.Z * length
            };

            int vao = GL.GenVertexArray();
            int vbo = GL.GenBuffer();
            GL.BindVertexArray(vao);
            GL.BindBuffer(BufferTarget.ArrayBuffer, vbo);
            GL.BufferData(BufferTarget.ArrayBuffer, verts.Length * sizeof(float),
                          verts, BufferUsageHint.StreamDraw);
            GL.EnableVertexAttribArray(0);
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 0, 0);

            var identity = Matrix4.Identity;
            shader.SetMatrix4("model", ref identity);
            shader.SetVector4("_Color", color);

            GL.DrawArrays(PrimitiveType.Lines, 0, 2);

            GL.BindVertexArray(0);
            GL.DeleteVertexArray(vao);
            GL.DeleteBuffer(vbo);
        }
    }
}
