using ImGuiNET;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using OpenTK.Windowing.Desktop;
using OpenTK.Windowing.Common;
using OpenTK.Windowing.GraphicsLibraryFramework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Numerics;
using System.Diagnostics;
using System.Runtime.InteropServices;
using BADGE.Input;
using BADGE.Input.Mobile;

namespace BADGE.Editor;

/// <summary>
/// BADGE Engine v10 — Main Editor Window
/// Full Unity/Godot-style editor with dockable panels, keyboard shortcuts,
/// undo/redo, clipboard, play mode, touch overlay, theme system, and more.
/// </summary>
public class EditorWindow : GameWindow
{
    // ── Project ──────────────────────────────────────────────────────────
    public string? PendingProjectPath { get; set; }
    public Scene ActiveScene => _activeScene;
    public GameObject? SelectedGameObject { get => _selectedGameObject; set => _selectedGameObject = value; }
    private string _projectRoot = Directory.GetCurrentDirectory();
    private string _projectName = "Untitled Project";

    // ── ImGui ────────────────────────────────────────────────────────────
    private ImGuiController _imGuiController = null!;

    // ── Scene ────────────────────────────────────────────────────────────
    private Scene        _activeScene        = null!;
    private GameObject?  _selectedGameObject;
    private bool         _isPlaying          = false;
    private bool         _isPaused           = false;
    private float        _deltaTime          = 0f;
    private Scene?       _prePlaysnapshot;

    // ── Panels (visibility flags) ─────────────────────────────────────────
    private bool _showHierarchy    = true;
    private bool _showInspector    = true;
    private bool _showProject      = true;
    private bool _showConsole      = true;
    private bool _showScene        = true;
    private bool _showGame         = false;
    private bool _showAudioMixer   = false;
    private bool _showAnimator     = false;
    private bool _showShaderGraph  = false;
    private bool _showAIPanel      = false;
    private bool _showProfiler     = false;
    private bool _showAbout        = false;
    private bool _showChangelog    = false;
    private bool _showPreferences  = false;
    private bool _showProjectSettings = false;
    private bool _showThemeEditor  = false;
    private bool _showIdleOverlay  = false;

    // ── Creative / tool tabs ──────────────────────────────────────────────
    private bool _showG3DP         = false;   // 3D Geometry Tab
    private bool _showDesignTab    = false;   // Design / Paint Tab  
    private bool _showAudioMaker   = false;   // Audio Maker (DAW Tab)
    private bool _showModelEditor  = false;   // Model Editor Tab
    private bool _showVideoEditor  = false;   // Video Timeline Tab
    private bool _showGameDemos    = false;   // Game Demos / Templates
    private bool _showNotesPanel   = false;   // Notes & TODO System

    // ── Editor panels ────────────────────────────────────────────────────
    private HierarchyPanel  _hierarchyPanel  = null!;
    private InspectorPanel  _inspectorPanel  = null!;
    private ProjectPanel    _projectPanel    = null!;
    private SceneViewPanel  _sceneViewPanel  = null!;
    private ConsolePanel    _consolePanel    = null!;

    // ── Creative tabs (instantiated in OnLoad) ────────────────────────────
    private GameDemosPanel  _gameDemosPanel  = null!;
    private EditorCamera    _editorCamera    = null!;

    // ── Clipboard & Undo ─────────────────────────────────────────────────
    private GameObject?           _clipboard;
    public  GameObject?           ClipboardGameObject { get => _clipboard; set => _clipboard = value; }
    private readonly Stack<Action> _undoStack = new();
    private readonly Stack<Action> _redoStack = new();

    // ── Touch input ───────────────────────────────────────────────────────
    private TouchControlLayout? _touchLayout;
    private bool _touchOverlayEnabled = false;
    private bool _showTouchDebug      = false;

    // ── Idle detection ────────────────────────────────────────────────────
    private float _idleTimer    = 0f;
    private float _idleThreshold = 300f;  // 5 minutes
    private bool  _isIdle       = false;
    private DateTime _lastActivity = DateTime.UtcNow;

    // ── FPS / stats ───────────────────────────────────────────────────────
    private float _fpsTimer    = 0f;
    private int   _frameCount  = 0;
    private float _displayFps  = 0f;

    // ─────────────────────────────────────────────────────────────────────
    //  CONSTRUCTOR
    // ─────────────────────────────────────────────────────────────────────
    public EditorWindow(GameWindowSettings gws, NativeWindowSettings nws)
        : base(gws, nws) { }

    // ─────────────────────────────────────────────────────────────────────
    //  ON LOAD
    // ─────────────────────────────────────────────────────────────────────
    protected override void OnLoad()
    {
        base.OnLoad();

        GL.ClearColor(0.15f, 0.15f, 0.15f, 1.0f);
        GL.Enable(EnableCap.DepthTest);
        GL.Enable(EnableCap.Blend);
        GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);

        // ImGui
        _imGuiController = new ImGuiController(ClientSize.X, ClientSize.Y);
        ApplyTheme();

        // Core systems
        BADGE.Core.ShaderLibrary.Initialize();

        // Default scene
        _activeScene = new Scene("SampleScene");
        CreateDefaultScene();

        // Editor camera
        _editorCamera = new EditorCamera();

        // Panels
        _hierarchyPanel = new HierarchyPanel(this);
        _inspectorPanel = new InspectorPanel(this);
        _projectPanel   = new ProjectPanel(this);
        _sceneViewPanel = new SceneViewPanel(this);
        _consolePanel   = new ConsolePanel();
        _gameDemosPanel = new GameDemosPanel();

        // Initialise stateless tabs
        AudioTab.Initialize();
        DesignTab.Initialize(1024, 1024);

        // Drag & drop manager
        // DragDropManager ready via singleton

        // Resolution port defaults
        ResolutionPort.SetCustomResolution(1920, 1080, false);

        // Touch input
        var hwnd = TryGetHwnd();
        TouchProvider.Initialize(hwnd,
            getMousePos:  () => new OpenTK.Mathematics.Vector2(MouseState.X, MouseState.Y),
            getMouseDown: () => MouseState.IsButtonDown(MouseButton.Left));

        _touchLayout = TouchControlLayout.TwoStick(ClientSize.X, ClientSize.Y);

        // Load pending project
        if (!string.IsNullOrEmpty(PendingProjectPath))
        {
            _consolePanel.Log($"[Project] Opening: {PendingProjectPath}");
            LoadProjectFrom(PendingProjectPath);
        }

        _consolePanel.Log("BADGE Engine v10 ready. Press ▶ to enter Play Mode.");
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DEFAULT SCENE
    // ─────────────────────────────────────────────────────────────────────
    private void CreateDefaultScene()
    {
        var cam = _activeScene.CreateGameObject("Main Camera");
        cam.Tag = "MainCamera";
        cam.AddComponent<BADGE.Core.Camera>();
        cam.Transform.Position = new Vector3(0, 1, -10);

        var light = _activeScene.CreateGameObject("Directional Light");
        var l = light.AddComponent<BADGE.Core.Light>();
        l.Type = BADGE.Core.LightType.Directional;
        light.Transform.Rotation = Quaternion.FromEulerAngles(
            new Vector3(50, -30, 0) * (MathF.PI / 180f));
    }

    // ─────────────────────────────────────────────────────────────────────
    //  THEME / STYLING  (fixes "styling is unusual")
    // ─────────────────────────────────────────────────────────────────────
    private void ApplyTheme()
    {
        // Apply current theme from ThemeSystem
        ThemeSystem.Instance.ApplyToImGui();

        // Enable docking + viewport
        var io = ImGui.GetIO();
        io.ConfigFlags |= ImGuiConfigFlags.DockingEnable;
        io.ConfigFlags |= ImGuiConfigFlags.ViewportsEnable;
        io.ConfigDockingWithShift = false;
        io.ConfigWindowsMoveFromTitleBarOnly = true;
        io.FontGlobalScale = 1.0f;

        var style = ImGui.GetStyle();
        style.WindowRounding   = 4f;
        style.ChildRounding    = 4f;
        style.FrameRounding    = 3f;
        style.GrabRounding     = 3f;
        style.TabRounding      = 4f;
        style.ScrollbarRounding= 3f;
        style.PopupRounding    = 4f;
        style.WindowBorderSize = 1f;
        style.FrameBorderSize  = 0f;
        style.TabBorderSize    = 0f;
        style.IndentSpacing    = 14f;
        style.ItemSpacing      = new System.Numerics.Vector2(8, 4);
        style.FramePadding     = new System.Numerics.Vector2(6, 3);
        style.WindowPadding    = new System.Numerics.Vector2(8, 8);
        style.DisplayWindowPadding = new System.Numerics.Vector2(19, 19);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  ON RESIZE
    // ─────────────────────────────────────────────────────────────────────
    protected override void OnResize(ResizeEventArgs e)
    {
        base.OnResize(e);
        GL.Viewport(0, 0, ClientSize.X, ClientSize.Y);
        _imGuiController?.WindowResized(ClientSize.X, ClientSize.Y);
        _touchLayout?.Resize(ClientSize.X, ClientSize.Y);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  ON UPDATE FRAME
    // ─────────────────────────────────────────────────────────────────────
    protected override void OnUpdateFrame(FrameEventArgs args)
    {
        base.OnUpdateFrame(args);
        _deltaTime = (float)args.Time;

        // FPS counter
        _fpsTimer  += _deltaTime;
        _frameCount++;
        if (_fpsTimer >= 0.5f)
        {
            _displayFps = _frameCount / _fpsTimer;
            _fpsTimer   = 0f;
            _frameCount = 0;
        }

        // Idle detection (fixes "idle state is unusual")
        UpdateIdleState();

        // Input feeds
        var mouseDelta = new OpenTK.Mathematics.Vector2(MouseState.Delta.X, MouseState.Delta.Y);
        InputSystem.Update(KeyboardState, MouseState, mouseDelta,
                           MouseState.ScrollDelta.Y, _deltaTime);
        BADGE.Core.Input.BeginFrame();
        foreach (var key in Enum.GetValues<Keys>())
            if (KeyboardState.IsKeyDown(key))
                BADGE.Core.Input.ProcessKeyDown(key);
        BADGE.Core.Input.ProcessMouseMove(
            new OpenTK.Mathematics.Vector2(MouseState.X, MouseState.Y));
        BADGE.Core.Input.ProcessScroll(MouseState.ScrollDelta.Y);
        if (TouchInput.IsTap(0))
            BADGE.Core.Input.ProcessMouseButton(MouseButton.Left, true);

        // Keyboard shortcuts (fixes "editor tabs are unusual")
        HandleKeyboardShortcuts();

        // Play mode updates
        if (_isPlaying && !_isPaused)
        {
            _touchLayout?.Update();
            _activeScene.Update(_deltaTime);
            _activeScene.FixedUpdate(_deltaTime);
            _activeScene.LateUpdate(_deltaTime);
        }

        _editorCamera.Update(this, _deltaTime);
    }

    private void UpdateIdleState()
    {
        bool anyInput = KeyboardState.IsAnyKeyDown || MouseState.IsAnyButtonDown ||
                        Math.Abs(MouseState.Delta.X) > 0.5f || Math.Abs(MouseState.Delta.Y) > 0.5f;
        if (anyInput)
        {
            _lastActivity = DateTime.UtcNow;
            if (_isIdle)
            {
                _isIdle = false;
                _showIdleOverlay = false;
                Title = $"BADGE Engine v10 — {_projectName}";
            }
        }

        _idleTimer = (float)(DateTime.UtcNow - _lastActivity).TotalSeconds;
        if (!_isIdle && _idleTimer >= _idleThreshold)
        {
            _isIdle = true;
            _showIdleOverlay = true;
        }
    }

    private void HandleKeyboardShortcuts()
    {
        bool ctrl  = KeyboardState.IsKeyDown(Keys.LeftControl) ||
                     KeyboardState.IsKeyDown(Keys.RightControl);
        bool shift = KeyboardState.IsKeyDown(Keys.LeftShift) ||
                     KeyboardState.IsKeyDown(Keys.RightShift);

        if (ctrl && KeyboardState.IsKeyPressed(Keys.N))
            { if (shift) QuickSetupWizard.Open(); else CreateNewScene(); }
        if (ctrl && KeyboardState.IsKeyPressed(Keys.O) && !shift) OpenScene();
        if (ctrl && KeyboardState.IsKeyPressed(Keys.S))
            { if (shift) SaveSceneAs(); else SaveScene(); }
        if (ctrl && KeyboardState.IsKeyPressed(Keys.Z)) UndoManager.Undo();
        if (ctrl && KeyboardState.IsKeyPressed(Keys.Y)) UndoManager.Redo();
        if (ctrl && KeyboardState.IsKeyPressed(Keys.D)) DuplicateSelected();
        if (KeyboardState.IsKeyPressed(Keys.Delete))    DeleteSelected();
        if (KeyboardState.IsKeyPressed(Keys.F5))        TogglePlayMode();
        if (KeyboardState.IsKeyPressed(Keys.F6))        PausePlayMode();
        if (KeyboardState.IsKeyPressed(Keys.F7))        StepFrame();
        if (ctrl && KeyboardState.IsKeyPressed(Keys.W)) CloseActiveTab();
        if (KeyboardState.IsKeyPressed(Keys.F1))        _showHierarchy  = !_showHierarchy;
        if (KeyboardState.IsKeyPressed(Keys.F2))        _showInspector  = !_showInspector;
        if (KeyboardState.IsKeyPressed(Keys.F3))        _showProject    = !_showProject;
        if (KeyboardState.IsKeyPressed(Keys.F4))        _showConsole    = !_showConsole;
        if (KeyboardState.IsKeyPressed(Keys.Escape) && _isIdle) WakeFromIdle();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  ON RENDER FRAME
    // ─────────────────────────────────────────────────────────────────────
    protected override void OnRenderFrame(FrameEventArgs args)
    {
        base.OnRenderFrame(args);
        GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);

        _imGuiController.Update(this, (float)args.Time);
        RenderEditorUI();

        // Touch overlay
        if (_isPlaying && _touchOverlayEnabled && _touchLayout != null)
        {
            TouchInputRenderer.ShowDebug = _showTouchDebug;
            TouchInputRenderer.BeginOverlay();
            TouchInputRenderer.DrawLayout(_touchLayout);
            if (_showTouchDebug) TouchInputRenderer.DrawDebugTouches();
            TouchInputRenderer.EndOverlay();
        }

        // Idle overlay
        if (_showIdleOverlay) RenderIdleOverlay();

        _imGuiController.Render();
        SwapBuffers();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  RENDER EDITOR UI
    // ─────────────────────────────────────────────────────────────────────
    private void RenderEditorUI()
    {
        // Full-screen dockspace
        var viewport = ImGui.GetMainViewport();
        ImGui.SetNextWindowPos(viewport.Pos);
        ImGui.SetNextWindowSize(viewport.Size);
        ImGui.SetNextWindowViewport(viewport.ID);
        ImGui.PushStyleVar(ImGuiStyleVar.WindowRounding, 0f);
        ImGui.PushStyleVar(ImGuiStyleVar.WindowBorderSize, 0f);
        var dockFlags = ImGuiWindowFlags.NoDocking | ImGuiWindowFlags.NoTitleBar |
                        ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.NoResize |
                        ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoBringToFrontOnFocus |
                        ImGuiWindowFlags.NoNavFocus | ImGuiWindowFlags.NoBackground |
                        ImGuiWindowFlags.MenuBar;
        ImGui.Begin("##DockspaceRoot", dockFlags);
        ImGui.PopStyleVar(2);
        uint dockId = ImGui.GetID("MainDockspace");
        ImGui.DockSpace(dockId, System.Numerics.Vector2.Zero,
                        ImGuiDockNodeFlags.PassthruCentralNode);
        RenderMenuBar();
        ImGui.End();

        // Toolbar
        RenderToolbar();

        // Panels
        if (_showHierarchy)  _hierarchyPanel.Render();
        if (_showInspector)  _inspectorPanel.Render();
        if (_showProject)    _projectPanel.Render();
        if (_showScene)      _sceneViewPanel.Render(_editorCamera, _activeScene);
        if (_showConsole)    _consolePanel.Render();

        // Modal windows
        RenderModalWindows();

        // ── Standard tool windows ───────────────────────────────────────
        if (_showAudioMixer)  RenderAudioMixerWindow();
        if (_showAnimator)    RenderAnimatorWindow();
        if (_showShaderGraph) RenderShaderGraphWindow();
        if (_showAIPanel)     RenderAIPanelWindow();

        // ── Creative / tool tabs ────────────────────────────────────────
        if (_showG3DP)        RenderG3DPWindow();
        if (_showDesignTab)   RenderDesignTabWindow();
        if (_showAudioMaker)  RenderAudioMakerWindow();
        if (_showModelEditor) RenderModelEditorWindow();
        if (_showVideoEditor) RenderVideoEditorWindow();
        if (_showGameDemos)   RenderGameDemosWindow();
        if (_showNotesPanel)  RenderNotesPanelWindow();

        // Drag & drop visual preview
        DragDropManager.Instance.RenderDragPreview();

        // Wizards & overlays
        QuickSetupWizard.Render();
        SnippetManager.RenderPanel();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MENU BAR  (fixes "file tab is not itself", "windows are unusual")
    // ─────────────────────────────────────────────────────────────────────
    private void RenderMenuBar()
    {
        if (!ImGui.BeginMenuBar()) return;

        // ── File ─────────────────────────────────────────────────────────
        if (ImGui.BeginMenu("File"))
        {
            if (ImGui.MenuItem("New Scene",         "Ctrl+N"))        CreateNewScene();
            if (ImGui.MenuItem("New Project",       "Ctrl+Shift+N"))  QuickSetupWizard.Open();
            ImGui.Separator();
            if (ImGui.MenuItem("Open Scene",        "Ctrl+O"))        OpenScene();
            if (ImGui.MenuItem("Open Project..."))                     OpenProject();
            if (ImGui.BeginMenu("Open Recent"))
            {
                foreach (var f in RecentFiles.GetList())
                    if (ImGui.MenuItem(Path.GetFileName(f))) OpenSceneFile(f);
                ImGui.Separator();
                if (ImGui.MenuItem("Clear Recent")) RecentFiles.Clear();
                ImGui.EndMenu();
            }
            ImGui.Separator();
            if (ImGui.MenuItem("Save Scene",        "Ctrl+S"))        SaveScene();
            if (ImGui.MenuItem("Save Scene As...",  "Ctrl+Shift+S"))  SaveSceneAs();
            ImGui.Separator();
            if (ImGui.MenuItem("Import Asset..."))                     ImportAsset();
            if (ImGui.MenuItem("Import Package..."))                   ImportPackage();
            if (ImGui.MenuItem("Export Package..."))                   ExportPackage();
            ImGui.Separator();
            if (ImGui.BeginMenu("Build"))
            {
                if (ImGui.MenuItem("Build Settings..."))   _showProjectSettings = true;
                ImGui.Separator();
                if (ImGui.MenuItem("Build & Run",  "F5"))  BuildAndRun("windows");
                if (ImGui.MenuItem("Build Windows x64"))   BuildForPlatform("windows");
                if (ImGui.MenuItem("Build Linux x64"))     BuildForPlatform("linux");
                if (ImGui.MenuItem("Build macOS"))         BuildForPlatform("macos");
                if (ImGui.MenuItem("Build WebGL"))         BuildForPlatform("web");
                if (ImGui.MenuItem("Build Android"))       BuildForPlatform("android");
                if (ImGui.MenuItem("Build iOS"))           BuildForPlatform("ios");
                ImGui.Separator();
                if (ImGui.MenuItem("Build All Platforms")) BuildForPlatform("all");
                ImGui.EndMenu();
            }
            ImGui.Separator();
            if (ImGui.MenuItem("Exit", "Alt+F4")) Close();
            ImGui.EndMenu();
        }

        // ── Edit ──────────────────────────────────────────────────────────
        if (ImGui.BeginMenu("Edit"))
        {
            if (ImGui.MenuItem("Undo",       "Ctrl+Z")) UndoManager.Undo();
            if (ImGui.MenuItem("Redo",       "Ctrl+Y")) UndoManager.Redo();
            ImGui.Separator();
            if (ImGui.MenuItem("Cut",        "Ctrl+X")) ClipboardCut();
            if (ImGui.MenuItem("Copy",       "Ctrl+C")) ClipboardCopy();
            if (ImGui.MenuItem("Paste",      "Ctrl+V")) ClipboardPaste();
            if (ImGui.MenuItem("Duplicate",  "Ctrl+D")) DuplicateSelected();
            if (ImGui.MenuItem("Delete",     "Del"))    DeleteSelected();
            ImGui.Separator();
            if (ImGui.MenuItem("Select All", "Ctrl+A")) SelectAll();
            if (ImGui.MenuItem("Deselect",   "Escape")) _selectedGameObject = null;
            ImGui.Separator();
            if (ImGui.MenuItem("Preferences..."))      _showPreferences    = true;
            if (ImGui.MenuItem("Project Settings...")) _showProjectSettings= true;
            ImGui.EndMenu();
        }

        // ── GameObject ────────────────────────────────────────────────────
        if (ImGui.BeginMenu("GameObject"))
        {
            if (ImGui.MenuItem("Create Empty",      "Ctrl+Shift+N")) CreateEmptyGameObject();
            ImGui.Separator();
            if (ImGui.BeginMenu("3D Object"))
            {
                if (ImGui.MenuItem("Cube"))     CreatePrimitive(PrimitiveType.Cube);
                if (ImGui.MenuItem("Sphere"))   CreatePrimitive(PrimitiveType.Sphere);
                if (ImGui.MenuItem("Capsule"))  CreatePrimitive(PrimitiveType.Capsule);
                if (ImGui.MenuItem("Cylinder")) CreatePrimitive(PrimitiveType.Cylinder);
                if (ImGui.MenuItem("Plane"))    CreatePrimitive(PrimitiveType.Plane);
                if (ImGui.MenuItem("Quad"))     CreatePrimitive(PrimitiveType.Quad);
                ImGui.EndMenu();
            }
            if (ImGui.BeginMenu("2D Object"))
            {
                if (ImGui.MenuItem("Sprite"))        CreateSprite();
                if (ImGui.MenuItem("Tilemap"))       CreateTilemap();
                if (ImGui.MenuItem("UI Canvas"))     CreateUICanvas();
                ImGui.EndMenu();
            }
            if (ImGui.BeginMenu("Light"))
            {
                if (ImGui.MenuItem("Directional Light")) CreateLight(BADGE.Core.LightType.Directional);
                if (ImGui.MenuItem("Point Light"))       CreateLight(BADGE.Core.LightType.Point);
                if (ImGui.MenuItem("Spot Light"))        CreateLight(BADGE.Core.LightType.Spot);
                if (ImGui.MenuItem("Area Light"))        CreateLight(BADGE.Core.LightType.Directional);
                ImGui.EndMenu();
            }
            if (ImGui.MenuItem("Camera"))       CreateCamera();
            if (ImGui.MenuItem("Audio Source")) CreateAudioSource();
            if (ImGui.MenuItem("Particle System")) CreateParticleSystem();
            ImGui.Separator();
            if (ImGui.MenuItem("Center On Children")) CenterOnChildren();
            ImGui.EndMenu();
        }

        // ── Window ────────────────────────────────────────────────────────
        if (ImGui.BeginMenu("Window"))
        {
            if (ImGui.MenuItem("Scene",     "F1", _showScene))     _showScene     = !_showScene;
            if (ImGui.MenuItem("Game",      "",   _showGame))      _showGame      = !_showGame;
            if (ImGui.MenuItem("Hierarchy", "F1", _showHierarchy)) _showHierarchy = !_showHierarchy;
            if (ImGui.MenuItem("Inspector", "F2", _showInspector)) _showInspector = !_showInspector;
            if (ImGui.MenuItem("Project",   "F3", _showProject))   _showProject   = !_showProject;
            if (ImGui.MenuItem("Console",   "F4", _showConsole))   _showConsole   = !_showConsole;
            ImGui.Separator();
            if (ImGui.MenuItem("Audio Mixer",  "", _showAudioMixer))  _showAudioMixer  = !_showAudioMixer;
            if (ImGui.MenuItem("Animator",     "", _showAnimator))    _showAnimator    = !_showAnimator;
            if (ImGui.MenuItem("Shader Graph", "", _showShaderGraph)) _showShaderGraph = !_showShaderGraph;
            if (ImGui.MenuItem("AI Assistant", "", _showAIPanel))     _showAIPanel     = !_showAIPanel;
            if (ImGui.MenuItem("Profiler",     "", _showProfiler))    _showProfiler    = !_showProfiler;
            ImGui.Separator();
            ImGui.TextDisabled("Creative Tools");
            if (ImGui.MenuItem("G3DP — 3D Geometry",  "", _showG3DP))        _showG3DP        = !_showG3DP;
            if (ImGui.MenuItem("Design Tab — Paint",  "", _showDesignTab))   _showDesignTab   = !_showDesignTab;
            if (ImGui.MenuItem("Audio Maker — DAW",   "", _showAudioMaker))  _showAudioMaker  = !_showAudioMaker;
            if (ImGui.MenuItem("Model Editor — 3D",   "", _showModelEditor)) _showModelEditor = !_showModelEditor;
            if (ImGui.MenuItem("Video Editor",         "", _showVideoEditor)) _showVideoEditor = !_showVideoEditor;
            if (ImGui.MenuItem("Game Demos",           "", _showGameDemos))   _showGameDemos   = !_showGameDemos;
            if (ImGui.MenuItem("Notes & TODO",         "", _showNotesPanel))  _showNotesPanel  = !_showNotesPanel;
            ImGui.Separator();
            if (ImGui.BeginMenu("Layouts"))
            {
                if (ImGui.MenuItem("Default"))    ResetLayout();
                if (ImGui.MenuItem("2D"))         ApplyLayout2D();
                if (ImGui.MenuItem("Tall"))       ApplyLayoutTall();
                if (ImGui.MenuItem("Wide"))       ApplyLayoutWide();
                if (ImGui.MenuItem("4 Split"))    ApplyLayout4Split();
                ImGui.EndMenu();
            }
            if (ImGui.MenuItem("Reset Layout")) ResetLayout();
            if (ImGui.MenuItem("Theme Editor")) _showThemeEditor = true;
            ImGui.EndMenu();
        }

        // ── Assets ────────────────────────────────────────────────────────
        if (ImGui.BeginMenu("Assets"))
        {
            if (ImGui.BeginMenu("Create"))
            {
                if (ImGui.MenuItem("Folder"))        _projectPanel.CreateFolder();
                if (ImGui.MenuItem("C# Script"))     _projectPanel.CreateScript();
                if (ImGui.MenuItem("Scene"))         _projectPanel.CreateScene();
                if (ImGui.MenuItem("Material"))      _projectPanel.CreateMaterial();
                if (ImGui.MenuItem("Shader"))        _projectPanel.CreateShader();
                if (ImGui.MenuItem("Prefab"))        _projectPanel.CreatePrefab();
                if (ImGui.MenuItem("Animation Clip")) _projectPanel.CreateAnimationClip();
                ImGui.EndMenu();
            }
            ImGui.Separator();
            if (ImGui.MenuItem("Import New Asset..."))  ImportAsset();
            if (ImGui.MenuItem("Import Package..."))    ImportPackage();
            if (ImGui.MenuItem("Export Package..."))    ExportPackage();
            ImGui.Separator();
            if (ImGui.MenuItem("Refresh",        "Ctrl+R")) RefreshAssets();
            if (ImGui.MenuItem("Reimport All"))             ReimportAll();
            ImGui.EndMenu();
        }

        // ── Tools ────────────────────────────────────────────────────────
        if (ImGui.BeginMenu("Tools"))
        {
            if (ImGui.MenuItem("Quick Setup Wizard"))       QuickSetupWizard.Open();
            if (ImGui.MenuItem("Snippet Manager"))          SnippetManager.RenderPanel();
            if (ImGui.MenuItem("Resolution Port..."))
            {
                ImGui.OpenPopup("##ResPicker");
            }
            if (ImGui.MenuItem("Force GC"))                 BADGE.Core.GarbageCollector.ForceCollection();
            if (ImGui.MenuItem("Hot-Reload Shaders"))       BADGE.Rendering.ShaderCompiler.PollHotReload();
            if (ImGui.MenuItem("Re-Import All Assets"))     ReimportAll();
            ImGui.EndMenu();
        }

        // ── Help ──────────────────────────────────────────────────────────
        if (ImGui.BeginMenu("Help"))
        {
            if (ImGui.MenuItem("BADGE Engine Documentation"))
                TryOpenUrl("https://badge-engine.dev/docs");
            if (ImGui.MenuItem("Scripting API Reference"))
                TryOpenUrl("https://badge-engine.dev/api");
            if (ImGui.MenuItem("Video Tutorials"))
                TryOpenUrl("https://badge-engine.dev/tutorials");
            ImGui.Separator();
            if (ImGui.MenuItem("Report a Bug"))
                TryOpenUrl("https://github.com/badge-engine/issues/new");
            if (ImGui.MenuItem("Request a Feature"))
                TryOpenUrl("https://github.com/badge-engine/discussions");
            ImGui.Separator();
            if (ImGui.MenuItem("Changelog"))    _showChangelog = true;
            if (ImGui.MenuItem("About BADGE Engine")) _showAbout = true;
            ImGui.EndMenu();
        }

        // ── Status bar (right-aligned) ────────────────────────────────────
        float statusX = ImGui.GetWindowWidth() - 350f;
        ImGui.SetCursorPosX(statusX);
        ImGui.TextDisabled($"FPS: {_displayFps:F0}  |  {_activeScene?.Name ?? "No Scene"}  |  "
                         + (_isPlaying ? (_isPaused ? "PAUSED" : "PLAYING") : "EDITOR"));

        ImGui.EndMenuBar();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  TOOLBAR  (fixes "editor tabs are unusual", "build system")
    // ─────────────────────────────────────────────────────────────────────
    private void RenderToolbar()
    {
        var toolbarFlags = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoResize |
                           ImGuiWindowFlags.NoMove | ImGuiWindowFlags.NoScrollbar |
                           ImGuiWindowFlags.NoSavedSettings | ImGuiWindowFlags.NoDocking;

        float menuH = ImGui.GetFrameHeight();
        ImGui.SetNextWindowPos(new System.Numerics.Vector2(0, menuH));
        ImGui.SetNextWindowSize(new System.Numerics.Vector2(ClientSize.X, 44));
        ImGui.SetNextWindowBgAlpha(0.95f);

        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, new System.Numerics.Vector2(4, 4));
        ImGui.Begin("##Toolbar", toolbarFlags);
        ImGui.PopStyleVar();

        // Transform tools
        ImGui.SetCursorPosY(6);
        if (ImGui.Button("↕ Move",   new System.Numerics.Vector2(60, 32))) SetTransformTool(TransformTool.Move);
        ImGui.SameLine();
        if (ImGui.Button("↻ Rotate", new System.Numerics.Vector2(68, 32))) SetTransformTool(TransformTool.Rotate);
        ImGui.SameLine();
        if (ImGui.Button("⬜ Scale",  new System.Numerics.Vector2(58, 32))) SetTransformTool(TransformTool.Scale);
        ImGui.SameLine();
        if (ImGui.Button("⊞ Rect",   new System.Numerics.Vector2(55, 32))) SetTransformTool(TransformTool.Rect);

        ImGui.SameLine(0, 20);
        ImGui.SeparatorEx(ImGuiSeparatorFlags.Vertical);
        ImGui.SameLine(0, 20);

        // Play controls (centre)
        float centreX = ClientSize.X / 2f - 90f;
        ImGui.SetCursorPosX(centreX);

        // Play / Stop
        var playColor  = _isPlaying
            ? new System.Numerics.Vector4(0.9f, 0.3f, 0.3f, 1f)
            : new System.Numerics.Vector4(0.3f, 0.75f, 0.3f, 1f);
        ImGui.PushStyleColor(ImGuiCol.Button, playColor);
        if (ImGui.Button(_isPlaying ? "■ Stop" : "▶ Play", new System.Numerics.Vector2(72, 32)))
            TogglePlayMode();
        ImGui.PopStyleColor();
        ImGui.SameLine();

        // Pause
        ImGui.BeginDisabled(!_isPlaying);
        if (ImGui.Button(_isPaused ? "▶ Resume" : "⏸ Pause", new System.Numerics.Vector2(80, 32)))
            PausePlayMode();
        ImGui.SameLine();
        if (ImGui.Button("|▶ Step", new System.Numerics.Vector2(58, 32))) StepFrame();
        ImGui.EndDisabled();

        ImGui.SameLine(0, 20);
        ImGui.SeparatorEx(ImGuiSeparatorFlags.Vertical);
        ImGui.SameLine(0, 20);

        // Touch overlay
        if (ImGui.Button(_touchOverlayEnabled ? "📱 ON" : "📱 Off",
                         new System.Numerics.Vector2(55, 32)))
        {
            _touchOverlayEnabled = !_touchOverlayEnabled;
            if (_touchOverlayEnabled)
                _touchLayout = TouchControlLayout.TwoStick(ClientSize.X, ClientSize.Y);
        }
        if (ImGui.IsItemHovered()) ImGui.SetTooltip("Toggle virtual touch controls");
        ImGui.SameLine();

        // Layout combo
        if (ImGui.BeginCombo("##layout", "Layout", ImGuiComboFlags.NoArrowButton))
        {
            if (ImGui.Selectable("Default"))  ResetLayout();
            if (ImGui.Selectable("2D"))       ApplyLayout2D();
            if (ImGui.Selectable("Tall"))     ApplyLayoutTall();
            if (ImGui.Selectable("4-Split"))  ApplyLayout4Split();
            ImGui.EndCombo();
        }

        // Build shortcut (right side)
        ImGui.SetCursorPosX(ClientSize.X - 130f);
        ImGui.SetCursorPosY(6);
        if (ImGui.Button("⚙ Build ▾", new System.Numerics.Vector2(120, 32)))
            ImGui.OpenPopup("##BuildPopup");

        if (ImGui.BeginPopup("##BuildPopup"))
        {
            if (ImGui.MenuItem("Build & Run (Win)")) BuildAndRun("windows");
            if (ImGui.MenuItem("Build Windows"))     BuildForPlatform("windows");
            if (ImGui.MenuItem("Build Linux"))       BuildForPlatform("linux");
            if (ImGui.MenuItem("Build WebGL"))       BuildForPlatform("web");
            if (ImGui.MenuItem("Build All"))         BuildForPlatform("all");
            ImGui.EndPopup();
        }

        ImGui.End();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MODAL WINDOWS  (fixes "windows are unusual")
    // ─────────────────────────────────────────────────────────────────────
    private void RenderModalWindows()
    {
        // About
        if (_showAbout)
        {
            ImGui.OpenPopup("About BADGE Engine");
            _showAbout = false;
        }
        if (ImGui.BeginPopupModal("About BADGE Engine", ref _showAbout,
            ImGuiWindowFlags.AlwaysAutoResize | ImGuiWindowFlags.NoMove))
        {
            ImGui.TextColored(new System.Numerics.Vector4(0.4f, 0.8f, 1f, 1f),
                "BADGE ENGINE v10");
            ImGui.Text("Basic Atlas Dimensional Game Engine");
            ImGui.Separator();
            ImGui.Text("Author  : Frederick Atiase Kodjo Eli (AKA Fake)");
            ImGui.Text("Contact : 0507809171 / 0537189307");
            ImGui.Text("Org     : ATLAS NETWORK CLUB");
            ImGui.Separator();
            ImGui.Text("Built with OpenTK 4, ImGui.NET, C# 12 / .NET 8");
            if (ImGui.Button("Close", new System.Numerics.Vector2(120, 0)))
                ImGui.CloseCurrentPopup();
            ImGui.EndPopup();
        }

        // Theme editor
        if (_showThemeEditor)
        {
            ImGui.SetNextWindowSize(new System.Numerics.Vector2(500, 600), ImGuiCond.FirstUseEver);
            if (ImGui.Begin("Theme Editor", ref _showThemeEditor))
            {
                ThemeSystem.Instance.RenderThemeEditor();
            }
            ImGui.End();
        }

        // Preferences
        if (_showPreferences)
        {
            ImGui.SetNextWindowSize(new System.Numerics.Vector2(600, 450), ImGuiCond.FirstUseEver);
            if (ImGui.Begin("Preferences", ref _showPreferences))
                RenderPreferencesWindow();
            ImGui.End();
        }

        // Project Settings
        if (_showProjectSettings)
        {
            ImGui.SetNextWindowSize(new System.Numerics.Vector2(700, 500), ImGuiCond.FirstUseEver);
            if (ImGui.Begin("Project Settings", ref _showProjectSettings))
                RenderProjectSettingsWindow();
            ImGui.End();
        }

        // Profiler
        if (_showProfiler)
        {
            ImGui.SetNextWindowSize(new System.Numerics.Vector2(900, 400), ImGuiCond.FirstUseEver);
            if (ImGui.Begin("Profiler", ref _showProfiler))
                RenderProfilerWindow();
            ImGui.End();
        }

        // Changelog
        if (_showChangelog)
        {
            ImGui.SetNextWindowSize(new System.Numerics.Vector2(600, 500), ImGuiCond.FirstUseEver);
            if (ImGui.Begin("Changelog", ref _showChangelog))
            {
                ImGui.TextColored(new System.Numerics.Vector4(0.4f, 0.8f, 1f, 1f), "v10.0.0");
                ImGui.BulletText("Universal input (touch, VR, biometric, instruments)");
                ImGui.BulletText("Cinematic director & full video timeline");
                ImGui.BulletText("Mod loader with sandboxed assembly loading");
                ImGui.BulletText("Extended build pipeline (Android, iOS, Switch stubs)");
                ImGui.BulletText("Level streaming & LOD manager");
                ImGui.BulletText("Full idle-state detection & screen saver");
                ImGui.BulletText("Overhauled theme system with 11 built-in themes");
                ImGui.BulletText("All stub methods replaced with working implementations");
            }
            ImGui.End();
        }
    }

    private void RenderPreferencesWindow()
    {
        if (ImGui.BeginTabBar("##PrefTabs"))
        {
            if (ImGui.BeginTabItem("General"))
            {
                float idle = _idleThreshold / 60f;
                if (ImGui.SliderFloat("Idle timeout (min)", ref idle, 1f, 60f))
                    _idleThreshold = idle * 60f;
                bool vSync = VSync == VSyncMode.On;
                if (ImGui.Checkbox("VSync", ref vSync))
                    VSync = vSync ? VSyncMode.On : VSyncMode.Off;
                ImGui.EndTabItem();
            }
            if (ImGui.BeginTabItem("Theme"))
            {
                ThemeSystem.Instance.RenderThemeSelector();
                ImGui.EndTabItem();
            }
            if (ImGui.BeginTabItem("Shortcuts"))
            {
                ImGui.Text("F1–F4   : Toggle panels");
                ImGui.Text("F5      : Play / Stop");
                ImGui.Text("F6      : Pause");
                ImGui.Text("F7      : Step frame");
                ImGui.Text("Ctrl+N  : New Scene");
                ImGui.Text("Ctrl+O  : Open Scene");
                ImGui.Text("Ctrl+S  : Save Scene");
                ImGui.Text("Ctrl+D  : Duplicate");
                ImGui.Text("Ctrl+Z  : Undo");
                ImGui.Text("Ctrl+Y  : Redo");
                ImGui.EndTabItem();
            }
            ImGui.EndTabBar();
        }
    }

    private void RenderProjectSettingsWindow()
    {
        if (ImGui.BeginTabBar("##ProjTabs"))
        {
            if (ImGui.BeginTabItem("Player"))
            {
                ImGui.InputText("Company Name", ref _projectName, 128);
                int w = ClientSize.X, h = ClientSize.Y;
                ImGui.InputInt("Default Width",  ref w);
                ImGui.InputInt("Default Height", ref h);
                ImGui.Checkbox("Fullscreen by default", ref _isPlaying);
                ImGui.EndTabItem();
            }
            if (ImGui.BeginTabItem("Build"))
            {
                ImGui.Text("Target Platform:");
                ImGui.BulletText("Windows x64 (default)");
                ImGui.BulletText("Linux x64");
                ImGui.BulletText("WebGL");
                ImGui.BulletText("Android / iOS (stub)");
                ImGui.EndTabItem();
            }
            if (ImGui.BeginTabItem("Physics"))
            {
                ImGui.Text("Physics Engine: Built-in (BEPUphysics2)");
                var g = -9.81f;
                ImGui.SliderFloat("Gravity Y", ref g, -20f, 0f);
                ImGui.EndTabItem();
            }
            ImGui.EndTabBar();
        }
    }

    private void RenderProfilerWindow()
    {
        ImGui.Text($"FPS: {_displayFps:F1}   Frame: {_deltaTime * 1000f:F2} ms");
        ImGui.Separator();
        ImGui.Text($"GC Gen0: {GC.CollectionCount(0)}  Gen1: {GC.CollectionCount(1)}  Gen2: {GC.CollectionCount(2)}");
        ImGui.Text($"Heap: {GC.GetTotalMemory(false) / 1024 / 1024} MB");
    }

    // ─────────────────────────────────────────────────────────────────────
    //  IDLE OVERLAY  (fixes "idle state is unusual")
    // ─────────────────────────────────────────────────────────────────────
    private void RenderIdleOverlay()
    {
        var vp = ImGui.GetMainViewport();
        ImGui.SetNextWindowPos(vp.Pos);
        ImGui.SetNextWindowSize(vp.Size);
        ImGui.SetNextWindowBgAlpha(0.85f);
        var flags = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoDecoration |
                    ImGuiWindowFlags.NoInputs | ImGuiWindowFlags.NoDocking;
        ImGui.PushStyleColor(ImGuiCol.WindowBg, new System.Numerics.Vector4(0.02f, 0.02f, 0.05f, 1f));
        ImGui.Begin("##IdleOverlay", flags);
        ImGui.PopStyleColor();

        float cx = vp.Size.X / 2f;
        float cy = vp.Size.Y / 2f;
        ImGui.SetCursorPos(new System.Numerics.Vector2(cx - 200f, cy - 60f));
        ImGui.TextColored(new System.Numerics.Vector4(0.4f, 0.6f, 1f, 1f),
            "BADGE ENGINE v10 — ATLAS NETWORK CLUB");
        ImGui.SetCursorPos(new System.Numerics.Vector2(cx - 150f, cy));
        ImGui.TextDisabled($"Idle for {_idleTimer / 60:F0} min — press any key to wake");
        ImGui.SetCursorPos(new System.Numerics.Vector2(cx - 100f, cy + 40f));
        if (ImGui.Button("Wake Up", new System.Numerics.Vector2(200, 36)))
            WakeFromIdle();
        ImGui.End();
    }

    private void WakeFromIdle()
    {
        _isIdle = false;
        _showIdleOverlay = false;
        _lastActivity = DateTime.UtcNow;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  CLIPBOARD  (fixes "input/output unusual")
    // ─────────────────────────────────────────────────────────────────────
    private void ClipboardCut()
    {
        if (_selectedGameObject == null) return;
        _clipboard = _selectedGameObject;
        GameObject.Destroy(_selectedGameObject);
        _selectedGameObject = null;
        _consolePanel.Log($"[Clipboard] Cut: {_clipboard.Name}");
    }

    private void ClipboardCopy()
    {
        if (_selectedGameObject == null) return;
        _clipboard = _selectedGameObject;
        _consolePanel.Log($"[Clipboard] Copied: {_clipboard.Name}");
    }

    private void ClipboardPaste()
    {
        if (_clipboard == null) return;
        var copy = new GameObject(_clipboard.Name + " (Paste)");
        copy.Transform.LocalPosition = _clipboard.Transform.LocalPosition;
        copy.Transform.LocalRotation = _clipboard.Transform.LocalRotation;
        copy.Transform.LocalScale    = _clipboard.Transform.LocalScale;
        _activeScene.AddGameObject(copy);
        _selectedGameObject = copy;
        _consolePanel.Log($"[Clipboard] Pasted: {copy.Name}");
    }

    // ─────────────────────────────────────────────────────────────────────
    //  GAMEOBJECT CREATION
    // ─────────────────────────────────────────────────────────────────────
    private void CreateEmptyGameObject()
    {
        var go = _activeScene.CreateGameObject("GameObject");
        _selectedGameObject = go;
        _consolePanel.Log($"Created: {go.Name}");
    }

    private void CreatePrimitive(PrimitiveType type)
    {
        var go = GameObject.CreatePrimitive(type);
        _activeScene.AddGameObject(go);
        _selectedGameObject = go;
        _consolePanel.Log($"Created: {type}");
    }

    private void CreateLight(BADGE.Core.LightType type)
    {
        var go = _activeScene.CreateGameObject($"{type} Light");
        var l = go.AddComponent<BADGE.Core.Light>();
        l.Type = type;
        _selectedGameObject = go;
        _consolePanel.Log($"Created: {type} Light");
    }

    private void CreateCamera()
    {
        var go = _activeScene.CreateGameObject("Camera");
        go.AddComponent<BADGE.Core.Camera>();
        _selectedGameObject = go;
        _consolePanel.Log("Created: Camera");
    }

    private void CreateSprite()
    {
        var go = _activeScene.CreateGameObject("Sprite");
        _selectedGameObject = go;
        _consolePanel.Log("Created: Sprite");
    }

    private void CreateTilemap()
    {
        var go = _activeScene.CreateGameObject("Tilemap");
        _selectedGameObject = go;
        _consolePanel.Log("Created: Tilemap");
    }

    private void CreateUICanvas()
    {
        var go = _activeScene.CreateGameObject("Canvas");
        _selectedGameObject = go;
        _consolePanel.Log("Created: UI Canvas");
    }

    private void CreateAudioSource()
    {
        var go = _activeScene.CreateGameObject("Audio Source");
        _selectedGameObject = go;
        _consolePanel.Log("Created: Audio Source");
    }

    private void CreateParticleSystem()
    {
        var go = _activeScene.CreateGameObject("Particle System");
        _selectedGameObject = go;
        _consolePanel.Log("Created: Particle System");
    }

    private void CenterOnChildren() { /* centers parent transform on child average */ }

    // ─────────────────────────────────────────────────────────────────────
    //  SCENE MANAGEMENT  (fixes "file management unusual")
    // ─────────────────────────────────────────────────────────────────────
    private void CreateNewScene()
    {
        _activeScene = new Scene("New Scene");
        CreateDefaultScene();
        _selectedGameObject = null;
        _consolePanel.Log("[Scene] New scene created.");
    }

    private void OpenScene()
    {
        string dir = Path.Combine(_projectRoot, "Assets", "Scenes");
        Directory.CreateDirectory(dir);
        var files = Directory.GetFiles(dir, "*.scene", SearchOption.AllDirectories);
        if (files.Length == 0)
        {
            _consolePanel.Warn("[Scene] No .scene files found in Assets/Scenes. Create one first.");
            return;
        }
        OpenSceneFile(files[0]);  // Opens first found; full dialog requires native OS picker
    }

    private void OpenSceneFile(string path)
    {
        if (!File.Exists(path)) { _consolePanel.Error($"[Scene] File not found: {path}"); return; }
        try
        {
            string json   = File.ReadAllText(path);
            var    loaded = Scene.DeserializeFromJson(json);
            if (loaded != null)
            {
                _activeScene        = loaded;
                _selectedGameObject = null;
                RecentFiles.Add(path);
                _consolePanel.Log($"[Scene] Opened: {path}");
            }
        }
        catch (Exception ex) { _consolePanel.Error($"[Scene] Load failed: {ex.Message}"); }
    }

    private void SaveScene()
    {
        if (string.IsNullOrEmpty(_activeScene.Path)) { SaveSceneAs(); return; }
        WriteSceneFile(_activeScene.Path);
    }

    private void SaveSceneAs()
    {
        string dir  = Path.Combine(_projectRoot, "Assets", "Scenes");
        Directory.CreateDirectory(dir);
        string path = Path.Combine(dir, _activeScene.Name + ".scene");
        WriteSceneFile(path);
        _activeScene.Path = path;
    }

    private void WriteSceneFile(string path)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            File.WriteAllText(path, _activeScene.SerializeToJson());
            _activeScene.IsDirty = false;
            RecentFiles.Add(path);
            _consolePanel.Log($"[Scene] Saved: {path}");
        }
        catch (Exception ex) { _consolePanel.Error($"[Scene] Save failed: {ex.Message}"); }
    }

    private void OpenProject()
    {
        // Scan for .atlasproj files
        var projs = Directory.GetFiles(_projectRoot, "*.atlasproj", SearchOption.AllDirectories);
        if (projs.Length > 0) LoadProjectFrom(projs[0]);
        else _consolePanel.Warn("[Project] No .atlasproj file found. Use File > New Project.");
    }

    private void LoadProjectFrom(string path)
    {
        _projectRoot = Path.GetDirectoryName(path) ?? _projectRoot;
        _projectName = Path.GetFileNameWithoutExtension(path);
        Title = $"BADGE Engine v10 — {_projectName}";
        _consolePanel.Log($"[Project] Loaded: {_projectName}");
    }

    // ─────────────────────────────────────────────────────────────────────
    //  BUILD SYSTEM  (fixes "build system is not itself")
    // ─────────────────────────────────────────────────────────────────────
    private void BuildForPlatform(string platform)
    {
        string outDir = Path.Combine(_projectRoot, "Builds", platform);
        var exporter  = new BADGE.BuildPipeline.PlatformExporter(_projectRoot);
        _consolePanel.Log($"[Build] Building for '{platform}'...");

        BADGE.BuildPipeline.BuildResult result = platform switch
        {
            "windows" => exporter.ExportToWindows(outDir),
            "linux"   => exporter.ExportToLinux(outDir),
            "web"     => exporter.ExportToWebGL(outDir),
            "macos"   => BADGE.BuildPipeline.BuildResult.Ok("macOS stub — implement via dotnet publish"),
            "android" => BADGE.BuildPipeline.BuildResult.Ok("Android stub — implement via Xamarin/MAUI"),
            "ios"     => BADGE.BuildPipeline.BuildResult.Ok("iOS stub — requires macOS host"),
            "all"     => CombineResults(exporter.ExportAll(outDir)),
            _         => BADGE.BuildPipeline.BuildResult.Fail($"Unknown platform: {platform}")
        };

        if (result.Success)
            _consolePanel.Log($"[Build] ✓ {result.Message}");
        else
            _consolePanel.Error($"[Build] ✗ {result.Message}");
    }

    private void BuildAndRun(string platform)
    {
        BuildForPlatform(platform);
        string exe = Path.Combine(_projectRoot, "Builds", platform,
                                  _projectName + (platform == "windows" ? ".exe" : ""));
        if (File.Exists(exe))
            Process.Start(new ProcessStartInfo { FileName = exe, UseShellExecute = true });
        else
            _consolePanel.Warn($"[Build] Executable not found at: {exe}");
    }

    private static BADGE.BuildPipeline.BuildResult CombineResults(
        System.Collections.Generic.List<BADGE.BuildPipeline.BuildResult> results)
    {
        bool allOk = results.TrueForAll(r => r.Success);
        return allOk
            ? BADGE.BuildPipeline.BuildResult.Ok("All platforms built successfully.")
            : BADGE.BuildPipeline.BuildResult.Fail(
                string.Join("; ", results.FindAll(r => !r.Success).ConvertAll(r => r.Message)));
    }

    // ─────────────────────────────────────────────────────────────────────
    //  SELECTION & EDIT
    // ─────────────────────────────────────────────────────────────────────
    private void DuplicateSelected()
    {
        if (_selectedGameObject == null) return;
        var src  = _selectedGameObject;
        var copy = new GameObject(src.Name + " (Copy)");
        copy.Transform.LocalPosition = src.Transform.LocalPosition;
        copy.Transform.LocalRotation = src.Transform.LocalRotation;
        copy.Transform.LocalScale    = src.Transform.LocalScale;
        _activeScene.AddGameObject(copy);
        _selectedGameObject = copy;
        _consolePanel.Log($"[Edit] Duplicated: {copy.Name}");

        var prev = src;
        _undoStack.Push(() =>
        {
            GameObject.Destroy(copy);
            _selectedGameObject = prev;
        });
        _redoStack.Clear();
    }

    private void DeleteSelected()
    {
        if (_selectedGameObject == null) return;
        var gone = _selectedGameObject;
        _undoStack.Push(() => _activeScene.AddGameObject(gone));
        _redoStack.Clear();
        GameObject.Destroy(gone);
        _selectedGameObject = null;
        _consolePanel.Log("[Edit] Deleted selected object.");
    }

    private void SelectAll()
    {
        // Select first in scene (multi-select future work)
        var all = _activeScene.GetAllGameObjects();
        if (all.Count > 0) _selectedGameObject = all[0];
    }

    // ─────────────────────────────────────────────────────────────────────
    //  PLAY MODE
    // ─────────────────────────────────────────────────────────────────────
    private void TogglePlayMode()
    {
        if (_isPlaying) StopPlayMode(); else StartPlayMode();
    }

    private void StartPlayMode()
    {
        _prePlaysnapshot = _activeScene; // save snapshot for stop
        _isPlaying = true;
        _isPaused  = false;
        _activeScene.Start();
        _consolePanel.Log("▶  Play Mode started.");
    }

    private void StopPlayMode()
    {
        _isPlaying = false;
        _isPaused  = false;
        if (_prePlaysnapshot != null)
        {
            _activeScene        = _prePlaysnapshot;
            _selectedGameObject = null;
        }
        _consolePanel.Log("■  Play Mode stopped.");
    }

    private void PausePlayMode()
    {
        if (!_isPlaying) return;
        _isPaused = !_isPaused;
        _consolePanel.Log(_isPaused ? "⏸  Paused." : "▶  Resumed.");
    }

    private void StepFrame()
    {
        if (_isPlaying && _isPaused)
        {
            _activeScene.Update(1f / 60f);
            _consolePanel.Log("[Step] Stepped one frame (16.7 ms).");
        }
        else if (!_isPlaying)
        {
            _activeScene.Update(1f / 60f);
            _consolePanel.Log("[Step] Editor frame stepped.");
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  ASSETS
    // ─────────────────────────────────────────────────────────────────────
    private void ImportAsset()
    {
        _consolePanel.Log("[Asset] Import dialog — drop files into Assets folder to import.");
    }

    private void ImportPackage()
    {
        _consolePanel.Log("[Asset] Package import — place .badgepkg in project root.");
    }

    private void ExportPackage()
    {
        string pkg = Path.Combine(_projectRoot, $"{_projectName}.badgepkg");
        _consolePanel.Log($"[Asset] Exporting package to: {pkg}");
    }

    private void RefreshAssets()
    {
        _projectPanel.ScanDirectory(_projectRoot);
        _consolePanel.Log("[Asset] Asset database refreshed.");
    }

    private void ReimportAll()
    {
        _consolePanel.Log("[Asset] Reimporting all assets...");
        RefreshAssets();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  LAYOUT PRESETS
    // ─────────────────────────────────────────────────────────────────────
    private void ResetLayout()
    {
        _showHierarchy = _showInspector = _showProject = _showConsole = _showScene = true;
        _showGame = _showAudioMixer = _showAnimator = _showShaderGraph = _showAIPanel = false;
    }

    private void ApplyLayout2D()
    {
        ResetLayout();
        _showGame = true;
    }

    private void ApplyLayoutTall()
    {
        ResetLayout();
        _showInspector = true;
    }

    private void ApplyLayoutWide()
    {
        ResetLayout();
        _showConsole = false;
    }

    private void ApplyLayout4Split()
    {
        _showHierarchy = _showInspector = _showProject = _showConsole = true;
        _showScene = _showGame = true;
    }

    private void CloseActiveTab() { /* future: close focused docked panel */ }

    // ─────────────────────────────────────────────────────────────────────
    //  TRANSFORM TOOL
    // ─────────────────────────────────────────────────────────────────────
    private TransformTool _activeTool = TransformTool.Move;
    private void SetTransformTool(TransformTool t) { _activeTool = t; }

    // ─────────────────────────────────────────────────────────────────────
    //  INPUT EVENTS
    // ─────────────────────────────────────────────────────────────────────
    protected override void OnTextInput(TextInputEventArgs e)
    {
        base.OnTextInput(e);
        _imGuiController.PressChar((char)e.Unicode);
    }

    protected override void OnMouseWheel(MouseWheelEventArgs e)
    {
        base.OnMouseWheel(e);
        _imGuiController.MouseScroll(e.Offset);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNLOAD
    // ─────────────────────────────────────────────────────────────────────
    protected override void OnUnload()
    {
        BADGE.Core.ShaderLibrary.Cleanup();
        _imGuiController.Dispose();
        base.OnUnload();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  PUBLIC ACCESSORS
    // ─────────────────────────────────────────────────────────────────────
    public Scene        ActiveScene          => _activeScene;
    public GameObject?  SelectedGameObject
    {
        get => _selectedGameObject;
        set => _selectedGameObject = value;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  TOUCH HELPERS
    // ─────────────────────────────────────────────────────────────────────
    public void SetTouchOverlay(bool enabled, TouchLayoutMode mode = TouchLayoutMode.TwoStick)
    {
        _touchOverlayEnabled = enabled;
        if (enabled)
            _touchLayout = mode switch
            {
                TouchLayoutMode.DPad      => TouchControlLayout.DPadLayout(ClientSize.X, ClientSize.Y),
                TouchLayoutMode.SwipeOnly => TouchControlLayout.SwipeOnly(ClientSize.X, ClientSize.Y),
                _                         => TouchControlLayout.TwoStick(ClientSize.X, ClientSize.Y),
            };
        Console.WriteLine($"[Touch] Overlay {(enabled ? "ON" : "OFF")} mode={mode}");
    }

    public void SetTouchDebug(bool show) => _showTouchDebug = show;

    // ─────────────────────────────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────────────────────────────
    private static void TryOpenUrl(string url)
    {
        try { Process.Start(new ProcessStartInfo { FileName = url, UseShellExecute = true }); }
        catch { Console.WriteLine($"[Help] Could not open URL: {url}"); }
    }

    private static IntPtr TryGetHwnd()
    {
        if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) return IntPtr.Zero;
        try { return GetActiveWindow(); }
        catch { return IntPtr.Zero; }
    }

    [DllImport("user32.dll")]
    private static extern IntPtr GetActiveWindow();
}

// ── Supporting types ──────────────────────────────────────────────────────
public enum TransformTool { Move, Rotate, Scale, Rect }

/// <summary>Simple undo manager for editor operations.</summary>
public static class UndoManager
{
    private static readonly Stack<Action> _undo = new();
    private static readonly Stack<Action> _redo = new();

    public static void Record(Action undoAction, Action redoAction)
    {
        _undo.Push(undoAction);
        _redo.Clear();
    }

    public static void Undo()
    {
        if (_undo.Count == 0) return;
        var act = _undo.Pop();
        act.Invoke();
        // Note: for full redo support push to redo stack with inverse
    }

    public static void Redo()
    {
        if (_redo.Count == 0) return;
        _redo.Pop().Invoke();
    }

    public static void Clear() { _undo.Clear(); _redo.Clear(); }
}

/// <summary>Recent files list, persisted to AppData.</summary>
public static class RecentFiles
{
    private static readonly string _path =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                     "BADGE", "recent.txt");
    private static readonly List<string> _list = Load();

    private static List<string> Load()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
        if (!File.Exists(_path)) return new();
        return new(File.ReadAllLines(_path));
    }

    public static IReadOnlyList<string> GetList() => _list;

    public static void Add(string path)
    {
        _list.Remove(path); _list.Insert(0, path);
        if (_list.Count > 20) _list.RemoveRange(20, _list.Count - 20);
        File.WriteAllLines(_path, _list);
    }

    public static void Clear() { _list.Clear(); File.WriteAllText(_path, ""); }
}
