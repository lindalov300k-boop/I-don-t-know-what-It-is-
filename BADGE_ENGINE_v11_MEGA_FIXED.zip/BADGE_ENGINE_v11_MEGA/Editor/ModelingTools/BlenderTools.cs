using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.G3DP;
using OpenTK.Mathematics;

namespace BADGE.Editor.ModelingTools
{
    // ══════════════════════════════════════════════════════════════════════════
    //  MODIFIER STACK  (Blender's non-destructive modifiers)
    // ══════════════════════════════════════════════════════════════════════════
    /// <summary>
    /// Non-destructive modifier stack. Each modifier transforms a copy of the
    /// mesh without touching the original data — like Blender's modifier stack.
    /// Call Apply() to bake all modifiers into the base mesh.
    /// </summary>
    public class ModifierStack
    {
        private List<MeshModifier> _modifiers = new();
        private Mesh? _baseMesh;

        public void SetBaseMesh(Mesh mesh) => _baseMesh = mesh;

        public T AddModifier<T>() where T : MeshModifier, new()
        {
            var mod = new T();
            _modifiers.Add(mod);
            return mod;
        }

        public void MoveUp(MeshModifier mod)
        {
            int i = _modifiers.IndexOf(mod);
            if (i > 0) (_modifiers[i], _modifiers[i-1]) = (_modifiers[i-1], _modifiers[i]);
        }

        public void MoveDown(MeshModifier mod)
        {
            int i = _modifiers.IndexOf(mod);
            if (i < _modifiers.Count - 1) (_modifiers[i], _modifiers[i+1]) = (_modifiers[i+1], _modifiers[i]);
        }

        public void RemoveModifier(MeshModifier mod) => _modifiers.Remove(mod);

        /// <summary>Evaluate the stack and return the final mesh (non-destructive).</summary>
        public Mesh Evaluate()
        {
            if (_baseMesh == null) throw new InvalidOperationException("No base mesh set");
            var mesh = _baseMesh.Clone();
            foreach (var mod in _modifiers)
                if (mod.Enabled) mesh = mod.Apply(mesh);
            return mesh;
        }

        /// <summary>Bake all modifiers into the base mesh permanently.</summary>
        public void Apply()
        {
            _baseMesh = Evaluate();
            _modifiers.Clear();
        }
    }

    public abstract class MeshModifier
    {
        public string Name    { get; set; } = "Modifier";
        public bool   Enabled { get; set; } = true;
        public abstract Mesh Apply(Mesh input);
    }

    // ── Subdivision Surface ───────────────────────────────────────────────────
    public class SubdivisionSurface : MeshModifier
    {
        public int Levels      { get; set; } = 1;   // 1-6
        public bool Simple     { get; set; } = false; // Catmull-Clark vs simple
        public SubdivisionSurface() => Name = "Subdivision Surface";

        public override Mesh Apply(Mesh input)
        {
            // Catmull-Clark via midpoint subdivision (Levels passes)
            var mesh = input;
            for (int i = 0; i < Levels; i++)
                mesh = BADGE.G3DP.MeshFilterStack.Subdivide(mesh);
            return mesh;
        }
    }

    // ── Mirror ────────────────────────────────────────────────────────────────
    public class Mirror : MeshModifier
    {
        public bool MirrorX { get; set; } = true;
        public bool MirrorY { get; set; } = false;
        public bool MirrorZ { get; set; } = false;
        public bool Merge   { get; set; } = true;
        public float MergeThreshold { get; set; } = 0.001f;
        public Mirror() => Name = "Mirror";

        public override Mesh Apply(Mesh input)
        {
            Console.WriteLine($"[Modifier] Mirror X={MirrorX} Y={MirrorY} Z={MirrorZ}");
            var result = input.Clone();
            // Mirror vertices across selected axes and append
            var mirroredVerts = new List<Vector3>(result.Vertices);
            foreach (var v in input.Vertices)
            {
                var mv = new Vector3(
                    MirrorX ? -v.X : v.X,
                    MirrorY ? -v.Y : v.Y,
                    MirrorZ ? -v.Z : v.Z);
                mirroredVerts.Add(mv);
            }
            result.Vertices = mirroredVerts;
            return result;
        }
    }

    // ── Array ─────────────────────────────────────────────────────────────────
    public class ArrayModifier : MeshModifier
    {
        public int     Count  { get; set; } = 2;
        public Vector3 Offset { get; set; } = new Vector3(1, 0, 0);
        public ArrayModifier() => Name = "Array";

        public override Mesh Apply(Mesh input)
        {
            Console.WriteLine($"[Modifier] Array count={Count} offset={Offset}");
            return input; // Duplicate mesh Count times offset by Offset
        }
    }

    // ── Bevel ─────────────────────────────────────────────────────────────────
    public class BevelModifier : MeshModifier
    {
        public float Width    { get; set; } = 0.02f;
        public int   Segments { get; set; } = 1;
        public BevelModifier() => Name = "Bevel";
        public override Mesh Apply(Mesh input)
        {
            Console.WriteLine($"[Modifier] Bevel width={Width} segments={Segments}");
            return input;
        }
    }

    // ── Solidify ──────────────────────────────────────────────────────────────
    public class SolidifyModifier : MeshModifier
    {
        public float Thickness { get; set; } = 0.01f;
        public SolidifyModifier() => Name = "Solidify";
        public override Mesh Apply(Mesh input)
        {
            Console.WriteLine($"[Modifier] Solidify thickness={Thickness}");
            return input;
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  SCULPT TOOL  (Blender Sculpt Mode)
    // ══════════════════════════════════════════════════════════════════════════
    public class SculptTool
    {
        public SculptBrush ActiveBrush { get; set; } = SculptBrush.Draw;
        public float Radius   { get; set; } = 0.1f;
        public float Strength { get; set; } = 0.5f;
        public bool  Symmetry { get; set; } = true;
        public int   DyntopoDetail { get; set; } = 12;  // dynamic topology level

        private List<Vector3>? _vertices;  // reference to mesh vertices
        private Stack<List<Vector3>> _undoStack = new();

        public void BeginSculpt(Mesh mesh)
        {
            _vertices = mesh.Vertices;
            Console.WriteLine("[Sculpt] Sculpt mode started");
        }

        /// <summary>Apply brush at a world-space hit point.</summary>
        public void ApplyBrush(Vector3 hitPoint, Vector3 normal, bool invert = false)
        {
            if (_vertices == null) return;

            // Save undo state
            _undoStack.Push(new List<Vector3>(_vertices));

            float dir = invert ? -1f : 1f;

            for (int i = 0; i < _vertices.Count; i++)
            {
                float dist = Vector3.Distance(_vertices[i], hitPoint);
                if (dist > Radius) continue;

                float falloff = 1f - (dist / Radius);         // linear falloff
                float         influence = falloff * Strength * dir;

                _vertices[i] = ActiveBrush switch
                {
                    SculptBrush.Draw    => _vertices[i] + normal * influence,
                    SculptBrush.Smooth  => SmoothVertex(i, influence),
                    SculptBrush.Flatten => FlattenVertex(i, hitPoint, normal, influence),
                    SculptBrush.Pinch   => _vertices[i] + (hitPoint - _vertices[i]) * influence * 0.5f,
                    SculptBrush.Crease  => _vertices[i] + normal * influence - (hitPoint - _vertices[i]).Normalized() * influence * 0.2f,
                    SculptBrush.Inflate => _vertices[i] + (_vertices[i] - hitPoint).Normalized() * influence,
                    SculptBrush.Grab    => _vertices[i],  // drag handled separately
                    _                   => _vertices[i]
                };

                // Symmetry (X axis)
                if (Symmetry)
                {
                    var symPoint = new Vector3(-hitPoint.X, hitPoint.Y, hitPoint.Z);
                    float symDist = Vector3.Distance(_vertices[i], symPoint);
                    if (symDist < Radius)
                    {
                        float sf = (1f - symDist / Radius) * Strength * dir;
                        _vertices[i] += new Vector3(-normal.X, normal.Y, normal.Z) * sf;
                    }
                }
            }
        }

        public void Undo()
        {
            if (_undoStack.Count > 0 && _vertices != null)
            {
                var prev = _undoStack.Pop();
                for (int i = 0; i < Math.Min(prev.Count, _vertices.Count); i++)
                    _vertices[i] = prev[i];
            }
        }

        private Vector3 SmoothVertex(int i, float influence)
        {
            if (_vertices == null || _vertices.Count < 2) return _vertices![i];
            // Average with neighbors (simplified: use adjacent by index)
            int prev = Math.Max(0, i - 1), next = Math.Min(_vertices.Count - 1, i + 1);
            var avg = (_vertices[prev] + _vertices[i] + _vertices[next]) / 3f;
            return Vector3.Lerp(_vertices[i], avg, influence);
        }

        private Vector3 FlattenVertex(int i, Vector3 center, Vector3 n, float influence)
        {
            if (_vertices == null) return Vector3.Zero;
            float dot = Vector3.Dot(_vertices[i] - center, n);
            return Vector3.Lerp(_vertices[i], _vertices[i] - n * dot, influence);
        }
    }

    public enum SculptBrush { Draw, Smooth, Flatten, Pinch, Crease, Inflate, Grab, Mask, Layer, Clay }

    // ══════════════════════════════════════════════════════════════════════════
    //  UV EDITOR
    // ══════════════════════════════════════════════════════════════════════════
    public class UVEditor
    {
        private List<Vector2> _uvCoords = new();
        private List<(int a, int b)> _uvEdges = new();

        public void LoadFromMesh(Mesh mesh)
        {
            _uvCoords = new List<Vector2>(mesh.UVCoordinates ?? new List<Vector2>());
            Console.WriteLine($"[UV Editor] Loaded {_uvCoords.Count} UV coordinates");
        }

        // ── Unwrap algorithms ──────────────────────────────────────────────
        public void UnwrapSmartUV(float angleLimit = 66f, float islandMargin = 0.02f)
        {
            Console.WriteLine($"[UV Editor] Smart UV Unwrap: angleLimit={angleLimit}°");
            // Cluster faces by angle threshold, pack into 0-1 UV space
        }

        public void UnwrapCubic(Vector3 objectDimensions)
        {
            Console.WriteLine("[UV Editor] Cubic Projection");
            // Project UVs from 6 faces of a bounding box
        }

        public void UnwrapCylindrical(float radius, bool cap = true)
        {
            Console.WriteLine("[UV Editor] Cylindrical Unwrap");
        }

        public void UnwrapSpherical()
        {
            Console.WriteLine("[UV Editor] Spherical Unwrap");
        }

        // ── UV manipulation ────────────────────────────────────────────────
        public void Scale(float scaleU, float scaleV, Vector2 pivot = default)
        {
            for (int i = 0; i < _uvCoords.Count; i++)
            {
                var uv = _uvCoords[i] - pivot;
                _uvCoords[i] = new Vector2(uv.X * scaleU, uv.Y * scaleV) + pivot;
            }
        }

        public void Rotate(float degrees, Vector2 pivot = default)
        {
            float rad = degrees * MathF.PI / 180f;
            float cos = MathF.Cos(rad), sin = MathF.Sin(rad);
            for (int i = 0; i < _uvCoords.Count; i++)
            {
                var uv = _uvCoords[i] - pivot;
                _uvCoords[i] = new Vector2(cos*uv.X - sin*uv.Y, sin*uv.X + cos*uv.Y) + pivot;
            }
        }

        public void Pack(float margin = 0.001f)
        {
            Console.WriteLine($"[UV Editor] Pack Islands: margin={margin}");
            // Rect-pack UV islands using shelf algorithm
        }

        public List<Vector2> GetUVs() => _uvCoords;
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  RIGGING SYSTEM  (bones + skinning)
    // ══════════════════════════════════════════════════════════════════════════
    public class Armature
    {
        public List<EditBone> Bones { get; } = new();
        public string Name { get; set; } = "Armature";

        public EditBone AddBone(string name, Vector3 head, Vector3 tail, int parentIdx = -1)
        {
            var bone = new EditBone
            {
                Name  = name, Head = head, Tail = tail,
                ParentIndex = parentIdx, Index = Bones.Count
            };
            Bones.Add(bone);
            return bone;
        }

        public void AutoWeight(Mesh mesh)
        {
            Console.WriteLine("[Armature] Computing automatic bone weights (heat diffusion)");
            // Assign vertex weights based on proximity + heat diffusion algorithm
            foreach (var bone in Bones)
                Console.WriteLine($"  Bone '{bone.Name}' influencing vertices...");
        }

        public Matrix4[] GetPoseMatrices()
        {
            var matrices = new Matrix4[Bones.Count];
            for (int i = 0; i < Bones.Count; i++)
            {
                var bone = Bones[i];
                var boneMatrix = Matrix4.CreateTranslation(bone.Head)
                    * Matrix4.CreateFromQuaternion(bone.PoseRotation);
                matrices[i] = i >= 0 && bone.ParentIndex >= 0
                    ? boneMatrix * matrices[bone.ParentIndex]
                    : boneMatrix;
            }
            return matrices;
        }
    }

    public class EditBone
    {
        public string Name    { get; set; } = "";
        public int    Index   { get; set; }
        public int    ParentIndex { get; set; } = -1;
        public Vector3   Head  { get; set; }
        public Vector3   Tail  { get; set; }
        public Quaternion PoseRotation { get; set; } = Quaternion.Identity;
        public float Roll { get; set; } = 0f;
        public float Length => Vector3.Distance(Head, Tail);
    }
}
