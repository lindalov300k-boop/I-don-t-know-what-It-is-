using System;
namespace BADGE.Procedural.Noise
{
    /// <summary>
    /// Real Ken Perlin improved noise (2002).
    /// REPLACES: The fake sin-hash stub that produced non-continuous garbage.
    /// Provides: Noise(x,y), Noise(x,y,z), OctaveNoise, fBm, RidgedNoise, DomainWarp.
    /// </summary>
    public static class Perlin
    {
        private static readonly int[] _p;
        static Perlin()
        {
            int[] src = {151,160,137,91,90,15,131,13,201,95,96,53,194,233,7,225,140,36,103,30,69,
                142,8,99,37,240,21,10,23,190,6,148,247,120,234,75,0,26,197,62,94,252,219,203,
                117,35,11,32,57,177,33,88,237,149,56,87,174,20,125,136,171,168,68,175,74,165,71,
                134,139,48,27,166,77,146,158,231,83,111,229,122,60,211,133,230,220,105,92,41,55,
                46,245,40,244,102,143,54,65,25,63,161,1,216,80,73,209,76,132,187,208,89,18,169,
                200,196,135,130,116,188,159,86,164,100,109,198,173,186,3,64,52,217,226,250,124,
                123,5,202,38,147,118,126,255,82,85,212,207,206,59,227,47,16,58,17,182,189,28,42,
                223,183,170,213,119,248,152,2,44,154,163,70,221,153,101,155,167,43,172,9,129,22,
                39,253,19,98,108,110,79,113,224,232,178,185,112,104,218,246,97,228,251,34,242,
                193,238,210,144,12,191,179,162,241,81,51,145,235,249,14,239,107,49,192,214,31,
                181,199,106,157,184,84,204,176,115,121,50,45,127,4,150,254,138,236,205,93,222,
                114,67,29,24,72,243,141,128,195,78,66,215,61,156,180};
            _p = new int[512];
            for (int i = 0; i < 512; i++) _p[i] = src[i & 255];
        }

        private static float Fade(float t) => t * t * t * (t * (t * 6 - 15) + 10);
        private static float Lerp(float t, float a, float b) => a + t * (b - a);
        private static float Grad(int hash, float x, float y, float z)
        {
            int h = hash & 15;
            float u = h < 8 ? x : y;
            float v = h < 4 ? y : (h == 12 || h == 14 ? x : z);
            return ((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v);
        }

        public static float Noise(float x, float y, float z = 0f)
        {
            int X = (int)MathF.Floor(x) & 255, Y = (int)MathF.Floor(y) & 255, Z = (int)MathF.Floor(z) & 255;
            x -= MathF.Floor(x); y -= MathF.Floor(y); z -= MathF.Floor(z);
            float u = Fade(x), v = Fade(y), w = Fade(z);
            int A = _p[X]+Y, AA = _p[A]+Z, AB = _p[A+1]+Z, B = _p[X+1]+Y, BA = _p[B]+Z, BB = _p[B+1]+Z;
            return Lerp(w, Lerp(v, Lerp(u, Grad(_p[AA],x,y,z), Grad(_p[BA],x-1,y,z)),
                                   Lerp(u, Grad(_p[AB],x,y-1,z), Grad(_p[BB],x-1,y-1,z))),
                           Lerp(v, Lerp(u, Grad(_p[AA+1],x,y,z-1), Grad(_p[BA+1],x-1,y,z-1)),
                                   Lerp(u, Grad(_p[AB+1],x,y-1,z-1), Grad(_p[BB+1],x-1,y-1,z-1))));
        }

        /// <summary>0-1 range Perlin (shifted from -1..1).</summary>
        public static float Noise01(float x, float y, float z = 0f) => (Noise(x, y, z) + 1f) * 0.5f;

        /// <summary>Fractional Brownian Motion — layered octaves.</summary>
        public static float OctaveNoise(float x, float y, int octaves, float persistence = 0.5f, float lacunarity = 2f)
        {
            float value = 0f, amplitude = 1f, frequency = 1f, maxVal = 0f;
            for (int i = 0; i < octaves; i++)
            {
                value    += Noise(x * frequency, y * frequency) * amplitude;
                maxVal   += amplitude;
                amplitude *= persistence;
                frequency *= lacunarity;
            }
            return value / maxVal;
        }

        /// <summary>Ridged multifractal noise — good for mountain ridges.</summary>
        public static float RidgedNoise(float x, float y, int octaves = 6)
        {
            float value = 0f, amplitude = 0.5f, frequency = 1f;
            for (int i = 0; i < octaves; i++)
            {
                float n   = 1f - MathF.Abs(Noise(x * frequency, y * frequency));
                value    += n * n * amplitude;
                amplitude *= 0.5f;
                frequency *= 2f;
            }
            return value;
        }

        /// <summary>Domain-warped noise — creates swirling, organic shapes.</summary>
        public static float WarpedNoise(float x, float y, float warpStrength = 1.2f)
        {
            float wx = x + warpStrength * OctaveNoise(x + 0.0f, y + 0.0f, 4);
            float wy = y + warpStrength * OctaveNoise(x + 5.2f, y + 1.3f, 4);
            return OctaveNoise(wx, wy, 4);
        }
    }
}
