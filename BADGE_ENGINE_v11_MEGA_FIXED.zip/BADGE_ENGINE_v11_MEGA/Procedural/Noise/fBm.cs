using System;

namespace BADGE.Procedural.Noise
{
    // ══════════════════════════════════════════════════════════════════════
    //  Fractional Brownian Motion — layered Perlin/Simplex noise
    //  Supports 2D and 3D, configurable octaves, persistence, lacunarity.
    // ══════════════════════════════════════════════════════════════════════
    public static class FractalBrownianMotion
    {
        /// <summary>2D fBm.</summary>
        public static float Generate(float x, float y,
            int   octaves     = 6,
            float persistence = 0.5f,
            float lacunarity  = 2.0f)
        {
            float total = 0f, frequency = 1f, amplitude = 1f, maxValue = 0f;
            for (int i = 0; i < octaves; i++)
            {
                total    += Perlin.Generate(x * frequency, y * frequency) * amplitude;
                maxValue += amplitude;
                amplitude *= persistence;
                frequency *= lacunarity;
            }
            return maxValue > 0f ? total / maxValue : 0f;
        }

        /// <summary>3D fBm.</summary>
        public static float Generate3D(float x, float y, float z,
            int   octaves     = 6,
            float persistence = 0.5f,
            float lacunarity  = 2.0f)
        {
            float total = 0f, frequency = 1f, amplitude = 1f, maxValue = 0f;
            for (int i = 0; i < octaves; i++)
            {
                total    += Perlin.Generate3D(x * frequency, y * frequency, z * frequency) * amplitude;
                maxValue += amplitude;
                amplitude *= persistence;
                frequency *= lacunarity;
            }
            return maxValue > 0f ? total / maxValue : 0f;
        }

        /// <summary>Domain-warped fBm — gives organic cloud/lava shapes.</summary>
        public static float Warped(float x, float y, int octaves = 5, float warpStrength = 1.5f)
        {
            float wx = Generate(x + 0.0f, y + 0.0f, octaves);
            float wy = Generate(x + 5.2f, y + 1.3f, octaves);
            return Generate(x + warpStrength * wx, y + warpStrength * wy, octaves);
        }

        /// <summary>Ridged multi-fractal — good for mountain ridges.</summary>
        public static float Ridged(float x, float y, int octaves = 6, float lacunarity = 2f, float gain = 0.5f)
        {
            float total = 0f, frequency = 1f, amplitude = 0.5f, weight = 1f;
            for (int i = 0; i < octaves; i++)
            {
                float signal = Perlin.Generate(x * frequency, y * frequency);
                signal = 1f - MathF.Abs(signal);   // ridge
                signal *= signal * weight;
                weight  = MathF.Max(0f, MathF.Min(1f, signal * 2f));
                total   += signal * amplitude;
                frequency *= lacunarity;
                amplitude *= gain;
            }
            return total;
        }
    }
}
