using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using BADGE.G3DP;
using BADGE.Procedural.Noise;

namespace BADGE.Procedural.Terrain
{
    /// <summary>
    /// Generates heightmap-based terrain meshes using layered Simplex noise.
    /// Supports erosion, biome maps, chunk streaming, and LOD.
    /// </summary>
    public class TerrainGenerator
    {
        // ── Settings ─────────────────────────────────────────────────────
        public int    ChunkSize     { get; set; } = 64;    // verts per side
        public float  WorldScale    { get; set; } = 1f;    // metres per vertex
        public float  MaxHeight     { get; set; } = 80f;   // peak height in metres
        public int    OctaveCount   { get; set; } = 6;
        public float  Persistence   { get; set; } = 0.5f;
        public float  Lacunarity    { get; set; } = 2f;
        public float  NoiseScale    { get; set; } = 0.003f;
        public long   Seed          { get; set; } = 42;
        public bool   ApplyErosion  { get; set; } = true;
        public int    ErosionPasses { get; set; } = 3;

        // ── Biome thresholds (0–1 normalized height) ──────────────────────
        public float WaterLevel    { get; set; } = 0.22f;
        public float SandLevel     { get; set; } = 0.27f;
        public float GrassLevel    { get; set; } = 0.60f;
        public float RockLevel     { get; set; } = 0.80f;
        // Above RockLevel = snow

        private readonly Random _rng;

        public TerrainGenerator() => _rng = new Random((int)Seed);

        // ── Main API ──────────────────────────────────────────────────────

        /// <summary>
        /// Generate a terrain chunk at chunk coordinate (cx, cz).
        /// Returns a Mesh ready for uploading to the GPU.
        /// </summary>
        public Mesh GenerateChunk(int cx, int cz)
        {
            int   verts   = ChunkSize + 1;
            float[,] hmap = GenerateHeightmap(cx * ChunkSize, cz * ChunkSize, verts);

            if (ApplyErosion) Erode(hmap, verts, ErosionPasses);

            return BuildMesh(hmap, verts);
        }

        /// <summary>
        /// Build a 2-D float heightmap in world units for the given origin.
        /// </summary>
        public float[,] GenerateHeightmap(int originX, int originZ, int resolution)
        {
            var map = new float[resolution, resolution];
            for (int z = 0; z < resolution; z++)
            for (int x = 0; x < resolution; x++)
            {
                float wx = (originX + x) * NoiseScale;
                float wz = (originZ + z) * NoiseScale;
                map[x, z] = Simplex.FBm(wx, wz, OctaveCount, Persistence, Lacunarity) * MaxHeight;
            }
            return map;
        }

        /// <summary>Sample terrain height at any world (x, z) position.</summary>
        public float SampleHeight(float worldX, float worldZ)
            => Simplex.FBm(worldX * NoiseScale, worldZ * NoiseScale,
                           OctaveCount, Persistence, Lacunarity) * MaxHeight;

        /// <summary>Returns the biome category at a normalized height (0–1).</summary>
        public static BiomeType ClassifyBiome(float normHeight) =>
            normHeight < 0.22f ? BiomeType.Water :
            normHeight < 0.27f ? BiomeType.Sand  :
            normHeight < 0.60f ? BiomeType.Grass :
            normHeight < 0.80f ? BiomeType.Rock  :
                                 BiomeType.Snow;

        // ── Mesh builder ─────────────────────────────────────────────────
        private Mesh BuildMesh(float[,] hmap, int verts)
        {
            int vertCount = verts * verts;
            var positions = new Vector3[vertCount];
            var normals   = new Vector3[vertCount];
            var uvs       = new Vector2[vertCount];

            float invSize = 1f / (verts - 1);

            for (int z = 0; z < verts; z++)
            for (int x = 0; x < verts; x++)
            {
                int i = z * verts + x;
                positions[i] = new Vector3(x * WorldScale, hmap[x, z], z * WorldScale);
                uvs[i]       = new Vector2(x * invSize, z * invSize);
            }

            // Compute smooth normals via cross product of neighbours
            for (int z = 0; z < verts; z++)
            for (int x = 0; x < verts; x++)
            {
                int i  = z * verts + x;
                float L = x > 0        ? hmap[x - 1, z] : hmap[x, z];
                float R = x < verts-1  ? hmap[x + 1, z] : hmap[x, z];
                float D = z > 0        ? hmap[x, z - 1] : hmap[x, z];
                float U = z < verts-1  ? hmap[x, z + 1] : hmap[x, z];
                normals[i] = Vector3.Normalize(new Vector3(L - R, 2f * WorldScale, D - U));
            }

            // Build triangle index buffer
            int quads   = (verts - 1) * (verts - 1);
            var indices = new int[quads * 6];
            int idx     = 0;
            for (int z = 0; z < verts - 1; z++)
            for (int x = 0; x < verts - 1; x++)
            {
                int tl = z * verts + x;
                int tr = tl + 1;
                int bl = tl + verts;
                int br = bl + 1;
                indices[idx++] = tl; indices[idx++] = bl; indices[idx++] = tr;
                indices[idx++] = tr; indices[idx++] = bl; indices[idx++] = br;
            }

            var mesh = new Mesh();
            mesh.SetVertices(positions);
            mesh.SetNormals(normals);
            mesh.SetUVs(uvs);
            mesh.SetTriangles(indices);
            return mesh;
        }

        // ── Simple hydraulic erosion ──────────────────────────────────────
        private void Erode(float[,] hmap, int size, int passes)
        {
            for (int pass = 0; pass < passes; pass++)
            for (int z = 1; z < size - 1; z++)
            for (int x = 1; x < size - 1; x++)
            {
                float h  = hmap[x, z];
                float n  = hmap[x, z - 1];
                float s  = hmap[x, z + 1];
                float w  = hmap[x - 1, z];
                float e  = hmap[x + 1, z];
                float lo = Math.Min(Math.Min(n, s), Math.Min(w, e));
                if (h > lo + 0.5f)
                {
                    float diff = (h - lo) * 0.05f;
                    hmap[x, z]  -= diff;
                    // Deposit on lowest neighbour
                    if      (lo == n) hmap[x, z - 1] += diff;
                    else if (lo == s) hmap[x, z + 1] += diff;
                    else if (lo == w) hmap[x - 1, z] += diff;
                    else              hmap[x + 1, z] += diff;
                }
            }
        }
    }

    // ── Chunk streaming ───────────────────────────────────────────────────
    /// <summary>
    /// Manages a grid of loaded terrain chunks centred around a viewer.
    /// Call Update() each frame with the viewer's world position.
    /// </summary>
    public class TerrainChunkManager
    {
        private readonly TerrainGenerator               _gen;
        private readonly Dictionary<(int, int), Mesh>  _loaded  = new();
        private readonly int                            _viewDist; // in chunks

        public event Action<int, int, Mesh>? ChunkLoaded;
        public event Action<int, int>?       ChunkUnloaded;

        public TerrainChunkManager(TerrainGenerator gen, int viewDistChunks = 3)
        {
            _gen      = gen;
            _viewDist = viewDistChunks;
        }

        public void Update(Vector3 viewerWorldPos)
        {
            int cx = (int)(viewerWorldPos.X / (_gen.ChunkSize * _gen.WorldScale));
            int cz = (int)(viewerWorldPos.Z / (_gen.ChunkSize * _gen.WorldScale));

            // Load new chunks
            for (int dz = -_viewDist; dz <= _viewDist; dz++)
            for (int dx = -_viewDist; dx <= _viewDist; dx++)
            {
                var key = (cx + dx, cz + dz);
                if (!_loaded.ContainsKey(key))
                {
                    var mesh = _gen.GenerateChunk(key.Item1, key.Item2);
                    _loaded[key] = mesh;
                    ChunkLoaded?.Invoke(key.Item1, key.Item2, mesh);
                }
            }

            // Unload distant chunks
            var toUnload = new List<(int, int)>();
            foreach (var key in _loaded.Keys)
            {
                if (Math.Abs(key.Item1 - cx) > _viewDist + 1 ||
                    Math.Abs(key.Item2 - cz) > _viewDist + 1)
                    toUnload.Add(key);
            }
            foreach (var key in toUnload)
            {
                _loaded.Remove(key);
                ChunkUnloaded?.Invoke(key.Item1, key.Item2);
            }
        }

        public IReadOnlyDictionary<(int, int), Mesh> LoadedChunks => _loaded;
    }

    // ── Biome types ───────────────────────────────────────────────────────
    public enum BiomeType { Water, Sand, Grass, Rock, Snow }
}
