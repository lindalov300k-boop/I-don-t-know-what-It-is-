using System;
using System.Collections.Generic;
using System.Linq;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Procedural.WFC
{
    // ══════════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE v8 — WAVE FUNCTION COLLAPSE (WFC)
    //
    //  A constraint-propagation tile placer.  Given a set of tiles and their
    //  adjacency rules, WFC fills an N×M grid so every tile is compatible with
    //  every neighbour — the same algorithm behind Townscaper / Caves of Qud
    //  level generation.
    //
    //  HOW IT WORKS
    //  ─────────────
    //  1. Every cell starts as a superposition of ALL possible tiles.
    //  2. OBSERVE: Pick the cell with the lowest entropy (fewest valid tiles).
    //     Collapse it to a single tile chosen by weighted random.
    //  3. PROPAGATE: Broadcast the constraint to all neighbours.
    //     Remove tiles from neighbours that are now invalid.
    //     Repeat recursively.
    //  4. If a cell reaches 0 valid tiles → CONTRADICTION.
    //     Back-track to the last safe snapshot and retry.
    //  5. Repeat 2-4 until every cell is collapsed.
    //
    //  USAGE
    //  ─────
    //  var tileset = WFCTileset.Create2DBiome();        // or your own ruleset
    //  var solver  = new WaveFunctionCollapse(30, 30, tileset);
    //  int[,] map  = solver.Solve();                    // returns tile IDs
    //  if (map == null) Console.WriteLine("contradiction - retry");
    // ══════════════════════════════════════════════════════════════════════════

    // ── Tile definition ───────────────────────────────────────────────────────
    public class WFCTile
    {
        public int    Id       { get; }
        public string Name     { get; }
        public float  Weight   { get; set; } = 1f;  // probability weight

        // Allowed neighbour IDs per direction: 0=North 1=East 2=South 3=West
        // (for 3-D add 4=Up 5=Down)
        public HashSet<int>[] Neighbours { get; } = new HashSet<int>[4];

        public WFCTile(int id, string name, float weight = 1f)
        {
            Id     = id;
            Name   = name;
            Weight = weight;
            for (int i = 0; i < 4; i++) Neighbours[i] = new HashSet<int>();
        }

        public void Allow(int direction, int neighbourId)
            => Neighbours[direction].Add(neighbourId);

        /// Allow symmetric adjacency: t1 can border t2 on axis, t2 can border t1 on opposite
        public static void AllowBoth(WFCTile a, WFCTile b, int dir)
        {
            int opp = (dir + 2) % 4;
            a.Allow(dir, b.Id);
            b.Allow(opp, a.Id);
        }
    }

    // ── Tileset (collection of tiles + rules) ─────────────────────────────────
    public class WFCTileset
    {
        public List<WFCTile> Tiles { get; } = new();
        private readonly Dictionary<int, WFCTile> _byId = new();

        public void Add(WFCTile tile)
        {
            Tiles.Add(tile);
            _byId[tile.Id] = tile;
        }

        public WFCTile Get(int id) => _byId[id];

        // ── Preset: 2-D top-down biome map ────────────────────────────────────
        // Tile IDs: 0=DeepWater 1=ShallowWater 2=Sand 3=Grass 4=Forest
        //           5=Hill 6=Mountain 7=Snow
        public static WFCTileset Create2DBiome()
        {
            var ts = new WFCTileset();
            var deep  = new WFCTile(0, "DeepWater",    0.8f);
            var water = new WFCTile(1, "ShallowWater", 1.2f);
            var sand  = new WFCTile(2, "Sand",         1.0f);
            var grass = new WFCTile(3, "Grass",        2.0f);
            var forst = new WFCTile(4, "Forest",       1.5f);
            var hill  = new WFCTile(5, "Hill",         1.0f);
            var mtn   = new WFCTile(6, "Mountain",     0.7f);
            var snow  = new WFCTile(7, "Snow",         0.4f);

            ts.Add(deep); ts.Add(water); ts.Add(sand); ts.Add(grass);
            ts.Add(forst); ts.Add(hill); ts.Add(mtn); ts.Add(snow);

            // Each tile can be beside itself (all dirs)
            foreach (var t in ts.Tiles)
                for (int d = 0; d < 4; d++) t.Allow(d, t.Id);

            // Adjacent zone transitions (both directions, all 4 cardinal dirs)
            void Sym(WFCTile a, WFCTile b)
            {
                for (int d = 0; d < 4; d++) WFCTile.AllowBoth(a, b, d);
            }

            Sym(deep, water); Sym(water, sand); Sym(sand, grass);
            Sym(grass, forst); Sym(grass, hill); Sym(hill, mtn);
            Sym(mtn, snow); Sym(forst, hill);

            return ts;
        }

        // ── Preset: maze / dungeon rooms ─────────────────────────────────────
        // 0=Wall 1=Floor 2=DoorH 3=DoorV 4=Room 5=Corridor
        public static WFCTileset CreateDungeon()
        {
            var ts   = new WFCTileset();
            var wall = new WFCTile(0, "Wall",      2.0f);
            var flor = new WFCTile(1, "Floor",     3.0f);
            var dh   = new WFCTile(2, "DoorH",    0.3f);
            var dv   = new WFCTile(3, "DoorV",    0.3f);
            var room = new WFCTile(4, "Room",      1.5f);
            var corr = new WFCTile(5, "Corridor",  1.0f);
            ts.Add(wall); ts.Add(flor); ts.Add(dh); ts.Add(dv);
            ts.Add(room); ts.Add(corr);

            // Walls border anything
            foreach (var t in ts.Tiles)
                for (int d = 0; d < 4; d++) { wall.Allow(d, t.Id); t.Allow(d, wall.Id); }

            // Floor-to-floor transitions
            for (int d = 0; d < 4; d++) flor.Allow(d, flor.Id);
            for (int d = 0; d < 4; d++) { room.Allow(d, flor.Id); flor.Allow(d, room.Id); }
            for (int d = 0; d < 4; d++) { room.Allow(d, room.Id); }
            for (int d = 0; d < 4; d++) { corr.Allow(d, flor.Id); flor.Allow(d, corr.Id); }
            for (int d = 0; d < 4; d++) { corr.Allow(d, corr.Id); }

            // Doors connect floor to corridor
            dh.Allow(0, flor.Id); dh.Allow(2, flor.Id);  // N/S = floor
            dh.Allow(1, corr.Id); dh.Allow(3, corr.Id);  // E/W = corridor
            flor.Allow(0, dh.Id); flor.Allow(2, dh.Id);
            corr.Allow(1, dh.Id); corr.Allow(3, dh.Id);

            dv.Allow(1, flor.Id); dv.Allow(3, flor.Id);  // E/W = floor
            dv.Allow(0, corr.Id); dv.Allow(2, corr.Id);  // N/S = corridor
            flor.Allow(1, dv.Id); flor.Allow(3, dv.Id);
            corr.Allow(0, dv.Id); corr.Allow(2, dv.Id);

            return ts;
        }

        // ── Preset: city block layout ─────────────────────────────────────────
        // 0=Building 1=Road 2=Park 3=Parking 4=Water 5=Bridge
        public static WFCTileset CreateCity()
        {
            var ts   = new WFCTileset();
            var bld  = new WFCTile(0, "Building", 1.5f);
            var road = new WFCTile(1, "Road",     2.0f);
            var park = new WFCTile(2, "Park",     0.8f);
            var prk  = new WFCTile(3, "Parking",  0.6f);
            var wat  = new WFCTile(4, "Water",    0.4f);
            var bri  = new WFCTile(5, "Bridge",   0.2f);
            ts.Add(bld); ts.Add(road); ts.Add(park); ts.Add(prk); ts.Add(wat); ts.Add(bri);

            void Sym(WFCTile a, WFCTile b)
            {
                for (int d = 0; d < 4; d++) WFCTile.AllowBoth(a, b, d);
            }
            foreach (var t in ts.Tiles) for (int d = 0; d < 4; d++) t.Allow(d, t.Id);
            Sym(bld, road); Sym(road, park); Sym(road, prk); Sym(road, bri);
            Sym(park, park); Sym(bld, bld); Sym(wat, bri); Sym(road, wat);
            return ts;
        }
    }

    // ── WFC Cell ──────────────────────────────────────────────────────────────
    internal class WFCCell
    {
        public HashSet<int> Possible;    // remaining valid tile IDs
        public int          Collapsed = -1;
        public bool         IsCollapsed => Collapsed >= 0;

        // Entropy cache
        private float _entropy  = float.MaxValue;
        private bool  _dirty    = true;

        public WFCCell(IEnumerable<int> allIds)
        {
            Possible = new HashSet<int>(allIds);
        }

        public WFCCell Clone()
        {
            var c = new WFCCell(Possible) { Collapsed = Collapsed };
            return c;
        }

        public float Entropy(WFCTileset ts)
        {
            if (!_dirty) return _entropy;
            _dirty = false;
            if (Possible.Count == 0) return 0f;

            // Shannon entropy: -Σ p·log(p) using weights
            float total = Possible.Sum(id => ts.Get(id).Weight);
            if (total <= 0f) { _entropy = 0f; return 0f; }
            float e = 0f;
            foreach (int id in Possible)
            {
                float p = ts.Get(id).Weight / total;
                if (p > 0f) e -= p * MathF.Log(p);
            }
            _entropy = e;
            return e;
        }

        public void Invalidate() => _dirty = true;

        public bool Remove(int id)
        {
            if (!Possible.Contains(id)) return false;
            Possible.Remove(id);
            _dirty = true;
            return true;
        }
    }

    // ── Main Solver ───────────────────────────────────────────────────────────
    public class WaveFunctionCollapse
    {
        public int       Width   { get; }
        public int       Height  { get; }
        public WFCTileset Tileset { get; }

        // Back-tracking
        public int MaxRetries   { get; set; } = 10;
        private readonly Random _rng;

        // Direction vectors: N E S W
        private static readonly (int dx, int dy)[] _dirs =
            { (0,-1),(1,0),(0,1),(-1,0) };

        public WaveFunctionCollapse(int width, int height, WFCTileset tileset,
                                    int? seed = null)
        {
            Width   = width;
            Height  = height;
            Tileset = tileset;
            _rng    = seed.HasValue ? new Random(seed.Value) : new Random();
        }

        /// <summary>Solve the grid. Returns tile-ID array [x,y], or null on failure.</summary>
        public int[,]? Solve()
        {
            for (int attempt = 0; attempt < MaxRetries; attempt++)
            {
                var grid = InitGrid();
                if (Run(grid)) return Extract(grid);
                Console.WriteLine($"[WFC] Contradiction on attempt {attempt+1}/{MaxRetries}, retrying…");
            }
            Console.WriteLine("[WFC] Failed after all retries.");
            return null;
        }

        // ── Solve with an initial seed (force specific tiles before solving) ──
        public int[,]? SolveWithSeeds(IEnumerable<(int x, int y, int tileId)> seeds)
        {
            for (int attempt = 0; attempt < MaxRetries; attempt++)
            {
                var grid = InitGrid();
                bool ok  = true;
                foreach (var (x, y, id) in seeds)
                {
                    if (!ForceCollapse(grid, x, y, id))
                    { ok = false; break; }
                }
                if (ok && Run(grid)) return Extract(grid);
                Console.WriteLine($"[WFC] Seed attempt {attempt+1} failed, retrying…");
            }
            return null;
        }

        // ── Internal ──────────────────────────────────────────────────────────
        private WFCCell[,] InitGrid()
        {
            var allIds = Tileset.Tiles.Select(t => t.Id).ToArray();
            var g = new WFCCell[Width, Height];
            for (int x = 0; x < Width;  x++)
            for (int y = 0; y < Height; y++)
                g[x, y] = new WFCCell(allIds);
            return g;
        }

        private bool ForceCollapse(WFCCell[,] grid, int x, int y, int id)
        {
            var cell = grid[x, y];
            if (!cell.Possible.Contains(id)) return false;
            cell.Possible.Clear();
            cell.Possible.Add(id);
            cell.Collapsed = id;
            cell.Invalidate();
            return Propagate(grid, x, y);
        }

        private bool Run(WFCCell[,] grid)
        {
            while (true)
            {
                // Find uncollapsed cell with lowest entropy
                (int bx, int by) = (-1, -1);
                float  minE = float.MaxValue;

                for (int x = 0; x < Width;  x++)
                for (int y = 0; y < Height; y++)
                {
                    var cell = grid[x, y];
                    if (cell.IsCollapsed) continue;
                    float e = cell.Entropy(Tileset);
                    if (e < minE) { minE = e; bx = x; by = y; }
                }

                if (bx == -1) return true;  // all collapsed!

                // Collapse chosen cell
                var chosen = grid[bx, by];
                if (chosen.Possible.Count == 0) return false; // contradiction

                int tileId = WeightedRandom(chosen.Possible);
                chosen.Possible.Clear();
                chosen.Possible.Add(tileId);
                chosen.Collapsed = tileId;
                chosen.Invalidate();

                if (!Propagate(grid, bx, by)) return false;
            }
        }

        private bool Propagate(WFCCell[,] grid, int startX, int startY)
        {
            // BFS constraint propagation
            var queue = new Queue<(int x, int y)>();
            queue.Enqueue((startX, startY));
            var inQueue = new HashSet<(int,int)> { (startX, startY) };

            while (queue.Count > 0)
            {
                var (cx, cy) = queue.Dequeue();
                inQueue.Remove((cx, cy));
                var current = grid[cx, cy];

                for (int d = 0; d < 4; d++)
                {
                    int nx = cx + _dirs[d].dx;
                    int ny = cy + _dirs[d].dy;
                    if (nx < 0 || nx >= Width || ny < 0 || ny >= Height) continue;

                    var neighbour = grid[nx, ny];
                    if (neighbour.IsCollapsed) continue;

                    // Build set of all IDs allowed by current cell in direction d
                    var allowed = new HashSet<int>();
                    foreach (int id in current.Possible)
                        foreach (int nid in Tileset.Get(id).Neighbours[d])
                            allowed.Add(nid);

                    // Remove any neighbour tile not in the allowed set
                    bool changed = false;
                    foreach (int nid in neighbour.Possible.ToArray())
                    {
                        if (!allowed.Contains(nid))
                        {
                            neighbour.Remove(nid);
                            changed = true;
                        }
                    }

                    if (neighbour.Possible.Count == 0) return false; // contradiction!

                    // Auto-collapse single-option cells
                    if (neighbour.Possible.Count == 1 && !neighbour.IsCollapsed)
                    {
                        neighbour.Collapsed = neighbour.Possible.First();
                        neighbour.Invalidate();
                    }

                    if (changed && !inQueue.Contains((nx, ny)))
                    {
                        queue.Enqueue((nx, ny));
                        inQueue.Add((nx, ny));
                    }
                }
            }
            return true;
        }

        private int WeightedRandom(HashSet<int> ids)
        {
            float total = ids.Sum(id => Tileset.Get(id).Weight);
            float r     = (float)_rng.NextDouble() * total;
            foreach (int id in ids)
            {
                r -= Tileset.Get(id).Weight;
                if (r <= 0f) return id;
            }
            return ids.Last();
        }

        private int[,] Extract(WFCCell[,] grid)
        {
            var result = new int[Width, Height];
            for (int x = 0; x < Width;  x++)
            for (int y = 0; y < Height; y++)
                result[x, y] = grid[x, y].Collapsed;
            return result;
        }

        // ── Utilities ─────────────────────────────────────────────────────────

        /// <summary>Print the solved map to the console for debugging.</summary>
        public static void DebugPrint(int[,] map, WFCTileset ts,
                                      int maxW = 80, int maxH = 30)
        {
            int w = Math.Min(map.GetLength(0), maxW);
            int h = Math.Min(map.GetLength(1), maxH);
            string[] glyphs = { "≈", "~", ".", "#", "T", "^", "M", "*" };
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    int id = map[x, y];
                    Console.Write(id < glyphs.Length ? glyphs[id] : id.ToString());
                }
                Console.WriteLine();
            }
        }

        /// <summary>
        /// Convert a solved WFC map to a flat bool array: true = passable tile.
        /// passTileIds: set of tile IDs considered walkable.
        /// </summary>
        public static bool[,] ToPassabilityMap(int[,] map, params int[] passTileIds)
        {
            int w = map.GetLength(0), h = map.GetLength(1);
            var pass = new HashSet<int>(passTileIds);
            var result = new bool[w, h];
            for (int x = 0; x < w; x++)
            for (int y = 0; y < h; y++)
                result[x, y] = pass.Contains(map[x, y]);
            return result;
        }
    }
}
