using System;
using System.Collections.Generic;
namespace BADGE.Procedural.Maze
{
    public class RecursiveBacktracking
    {
        public static int[,] Generate(int width, int height)
        {
            int[,] maze = new int[width, height];
            Random rand = new Random();
            Stack<(int,int)> stack = new Stack<(int,int)>();
            stack.Push((0, 0));
            maze[0, 0] = 1;
            while(stack.Count > 0) {
                var (x, y) = stack.Pop();
                List<(int,int)> neighbors = new List<(int,int)>();
                if(x > 1 && maze[x-2,y] == 0) neighbors.Add((x-2,y));
                if(x < width-2 && maze[x+2,y] == 0) neighbors.Add((x+2,y));
                if(y > 1 && maze[x,y-2] == 0) neighbors.Add((x,y-2));
                if(y < height-2 && maze[x,y+2] == 0) neighbors.Add((x,y+2));
                if(neighbors.Count > 0) {
                    stack.Push((x,y));
                    var (nx,ny) = neighbors[rand.Next(neighbors.Count)];
                    maze[(x+nx)/2,(y+ny)/2] = 1;
                    maze[nx,ny] = 1;
                    stack.Push((nx,ny));
                }
            }
            return maze;
        }
    }
}
