using System;
using System.Collections.Generic;

namespace BADGE.Procedural
{
    // ══════════════════════════════════════════════════════════════════════
    //  ProceduralManager — coordinates all procedural generation systems
    //  and respects the engine idle/throttle state.
    // ══════════════════════════════════════════════════════════════════════
    public static class ProceduralManager
    {
        private static bool _isIdle = true;
        private static readonly List<IProceduralJob> _pendingJobs  = new();
        private static readonly List<IProceduralJob> _activeJobs   = new();
        private static readonly object _lock = new();

        // ── Idle management ───────────────────────────────────────────────
        public static void SetIdle(bool idle)
        {
            _isIdle = idle;
            if (!idle) FlushPending();
        }

        public static bool IsIdle => _isIdle;

        // ── Job submission ─────────────────────────────────────────────────
        public static void Enqueue(IProceduralJob job)
        {
            lock (_lock)
            {
                if (_isIdle)
                    _pendingJobs.Add(job);
                else
                    _activeJobs.Add(job);
            }
        }

        // ── Tick (called from engine when not idle) ───────────────────────
        public static void Tick(float dt)
        {
            if (_isIdle) return;
            lock (_lock)
            {
                for (int i = _activeJobs.Count - 1; i >= 0; i--)
                {
                    var job = _activeJobs[i];
                    job.Advance(dt);
                    if (job.IsComplete)
                    {
                        job.OnComplete?.Invoke();
                        _activeJobs.RemoveAt(i);
                    }
                }
            }
        }

        private static void FlushPending()
        {
            lock (_lock)
            {
                _activeJobs.AddRange(_pendingJobs);
                _pendingJobs.Clear();
            }
        }

        // ── Quick helpers ─────────────────────────────────────────────────
        public static float[,] GenerateHeightmap(int width, int height,
            float scale = 0.05f, int octaves = 6, float persistence = 0.5f, float lacunarity = 2f)
        {
            var map = new float[height, width];
            float maxVal = 0f;
            for (int y = 0; y < height; y++)
            for (int x = 0; x < width;  x++)
            {
                float v = Noise.FractalBrownianMotion.Generate(
                    x * scale, y * scale, octaves, persistence, lacunarity);
                map[y, x] = v;
                if (v > maxVal) maxVal = v;
            }
            // Normalize to 0..1
            if (maxVal > 0f)
                for (int y = 0; y < height; y++)
                for (int x = 0; x < width;  x++)
                    map[y, x] /= maxVal;
            return map;
        }

        public static int[,] GenerateBiomeMap(float[,] heightmap, float waterLevel = 0.35f,
            float beachLevel = 0.4f, float plainsLevel = 0.6f, float mountainLevel = 0.8f)
        {
            int rows = heightmap.GetLength(0), cols = heightmap.GetLength(1);
            var biomes = new int[rows, cols];
            for (int y = 0; y < rows; y++)
            for (int x = 0; x < cols; x++)
            {
                float h = heightmap[y, x];
                biomes[y, x] = h < waterLevel    ? 0  // Ocean
                             : h < beachLevel    ? 1  // Beach
                             : h < plainsLevel   ? 2  // Plains
                             : h < mountainLevel ? 3  // Hills
                                                 : 4; // Mountain
            }
            return biomes;
        }
    }

    public interface IProceduralJob
    {
        bool     IsComplete { get; }
        Action?  OnComplete { get; set; }
        void     Advance(float dt);
    }
}
