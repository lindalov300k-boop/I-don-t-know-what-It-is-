using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace BADGE.Core
{
    /// <summary>
    /// Gamepad / controller input using GLFW's joystick API.
    /// Supports up to 4 simultaneous gamepads.
    /// Xbox, PlayStation, and generic HID layouts are auto-detected.
    ///
    /// Usage:
    ///   var g = GamepadInput.Get(0);          // player 1
    ///   if (g.IsConnected) {
    ///       if (g.GetButtonDown(GamepadButton.A))  Jump();
    ///       Vector2 move = g.LeftStick;
    ///       float trigger = g.RightTrigger;
    ///   }
    ///
    /// Call GamepadInput.UpdateAll() once per frame from Input.BeginFrame().
    /// </summary>
    public static class GamepadInput
    {
        public const int MAX_GAMEPADS = 4;
        private static readonly GamepadState[] _states = new GamepadState[MAX_GAMEPADS];

        static GamepadInput()
        {
            for (int i = 0; i < MAX_GAMEPADS; i++)
                _states[i] = new GamepadState(i);
        }

        public static GamepadState Get(int playerIndex)
        {
            if (playerIndex < 0 || playerIndex >= MAX_GAMEPADS)
                throw new ArgumentOutOfRangeException(nameof(playerIndex));
            return _states[playerIndex];
        }

        /// <summary>Called by Input.BeginFrame() each frame.</summary>
        public static void UpdateAll()
        {
            for (int i = 0; i < MAX_GAMEPADS; i++)
                _states[i].Update();
        }

        /// <summary>Returns indices of all connected gamepads.</summary>
        public static IEnumerable<int> ConnectedIndices()
        {
            for (int i = 0; i < MAX_GAMEPADS; i++)
                if (_states[i].IsConnected) yield return i;
        }

        public static int ConnectedCount
        {
            get { int c = 0; for (int i = 0; i < MAX_GAMEPADS; i++) if (_states[i].IsConnected) c++; return c; }
        }
    }

    // ── Button enum (Xbox labelling — PS labels shown in comments) ─────────
    public enum GamepadButton
    {
        A = 0,        // Cross
        B = 1,        // Circle
        X = 2,        // Square
        Y = 3,        // Triangle
        LBumper = 4,  // L1
        RBumper = 5,  // R1
        Back    = 6,  // Select / Share
        Start   = 7,  // Options
        LStick  = 8,  // L3
        RStick  = 9,  // R3
        DPadUp  = 10,
        DPadRight = 11,
        DPadDown  = 12,
        DPadLeft  = 13,
    }

    // ── Per-gamepad state ──────────────────────────────────────────────────
    public class GamepadState
    {
        private readonly int _index;

        // Current + previous raw GLFW state
        private bool[] _buttons     = new bool[16];
        private bool[] _prevButtons = new bool[16];
        private float[] _axes       = new float[6];

        // ── Sticks ────────────────────────────────────────────────────────
        public Vector2 LeftStick    { get; private set; }
        public Vector2 RightStick   { get; private set; }

        /// <summary>Left trigger — 0 (released) to 1 (fully pressed).</summary>
        public float LeftTrigger    { get; private set; }
        /// <summary>Right trigger — 0 (released) to 1 (fully pressed).</summary>
        public float RightTrigger   { get; private set; }

        // ── Connection ────────────────────────────────────────────────────
        public bool IsConnected { get; private set; }
        public string Name      { get; private set; } = "Unknown";

        // ── Deadzone ──────────────────────────────────────────────────────
        public float StickDeadzone   { get; set; } = 0.12f;
        public float TriggerDeadzone { get; set; } = 0.05f;

        internal GamepadState(int index) => _index = index;

        internal unsafe void Update()
        {
            Array.Copy(_buttons, _prevButtons, _buttons.Length);

            int joy = _index;  // GLFW joystick index = player index
            IsConnected = GLFW.JoystickPresent(joy);
            if (!IsConnected) { ClearState(); return; }

            // Name
            Name = GLFW.GetJoystickName(joy) ?? "Gamepad";

            // Try gamepad mappings (SDL database — best for Xbox/PS)
            if (GLFW.JoystickIsGamepad(joy))
            {
                GLFW.GetGamepadState(joy, out var gps);

                // Buttons
                for (int b = 0; b < Math.Min(_buttons.Length, 15); b++)
                    _buttons[b] = gps.Buttons[b] == 1;

                // Axes
                float lx = ApplyDeadzone(gps.Axes[0], StickDeadzone);
                float ly = ApplyDeadzone(-gps.Axes[1], StickDeadzone);  // flip Y
                float rx = ApplyDeadzone(gps.Axes[2], StickDeadzone);
                float ry = ApplyDeadzone(-gps.Axes[3], StickDeadzone);

                LeftStick   = new Vector2(lx, ly);
                RightStick  = new Vector2(rx, ry);
                LeftTrigger  = NormaliseTrigger(gps.Axes[4]);
                RightTrigger = NormaliseTrigger(gps.Axes[5]);
            }
            else
            {
                // Raw HID fallback
                var rawAxes    = GLFW.GetJoystickAxes(joy);
                var rawButtons = GLFW.GetJoystickButtons(joy);

                for (int b = 0; b < Math.Min(_buttons.Length, rawButtons.Count); b++)
                    _buttons[b] = rawButtons[b] == 1;

                if (rawAxes.Count >= 4)
                {
                    LeftStick   = new Vector2(
                        ApplyDeadzone(rawAxes[0], StickDeadzone),
                        ApplyDeadzone(-rawAxes[1], StickDeadzone));
                    RightStick  = new Vector2(
                        ApplyDeadzone(rawAxes[2], StickDeadzone),
                        ApplyDeadzone(-rawAxes[3], StickDeadzone));
                }
                if (rawAxes.Count >= 6)
                {
                    LeftTrigger  = NormaliseTrigger(rawAxes[4]);
                    RightTrigger = NormaliseTrigger(rawAxes[5]);
                }
            }
        }

        // ── Button queries ─────────────────────────────────────────────────
        public bool GetButton(GamepadButton btn)
            => IsConnected && _buttons[(int)btn];

        public bool GetButtonDown(GamepadButton btn)
            => IsConnected && _buttons[(int)btn] && !_prevButtons[(int)btn];

        public bool GetButtonUp(GamepadButton btn)
            => IsConnected && !_buttons[(int)btn] && _prevButtons[(int)btn];

        // ── DPad as Vector2 ────────────────────────────────────────────────
        public Vector2 DPad => new(
            (GetButton(GamepadButton.DPadRight) ? 1f : 0f) -
            (GetButton(GamepadButton.DPadLeft)  ? 1f : 0f),
            (GetButton(GamepadButton.DPadUp)    ? 1f : 0f) -
            (GetButton(GamepadButton.DPadDown)  ? 1f : 0f));

        // ── Convenience: any button pressed ───────────────────────────────
        public bool AnyButtonDown()
        {
            if (!IsConnected) return false;
            for (int i = 0; i < _buttons.Length; i++)
                if (_buttons[i] && !_prevButtons[i]) return true;
            return LeftTrigger > 0.5f || RightTrigger > 0.5f;
        }

        // ── Helpers ───────────────────────────────────────────────────────
        private static float ApplyDeadzone(float v, float dz)
        {
            if (MathF.Abs(v) < dz) return 0f;
            float sign = v > 0 ? 1f : -1f;
            return sign * (MathF.Abs(v) - dz) / (1f - dz);
        }

        private static float NormaliseTrigger(float raw)
            => Math.Clamp((raw + 1f) * 0.5f, 0f, 1f);

        private void ClearState()
        {
            Array.Clear(_buttons, 0, _buttons.Length);
            LeftStick = RightStick = Vector2.Zero;
            LeftTrigger = RightTrigger = 0f;
        }
    }
}
// ── Rumble / haptic feedback extension ─────────────────────────────────────
// NOTE: Added for Game Pass / Xbox controller support.
// GLFW does not expose rumble natively; use XInput on Windows via P/Invoke,
// and SDL_GameControllerRumble on Linux via interop.
// This wrapper tries both and silently falls back if unavailable.
//
// Usage:
//   GamepadInput.Get(0).Rumble(0.5f, 0.8f, 200);  // left, right, ms
