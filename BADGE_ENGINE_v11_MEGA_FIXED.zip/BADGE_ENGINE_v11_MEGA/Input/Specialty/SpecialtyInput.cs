using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace BADGE.Input.Specialty
{
    // ═══════════════════════════════════════════════════════════════════════
    //  SPECIALTY / SIMULATION CONTROLLERS
    //
    //  Covers:
    //    • Steering Wheel (Logitech G29/G923, Thrustmaster T300, Fanatec)
    //    • Racing Pedals (brake/throttle/clutch, load-cell support)
    //    • H-Pattern Shifter + sequential
    //    • Flight Stick (joystick + twist + hat switches)
    //    • Throttle / HOTAS (Hands On Throttle And Stick)
    //    • Rudder Pedals (yaw axis + toe brakes)
    //    • Button Box / Stream Deck (16-128 programmable buttons)
    //    • Arcade Stick (4+8 button layout, restrictor plate mode)
    //    • Dance Pad (9-zone pressure mat)
    //    • Drum Kit (velocity-sensitive pads)
    //    • Force Feedback output
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  STEERING WHEEL
    // ─────────────────────────────────────────────────────────────────────
    public struct SteeringWheelState
    {
        public float   SteeringAngle;    // -1..1  (maps to ±SteeringRange degrees)
        public float   SteeringRangeDeg; // physical lock-to-lock (e.g. 900)
        public float   Throttle;         // 0-1
        public float   Brake;            // 0-1
        public float   Clutch;           // 0-1
        public float   Handbrake;        // 0-1 (if available as axis)
        public int     GearShifter;      // -1=reverse, 0=neutral, 1-8=gear
        public bool    ShiftUp;          // paddle shift
        public bool    ShiftDown;
        public bool    IsConnected;
        private uint   _buttons;
        private uint   _prevButtons;

        public float   SteeringDegrees => SteeringAngle * SteeringRangeDeg * 0.5f;

        public bool GetButton(int index)     => (_buttons & (1u << index)) != 0;
        public bool GetButtonDown(int index) =>
            (_buttons & (1u << index)) != 0 && (_prevButtons & (1u << index)) == 0;

        internal void UpdateButtons(uint curr) { _prevButtons = _buttons; _buttons = curr; }
    }

    public struct ForceFeedbackCommand
    {
        public ForceFeedbackEffect Effect;
        public float  Magnitude;       // 0-1
        public float  DurationSec;
        public float  StartPosition;   // for spring/friction
        public float  DirectionAngle;  // for directional effects
        public float  FrequencyHz;     // for periodic effects
        public float  Saturation;      // 0-1 clamp
        public float  Deadband;        // 0-1 center dead zone
    }

    public enum ForceFeedbackEffect
    {
        Constant, Spring, Friction, Damper, Inertia,
        Sine, Square, Triangle, SawtoothUp, SawtoothDown,
        AutoCenter, Rumble
    }

    // ─────────────────────────────────────────────────────────────────────
    //  FLIGHT STICK / HOTAS
    // ─────────────────────────────────────────────────────────────────────
    public struct FlightStickState
    {
        public float   Pitch;          // -1..1 (nose up/down)
        public float   Roll;           // -1..1 (bank left/right)
        public float   Yaw;            // -1..1 (twist/rudder)
        public float   Throttle;       // 0..1
        public float   Throttle2;      // second throttle (HOTAS split)
        public float   MiniStickX;     // thumb mini-stick
        public float   MiniStickY;
        public Vector2 HatSwitch1;     // 8-way hat (-1..1 per axis)
        public Vector2 HatSwitch2;
        public Vector2 HatSwitch3;
        public Vector2 HatSwitch4;
        public bool    IsConnected;
        private uint   _buttons;
        private uint   _prevButtons;

        public bool GetButton(int i)     => (_buttons & (1u << i)) != 0;
        public bool GetButtonDown(int i) => (_buttons & (1u << i)) != 0 && (_prevButtons & (1u << i)) == 0;
        public bool GetButtonUp(int i)   => (_buttons & (1u << i)) == 0 && (_prevButtons & (1u << i)) != 0;
        internal void UpdateButtons(uint c) { _prevButtons = _buttons; _buttons = c; }

        // Derived
        public Vector2 AileronElevator => new(Roll, Pitch);
        public bool    TriggerPressed  => GetButton(0);
        public bool    FireButtonA     => GetButton(1);
        public bool    FireButtonB     => GetButton(2);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  ARCADE STICK
    // ─────────────────────────────────────────────────────────────────────
    public enum ArcadeRestrictor { Circular, Square, Octagonal }

    public struct ArcadeStickState
    {
        public float   AxisX;        // -1..1
        public float   AxisY;        // -1..1
        public ArcadeRestrictor Restrictor;
        private uint   _buttons;
        private uint   _prevButtons;

        public bool GetButton(int i)     => (_buttons & (1u << i)) != 0;
        public bool GetButtonDown(int i) => (_buttons & (1u << i)) != 0 && (_prevButtons & (1u << i)) == 0;
        internal void UpdateButtons(uint c) { _prevButtons = _buttons; _buttons = c; }

        // 8-way digital direction derived from analog
        public bool Up    => AxisY < -0.5f;
        public bool Down  => AxisY >  0.5f;
        public bool Left  => AxisX < -0.5f;
        public bool Right => AxisX >  0.5f;

        // Street Fighter layout helpers (LP, MP, HP, LK, MK, HK)
        public bool LP => GetButton(0);
        public bool MP => GetButton(1);
        public bool HP => GetButton(2);
        public bool LK => GetButton(3);
        public bool MK => GetButton(4);
        public bool HK => GetButton(5);
        public bool Start => GetButton(8);
        public bool Select => GetButton(9);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DANCE PAD
    // ─────────────────────────────────────────────────────────────────────
    public enum DancePadZone
    {
        UpLeft = 0, Up, UpRight,
        Left,       Center, Right,
        DownLeft,   Down,   DownRight
    }

    public struct DancePadState
    {
        private readonly float[] _pressure; // [9] zones

        public DancePadState() { _pressure = new float[9]; }

        public float GetPressure(DancePadZone zone) => _pressure[(int)zone];
        public bool  IsPressed(DancePadZone zone)   => _pressure[(int)zone] > 0.2f;

        internal void SetZone(DancePadZone zone, float pressure) =>
            _pressure[(int)zone] = pressure;

        public bool Up    => IsPressed(DancePadZone.Up);
        public bool Down  => IsPressed(DancePadZone.Down);
        public bool Left  => IsPressed(DancePadZone.Left);
        public bool Right => IsPressed(DancePadZone.Right);
        public bool Center => IsPressed(DancePadZone.Center);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DRUM KIT
    // ─────────────────────────────────────────────────────────────────────
    public enum DrumPad
    {
        Kick1, Kick2,
        Snare, SnareCrossStick,
        HiHat, HiHatOpen, HiHatClose,
        Tom1, Tom2, Tom3, Tom4,
        CrashLeft, CrashRight,
        Ride, RideBell
    }

    public struct DrumKitState
    {
        private readonly float[] _velocity; // per pad, 0-1
        private readonly bool[]  _hit;      // this-frame hit

        public DrumKitState() { _velocity = new float[16]; _hit = new bool[16]; }

        public float GetVelocity(DrumPad pad) => _velocity[(int)pad];
        public bool  WasHit(DrumPad pad)      => _hit[(int)pad];
        public bool  IsHeld(DrumPad pad)      => _velocity[(int)pad] > 0.05f;

        internal void SetPad(DrumPad pad, float vel, bool hit)
        {
            _velocity[(int)pad] = vel;
            _hit[(int)pad]      = hit;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  BUTTON BOX / STREAM DECK
    // ─────────────────────────────────────────────────────────────────────
    public struct ButtonBoxState
    {
        public int    ButtonCount;
        public string DeviceName;
        private readonly bool[] _pressed;
        private readonly bool[] _prevPressed;

        public ButtonBoxState(int count, string name = "ButtonBox")
        {
            ButtonCount  = count;
            DeviceName   = name;
            _pressed     = new bool[count];
            _prevPressed = new bool[count];
        }

        public bool GetButton(int i)     => i < ButtonCount && _pressed[i];
        public bool GetButtonDown(int i) => i < ButtonCount && _pressed[i] && !_prevPressed[i];
        public bool GetButtonUp(int i)   => i < ButtonCount && !_pressed[i] && _prevPressed[i];

        internal void SetButton(int i, bool state)
        {
            if (i >= ButtonCount) return;
            _prevPressed[i] = _pressed[i];
            _pressed[i]     = state;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNIFIED SPECIALTY INPUT MANAGER
    // ─────────────────────────────────────────────────────────────────────
    public static class SpecialtyInput
    {
        public static SteeringWheelState  SteeringWheel { get; private set; }
        public static FlightStickState    FlightStick   { get; private set; }
        public static ArcadeStickState    ArcadeStick   { get; private set; }
        public static DancePadState       DancePad      { get; private set; } = new();
        public static DrumKitState        DrumKit       { get; private set; } = new();

        private static readonly List<ButtonBoxState> _buttonBoxes = new();
        private static readonly Queue<ForceFeedbackCommand> _ffbQueue = new();

        // ── Injection ─────────────────────────────────────────────────────
        public static void InjectSteeringWheel(SteeringWheelState s)   => SteeringWheel = s;
        public static void InjectFlightStick(FlightStickState s)       => FlightStick   = s;
        public static void InjectArcadeStick(ArcadeStickState s)       => ArcadeStick   = s;
        public static void InjectDancePadZone(DancePadZone z, float p)
        {
            var pad = DancePad;
            pad.SetZone(z, p);
            DancePad = pad;
        }
        public static void InjectDrumHit(DrumPad pad, float velocity)
        {
            var kit = DrumKit;
            kit.SetPad(pad, velocity, true);
            DrumKit = kit;
        }

        // ── Force Feedback ────────────────────────────────────────────────
        public static void SendFFB(ForceFeedbackCommand cmd) => _ffbQueue.Enqueue(cmd);
        public static bool PollFFB(out ForceFeedbackCommand cmd) => _ffbQueue.TryDequeue(out cmd);

        public static void SetConstantForce(float magnitude, float durationSec = float.MaxValue) =>
            SendFFB(new ForceFeedbackCommand { Effect = ForceFeedbackEffect.Constant,
                Magnitude = magnitude, DurationSec = durationSec });

        public static void SetSpring(float startPos, float magnitude = 0.8f) =>
            SendFFB(new ForceFeedbackCommand { Effect = ForceFeedbackEffect.Spring,
                StartPosition = startPos, Magnitude = magnitude, DurationSec = float.MaxValue });

        public static void RumbleWheel(float magnitude = 0.5f, float seconds = 0.2f) =>
            SendFFB(new ForceFeedbackCommand { Effect = ForceFeedbackEffect.Rumble,
                Magnitude = magnitude, DurationSec = seconds });
    }
}
