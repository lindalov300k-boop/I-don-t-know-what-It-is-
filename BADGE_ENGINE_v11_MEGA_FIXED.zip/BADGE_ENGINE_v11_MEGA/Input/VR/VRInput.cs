using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Input.VR
{
    // ═══════════════════════════════════════════════════════════════════════
    //  VR INPUT SYSTEM  — OpenXR / OpenVR / Oculus / SteamVR compatible
    //
    //  Supports:
    //    • 6DOF HMD pose (position + orientation)
    //    • Left/Right motion controllers (position, rotation, velocity)
    //    • Trigger, grip, thumbstick, buttons (A/B/X/Y, menu, system)
    //    • Hand tracking (skeletal 26-joint model)
    //    • Eye tracking (gaze direction per eye + combined)
    //    • Haptic rumble (amplitude, duration, frequency)
    //    • Boundary / guardian detection
    //    • Pass-through / mixed reality mode flag
    //
    //  Platform bridge:
    //    Call VRInput.InjectHMDPose() and VRInput.InjectControllerState()
    //    from your native OpenXR plugin each frame.
    // ═══════════════════════════════════════════════════════════════════════

    public enum VRHandedness { Left, Right }

    public enum VRButton
    {
        // Face buttons
        A, B, X, Y,
        // System
        Menu, System, Home,
        // Sticks/pads
        ThumbstickClick, TouchpadClick, TouchpadTouch,
        // Triggers (digital threshold)
        TriggerClick, GripClick,
        // Oculus-specific
        OculusThumbRest,
        // Valve Index Finger Curl thresholds (digital)
        IndexFingerPinch, MiddleFingerCurl, RingFingerCurl, PinkyFingerCurl
    }

    public enum VRTrackingSpace { Local, Stage, View }

    // ── Skeletal hand joint (OpenXR spec order) ───────────────────────────
    public enum HandJoint
    {
        Palm = 0, Wrist,
        ThumbMetacarpal, ThumbProximal, ThumbDistal, ThumbTip,
        IndexMetacarpal, IndexProximal, IndexIntermediate, IndexDistal, IndexTip,
        MiddleMetacarpal, MiddleProximal, MiddleIntermediate, MiddleDistal, MiddleTip,
        RingMetacarpal, RingProximal, RingIntermediate, RingDistal, RingTip,
        LittleMetacarpal, LittleProximal, LittleIntermediate, LittleDistal, LittleTip,
        Count = 26
    }

    public struct VRPose
    {
        public Vector3    Position;
        public Quaternion Rotation;
        public bool       IsTracked;

        public Matrix4 ToMatrix()
        {
            var rot = Matrix4.CreateFromQuaternion(Rotation);
            rot.Row3 = new Vector4(Position, 1f);
            return rot;
        }

        public Vector3 Forward => Vector3.Transform(-Vector3.UnitZ, Rotation);
        public Vector3 Up      => Vector3.Transform(Vector3.UnitY,  Rotation);
        public Vector3 Right   => Vector3.Transform(Vector3.UnitX,  Rotation);
    }

    public struct VRControllerState
    {
        public VRPose    Pose;
        public Vector3   Velocity;
        public Vector3   AngularVelocity;

        // Analog
        public float     Trigger;       // 0-1
        public float     Grip;          // 0-1
        public Vector2   Thumbstick;    // -1..1 per axis
        public Vector2   Touchpad;      // -1..1 per axis
        public float     TouchpadForce; // Valve Index only

        // Finger curls (Valve Index / hand tracking)
        public float     IndexCurl;
        public float     MiddleCurl;
        public float     RingCurl;
        public float     PinkyCurl;
        public float     ThumbCurl;

        // Digital (packed bits via HashSet)
        internal HashSet<VRButton> _pressed;
        internal HashSet<VRButton> _prevPressed;

        public bool GetButton(VRButton b)     => _pressed?.Contains(b) ?? false;
        public bool GetButtonDown(VRButton b) => (_pressed?.Contains(b) ?? false) && !(_prevPressed?.Contains(b) ?? false);
        public bool GetButtonUp(VRButton b)   => !(_pressed?.Contains(b) ?? false) && (_prevPressed?.Contains(b) ?? false);
    }

    public struct HandSkeletonPose
    {
        public VRPose[]  Joints;     // [HandJoint.Count]
        public float[]   Radii;      // bone radius per joint (meters)
        public bool      IsTracked;
        public float     Confidence; // 0-1

        public VRPose GetJoint(HandJoint j) => IsTracked ? Joints[(int)j] : default;
        public Vector3 FingerTip(HandJoint tip) => GetJoint(tip).Position;

        // Pinch detection
        public float PinchStrength(HandJoint finger = HandJoint.IndexTip)
        {
            if (!IsTracked) return 0f;
            float dist = Vector3.Distance(Joints[(int)HandJoint.ThumbTip].Position,
                                          Joints[(int)finger].Position);
            return 1f - MathHelper.Clamp(dist / 0.04f, 0f, 1f); // 4cm = fully open
        }
    }

    public struct VREyeGaze
    {
        public Vector3 OriginLeft,  DirectionLeft;
        public Vector3 OriginRight, DirectionRight;
        public Vector3 CombinedOrigin, CombinedDirection;
        public float   PupilDiameterLeftMm, PupilDiameterRightMm;
        public bool    IsTracked;

        /// <summary>Ray-cast gaze into scene at given distance.</summary>
        public Vector3 GazePoint(float distance = 10f) =>
            CombinedOrigin + CombinedDirection * distance;
    }

    // ── Haptics request ───────────────────────────────────────────────────
    public struct HapticPulse
    {
        public VRHandedness Hand;
        public float        Amplitude;  // 0-1
        public float        DurationSec;
        public float        FrequencyHz; // 0 = broadband
    }

    public static class VRInput
    {
        // ── HMD ───────────────────────────────────────────────────────────
        public static VRPose    HMDPose          { get; private set; }
        public static VREyeGaze EyeGaze          { get; private set; }
        public static bool      IsHMDConnected   { get; private set; }
        public static bool      IsHMDMounted     { get; private set; }
        public static float     IPDMeters        { get; set; } = 0.063f;
        public static bool      BoundaryVisible  { get; private set; }
        public static bool      PassThroughActive{ get; private set; }

        // ── Render targets ────────────────────────────────────────────────
        public static Vector2i  RecommendedEyeResolution { get; private set; } = new(1832, 1920);

        // ── Controllers ───────────────────────────────────────────────────
        private static VRControllerState _left  = new() { _pressed = new(), _prevPressed = new() };
        private static VRControllerState _right = new() { _pressed = new(), _prevPressed = new() };

        public static VRControllerState LeftController  => _left;
        public static VRControllerState RightController => _right;
        public static VRControllerState GetController(VRHandedness h) =>
            h == VRHandedness.Left ? _left : _right;

        // ── Hand tracking ─────────────────────────────────────────────────
        public static HandSkeletonPose LeftHand  { get; private set; }
        public static HandSkeletonPose RightHand { get; private set; }

        // ── Haptic queue ──────────────────────────────────────────────────
        private static readonly Queue<HapticPulse> _hapticQueue = new();

        // ── Velocity helpers ──────────────────────────────────────────────
        public static Vector3 GetControllerVelocity(VRHandedness h) =>
            h == VRHandedness.Left ? _left.Velocity : _right.Velocity;

        public static float ThrowSpeed(VRHandedness h) =>
            GetControllerVelocity(h).Length;

        // ─────────────────────────────────────────────────────────────────
        //  INJECTION API  (called by native VR bridge each frame)
        // ─────────────────────────────────────────────────────────────────

        public static void InjectHMDPose(Vector3 pos, Quaternion rot,
                                          bool connected = true, bool mounted = true)
        {
            HMDPose = new VRPose { Position = pos, Rotation = rot, IsTracked = connected };
            IsHMDConnected = connected;
            IsHMDMounted   = mounted;
        }

        public static void InjectControllerState(VRHandedness hand, VRControllerState state)
        {
            if (hand == VRHandedness.Left)
            {
                state._prevPressed = new HashSet<VRButton>(_left._pressed ?? new HashSet<VRButton>());
                state._pressed ??= new HashSet<VRButton>();
                _left = state;
            }
            else
            {
                state._prevPressed = new HashSet<VRButton>(_right._pressed ?? new HashSet<VRButton>());
                state._pressed ??= new HashSet<VRButton>();
                _right = state;
            }
        }

        public static void InjectHandSkeleton(VRHandedness hand, HandSkeletonPose pose)
        {
            if (hand == VRHandedness.Left)  LeftHand  = pose;
            else                             RightHand = pose;
        }

        public static void InjectEyeGaze(VREyeGaze gaze) => EyeGaze = gaze;

        public static void InjectBoundaryState(bool visible)   => BoundaryVisible  = visible;
        public static void InjectPassThrough(bool active)      => PassThroughActive = active;

        // ─────────────────────────────────────────────────────────────────
        //  HAPTICS
        // ─────────────────────────────────────────────────────────────────
        public static void Vibrate(VRHandedness hand, float amplitude = 0.5f,
                                    float durationSec = 0.1f, float frequencyHz = 200f)
        {
            _hapticQueue.Enqueue(new HapticPulse
            {
                Hand = hand, Amplitude = amplitude,
                DurationSec = durationSec, FrequencyHz = frequencyHz
            });
        }

        public static bool PollHaptic(out HapticPulse pulse) =>
            _hapticQueue.TryDequeue(out pulse);

        // ─────────────────────────────────────────────────────────────────
        //  HIGH-LEVEL HELPERS
        // ─────────────────────────────────────────────────────────────────

        /// <summary>Both hands grabbing simultaneously (co-op grab).</summary>
        public static bool IsTwoHandedGrip =>
            _left.Grip > 0.8f && _right.Grip > 0.8f;

        /// <summary>Pointing gesture: index extended, others curled.</summary>
        public static bool IsPointing(VRHandedness h)
        {
            var hand = h == VRHandedness.Left ? LeftHand : RightHand;
            if (!hand.IsTracked) return false;
            return hand.Joints[(int)HandJoint.IndexTip].Position.Y >
                   hand.Joints[(int)HandJoint.IndexProximal].Position.Y &&
                   hand.PinchStrength(HandJoint.MiddleTip) < 0.3f;
        }

        /// <summary>World-space ray from controller.</summary>
        public static (Vector3 Origin, Vector3 Dir) GetPointerRay(VRHandedness h)
        {
            var ctrl = GetController(h);
            return (ctrl.Pose.Position, ctrl.Pose.Forward);
        }

        public static void Reset()
        {
            _left  = new VRControllerState { _pressed = new(), _prevPressed = new() };
            _right = new VRControllerState { _pressed = new(), _prevPressed = new() };
            IsHMDConnected = false;
        }
    }
}
