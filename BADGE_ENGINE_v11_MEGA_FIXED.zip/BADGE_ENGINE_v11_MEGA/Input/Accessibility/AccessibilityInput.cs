using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Input.Accessibility
{
    // ═══════════════════════════════════════════════════════════════════════
    //  ACCESSIBILITY INPUT
    //
    //  Covers:
    //    • Single-switch scanning (one-button navigation through UI)
    //    • Two-switch scanning (next + select)
    //    • Head tracking (camera-based, e.g. TrackIR, webcam)
    //    • Mouth/sip-and-puff controller
    //    • Foot pedal input (1-5 pedals)
    //    • Xbox Adaptive Controller (custom input remapping surface)
    //    • Switch adapted devices (large buttons, slap switches, etc.)
    //    • On-screen keyboard integration
    //    • Dwell-click emulation
    //    • Auto-fire / hold assistance
    //    • Slow keys (extended hold to activate)
    //    • Sticky keys (hold replacement)
    //    • One-handed mode (gamepad or keyboard)
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  SWITCH ACCESS SCANNING
    // ─────────────────────────────────────────────────────────────────────
    public enum ScanningMode { Auto, TwoSwitch, Directed }

    public static class SwitchAccess
    {
        public static ScanningMode Mode { get; set; } = ScanningMode.Auto;
        public static float        AutoScanIntervalSec { get; set; } = 1.5f;
        public static int          ScanPosition        { get; private set; } = 0;
        public static int          MaxItems            { get; set; } = 10;
        public static bool         WrapAround          { get; set; } = true;

        private static bool _switchA, _prevA;
        private static bool _switchB, _prevB;
        private static float _autoTimer;

        // ── Injection (from any button mapped to switch 1/2) ─────────────
        public static void InjectSwitch(int switchIndex, bool pressed)
        {
            if (switchIndex == 0) { _prevA = _switchA; _switchA = pressed; }
            else                  { _prevB = _switchB; _switchB = pressed; }
        }

        public static void Update(float dt)
        {
            bool a0 = !_prevA && _switchA; // A just pressed
            bool b0 = !_prevB && _switchB; // B just pressed

            switch (Mode)
            {
                case ScanningMode.Auto:
                    _autoTimer += dt;
                    if (_autoTimer >= AutoScanIntervalSec)
                    {
                        _autoTimer = 0f;
                        Advance();
                    }
                    if (a0) OnSelectFired?.Invoke(ScanPosition);
                    break;

                case ScanningMode.TwoSwitch:
                    if (a0) Advance();
                    if (b0) OnSelectFired?.Invoke(ScanPosition);
                    break;

                case ScanningMode.Directed:
                    if (a0) Advance();
                    if (b0) Retreat();
                    break;
            }
        }

        private static void Advance()
        {
            ScanPosition++;
            if (ScanPosition >= MaxItems)
                ScanPosition = WrapAround ? 0 : MaxItems - 1;
            OnScanMoved?.Invoke(ScanPosition);
        }

        private static void Retreat()
        {
            ScanPosition--;
            if (ScanPosition < 0)
                ScanPosition = WrapAround ? MaxItems - 1 : 0;
            OnScanMoved?.Invoke(ScanPosition);
        }

        public static event Action<int>? OnScanMoved;
        public static event Action<int>? OnSelectFired;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  HEAD TRACKING
    // ─────────────────────────────────────────────────────────────────────
    public struct HeadPoseState
    {
        public float  Yaw;          // degrees, left/right head rotation
        public float  Pitch;        // degrees, up/down head tilt
        public float  Roll;         // degrees, head tilt (ear to shoulder)
        public Vector3 Position;    // head position offset in cm
        public bool   IsTracked;

        // Mapped cursor output (head movement → cursor delta)
        public Vector2 CursorDelta;
        public float   CursorSpeed;
    }

    public static class HeadTrackingInput
    {
        public static HeadPoseState State { get; private set; }
        public static float YawSensitivity   { get; set; } = 1f;
        public static float PitchSensitivity { get; set; } = 1f;
        public static float DeadZoneDeg      { get; set; } = 3f;

        public static void InjectPose(HeadPoseState pose) => State = pose;

        // Derive virtual joystick values from head rotation
        public static Vector2 GetVirtualStick()
        {
            float x = Math.Abs(State.Yaw)   > DeadZoneDeg ? State.Yaw   * YawSensitivity   / 45f : 0f;
            float y = Math.Abs(State.Pitch) > DeadZoneDeg ? State.Pitch * PitchSensitivity / 45f : 0f;
            return new Vector2(MathHelper.Clamp(x, -1f, 1f), MathHelper.Clamp(y, -1f, 1f));
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  SIP & PUFF CONTROLLER
    // ─────────────────────────────────────────────────────────────────────
    public enum SipPuffAction { None, Sip, Puff, HardSip, HardPuff }

    public static class SipPuffInput
    {
        public static float SipPuffValue      { get; private set; }  // -1 sip .. +1 puff
        public static SipPuffAction Action    { get; private set; }

        public static float SoftThreshold { get; set; } = 0.3f;
        public static float HardThreshold { get; set; } = 0.8f;

        public static void InjectValue(float value)
        {
            SipPuffValue = MathHelper.Clamp(value, -1f, 1f);
            Action = value switch
            {
                < -0.8f => SipPuffAction.HardSip,
                < -0.3f => SipPuffAction.Sip,
                >  0.8f => SipPuffAction.HardPuff,
                >  0.3f => SipPuffAction.Puff,
                _       => SipPuffAction.None
            };
        }

        public static bool IsSipping  => Action is SipPuffAction.Sip or SipPuffAction.HardSip;
        public static bool IsPuffing  => Action is SipPuffAction.Puff or SipPuffAction.HardPuff;
        public static bool IsHardSip  => Action == SipPuffAction.HardSip;
        public static bool IsHardPuff => Action == SipPuffAction.HardPuff;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  FOOT PEDAL
    // ─────────────────────────────────────────────────────────────────────
    public static class FootPedalInput
    {
        public const int MAX_PEDALS = 5;
        private static readonly float[] _values  = new float[MAX_PEDALS];
        private static readonly float[] _prev    = new float[MAX_PEDALS];

        public static float Get(int pedal)     => pedal < MAX_PEDALS ? _values[pedal] : 0f;
        public static bool  IsPressed(int p)   => _values[p] > 0.1f;
        public static bool  JustPressed(int p) => _values[p] > 0.1f && _prev[p] <= 0.1f;
        public static bool  JustReleased(int p)=> _values[p] <= 0.1f && _prev[p] > 0.1f;

        public static void InjectPedal(int index, float value)
        {
            if (index < 0 || index >= MAX_PEDALS) return;
            _prev[index]   = _values[index];
            _values[index] = value;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  ACCESSIBILITY MODIFIERS (Slow Keys, Sticky Keys, Auto-Fire)
    // ─────────────────────────────────────────────────────────────────────
    public class SlowKeysFilter
    {
        public float HoldRequired { get; set; } = 0.5f; // seconds
        private readonly Dictionary<string, float> _holdTimes = new();

        public bool IsActive(string key, bool physicallyHeld, float dt)
        {
            if (!physicallyHeld) { _holdTimes[key] = 0f; return false; }
            if (!_holdTimes.TryGetValue(key, out float t)) t = 0f;
            t += dt;
            _holdTimes[key] = t;
            return t >= HoldRequired;
        }
    }

    public class AutoFireModifier
    {
        public float Interval { get; set; } = 0.1f; // seconds between fires
        private readonly Dictionary<string, float> _timers = new();

        public bool ShouldFire(string key, bool held, float dt)
        {
            if (!held) { _timers[key] = 0f; return false; }
            if (!_timers.TryGetValue(key, out float t)) { _timers[key] = 0f; return true; }
            t += dt;
            if (t >= Interval) { _timers[key] = 0f; return true; }
            _timers[key] = t;
            return false;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  REMAPPING OVERLAY (Xbox Adaptive Controller surface)
    // ─────────────────────────────────────────────────────────────────────
    public class AdaptiveControllerSurface
    {
        private readonly Dictionary<string, string> _remapTable = new();

        public void Remap(string source, string target) =>
            _remapTable[source] = target;

        public string Resolve(string input) =>
            _remapTable.TryGetValue(input, out string? mapped) ? mapped : input;

        public void LoadPreset(string presetName)
        {
            _remapTable.Clear();
            // Preset profiles for one-handed play etc.
            switch (presetName)
            {
                case "LeftHandOnly":
                    Remap("RightStickX", "Horizontal");
                    Remap("RightStickY", "Vertical");
                    Remap("LeftTrigger", "Fire1");
                    break;
                case "RightHandOnly":
                    Remap("LeftStickX", "Horizontal");
                    Remap("LeftStickY", "Vertical");
                    Remap("RightTrigger", "Fire1");
                    break;
            }
        }
    }
}
