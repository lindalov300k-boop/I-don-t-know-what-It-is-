using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Input.EyeTracking
{
    // ═══════════════════════════════════════════════════════════════════════
    //  EYE TRACKING INPUT  — Tobii, Varjo, Eyeware Beam, WebGazer, SRanipal
    //
    //  Supports:
    //    • Gaze origin + direction per eye
    //    • Combined/cyclopean gaze ray
    //    • Gaze point on screen (pixels or NDC)
    //    • Pupil diameter and dilation (both eyes)
    //    • Blink detection (per eye and bilateral)
    //    • Fixation detection + dwell timer
    //    • Saccade detection
    //    • Smooth pursuit detection
    //    • Foveated rendering hint region
    //    • Calibration state
    //    • User presence (is anyone looking)
    //    • Head pose (from tracker if available)
    // ═══════════════════════════════════════════════════════════════════════

    public enum GazeEye { Left, Right, Combined }

    public enum GazeValidity { Valid, Invalid, Unknown }

    public enum FixationState { None, Dwell, Fixated, Saccade, SmoothPursuit }

    public struct EyeData
    {
        public Vector3       GazeOrigin;
        public Vector3       GazeDirection;
        public Vector2       ScreenPoint;     // screen pixels
        public Vector2       NDCPoint;        // -1..1
        public float         PupilDiameterMm;
        public float         Openness;        // 0=closed, 1=fully open
        public GazeValidity  Validity;
        public bool          IsBlink;
        public bool          IsSquinting;
    }

    public struct GazePoint2D
    {
        public Vector2  ScreenPos;
        public Vector2  NDCPos;
        public float    Confidence;  // 0-1
        public bool     IsValid;
    }

    public struct FixationData
    {
        public FixationState State;
        public Vector2       FixationCenter;  // screen coords
        public float         DwellTime;       // seconds in current fixation
        public float         DispersionRadius;
        public Vector2       SaccadeVelocity; // pixels/sec
    }

    public struct FoveationRegion
    {
        public Vector2 Center;      // NDC
        public float   InnerRadius; // full quality
        public float   OuterRadius; // degraded quality
    }

    public static class EyeTrackingInput
    {
        // ── State ─────────────────────────────────────────────────────────
        public static EyeData     LeftEye          { get; private set; }
        public static EyeData     RightEye         { get; private set; }
        public static EyeData     CombinedEye      { get; private set; }
        public static FixationData Fixation        { get; private set; }
        public static FoveationRegion FoveaHint    { get; private set; }
        public static bool         IsCalibrated    { get; private set; }
        public static bool         UserPresent      { get; private set; }
        public static float        UserDistance     { get; private set; } // meters

        // ── Dwell timer settings ──────────────────────────────────────────
        public static float DwellActivationTime { get; set; } = 1.5f;  // seconds
        public static float FixationRadius      { get; set; } = 50f;   // pixels

        // ── Dwell targets ─────────────────────────────────────────────────
        private static readonly Dictionary<int, float> _dwellTimers = new();

        // ── Injection ─────────────────────────────────────────────────────
        public static void InjectFrame(EyeData left, EyeData right, EyeData combined,
                                        bool calibrated, bool userPresent, float userDistM = 0.6f)
        {
            LeftEye    = left;
            RightEye   = right;
            CombinedEye = combined;
            IsCalibrated = calibrated;
            UserPresent  = userPresent;
            UserDistance = userDistM;

            // Auto-compute foveation hint from combined gaze
            FoveaHint = new FoveationRegion
            {
                Center      = combined.NDCPoint,
                InnerRadius = 0.1f,
                OuterRadius = 0.3f
            };
        }

        public static void UpdateFixation(FixationData fixation) => Fixation = fixation;

        // ── Helpers ───────────────────────────────────────────────────────

        public static bool IsBilateralBlink =>
            LeftEye.IsBlink && RightEye.IsBlink;

        public static bool IsWinking(GazeEye eye) =>
            eye == GazeEye.Left ? (LeftEye.IsBlink && !RightEye.IsBlink)
                                 : (RightEye.IsBlink && !LeftEye.IsBlink);

        public static float AveragePupilDiameter =>
            (LeftEye.PupilDiameterMm + RightEye.PupilDiameterMm) * 0.5f;

        /// <summary>True when user has dwelled on a region for the required time.</summary>
        public static bool IsDwelling(int targetId, Vector2 center, float radius, float dt)
        {
            if (!CombinedEye.IsValid || !UserPresent) return false;
            float dist = Vector2.Distance(CombinedEye.ScreenPoint, center);
            if (dist <= radius)
            {
                if (!_dwellTimers.TryGetValue(targetId, out float t)) t = 0f;
                t += dt;
                _dwellTimers[targetId] = t;
                return t >= DwellActivationTime;
            }
            _dwellTimers[targetId] = 0f;
            return false;
        }

        public static void ResetDwell(int targetId) => _dwellTimers.Remove(targetId);
        public static void ResetAllDwells() => _dwellTimers.Clear();

        /// <summary>Ray cast from gaze into 3D scene.</summary>
        public static (Vector3 origin, Vector3 dir) GetGazeRay(GazeEye eye = GazeEye.Combined)
        {
            var e = eye switch
            {
                GazeEye.Left  => LeftEye,
                GazeEye.Right => RightEye,
                _             => CombinedEye
            };
            return (e.GazeOrigin, e.GazeDirection.Normalized());
        }

        /// <summary>
        /// Returns gaze-weighted blend between two positions —
        /// useful for adaptive UI that shifts toward where user looks.
        /// </summary>
        public static Vector2 AttractToGaze(Vector2 position, float strength = 0.1f)
        {
            if (!UserPresent || !CombinedEye.IsValid) return position;
            return Vector2.Lerp(position, CombinedEye.ScreenPoint, strength);
        }
    }
}
