using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Input.AR
{
    // ═══════════════════════════════════════════════════════════════════════
    //  AR / MIXED REALITY INPUT
    //
    //  Covers:
    //    • Plane detection (horizontal, vertical, arbitrary)
    //    • Image marker tracking (QR, ArUco, custom target)
    //    • World anchor creation / retrieval
    //    • Feature points / point cloud
    //    • Light estimation (ambient intensity + color temp)
    //    • Camera-space pinch and gesture for ARCore/ARKit
    //    • Spatial mesh (LiDAR-style environment mesh)
    //    • Object detection / classification results
    //    • Depth map (ToF / stereo depth)
    //    • Face mesh (AR face filters, blend shapes)
    //    • Body pose (33-landmark skeleton via MediaPipe)
    // ═══════════════════════════════════════════════════════════════════════

    public enum ARPlaneType { HorizontalUp, HorizontalDown, Vertical, Arbitrary }
    public enum ARTrackingState { None, Limited, Tracking }

    // ─────────────────────────────────────────────────────────────────────
    //  AR PLANES
    // ─────────────────────────────────────────────────────────────────────
    public struct ARPlane
    {
        public string         Id;
        public Vector3        Center;
        public Vector3        Normal;
        public Vector2        Extents;    // half-size X/Z
        public ARPlaneType    Type;
        public ARTrackingState Tracking;
        public List<Vector2>  Boundary;  // 2D polygon in plane local space

        public bool Contains(Vector3 worldPoint)
        {
            // Rough box test
            Vector3 local = worldPoint - Center;
            return MathF.Abs(local.X) <= Extents.X && MathF.Abs(local.Z) <= Extents.Y;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  IMAGE MARKERS
    // ─────────────────────────────────────────────────────────────────────
    public struct ARImageMarker
    {
        public string         MarkerId;
        public string         ReferenceImageName;
        public Vector3        Position;
        public Quaternion     Rotation;
        public Vector2        PhysicalSizeMeters;
        public ARTrackingState Tracking;
        public float          TrackingScore; // 0-1
    }

    // ─────────────────────────────────────────────────────────────────────
    //  WORLD ANCHOR
    // ─────────────────────────────────────────────────────────────────────
    public class WorldAnchor
    {
        public string    Id       { get; }
        public Vector3   Position { get; set; }
        public Quaternion Rotation{ get; set; }
        public bool      IsPersisted { get; set; }
        public WorldAnchor(string id, Vector3 pos, Quaternion rot)
        { Id = id; Position = pos; Rotation = rot; }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  BODY POSE (MediaPipe 33-point)
    // ─────────────────────────────────────────────────────────────────────
    public enum BodyLandmark
    {
        Nose = 0, LeftEyeInner, LeftEye, LeftEyeOuter, RightEyeInner,
        RightEye, RightEyeOuter, LeftEar, RightEar, MouthLeft, MouthRight,
        LeftShoulder, RightShoulder, LeftElbow, RightElbow,
        LeftWrist, RightWrist, LeftPinky, RightPinky, LeftIndex,
        RightIndex, LeftThumb, RightThumb, LeftHip, RightHip,
        LeftKnee, RightKnee, LeftAnkle, RightAnkle,
        LeftHeel, RightHeel, LeftFootIndex, RightFootIndex,
        Count = 33
    }

    public struct BodyPose
    {
        public Vector3[] Landmarks;   // [BodyLandmark.Count] world-space
        public float[]   Visibility;  // [BodyLandmark.Count] 0-1
        public bool      IsDetected;

        public Vector3 GetLandmark(BodyLandmark l) =>
            IsDetected ? Landmarks[(int)l] : Vector3.Zero;

        // High-level derived gestures
        public bool IsHandsUp =>
            IsDetected &&
            Landmarks[(int)BodyLandmark.LeftWrist].Y  < Landmarks[(int)BodyLandmark.LeftShoulder].Y &&
            Landmarks[(int)BodyLandmark.RightWrist].Y < Landmarks[(int)BodyLandmark.RightShoulder].Y;

        public float JumpHeight =>
            IsDetected ? Math.Max(0f,
                (Landmarks[(int)BodyLandmark.LeftAnkle].Y +
                 Landmarks[(int)BodyLandmark.RightAnkle].Y) * 0.5f) : 0f;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  FACE MESH
    // ─────────────────────────────────────────────────────────────────────
    public struct FaceMesh
    {
        public Vector3[]  Vertices;  // 468 MediaPipe landmarks
        public bool       IsDetected;
        public float      HeadPitchDeg;
        public float      HeadYawDeg;
        public float      HeadRollDeg;

        // 52 Apple ARKit-compatible blend shapes
        public float[]    BlendShapes;

        public float GetBlendShape(int index) =>
            BlendShapes != null && index < BlendShapes.Length ? BlendShapes[index] : 0f;

        // Common helpers
        public float MouthOpen    => GetBlendShape(25);  // jawOpen
        public float LeftEyeBlink => GetBlendShape(0);
        public float RightEyeBlink=> GetBlendShape(7);
        public float SmileLeft    => GetBlendShape(44);
        public float SmileRight   => GetBlendShape(45);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  LIGHT ESTIMATION
    // ─────────────────────────────────────────────────────────────────────
    public struct ARLightEstimate
    {
        public float   AmbientIntensityLumens;
        public float   AmbientColorTemperatureK;
        public Vector3 PrimaryLightDirection;
        public Vector3 PrimaryLightColor;
        public float   PrimaryLightIntensity;
        public float[] SphericalHarmonics; // 9 SH coefficients per channel
    }

    // ─────────────────────────────────────────────────────────────────────
    //  AR DEPTH MAP
    // ─────────────────────────────────────────────────────────────────────
    public struct ARDepthMap
    {
        public float[]  DepthValues;  // meters, row-major
        public int      Width, Height;
        public bool     IsValid;

        public float SampleDepth(float u, float v) // u,v 0-1
        {
            if (!IsValid || DepthValues == null) return 0f;
            int x = (int)(u * (Width  - 1));
            int y = (int)(v * (Height - 1));
            return DepthValues[y * Width + x];
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNIFIED AR INPUT MANAGER
    // ─────────────────────────────────────────────────────────────────────
    public static class ARInput
    {
        private static readonly Dictionary<string, ARPlane>        _planes  = new();
        private static readonly Dictionary<string, ARImageMarker>  _markers = new();
        private static readonly Dictionary<string, WorldAnchor>    _anchors = new();

        public static ARTrackingState SessionTracking { get; private set; }
        public static ARLightEstimate LightEstimate   { get; private set; }
        public static ARDepthMap      DepthMap        { get; private set; }
        public static BodyPose        DetectedBody    { get; private set; }
        public static FaceMesh        DetectedFace    { get; private set; }
        public static bool            IsSupported     { get; private set; }

        // ── Planes ────────────────────────────────────────────────────────
        public static IEnumerable<ARPlane> Planes => _planes.Values;
        public static bool TryGetPlane(string id, out ARPlane plane) =>
            _planes.TryGetValue(id, out plane);

        public static void InjectPlane(ARPlane plane) => _planes[plane.Id] = plane;
        public static void RemovePlane(string id)     => _planes.Remove(id);

        // ── Markers ───────────────────────────────────────────────────────
        public static IEnumerable<ARImageMarker> Markers => _markers.Values;
        public static void InjectMarker(ARImageMarker m) => _markers[m.MarkerId] = m;
        public static void LoseMarker(string id) =>
        {
            if (_markers.TryGetValue(id, out var m))
            {
                var lost = m;
                lost.Tracking = ARTrackingState.None;
                _markers[id] = lost;
            }
        };

        // ── Anchors ───────────────────────────────────────────────────────
        public static WorldAnchor CreateAnchor(Vector3 pos, Quaternion rot)
        {
            var a = new WorldAnchor(Guid.NewGuid().ToString("N"), pos, rot);
            _anchors[a.Id] = a;
            return a;
        }
        public static bool TryGetAnchor(string id, out WorldAnchor anchor) =>
            _anchors.TryGetValue(id, out anchor!);
        public static void RemoveAnchor(string id) => _anchors.Remove(id);

        // ── Injection ─────────────────────────────────────────────────────
        public static void InjectSession(ARTrackingState state, bool supported = true)
        {
            SessionTracking = state;
            IsSupported     = supported;
        }
        public static void InjectLightEstimate(ARLightEstimate light)   => LightEstimate = light;
        public static void InjectDepthMap(ARDepthMap depth)             => DepthMap = depth;
        public static void InjectBodyPose(BodyPose pose)                => DetectedBody = pose;
        public static void InjectFaceMesh(FaceMesh face)                => DetectedFace = face;

        // ── Raycasting ────────────────────────────────────────────────────
        /// <summary>Finds the nearest AR plane hit by a screen-space ray.</summary>
        public static bool RaycastPlanes(Vector3 origin, Vector3 direction,
                                          out Vector3 hitPoint, out string planeId,
                                          ARPlaneType? filter = null)
        {
            hitPoint = Vector3.Zero;
            planeId  = "";
            float best = float.MaxValue;
            bool found = false;

            foreach (var (id, plane) in _planes)
            {
                if (filter.HasValue && plane.Type != filter.Value) continue;
                float denom = Vector3.Dot(plane.Normal, direction);
                if (MathF.Abs(denom) < 1e-6f) continue;
                float t = Vector3.Dot(plane.Center - origin, plane.Normal) / denom;
                if (t < 0f || t >= best) continue;
                Vector3 pt = origin + direction * t;
                if (!plane.Contains(pt)) continue;
                best    = t;
                hitPoint = pt;
                planeId  = id;
                found   = true;
            }
            return found;
        }
    }
}
