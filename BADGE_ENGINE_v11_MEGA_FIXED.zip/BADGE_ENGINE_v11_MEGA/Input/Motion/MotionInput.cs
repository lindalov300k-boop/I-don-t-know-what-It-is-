using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Input.Motion
{
    // ═══════════════════════════════════════════════════════════════════════
    //  MOTION / GYRO / IMU INPUT
    //
    //  Covers:
    //    • 3-axis Gyroscope (rad/s, deg/s)
    //    • 3-axis Accelerometer (m/s²)
    //    • 3-axis Magnetometer (μT)
    //    • Gravity vector (device orientation)
    //    • Absolute orientation quaternion (sensor fusion)
    //    • Linear acceleration (accel minus gravity)
    //    • Step counter (phone pedometer)
    //    • Shake detection
    //    • Tilt detection (left/right/up/down)
    //    • Nintendo Switch style IR camera (see IRCameraInput)
    //    • DualSense adaptive trigger resistance levels
    //
    //  Devices:
    //    Nintendo Switch Joy-Con (L + R), Pro Controller
    //    Sony DualSense / DualShock 4
    //    Xbox controllers (no gyro, but extension)
    //    iOS/Android phone sensors
    //    Steam Deck, ROG Ally, PC handhelds
    // ═══════════════════════════════════════════════════════════════════════

    public enum MotionDeviceType
    {
        Unknown, JoyConLeft, JoyConRight, SwitchPro, DualSense, DualShock4,
        MobilePhone, SteamController, SteamDeck, Generic
    }

    public enum ShakeAxis { Any, X, Y, Z }

    public struct IMUState
    {
        public int              DeviceIndex;
        public MotionDeviceType DeviceType;

        // Raw sensor data
        public Vector3   Gyroscope;          // rad/s
        public Vector3   Accelerometer;      // m/s²
        public Vector3   Magnetometer;       // μT
        public Vector3   Gravity;            // normalized gravity vector
        public Vector3   LinearAcceleration; // accel - gravity
        public Quaternion Orientation;        // fused orientation

        // Derived
        public float     Pitch => MathF.Asin(-2f * (Orientation.X * Orientation.Z - Orientation.W * Orientation.Y));
        public float     Yaw   => MathF.Atan2(2f * (Orientation.X * Orientation.W + Orientation.Y * Orientation.Z),
                                               1f - 2f * (Orientation.Z * Orientation.Z + Orientation.W * Orientation.W));
        public float     Roll  => MathF.Atan2(2f * (Orientation.X * Orientation.Y + Orientation.Z * Orientation.W),
                                               1f - 2f * (Orientation.Y * Orientation.Y + Orientation.Z * Orientation.Z));

        public float     PitchDeg => Pitch * MathHelper.RadiansToDegrees(1f);
        public float     YawDeg   => Yaw   * MathHelper.RadiansToDegrees(1f);
        public float     RollDeg  => Roll  * MathHelper.RadiansToDegrees(1f);

        public bool      IsValid;
        public long      TimestampUs; // microseconds since epoch
    }

    public struct AdaptiveTriggerState
    {
        public float    Resistance;      // 0-1 physical force required
        public float    EffectStart;     // 0-1 position where effect begins
        public float    EffectEnd;       // 0-1 position where effect ends
        public bool     IsVibrating;     // trigger haptic feedback
        public TriggerEffect Effect;
    }

    public enum TriggerEffect
    {
        Off, Uniform, Feedback, Weapon, Vibration, BowString, GallopeHorseStep
    }

    public static class MotionInput
    {
        public const int MAX_MOTION_DEVICES = 8;

        private static readonly IMUState[] _states     = new IMUState[MAX_MOTION_DEVICES];
        private static readonly IMUState[] _prevStates = new IMUState[MAX_MOTION_DEVICES];

        // DualSense adaptive triggers (per player)
        private static readonly AdaptiveTriggerState[] _leftTriggers  = new AdaptiveTriggerState[MAX_MOTION_DEVICES];
        private static readonly AdaptiveTriggerState[] _rightTriggers = new AdaptiveTriggerState[MAX_MOTION_DEVICES];

        // Shake detection
        private static readonly float[] _shakeAccum = new float[MAX_MOTION_DEVICES];
        public static float ShakeThreshold { get; set; } = 25f; // m/s²

        // Step counter
        private static readonly int[] _stepCount  = new int[MAX_MOTION_DEVICES];
        private static readonly float[]_stepAccum  = new float[MAX_MOTION_DEVICES];
        public static float StepThreshold { get; set; } = 12f;  // m/s²

        // ── Accessors ─────────────────────────────────────────────────────
        public static IMUState Get(int device = 0) =>
            device < MAX_MOTION_DEVICES ? _states[device] : default;

        // Joy-Con pair merged (average orientation, combined accel)
        public static IMUState GetMergedJoyCon()
        {
            IMUState l = default, r = default;
            for (int i = 0; i < MAX_MOTION_DEVICES; i++)
            {
                if (_states[i].DeviceType == MotionDeviceType.JoyConLeft)  l = _states[i];
                if (_states[i].DeviceType == MotionDeviceType.JoyConRight) r = _states[i];
            }
            if (!l.IsValid && !r.IsValid) return default;
            if (!l.IsValid) return r;
            if (!r.IsValid) return l;
            return new IMUState
            {
                IsValid         = true,
                Gyroscope       = (l.Gyroscope + r.Gyroscope) * 0.5f,
                Accelerometer   = (l.Accelerometer + r.Accelerometer) * 0.5f,
                Orientation     = Quaternion.Slerp(l.Orientation, r.Orientation, 0.5f),
                Gravity         = (l.Gravity + r.Gravity).Normalized(),
                DeviceType      = MotionDeviceType.JoyConRight
            };
        }

        // ── Injection ─────────────────────────────────────────────────────
        public static void InjectState(int device, IMUState state)
        {
            if (device < 0 || device >= MAX_MOTION_DEVICES) return;
            _prevStates[device] = _states[device];
            _states[device]     = state;

            // Shake detection
            float mag = state.LinearAcceleration.Length;
            _shakeAccum[device] = mag > ShakeThreshold ? _shakeAccum[device] + mag : 0f;

            // Step detection (vertical accel peak)
            float vert = MathF.Abs(state.LinearAcceleration.Y);
            if (vert > StepThreshold && _stepAccum[device] < StepThreshold)
                _stepCount[device]++;
            _stepAccum[device] = vert;
        }

        public static void SetAdaptiveTrigger(int device, bool left, AdaptiveTriggerState state)
        {
            if (device < 0 || device >= MAX_MOTION_DEVICES) return;
            if (left) _leftTriggers[device]  = state;
            else      _rightTriggers[device] = state;
        }

        public static AdaptiveTriggerState GetAdaptiveTrigger(int device, bool left) =>
            device < MAX_MOTION_DEVICES
                ? (left ? _leftTriggers[device] : _rightTriggers[device])
                : default;

        // ── High-level ────────────────────────────────────────────────────

        public static bool IsShaking(int device = 0)   => _shakeAccum[device] > ShakeThreshold * 3f;
        public static int  GetStepCount(int device = 0) => _stepCount[device];

        public static bool IsTiltingLeft(int device = 0, float threshold = 20f) =>
            _states[device].RollDeg < -threshold;
        public static bool IsTiltingRight(int device = 0, float threshold = 20f) =>
            _states[device].RollDeg > threshold;
        public static bool IsTiltingForward(int device = 0, float threshold = 20f) =>
            _states[device].PitchDeg < -threshold;
        public static bool IsTiltingBack(int device = 0, float threshold = 20f) =>
            _states[device].PitchDeg > threshold;

        /// <summary>Delta rotation between frames (useful for camera control).</summary>
        public static Vector3 GyroMouseDelta(int device = 0, float sensitivity = 1f)
        {
            if (!_states[device].IsValid) return Vector3.Zero;
            return _states[device].Gyroscope * sensitivity;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  IR CAMERA INPUT  (Nintendo Switch Joy-Con R IR sensor)
    // ─────────────────────────────────────────────────────────────────────
    public struct IRPoint
    {
        public Vector2 Position;   // 0-1 normalized in IR frame
        public float   Size;       // detected blob size
        public float   Intensity;  // 0-1 brightness
    }

    public static class IRCameraInput
    {
        public const int MAX_IR_POINTS = 4;
        private static readonly IRPoint[] _points = new IRPoint[MAX_IR_POINTS];
        private static int _count;

        public static int PointCount => _count;
        public static IRPoint GetPoint(int i) => i < _count ? _points[i] : default;

        public static void InjectFrame(IRPoint[] points, int count)
        {
            _count = Math.Min(count, MAX_IR_POINTS);
            for (int i = 0; i < _count; i++) _points[i] = points[i];
        }

        // Distance estimation (like Wii sensor bar)
        public static float EstimateDistance(float knownSeparationMeters = 0.2f)
        {
            if (_count < 2) return -1f;
            float pixelDist = Vector2.Distance(_points[0].Position, _points[1].Position);
            return knownSeparationMeters / (2f * MathF.Tan(MathF.PI / 8f * pixelDist));
        }
    }
}
