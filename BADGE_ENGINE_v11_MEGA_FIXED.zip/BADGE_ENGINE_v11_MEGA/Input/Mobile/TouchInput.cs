using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Input.Mobile;

// ═══════════════════════════════════════════════════════════════════════════
//  TOUCH INPUT  — multi-touch, gestures, time tracking
//
//  Works with:
//    • Touchscreen monitors   (Windows WM_POINTER → TouchProvider feeds this)
//    • Any touch surface      (call RegisterTouch() from your platform hook)
//    • Mouse fallback         (single-finger simulation via left-click drag)
//
//  Game API:
//    TouchInput.TouchCount          — how many fingers are down
//    TouchInput.GetTouch(0)         — first touch point
//    TouchInput.IsTap(0)            — was it a quick tap?
//    TouchInput.IsHold(0)           — finger held for > HoldThreshold?
//    TouchInput.DetectSwipe(0)      — swipe direction + speed
//    TouchInput.PinchDelta()        — two-finger pinch magnitude change
//    TouchInput.RotateDelta()       — two-finger rotation in degrees
//    TouchInput.TwoFingerPanDelta() — two-finger pan offset
// ═══════════════════════════════════════════════════════════════════════════
public static class TouchInput
{
    public const int   MAX_TOUCHES    = 10;
    public static float HoldThreshold { get; set; } = 0.5f;   // seconds before "hold" fires
    public static float TapMaxDist    { get; set; } = 22f;    // pixels
    public static float TapMaxTime    { get; set; } = 0.28f;  // seconds
    public static float SwipeMinDist  { get; set; } = 48f;    // pixels

    // ── Internal state ────────────────────────────────────────────────────
    private static readonly TouchPoint[] _points   = new TouchPoint[MAX_TOUCHES];
    private static int                   _count     = 0;
    private static float                 _dt        = 0f;

    // Per-frame gesture results (computed once per frame)
    private static readonly SwipeResult[]  _swipes  = new SwipeResult[MAX_TOUCHES];
    private static readonly TapResult[]    _taps    = new TapResult[MAX_TOUCHES];

    // ── Public read ───────────────────────────────────────────────────────
    public static int                   TouchCount  => _count;
    public static bool                  HasTouch    => _count > 0;
    public static TouchPoint            GetTouch(int i) => i < _count ? _points[i] : default;

    // ── Engine feed (call once per frame from InputSystem.Update) ─────────
    public static void BeginFrame(float deltaTime)
    {
        _dt = deltaTime;

        for (int i = _count - 1; i >= 0; i--)
        {
            ref var p = ref _points[i];
            p.DeltaPosition = Vector2.Zero;

            if (p.Phase == TouchPhase.Began)
                p.Phase = TouchPhase.Stationary;

            if (p.Phase is TouchPhase.Ended or TouchPhase.Cancelled)
            {
                // Compute final gesture before removing
                _swipes[i] = ComputeSwipe(ref p);
                _taps[i]   = ComputeTap(ref p);
                ShiftLeft(i);
                _count--;
            }
            else
            {
                p.Time += deltaTime;
                _swipes[i] = default;
                _taps[i]   = default;
            }
        }
    }

    // ── OS event feed (called by TouchProvider) ───────────────────────────
    public static void RegisterTouch(int fingerId, TouchPhase phase, Vector2 position, float pressure = 1f)
    {
        for (int i = 0; i < _count; i++)
        {
            if (_points[i].FingerId != fingerId) continue;
            ref var p = ref _points[i];
            p.DeltaPosition = position - p.Position;
            p.Position      = position;
            p.Phase         = phase;
            p.Pressure      = pressure;
            return;
        }

        if (_count < MAX_TOUCHES && phase == TouchPhase.Began)
        {
            _points[_count++] = new TouchPoint
            {
                FingerId      = fingerId,
                Position      = position,
                StartPosition = position,
                DeltaPosition = Vector2.Zero,
                Phase         = TouchPhase.Began,
                Pressure      = pressure,
                Time          = 0f,
            };
        }
    }

    // ── Tap detection ──────────────────────────────────────────────────────
    /// <summary>True the frame a finger lifts after a quick short-distance press.</summary>
    public static bool IsTap(int index)
    {
        if (index >= _count) return false;
        return ComputeTap(ref _points[index]).IsTap;
    }

    // ── Hold detection ─────────────────────────────────────────────────────
    /// <summary>True while a finger has been held still past HoldThreshold seconds.</summary>
    public static bool IsHold(int index)
    {
        if (index >= _count) return false;
        ref var p = ref _points[index];
        return p.Time >= HoldThreshold
            && (p.Position - p.StartPosition).Length < TapMaxDist
            && p.Phase != TouchPhase.Ended;
    }

    // ── Swipe detection ────────────────────────────────────────────────────
    /// <summary>Returns swipe direction the frame a touch ends (if it was a swipe).</summary>
    public static SwipeResult DetectSwipe(int index)
    {
        if (index >= _count) return default;
        return ComputeSwipe(ref _points[index]);
    }

    /// <summary>Check for swipe in a specific direction this frame.</summary>
    public static bool IsSwipe(SwipeDirection dir, int index = 0)
        => DetectSwipe(index).Direction == dir;

    // ── Two-finger gestures ────────────────────────────────────────────────
    /// <summary>
    /// Change in distance between two fingers this frame.
    /// Positive = fingers spreading apart (zoom in).
    /// Negative = fingers pinching together (zoom out).
    /// Returns 0 if fewer than 2 touches.
    /// </summary>
    public static float PinchDelta()
    {
        if (_count < 2) return 0f;
        float cur  = (_points[0].Position - _points[1].Position).Length;
        float prev = ((_points[0].Position - _points[0].DeltaPosition)
                    - (_points[1].Position - _points[1].DeltaPosition)).Length;
        return cur - prev;
    }

    /// <summary>
    /// Two-finger rotation delta in degrees this frame.
    /// Positive = clockwise, Negative = counter-clockwise.
    /// Returns 0 if fewer than 2 touches.
    /// </summary>
    public static float RotateDelta()
    {
        if (_count < 2) return 0f;
        var cur  = _points[1].Position - _points[0].Position;
        var prev = (_points[1].Position - _points[1].DeltaPosition)
                 - (_points[0].Position - _points[0].DeltaPosition);
        float curAngle  = MathF.Atan2(cur.Y,  cur.X);
        float prevAngle = MathF.Atan2(prev.Y, prev.X);
        float delta = (curAngle - prevAngle) * (180f / MathF.PI);
        // Wrap to -180..180
        while (delta >  180f) delta -= 360f;
        while (delta < -180f) delta += 360f;
        return delta;
    }

    /// <summary>
    /// Average movement of two fingers this frame — use for panning/camera orbit.
    /// Returns Vector2.Zero if fewer than 2 touches.
    /// </summary>
    public static Vector2 TwoFingerPanDelta()
    {
        if (_count < 2) return Vector2.Zero;
        return (_points[0].DeltaPosition + _points[1].DeltaPosition) * 0.5f;
    }

    /// <summary>Midpoint between finger 0 and finger 1 (in screen pixels).</summary>
    public static Vector2 PinchCenter()
    {
        if (_count < 2) return _count > 0 ? _points[0].Position : Vector2.Zero;
        return (_points[0].Position + _points[1].Position) * 0.5f;
    }

    // ── Axis helpers (for InputSystem integration) ─────────────────────────
    /// <summary>
    /// Normalized drag direction of touch 0 as a 2D axis (-1..1 each).
    /// Useful for driving Horizontal/Vertical axes from a swipe.
    /// </summary>
    public static Vector2 DragAxis(int index = 0, float scale = 0.01f)
    {
        if (index >= _count || _points[index].Phase == TouchPhase.Began) return Vector2.Zero;
        var delta = _points[index].DeltaPosition * scale;
        return new Vector2(
            Math.Clamp(delta.X, -1f, 1f),
            Math.Clamp(delta.Y, -1f, 1f));
    }

    // ── Internal helpers ───────────────────────────────────────────────────
    private static SwipeResult ComputeSwipe(ref TouchPoint p)
    {
        if (p.Phase != TouchPhase.Ended) return default;
        var delta = p.Position - p.StartPosition;
        float dist = delta.Length;
        if (dist < SwipeMinDist) return default;
        bool horiz = MathF.Abs(delta.X) > MathF.Abs(delta.Y);
        float speed = dist / MathF.Max(p.Time, 0.001f);   // pixels/sec
        SwipeDirection dir = horiz
            ? (delta.X > 0 ? SwipeDirection.Right : SwipeDirection.Left)
            : (delta.Y > 0 ? SwipeDirection.Down  : SwipeDirection.Up);
        return new SwipeResult(dir, dist, speed);
    }

    private static TapResult ComputeTap(ref TouchPoint p)
    {
        if (p.Phase != TouchPhase.Ended) return default;
        bool isTap = (p.Position - p.StartPosition).Length < TapMaxDist
                   && p.Time < TapMaxTime;
        return new TapResult(isTap, p.Position);
    }

    private static void ShiftLeft(int from)
    {
        for (int i = from; i < _count - 1; i++) _points[i] = _points[i + 1];
    }

    // ── Debug info ─────────────────────────────────────────────────────────
    public static string DebugString()
    {
        var sb = new System.Text.StringBuilder();
        sb.Append($"Touches: {_count}");
        for (int i = 0; i < _count; i++)
            sb.Append($"  [{i}] {_points[i].Phase} ({_points[i].Position.X:F0},{_points[i].Position.Y:F0}) t={_points[i].Time:F2}s");
        return sb.ToString();
    }
}

// ── Data types ────────────────────────────────────────────────────────────
public struct TouchPoint
{
    public int        FingerId;
    public Vector2    Position;
    public Vector2    StartPosition;
    public Vector2    DeltaPosition;
    public TouchPhase Phase;
    public float      Time;       // seconds since touch began
    public float      Pressure;  // 0..1 (1 if hardware doesn't report pressure)
}

public enum TouchPhase     { Began, Stationary, Moved, Ended, Cancelled }
public enum SwipeDirection { None, Left, Right, Up, Down }

public readonly struct SwipeResult
{
    public SwipeDirection Direction { get; }
    public float          Distance  { get; }  // pixels
    public float          Speed     { get; }  // pixels/sec
    public bool           IsSwipe   => Direction != SwipeDirection.None;

    public SwipeResult(SwipeDirection dir, float dist, float speed = 0f)
    { Direction = dir; Distance = dist; Speed = speed; }
}

public readonly struct TapResult
{
    public bool    IsTap    { get; }
    public Vector2 Position { get; }
    public TapResult(bool isTap, Vector2 pos) { IsTap = isTap; Position = pos; }
}
