using System;
using System.Runtime.InteropServices;
using OpenTK.Mathematics;

namespace BADGE.Input.Mobile;

// ═══════════════════════════════════════════════════════════════════════════
//  TOUCH PROVIDER — OS-level touch event receiver
//
//  Connects the OS touch APIs to TouchInput.RegisterTouch().
//
//  Platform support:
//    Windows 8+   WM_POINTER messages (all touchscreen monitors)
//    Linux/X11    XInput2 touch events via P/Invoke
//    macOS        NSTouch via ObjC runtime
//    Fallback     Mouse-as-single-touch (works everywhere, single finger only)
//
//  Usage (call once during engine init, pass the native HWND):
//    TouchProvider.Initialize(nativeWindowHandle);
//    TouchProvider.EnableMouseFallback(true);  // for non-touch environments
//
//  Each frame:
//    TouchProvider.PollEvents();   // pumps any queued native touch messages
// ═══════════════════════════════════════════════════════════════════════════
public static class TouchProvider
{
    public static bool IsInitialized  { get; private set; }
    public static bool TouchAvailable { get; private set; }
    public static TouchPlatform Platform { get; private set; } = TouchPlatform.None;

    // Mouse-as-touch fallback state
    private static bool    _mouseFallback      = true;
    private static bool    _mouseWasDown       = false;
    private static Vector2 _lastMousePos       = Vector2.Zero;
    private static Func<Vector2>? _getMousePos;
    private static Func<bool>?    _getMouseDown;

    // Windows native hook
    private static IntPtr _hwnd = IntPtr.Zero;
    private static WndProcDelegate? _wndProcDelegate;
    private static IntPtr _origWndProc = IntPtr.Zero;

    // ── Init ──────────────────────────────────────────────────────────────
    /// <summary>
    /// Initialize touch input for the given native window handle.
    /// Call right after the OpenTK window is created.
    /// </summary>
    /// <param name="hwnd">Native window handle (IntPtr.Zero to skip native hooks).</param>
    /// <param name="getMousePos">Delegate that returns current mouse position in screen pixels.</param>
    /// <param name="getMouseDown">Delegate that returns whether left mouse button is held.</param>
    public static void Initialize(
        IntPtr hwnd,
        Func<Vector2>? getMousePos  = null,
        Func<bool>?    getMouseDown = null)
    {
        _getMousePos  = getMousePos;
        _getMouseDown = getMouseDown;

        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) && hwnd != IntPtr.Zero)
        {
            InitWindows(hwnd);
        }
        else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
        {
            InitLinux();
        }
        else
        {
            Platform = TouchPlatform.MouseFallback;
            Console.WriteLine("[TouchProvider] Platform: mouse fallback (no native touch)");
        }

        if (!TouchAvailable)
        {
            Platform = TouchPlatform.MouseFallback;
            Console.WriteLine("[TouchProvider] Touch hardware not available — mouse fallback active.");
        }

        IsInitialized = true;
    }

    /// <summary>Enable or disable the mouse-as-single-touch fallback.</summary>
    public static void EnableMouseFallback(bool enable) => _mouseFallback = enable;

    // ── Per-frame poll ────────────────────────────────────────────────────
    /// <summary>
    /// Call once per frame before TouchInput.BeginFrame().
    /// Pumps any queued native events and drives the mouse fallback.
    /// </summary>
    public static void PollEvents()
    {
        if (!IsInitialized) return;

        // Native WndProc already feeds touch events via the hook — nothing to pump here
        // for Windows. On Linux we'd drain the XInput2 queue here.

        // Mouse fallback: simulate finger-0 from left mouse button
        if (_mouseFallback && _getMousePos != null && _getMouseDown != null)
        {
            bool  isDown   = _getMouseDown();
            var   mousePos = _getMousePos();

            if (isDown && !_mouseWasDown)
            {
                TouchInput.RegisterTouch(999, TouchPhase.Began, mousePos);
                _lastMousePos = mousePos;
            }
            else if (isDown && _mouseWasDown)
            {
                if (mousePos != _lastMousePos)
                {
                    TouchInput.RegisterTouch(999, TouchPhase.Moved, mousePos);
                    _lastMousePos = mousePos;
                }
                else
                {
                    TouchInput.RegisterTouch(999, TouchPhase.Stationary, mousePos);
                }
            }
            else if (!isDown && _mouseWasDown)
            {
                TouchInput.RegisterTouch(999, TouchPhase.Ended, _lastMousePos);
            }

            _mouseWasDown = isDown;
        }
    }

    // ── Windows WM_POINTER implementation ─────────────────────────────────
#if WINDOWS || true   // always compile — guarded at runtime by OS check
    private static void InitWindows(IntPtr hwnd)
    {
        _hwnd = hwnd;
        try
        {
            // RegisterTouchWindow enables WM_TOUCH (legacy) on the HWND
            if (RegisterTouchWindow(hwnd, 0))
            {
                // Subclass the window to intercept WM_TOUCH and WM_POINTER
                _wndProcDelegate = WndProc;
                _origWndProc = SetWindowLongPtr(hwnd, GWLP_WNDPROC,
                    Marshal.GetFunctionPointerForDelegate(_wndProcDelegate));

                TouchAvailable = true;
                Platform       = TouchPlatform.WindowsPointer;
                Console.WriteLine("[TouchProvider] Windows WM_TOUCH/WM_POINTER registered.");
            }
            else
            {
                Console.WriteLine("[TouchProvider] RegisterTouchWindow failed (touchscreen may not be present).");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[TouchProvider] Windows init error: {ex.Message}");
        }
    }

    private delegate IntPtr WndProcDelegate(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

    private static IntPtr WndProc(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam)
    {
        const uint WM_TOUCH   = 0x0240;
        const uint WM_POINTER = 0x0245;
        const uint WM_POINTERDOWN   = 0x0246;
        const uint WM_POINTERUP     = 0x0247;
        const uint WM_POINTERUPDATE = 0x0245;

        if (msg == WM_TOUCH)
        {
            HandleWmTouch(wParam, lParam);
            CloseTouchInputHandle(lParam);
            return IntPtr.Zero;
        }

        if (msg is WM_POINTERDOWN or WM_POINTERUP or WM_POINTERUPDATE)
        {
            HandleWmPointer(msg, wParam, lParam);
        }

        return CallWindowProc(_origWndProc, hWnd, msg, wParam, lParam);
    }

    private static void HandleWmTouch(IntPtr wParam, IntPtr lParam)
    {
        int count = wParam.ToInt32() & 0xFFFF;
        var inputs = new TOUCHINPUT[count];
        if (!GetTouchInputInfo(lParam, count, inputs, Marshal.SizeOf<TOUCHINPUT>())) return;

        foreach (var ti in inputs)
        {
            // TOUCHINPUT coordinates are in hundredths of a pixel
            var screenPos = new Vector2(ti.x / 100f, ti.y / 100f);
            // Convert screen → client coords
            var pt = new POINT { x = (int)(ti.x / 100), y = (int)(ti.y / 100) };
            ScreenToClient(_hwnd, ref pt);
            var clientPos = new Vector2(pt.x, pt.y);

            TouchPhase phase;
            if ((ti.dwFlags & TOUCHEVENTF_DOWN) != 0)   phase = TouchPhase.Began;
            else if ((ti.dwFlags & TOUCHEVENTF_UP) != 0) phase = TouchPhase.Ended;
            else                                          phase = TouchPhase.Moved;

            TouchInput.RegisterTouch((int)ti.dwID, phase, clientPos);
        }
    }

    private static void HandleWmPointer(uint msg, IntPtr wParam, IntPtr lParam)
    {
        const uint WM_POINTERDOWN   = 0x0246;
        const uint WM_POINTERUP     = 0x0247;

        int pointerId = wParam.ToInt32() & 0xFFFF;
        int x = lParam.ToInt32() & 0xFFFF;
        int y = (lParam.ToInt32() >> 16) & 0xFFFF;

        var pt = new POINT { x = x, y = y };
        ScreenToClient(_hwnd, ref pt);
        var pos = new Vector2(pt.x, pt.y);

        TouchPhase phase = msg switch
        {
            WM_POINTERDOWN => TouchPhase.Began,
            WM_POINTERUP   => TouchPhase.Ended,
            _              => TouchPhase.Moved,
        };

        // Only register pointer-type touches (not mouse/pen)
        if (GetPointerType(pointerId, out uint ptrType) && ptrType == PT_TOUCH)
            TouchInput.RegisterTouch(pointerId, phase, pos);
    }

    // ── P/Invoke declarations ──────────────────────────────────────────────
    private const int  GWLP_WNDPROC  = -4;
    private const uint TOUCHEVENTF_DOWN = 0x0002;
    private const uint TOUCHEVENTF_UP   = 0x0004;
    private const uint PT_TOUCH         = 2;

    [StructLayout(LayoutKind.Sequential)]
    private struct TOUCHINPUT
    {
        public int  x, y;
        public IntPtr hSource;
        public uint dwID, dwFlags, dwMask, dwTime;
        public IntPtr dwExtraInfo;
        public uint cxContact, cyContact;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct POINT { public int x, y; }

    [DllImport("user32.dll")] private static extern bool RegisterTouchWindow(IntPtr hWnd, uint ulFlags);
    [DllImport("user32.dll")] private static extern bool GetTouchInputInfo(IntPtr hTouchInput, int cInputs, [Out] TOUCHINPUT[] pInputs, int cbSize);
    [DllImport("user32.dll")] private static extern void CloseTouchInputHandle(IntPtr lParam);
    [DllImport("user32.dll")] private static extern bool ScreenToClient(IntPtr hWnd, ref POINT lpPoint);
    [DllImport("user32.dll")] private static extern bool GetPointerType(int pointerId, out uint pointerType);
    [DllImport("user32.dll")] private static extern IntPtr SetWindowLongPtr(IntPtr hWnd, int nIndex, IntPtr dwNewLong);
    [DllImport("user32.dll")] private static extern IntPtr CallWindowProc(IntPtr lpPrevWndFunc, IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);
#endif

    // ── Linux stub ────────────────────────────────────────────────────────
    private static void InitLinux()
    {
        // XInput2 multi-touch is possible via libXi P/Invoke but complex.
        // Most Linux touchscreen monitors map touch to mouse events (evdev),
        // so the mouse fallback already covers single-touch.
        // Multi-touch via XInput2: left as a future platform extension.
        Console.WriteLine("[TouchProvider] Linux: mouse fallback (XInput2 multi-touch: future).");
        Platform = TouchPlatform.MouseFallback;
    }
}

public enum TouchPlatform { None, WindowsPointer, LinuxXInput2, MacOSTouch, MouseFallback }


// ── Layout mode enum (used by EditorWindow.SetTouchOverlay) ───────────────
public enum TouchLayoutMode { TwoStick, DPad, SwipeOnly }
