using System;
using System.Collections.Generic;
using ImGuiNET;
using OpenTK.Mathematics;
using System.Numerics;

namespace BADGE.Input.Mobile;

// ═══════════════════════════════════════════════════════════════════════════
//  TOUCH INPUT RENDERER
//
//  Draws virtual controls over the game view using ImGui's DrawList.
//  Zero UI widgets — everything is custom-drawn primitives so it works
//  in both editor "game view" and standalone builds.
//
//  Usage:
//    // In your render loop, after rendering the game:
//    TouchInputRenderer.BeginOverlay();
//    TouchInputRenderer.DrawLayout(layout);   // draws all controls
//    TouchInputRenderer.DrawDebugTouches();   // optional: show touch points
//    TouchInputRenderer.EndOverlay();
// ═══════════════════════════════════════════════════════════════════════════
public static class TouchInputRenderer
{
    // Visual style
    public static float TrackAlpha   { get; set; } = 0.25f;
    public static float KnobAlpha    { get; set; } = 0.60f;
    public static float ButtonAlpha  { get; set; } = 0.45f;
    public static float ActiveBoost  { get; set; } = 0.30f;
    public static bool  ShowLabels   { get; set; } = true;
    public static bool  ShowDebug    { get; set; } = false;

    private static System.Numerics.Vector4 _trackColor  = new(0.6f, 0.7f, 1.0f, 1f);
    private static System.Numerics.Vector4 _knobColor   = new(0.8f, 0.9f, 1.0f, 1f);
    private static System.Numerics.Vector4 _btnColor    = new(0.7f, 0.5f, 1.0f, 1f);
    private static System.Numerics.Vector4 _btnAColor   = new(1.0f, 0.7f, 0.3f, 1f);  // A button
    private static System.Numerics.Vector4 _touchDot    = new(1.0f, 0.4f, 0.4f, 0.8f);

    private static ImDrawListPtr _dl;
    private static bool _inOverlay;

    // ── Begin / End ───────────────────────────────────────────────────────
    public static void BeginOverlay()
    {
        // Full-screen transparent ImGui window so we can use the draw list
        var viewport = ImGui.GetMainViewport();
        ImGui.SetNextWindowPos(viewport.Pos);
        ImGui.SetNextWindowSize(viewport.Size);
        ImGui.SetNextWindowBgAlpha(0f);
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, System.Numerics.Vector2.Zero);
        ImGui.PushStyleVar(ImGuiStyleVar.WindowBorderSize, 0f);
        const ImGuiWindowFlags flags =
            ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoResize |
            ImGuiWindowFlags.NoMove     | ImGuiWindowFlags.NoScrollbar |
            ImGuiWindowFlags.NoInputs   | ImGuiWindowFlags.NoNav |
            ImGuiWindowFlags.NoDecoration | ImGuiWindowFlags.NoBringToFrontOnFocus;

        ImGui.Begin("##touch_overlay", flags);
        _dl = ImGui.GetWindowDrawList();
        _inOverlay = true;
    }

    public static void EndOverlay()
    {
        if (!_inOverlay) return;
        ImGui.End();
        ImGui.PopStyleVar(2);
        _inOverlay = false;
    }

    // ── Draw full layout ──────────────────────────────────────────────────
    public static void DrawLayout(TouchControlLayout layout)
    {
        if (!_inOverlay) return;
        if (layout.LeftStick  != null) DrawJoystick(layout.LeftStick);
        if (layout.RightStick != null) DrawJoystick(layout.RightStick);
        if (layout.DPad       != null) DrawDPad(layout.DPad);
        foreach (var btn in layout.Buttons) DrawButton(btn);
    }

    // ── Individual drawers ────────────────────────────────────────────────
    public static void DrawJoystick(VirtualJoystick stick)
    {
        if (!_inOverlay) return;
        var center = ToImVec(stick.IsActive ? stick.KnobPosition - (stick.KnobPosition - ToVec2(stick.Center)) : stick.Center);
        var origin = ToImVec(stick.Center);
        if (stick.Floating && stick.IsActive) origin = ToImVec(stick.Center);  // keep base visible

        // Outer ring
        uint trackCol = AlphaColor(_trackColor, TrackAlpha + (stick.IsActive ? ActiveBoost * 0.4f : 0f));
        _dl.AddCircle(origin, stick.Radius, trackCol, 48, 2.5f);

        // Inner fill
        uint fillCol = AlphaColor(_trackColor, TrackAlpha * 0.3f);
        _dl.AddCircleFilled(origin, stick.Radius, fillCol, 48);

        // Knob
        uint knobCol = AlphaColor(_knobColor, KnobAlpha + (stick.IsActive ? ActiveBoost : 0f));
        var  knobPos = ToImVec(stick.KnobPosition);
        _dl.AddCircleFilled(knobPos, stick.KnobRadius, knobCol, 32);

        // Knob highlight
        uint hiCol = AlphaColor(new System.Numerics.Vector4(1,1,1,1), 0.25f);
        _dl.AddCircleFilled(
            new System.Numerics.Vector2(knobPos.X - stick.KnobRadius*0.2f, knobPos.Y - stick.KnobRadius*0.25f),
            stick.KnobRadius * 0.45f, hiCol, 16);
    }

    public static void DrawButton(VirtualButton btn)
    {
        if (!_inOverlay) return;
        var pos   = ToImVec(btn.Center);
        bool active = btn.IsDown;

        // Pick color by label
        var baseColor = btn.Label is "A" ? _btnAColor : _btnColor;
        uint fillCol = AlphaColor(baseColor, active ? ButtonAlpha + ActiveBoost : ButtonAlpha * 0.5f);
        uint rimCol  = AlphaColor(baseColor, active ? 0.9f : 0.5f);

        _dl.AddCircleFilled(pos, btn.Radius, fillCol, 32);
        _dl.AddCircle(pos, btn.Radius, rimCol, 32, 2f);

        if (ShowLabels && !string.IsNullOrEmpty(btn.Label))
        {
            uint textCol = AlphaColor(new System.Numerics.Vector4(1,1,1,1), active ? 1f : 0.7f);
            var textSize = ImGui.CalcTextSize(btn.Label);
            _dl.AddText(
                new System.Numerics.Vector2(pos.X - textSize.X * 0.5f, pos.Y - textSize.Y * 0.5f),
                textCol, btn.Label);
        }
    }

    public static void DrawDPad(VirtualDPad dpad)
    {
        if (!_inOverlay) return;
        var c    = ToImVec(dpad.Center);
        float s  = dpad.Size * 0.38f;  // arm length
        float aw = dpad.Size * 0.28f;  // arm width

        DrawDPadArm(c, new System.Numerics.Vector2(0,-1), s, aw, dpad.Up);
        DrawDPadArm(c, new System.Numerics.Vector2(0, 1), s, aw, dpad.Down);
        DrawDPadArm(c, new System.Numerics.Vector2(-1,0), s, aw, dpad.Left);
        DrawDPadArm(c, new System.Numerics.Vector2( 1,0), s, aw, dpad.Right);

        // Center disc
        uint cCol = AlphaColor(_trackColor, TrackAlpha * 0.8f);
        _dl.AddCircleFilled(c, aw * 0.6f, cCol, 16);
    }

    private static void DrawDPadArm(System.Numerics.Vector2 center, System.Numerics.Vector2 dir,
                                     float len, float width, bool active)
    {
        uint col = AlphaColor(_trackColor, active ? ButtonAlpha + ActiveBoost : ButtonAlpha * 0.5f);
        uint rim = AlphaColor(_trackColor, active ? 0.85f : 0.4f);

        var perp = new System.Numerics.Vector2(-dir.Y, dir.X) * (width * 0.5f);
        var tip  = center + dir * len;
        var p0   = center + perp;
        var p1   = center - perp;
        var p2   = tip    - perp;
        var p3   = tip    + perp;

        _dl.AddQuadFilled(p0, p1, p2, p3, col);
        _dl.AddQuad(p0, p1, p2, p3, rim, 1.5f);

        // Arrow
        if (ShowLabels)
        {
            float hs = width * 0.25f;
            var a0 = tip + dir * hs;
            var a1 = tip - dir * hs + perp * 0.8f;
            var a2 = tip - dir * hs - perp * 0.8f;
            uint arrowCol = AlphaColor(new System.Numerics.Vector4(1,1,1,1), active ? 0.9f : 0.4f);
            _dl.AddTriangleFilled(a0, a1, a2, arrowCol);
        }
    }

    // ── Debug touch visualiser ────────────────────────────────────────────
    public static void DrawDebugTouches()
    {
        if (!_inOverlay || !ShowDebug) return;
        for (int i = 0; i < TouchInput.TouchCount; i++)
        {
            var t   = TouchInput.GetTouch(i);
            var pos = ToImVec(t.Position);
            uint col = AlphaColor(_touchDot, 0.85f);
            _dl.AddCircle(pos, 28f, col, 32, 2f);
            _dl.AddCircleFilled(pos, 8f, col, 16);

            // Trail from start
            if ((t.Position - t.StartPosition).Length > 5f)
            {
                uint trailCol = AlphaColor(_touchDot, 0.3f);
                _dl.AddLine(ToImVec(t.StartPosition), pos, trailCol, 2f);
            }

            // Finger ID label
            string label = $"F{t.FingerId}  {t.Phase}  t={t.Time:F1}s";
            _dl.AddText(new System.Numerics.Vector2(pos.X + 30f, pos.Y - 8f),
                AlphaColor(new System.Numerics.Vector4(1,1,0.5f,1), 0.9f), label);
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    private static System.Numerics.Vector2 ToImVec(OpenTK.Mathematics.Vector2 v)
        => new(v.X, v.Y);

    private static OpenTK.Mathematics.Vector2 ToVec2(OpenTK.Mathematics.Vector2 v) => v;

    private static uint AlphaColor(System.Numerics.Vector4 c, float alpha)
    {
        alpha = Math.Clamp(alpha, 0f, 1f);
        return ImGui.ColorConvertFloat4ToU32(new System.Numerics.Vector4(c.X, c.Y, c.Z, c.W * alpha));
    }
}
