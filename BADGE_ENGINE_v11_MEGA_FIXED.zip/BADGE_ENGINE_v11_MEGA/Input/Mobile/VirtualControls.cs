using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Input.Mobile;

// ═══════════════════════════════════════════════════════════════════════════
//  VIRTUAL CONTROLS — on-screen joystick, buttons, d-pad, slider
//
//  For touchscreen monitor games. Renders with ImGui.
//  Game code just reads .Value or .IsDown — no touch logic needed.
//
//  Usage:
//    // Create once
//    var stick  = new VirtualJoystick(new Vector2(120, screenH - 120));
//    var jumpBtn = new VirtualButton(new Vector2(screenW - 100, screenH - 120), "Jump");
//    var dpad   = new VirtualDPad(new Vector2(130, screenH - 130));
//
//    // Update every frame
//    stick.Update();  jumpBtn.Update();  dpad.Update();
//
//    // Read values
//    float h = stick.Horizontal;
//    float v = stick.Vertical;
//    if (jumpBtn.WasPressed) player.Jump();
//    if (dpad.Left) player.MoveLeft();
// ═══════════════════════════════════════════════════════════════════════════

// ── VIRTUAL JOYSTICK ──────────────────────────────────────────────────────
/// <summary>Analogue thumbstick drawn on-screen. Supports floating mode (follows initial touch).</summary>
public class VirtualJoystick
{
    public Vector2 Center      { get; set; }
    public float   Radius      { get; set; } = 80f;
    public float   DeadZone    { get; set; } = 0.12f;
    public bool    Floating    { get; set; } = true;   // follow first touch
    public Vector2 Value       { get; private set; }   // -1..1 normalised
    public bool    IsActive    { get; private set; }

    public float   Horizontal  => Value.X;
    public float   Vertical    => -Value.Y;  // screen Y is inverted vs game Y
    public Vector3 AsVector3XZ => new(Value.X, 0f, -Value.Y);

    // Rendering hints
    public Vector2 KnobPosition { get; private set; }
    public float   KnobRadius   => Radius * 0.38f;

    private int     _touchId      = -1;
    private Vector2 _activeCenter;

    public VirtualJoystick(Vector2 center, float radius = 80f, bool floating = true)
    { Center = center; Radius = radius; Floating = floating; _activeCenter = center; }

    public void Update()
    {
        Value       = Vector2.Zero;
        IsActive    = false;
        KnobPosition = _activeCenter;

        for (int i = 0; i < TouchInput.TouchCount; i++)
        {
            var t = TouchInput.GetTouch(i);

            // Claim a new touch
            if (_touchId < 0 && t.Phase == TouchPhase.Began)
            {
                bool inZone = Floating || (t.Position - Center).Length <= Radius * 1.6f;
                if (!inZone) continue;
                _touchId = t.FingerId;
                _activeCenter = Floating ? t.Position : Center;
            }

            if (t.FingerId != _touchId) continue;

            // Release
            if (t.Phase is TouchPhase.Ended or TouchPhase.Cancelled)
            { _touchId = -1; _activeCenter = Center; return; }

            // Compute normalised axis
            var delta = t.Position - _activeCenter;
            if (delta.Length > Radius) delta = delta.Normalized() * Radius;

            KnobPosition = _activeCenter + delta;

            var raw = delta / Radius;
            float mag = raw.Length;
            if (mag < DeadZone) raw = Vector2.Zero;
            else raw = raw.Normalized() * ((mag - DeadZone) / (1f - DeadZone));

            Value    = raw;
            IsActive = true;
        }
    }
}

// ── VIRTUAL BUTTON ─────────────────────────────────────────────────────────
/// <summary>On-screen tap button. Circular hitzone.</summary>
public class VirtualButton
{
    public Vector2 Center     { get; set; }
    public float   Radius     { get; set; } = 50f;
    public string  Label      { get; set; }
    public bool    IsDown     { get; private set; }
    public bool    WasPressed { get; private set; }  // true for ONE frame on press
    public bool    WasReleased{ get; private set; }  // true for ONE frame on release

    private bool _prevDown;

    public VirtualButton(Vector2 center, string label = "A", float radius = 50f)
    { Center = center; Label = label; Radius = radius; }

    public void Update()
    {
        _prevDown  = IsDown;
        IsDown     = false;

        for (int i = 0; i < TouchInput.TouchCount; i++)
        {
            var t = TouchInput.GetTouch(i);
            if (t.Phase is TouchPhase.Ended or TouchPhase.Cancelled) continue;
            if ((t.Position - Center).Length <= Radius) { IsDown = true; break; }
        }

        WasPressed  =  IsDown && !_prevDown;
        WasReleased = !IsDown &&  _prevDown;
    }
}

// ── VIRTUAL D-PAD ──────────────────────────────────────────────────────────
/// <summary>4-direction digital pad. Each direction has a bool and a combined axis.</summary>
public class VirtualDPad
{
    public Vector2 Center  { get; set; }
    public float   Size    { get; set; } = 120f;  // full width/height of dpad
    public bool    Up      { get; private set; }
    public bool    Down    { get; private set; }
    public bool    Left    { get; private set; }
    public bool    Right   { get; private set; }
    public Vector2 Axis    => new(
        (Right ? 1f : 0f) - (Left ? 1f : 0f),
        (Up    ? 1f : 0f) - (Down ? 1f : 0f));

    public VirtualDPad(Vector2 center, float size = 120f)
    { Center = center; Size = size; }

    public void Update()
    {
        Up = Down = Left = Right = false;
        float third = Size / 3f;

        for (int i = 0; i < TouchInput.TouchCount; i++)
        {
            var t = TouchInput.GetTouch(i);
            if (t.Phase is TouchPhase.Ended or TouchPhase.Cancelled) continue;
            var delta = t.Position - Center;
            if (MathF.Max(MathF.Abs(delta.X), MathF.Abs(delta.Y)) > Size * 0.6f) continue;
            if (delta.Length < third * 0.3f) continue;  // dead zone

            if (MathF.Abs(delta.X) > MathF.Abs(delta.Y))
            { if (delta.X > 0) Right = true; else Left = true; }
            else
            { if (delta.Y < 0) Up = true; else Down = true; }
        }
    }
}

// ── VIRTUAL SLIDER ─────────────────────────────────────────────────────────
/// <summary>Horizontal or vertical touch slider. Good for volume, zoom, etc.</summary>
public class VirtualSlider
{
    public Vector2 Start     { get; set; }
    public Vector2 End       { get; set; }
    public float   Value     { get; private set; }  // 0..1
    public float   HitWidth  { get; set; } = 40f;
    public bool    IsHeld    { get; private set; }

    private int _touchId = -1;

    public VirtualSlider(Vector2 start, Vector2 end, float initialValue = 0.5f)
    { Start = start; End = end; Value = initialValue; }

    public void Update()
    {
        IsHeld = false;
        var axis = End - Start;
        float len = axis.Length;
        if (len < 0.001f) return;
        var dir = axis / len;

        for (int i = 0; i < TouchInput.TouchCount; i++)
        {
            var t = TouchInput.GetTouch(i);

            if (_touchId < 0 && t.Phase == TouchPhase.Began)
            {
                // Check if touch is near the track
                var toTouch = t.Position - Start;
                float along = Vector2.Dot(toTouch, dir);
                float perp  = (toTouch - dir * along).Length;
                if (perp < HitWidth && along >= -HitWidth && along <= len + HitWidth)
                    _touchId = t.FingerId;
            }

            if (t.FingerId != _touchId) continue;

            if (t.Phase is TouchPhase.Ended or TouchPhase.Cancelled)
            { _touchId = -1; return; }

            var proj = t.Position - Start;
            float t2 = Math.Clamp(Vector2.Dot(proj, dir) / len, 0f, 1f);
            Value  = t2;
            IsHeld = true;
        }
    }
}

// ── TOUCH CONTROL LAYOUT ───────────────────────────────────────────────────
/// <summary>
/// Preset layouts for common game types.
/// Create one of these and call Update() each frame — all controls updated together.
/// </summary>
public class TouchControlLayout
{
    public VirtualJoystick? LeftStick  { get; private set; }
    public VirtualJoystick? RightStick { get; private set; }
    public VirtualDPad?     DPad       { get; private set; }
    public VirtualButton[]  Buttons    { get; private set; } = Array.Empty<VirtualButton>();

    private int _sw, _sh;  // screen width/height

    /// <summary>Standard 2-stick layout (left stick + 4 face buttons).</summary>
    public static TouchControlLayout TwoStick(int screenW, int screenH)
    {
        float pad = 30f, btnR = 46f;
        return new TouchControlLayout
        {
            _sw = screenW, _sh = screenH,
            LeftStick  = new VirtualJoystick(new Vector2(130, screenH - 130), 90f),
            RightStick = new VirtualJoystick(new Vector2(screenW - 130, screenH - 130), 90f),
            Buttons    = new[]
            {
                new VirtualButton(new Vector2(screenW - 200, screenH - 220), "X", btnR),
                new VirtualButton(new Vector2(screenW - 120, screenH - 280), "Y", btnR),
                new VirtualButton(new Vector2(screenW - 40,  screenH - 220), "B", btnR),
                new VirtualButton(new Vector2(screenW - 120, screenH - 160), "A", btnR),
            }
        };
    }

    /// <summary>D-Pad + 2 buttons layout (platformers, fighters).</summary>
    public static TouchControlLayout DPadLayout(int screenW, int screenH)
    {
        return new TouchControlLayout
        {
            _sw = screenW, _sh = screenH,
            DPad = new VirtualDPad(new Vector2(130, screenH - 140), 130f),
            Buttons = new[]
            {
                new VirtualButton(new Vector2(screenW - 100, screenH - 160), "Jump",  56f),
                new VirtualButton(new Vector2(screenW - 190, screenH - 100), "Attack",50f),
            }
        };
    }

    /// <summary>Swipe-only layout (Subway Surfers style) — no visible controls.</summary>
    public static TouchControlLayout SwipeOnly(int screenW, int screenH)
        => new TouchControlLayout { _sw = screenW, _sh = screenH };

    public void Update()
    {
        LeftStick?.Update();
        RightStick?.Update();
        DPad?.Update();
        foreach (var b in Buttons) b.Update();
    }

    /// <summary>Resize layout when window changes size.</summary>
    public void Resize(int screenW, int screenH)
    {
        _sw = screenW; _sh = screenH;
        // Reposition proportionally
        if (LeftStick  != null) LeftStick.Center  = new Vector2(130, screenH - 130);
        if (RightStick != null) RightStick.Center = new Vector2(screenW - 130, screenH - 130);
        if (DPad       != null) DPad.Center       = new Vector2(130, screenH - 140);
        if (Buttons.Length > 0) Buttons[0].Center = new Vector2(screenW - 200, screenH - 220);
        if (Buttons.Length > 1) Buttons[1].Center = new Vector2(screenW - 120, screenH - 280);
        if (Buttons.Length > 2) Buttons[2].Center = new Vector2(screenW - 40,  screenH - 220);
        if (Buttons.Length > 3) Buttons[3].Center = new Vector2(screenW - 120, screenH - 160);
    }
}
