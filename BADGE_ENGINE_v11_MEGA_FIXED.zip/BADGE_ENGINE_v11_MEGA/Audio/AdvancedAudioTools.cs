using System;
using System.Collections.Generic;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using BADGE.Audio.Effects;

namespace BADGE.Audio
{
    /// <summary>
    /// Advanced audio tools:
    /// multi-bus mixer, compressor/limiter, 3D spatial audio,
    /// waveform analysis, spectrum analyzer, audio slicer, loop points.
    /// </summary>
    public static class AdvancedAudioTools
    {
        // ── Multi-bus mixer ───────────────────────────────────────────────
        public class AudioBus
        {
            public string Name    { get; }
            public float  Volume  { get; set; } = 1f;
            public bool   Muted   { get; set; } = false;
            public bool   Soloed  { get; set; } = false;

            private Reverb? _reverb;
            private Echo?   _echo;
            private Compressor? _compressor;

            public AudioBus(string name) => Name = name;

            public void SetReverb(float roomSize, float wet)
                => _reverb = new Reverb { RoomSize = roomSize, WetLevel = wet };

            public void SetEcho(float delaySeconds, float feedback)
                => _echo = new Echo { DelayTime = delaySeconds, Feedback = feedback };

            public void SetCompressor(float threshold, float ratio)
                => _compressor = new Compressor { Threshold = threshold, Ratio = ratio };

            public float[] Process(float[] samples)
            {
                if (Muted) return new float[samples.Length];
                float[] s = samples;
                if (_reverb     != null) s = _reverb.Process(s);
                if (_echo       != null) s = _echo.Process(s);
                if (_compressor != null) s = _compressor.Process(s);

                float vol = Volume;
                for (int i = 0; i < s.Length; i++) s[i] *= vol;
                return s;
            }
        }

        // ── Compressor / Limiter ──────────────────────────────────────────
        public class Compressor
        {
            public float Threshold { get; set; } = -18f;  // dB
            public float Ratio     { get; set; } = 4f;
            public float Attack    { get; set; } = 0.003f; // seconds
            public float Release   { get; set; } = 0.1f;
            public float MakeupGain{ get; set; } = 0f;     // dB

            private float _envelope;

            public float[] Process(float[] samples)
            {
                float threshLin  = DbToLinear(Threshold);
                float makeupLin  = DbToLinear(MakeupGain);
                var   output     = new float[samples.Length];
                const int SR     = 44100;
                float attackCoef = MathF.Exp(-1f / (Attack * SR));
                float relCoef    = MathF.Exp(-1f / (Release * SR));

                for (int i = 0; i < samples.Length; i++)
                {
                    float x    = MathF.Abs(samples[i]);
                    float coef = x > _envelope ? attackCoef : relCoef;
                    _envelope  = coef * _envelope + (1f - coef) * x;

                    float gain = 1f;
                    if (_envelope > threshLin)
                        gain = threshLin + (_envelope - threshLin) / Ratio / _envelope;

                    output[i] = samples[i] * gain * makeupLin;
                }
                return output;
            }

            private static float DbToLinear(float db) => MathF.Pow(10f, db / 20f);
        }

        // ── Waveform analysis ─────────────────────────────────────────────
        public static class WaveformAnalyzer
        {
            /// <summary>
            /// Compute peak amplitude per chunk for waveform display.
            /// Returns chunks × 2 array (peak positive, peak negative).
            /// </summary>
            public static float[,] ComputePeaks(float[] samples, int chunkCount)
            {
                var peaks  = new float[chunkCount, 2];
                int stride = Math.Max(1, samples.Length / chunkCount);

                for (int c = 0; c < chunkCount; c++)
                {
                    int start = c * stride;
                    int end   = Math.Min(start + stride, samples.Length);
                    float max = 0f, min = 0f;
                    for (int i = start; i < end; i++)
                    {
                        if (samples[i] > max) max = samples[i];
                        if (samples[i] < min) min = samples[i];
                    }
                    peaks[c, 0] = max;
                    peaks[c, 1] = min;
                }
                return peaks;
            }

            /// <summary>Compute RMS amplitude per chunk.</summary>
            public static float[] ComputeRMS(float[] samples, int chunkCount)
            {
                var rms    = new float[chunkCount];
                int stride = Math.Max(1, samples.Length / chunkCount);

                for (int c = 0; c < chunkCount; c++)
                {
                    int start = c * stride;
                    int end   = Math.Min(start + stride, samples.Length);
                    float sum = 0f;
                    for (int i = start; i < end; i++) sum += samples[i] * samples[i];
                    rms[c] = MathF.Sqrt(sum / (end - start));
                }
                return rms;
            }
        }

        // ── Spectrum Analyzer (DFT-based) ─────────────────────────────────
        public static class SpectrumAnalyzer
        {
            /// <summary>
            /// Compute magnitude spectrum using a real DFT (no FFT library required).
            /// bins = number of frequency bins (output size = bins).
            /// </summary>
            public static float[] ComputeSpectrum(float[] samples, int bins = 64)
            {
                int N      = Math.Min(samples.Length, 1024);
                var mag    = new float[bins];
                float step = MathF.PI / bins;

                for (int k = 0; k < bins; k++)
                {
                    float re = 0f, im = 0f;
                    float freq = k * step;
                    for (int n = 0; n < N; n++)
                    {
                        re += samples[n] * MathF.Cos(freq * n);
                        im += samples[n] * MathF.Sin(freq * n);
                    }
                    mag[k] = MathF.Sqrt(re*re + im*im) / N;
                }
                return mag;
            }
        }

        // ── Audio Slicer ──────────────────────────────────────────────────
        public static class AudioSlicer
        {
            /// <summary>
            /// Slice a clip at evenly-spaced beat intervals.
            /// Returns a list of sub-clips.
            /// </summary>
            public static List<AudioClip> SliceByBeats(AudioClip clip, float bpm, int beatsPerSlice = 1)
            {
                float samplesPerBeat = clip.SampleRate * 60f / bpm;
                float sliceSamples   = samplesPerBeat * beatsPerSlice;
                var   slices         = new List<AudioClip>();
                int   totalSamples   = clip.Samples.Length;
                int   sliceLen       = (int)sliceSamples;
                int   idx            = 0;

                while (idx + sliceLen <= totalSamples)
                {
                    var data = new float[sliceLen];
                    Array.Copy(clip.Samples, idx, data, 0, sliceLen);
                    slices.Add(AudioClip.CreateFromPCM(
                        $"{clip.Name}_slice{slices.Count}", data,
                        clip.SampleRate, clip.Channels));
                    idx += sliceLen;
                }

                return slices;
            }

            /// <summary>Trim silence from start and end of a clip.</summary>
            public static AudioClip TrimSilence(AudioClip clip, float threshold = 0.01f)
            {
                int start = 0, end = clip.Samples.Length - 1;
                while (start < end && MathF.Abs(clip.Samples[start]) < threshold) start++;
                while (end > start && MathF.Abs(clip.Samples[end])   < threshold) end--;
                int len  = end - start + 1;
                var data = new float[len];
                Array.Copy(clip.Samples, start, data, 0, len);
                return AudioClip.CreateFromPCM(clip.Name + "_trimmed", data,
                                               clip.SampleRate, clip.Channels);
            }
        }

        // ── Audio ducking ─────────────────────────────────────────────────
        public class AudioDucker
        {
            public float TargetVolume  { get; set; } = 0.3f;
            public float FadeSpeed     { get; set; } = 3f;     // volume/sec

            private float _currentVol = 1f;
            private bool  _isDucked;

            public void Duck()   => _isDucked = true;
            public void Unduck() => _isDucked = false;

            public float GetVolume(float dt)
            {
                float target = _isDucked ? TargetVolume : 1f;
                float step   = FadeSpeed * dt;
                _currentVol  = _currentVol < target
                    ? Math.Min(_currentVol + step, target)
                    : Math.Max(_currentVol - step, target);
                return _currentVol;
            }
        }
    }
}
