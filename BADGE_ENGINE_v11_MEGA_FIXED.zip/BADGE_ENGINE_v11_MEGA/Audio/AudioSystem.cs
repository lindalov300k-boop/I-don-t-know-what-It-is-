using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Audio;

// ═══════════════════════════════════════════════════════════════════════
//  AUDIO CLIP
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Holds raw PCM audio data.
///
/// REPLACES: The old AudioClip stub (just Name + float[] with no factory).
/// ADDS: CreateFromPCM() factory, metadata, loop points.
/// </summary>
public class AudioClip
{
    public string Name       { get; private set; }
    public float[] Samples   { get; private set; }
    public int SampleRate    { get; private set; }
    public int Channels      { get; private set; }
    public float Length      => Samples.Length / (float)(SampleRate * Channels);

    private AudioClip(string name, float[] samples, int sampleRate, int channels)
    {
        Name       = name;
        Samples    = samples;
        SampleRate = sampleRate;
        Channels   = channels;
    }

    /// <summary>
    /// Create an AudioClip from a raw interleaved PCM float array.
    /// This is the primary way BADGE code (and converted Unity code) creates clips.
    /// </summary>
    public static AudioClip CreateFromPCM(string name, float[] data, int sampleRate, int channels = 1)
    {
        if (data == null || data.Length == 0)
            throw new ArgumentException("PCM data must not be empty.", nameof(data));
        return new AudioClip(name, data, sampleRate, channels);
    }

    /// <summary>Create a silent clip of the given duration.</summary>
    public static AudioClip CreateSilent(string name, float durationSeconds, int sampleRate = 44100, int channels = 1)
    {
        int n = (int)(durationSeconds * sampleRate * channels);
        return new AudioClip(name, new float[n], sampleRate, channels);
    }

    /// <summary>Load from WAV file on disk (returns null if file missing).</summary>
    public static AudioClip? LoadFromFile(string path)
    {
        if (!System.IO.File.Exists(path)) return null;
        // Minimal WAV parser (PCM 16-bit, mono/stereo)
        try
        {
            using var fs = System.IO.File.OpenRead(path);
            using var br = new System.IO.BinaryReader(fs);

            // RIFF header
            br.ReadBytes(4);  // "RIFF"
            br.ReadInt32();   // chunk size
            br.ReadBytes(4);  // "WAVE"
            br.ReadBytes(4);  // "fmt "
            br.ReadInt32();   // fmt chunk size (16)
            br.ReadInt16();   // PCM = 1
            short channels  = br.ReadInt16();
            int sampleRate  = br.ReadInt32();
            br.ReadInt32();   // byte rate
            br.ReadInt16();   // block align
            short bitDepth  = br.ReadInt16();
            br.ReadBytes(4);  // "data"
            int dataSize    = br.ReadInt32();

            int sampleCount = dataSize / (bitDepth / 8);
            float[] samples = new float[sampleCount];
            float scale     = bitDepth == 16 ? 1f / 32768f : 1f / 128f - 1f;
            for (int i = 0; i < sampleCount; i++)
            {
                samples[i] = bitDepth == 16
                    ? br.ReadInt16() * scale
                    : (br.ReadByte() - 128) * scale;
            }
            return new AudioClip(System.IO.Path.GetFileNameWithoutExtension(path), samples, sampleRate, channels);
        }
        catch { return null; }
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  AUDIO SOURCE COMPONENT
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Component that plays audio clips in the scene.
///
/// NEW: Was completely absent. LUMINOUS needed Pitch, Volume, SpatialBlend,
///      MaxDistance, Loop, Play(), Stop(), and 3D positional audio.
/// </summary>
public class AudioSource : BADGE.Core.Component
{
    // ── Properties ────────────────────────────────────────────────
    public AudioClip?    Clip          { get; set; }
    public float         Volume        { get; set; } = 1f;
    public float         Pitch         { get; set; } = 1f;
    public bool          Loop          { get; set; } = false;
    public bool          PlayOnAwake   { get; set; } = true;

    /// <summary>0 = fully 2D (no position), 1 = fully 3D positional.</summary>
    public float         SpatialBlend  { get; set; } = 0f;

    public float         MinDistance   { get; set; } = 1f;
    public float         MaxDistance   { get; set; } = 100f;
    public AudioRolloffMode RolloffMode { get; set; } = AudioRolloffMode.Logarithmic;

    // ── Playback state ────────────────────────────────────────────
    public bool   IsPlaying   { get; private set; }
    public float  PlaybackPos { get; private set; }   // sample index

    private float _sampleAccumulator;

    // ── Lifecycle ─────────────────────────────────────────────────
    public override void Awake()
    {
        if (PlayOnAwake && Clip != null) Play();
    }

    public override void Update(float dt)
    {
        if (!IsPlaying || Clip == null) return;
        AdvancePlayback(dt);
    }

    // ── Playback API ──────────────────────────────────────────────
    public void Play()
    {
        if (Clip == null) return;
        PlaybackPos  = 0f;
        IsPlaying    = true;
        AudioMixer.Register(this);
    }

    public void Play(AudioClip clip)
    {
        Clip        = clip;
        Play();
    }

    public void Stop()
    {
        IsPlaying   = false;
        PlaybackPos = 0f;
        AudioMixer.Unregister(this);
    }

    public void Pause()  => IsPlaying = false;
    public void Resume() => IsPlaying = Clip != null;

    // ── Internal playback ─────────────────────────────────────────
    private void AdvancePlayback(float dt)
    {
        if (Clip == null) return;
        float advance = dt * Clip.SampleRate * Pitch;
        PlaybackPos += advance;
        if (PlaybackPos >= Clip.Samples.Length)
        {
            if (Loop) PlaybackPos %= Clip.Samples.Length;
            else      Stop();
        }
    }

    /// <summary>
    /// Called by the AudioMixer to pull the next buffer of samples.
    /// Returns the number of samples actually written.
    /// </summary>
    internal int FillBuffer(float[] buffer, int count, Vector3 listenerPos)
    {
        if (!IsPlaying || Clip == null) return 0;

        float spatialVol = ComputeSpatialVolume(listenerPos);
        float totalVol   = Volume * spatialVol;
        int   start      = (int)PlaybackPos;

        for (int i = 0; i < count; i++)
        {
            int idx = start + i;
            if (idx >= Clip.Samples.Length)
            {
                if (Loop) idx %= Clip.Samples.Length;
                else       break;
            }
            buffer[i] += Clip.Samples[idx] * totalVol;
        }
        return count;
    }

    private float ComputeSpatialVolume(Vector3 listenerPos)
    {
        if (SpatialBlend < 0.001f || Transform == null) return 1f;
        float dist = Vector3.Distance(Transform.Position, listenerPos);
        if (dist <= MinDistance) return 1f;
        if (dist >= MaxDistance) return SpatialBlend < 1f ? 1f - SpatialBlend : 0f;

        float atten = RolloffMode switch
        {
            AudioRolloffMode.Linear      => 1f - (dist - MinDistance) / (MaxDistance - MinDistance),
            AudioRolloffMode.Logarithmic => MinDistance / (MinDistance + dist),
            _                            => 1f
        };

        return MathHelper.Lerp(1f, atten, SpatialBlend);
    }
}

public enum AudioRolloffMode { Logarithmic, Linear, Custom }

// ═══════════════════════════════════════════════════════════════════════
//  AUDIO MIXER  (replaces the old stub)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Central mixer: tracks all active AudioSources, applies group volumes,
/// and provides a simple mixing bus for the audio backend.
///
/// REPLACES: The old stub (SetIdle + empty Play()).
/// </summary>
// AudioMixer defined in AudioMixer.cs

