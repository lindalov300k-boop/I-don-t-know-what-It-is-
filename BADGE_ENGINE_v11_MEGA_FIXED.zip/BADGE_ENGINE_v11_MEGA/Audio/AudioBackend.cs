using System;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using OpenTK.Mathematics;

namespace BADGE.Audio
{
    /// <summary>
    /// NAudio-backed audio output.  Pulls mixed samples from AudioMixer
    /// and sends them to the system's default audio device at 44100 Hz stereo.
    ///
    /// Call AudioBackend.Start() once during engine initialisation.
    /// The mixer's Mix() method is invoked from NAudio's callback thread.
    /// </summary>
    public static class AudioBackend
    {
        private static WaveOutEvent?          _waveOut;
        private static BadgeSampleProvider?   _provider;
        private static bool                   _running;

        public static bool IsRunning => _running;

        public static void Start()
        {
            if (_running) return;

            _provider = new BadgeSampleProvider(44100, 2);
            _waveOut  = new WaveOutEvent { DesiredLatency = 80 };
            _waveOut.Init(_provider);
            _waveOut.Play();
            _running = true;
        }

        public static void Stop()
        {
            _waveOut?.Stop();
            _waveOut?.Dispose();
            _waveOut  = null;
            _provider = null;
            _running  = false;
        }

        /// <summary>Update the listener position (for 3D spatial audio).</summary>
        public static void SetListenerPosition(Vector3 pos)
        {
            if (_provider != null) _provider.ListenerPosition = pos;
        }

        // ── NAudio ISampleProvider ─────────────────────────────────────────
        private sealed class BadgeSampleProvider : ISampleProvider
        {
            public WaveFormat WaveFormat { get; }
            public Vector3    ListenerPosition { get; set; }

            // Mono mix buffer — channels are duplicated for stereo output
            private readonly float[] _monoBuffer;

            public BadgeSampleProvider(int sampleRate, int channels)
            {
                WaveFormat   = WaveFormat.CreateIeeeFloatWaveFormat(sampleRate, channels);
                _monoBuffer  = new float[sampleRate / 20];   // 50 ms chunks
            }

            public int Read(float[] buffer, int offset, int count)
            {
                // count is in stereo samples; mix operates on mono
                int monoCount = count / WaveFormat.Channels;
                monoCount = Math.Min(monoCount, _monoBuffer.Length);

                AudioMixer.Mix(_monoBuffer, monoCount, ListenerPosition);

                // Duplicate mono → stereo (or fill all channels equally)
                for (int i = 0; i < monoCount; i++)
                {
                    for (int ch = 0; ch < WaveFormat.Channels; ch++)
                        buffer[offset + i * WaveFormat.Channels + ch] = _monoBuffer[i];
                }

                return monoCount * WaveFormat.Channels;
            }
        }
    }
}
