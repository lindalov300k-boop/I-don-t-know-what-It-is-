using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using BADGE.Core;

namespace BADGE.Audio
{
    /// <summary>
    /// Background music manager with crossfade, looping, layers, and cue system.
    ///
    /// Usage:
    ///   MusicManager.Play("music/theme.ogg");
    ///   MusicManager.CrossfadeTo("music/battle.ogg", 2f);
    ///   MusicManager.SetVolume(0.8f);
    ///   MusicManager.Pause();
    ///   MusicManager.Resume();
    ///   MusicManager.Stop(fadeOut: 1f);
    ///
    ///   // Layer on top of base track (e.g. add drums when combat starts)
    ///   MusicManager.AddLayer("music/drums.ogg", 0f);
    ///   MusicManager.FadeLayer("music/drums.ogg", 1f, 1.5f);
    /// </summary>
    public static class MusicManager
    {
        // ── State ─────────────────────────────────────────────────────────
        private static MusicTrack? _current;
        private static MusicTrack? _fading;          // outgoing during crossfade
        private static float       _masterVolume = 0.8f;
        private static bool        _paused;

        private static readonly Dictionary<string, MusicTrack> _layers = new();

        // ── NAudio mixer (shared with AudioMixer if possible) ─────────────
        private static MixingSampleProvider? _mixer;
        private static IWavePlayer?          _player;
        private static bool                  _initialized;

        // ── Init ──────────────────────────────────────────────────────────
        private static void EnsureInit()
        {
            if (_initialized) return;
            _initialized = true;
            try
            {
                _mixer  = new MixingSampleProvider(WaveFormat.CreateIeeeFloatWaveFormat(44100, 2));
                _mixer.ReadFully = true;
                _player = new WaveOutEvent();
                _player.Init(_mixer);
                _player.Play();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[MusicManager] Audio init failed: {ex.Message}");
            }
        }

        // ── Public API ────────────────────────────────────────────────────

        /// <summary>Play a track, stopping any current music immediately.</summary>
        public static void Play(string path, bool loop = true, float volume = 1f)
        {
            EnsureInit();
            Stop(fadeOut: 0f);
            _current = CreateTrack(path, loop, volume * _masterVolume);
            if (_current != null) AddToMixer(_current);
        }

        /// <summary>
        /// Smoothly crossfade from current track to a new one.
        /// oldFadeDuration controls how long current fades out;
        /// the new one fades in over newFadeDuration.
        /// </summary>
        public static void CrossfadeTo(string path, float oldFadeDuration = 1.5f,
                                         float newFadeDuration = 1.5f,
                                         bool loop = true, float volume = 1f)
        {
            EnsureInit();

            // Park current as fading-out
            _fading = _current;
            _current = null;

            var next = CreateTrack(path, loop, 0f);  // start silent
            if (next == null) return;

            _current = next;
            AddToMixer(next);

            // Animate volumes
            _ = FadeOutTrack(_fading, oldFadeDuration);
            _ = FadeInTrack(next, volume * _masterVolume, newFadeDuration);
        }

        /// <summary>Add an additional layer (e.g. drums, stings) on top.</summary>
        public static void AddLayer(string path, float initialVolume = 0f, bool loop = true)
        {
            EnsureInit();
            if (_layers.ContainsKey(path)) return;
            var track = CreateTrack(path, loop, initialVolume * _masterVolume);
            if (track == null) return;
            _layers[path] = track;
            AddToMixer(track);
        }

        /// <summary>Fade a layer in or out.</summary>
        public static void FadeLayer(string path, float targetVolume, float duration)
        {
            if (!_layers.TryGetValue(path, out var track)) return;
            _ = FadeTrackTo(track, targetVolume * _masterVolume, duration);
        }

        public static void RemoveLayer(string path, float fadeOut = 0.5f)
        {
            if (!_layers.TryGetValue(path, out var track)) return;
            _ = FadeOutTrack(track, fadeOut, () =>
            {
                _layers.Remove(path);
                RemoveFromMixer(track);
                track.Dispose();
            });
        }

        /// <summary>Stop current music. fadeOut=0 is immediate.</summary>
        public static void Stop(float fadeOut = 0.5f)
        {
            if (_current == null) return;
            var t = _current;
            _current = null;

            if (fadeOut <= 0f)
            {
                RemoveFromMixer(t);
                t.Dispose();
            }
            else
            {
                _ = FadeOutTrack(t, fadeOut, () => { RemoveFromMixer(t); t.Dispose(); });
            }
        }

        public static void Pause()
        {
            _paused = true;
            _player?.Pause();
        }

        public static void Resume()
        {
            _paused = false;
            _player?.Play();
        }

        public static void SetVolume(float v)
        {
            _masterVolume = Math.Clamp(v, 0f, 1f);
            _current?.SetVolume(_masterVolume);
            foreach (var layer in _layers.Values) layer.SetVolume(_masterVolume);
        }

        public static bool IsPlaying => _current != null && !_paused;
        public static string? CurrentTrackName => _current?.Path;

        public static void Shutdown()
        {
            Stop(0f);
            foreach (var l in _layers.Values) { RemoveFromMixer(l); l.Dispose(); }
            _layers.Clear();
            _player?.Dispose();
            _mixer  = null;
            _player = null;
            _initialized = false;
        }

        // ── Internal ──────────────────────────────────────────────────────
        private static MusicTrack? CreateTrack(string path, bool loop, float volume)
        {
            try { return new MusicTrack(path, loop, volume); }
            catch (Exception ex)
            {
                Console.WriteLine($"[MusicManager] Failed to load '{path}': {ex.Message}");
                return null;
            }
        }

        private static void AddToMixer(MusicTrack t)
            => _mixer?.AddMixerInput(t.Provider);

        private static void RemoveFromMixer(MusicTrack t)
        {
            try { _mixer?.RemoveMixerInput(t.Provider); } catch { }
        }

        private static async Task FadeInTrack(MusicTrack t, float targetVol, float dur)
        {
            float elapsed = 0f;
            while (elapsed < dur)
            {
                elapsed += Time.UnscaledDeltaTime;
                t.SetVolume(BMath.LerpClamped(0f, targetVol, elapsed / dur));
                await Task.Yield();
            }
            t.SetVolume(targetVol);
        }

        private static async Task FadeOutTrack(MusicTrack? t, float dur,
                                                 Action? onComplete = null)
        {
            if (t == null) { onComplete?.Invoke(); return; }
            float startVol = t.Volume;
            float elapsed  = 0f;
            while (elapsed < dur)
            {
                elapsed += Time.UnscaledDeltaTime;
                t.SetVolume(BMath.LerpClamped(startVol, 0f, elapsed / dur));
                await Task.Yield();
            }
            t.SetVolume(0f);
            onComplete?.Invoke();
        }

        private static async Task FadeTrackTo(MusicTrack t, float target, float dur)
        {
            float start = t.Volume, elapsed = 0f;
            while (elapsed < dur)
            {
                elapsed += Time.UnscaledDeltaTime;
                t.SetVolume(BMath.LerpClamped(start, target, elapsed / dur));
                await Task.Yield();
            }
            t.SetVolume(target);
        }
    }

    // ── MusicTrack wrapper ─────────────────────────────────────────────────
    internal sealed class MusicTrack : IDisposable
    {
        public string Path { get; }
        public float  Volume { get; private set; }
        public VolumeSampleProvider Provider { get; }

        private readonly AudioFileReader _reader;
        private readonly LoopStream?     _loop;

        public MusicTrack(string path, bool loop, float volume)
        {
            Path    = path;
            _reader = new AudioFileReader(path);

            ISampleProvider source = _reader;

            if (loop)
            {
                _loop  = new LoopStream(_reader);
                source = _loop.ToSampleProvider();
            }

            Provider = new VolumeSampleProvider(source);
            SetVolume(volume);
        }

        public void SetVolume(float v)
        {
            Volume = Math.Clamp(v, 0f, 1f);
            Provider.Volume = Volume;
        }

        public void Dispose()
        {
            _loop?.Dispose();
            _reader.Dispose();
        }
    }

    // ── Minimal LoopStream ─────────────────────────────────────────────────
    internal sealed class LoopStream : WaveStream
    {
        private readonly WaveStream _source;
        public LoopStream(WaveStream source) => _source = source;
        public override WaveFormat WaveFormat => _source.WaveFormat;
        public override long Length           => _source.Length;
        public override long Position
        {
            get => _source.Position;
            set => _source.Position = value;
        }
        public override int Read(byte[] buffer, int offset, int count)
        {
            int total = 0;
            while (total < count)
            {
                int read = _source.Read(buffer, offset + total, count - total);
                if (read == 0) _source.Position = 0;
                else total += read;
            }
            return total;
        }
    }
}
