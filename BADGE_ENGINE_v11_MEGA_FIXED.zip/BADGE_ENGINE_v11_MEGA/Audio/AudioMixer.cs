using System;
using System.Collections.Generic;
using System.Linq;

namespace BADGE.Audio
{
    /// <summary>
    /// Central audio mixer — mixes multiple active channels into a
    /// stereo float buffer consumed by AudioBackend's NAudio provider.
    /// Supports volume, pitch, spatial attenuation, and per-bus sends.
    /// </summary>
    public static class AudioMixer
    {
        // ── State ─────────────────────────────────────────────────────────
        private static readonly List<ActiveVoice> _voices  = new();
        private static readonly object            _lock    = new();
        private static float  _masterVolume = 1f;
        private static bool   _muted;

        // ── Public API ────────────────────────────────────────────────────
        public static float MasterVolume
        {
            get => _masterVolume;
            set => _masterVolume = Math.Clamp(value, 0f, 2f);
        }

        public static bool Muted
        {
            get => _muted;
            set => _muted = value;
        }

        /// <summary>
        /// Begin playing an audio clip. Returns a voice ID that can be used to stop it.
        /// </summary>
        public static int Play(AudioClip clip, float volume = 1f,
                               float pitch = 1f, bool loop = false)
        {
            if (clip?.Samples == null || clip.Samples.Length == 0) return -1;
            var voice = new ActiveVoice
            {
                Id        = _nextId++,
                Clip      = clip,
                Volume    = Math.Clamp(volume, 0f, 2f),
                Pitch     = Math.Clamp(pitch,  0.1f, 4f),
                Loop      = loop,
                Position  = 0f,
                IsPlaying = true,
            };
            lock (_lock) _voices.Add(voice);
            return voice.Id;
        }

        /// <summary>
        /// Stop a specific voice by its ID.
        /// </summary>
        public static void Stop(int voiceId)
        {
            lock (_lock)
            {
                var v = _voices.FirstOrDefault(v => v.Id == voiceId);
                if (v != null) v.IsPlaying = false;
            }
        }

        /// <summary>
        /// Stop all voices.
        /// </summary>
        public static void StopAll()
        {
            lock (_lock)
            {
                foreach (var v in _voices) v.IsPlaying = false;
            }
        }

        /// <summary>
        /// Called by AudioBackend.BadgeSampleProvider from the audio thread.
        /// Fills <paramref name="buffer"/> with mixed mono samples.
        /// </summary>
        public static int Mix(float[] buffer, int offset, int count)
        {
            // Clear output
            Array.Clear(buffer, offset, count);

            if (_muted || _masterVolume <= 0f) return count;

            lock (_lock)
            {
                foreach (var voice in _voices)
                {
                    if (!voice.IsPlaying) continue;

                    float[] samples = voice.Clip.Samples;
                    int     len     = samples.Length;

                    for (int i = 0; i < count; i++)
                    {
                        int srcIdx = (int)voice.Position;
                        if (srcIdx >= len)
                        {
                            if (voice.Loop) voice.Position %= len;
                            else { voice.IsPlaying = false; break; }
                            srcIdx = (int)voice.Position;
                        }

                        // Linear interpolation for pitch shifting
                        float frac = voice.Position - srcIdx;
                        float s0   = samples[srcIdx];
                        float s1   = srcIdx + 1 < len ? samples[srcIdx + 1] : 0f;
                        float sample = s0 + frac * (s1 - s0);

                        buffer[offset + i] += sample * voice.Volume * _masterVolume;
                        voice.Position     += voice.Pitch;
                    }
                }

                // Prune dead voices
                _voices.RemoveAll(v => !v.IsPlaying);
            }

            // Soft-clip to prevent harsh clipping
            for (int i = 0; i < count; i++)
            {
                float s = buffer[offset + i];
                buffer[offset + i] = s < -1f ? -1f : (s > 1f ? 1f : s);
            }

            return count;
        }

        public static void SetIdle(bool idle) => _muted = idle;

        // ── Internal ──────────────────────────────────────────────────────
        private static int _nextId = 1;

        private class ActiveVoice
        {
            public int       Id;
            public AudioClip Clip     = null!;
            public float     Volume   = 1f;
            public float     Pitch    = 1f;
            public bool      Loop;
            public float     Position; // fractional sample index
            public bool      IsPlaying;
        }
    }

    // ── AudioClip ─────────────────────────────────────────────────────────
    // AudioClip defined in AudioSystem.cs

    public class Channel
    {
        public string Name   { get; set; } = "Channel";
        public float  Volume { get; set; } = 1f;
        public bool   Mute   { get; set; }
        public bool   Solo   { get; set; }
        public float  Pan    { get; set; }   // -1 left … +1 right
    }
}
