using BADGE.Core;
using OpenTK.Mathematics;
using System.Collections;

/// <summary>
/// Handles player movement along the grid
/// </summary>

namespace BADGE.Games.MysticGridJourney;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed = 3f;
    private PlayerController controller;

    private void Awake()
    {
        controller = GetComponent<PlayerController>();
    }

    /// <summary>
    /// Moves the player a specified number of steps along the grid
    /// </summary>
    public IEnumerator MoveSteps(int steps)
    {
        GridManager gridManager = GameManager.Instance.gridManager;
        
        int targetIndex = MathF.Min(
            controller.PlayerData.currentGridIndex + steps,
            gridManager.GridCells.Count - 1
        );

        // Move step by step
        while (controller.PlayerData.currentGridIndex < targetIndex)
        {
            controller.PlayerData.currentGridIndex++;
            GridCell targetCell = gridManager.GetCellAtIndex(controller.PlayerData.currentGridIndex);
            
            if (targetCell != null)
            {
                Vector3 targetPos = targetCell.Transform.Position + Vector3.up * 0.5f;
                
                // Smooth movement
                while (Vector3.Distance(Transform.Position, targetPos) > 0.1f)
                {
                    Transform.Position = Vector3.MoveTowards(Transform.Position, targetPos, moveSpeed * BADGE.Core.Time.DeltaTime);
                    yield return null;
                }
                
                Transform.Position = targetPos;
            }
            
            yield return new WaitForSeconds(0.2f);
        }
    }

    /// <summary>
    /// Instantly teleports the player to a specific cell
    /// </summary>
    public void TeleportToCell(int cellIndex)
    {
        GridManager gridManager = GameManager.Instance.gridManager;
        GridCell cell = gridManager.GetCellAtIndex(cellIndex);
        
        if (cell != null)
        {
            controller.PlayerData.currentGridIndex = cellIndex;
            Transform.Position = cell.Transform.Position + Vector3.up * 0.5f;
        }
    }
}
