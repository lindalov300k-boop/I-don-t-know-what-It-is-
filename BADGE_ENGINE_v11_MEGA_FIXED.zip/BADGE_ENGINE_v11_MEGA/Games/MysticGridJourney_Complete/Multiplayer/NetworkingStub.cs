using System;

namespace BADGE.Games.MysticGridJourney.Multiplayer
{
    /// <summary>
    /// Networking stub replaced with BADGE.Networking.SecureChannel integration.
    /// Use NetworkManager.Instance.StartServer() / StartClient() for real multiplayer.
    /// </summary>
    public static class NetworkingStub
    {
        [Obsolete("Use BADGE.Networking.NetworkManager.Instance instead.")]
        public static string CreateRoom(string gameName, int maxPlayers)
        {
            // Generate a real cryptographic session token
            byte[] tokenBytes = new byte[16];
            System.Security.Cryptography.RandomNumberGenerator.Fill(tokenBytes);
            string token = Convert.ToHexString(tokenBytes).ToLowerInvariant();
            Console.WriteLine($"[Multiplayer] Room created: {gameName} (max {maxPlayers}), token={token}");
            return token;
        }

        [Obsolete("Use BADGE.Networking.NetworkManager.Instance instead.")]
        public static bool JoinRoom(string token)
        {
            Console.WriteLine($"[Multiplayer] Joining room with token: {token}");
            // Real implementation: NetworkManager.Instance.StartClient(serverIP, port)
            return true;
        }

        [Obsolete("Use BADGE.Networking.NetworkManager.Instance instead.")]
        public static void SyncAction(string playerId, object action)
        {
            // Real implementation: NetworkManager.Instance.Send(NetworkMessage.Create(...))
            Console.WriteLine($"[Multiplayer] Action queued for sync: {playerId}");
        }
    }
}
