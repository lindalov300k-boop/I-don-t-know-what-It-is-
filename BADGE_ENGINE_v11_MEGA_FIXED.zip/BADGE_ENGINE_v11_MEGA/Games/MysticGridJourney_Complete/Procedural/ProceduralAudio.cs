using BADGE.Core;
using OpenTK.Mathematics;

/// <summary>
/// Generates procedural audio effects for mystical sounds
/// </summary>
public class ProceduralAudio : MonoBehaviour

namespace BADGE.Games.MysticGridJourney;

{
    public int sampleRate = 44100;
    public float duration = 0.5f;

    /// <summary>
    /// Generates a mystical sound effect using sine waves
    /// </summary>
    public AudioClip GenerateMysticalSound(float frequency = 440f)
    {
        int sampleCount = MathF.RoundToInt(sampleRate * duration);
        float[] samples = new float[sampleCount];
        
        for (int i = 0; i < sampleCount; i++)
        {
            float t = (float)i / sampleRate;
            
            // Combine multiple sine waves for mystical effect
            samples[i] = MathF.Sin(2 * MathF.PI * frequency * t) * 0.3f;
            samples[i] += MathF.Sin(2 * MathF.PI * frequency * 1.5f * t) * 0.2f;
            samples[i] += MathF.Sin(2 * MathF.PI * frequency * 2f * t) * 0.1f;
            
            // Apply envelope (fade in/out)
            float envelope = MathF.Sin(MathF.PI * t / duration);
            samples[i] *= envelope;
        }
        
        AudioClip clip = AudioClip.Create("MysticalSound", sampleCount, 1, sampleRate, false);
        clip.SetData(samples, 0);
        
        return clip;
    }

    /// <summary>
    /// Plays a randomly generated mystical sound at camera position
    /// </summary>
    public void PlayMysticalSound()
    {
        AudioClip clip = GenerateMysticalSound(Random.Range(300f, 600f));
        AudioSource.PlayClipAtPoint(clip, Camera.main.Transform.Position);
    }
}
