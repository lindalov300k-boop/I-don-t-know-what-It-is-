using BADGE.Core;
using OpenTK.Mathematics;

/// <summary>
/// Generates procedural character models based on customization settings
/// </summary>
public class ProceduralCharacter : MonoBehaviour

namespace BADGE.Games.MysticGridJourney;

{
    public MeshFilter meshFilter;
    public MeshRenderer meshRenderer;
    public ProceduralMesh meshGenerator;
    public ProceduralTexture textureGenerator;

    /// <summary>
    /// Generates a complete character from customization data
    /// </summary>
    public void GenerateCharacter(CharacterCustomization customization)
    {
        // Generate mesh based on gender
        Mesh characterMesh = meshGenerator.GenerateCharacterMesh(customization.gender);
        meshFilter.mesh = characterMesh;
        
        // Generate and apply texture
        Texture2D characterTexture = textureGenerator.GenerateCharacterTexture(customization);
        meshRenderer.material.mainTexture = characterTexture;
        
        Console.WriteLine($"Generated procedural character: {customization.gender}");
    }
}
