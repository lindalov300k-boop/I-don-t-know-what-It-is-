using BADGE.Core;
using OpenTK.Mathematics;
using TMPro;

/// <summary>
/// Controls the UI elements related to turn display and game state

namespace BADGE.Games.MysticGridJourney;

/// NOTE: Requires TextMeshPro package. If not installed, replace TextMeshProUGUI with Text
/// </summary>
public class TurnUIController : MonoBehaviour
{
    // [Header("UI References")]
    public TextMeshProUGUI turnText;
    public TextMeshProUGUI diceText;
    public GameObject skipTurnPanel;
    public TextMeshProUGUI skipTurnText;
    public GameObject winPanel;
    public TextMeshProUGUI winText;

    /// <summary>
    /// Updates the turn display to show whose turn it currently is
    /// </summary>
    public void UpdateTurnDisplay(string playerName)
    {
        turnText.text = $"{playerName}'s Turn";
    }

    /// <summary>
    /// Shows the dice roll result
    /// </summary>
    public void ShowDiceResult(int result)
    {
        diceText.text = $"Rolled: {result}";
    }

    /// <summary>
    /// Displays a message when a player's turn is skipped
    /// </summary>
    public void ShowSkipTurnMessage(string playerName)
    {
        skipTurnText.text = $"{playerName} is trapped! Turn skipped.";
        skipTurnPanel.SetActive(true);
        Invoke(nameof(HideSkipTurnPanel), 2f);
    }

    private void HideSkipTurnPanel()
    {
        skipTurnPanel.SetActive(false);
    }

    /// <summary>
    /// Shows the win screen with the winner's name
    /// </summary>
    public void ShowWinScreen(string playerName)
    {
        winText.text = $"{playerName} Wins!";
        winPanel.SetActive(true);
    }
}
