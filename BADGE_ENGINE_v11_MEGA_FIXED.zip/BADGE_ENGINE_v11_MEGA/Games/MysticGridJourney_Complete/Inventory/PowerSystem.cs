using BADGE.Core;
using OpenTK.Mathematics;

/// <summary>
/// Power types available in the game
/// </summary>
public enum PowerType

namespace BADGE.Games.MysticGridJourney;

{
    None,
    Freeze,
    Teleport,
    MultiplySteps,
    StealCoins,
    Shield
}

/// <summary>
/// Executes power effects on target players
/// </summary>
public class PowerSystem : MonoBehaviour
{
    /// <summary>
    /// Executes a specific power on a target player
    /// </summary>
    public void ExecutePower(PowerType power, PlayerController target)
    {
        switch (power)
        {
            case PowerType.Freeze:
                FreezePower(target);
                break;
            case PowerType.Teleport:
                TeleportPower(target);
                break;
            case PowerType.MultiplySteps:
                MultiplyStepsPower(target);
                break;
            case PowerType.StealCoins:
                StealCoinsPower(target);
                break;
            case PowerType.Shield:
                ShieldPower(target);
                break;
        }
    }

    private void FreezePower(PlayerController target)
    {
        target.PlayerData.skipNextTurn = true;
        Console.WriteLine($"{target.PlayerData.playerName} has been frozen!");
    }

    private void TeleportPower(PlayerController target)
    {
        // Teleport to a random cell
        GridManager gridManager = GameManager.Instance.gridManager;
        int randomIndex = Random.Range(0, gridManager.GridCells.Count);
        target.movement.TeleportToCell(randomIndex);
        Console.WriteLine($"{target.PlayerData.playerName} was teleported!");
    }

    private void MultiplyStepsPower(PlayerController target)
    {
        target.PlayerData.extraStepsNextTurn = 3;
        Console.WriteLine($"{target.PlayerData.playerName} will get +3 steps next turn!");
    }

    private void StealCoinsPower(PlayerController target)
    {
        int stolenAmount = MathF.Min(5, target.PlayerData.coins);
        target.PlayerData.coins -= stolenAmount;
        Console.WriteLine($"Stole {stolenAmount} coins from {target.PlayerData.playerName}!");
    }

    private void ShieldPower(PlayerController target)
    {
        // Protect from next negative effect (implement as needed)
        Console.WriteLine($"{target.PlayerData.playerName} is shielded!");
    }
}
