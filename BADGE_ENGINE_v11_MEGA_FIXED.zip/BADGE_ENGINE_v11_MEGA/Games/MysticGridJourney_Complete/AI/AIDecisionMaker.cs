using BADGE.Core;
using OpenTK.Mathematics;
using System.Collections.Generic;

/// <summary>
/// AI decision-making logic: determines actions based on personality and game state
/// </summary>

namespace BADGE.Games.MysticGridJourney;

public class AIDecisionMaker : MonoBehaviour
{
    private AIController aiController;
    private MultiplayerManager multiplayerManager;

    public void Initialize(AIController controller)
    {
        aiController = controller;
        multiplayerManager = GameManager.Instance.multiplayerManager;
    }

    /// <summary>
    /// Main decision point: evaluates options and takes action
    /// </summary>
    public void DecideAction(PlayerData aiData, AIPersonality personality)
    {
        float aggressionRoll = Random.value;
        
        // Should AI use a power?
        if (aiData.powers.Count > 0 && aggressionRoll < personality.powerUsageChance)
        {
            DecideWhichPowerToUse(aiData, personality);
        }
        
        // Should AI betray someone?
        if (aggressionRoll < personality.betrayalChance)
        {
            ConsiderBetrayal(aiData, personality);
        }
        
        // Should AI help someone?
        if (Random.value < personality.helpfulChance)
        {
            ConsiderHelping(aiData);
        }
    }

    private void DecideWhichPowerToUse(PlayerData aiData, AIPersonality personality)
    {
        if (aiData.powers.Count == 0) return;
        
        PowerType powerToUse = aiData.powers[Random.Range(0, aiData.powers.Count)];
        PlayerController target = ChooseTarget(personality);
        
        if (target != null)
        {
            UsePowerOnTarget(aiData, powerToUse, target);
        }
    }

    private void ConsiderBetrayal(PlayerData aiData, AIPersonality personality)
    {
        // Find player ahead of AI
        PlayerController playerAhead = FindPlayerAhead(aiData.currentGridIndex);
        
        if (playerAhead != null && aiData.powers.Count > 0)
        {
            // Use freeze or trap power
            foreach (PowerType power in aiData.powers)
            {
                if (power == PowerType.Freeze)
                {
                    UsePowerOnTarget(aiData, power, playerAhead);
                    Console.WriteLine($"{aiData.playerName} betrayed {playerAhead.PlayerData.playerName}!");
                    return;
                }
            }
        }
    }

    private void ConsiderHelping(PlayerData aiData)
    {
        // Find player behind AI who could use help
        PlayerController playerBehind = FindPlayerBehind(aiData.currentGridIndex);
        
        if (playerBehind != null)
        {
            Console.WriteLine($"{aiData.playerName} considers helping {playerBehind.PlayerData.playerName}");
            // Could give coins or buff (implement as needed)
        }
    }

    private PlayerController ChooseTarget(AIPersonality personality)
    {
        List<PlayerController> allPlayers = multiplayerManager.GetAllPlayers();
        
        if (allPlayers.Count <= 1) return null;
        
        // Random or strategic target
        return allPlayers[Random.Range(0, allPlayers.Count)];
    }

    private void UsePowerOnTarget(PlayerData aiData, PowerType power, PlayerController target)
    {
        PowerSystem powerSystem = GameManager.Instance.inventoryManager.GetComponent<PowerSystem>();
        
        if (powerSystem != null && aiData.UsePower(power))
        {
            powerSystem.ExecutePower(power, target);
        }
    }

    private PlayerController FindPlayerAhead(int currentIndex)
    {
        List<PlayerController> players = multiplayerManager.GetAllPlayers();
        PlayerController closestAhead = null;
        int smallestDistance = int.MaxValue;
        
        foreach (PlayerController player in players)
        {
            int playerIndex = player.PlayerData.currentGridIndex;
            if (playerIndex > currentIndex && playerIndex - currentIndex < smallestDistance)
            {
                closestAhead = player;
                smallestDistance = playerIndex - currentIndex;
            }
        }
        
        return closestAhead;
    }

    private PlayerController FindPlayerBehind(int currentIndex)
    {
        List<PlayerController> players = multiplayerManager.GetAllPlayers();
        PlayerController closestBehind = null;
        int smallestDistance = int.MaxValue;
        
        foreach (PlayerController player in players)
        {
            int playerIndex = player.PlayerData.currentGridIndex;
            if (playerIndex < currentIndex && currentIndex - playerIndex < smallestDistance)
            {
                closestBehind = player;
                smallestDistance = currentIndex - playerIndex;
            }
        }
        
        return closestBehind;
    }
}
