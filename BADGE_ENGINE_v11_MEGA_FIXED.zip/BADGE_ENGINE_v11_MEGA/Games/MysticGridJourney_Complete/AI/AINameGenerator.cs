using BADGE.Core;
using OpenTK.Mathematics;

/// <summary>
/// Utility class for generating procedural AI names
/// </summary>
public static class AINameGenerator

namespace BADGE.Games.MysticGridJourney;

{
    private static string[] prefixes = { "Shadow", "Mystic", "Dark", "Ancient", "Ethereal", "Crystal", "Storm", "Fire" };
    private static string[] suffixes = { "walker", "mancer", "blade", "heart", "wind", "sage", "keeper", "seer" };

    /// <summary>
    /// Generates a random mystical AI name
    /// </summary>
    public static string GenerateRandomName()
    {
        string prefix = prefixes[Random.Range(0, prefixes.Length)];
        string suffix = suffixes[Random.Range(0, suffixes.Length)];
        
        return prefix + suffix;
    }

    /// <summary>
    /// Generates a deterministic name based on a seed
    /// </summary>
    public static string GenerateName(int seed)
    {
        Random.InitState(seed);
        return GenerateRandomName();
    }
}
