# Mystic Grid Journey - Unity Setup Guide

## 📋 Overview
Complete C# script collection for Mystic Grid Journey - a fantasy turn-based board game with procedural generation, AI opponents, and multiplayer support.

**Unity Version:** 2019.4 LTS  
**Architecture:** Modular, Event-Driven  
**Multiplayer:** Local (Online-ready)

---

## 📁 Project Structure

```
Assets/
├── Scenes/
│   ├── StartScene.unity
│   ├── GameScene.unity
│   ├── InventoryScene.unity
│   └── CharacterCustomization.unity
│
├── Scripts/                     ← Copy all scripts here
│   ├── Core/                    (3 scripts)
│   ├── Grid/                    (4 scripts)
│   ├── Player/                  (4 scripts)
│   ├── AI/                      (4 scripts)
│   ├── TurnSystem/              (3 scripts)
│   ├── Inventory/               (3 scripts)
│   ├── Procedural/              (4 scripts)
│   ├── Effects/                 (2 scripts)
│   ├── Multiplayer/             (3 scripts)
│   ├── Data/                    (2 scripts)
│   └── Utilities/               (3 scripts)
│
├── ScriptableObjects/
│   ├── GameConfig/
│   │   └── DefaultGameConfig.asset
│   ├── AIPersonalities/
│   │   ├── AggressiveAI.asset
│   │   ├── HelpfulAI.asset
│   │   └── NeutralAI.asset
│   └── Powers/ (optional)
│
├── Prefabs/
│   ├── GridCell.prefab
│   ├── Player.prefab
│   └── UI/
│       ├── TurnUI.prefab
│       └── InventoryPanel.prefab
│
└── Resources/
    └── Data/
        └── (save files will be generated here)
```

---

## 🚀 Quick Start Setup

### Step 1: Create Unity Project
1. Open Unity Hub
2. Create new project with Unity 2019.4 LTS
3. Select **3D** template
4. Name it "MysticGridJourney"

### Step 2: Install Dependencies
1. Install **TextMeshPro** (if not already installed):
   - Window → Package Manager
   - Search "TextMeshPro"
   - Click Install
   - Import TMP Essentials when prompted

### Step 3: Copy Scripts
1. Create the folder structure shown above in your Assets folder
2. Copy each script to its corresponding folder:

```
Core/
├── GameManager.cs
├── SceneTransitionManager.cs
└── GameConfig.cs

Grid/
├── GridManager.cs
├── GridCell.cs
├── GridGenerator.cs
└── GridEventHandler.cs

Player/
├── PlayerController.cs
├── PlayerData.cs
├── PlayerMovement.cs
└── PlayerCustomization.cs

AI/
├── AIController.cs
├── AIDecisionMaker.cs
├── AIPersonality.cs
└── AINameGenerator.cs

TurnSystem/
├── TurnManager.cs
├── DiceRoller.cs
└── TurnUIController.cs

Inventory/
├── InventoryManager.cs
├── PowerSystem.cs
└── InventoryUI.cs

Procedural/
├── ProceduralCharacter.cs
├── ProceduralMesh.cs
├── ProceduralTexture.cs
└── ProceduralAudio.cs

Effects/
├── FogSystem.cs
└── GridVisualEffects.cs

Multiplayer/
├── MultiplayerManager.cs
├── PlayerSlot.cs
└── NetworkingStub.cs

Data/
├── SaveSystem.cs
└── GameData.cs

Utilities/
├── EventBus.cs
├── Constants.cs
└── RandomHelper.cs
```

### Step 4: Create ScriptableObjects

#### A. Create GameConfig
1. In Unity: Right-click in Project → Create → MysticGrid → GameConfig
2. Name it "DefaultGameConfig"
3. Adjust values in Inspector:
   - Grid Count: 50-200
   - Max Players: 8
   - Move Speed: 3
   - Dice Range: 0-6
   - Event Probabilities (adjust as needed)

#### B. Create AI Personalities (Optional but Recommended)
1. Right-click → Create → MysticGrid → AIPersonality
2. Create three personalities:

**AggressiveAI:**
- Betrayal Chance: 0.7
- Helpful Chance: 0.1
- Power Usage: 0.8

**HelpfulAI:**
- Betrayal Chance: 0.1
- Helpful Chance: 0.7
- Power Usage: 0.4

**NeutralAI:**
- Betrayal Chance: 0.3
- Helpful Chance: 0.3
- Power Usage: 0.5

---

## 🏗️ Scene Setup

### Scene 1: GameScene (Main Gameplay)

#### Hierarchy Setup:
```
GameScene
├── GameManager (Empty GameObject)
│   └── Attach: GameManager.cs
│   └── References:
│       - Grid Manager → GridManager object
│       - Turn Manager → TurnManager object
│       - Multiplayer Manager → MultiplayerManager object
│       - Inventory Manager → InventoryManager object
│       - Fog System → FogSystem object
│       - Game Config → DefaultGameConfig asset
│
├── GridManager (Empty GameObject)
│   ├── GridGenerator (Child)
│   │   └── Attach: GridGenerator.cs
│   │   └── Reference: GameConfig
│   ├── GridEventHandler (Child)
│   │   └── Attach: GridEventHandler.cs
│   └── Attach: GridManager.cs
│       └── References:
│           - Grid Generator → GridGenerator child
│           - Event Handler → GridEventHandler child
│           - Grid Cell Prefab → GridCell prefab
│
├── TurnManager (Empty GameObject)
│   ├── DiceRoller (Child)
│   │   └── Attach: DiceRoller.cs
│   │   └── Reference: GameConfig
│   ├── TurnUI (Child - Canvas)
│   │   └── Attach: TurnUIController.cs
│   │   └── Setup UI elements (see UI section)
│   └── Attach: TurnManager.cs
│       └── References:
│           - Dice Roller → DiceRoller child
│           - Turn UI → TurnUIController
│
├── MultiplayerManager (Empty GameObject)
│   └── Attach: MultiplayerManager.cs
│       └── Reference: Player Prefab
│
├── InventoryManager (Empty GameObject)
│   ├── PowerSystem (Child)
│   │   └── Attach: PowerSystem.cs
│   ├── InventoryUI (Child - Canvas)
│   │   └── Attach: InventoryUI.cs
│   └── Attach: InventoryManager.cs
│
├── FogSystem (Empty GameObject)
│   └── Attach: FogSystem.cs
│       └── Reference: GameConfig
│
├── Main Camera
│   └── Position: (10, 20, 10)
│   └── Rotation: Look at origin
│
└── Directional Light
```

---

## 🎮 Prefab Setup

### 1. GridCell Prefab

1. Create a Cube primitive
2. Scale: (1, 0.1, 1)
3. Add GridCell.cs script
4. Save as Prefab in Prefabs/ folder

### 2. Player Prefab

```
Player (Empty GameObject)
├── Visual (Cube or custom mesh)
│   └── Add: ProceduralCharacter.cs
│       ├── ProceduralMesh (Child)
│       │   └── Attach: ProceduralMesh.cs
│       └── ProceduralTexture (Child)
│           └── Attach: ProceduralTexture.cs
├── Attach: PlayerController.cs
├── Attach: PlayerMovement.cs
└── Attach: PlayerCustomization.cs
```

---

## 🎨 UI Setup

### TurnUI Canvas
```
TurnUI (Canvas)
├── TurnText (TextMeshPro - Text)
│   └── Text: "Player's Turn"
├── DiceText (TextMeshPro - Text)
│   └── Text: "Rolled: 0"
├── SkipTurnPanel (Panel)
│   ├── SkipTurnText (TextMeshPro - Text)
│   └── Initially: Disabled
└── WinPanel (Panel)
    ├── WinText (TextMeshPro - Text)
    └── Initially: Disabled
```

### InventoryUI Canvas
```
InventoryUI (Canvas)
├── InventoryPanel (Panel)
│   ├── CoinsText (TextMeshPro - Text)
│   ├── PowerList (Vertical Layout Group)
│   │   └── PowerItemPrefab reference
│   └── CloseButton (Button)
└── Initially: Disabled
```

---

## ⚙️ Configuration Steps

### 1. Link GameManager References
In GameScene, select GameManager object:
- Drag GridManager → Grid Manager field
- Drag TurnManager → Turn Manager field
- Drag MultiplayerManager → Multiplayer Manager field
- Drag InventoryManager → Inventory Manager field
- Drag FogSystem → Fog System field
- Drag DefaultGameConfig asset → Game Config field

### 2. Configure GridManager
- Drag GridGenerator child → Grid Generator field
- Drag GridEventHandler child → Event Handler field
- Drag GridCell prefab → Grid Cell Prefab field

### 3. Configure TurnManager
- Drag DiceRoller child → Dice Roller field
- Drag TurnUIController → Turn UI field

### 4. Configure MultiplayerManager
- Drag Player prefab → Player Prefab field

### 5. Configure TurnUIController
- Drag TurnText → Turn Text field
- Drag DiceText → Dice Text field
- Drag SkipTurnPanel → Skip Turn Panel field
- Drag SkipTurnText → Skip Turn Text field
- Drag WinPanel → Win Panel field
- Drag WinText → Win Text field

---

## 🎯 Testing the Game

### Basic Test Sequence:

1. **Test Scene Load**
   ```csharp
   // In a test script or GameSceneController:
   GameManager.Instance.StartNewGame(100, 1, 3);
   ```

2. **Check Console for:**
   - "Grid Generated: 100"
   - Player names (Player_1, AI names)
   - Turn system starting

3. **Verify Gameplay:**
   - Dice rolls appear in UI
   - Players move along grid
   - Events trigger (coins, traps, powers)
   - Turn cycles through all players

---

## 🐛 Common Issues & Solutions

### Issue 1: "GameManager.Instance is null"
**Solution:** Ensure GameManager script is on a GameObject in the scene with all references assigned.

### Issue 2: "NullReferenceException in GridManager"
**Solution:** Check that GridCell prefab is assigned and has GridCell.cs script attached.

### Issue 3: "TextMeshPro namespace not found"
**Solution:** 
- Install TextMeshPro via Package Manager
- OR replace `TextMeshProUGUI` with `Text` in TurnUIController.cs and InventoryUI.cs

### Issue 4: Players not moving
**Solution:** 
- Check that GridCells have Colliders disabled (or are triggers)
- Verify moveSpeed > 0 in GameConfig
- Ensure GridGenerator is creating cells with proper positions

### Issue 5: AI not making decisions
**Solution:** 
- Verify AIController component is added to AI players
- Check that AIPersonality is assigned
- Ensure MultiplayerManager is creating AI correctly

---

## 📊 Script Dependencies

### Core Dependencies:
- **GameManager** depends on: All managers, GameConfig
- **All Scripts** depend on: EventBus (Utilities)

### Module Dependencies:
```
Grid ─────┐
Player ────┼──→ Core (GameManager, GameConfig)
AI ────────┤
Turn ──────┤
Inventory ─┘

Procedural → Player
Effects → Grid
Multiplayer → Player, AI
Data → All (for save/load)
```

---

## 🔧 Customization Guide

### Adding New Power Types:

1. **Edit PowerSystem.cs:**
```csharp
public enum PowerType
{
    None,
    Freeze,
    Teleport,
    MyNewPower  // Add here
}

// Then add method:
private void MyNewPowerEffect(PlayerController target)
{
    // Your logic here
}
```

2. **Update ExecutePower() switch statement**

### Adding New Grid Events:

1. **Edit GridCell.cs CellType enum**
2. **Add handler in GridEventHandler.cs**
3. **Update GridGenerator probability calculations**

### Changing Grid Layout:

Edit `GridGenerator.CalculateGridPosition()`:
```csharp
// Spiral pattern example:
float angle = i * 0.5f;
float radius = i * 0.2f;
float x = Mathf.Cos(angle) * radius;
float z = Mathf.Sin(angle) * radius;
```

---

## 📈 Performance Optimization

### For Large Grids (150+):
1. Enable object pooling for GridCells
2. Use LOD (Level of Detail) for distant cells
3. Frustum culling for off-screen cells

### Memory Management:
- Unsubscribe from EventBus in OnDestroy()
- Clear coroutines properly
- Use object pooling for frequently instantiated objects

---

## 🎓 Learning Path

### Beginner Start:
1. Study GameManager.cs → Entry point
2. Understand EventBus.cs → Communication
3. Follow TurnManager.cs → Game loop

### Intermediate:
1. Explore GridGenerator.cs → Procedural generation
2. Analyze AIDecisionMaker.cs → AI logic
3. Study SaveSystem.cs → Data persistence

### Advanced:
1. Extend ProceduralMesh.cs → Better character models
2. Implement NetworkingStub.cs → Online multiplayer
3. Optimize rendering → Performance tuning

---

## 📚 Next Steps

### Phase 1: Basic Setup ✓
- [x] Import all scripts
- [ ] Create GameConfig
- [ ] Build GridCell prefab
- [ ] Setup GameScene hierarchy

### Phase 2: Testing
- [ ] Test grid generation
- [ ] Test player movement
- [ ] Test turn system
- [ ] Test AI behavior

### Phase 3: Polish
- [ ] Add UI polish
- [ ] Implement procedural audio
- [ ] Create start menu
- [ ] Add win conditions

### Phase 4: Advanced
- [ ] Save/Load functionality
- [ ] Character customization UI
- [ ] Inventory UI refinement
- [ ] Network multiplayer (future)

---

## 🆘 Support & Resources

### Unity Documentation:
- [Unity 2019.4 LTS Docs](https://docs.unity3d.com/2019.4/Documentation/Manual/)
- [ScriptableObjects Guide](https://docs.unity3d.com/Manual/class-ScriptableObject.html)
- [Coroutines Tutorial](https://docs.unity3d.com/Manual/Coroutines.html)

### Code Architecture:
- **Singleton Pattern:** GameManager, SceneTransitionManager
- **Event System:** EventBus for decoupled communication
- **Strategy Pattern:** AIPersonality ScriptableObjects
- **Component Pattern:** Modular scripts per GameObject

---

## ✅ Checklist Before First Run

- [ ] All 35 scripts copied to correct folders
- [ ] TextMeshPro installed and imported
- [ ] DefaultGameConfig created and configured
- [ ] GameManager in scene with all references
- [ ] GridCell prefab created
- [ ] Player prefab created
- [ ] UI elements setup (TurnUI, InventoryUI)
- [ ] Camera positioned properly
- [ ] No compilation errors in Console

---

## 📝 Notes

- **Save Location:** Game saves to `Application.persistentDataPath/save.json`
- **Event Names:** Defined in Constants.cs
- **Multiplayer:** Currently local only; NetworkingStub prepared for future online
- **Procedural Generation:** Basic implementation; expand as needed

---

## 🎮 Example Game Flow

```
1. Game starts → GameManager.StartNewGame()
2. Grid generated → 100 cells with random events
3. Players spawned → 1 human + 3 AI
4. Turn loop begins → TurnManager cycles through players
5. Player turn:
   - Dice rolled (0-6)
   - Player moves
   - Cell event triggered
   - Check win condition
6. Next player's turn
7. Repeat until winner reaches end
```

---

**Version:** 1.0  
**Last Updated:** 2024  
**Status:** Ready for Development

**Good luck with your Mystic Grid Journey! 🎲✨**
