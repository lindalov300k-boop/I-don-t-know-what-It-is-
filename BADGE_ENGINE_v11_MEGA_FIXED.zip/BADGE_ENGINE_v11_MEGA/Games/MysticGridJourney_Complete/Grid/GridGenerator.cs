using BADGE.Core;
using OpenTK.Mathematics;
using System.Collections.Generic;

/// <summary>
/// Procedurally generates the game grid with random cell types
/// </summary>

namespace BADGE.Games.MysticGridJourney;

public class GridGenerator : MonoBehaviour
{
    public GameConfig config;

    /// <summary>
    /// Generates a complete grid with specified number of cells
    /// </summary>
    public List<GridCell> GenerateGrid(int cellCount, GameObject cellPrefab, Transform parent)
    {
        List<GridCell> cells = new List<GridCell>();
        
        for (int i = 0; i < cellCount; i++)
        {
            // Calculate position (can be linear, spiral, or custom pattern)
            Vector3 position = CalculateGridPosition(i);
            
            // Instantiate cell
            GameObject cellObj = Instantiate(cellPrefab, position, Quaternion.identity, parent);
            GridCell cell = cellObj.GetComponent<GridCell>();
            
            // Determine cell type
            CellType type = DetermineCellType(i, cellCount);
            
            // Initialize cell
            cell.Initialize(i, type, config);
            
            cells.Add(cell);
        }
        
        return cells;
    }

    /// <summary>
    /// Calculates the 3D position for a cell based on its index.
    /// Current implementation: Linear path (can be enhanced to spiral, snake, etc.)
    /// </summary>
    private Vector3 CalculateGridPosition(int index)
    {
        float x = (index % 10) * config.gridSpacing;
        float z = (index / 10) * config.gridSpacing;
        float y = config.gridHeight;
        
        return new Vector3(x, y, z);
    }

    /// <summary>
    /// Determines the type of cell based on configured probabilities
    /// </summary>
    private CellType DetermineCellType(int index, int totalCells)
    {
        // First cell is always empty
        if (index == 0) return CellType.Empty;
        
        // Last cell is always checkpoint
        if (index == totalCells - 1) return CellType.Checkpoint;
        
        // Random distribution based on config probabilities
        float roll = Random.value;
        
        if (roll < config.coinSpawnChance)
            return CellType.Coin;
        else if (roll < config.coinSpawnChance + config.trapSpawnChance)
            return CellType.Trap;
        else if (roll < config.coinSpawnChance + config.trapSpawnChance + config.powerSpawnChance)
            return CellType.Power;
        else if (roll < config.coinSpawnChance + config.trapSpawnChance + config.powerSpawnChance + config.animalSpawnChance)
            return CellType.Animal;
        else if (roll < config.coinSpawnChance + config.trapSpawnChance + config.powerSpawnChance + config.animalSpawnChance + config.checkpointSpawnChance)
            return CellType.Checkpoint;
        
        return CellType.Empty;
    }
}
