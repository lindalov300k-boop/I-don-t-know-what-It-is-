using BADGE.Core;
using OpenTK.Mathematics;
using System.Collections.Generic;

/// <summary>
/// Manages the game grid: generation, access, and event handling.
/// </summary>

namespace BADGE.Games.MysticGridJourney;

public class GridManager : MonoBehaviour
{
    // [Header("References")]
    public GridGenerator gridGenerator;
    public GridEventHandler eventHandler;
    public GameObject gridCellPrefab;

    // [Header("Runtime")]
    private List<GridCell> gridCells = new List<GridCell>();
    private Transform gridParent;

    public List<GridCell> GridCells => gridCells;

    private void Awake()
    {
        gridParent = new GameObject("GridParent").transform;
        gridParent.parent = transform;
    }

    /// <summary>
    /// Generates a new grid with specified number of cells
    /// </summary>
    public void GenerateGrid(int cellCount)
    {
        ClearGrid();
        gridCells = gridGenerator.GenerateGrid(cellCount, gridCellPrefab, gridParent);
        
        EventBus.Publish("GridGenerated", cellCount);
    }

    /// <summary>
    /// Gets a specific cell by its index
    /// </summary>
    public GridCell GetCellAtIndex(int index)
    {
        if (index >= 0 && index < gridCells.Count)
            return gridCells[index];
        return null;
    }

    /// <summary>
    /// Triggers the event associated with a cell when a player lands on it
    /// </summary>
    public void TriggerCellEvent(GridCell cell, PlayerController player)
    {
        eventHandler.HandleCellEvent(cell, player);
    }

    /// <summary>
    /// Clears all grid cells from the scene
    /// </summary>
    public void ClearGrid()
    {
        foreach (GridCell cell in gridCells)
        {
            if (cell != null)
                Destroy(cell.gameObject);
        }
        gridCells.Clear();
    }

    // Serialization methods for save system
    public List<GridCellData> SerializeGrid()
    {
        List<GridCellData> data = new List<GridCellData>();
        foreach (GridCell cell in gridCells)
        {
            data.Add(cell.Serialize());
        }
        return data;
    }

    public void DeserializeGrid(List<GridCellData> data)
    {
        ClearGrid();
        
        for (int i = 0; i < data.Count; i++)
        {
            GameObject cellObj = Instantiate(gridCellPrefab, gridParent);
            GridCell cell = cellObj.GetComponent<GridCell>();
            cell.Deserialize(data[i]);
            gridCells.Add(cell);
        }
    }
}
