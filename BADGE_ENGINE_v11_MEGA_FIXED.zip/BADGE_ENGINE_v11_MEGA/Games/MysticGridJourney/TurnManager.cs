using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using BADGE.Core.GameSystems;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Cycles through players turn by turn, rolls dice, and invokes each
    /// player's ExecuteTurn. Raises EventBus events for UI to react to.
    /// This class was referenced in the original project but not included in
    /// the source zip — fully implemented here.
    /// </summary>
    public class TurnManager
    {
        private List<PlayerController> _players = new();
        private int                    _turnIndex;
        private bool                   _running;
        private readonly Random        _rng = new();
        private readonly GameConfig    _config;

        public int  CurrentTurnIndex => _turnIndex;
        public bool IsRunning        => _running;

        public TurnManager(GameConfig config) => _config = config;

        // ── Start / stop ──────────────────────────────────────────────────
        public void StartTurns(List<PlayerController> players)
        {
            _players   = players;
            _turnIndex = 0;
            _running   = true;

            Console.WriteLine("[MysticGrid] Game started!");
            EventBus.Publish("TurnStarted", CurrentPlayer);

            // Fire-and-forget async loop
            _ = RunTurnLoop();
        }

        public void Stop() => _running = false;

        public void SetTurnIndex(int index) => _turnIndex = index;

        // ── Loop ──────────────────────────────────────────────────────────
        private async Task RunTurnLoop()
        {
            while (_running && _players.Count > 0)
            {
                var player = CurrentPlayer;

                // Check for winner (reached last cell)
                // (Grid cell count injected via event at game start)

                EventBus.Publish("TurnBegun", player);

                // Dice roll delay for drama
                await Task.Delay((int)(_config.DiceRollDelay * 1000));

                int roll = RollDice();
                Console.WriteLine($"[MysticGrid] {player.Data.PlayerName} rolled {roll}.");
                EventBus.Publish("DiceRolled", (player, roll));

                await player.ExecuteTurn(roll);

                EventBus.Publish("TurnEnded", player);

                // Check win condition
                if (IsWinner(player))
                {
                    Console.WriteLine($"[MysticGrid] 🎉 {player.Data.PlayerName} wins!");
                    EventBus.Publish("GameOver", player);
                    _running = false;
                    return;
                }

                AdvanceTurn();
                await Task.Delay(500);   // short breath between turns
            }
        }

        // ── Helpers ───────────────────────────────────────────────────────
        private int RollDice()
            => _rng.Next(_config.MinDiceRoll, _config.MaxDiceRoll + 1);

        private void AdvanceTurn()
        {
            _turnIndex = (_turnIndex + 1) % _players.Count;
            EventBus.Publish("TurnStarted", CurrentPlayer);
        }

        private bool IsWinner(PlayerController p)
            => p.Data.CurrentGridIndex >= _winCellIndex;

        private int _winCellIndex = int.MaxValue;

        /// <summary>Called by GameManager once the grid is built.</summary>
        public void SetWinCondition(int lastCellIndex)
            => _winCellIndex = lastCellIndex;

        public PlayerController? CurrentPlayer
            => _players.Count > 0 ? _players[_turnIndex % _players.Count] : null;

        // ── Leaderboard ───────────────────────────────────────────────────
        public List<PlayerController> GetLeaderboard()
        {
            var sorted = new List<PlayerController>(_players);
            sorted.Sort((a, b) =>
            {
                int posComp = b.Data.CurrentGridIndex.CompareTo(a.Data.CurrentGridIndex);
                return posComp != 0 ? posComp : b.Data.Coins.CompareTo(a.Data.Coins);
            });
            return sorted;
        }
    }
}
