using System;
using BADGE.Core;
using BADGE.Core.GameSystems;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Central coordinator: creates all sub-systems, wires them together,
    /// and drives the game loop.  Replaces Unity GameManager MonoBehaviour.
    ///
    /// Usage:
    ///   var gm = new MysticGameManager();
    ///   gm.StartNewGame(gridCount: 80, playerCount: 2, aiCount: 2);
    /// </summary>
    public class MysticGameManager
    {
        // ── Systems ───────────────────────────────────────────────────────
        public GameConfig          Config       { get; } = GameConfig.Default;
        public GridEventHandler    EventHandler { get; }
        public GridManager         Grid         { get; }
        public PowerSystem         Powers       { get; }
        public InventoryManager    Inventory    { get; }
        public MultiplayerManager  Players      { get; }
        public TurnManager         Turns        { get; }
        public FogSystem?          Fog          { get; private set; }

        // ── Singleton (optional — game code can also just hold a reference)
        public static MysticGameManager? Instance { get; private set; }

        public MysticGameManager()
        {
            Instance     = this;

            EventHandler = new GridEventHandler();
            Grid         = new GridManager(Config, EventHandler);
            Powers       = new PowerSystem(Grid);
            Inventory    = new InventoryManager(Powers);
            Players      = new MultiplayerManager(Config, Grid, Powers);
            Turns        = new TurnManager(Config);

            // Auto-save on checkpoint
            EventBus.Subscribe<PlayerController>("CheckpointReached", _ => SaveGame());

            // Wire leaderboard logging on game over
            EventBus.Subscribe<PlayerController>("GameOver", OnGameOver);
        }

        // ── Public API ────────────────────────────────────────────────────

        /// <summary>Start a fresh game.</summary>
        public void StartNewGame(int gridCount, int playerCount, int aiCount)
        {
            gridCount = Math.Clamp(gridCount, Config.MinGridCount, Config.MaxGridCount);

            Players.InitializePlayers(playerCount, aiCount);
            Grid.GenerateGrid(gridCount);
            Turns.SetWinCondition(gridCount - 1);
            Turns.StartTurns(Players.GetAllPlayers());

            // Attach fog to lead player
            var lead = Players.GetPlayerByIndex(0);
            if (lead != null)
            {
                var fogGo = new GameObject("FogPlane");
                Fog = fogGo.AddComponent<FogSystem>();
                Fog.Config = Config;
                Fog.SetPlayer(lead.Transform);
                Fog.Start();
            }

            // Register all players with inventory
            foreach (var p in Players.GetAllPlayers())
                Inventory.RegisterPlayer(p);

            EventBus.Publish("GameStarted", (playerCount, aiCount, gridCount));
            Console.WriteLine($"[MysticGrid] New game: {gridCount} cells, " +
                              $"{playerCount} human + {aiCount} AI players.");
        }

        /// <summary>Load a previously saved game.</summary>
        public void LoadGame()
        {
            var data = MysticSaveSystem.Load();
            if (data == null) return;

            Grid.DeserializeGrid(data.GridCells, Config);
            Players.DeserializePlayers(data.Players);
            Turns.SetTurnIndex(data.CurrentTurn);
            Turns.SetWinCondition(data.GridCount - 1);
            Turns.StartTurns(Players.GetAllPlayers());

            Console.WriteLine("[MysticGrid] Game loaded.");
        }

        /// <summary>Save current state.</summary>
        public void SaveGame()
        {
            MysticSaveSystem.Save(new MysticGameData
            {
                GridCells   = Grid.SerializeGrid(),
                Players     = Players.SerializePlayers(),
                CurrentTurn = Turns.CurrentTurnIndex,
                GridCount   = Grid.CellCount
            });
        }

        // ── Internal ──────────────────────────────────────────────────────
        private void OnGameOver(PlayerController winner)
        {
            Console.WriteLine($"\n[MysticGrid] ══ GAME OVER ══");
            int rank = 1;
            foreach (var p in Turns.GetLeaderboard())
                Console.WriteLine($"  #{rank++}  {p.Data.PlayerName,-18}  " +
                                  $"cell {p.Data.CurrentGridIndex,3}  " +
                                  $"coins {p.Data.Coins,4}");
        }

        // ── Per-frame update (hook into BADGE Engine.Update) ──────────────
        public void Update(float dt)
        {
            Fog?.Update(dt);

            // Update fog position to follow current turn player
            var current = Turns.CurrentPlayer;
            if (current != null)
                Fog?.SetPlayer(current.Transform);
        }
    }
}
