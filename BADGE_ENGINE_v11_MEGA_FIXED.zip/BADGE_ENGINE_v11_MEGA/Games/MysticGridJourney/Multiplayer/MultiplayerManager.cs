using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.GameSystems;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Creates human and AI PlayerControllers for a game session.
    /// Replaces Unity MultiplayerManager MonoBehaviour.
    /// </summary>
    public class MultiplayerManager
    {
        private readonly List<PlayerSlot>        _slots   = new();
        private readonly List<PlayerController>  _players = new();
        private readonly GameConfig              _config;
        private readonly GridManager             _grid;
        private readonly PowerSystem             _powers;
        private readonly Random                  _rng     = new();

        public MultiplayerManager(GameConfig config, GridManager grid, PowerSystem powers)
        {
            _config = config;
            _grid   = grid;
            _powers = powers;
        }

        // ── Setup ─────────────────────────────────────────────────────────
        public void InitializePlayers(int humanCount, int aiCount)
        {
            ClearPlayers();

            for (int i = 0; i < humanCount; i++)
                CreatePlayer($"Player_{i + 1}", false, i);

            for (int i = 0; i < aiCount; i++)
            {
                string name = AINameGenerator.GenerateRandomName();
                CreatePlayer(name, true, humanCount + i);
            }

            // Inject back-references so AI can see all players
            foreach (var p in _players)
                if (p.AI != null)
                {
                    p.AI.Players = this;
                    p.AI.Powers  = _powers;
                }

            EventBus.Publish("PlayersInitialized", _players);
        }

        // ── Player creation ───────────────────────────────────────────────
        private void CreatePlayer(string name, bool isAI, int slotIndex)
        {
            var go = new GameObject(name);
            var ctrl = go.AddComponent<PlayerController>();
            ctrl.IsAI = isAI;

            var personality = isAI
                ? AIPersonality.Random(_rng)
                : AIPersonality.Balanced;

            ctrl.Initialize(name, isAI, 0, _grid, _config, personality);

            // Procedural character mesh
            var procChar = go.AddComponent<ProceduralCharacter>();
            procChar.GenerateCharacter(ctrl.Data.Customization);

            var slot = new PlayerSlot(slotIndex);
            slot.AssignPlayer(ctrl, isAI);
            _slots.Add(slot);
            _players.Add(ctrl);
        }

        // ── Accessors ─────────────────────────────────────────────────────
        public List<PlayerController> GetAllPlayers()   => _players;
        public int                    PlayerCount       => _players.Count;

        public PlayerController? GetPlayerByName(string name)
            => _players.Find(p => p.Data.PlayerName == name);

        public PlayerController? GetPlayerByIndex(int i)
            => i >= 0 && i < _players.Count ? _players[i] : null;

        // ── Cleanup ───────────────────────────────────────────────────────
        private void ClearPlayers()
        {
            foreach (var p in _players) p.GameObject?.Destroy();
            _players.Clear();
            _slots.Clear();
        }

        // ── Serialisation ─────────────────────────────────────────────────
        public List<PlayerData> SerializePlayers()
        {
            var data = new List<PlayerData>(_players.Count);
            foreach (var p in _players) data.Add(p.Data);
            return data;
        }

        public void DeserializePlayers(List<PlayerData> data)
        {
            ClearPlayers();
            foreach (var d in data)
            {
                CreatePlayer(d.PlayerName, false, _players.Count);
                _players[^1].Data = d;
            }
        }
    }

    // ── PlayerSlot ────────────────────────────────────────────────────────
    public class PlayerSlot
    {
        public int               SlotIndex   { get; }
        public bool              IsOccupied  { get; private set; }
        public bool              IsAI        { get; private set; }
        public PlayerController? Player      { get; private set; }
        public string            ConnectionToken { get; set; } = ""; // future online use

        public PlayerSlot(int index) => SlotIndex = index;

        public void AssignPlayer(PlayerController ctrl, bool ai)
        {
            Player     = ctrl;
            IsOccupied = true;
            IsAI       = ai;
        }

        public void Clear() { Player = null; IsOccupied = false; IsAI = false; }
    }
}
