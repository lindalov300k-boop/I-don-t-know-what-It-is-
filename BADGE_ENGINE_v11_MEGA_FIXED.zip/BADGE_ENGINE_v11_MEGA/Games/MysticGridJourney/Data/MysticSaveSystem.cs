using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace BADGE.Games.MysticGridJourney
{
    // ── Save data container ───────────────────────────────────────────────
    [Serializable]
    public class MysticGameData
    {
        public List<GridCellData> GridCells   { get; set; } = new();
        public List<PlayerData>   Players     { get; set; } = new();
        public int                CurrentTurn { get; set; }
        public string             Timestamp   { get; set; } = DateTime.Now.ToString("O");
        public int                GridCount   { get; set; }
    }

    // ── Save / Load ───────────────────────────────────────────────────────
    public static class MysticSaveSystem
    {
        private static string SavePath =>
            Path.Combine("Saves", "MysticGridJourney.json");

        public static void Save(MysticGameData data)
        {
            Directory.CreateDirectory("Saves");
            File.WriteAllText(SavePath,
                JsonConvert.SerializeObject(data, Formatting.Indented));
            Console.WriteLine($"[MysticGrid] Game saved to {SavePath}");
        }

        public static MysticGameData? Load()
        {
            if (!File.Exists(SavePath))
            {
                Console.WriteLine("[MysticGrid] No save file found.");
                return null;
            }

            try
            {
                var data = JsonConvert.DeserializeObject<MysticGameData>(
                    File.ReadAllText(SavePath));
                Console.WriteLine("[MysticGrid] Game loaded successfully.");
                return data;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[MysticGrid] Failed to load save: {ex.Message}");
                return null;
            }
        }

        public static bool SaveExists() => File.Exists(SavePath);

        public static void DeleteSave()
        {
            if (File.Exists(SavePath)) File.Delete(SavePath);
            Console.WriteLine("[MysticGrid] Save deleted.");
        }
    }
}
