using System;
using OpenTK.Mathematics;
using OpenTK.Graphics.OpenGL4;
using BADGE.Core;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Manages a large translucent quad above the board that slowly regenerates
    /// and is locally cleared around the active player, mimicking fog of war.
    /// Replaces Unity FogSystem MonoBehaviour.
    /// </summary>
    public class FogSystem : Component
    {
        private GameConfig  _config       = GameConfig.Default;
        public  GameConfig  Config        { get => _config; set { _config = value; _currentAlpha = value.FogColor.A; } }
        private float       _currentAlpha;
        private Transform?  _playerTransform;

        // GL resources
        private int _vao, _vbo, _ibo;
        private int _shaderHandle;
        private bool _initialized;

        public void SetPlayer(Transform? t) => _playerTransform = t;

        // ── Lifecycle ─────────────────────────────────────────────────────
        public override void Start()
        {
            BuildFogQuad();
            _initialized = true;
        }

        public override void Update(float dt)
        {
            if (!_initialized || _playerTransform == null) return;

            // Follow player (x/z) at a fixed y above the board
            float fogY = _config.GridHeight + 1f;
            Transform.Position = new Vector3(
                _playerTransform.Position.X,
                fogY,
                _playerTransform.Position.Z);

            // Gradually regenerate fog density
            float target = _config.FogColor.A;
            _currentAlpha = MathHelper.Clamp(
                _currentAlpha + _config.FogRegenerationRate * dt,
                0f, target);
        }

        /// <summary>
        /// Temporarily thin the fog around a world position (e.g., player is there).
        /// </summary>
        public void DissipateAt(Vector3 position, float radius)
        {
            _currentAlpha = MathF.Max(0f, _currentAlpha - 0.2f);
        }

        public Color4 CurrentColor =>
            new(_config.FogColor.R, _config.FogColor.G, _config.FogColor.B, _currentAlpha);

        // ── GL quad ───────────────────────────────────────────────────────
        private void BuildFogQuad()
        {
            float s = 50f; // 50-unit wide quad
            float[] verts =
            {
                -s, 0f, -s,   0f, 1f,
                 s, 0f, -s,   1f, 1f,
                 s, 0f,  s,   1f, 0f,
                -s, 0f,  s,   0f, 0f
            };
            int[] indices = { 0, 1, 2, 0, 2, 3 };

            _vao = GL.GenVertexArray();
            _vbo = GL.GenBuffer();
            _ibo = GL.GenBuffer();

            GL.BindVertexArray(_vao);
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
            GL.BufferData(BufferTarget.ArrayBuffer, verts.Length * 4, verts,
                          BufferUsageHint.StaticDraw);
            GL.BindBuffer(BufferTarget.ElementArrayBuffer, _ibo);
            GL.BufferData(BufferTarget.ElementArrayBuffer, indices.Length * 4, indices,
                          BufferUsageHint.StaticDraw);

            // Position (loc 0)
            GL.EnableVertexAttribArray(0);
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 20, 0);
            // UV (loc 1)
            GL.EnableVertexAttribArray(1);
            GL.VertexAttribPointer(1, 2, VertexAttribPointerType.Float, false, 20, 12);

            GL.BindVertexArray(0);
        }

        // ── Render (called from scene Render pass) ────────────────────────
        public void Render(Matrix4 view, Matrix4 projection)
        {
            if (!_initialized) return;

            GL.Enable(EnableCap.Blend);
            GL.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);

            var shader = BADGE.Core.ShaderLibrary.GetShader("Sprite2D");
            if (shader == null) return;

            shader.Use();
            Matrix4 model = Matrix4.CreateTranslation(Transform.Position);
            shader.SetMatrix4("model",      model);
            shader.SetMatrix4("view",       view);
            shader.SetMatrix4("projection", projection);
            shader.SetVector4("_Color",     new Vector4(
                CurrentColor.R, CurrentColor.G, CurrentColor.B, CurrentColor.A));

            GL.BindVertexArray(_vao);
            GL.DrawElements(PrimitiveType.Triangles, 6, DrawElementsType.UnsignedInt, 0);
            GL.BindVertexArray(0);
            shader.Unuse();
            GL.Disable(EnableCap.Blend);
        }
    }
}
