using System;
using System.Collections.Generic;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// All data for one player — grid position, coins, powers, status flags.
    /// Pure C# with no engine dependency; serialisable to JSON.
    /// </summary>
    [Serializable]
    public class PlayerData
    {
        public string         PlayerName           { get; set; } = "";
        public int            CurrentGridIndex     { get; set; } = 0;
        public int            Coins                { get; set; } = 0;
        public int            LastCheckpointIndex  { get; set; } = 0;
        public bool           SkipNextTurn         { get; set; } = false;
        public int            ExtraStepsNextTurn   { get; set; } = 0;
        public bool           IsShielded           { get; set; } = false;
        public List<PowerType> Powers              { get; set; } = new();
        public CharacterCustomization Customization { get; set; } = new();

        // ── Coin helpers ──────────────────────────────────────────────────
        public void AddCoins(int amount) => Coins += amount;

        public bool SpendCoins(int amount)
        {
            if (Coins < amount) return false;
            Coins -= amount;
            return true;
        }

        // ── Power helpers ─────────────────────────────────────────────────
        public void AddPower(PowerType power) => Powers.Add(power);

        public bool UsePower(PowerType power)
        {
            if (!Powers.Contains(power)) return false;
            Powers.Remove(power);
            return true;
        }

        public bool HasPower(PowerType power) => Powers.Contains(power);
    }

    // ── Enums ─────────────────────────────────────────────────────────────
    public enum PowerType { None, Freeze, Teleport, MultiplySteps, StealCoins, Shield }

    public enum Gender { Male, Female, NonBinary }

    // ── Character customization ───────────────────────────────────────────
    [Serializable]
    public class CharacterCustomization
    {
        public Gender Gender         { get; set; } = Gender.NonBinary;
        public int    SkinColorIndex { get; set; } = 0;
        public int    HairStyleIndex { get; set; } = 0;
        public int    HairColorIndex { get; set; } = 0;
        public int    ClothingIndex  { get; set; } = 0;
    }
}
