namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Triggers visual effects on cells.
    /// Pulse animation is handled by GridCell.Update().
    /// </summary>
    public class GridVisualEffects
    {
        public void HighlightCell(GridCell cell)   => cell.Highlight(true);
        public void RemoveHighlight(GridCell cell) => cell.Highlight(false);

        /// <summary>Start a brief scale pulse on the cell.</summary>
        public void PlayCellActivationEffect(GridCell cell) => cell.StartPulse();
    }
}
