using BADGE.Core;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Bootstraps the MysticGridJourney game scene in BADGE Engine.
    /// Register with BADGE.Core.SceneManager.RegisterScene("MysticGrid", new MysticGridScene())
    /// then call SceneManager.LoadScene("MysticGrid").
    /// </summary>
    public class MysticGridScene : BADGE.Core.Scene
    {
        private MysticGameManager? _gm;

        public MysticGridScene() : base("MysticGrid") { }

        public override void OnLoad()
        {
            // Default match: 80 cells, 1 human, 3 AI
            _gm = new MysticGameManager();
            _gm.StartNewGame(
                gridCount:   80,
                playerCount: 1,
                aiCount:     3);
        }

        public override void OnUpdate(float dt)
        {
            _gm?.Update(dt);
            InventoryUI.Render();
        }

        public override void OnUnload()
        {
            _gm = null;
        }

        // ── Helper: launch from anywhere ─────────────────────────────────
        public static void Launch()
        {
            var scene = new MysticGridScene();
            BADGE.Core.SceneManager.Instance?.RegisterScene(scene);
            BADGE.Core.SceneManager.Instance?.LoadScene("MysticGrid");
        }
    }
}
