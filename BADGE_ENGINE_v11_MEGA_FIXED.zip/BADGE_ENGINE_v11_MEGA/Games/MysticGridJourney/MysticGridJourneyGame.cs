using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;
using BADGE.Core;

namespace BADGE.Games.MysticGridJourney
{
    // ═══════════════════════════════════════════════════════════════════════════
    //  MYSTIC GRID JOURNEY  —  BADGE Engine v8 conversion
    //
    //  Original: Unity board game — Monopoly Go / Mario Party style.
    //  Players (human + AI) take turns rolling dice and landing on grid cells.
    //  Each cell triggers an event (gain coins, lose coins, battle, etc.).
    //  AI personality system generates unique names and playstyles.
    //  Multiplayer-ready (local hot-seat + networked stub).
    //
    //  BADGE conversion: all Unity APIs → BADGE/OpenTK.
    //  Gamepad: hot-seat multiplayer — each player uses a controller slot.
    // ═══════════════════════════════════════════════════════════════════════════

    // ─────────────────────────────── Enums ────────────────────────────────────
    public enum CellType
    {
        Normal, GainCoins, LoseCoins, Battle, Shortcut,
        Trap, BonusRoll, Shop, Safe, Start, End
    }

    public enum AIPersonalityType { Aggressive, Defensive, Random, Strategic }
    public enum TodoPriority { Low, Normal, High, Critical }

    // ─────────────────────────────── Data classes ─────────────────────────────
    [Serializable]
    public class PlayerData
    {
        public string PlayerName     = "Player";
        public int    CurrentCell    = 0;
        public int    Coins          = 100;
        public int    Stars          = 0;
        public int    Laps           = 0;
        public int    GamesWon       = 0;
        public bool   IsEliminated   = false;
        public List<string> Inventory = new();
    }

    [Serializable]
    public class GridCellData
    {
        public int      Index;
        public CellType Type;
        public int      CoinValue;
        public string   EventText = "";
        public Vector3  WorldPos;
    }

    [Serializable]
    public class MGJSaveData
    {
        public List<GridCellData>  GridCells  = new();
        public List<PlayerData>    Players    = new();
        public int                 CurrentTurn = 0;
        public int                 TurnNumber  = 0;
        public int                 MaxTurns    = 20;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  GameConfig
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJGameConfig : MonoBehaviour
    {
        public int   GridCellCount  = 40;
        public int   StartingCoins  = 100;
        public int   MaxTurns       = 20;
        public float CellSpacing    = 2.0f;
        public float GridRadius     = 10f;
        public bool  AllowNetworking = false;

        // Cell type distribution (must sum to 1)
        public float NormalChance    = 0.30f;
        public float GainChance      = 0.20f;
        public float LoseChance      = 0.15f;
        public float BattleChance    = 0.10f;
        public float ShortcutChance  = 0.05f;
        public float TrapChance      = 0.10f;
        public float BonusRollChance = 0.05f;
        public float ShopChance      = 0.05f;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  GridCell
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJGridCell : MonoBehaviour
    {
        public int      Index;
        public CellType Type     = CellType.Normal;
        public int      CoinValue = 0;
        public string   EventText = "";

        // Visual state
        private float _highlightTimer;
        private bool  _isHighlighted;

        public override void Update()
        {
            if (_isHighlighted)
            {
                _highlightTimer += Time.DeltaTime * 3f;
                float pulse = (MathF.Sin(_highlightTimer) + 1f) * 0.5f;
                Transform.Scale = new Vector3(1f + pulse * 0.1f);
            }
        }

        public void Highlight()  { _isHighlighted = true;  _highlightTimer = 0f; }
        public void Unhighlight(){ _isHighlighted = false; Transform.Scale = Vector3.One; }

        public GridCellData Serialize() => new()
        {
            Index = Index, Type = Type, CoinValue = CoinValue,
            EventText = EventText, WorldPos = Transform.Position
        };

        public Vector3 CellColor => Type switch
        {
            CellType.GainCoins  => new(0.2f, 0.8f, 0.2f),
            CellType.LoseCoins  => new(0.8f, 0.2f, 0.2f),
            CellType.Battle     => new(0.9f, 0.4f, 0.1f),
            CellType.Shortcut   => new(0.2f, 0.6f, 0.9f),
            CellType.Trap       => new(0.6f, 0.1f, 0.8f),
            CellType.BonusRoll  => new(0.9f, 0.8f, 0.1f),
            CellType.Shop       => new(0.3f, 0.9f, 0.7f),
            CellType.Safe       => new(0.8f, 0.8f, 0.9f),
            CellType.Start      => new(0.1f, 0.9f, 0.5f),
            CellType.End        => new(1.0f, 0.8f, 0.0f),
            _                   => new(0.5f, 0.5f, 0.6f),
        };
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  GridGenerator — lays cells in a circle
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJGridGenerator : MonoBehaviour
    {
        private readonly Random _rng = new();

        public List<MGJGridCell> Generate(int count, float radius, MGJGameConfig cfg)
        {
            var cells = new List<MGJGridCell>();
            for (int i = 0; i < count; i++)
            {
                float angle = i / (float)count * MathF.PI * 2f;
                Vector3 pos = new(MathF.Cos(angle) * radius, 0f, MathF.Sin(angle) * radius);

                var go   = new BADGE.Core.GameObject($"Cell_{i}");
                var cell = go.AddComponent<MGJGridCell>();
                cell.Index     = i;
                cell.Type      = i == 0 ? CellType.Start : i == count - 1 ? CellType.End
                                         : RollCellType(cfg);
                cell.CoinValue = cell.Type switch
                {
                    CellType.GainCoins => 10 + _rng.Next(0, 31),
                    CellType.LoseCoins => -(5 + _rng.Next(0, 21)),
                    _                  => 0
                };
                cell.EventText = GetEventText(cell.Type);
                go.Transform.Position = pos;
                cells.Add(cell);
            }
            return cells;
        }

        private CellType RollCellType(MGJGameConfig cfg)
        {
            float r = (float)_rng.NextDouble();
            float acc = 0;
            if ((acc += cfg.GainChance)   > r) return CellType.GainCoins;
            if ((acc += cfg.LoseChance)   > r) return CellType.LoseCoins;
            if ((acc += cfg.BattleChance) > r) return CellType.Battle;
            if ((acc += cfg.ShortcutChance)>r) return CellType.Shortcut;
            if ((acc += cfg.TrapChance)   > r) return CellType.Trap;
            if ((acc += cfg.BonusRollChance)>r)return CellType.BonusRoll;
            if ((acc += cfg.ShopChance)   > r) return CellType.Shop;
            return CellType.Normal;
        }

        private string GetEventText(CellType t) => t switch
        {
            CellType.GainCoins  => "Found treasure! Gain coins.",
            CellType.LoseCoins  => "Thief! Lose coins.",
            CellType.Battle     => "Battle! Roll highest to win coins.",
            CellType.Shortcut   => "Secret path! Skip forward 5 cells.",
            CellType.Trap       => "Trap! Miss next turn.",
            CellType.BonusRoll  => "Lucky! Roll again.",
            CellType.Shop       => "Mystic Shop. Buy an item.",
            CellType.Safe       => "Safe zone. Breathe easy.",
            _                   => "",
        };
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  DiceRoller
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJDiceRoller : MonoBehaviour
    {
        public static int Roll(int sides = 6)   => new Random().Next(1, sides + 1);
        public static int RollDouble()          => Roll() + Roll();
        public static int RollWithBonus(int b)  => Roll() + b;

        // Animated roll — returns result after animation frames
        public IEnumerator RollAnimated(int sides, Action<int> onDone)
        {
            int result = Roll(sides);
            // Simulate rapid number flicker for 0.6s
            float elapsed = 0f;
            while (elapsed < 0.6f)
            {
                elapsed += Time.DeltaTime;
                MGJGameUI.Instance?.ShowDiceFlicker(Roll(sides));
                yield return null;
            }
            MGJGameUI.Instance?.ShowDiceResult(result);
            onDone(result);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  AI Name Generator — procedural NPC names
    // ═══════════════════════════════════════════════════════════════════════════
    public static class AINameGenerator
    {
        static readonly string[] Prefixes = { "Lord","Lady","Dark","Bright","Wild","Iron","Silver","Storm" };
        static readonly string[] Names    = { "Aether","Vex","Nox","Zara","Kael","Mira","Oryn","Dusk" };
        static readonly string[] Suffixes = { "","the Wise","the Bold","of the Void","the Swift","Reborn","Prime","Infinite" };
        static readonly Random   _rng     = new();

        public static string Generate()
        {
            string prefix = _rng.NextDouble() > 0.5 ? Prefixes[_rng.Next(Prefixes.Length)] + " " : "";
            string name   = Names[_rng.Next(Names.Length)];
            string suffix = _rng.NextDouble() > 0.6 ? " " + Suffixes[_rng.Next(1, Suffixes.Length)] : "";
            return prefix + name + suffix;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  AI Personality
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJAIPersonality
    {
        public AIPersonalityType Type;
        public float Aggression;   // 0-1
        public float Caution;      // 0-1
        public float Greed;        // 0-1
        public string Description;

        public static MGJAIPersonality Generate(Random rng = null)
        {
            rng ??= new Random();
            var type = (AIPersonalityType)rng.Next(4);
            return type switch
            {
                AIPersonalityType.Aggressive => new() { Type=type, Aggression=0.9f, Caution=0.1f, Greed=0.7f, Description="Seeks battles and risky moves." },
                AIPersonalityType.Defensive  => new() { Type=type, Aggression=0.2f, Caution=0.9f, Greed=0.3f, Description="Avoids danger, conserves coins." },
                AIPersonalityType.Strategic  => new() { Type=type, Aggression=0.5f, Caution=0.6f, Greed=0.8f, Description="Calculates optimal paths." },
                _                            => new() { Type=type, Aggression=(float)rng.NextDouble(), Caution=(float)rng.NextDouble(), Greed=(float)rng.NextDouble(), Description="Unpredictable." },
            };
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  AIController
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJAIController : MonoBehaviour
    {
        public MGJAIPersonality Personality;
        private readonly Random _rng = new();

        public void MakeDecision(MGJPlayer player, List<MGJGridCell> cells)
        {
            // Aggressive AI: always roll max
            // Defensive AI: prefer safe cells
            // Strategic AI: looks ahead
            // Applied post-roll as cell choice if branching

            if (Personality.Type == AIPersonalityType.Aggressive)
            {
                // Buy battle items from shop if on shop cell
                var cell = cells.ElementAtOrDefault(player.Data.CurrentCell);
                if (cell?.Type == CellType.Shop && player.Data.Coins >= 20)
                {
                    player.Data.Coins -= 20;
                    player.Data.Inventory.Add("Battle Boost");
                    MGJGameUI.Instance?.ShowEvent($"{player.Data.PlayerName} bought Battle Boost!");
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  Player entity
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJPlayer : MonoBehaviour
    {
        public PlayerData Data   = new();
        public bool       IsAI  = false;
        public MGJAIController AI;
        public MGJAIPersonality Personality;
        public bool SkipNextTurn = false;

        private List<MGJGridCell> _cells;
        private float _moveProgress;
        private int   _moveTarget;
        private bool  _moving;

        public void Init(List<MGJGridCell> cells) => _cells = cells;

        // ── Execute turn (coroutine-style) ────────────────────────────────────
        public IEnumerator ExecuteTurn(int steps)
        {
            if (SkipNextTurn)
            {
                SkipNextTurn = false;
                MGJGameUI.Instance?.ShowEvent($"{Data.PlayerName} is trapped — skip turn!");
                yield break;
            }

            // AI pre-decision
            if (IsAI) AI?.MakeDecision(this, _cells);

            // Advance cell index
            int targetIndex = (Data.CurrentCell + steps) % _cells.Count;
            if (targetIndex < Data.CurrentCell) Data.Laps++;

            // Animate movement
            yield return MoveToCell(targetIndex);

            // Apply cell event
            var cell = _cells[targetIndex];
            Data.CurrentCell = targetIndex;
            ApplyCellEvent(cell);
        }

        private IEnumerator MoveToCell(int targetIndex)
        {
            // Step through each cell on the way
            int current = Data.CurrentCell;
            int total   = (targetIndex - current + _cells.Count) % _cells.Count;

            for (int step = 0; step < total; step++)
            {
                int nextIdx = (current + 1) % _cells.Count;
                Vector3 from = Transform.Position;
                Vector3 to   = _cells[nextIdx].Transform.Position + new Vector3(0, 0.5f, 0);

                float t = 0f;
                while (t < 1f)
                {
                    t += Time.DeltaTime * 4f;
                    Transform.Position = Vector3.Lerp(from, to, MathHelper.Clamp(t, 0f, 1f));
                    yield return null;
                }
                current = nextIdx;
            }
        }

        private void ApplyCellEvent(MGJGridCell cell)
        {
            string msg = "";
            switch (cell.Type)
            {
                case CellType.GainCoins:
                    Data.Coins += cell.CoinValue;
                    msg = $"{Data.PlayerName} gains {cell.CoinValue} coins! (Total: {Data.Coins})";
                    break;
                case CellType.LoseCoins:
                    Data.Coins = Math.Max(0, Data.Coins + cell.CoinValue); // CoinValue is negative
                    msg = $"{Data.PlayerName} loses {-cell.CoinValue} coins. (Total: {Data.Coins})";
                    break;
                case CellType.Battle:
                    ResolveBattle();
                    return;
                case CellType.Shortcut:
                    int skip = Math.Min(5, _cells.Count - Data.CurrentCell - 1);
                    Data.CurrentCell += skip;
                    msg = $"{Data.PlayerName} takes a shortcut! +{skip} cells.";
                    break;
                case CellType.Trap:
                    SkipNextTurn = true;
                    msg = $"{Data.PlayerName} is trapped! Miss next turn.";
                    break;
                case CellType.BonusRoll:
                    msg = $"{Data.PlayerName} gets a bonus roll!";
                    // Handled by TurnManager
                    break;
                case CellType.Shop:
                    msg = $"{Data.PlayerName} visits the Mystic Shop.";
                    break;
                case CellType.End:
                    Data.Stars++;
                    Data.CurrentCell = 0;
                    msg = $"{Data.PlayerName} completes a lap! Stars: {Data.Stars}";
                    break;
                default:
                    if (!string.IsNullOrEmpty(cell.EventText))
                        msg = $"{Data.PlayerName}: {cell.EventText}";
                    break;
            }
            if (!string.IsNullOrEmpty(msg))
                MGJGameUI.Instance?.ShowEvent(msg);
        }

        private void ResolveBattle()
        {
            var players = FindObjectsOfType<MGJPlayer>();
            int myRoll  = MGJDiceRoller.Roll(6) + (Data.Inventory.Contains("Battle Boost") ? 3 : 0);
            int bestRoll = 0;
            MGJPlayer winner = this;

            foreach (var p in players)
            {
                if (p == this) continue;
                int theirRoll = MGJDiceRoller.Roll(6);
                if (theirRoll > bestRoll) { bestRoll = theirRoll; winner = p; }
            }

            if (myRoll >= bestRoll) winner = this;

            int prize = 20;
            foreach (var p in players)
            {
                if (p != winner) { p.Data.Coins = Math.Max(0, p.Data.Coins - prize); }
            }
            winner.Data.Coins += prize * (players.Length - 1);
            MGJGameUI.Instance?.ShowEvent($"Battle! {winner.Data.PlayerName} wins {prize*(players.Length-1)} coins!");
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  TurnManager
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJTurnManager : MonoBehaviour
    {
        public int  CurrentTurnIndex { get; private set; }
        public int  TurnNumber       { get; private set; }
        public bool GameOver         { get; private set; }

        private List<MGJPlayer> _players;
        private MGJGameConfig   _cfg;
        private bool            _turnInProgress;

        public void Init(List<MGJPlayer> players, MGJGameConfig cfg)
        {
            _players = players;
            _cfg     = cfg;
        }

        public void SetTurnIndex(int idx) => CurrentTurnIndex = idx;

        public override void Update()
        {
            if (_turnInProgress || GameOver || _players == null) return;

            var cur = _players[CurrentTurnIndex];

            // Human: wait for input (Space / gamepad A)
            bool rollPressed = !cur.IsAI &&
                               (Input.GetKeyDown(Keys.Space) ||
                                GamepadInput.Get(CurrentTurnIndex).GetButtonDown(GamepadButton.A));

            // AI: auto-roll after delay
            bool aiReady = cur.IsAI;

            if (rollPressed || aiReady)
            {
                _turnInProgress = true;
                MGJCoroutineRunner.Start(DoTurn(cur));
            }
        }

        private IEnumerator DoTurn(MGJPlayer player)
        {
            MGJGameUI.Instance?.SetActivePlayer(player.Data.PlayerName);

            // Dice animation + roll
            int roll = 0;
            yield return new MGJDiceRoller().RollAnimated(6, r => roll = r);

            // Execute turn
            yield return player.ExecuteTurn(roll);

            // Bonus roll?
            var cell = FindObjectsOfType<MGJGridCell>()
                       .FirstOrDefault(c => c.Index == player.Data.CurrentCell);
            if (cell?.Type == CellType.BonusRoll)
            {
                int bonus = 0;
                yield return new MGJDiceRoller().RollAnimated(6, r => bonus = r);
                yield return player.ExecuteTurn(bonus);
            }

            Advance();
        }

        private void Advance()
        {
            TurnNumber++;
            CurrentTurnIndex = (CurrentTurnIndex + 1) % _players.Count;
            _turnInProgress = false;

            if (TurnNumber >= _cfg.MaxTurns)
            {
                GameOver = true;
                MGJGameManager.Instance?.EndGame(_players);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  Multiplayer  (local hot-seat + networking stub)
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJMultiplayerManager : MonoBehaviour
    {
        private readonly List<MGJPlayer> _players = new();
        private readonly Random _rng = new();

        public List<MGJPlayer> GetAllPlayers() => _players;

        public void InitializePlayers(int humanCount, int aiCount)
        {
            _players.Clear();
            string[] playerColors = { "Blue","Red","Green","Yellow" };

            for (int i = 0; i < humanCount && i < 4; i++)
            {
                var go     = new BADGE.Core.GameObject($"HumanPlayer_{i+1}");
                var player = go.AddComponent<MGJPlayer>();
                player.Data = new PlayerData
                {
                    PlayerName = $"Player {i+1}",
                    Coins      = 100,
                };
                player.IsAI = false;
                go.Transform.Position = new Vector3(i * 0.4f, 0.5f, 0);
                _players.Add(player);
            }

            for (int i = 0; i < aiCount && (_players.Count < 4); i++)
            {
                var go     = new BADGE.Core.GameObject($"AI_{i+1}");
                var player = go.AddComponent<MGJPlayer>();
                var pers   = MGJAIPersonality.Generate(_rng);
                player.Data = new PlayerData
                {
                    PlayerName = AINameGenerator.Generate(),
                    Coins      = 100,
                };
                player.IsAI        = true;
                player.Personality = pers;
                var ai = go.AddComponent<MGJAIController>();
                ai.Personality = pers;
                player.AI = ai;
                go.Transform.Position = new Vector3(i * 0.4f + humanCount * 0.4f, 0.5f, 0);
                _players.Add(player);
            }
        }

        public List<PlayerData> SerializePlayers() =>
            _players.Select(p => p.Data).ToList();

        public void DeserializePlayers(List<PlayerData> data)
        {
            for (int i = 0; i < Math.Min(data.Count, _players.Count); i++)
                _players[i].Data = data[i];
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  FogSystem — visual fog of unexplored cells
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJFogSystem : MonoBehaviour
    {
        private readonly HashSet<int> _revealed = new();

        public void Reveal(int cellIndex, int range = 2)
        {
            for (int i = cellIndex - range; i <= cellIndex + range; i++)
                _revealed.Add(i);
        }

        public bool IsFogged(int cellIndex) => !_revealed.Contains(cellIndex);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  GridVisualEffects
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJGridVisualEffects : MonoBehaviour
    {
        private float _glowTimer;

        public override void Update()
        {
            _glowTimer += Time.DeltaTime;
            // Pulse all battle cells
            float pulse = (MathF.Sin(_glowTimer * 2f) + 1f) * 0.5f;
            foreach (var cell in FindObjectsOfType<MGJGridCell>())
            {
                if (cell.Type == CellType.Battle)
                {
                    // Visual pulse (scale) — 3D renderer picks this up
                    cell.Transform.Scale = Vector3.One * (0.95f + pulse * 0.1f);
                }
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  InventoryManager
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJInventoryManager : MonoBehaviour
    {
        private readonly Dictionary<string, int> _shopItems = new()
        {
            { "Battle Boost",  20 },
            { "Coin Magnet",   30 },
            { "Shortcut Key",  25 },
            { "Shield",        35 },
            { "Extra Roll",    15 },
        };

        public bool TryBuy(MGJPlayer player, string item)
        {
            if (!_shopItems.TryGetValue(item, out int cost)) return false;
            if (player.Data.Coins < cost) return false;
            player.Data.Coins -= cost;
            player.Data.Inventory.Add(item);
            MGJGameUI.Instance?.ShowEvent($"{player.Data.PlayerName} bought {item}.");
            return true;
        }

        public Dictionary<string,int> ShopItems => _shopItems;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  SaveSystem  (wraps BADGE SaveSystem)
    // ═══════════════════════════════════════════════════════════════════════════
    public static class MGJSaveSystem
    {
        private const int SLOT = 30;

        public static void SaveGame(MGJSaveData data)
        {
            SaveSystem.AutoEncrypt = true;
            try   { SaveSystem.WriteData(SLOT, data); }
            catch { Console.Error.WriteLine("[MGJ] Save failed."); }
        }

        public static MGJSaveData LoadGame()
        {
            SaveSystem.AutoEncrypt = true;
            try { return SaveSystem.ReadData<MGJSaveData>(SLOT) ?? new MGJSaveData(); }
            catch { return new MGJSaveData(); }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  GameManager
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJGameManager : MonoBehaviour
    {
        public static MGJGameManager Instance { get; private set; }

        private MGJGridGenerator    _gridGen;
        private MGJMultiplayerManager _multi;
        private MGJTurnManager      _turns;
        private MGJInventoryManager _inv;
        private MGJFogSystem        _fog;
        private MGJGameConfig       _cfg;
        private List<MGJGridCell>   _cells;

        public override void Awake()
        {
            if (Instance == null) Instance = this;
            else { Destroy(this); return; }
        }

        public void StartNewGame(int gridCount, int humanPlayers, int aiPlayers)
        {
            _cfg     = GetComponent<MGJGameConfig>() ?? new MGJGameConfig { GridCellCount = gridCount };
            _gridGen = GetComponent<MGJGridGenerator>() ?? new MGJGridGenerator();
            _multi   = GetComponent<MGJMultiplayerManager>();
            _turns   = GetComponent<MGJTurnManager>();
            _inv     = GetComponent<MGJInventoryManager>();
            _fog     = GetComponent<MGJFogSystem>();

            _cells = _gridGen.Generate(gridCount, _cfg.GridRadius, _cfg);
            _multi.InitializePlayers(humanPlayers, aiPlayers);

            var players = _multi.GetAllPlayers();
            foreach (var p in players) p.Init(_cells);

            _turns.Init(players, _cfg);
            _fog.Reveal(0, 3);

            MGJCoroutineRunner.Start(PublishGameStarted());
        }

        private IEnumerator PublishGameStarted()
        {
            yield return null;
            Console.WriteLine("[MGJ] Game started!");
        }

        public void LoadGame()
        {
            var data = MGJSaveSystem.LoadGame();
            if (data.Players.Count > 0)
            {
                // Restore grid
                _cells = _gridGen.Generate(data.GridCells.Count > 0 ? data.GridCells.Count : 40, _cfg.GridRadius, _cfg);
                _multi.DeserializePlayers(data.Players);
                _turns.SetTurnIndex(data.CurrentTurn);
            }
        }

        public void SaveGame()
        {
            var data = new MGJSaveData
            {
                Players     = _multi.SerializePlayers(),
                CurrentTurn = _turns.CurrentTurnIndex,
                TurnNumber  = _turns.TurnNumber,
                GridCells   = _cells?.Select(c => c.Serialize()).ToList() ?? new(),
            };
            MGJSaveSystem.SaveGame(data);
        }

        public void EndGame(List<MGJPlayer> players)
        {
            // Rank by stars, then coins
            var ranked = players.OrderByDescending(p => p.Data.Stars)
                                .ThenByDescending(p => p.Data.Coins)
                                .ToList();

            ranked[0].Data.GamesWon++;
            MGJGameUI.Instance?.ShowEndScreen(ranked);
            SaveGame();
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  UI — ImGui-based HUD and menus
    // ═══════════════════════════════════════════════════════════════════════════
    public class MGJGameUI : MonoBehaviour
    {
        public static MGJGameUI Instance { get; private set; }

        private string _activePlayer = "";
        private string _eventText    = "";
        private float  _eventTimer;
        private int    _diceDisplay  = 0;
        private bool   _showEndScreen;
        private List<MGJPlayer> _endRanking;
        private bool   _showShop;

        public override void Awake()
        {
            if (Instance == null) Instance = this;
        }

        public void SetActivePlayer(string name) { _activePlayer = name; _diceDisplay = 0; }
        public void ShowDiceFlicker(int n)  => _diceDisplay = n;
        public void ShowDiceResult(int n)   { _diceDisplay = n; }
        public void ShowEvent(string text)  { _eventText = text; _eventTimer = 3f; }
        public void ShowEndScreen(List<MGJPlayer> ranked) { _showEndScreen = true; _endRanking = ranked; }

        public override void Update()
        {
            if (_eventTimer > 0f) _eventTimer -= Time.DeltaTime;
        }

        public override void OnGUI()
        {
            // HUD
            MGJImGui.BeginOverlay("MGJ_HUD");
            MGJImGui.Text($"Turn: {_activePlayer}");
            if (_diceDisplay > 0) MGJImGui.Text($"Dice: {_diceDisplay}");
            if (_eventTimer > 0f) MGJImGui.Text($"> {_eventText}", highlighted: true);
            MGJImGui.Text("[SPACE / A] Roll Dice", dimmed: true);
            MGJImGui.EndOverlay();

            // Scoreboard (mini)
            var players = FindObjectsOfType<MGJPlayer>();
            MGJImGui.BeginOverlay("Scoreboard");
            foreach (var p in players.OrderByDescending(x => x.Data.Coins))
                MGJImGui.Text($"{p.Data.PlayerName}: {p.Data.Coins} coins | {p.Data.Stars} ★");
            MGJImGui.EndOverlay();

            if (_showEndScreen) DrawEndScreen();
            if (_showShop) DrawShop();
        }

        private void DrawEndScreen()
        {
            MGJImGui.BeginModal("GAME OVER");
            MGJImGui.Text("Final Rankings:");
            for (int i = 0; i < _endRanking.Count; i++)
            {
                var p = _endRanking[i];
                MGJImGui.Text($"#{i+1} {p.Data.PlayerName}  —  {p.Data.Coins} coins, {p.Data.Stars} stars");
            }
            if (MGJImGui.Button("Play Again")) MGJGameManager.Instance?.StartNewGame(40, 1, 3);
            if (MGJImGui.Button("Quit"))       Engine.Instance.Shutdown();
            MGJImGui.EndModal();
        }

        private void DrawShop()
        {
            var inv = FindObjectOfType<MGJInventoryManager>();
            if (inv == null) return;
            MGJImGui.BeginModal("Mystic Shop");
            foreach (var item in inv.ShopItems)
                if (MGJImGui.Button($"{item.Key} — {item.Value} coins"))
                {
                    var active = FindObjectsOfType<MGJPlayer>()
                                 .FirstOrDefault(p => p.Data.PlayerName == _activePlayer);
                    if (active != null) inv.TryBuy(active, item.Key);
                }
            if (MGJImGui.Button("Leave")) _showShop = false;
            MGJImGui.EndModal();
        }
    }

    // ── ImGui adapter ─────────────────────────────────────────────────────────
    public static class MGJImGui
    {
        public static void BeginOverlay(string id) { }
        public static void EndOverlay() { }
        public static void BeginModal(string t) { }
        public static void EndModal() { }
        public static void Text(string t, bool dimmed=false, bool highlighted=false) => Console.WriteLine(t);
        public static bool Button(string l) => false;
    }

    // ── Coroutine runner ──────────────────────────────────────────────────────
    public static class MGJCoroutineRunner
    {
        public static void Start(IEnumerator routine) =>
            BADGE.Core.CoroutineRunner.Instance?.StartCoroutine(routine);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  Bootstrap
    // ═══════════════════════════════════════════════════════════════════════════
    public static class MGJBootstrap
    {
        public static void Load(int humanPlayers = 1, int aiPlayers = 3)
        {
            Console.WriteLine("[MGJ] Loading Mystic Grid Journey...");

            var root = new BADGE.Core.GameObject("MGJ_Root");
            root.AddComponent<MGJGameConfig>();
            root.AddComponent<MGJGridGenerator>();
            root.AddComponent<MGJMultiplayerManager>();
            root.AddComponent<MGJTurnManager>();
            root.AddComponent<MGJInventoryManager>();
            root.AddComponent<MGJFogSystem>();
            root.AddComponent<MGJGridVisualEffects>();

            var gm = root.AddComponent<MGJGameManager>();

            var uiGO = new BADGE.Core.GameObject("MGJ_UI");
            uiGO.AddComponent<MGJGameUI>();

            MGJGameManager.Instance?.StartNewGame(40, humanPlayers, aiPlayers);
        }
    }
}
