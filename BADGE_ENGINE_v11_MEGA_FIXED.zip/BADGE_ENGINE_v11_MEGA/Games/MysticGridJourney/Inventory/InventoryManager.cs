using System;
using System.Collections.Generic;
using ImGuiNET;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Manages per-player inventories and proxies power usage.
    /// Replaces Unity InventoryManager MonoBehaviour.
    /// </summary>
    public class InventoryManager
    {
        private readonly PowerSystem                     _powers;
        private readonly Dictionary<string, PlayerData> _inventories = new();

        public InventoryManager(PowerSystem powers) => _powers = powers;

        public void RegisterPlayer(PlayerController player)
        {
            string key = player.Data.PlayerName;
            if (!_inventories.ContainsKey(key))
                _inventories[key] = player.Data;
        }

        /// <summary>Open ImGui inventory window for a player (call from Render loop).</summary>
        public void OpenInventoryForPlayer(string playerName)
        {
            if (_inventories.TryGetValue(playerName, out var data))
                InventoryUI.Show(data);
        }

        public void UsePower(string playerName, PowerType power,
                              PlayerController target, PlayerController? source = null)
        {
            if (!_inventories.TryGetValue(playerName, out var data)) return;
            if (data.UsePower(power))
                _powers.ExecutePower(power, target, source);
        }

        public bool CanAffordItem(string playerName, int cost)
            => _inventories.TryGetValue(playerName, out var d) && d.Coins >= cost;

        public void PurchaseItem(string playerName, PowerType power, int cost)
        {
            if (!_inventories.TryGetValue(playerName, out var d)) return;
            if (d.SpendCoins(cost))
            {
                d.AddPower(power);
                Console.WriteLine($"[MysticGrid] {playerName} purchased {power}");
            }
        }
    }

    // ── ImGui inventory panel ─────────────────────────────────────────────
    public static class InventoryUI
    {
        private static PlayerData? _shown;

        public static void Show(PlayerData data)  => _shown = data;
        public static void Hide()                 => _shown = null;

        /// <summary>Call from the game's Render() pass each frame.</summary>
        public static void Render()
        {
            if (_shown == null) return;

            bool open = true;
            if (!ImGui.Begin($"{_shown.PlayerName} — Inventory", ref open))
            { ImGui.End(); return; }

            ImGui.Text($"Coins: {_shown.Coins}");
            ImGui.Separator();

            if (_shown.Powers.Count == 0)
            {
                ImGui.TextDisabled("No powers in inventory.");
            }
            else
            {
                ImGui.Text("Powers:");
                foreach (var p in _shown.Powers)
                {
                    ImGui.BulletText(p.ToString());
                }
            }

            ImGui.Separator();
            if (ImGui.Button("Close")) Hide();

            ImGui.End();
            if (!open) Hide();
        }
    }
}
