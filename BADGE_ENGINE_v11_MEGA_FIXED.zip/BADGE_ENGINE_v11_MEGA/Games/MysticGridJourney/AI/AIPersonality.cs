using System;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Defines the behavioural weights for one AI archetype.
    /// Replaces Unity ScriptableObject AIPersonality.
    /// </summary>
    public class AIPersonality
    {
        public float BetrayalChance       { get; set; } = 0.30f;
        public float HelpfulChance        { get; set; } = 0.20f;
        public float PowerUsageChance     { get; set; } = 0.50f;
        public float RiskTakingLevel      { get; set; } = 0.50f;
        public bool  PreferForwardProgress{ get; set; } = true;
        public bool  TargetLeadingPlayer  { get; set; } = true;

        // ── Presets ───────────────────────────────────────────────────────
        public static AIPersonality Aggressive => new()
        {
            BetrayalChance   = 0.70f, HelpfulChance = 0.05f,
            PowerUsageChance = 0.80f, RiskTakingLevel = 0.85f,
            TargetLeadingPlayer = true
        };

        public static AIPersonality Passive => new()
        {
            BetrayalChance   = 0.05f, HelpfulChance = 0.60f,
            PowerUsageChance = 0.20f, RiskTakingLevel = 0.15f,
            TargetLeadingPlayer = false
        };

        public static AIPersonality Balanced => new();

        public static AIPersonality Random(System.Random rng) => new()
        {
            BetrayalChance   = (float)rng.NextDouble(),
            HelpfulChance    = (float)rng.NextDouble(),
            PowerUsageChance = (float)rng.NextDouble(),
            RiskTakingLevel  = (float)rng.NextDouble()
        };
    }
}
