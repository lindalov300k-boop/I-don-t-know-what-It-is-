using System;
using System.Collections.Generic;
using BADGE.Core;

namespace BADGE.Games.MysticGridJourney
{
    /// <summary>
    /// Drives AI decision making each turn.
    /// Replaces Unity AIController + AIDecisionMaker.
    /// </summary>
    public class AIController : Component
    {
        private PlayerController?  _owner;
        private AIPersonality      _personality = AIPersonality.Balanced;
        private readonly Random    _rng = new();

        // Injected by scene after all players are created
        public MultiplayerManager? Players { private get; set; }
        public PowerSystem?        Powers  { private get; set; }

        public void Initialize(PlayerController owner, AIPersonality personality)
        {
            _owner       = owner;
            _personality = personality;
        }

        public void SetPersonality(AIPersonality p) => _personality = p;

        // ── Decision point (called at start of AI turn) ───────────────────
        public void MakeDecision()
        {
            if (_owner == null) return;

            float roll = (float)_rng.NextDouble();

            // Consider using a power
            if (_owner.Data.Powers.Count > 0 &&
                roll < _personality.PowerUsageChance)
                TryUsePower();

            // Consider betrayal
            if (roll < _personality.BetrayalChance)
                ConsiderBetrayal();

            // Consider helping
            if ((float)_rng.NextDouble() < _personality.HelpfulChance)
                ConsiderHelping();
        }

        // ── Actions ───────────────────────────────────────────────────────
        private void TryUsePower()
        {
            if (_owner == null) return;

            var powers = _owner.Data.Powers;
            if (powers.Count == 0) return;

            PowerType chosen = powers[_rng.Next(powers.Count)];
            var target = ChooseTarget(_personality.TargetLeadingPlayer);

            if (target != null && _owner.Data.UsePower(chosen))
            {
                Powers?.ExecutePower(chosen, target, _owner);
                Console.WriteLine($"[MysticGrid][AI] {_owner.Data.PlayerName} used {chosen} on {target.Data.PlayerName}!");
            }
        }

        private void ConsiderBetrayal()
        {
            if (_owner == null) return;

            var ahead = FindPlayerAhead();
            if (ahead == null) return;

            if (_owner.Data.HasPower(PowerType.Freeze) &&
                _owner.Data.UsePower(PowerType.Freeze))
            {
                Powers?.ExecutePower(PowerType.Freeze, ahead, _owner);
                Console.WriteLine($"[MysticGrid][AI] {_owner.Data.PlayerName} betrayed {ahead.Data.PlayerName}!");
            }
        }

        private void ConsiderHelping()
        {
            if (_owner == null) return;
            var behind = FindPlayerBehind();
            if (behind == null) return;

            // Grant extra steps as help
            if (_owner.Data.HasPower(PowerType.MultiplySteps) &&
                _owner.Data.UsePower(PowerType.MultiplySteps))
            {
                Powers?.ExecutePower(PowerType.MultiplySteps, behind, _owner);
                Console.WriteLine($"[MysticGrid][AI] {_owner.Data.PlayerName} helped {behind.Data.PlayerName}!");
            }
        }

        // ── Target selection ──────────────────────────────────────────────
        private PlayerController? ChooseTarget(bool preferLeader)
        {
            var all = Players?.GetAllPlayers();
            if (all == null || all.Count <= 1) return null;

            if (preferLeader)
                return FindPlayerAhead();

            // Random non-self target
            var others = all.FindAll(p => p != _owner);
            return others.Count > 0 ? others[_rng.Next(others.Count)] : null;
        }

        private PlayerController? FindPlayerAhead()
        {
            if (_owner == null || Players == null) return null;
            int    myIdx  = _owner.Data.CurrentGridIndex;
            int    best   = int.MaxValue;
            PlayerController? found = null;

            foreach (var p in Players.GetAllPlayers())
            {
                if (p == _owner) continue;
                int d = p.Data.CurrentGridIndex - myIdx;
                if (d > 0 && d < best) { best = d; found = p; }
            }
            return found;
        }

        private PlayerController? FindPlayerBehind()
        {
            if (_owner == null || Players == null) return null;
            int    myIdx = _owner.Data.CurrentGridIndex;
            int    best  = int.MaxValue;
            PlayerController? found = null;

            foreach (var p in Players.GetAllPlayers())
            {
                if (p == _owner) continue;
                int d = myIdx - p.Data.CurrentGridIndex;
                if (d > 0 && d < best) { best = d; found = p; }
            }
            return found;
        }
    }
}
