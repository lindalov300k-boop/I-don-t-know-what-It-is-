using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using BADGE.Core;
using BADGE.Rendering;

namespace BADGE.Games.Luminous
{
    // ══════════════════════════════════════════════════════════════════════════
    //  LUMINOUS — BADGE Engine v8 Port
    //  Original Unity game converted to BADGE Engine by Frederick (Fake)
    //  Atlas Network Club
    //
    //  A top-down procedural maze game. An alien creature must navigate
    //  Perlin-noise generated mazes, collect glowing orbs, and survive
    //  black horror creatures that chase when the player glows.
    //
    //  MECHANICS:
    //   • WASD/Arrows — move the alien player
    //   • Space        — toggle glow (drains health, activates chase)
    //   • Collect orbs — generates a new maze
    //   • Die          — full health loss → new maze, health reset
    // ══════════════════════════════════════════════════════════════════════════

    public enum LuminousScene { StartScene, MainScene }

    public class LuminousGame : MonoBehaviour
    {
        public static LuminousGame Instance { get; private set; } = null!;

        public LuminousScene CurrentScene { get; private set; } = LuminousScene.StartScene;
        public int  TotalOrbs   { get; private set; }
        public bool IsRunning   { get; private set; }

        // Sub-systems (created at runtime)
        public LuminousGameManager GameMgr   { get; private set; } = null!;
        public LuminousProceduralMaze Maze   { get; private set; } = null!;
        public LuminousPlayer  Player        { get; private set; } = null!;
        public LuminousOrb     Orb           { get; private set; } = null!;
        public LuminousEnemySpawner Spawner  { get; private set; } = null!;
        public LuminousHUD     HUD           { get; private set; } = null!;

        private readonly string _saveKey = "luminous_orbs";

        public override void Awake()
        {
            if (Instance != null) { Destroy(gameObject); return; }
            Instance = this;
            TotalOrbs = SaveSystem.ReadData<LuminousSave>(0)?.Orbs ?? 0;
            Console.WriteLine($"[Luminous] Loaded. Orbs: {TotalOrbs}");
        }

        public override void Start()
        {
            LoadStartScene();
        }

        // ── Scene management ──────────────────────────────────────────────────
        public void LoadStartScene()
        {
            CurrentScene = LuminousScene.StartScene;
            IsRunning    = false;
            HUD?.SetVisible(false);
            Console.WriteLine("[Luminous] StartScene loaded.");
        }

        public void LoadMainScene()
        {
            CurrentScene = LuminousScene.MainScene;
            IsRunning    = true;

            // Build subsystems
            var mazeObj = new GameObject("Maze");
            mazeObj.SetParent(gameObject);
            Maze = mazeObj.AddComponent<LuminousProceduralMaze>();
            Maze.Generate();

            var playerObj = new GameObject("Player");
            Player = playerObj.AddComponent<LuminousPlayer>();
            Player.Position = Maze.PlayerSpawnPos;

            var orbObj = new GameObject("Orb");
            Orb = orbObj.AddComponent<LuminousOrb>();
            Orb.Position = Maze.OrbSpawnPos;

            var spawnerObj = new GameObject("EnemySpawner");
            Spawner = spawnerObj.AddComponent<LuminousEnemySpawner>();

            var hudObj = new GameObject("HUD");
            HUD = hudObj.AddComponent<LuminousHUD>();
            HUD.SetVisible(true);
            HUD.UpdateOrbCount(TotalOrbs);

            Console.WriteLine("[Luminous] MainScene loaded.");
        }

        public void AddOrb()
        {
            TotalOrbs++;
            SaveSystem.WriteData(0, new LuminousSave { Orbs = TotalOrbs });
            HUD?.UpdateOrbCount(TotalOrbs);
        }

        public void RegenerateMaze()
        {
            Maze?.Generate();
            if (Player != null) Player.Position = Maze!.PlayerSpawnPos;
            if (Orb    != null) Orb.Position    = Maze!.OrbSpawnPos;
            Spawner?.Respawn();
            HUD?.ShowNewMazeFlash();
        }

        public override void Update()
        {
            if (CurrentScene == LuminousScene.StartScene)
                UpdateStartScene();
        }

        private void UpdateStartScene()
        {
            // Enter pressed → load main scene
            if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.Space))
                LoadMainScene();
        }

        public override void OnDestroy()
        {
            if (Instance == this) Instance = null!;
        }
    }

    [Serializable]
    public class LuminousSave { public int Orbs; }
}
