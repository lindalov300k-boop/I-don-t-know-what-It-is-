using System;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Games.Luminous
{
    /// <summary>
    /// HUD for Luminous: health bar, orb counter, new maze flash text.
    /// Drawn via BADGE ImGui/UISystem.
    /// </summary>
    public class LuminousHUD : MonoBehaviour
    {
        // Health bar state
        public float HealthNormalized { get; private set; } = 1f;

        // Orb count
        public int OrbCount { get; private set; }

        // Flash text state
        public bool    ShowFlash    { get; private set; }
        public float   FlashAlpha   { get; private set; }
        private float  _flashTimer;
        private const float FlashDuration = 2.5f;

        // Visible flag
        public bool Visible { get; private set; }

        // Start scene data
        public int  StartOrbCount { get; private set; }
        public bool IsStartScene  => LuminousGame.Instance?.CurrentScene == LuminousScene.StartScene;
        public float TitlePulse   { get; private set; }
        private float _titleTimer;

        public void SetVisible(bool v) => Visible = v;

        public void UpdateHealth(float normalized)
        {
            HealthNormalized = Math.Clamp(normalized, 0f, 1f);
        }

        public void UpdateOrbCount(int count)
        {
            OrbCount = count;
            StartOrbCount = count;
        }

        public void ShowNewMazeFlash()
        {
            ShowFlash = true;
            _flashTimer = 0f;
            FlashAlpha  = 0f;
        }

        public override void Update()
        {
            _titleTimer += Time.DeltaTime * 1.4f;
            TitlePulse   = (MathF.Sin(_titleTimer) + 1f) * 0.5f;

            if (!ShowFlash) return;
            _flashTimer += Time.DeltaTime;
            FlashAlpha = _flashTimer < 0.3f ? _flashTimer / 0.3f
                       : _flashTimer > 2.0f ? 1f - (_flashTimer - 2.0f) / 0.5f
                       : 1f;
            if (_flashTimer >= FlashDuration)
            {
                ShowFlash  = false;
                FlashAlpha = 0f;
            }
        }

        public override void OnGUI()
        {
            if (!Visible) return;

            if (IsStartScene)
            {
                DrawStartScreen();
            }
            else
            {
                DrawHUD();
            }
        }

        private void DrawStartScreen()
        {
            float brightness = MathF.Lerp(0.65f, 1.05f, TitlePulse);
            UISystem.Label("LUMINOUS", 0.5f, 0.22f, fontSize: 64, color: new Vector4(1f, 0.92f, 0.25f, 1f) * brightness, centered: true);
            UISystem.Label("find the light. survive the dark.", 0.5f, 0.32f, fontSize: 20, color: new Vector4(0.4f, 0.4f, 0.5f, 1f), centered: true);
            UISystem.Label($"Orbs Collected: {StartOrbCount}", 0.5f, 0.42f, fontSize: 18, color: new Vector4(0.3f, 0.55f, 1f, 1f), centered: true);
            if (UISystem.Button("EXCAPE", 0.35f, 0.60f, 0.3f, 0.08f))
                LuminousGame.Instance?.LoadMainScene();
            UISystem.Label("[ENTER] to begin", 0.5f, 0.72f, fontSize: 14, color: new Vector4(0.5f, 0.5f, 0.5f, 0.7f), centered: true);
        }

        private void DrawHUD()
        {
            // Health bar background
            UISystem.FillRect(0.02f, 0.02f, 0.26f, 0.05f, new Vector4(0.08f, 0.08f, 0.08f, 0.8f));
            // Health bar fill (green→red)
            float fillW = 0.24f * HealthNormalized;
            Vector4 hpColor = Vector4.Lerp(new Vector4(0.9f, 0.15f, 0.1f, 1f), new Vector4(0.15f, 0.9f, 0.2f, 1f), HealthNormalized);
            UISystem.FillRect(0.03f, 0.025f, fillW, 0.04f, hpColor);
            UISystem.Label("HP", 0.04f, 0.03f, fontSize: 13, color: new Vector4(1f, 1f, 1f, 1f));

            // Orb count
            UISystem.Label($"◉ Orbs: {OrbCount}", 0.02f, 0.09f, fontSize: 16, color: new Vector4(0.3f, 0.6f, 1f, 1f));

            // Glow hint
            string glowState = LuminousGame.Instance?.Player?.IsGlowing == true ? "GLOW: ON [drain]" : "[SPACE] Toggle Glow";
            UISystem.Label(glowState, 0.5f, 0.95f, fontSize: 13, color: new Vector4(0.6f, 0.6f, 0.6f, 1f), centered: true);

            // New maze flash
            if (ShowFlash)
                UISystem.Label("✦ New Maze Generated ✦", 0.5f, 0.5f, fontSize: 22,
                    color: new Vector4(1f, 0.8f, 0.2f, FlashAlpha), centered: true);
        }
    }
}
