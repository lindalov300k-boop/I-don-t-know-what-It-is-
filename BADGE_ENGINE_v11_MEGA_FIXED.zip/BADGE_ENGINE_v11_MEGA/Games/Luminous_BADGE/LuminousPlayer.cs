using System;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Games.Luminous
{
    /// <summary>
    /// Top-down alien player for Luminous.
    /// WASD = move. Space = toggle glow.
    /// Glow drains health; being hit by enemies also drains health.
    /// Reaching 0 health regenerates the maze.
    /// </summary>
    public class LuminousPlayer : MonoBehaviour
    {
        // Config
        public float WalkSpeed       = 4f;
        public float RunSpeed        = 7f;
        public float MaxHealth       = 100f;
        public float HealthDrainRate = 8f;   // per second while glowing
        public float HealthRegenRate = 5f;   // per second while dim

        // State
        public float CurrentHealth  { get; private set; }
        public bool  IsGlowing      { get; private set; }
        public Vector3 Position     { get => Transform.Position; set => Transform.Position = value; }

        // Animation
        private float _walkCycle;
        private float _footstepTimer;
        private const float FootstepInterval = 0.38f;

        // Procedural parts (positions relative to body centre)
        public record BodyPart(string Name, Vector3 Offset, Vector3 Scale, Vector4 Color);
        public BodyPart[] Parts { get; private set; } = Array.Empty<BodyPart>();

        // Glow light (virtual — renderer reads these)
        public float GlowIntensity { get; private set; }
        public Vector4 GlowColor = new(1f, 0.95f, 0.3f, 1f);
        public float   GlowRange  = 8f;

        public override void Awake()
        {
            CurrentHealth = MaxHealth;
            BuildParts();
        }

        private void BuildParts()
        {
            Parts = new[]
            {
                new BodyPart("Torso",  new Vector3(0f,  0.7f, 0f),  new Vector3(0.4f, 0.5f, 0.28f), new Vector4(0.1f,  0.55f, 0.15f, 1f)),
                new BodyPart("Head",   new Vector3(0f,  1.35f, 0f), new Vector3(0.55f,0.6f, 0.5f),  new Vector4(0.08f, 0.45f, 0.12f, 1f)),
                new BodyPart("EyeL",   new Vector3(-0.14f,1.38f,-0.23f),new Vector3(0.1f,0.07f,0.05f),new Vector4(0f,0f,0f,1f)),
                new BodyPart("EyeR",   new Vector3( 0.14f,1.38f,-0.23f),new Vector3(0.1f,0.07f,0.05f),new Vector4(0f,0f,0f,1f)),
                new BodyPart("ArmL",   new Vector3(-0.3f,0.72f,0f), new Vector3(0.14f,0.42f,0.14f), new Vector4(0.1f, 0.55f,0.15f,1f)),
                new BodyPart("ArmR",   new Vector3( 0.3f,0.72f,0f), new Vector3(0.14f,0.42f,0.14f), new Vector4(0.1f, 0.55f,0.15f,1f)),
                new BodyPart("LegL",   new Vector3(-0.13f,0.22f,0f),new Vector3(0.15f,0.44f,0.15f), new Vector4(0.1f, 0.55f,0.15f,1f)),
                new BodyPart("LegR",   new Vector3( 0.13f,0.22f,0f),new Vector3(0.15f,0.44f,0.15f), new Vector4(0.1f, 0.55f,0.15f,1f)),
            };
        }

        public override void Update()
        {
            HandleInput();
            HandleGlow();
            HandleHealth();
            AnimateBody();
        }

        // ── Input ─────────────────────────────────────────────────────────────
        private float _moveX, _moveZ;

        private void HandleInput()
        {
            _moveX = (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.Right) ? 1f : 0f)
                   - (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.Left)  ? 1f : 0f);
            _moveZ = (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.Up)    ? 1f : 0f)
                   - (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.Down)  ? 1f : 0f);

            bool run   = Input.GetKey(KeyCode.LeftShift);
            float spd  = run ? RunSpeed : WalkSpeed;
            var dir    = new Vector3(_moveX, 0f, _moveZ);

            if (dir.LengthSquared > 1f) dir = Vector3.Normalize(dir);

            // Collision with maze walls
            var maze = LuminousProceduralMaze.Instance;
            Vector3 nextPos = Transform.Position + dir * spd * Time.DeltaTime;
            if (maze != null)
            {
                int gx = (int)MathF.Round(nextPos.X / maze.BlockSize);
                int gy = (int)MathF.Round(nextPos.Z / maze.BlockSize);
                if (maze.IsWall(gx, gy))
                {
                    // Try sliding along each axis
                    Vector3 slideX = Transform.Position + new Vector3(dir.X, 0f, 0f) * spd * Time.DeltaTime;
                    int sx = (int)MathF.Round(slideX.X / maze.BlockSize);
                    int sz = (int)MathF.Round(slideX.Z / maze.BlockSize);
                    if (!maze.IsWall(sx, sz)) nextPos = slideX;
                    else nextPos = Transform.Position;
                }
            }
            Transform.Position = nextPos;

            if (dir.LengthSquared > 0.01f)
            {
                Transform.Rotation = Quaternion.Slerp(Transform.Rotation,
                    Quaternion.FromAxisAngle(Vector3.UnitY, MathF.Atan2(dir.X, dir.Z)),
                    12f * Time.DeltaTime);
            }

            // Glow toggle
            if (Input.GetKeyDown(KeyCode.Space)) IsGlowing = !IsGlowing;

            // Footsteps
            if (dir.LengthSquared > 0.01f)
            {
                _footstepTimer += Time.DeltaTime;
                if (_footstepTimer >= FootstepInterval / (run ? 1.6f : 1f))
                {
                    AudioSystem.PlayOneShot(AudioSystem.GenerateFootstep(80f, 0.12f), 0.18f);
                    _footstepTimer = 0f;
                }
            }
            else _footstepTimer = 0f;
        }

        private float _pulseTimer;
        private void HandleGlow()
        {
            if (IsGlowing)
            {
                _pulseTimer += Time.DeltaTime * 2.5f;
                float pulse = (MathF.Sin(_pulseTimer) + 1f) * 0.5f;
                GlowIntensity = MathF.Lerp(0.6f, 1.4f, pulse) * 3.5f;
            }
            else
            {
                GlowIntensity = 0f;
                _pulseTimer = 0f;
            }
        }

        private void HandleHealth()
        {
            float dt = Time.DeltaTime;
            if (IsGlowing)
                CurrentHealth = Math.Clamp(CurrentHealth - HealthDrainRate * dt, 0f, MaxHealth);
            else
                CurrentHealth = Math.Clamp(CurrentHealth + HealthRegenRate * dt, 0f, MaxHealth);

            LuminousGame.Instance?.HUD?.UpdateHealth(CurrentHealth / MaxHealth);

            if (CurrentHealth <= 0f) OnDeath();
        }

        public void TakeDamage(float dmg)
        {
            CurrentHealth = Math.Clamp(CurrentHealth - dmg, 0f, MaxHealth);
        }

        private void OnDeath()
        {
            CurrentHealth = MaxHealth;
            IsGlowing     = false;
            LuminousGame.Instance?.RegenerateMaze();
        }

        // ── Limb animation data (offsets, renderer reads these) ───────────────
        public float LegSwingAngle  { get; private set; }
        public float ArmSwingAngle  { get; private set; }

        private void AnimateBody()
        {
            bool moving = (_moveX * _moveX + _moveZ * _moveZ) > 0.01f;
            if (moving)
            {
                _walkCycle += Time.DeltaTime * WalkSpeed * 3f;
                float swing = MathF.Sin(_walkCycle) * 18f;
                LegSwingAngle =  swing;
                ArmSwingAngle = -swing * 0.5f;
            }
            else
            {
                _walkCycle += Time.DeltaTime * 1.5f;
                float idle = MathF.Sin(_walkCycle) * 0.04f;
                Transform.Position = new Vector3(Transform.Position.X,
                                                 0.5f + idle,
                                                 Transform.Position.Z);
                LegSwingAngle = ArmSwingAngle = 0f;
            }
        }
    }
}
