using System;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Games.Luminous
{
    /// <summary>
    /// Collectible glowing orb for Luminous.
    /// Pulses blue, floats gently, rotates.
    /// On collection: adds to orb count, triggers new maze generation.
    /// </summary>
    public class LuminousOrb : MonoBehaviour
    {
        public Vector3 Position { get => Transform.Position; set => Transform.Position = value; }

        // Visual state (renderer reads)
        public float   PulsePhase     { get; private set; }
        public float   GlowIntensity  { get; private set; }
        public Vector4 GlowColor      = new(0.2f, 0.5f, 1f, 1f);
        public float   CollectRadius  = 0.55f;
        public float   GlowRange      = 5f;

        private float _baseY;
        private bool  _collected;

        public override void Start()
        {
            _baseY = Transform.Position.Y;
        }

        public override void Update()
        {
            if (_collected) return;

            PulsePhase += Time.DeltaTime * 1.8f;
            float pulse   = (MathF.Sin(PulsePhase) + 1f) * 0.5f;
            GlowIntensity = MathF.Lerp(0.8f, 2.2f, pulse);

            // Float and rotate
            Transform.Position = new Vector3(
                Transform.Position.X,
                _baseY + MathF.Sin(PulsePhase * 0.9f) * 0.15f,
                Transform.Position.Z);
            Transform.Rotation *= Quaternion.FromAxisAngle(Vector3.UnitY, 60f * Time.DeltaTime * MathF.PI / 180f);

            // Check collection
            var player = LuminousGame.Instance?.Player;
            if (player != null)
            {
                float dist = Vector3.Distance(Transform.Position, player.Transform.Position);
                if (dist < CollectRadius) Collect(player);
            }
        }

        private void Collect(LuminousPlayer player)
        {
            if (_collected) return;
            _collected = true;
            LuminousGame.Instance?.AddOrb();
            LuminousGame.Instance?.RegenerateMaze();
            _collected = false; // Reset after maze regeneration
        }
    }
}
