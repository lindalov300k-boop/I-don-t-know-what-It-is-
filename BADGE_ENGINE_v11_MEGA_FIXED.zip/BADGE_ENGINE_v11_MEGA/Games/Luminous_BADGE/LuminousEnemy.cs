using System;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Games.Luminous
{
    /// <summary>
    /// Procedural black horror creature for Luminous.
    /// Idles with jitter. Chases the player only when player is glowing
    /// and within detection range.  Attacks on contact.
    /// </summary>
    public class LuminousEnemy : MonoBehaviour
    {
        // Config
        public float ChaseSpeed     = 3.2f;
        public float IdleJitterAmp  = 0.06f;
        public float DamagePerSec   = 12f;
        public float DetectionRange = 20f;
        public float AttackRange    = 0.9f;

        public Vector3 Position { get => Transform.Position; set => Transform.Position = value; }

        // Limb animation state (renderer reads these)
        public float[] LimbAngles { get; } = new float[5];
        private float[] _limbPhases = new float[5];
        private float   _jitterTimer;

        // Distortion audio cooldown
        private float _soundCooldown;

        public override void Awake()
        {
            var rng = new Random();
            for (int i = 0; i < _limbPhases.Length; i++)
                _limbPhases[i] = (float)(rng.NextDouble() * MathF.PI * 2f);
        }

        public override void Update()
        {
            var game   = LuminousGame.Instance;
            var player = game?.Player;
            if (player == null) return;

            bool glowing = player.IsGlowing;
            float dist   = Vector3.Distance(Transform.Position, player.Transform.Position);

            // Distortion sound when close and player glowing
            _soundCooldown -= Time.DeltaTime;
            if (glowing && dist < DetectionRange && _soundCooldown <= 0f)
            {
                AudioSystem.PlayOneShot(AudioSystem.GenerateDistortion(100f, 300f, 1.8f), 0.28f);
                _soundCooldown = 1.8f + (float)new Random().NextDouble();
            }

            if (glowing && dist < DetectionRange)
                ChasePlayer(player);
            else
                IdleJitter();

            // Attack on contact
            if (dist < AttackRange)
                player.TakeDamage(DamagePerSec * Time.DeltaTime);

            AnimateLimbs(glowing && dist < DetectionRange);
        }

        private void ChasePlayer(LuminousPlayer player)
        {
            Vector3 dir = player.Transform.Position - Transform.Position;
            dir.Y = 0f;

            // Simple wall avoidance
            var maze = LuminousProceduralMaze.Instance;
            if (maze != null)
            {
                Vector3 look = Vector3.Normalize(dir);
                Vector3 next = Transform.Position + look * 1.2f;
                int nx = (int)MathF.Round(next.X / maze.BlockSize);
                int ny = (int)MathF.Round(next.Z / maze.BlockSize);
                if (maze.IsWall(nx, ny))
                    dir = Vector3.Cross(dir, Vector3.UnitY);
            }

            if (dir.LengthSquared > 0.001f) dir = Vector3.Normalize(dir);
            Transform.Position += dir * ChaseSpeed * Time.DeltaTime;

            if (dir.LengthSquared > 0.01f)
                Transform.Rotation = Quaternion.Slerp(Transform.Rotation,
                    Quaternion.FromAxisAngle(Vector3.UnitY, MathF.Atan2(dir.X, dir.Z)),
                    6f * Time.DeltaTime);
        }

        private void IdleJitter()
        {
            _jitterTimer += Time.DeltaTime * 8f;
            float jx = MathF.Sin(_jitterTimer * 1.3f) * IdleJitterAmp;
            float jz = MathF.Cos(_jitterTimer * 1.7f) * IdleJitterAmp;
            Transform.Position += new Vector3(jx, 0f, jz) * Time.DeltaTime;
        }

        private void AnimateLimbs(bool chasing)
        {
            float speed = chasing ? 14f : 4f;
            float amp   = chasing ? 35f : 12f;
            for (int i = 0; i < LimbAngles.Length; i++)
            {
                _limbPhases[i] += Time.DeltaTime * (speed + i * 1.3f);
                LimbAngles[i]   = MathF.Sin(_limbPhases[i]) * amp;
            }
        }
    }

    // ── Enemy spawner ─────────────────────────────────────────────────────────
    public class LuminousEnemySpawner : MonoBehaviour
    {
        public int   EnemyCount   = 6;
        public float MinSpawnDist = 8f;

        private readonly System.Collections.Generic.List<LuminousEnemy> _enemies = new();

        public override void Start() => Respawn();

        public void Respawn()
        {
            foreach (var e in _enemies) Destroy(e.gameObject);
            _enemies.Clear();

            var maze = LuminousProceduralMaze.Instance;
            if (maze == null) return;

            var candidates = new System.Collections.Generic.List<Vector3>();
            for (int x = 0; x < maze.Width; x++)
            for (int y = 0; y < maze.Height; y++)
            {
                if (maze.IsWall(x, y)) continue;
                Vector3 wp = maze.GridToWorld(x, y);
                if (Vector3.Distance(wp, maze.PlayerSpawnPos) < MinSpawnDist) continue;
                candidates.Add(wp);
            }

            var rng = new Random();
            for (int i = candidates.Count - 1; i > 0; i--)
            {
                int j = rng.Next(i + 1);
                (candidates[i], candidates[j]) = (candidates[j], candidates[i]);
            }

            int toSpawn = Math.Min(EnemyCount, candidates.Count);
            for (int i = 0; i < toSpawn; i++)
            {
                var obj = new GameObject($"Enemy_{i}");
                var enemy = obj.AddComponent<LuminousEnemy>();
                enemy.Position = candidates[i] + Vector3.UnitY * 0.7f;
                _enemies.Add(enemy);
            }
        }
    }
}
