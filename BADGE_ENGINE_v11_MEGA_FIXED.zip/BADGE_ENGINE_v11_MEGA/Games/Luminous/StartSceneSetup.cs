using BADGE.Core;
using OpenTK.Mathematics;

/// <summary>
/// Drop onto ONE empty GameObject in StartScene.
/// Ensures GameManager exists, then hands off to StartSceneManager.
/// Unity 2019.4 LTS compatible.

namespace BADGE.Games.Luminous;

/// </summary>
public class StartSceneSetup : MonoBehaviour
{
    void Awake()
    {
        if (GameManager.Instance == null)
            new GameObject("GameManager").AddComponent<GameManager>();

        gameObject.AddComponent<StartSceneManager>();
    }
}
