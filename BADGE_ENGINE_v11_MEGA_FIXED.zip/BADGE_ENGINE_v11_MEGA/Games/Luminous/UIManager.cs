using BADGE.Core;
using OpenTK.Mathematics;
using System.Collections;

/// <summary>
/// Procedural HUD for MainScene — built entirely in code.

namespace BADGE.Games.Luminous;

/// Unity 2019.4 LTS — uses legacy UI (Canvas, Image, Text).
///
/// Elements:
///   - Health bar (color shifts green → red, glows when draining)
///   - Orb counter: shows count + tier label + tier progress bar
///   - "✦ New Maze Generated ✦" flash text
///   - Spacebar hint
///   - Tier milestone banners (TIER I → TIER II → TIER III → MAX)
/// </summary>
public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    // ── Refs ──────────────────────────────────────────────────────
    Image healthFill;
    Image tierProgressFill;
    Text  healthText;
    Text  orbCountText;
    Text  orbTierText;
    Text  newMazeText;
    Text  tierBannerText;

    GameObject tierBannerGO;
    Coroutine  newMazeCo;
    Coroutine  tierBannerCo;

    // Track last tier for milestone detection
    string lastTierLabel = "";

    // ── Canvas ────────────────────────────────────────────────────
    void Awake()
    {
        Instance = this;
        BuildHUD();
    }

    void BuildHUD()
    {
        GameObject canvasGO = new GameObject("HUDCanvas");
        Canvas canvas = canvasGO.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 10;

        CanvasScaler scaler = canvasGO.AddComponent<CanvasScaler>();
        scaler.uiScaleMode          = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution  = new Vector2(1920f, 1080f);
        canvasGO.AddComponent<GraphicRaycaster>();
        SceneManager.Instance.DontDestroyOnLoad(canvasGO);

        Transform root = canvasGO.transform;

        BuildHealthBar(root);
        BuildOrbCounter(root);
        BuildNewMazeText(root);
        BuildControlHint(root);
        BuildTierBanner(root);
    }

    // ── Health Bar ────────────────────────────────────────────────
    void BuildHealthBar(Transform root)
    {
        // Panel bg
        GameObject bg = MakeImage(root, "HealthBg", new Color(0.05f, 0.05f, 0.08f, 0.88f));
        Anchor(bg, new Vector2(0.02f, 0.93f), new Vector2(0.26f, 0.98f));

        // Label
        healthText = MakeText(bg.transform, "HP ████", Color.white, 13,
                               new Vector2(0f, 0f), new Vector2(1f, 1f));
        healthText.alignment = TextAnchor.MiddleLeft;

        // Fill
        GameObject fill = MakeImage(bg.transform, "HealthFill", new Color(0.18f, 0.85f, 0.22f));
        healthFill = fill.GetComponent<Image>();
        healthFill.type = Image.Type.Filled;
        healthFill.fillMethod = Image.FillMethod.Horizontal;
        healthFill.fillAmount = 1f;
        RectTransform fr = fill.GetComponent<RectTransform>();
        fr.anchorMin = new Vector2(0f, 0f);
        fr.anchorMax = new Vector2(1f, 1f);
        fr.offsetMin = new Vector2(4f, 4f);
        fr.offsetMax = new Vector2(-4f, -4f);
    }

    // ── Orb Counter ───────────────────────────────────────────────
    void BuildOrbCounter(Transform root)
    {
        // Panel
        GameObject panel = MakeImage(root, "OrbPanel", new Color(0.03f, 0.03f, 0.07f, 0.88f));
        Anchor(panel, new Vector2(0.02f, 0.84f), new Vector2(0.26f, 0.92f));

        // Count label
        orbCountText = MakeText(panel.transform, "◉ 0", new Color(0.4f, 0.65f, 1f), 18,
                                 new Vector2(0f, 0.45f), new Vector2(1f, 1f));
        orbCountText.alignment = TextAnchor.MiddleCenter;

        // Tier label
        orbTierText = MakeText(panel.transform, "TIER I", new Color(0.7f, 0.5f, 0.1f), 11,
                                new Vector2(0f, 0.0f), new Vector2(1f, 0.48f));
        orbTierText.alignment = TextAnchor.MiddleCenter;

        // Tier progress bar bg
        GameObject pbBg = MakeImage(panel.transform, "TierProgBg", new Color(0.08f, 0.06f, 0.12f));
        RectTransform pbBgRT = pbBg.GetComponent<RectTransform>();
        pbBgRT.anchorMin = new Vector2(0.04f, 0.06f);
        pbBgRT.anchorMax = new Vector2(0.96f, 0.22f);
        pbBgRT.offsetMin = pbBgRT.offsetMax = Vector2.zero;

        // Tier progress fill
        GameObject pbFill = MakeImage(pbBg.transform, "TierProgFill", new Color(0.3f, 0.5f, 1f));
        tierProgressFill = pbFill.GetComponent<Image>();
        tierProgressFill.type        = Image.Type.Filled;
        tierProgressFill.fillMethod  = Image.FillMethod.Horizontal;
        tierProgressFill.fillAmount  = 0f;
        RectTransform pf = pbFill.GetComponent<RectTransform>();
        pf.anchorMin = Vector2.zero;
        pf.anchorMax = Vector2.one;
        pf.offsetMin = new Vector2(2f, 2f);
        pf.offsetMax = new Vector2(-2f, -2f);
    }

    // ── New Maze Flash ────────────────────────────────────────────
    void BuildNewMazeText(Transform root)
    {
        newMazeText = MakeText(root, "✦ New Maze Generated ✦",
                               new Color(1f, 0.80f, 0.15f), 26,
                               new Vector2(0.15f, 0.44f), new Vector2(0.85f, 0.56f));
        newMazeText.alignment = TextAnchor.MiddleCenter;
        newMazeText.fontStyle = FontStyle.Bold;
        newMazeText.gameObject.SetActive(false);
    }

    // ── Control Hint ──────────────────────────────────────────────
    void BuildControlHint(Transform root)
    {
        Text hint = MakeText(root, "[SPACE] Toggle Glow  |  [SHIFT] Run",
                             new Color(0.35f, 0.35f, 0.4f), 14,
                             new Vector2(0.25f, 0.01f), new Vector2(0.75f, 0.06f));
        hint.alignment = TextAnchor.MiddleCenter;
    }

    // ── Tier Milestone Banner ─────────────────────────────────────
    void BuildTierBanner(Transform root)
    {
        tierBannerGO = MakeImage(root, "TierBanner",
                                  new Color(0.05f, 0.05f, 0.10f, 0.92f)).gameObject;
        Anchor(tierBannerGO, new Vector2(0.25f, 0.60f), new Vector2(0.75f, 0.75f));

        tierBannerText = MakeText(tierBannerGO.transform, "",
                                   new Color(1f, 0.85f, 0.2f), 32,
                                   new Vector2(0f, 0f), new Vector2(1f, 1f));
        tierBannerText.alignment = TextAnchor.MiddleCenter;
        tierBannerText.fontStyle = FontStyle.Bold;
        tierBannerGO.SetActive(false);
    }

    // ══════════════════════════════════════════════════════════════
    //  PUBLIC API
    // ══════════════════════════════════════════════════════════════
    public void SetHealth(float normalized)
    {
        if (!healthFill) return;
        healthFill.fillAmount = MathF.Clamp01(normalized);
        healthFill.color = Color.Lerp(new Color(0.85f, 0.12f, 0.08f),
                                       new Color(0.18f, 0.85f, 0.22f), normalized);
        if (healthText)
            healthText.text = "HP " + MathF.RoundToInt(normalized * 100f) + "%";
    }

    public void SetOrbs(int count, float tierProgress, string tierLabel)
    {
        if (orbCountText)      orbCountText.text  = "◉ " + count.ToString("N0");
        if (orbTierText)       orbTierText.text   = tierLabel;
        if (tierProgressFill)  tierProgressFill.fillAmount = tierProgress;

        // Detect tier change
        if (tierLabel != lastTierLabel && lastTierLabel != "")
            ShowTierBanner(tierLabel, count);
        lastTierLabel = tierLabel;

        // Color shift per tier
        if (orbCountText)
        {
            if      (tierLabel == "TIER II")  orbCountText.color = new Color(0.7f, 0.9f, 0.3f);
            else if (tierLabel == "TIER III") orbCountText.color = new Color(1.0f, 0.55f, 0.1f);
            else if (tierLabel == "MAX")      orbCountText.color = new Color(1.0f, 0.85f, 0.0f);
            else                              orbCountText.color = new Color(0.4f, 0.65f, 1f);
        }
    }

    public void FlashNewMaze()
    {
        if (newMazeText == null) return;
        if (newMazeCo != null) StopCoroutine(newMazeCo);
        newMazeCo = StartCoroutine(NewMazeFlash());
    }

    IEnumerator NewMazeFlash()
    {
        newMazeText.gameObject.SetActive(true);
        float t = 0f;
        while (t < 2.8f)
        {
            t += BADGE.Core.Time.DeltaTime;
            float alpha = t < 0.25f ? t / 0.25f :
                          t > 2.2f  ? 1f - (t - 2.2f) / 0.6f : 1f;
            SetTextAlpha(newMazeText, alpha);
            yield return null;
        }
        newMazeText.gameObject.SetActive(false);
    }

    void ShowTierBanner(string label, int count)
    {
        if (tierBannerCo != null) StopCoroutine(tierBannerCo);
        tierBannerCo = StartCoroutine(TierBannerAnim(label, count));
    }

    IEnumerator TierBannerAnim(string label, int count)
    {
        if (!tierBannerGO || !tierBannerText) yield break;
        tierBannerText.text = "★ " + label + " REACHED ★\n" + count.ToString("N0") + " Orbs";
        tierBannerGO.SetActive(true);

        float t = 0f;
        while (t < 3.5f)
        {
            t += BADGE.Core.Time.DeltaTime;
            float alpha = t < 0.4f ? t / 0.4f :
                          t > 2.8f ? 1f - (t - 2.8f) / 0.7f : 1f;
            SetTextAlpha(tierBannerText, alpha);
            yield return null;
        }
        tierBannerGO.SetActive(false);
    }

    // ── Helpers ───────────────────────────────────────────────────
    void SetTextAlpha(Text t, float a)
    {
        Color c = t.color; c.a = MathF.Clamp01(a); t.color = c;
    }

    GameObject MakeImage(Transform parent, string name, Color col)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        Image img = go.AddComponent<Image>();
        img.color = col;
        go.AddComponent<RectTransform>();
        return go;
    }

    Text MakeText(Transform parent, string content, Color col, int size,
                  Vector2 ancMin, Vector2 ancMax)
    {
        GameObject go = new GameObject("T_" + name);
        go.transform.SetParent(parent, false);
        Text t = go.AddComponent<Text>();
        t.text      = content;
        t.color     = col;
        t.fontSize  = size;
        t.font      = Resources.GetBuiltinResource<Font>("Arial.ttf");
        t.alignment = TextAnchor.MiddleLeft;

        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = ancMin;
        rt.anchorMax = ancMax;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return t;
    }

    void Anchor(GameObject go, Vector2 min, Vector2 max)
    {
        RectTransform rt = go.GetComponent<RectTransform>();
        if (!rt) rt = go.AddComponent<RectTransform>();
        rt.anchorMin = min;
        rt.anchorMax = max;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
    }
}
