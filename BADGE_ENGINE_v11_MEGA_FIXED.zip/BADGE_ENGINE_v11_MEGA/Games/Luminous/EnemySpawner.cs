using BADGE.Core;
using OpenTK.Mathematics;
using System.Collections.Generic;

/// <summary>
/// Finds valid open cells in the maze and spawns enemy creatures there.
/// Called by ProceduralMaze after each generation.

namespace BADGE.Games.Luminous;

/// Unity 2019.4 LTS compatible.
/// </summary>
public class EnemySpawner : MonoBehaviour
{
    public int   EnemyCount   = 7;
    public float MinDistFromPlayer = 9f;

    List<GameObject> active = new List<GameObject>();

    void Start() => Invoke(nameof(RespawnEnemies), 0.08f);

    public void RespawnEnemies()
    {
        ClearAll();

        ProceduralMaze maze = ProceduralMaze.Instance;
        if (maze == null) return;

        Vector3 pSpawn = maze.PlayerSpawnPos;

        // Collect candidate positions
        List<Vector3> candidates = new List<Vector3>();
        for (int x = 0; x < maze.Width;  x++)
        for (int y = 0; y < maze.Height; y++)
        {
            if (maze.IsWall(x, y)) continue;
            Vector3 wp = maze.GridToWorld(x, y);
            if (Vector3.Distance(wp, pSpawn) < MinDistFromPlayer) continue;
            candidates.Add(wp);
        }

        // Fisher-Yates shuffle
        for (int i = candidates.Count - 1; i > 0; i--)
        {
            int j = Random.Range(0, i + 1);
            Vector3 tmp    = candidates[i];
            candidates[i] = candidates[j];
            candidates[j] = tmp;
        }

        int spawnCount = MathF.Min(EnemyCount, candidates.Count);
        for (int i = 0; i < spawnCount; i++)
        {
            GameObject go = new GameObject("Enemy_" + i);
            go.Transform.Position = candidates[i] + Vector3.up * 0.75f;
            go.AddComponent<EnemyController>();
            active.Add(go);
        }
    }

    void ClearAll()
    {
        foreach (var e in active) if (e) Destroy(e);
        active.Clear();
    }
}
