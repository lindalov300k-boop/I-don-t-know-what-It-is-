using BADGE.Core;
using OpenTK.Mathematics;
using System.IO;

/// <summary>
/// Persistent singleton. Handles orb count with tiered milestones:

namespace BADGE.Games.Luminous;

///   Tier 1: 0   → 100   (increments of 1)
///   Tier 2: 100 → 1000  (increments of 1, continues past 100)
///   Tier 3: 1000 → 10000 (increments of 1, continues past 1000)
///   Stops tracking at 10000.
/// Saves to JSON on every collection.
/// </summary>
public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public int TotalOrbs { get; private set; }

    // Tier thresholds
    public const int TIER1_MAX  = 100;
    public const int TIER2_MAX  = 1000;
    public const int TIER3_MAX  = 10000;

    private string savePath;

    // ── Lifecycle ─────────────────────────────────────────────────
    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        SceneManager.Instance.DontDestroyOnLoad(gameObject);
        savePath = Path.Combine(Application.persistentDataPath, "luminous_save.json");
        LoadData();
    }

    // ── Orb API ───────────────────────────────────────────────────
    /// <summary>Returns current display tier string.</summary>
    public string GetTierLabel()
    {
        if (TotalOrbs < TIER1_MAX)  return "TIER I";
        if (TotalOrbs < TIER2_MAX)  return "TIER II";
        if (TotalOrbs < TIER3_MAX)  return "TIER III";
        return "MAX";
    }

    public int GetCurrentMilestone()
    {
        if (TotalOrbs < TIER1_MAX)  return TIER1_MAX;
        if (TotalOrbs < TIER2_MAX)  return TIER2_MAX;
        return TIER3_MAX;
    }

    public void AddOrb()
    {
        if (TotalOrbs >= TIER3_MAX) return;   // hard cap at 10,000
        TotalOrbs++;
        SaveData();
    }

    public float GetTierProgress()
    {
        if (TotalOrbs < TIER1_MAX)
            return TotalOrbs / (float)TIER1_MAX;
        if (TotalOrbs < TIER2_MAX)
            return (TotalOrbs - TIER1_MAX) / (float)(TIER2_MAX - TIER1_MAX);
        if (TotalOrbs < TIER3_MAX)
            return (TotalOrbs - TIER2_MAX) / (float)(TIER3_MAX - TIER2_MAX);
        return 1f;
    }

    // ── Persistence ───────────────────────────────────────────────
    [System.Serializable]
    class SaveData { public int totalOrbs; }

    void SaveData()
    {
        SaveData d = new SaveData { totalOrbs = TotalOrbs };
        File.WriteAllText(savePath, JsonUtility.ToJson(d, true));
    }

    void LoadData()
    {
        if (!File.Exists(savePath)) return;
        try
        {
            SaveData d = JsonUtility.FromJson<SaveData>(File.ReadAllText(savePath));
            if (d != null) TotalOrbs = MathF.Clamp(d.totalOrbs, 0, TIER3_MAX);
        }
        catch { TotalOrbs = 0; }
    }

    // ── Scene Loading ─────────────────────────────────────────────
    public void GoToMain()  => SceneManager.Instance.LoadScene("MainScene");
    public void GoToStart() => SceneManager.Instance.LoadScene("StartScene");
}
