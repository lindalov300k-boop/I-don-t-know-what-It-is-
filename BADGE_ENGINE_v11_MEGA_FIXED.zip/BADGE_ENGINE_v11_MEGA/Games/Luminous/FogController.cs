using BADGE.Core;
using OpenTK.Mathematics;

/// <summary>
/// Manages RenderSettings fog dynamically.
/// DEFAULT state : near-zero fog (pure darkness, player can't see anything).
/// GLOWING state : thick, colored, shifting fog — the light reveals but distorts.

namespace BADGE.Games.Luminous;

///
/// Fog layers:
///   - Base fog (linear) that rolls in close when glowing.
///   - A slow pulsing color shift (yellow → sickly green → orange) for dread.
///   - A secondary "deep" fog that makes walls further away disappear eerily.
///
/// Unity 2019.4 LTS — only RenderSettings, no URP volumes needed.
/// </summary>
public class FogController : MonoBehaviour
{
    public static FogController Instance;

    // ── Darkness state (no glow) ──────────────────────────────────
    // Absolute darkness: fog is essentially a black wall just past the player.
    const float DARK_START    = 0.1f;
    const float DARK_END      = 2.5f;
    static readonly Color DARK_COLOR = new Color(0f, 0f, 0f, 1f);

    // ── Glowing state ─────────────────────────────────────────────
    // When glowing, fog lifts a little but becomes COLORED and PULSING.
    // This creates the "torch in a nightmare" look.
    const float GLOW_START_NEAR = 5f;
    const float GLOW_START_FAR  = 9f;   // oscillates
    const float GLOW_END_NEAR   = 12f;
    const float GLOW_END_FAR    = 18f;  // oscillates

    // Fog colors that cycle when glowing — unsettling palette
    static readonly Color[] GLOW_COLORS = new Color[]
    {
        new Color(0.25f, 0.18f, 0.04f),   // deep amber
        new Color(0.18f, 0.24f, 0.04f),   // sickly yellow-green
        new Color(0.22f, 0.06f, 0.06f),   // blood-dark red
        new Color(0.10f, 0.15f, 0.22f),   // cold midnight blue
    };

    // ── Runtime ───────────────────────────────────────────────────
    float colorPhase   = 0f;
    float pulsePhase   = 0f;
    bool  playerGlowing = false;

    // Smooth transition
    float currentStart;
    float currentEnd;
    Color currentColor;

    void Awake()
    {
        Instance = this;
        ApplyDarkness();
    }

    void ApplyDarkness()
    {
        RenderSettings.fog          = true;
        RenderSettings.fogMode      = FogMode.Linear;
        RenderSettings.fogStartDistance = DARK_START;
        RenderSettings.fogEndDistance   = DARK_END;
        RenderSettings.fogColor         = DARK_COLOR;
        currentStart = DARK_START;
        currentEnd   = DARK_END;
        currentColor = DARK_COLOR;
    }

    // Called by PlayerController each frame
    public void SetGlowing(bool glow)
    {
        playerGlowing = glow;
    }

    void Update()
    {
        if (playerGlowing)
        {
            UpdateGlowFog();
        }
        else
        {
            UpdateDarkFog();
        }

        // Apply smoothed values
        RenderSettings.fogStartDistance = currentStart;
        RenderSettings.fogEndDistance   = currentEnd;
        RenderSettings.fogColor         = currentColor;
    }

    void UpdateGlowFog()
    {
        pulsePhase  += BADGE.Core.Time.DeltaTime * 0.9f;
        colorPhase  += BADGE.Core.Time.DeltaTime * 0.22f;

        // Pulse fog range — makes the "visibility bubble" breathe
        float pulse   = (MathF.Sin(pulsePhase) + 1f) * 0.5f;
        float targetS = MathF.Lerp(GLOW_START_NEAR, GLOW_START_FAR, pulse);
        float targetE = MathF.Lerp(GLOW_END_NEAR,   GLOW_END_FAR,   pulse);

        // Cycle through unsettling colors
        int   idxA = MathF.FloorToInt(colorPhase) % GLOW_COLORS.Length;
        int   idxB = (idxA + 1) % GLOW_COLORS.Length;
        float t    = colorPhase - MathF.Floor(colorPhase);
        Color targetColor = Color.Lerp(GLOW_COLORS[idxA], GLOW_COLORS[idxB], t);

        // Smooth transitions
        float spd = BADGE.Core.Time.DeltaTime * 3.5f;
        currentStart = MathF.Lerp(currentStart, targetS,     spd);
        currentEnd   = MathF.Lerp(currentEnd,   targetE,     spd);
        currentColor = Color.Lerp(currentColor, targetColor, spd * 0.6f);
    }

    void UpdateDarkFog()
    {
        // Snap back to darkness quickly
        float spd    = BADGE.Core.Time.DeltaTime * 5f;
        currentStart = MathF.Lerp(currentStart, DARK_START, spd);
        currentEnd   = MathF.Lerp(currentEnd,   DARK_END,   spd);
        currentColor = Color.Lerp(currentColor, DARK_COLOR, spd);
        pulsePhase   = 0f;
    }
}
