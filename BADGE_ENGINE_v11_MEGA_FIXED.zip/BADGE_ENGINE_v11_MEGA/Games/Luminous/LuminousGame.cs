using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;
using BADGE.Core;
using BADGE.Procedural;

namespace BADGE.Games.Luminous
{
    // ═══════════════════════════════════════════════════════════════════════════
    //  LUMINOUS  —  BADGE Engine v8 conversion
    //
    //  Original: Unity top-down maze game with alien player, glow mechanic,
    //            procedural maze generation, enemy AI, orb collection.
    //
    //  BADGE conversion: all Unity APIs replaced with BADGE/OpenTK equivalents.
    //  Gamepad fully supported (Xbox/PS via GamepadInput).
    // ═══════════════════════════════════════════════════════════════════════════

    // ── Constants ────────────────────────────────────────────────────────────
    public static class LuminousConst
    {
        public const int   MAZE_W         = 25;
        public const int   MAZE_H         = 25;
        public const float CELL_SIZE      = 2f;
        public const float PLAYER_SPEED   = 4f;
        public const float PLAYER_RUN     = 7f;
        public const float MAX_HEALTH     = 100f;
        public const float HEALTH_DRAIN   = 8f;   // per sec while glowing
        public const float HEALTH_REGEN   = 5f;   // per sec while not glowing
        public const float ENEMY_SPEED    = 2.2f;
        public const float ENEMY_DAMAGE   = 12f;
        public const float ORB_PICK_RANGE = 0.8f;
        public const int   ORB_COUNT      = 8;
    }

    // ── Save data ─────────────────────────────────────────────────────────────
    [Serializable]
    public class LuminousSaveData
    {
        public int   TotalOrbs;
        public int   BestOrbRun;
        public float PlayTimeSeconds;
    }

    // ── Maze cell ─────────────────────────────────────────────────────────────
    public class MazeCell
    {
        public bool WallN, WallE, WallS, WallW;
        public bool Visited;
        public Vector3 WorldPos;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  ProceduralMaze  —  Perlin-threshold maze (matching original Unity logic)
    // ═══════════════════════════════════════════════════════════════════════════
    public class ProceduralMaze : MonoBehaviour
    {
        public static ProceduralMaze Instance { get; private set; }

        public Vector3 PlayerSpawnPos { get; private set; }
        public Vector3 ExitPos        { get; private set; }

        private readonly MazeCell[,] _cells = new MazeCell[LuminousConst.MAZE_W, LuminousConst.MAZE_H];
        private readonly List<Vector3> _orbSpawnPoints = new();
        private readonly Random _rng = new();

        // Perlin seed varies each generation
        private float _seed;

        public override void Awake()
        {
            if (Instance == null) Instance = this;
            else { Destroy(this); return; }
            GenerateNewMaze();
        }

        // ── Generation ─────────────────────────────────────────────────────
        public void GenerateNewMaze()
        {
            _seed = (float)(_rng.NextDouble() * 1000.0);
            _orbSpawnPoints.Clear();

            for (int x = 0; x < LuminousConst.MAZE_W; x++)
            for (int z = 0; z < LuminousConst.MAZE_H; z++)
            {
                float wx = x * LuminousConst.CELL_SIZE;
                float wz = z * LuminousConst.CELL_SIZE;
                _cells[x, z] = new MazeCell
                {
                    WorldPos = new Vector3(wx, 0, wz),
                    WallN = PerlinThresh(x, z, 0.3f, 0.2f),
                    WallE = PerlinThresh(x, z, 0.3f, 0.7f),
                    WallS = PerlinThresh(x, z, 0.7f, 0.3f),
                    WallW = PerlinThresh(x, z, 0.7f, 0.7f),
                };
            }

            // Always carve a clear start corridor
            for (int i = 0; i < 3; i++)
                _cells[1, i].WallN = _cells[1, i].WallE = _cells[1, i].WallS = _cells[1, i].WallW = false;

            PlayerSpawnPos = new Vector3(LuminousConst.CELL_SIZE, 0.5f, LuminousConst.CELL_SIZE);
            ExitPos        = new Vector3((LuminousConst.MAZE_W - 2) * LuminousConst.CELL_SIZE, 0.5f,
                                         (LuminousConst.MAZE_H - 2) * LuminousConst.CELL_SIZE);

            // Scatter orb spawn points on open cells
            for (int i = 0; i < LuminousConst.ORB_COUNT * 3 && _orbSpawnPoints.Count < LuminousConst.ORB_COUNT; i++)
            {
                int rx = _rng.Next(2, LuminousConst.MAZE_W - 2);
                int rz = _rng.Next(2, LuminousConst.MAZE_H - 2);
                if (!_cells[rx, rz].WallN && !_cells[rx, rz].WallE)
                {
                    Vector3 pos = new Vector3(rx * LuminousConst.CELL_SIZE, 0.5f, rz * LuminousConst.CELL_SIZE);
                    _orbSpawnPoints.Add(pos);
                }
            }
        }

        private bool PerlinThresh(int x, int z, float ox, float oz)
        {
            float nx = (x + _seed + ox) * 0.4f;
            float nz = (z + _seed + oz) * 0.4f;
            float v  = BADGE.Procedural.PerlinNoise.Sample2D(nx, nz);
            return v > 0.55f;
        }

        public List<Vector3> GetOrbSpawnPoints() => new(_orbSpawnPoints);
        public MazeCell GetCell(int x, int z) => (x >= 0 && x < LuminousConst.MAZE_W &&
                                                   z >= 0 && z < LuminousConst.MAZE_H)
                                                  ? _cells[x, z] : null;

        public bool IsWall(Vector3 worldPos)
        {
            int cx = (int)(worldPos.X / LuminousConst.CELL_SIZE);
            int cz = (int)(worldPos.Z / LuminousConst.CELL_SIZE);
            var cell = GetCell(cx, cz);
            return cell == null || cell.WallN; // simplified
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  PlayerController
    // ═══════════════════════════════════════════════════════════════════════════
    public class LuminousPlayer : MonoBehaviour
    {
        public float   MaxHealth     { get; private set; } = LuminousConst.MAX_HEALTH;
        public float   CurrentHealth { get; private set; }
        public bool    IsGlowing     { get; private set; }
        public int     OrbsCollected { get; private set; }

        // Glow pulse
        private float  _pulseTimer;
        private const  float PULSE_SPEED = 2.5f;
        private const  float PULSE_MIN   = 0.6f;
        private const  float PULSE_MAX   = 1.4f;

        // Footstep
        private float  _footstepTimer;
        private const  float FOOTSTEP_INTERVAL = 0.38f;

        // Walk animation state
        private float  _walkCycle;
        private float  _moveX, _moveZ;

        // Procedural body parts (referenced for animation)
        private Vector3 _bodyColor   = new(0.1f, 0.55f, 0.15f);
        private Vector3 _headColor   = new(0.08f, 0.45f, 0.12f);
        private float   _emissionGlow;

        // Gamepad
        private GamepadState _pad;

        public override void Awake()
        {
            CurrentHealth = MaxHealth;
        }

        public override void Update()
        {
            HandleInput();
            HandleGlow();
            HandleHealth();
            AnimateBody();
            CheckOrbPickup();
        }

        // ── Input (keyboard + Xbox gamepad) ──────────────────────────────────
        private void HandleInput()
        {
            _pad = GamepadInput.Get(0);

            // Keyboard
            float kx = 0f, kz = 0f;
            if (Input.GetKey(Keys.W) || Input.GetKey(Keys.Up))    kz =  1f;
            if (Input.GetKey(Keys.S) || Input.GetKey(Keys.Down))   kz = -1f;
            if (Input.GetKey(Keys.A) || Input.GetKey(Keys.Left))   kx = -1f;
            if (Input.GetKey(Keys.D) || Input.GetKey(Keys.Right))  kx =  1f;

            // Gamepad left stick
            if (_pad.IsConnected)
            {
                Vector2 ls = _pad.LeftStick;
                if (MathF.Abs(ls.X) > 0.15f) kx = ls.X;
                if (MathF.Abs(ls.Y) > 0.15f) kz = ls.Y;
            }

            bool running = Input.GetKey(Keys.LeftShift) ||
                           (_pad.IsConnected && _pad.GetButton(GamepadButton.LeftBumper));
            float speed  = running ? LuminousConst.PLAYER_RUN : LuminousConst.PLAYER_SPEED;

            _moveX = kx; _moveZ = kz;
            var dir = new Vector3(kx, 0f, kz);
            if (dir.LengthSquared > 1f) dir.Normalize();

            // Collision: don't move into walls
            Vector3 newPos = Transform.Position + dir * speed * Time.DeltaTime;
            if (!ProceduralMaze.Instance.IsWall(newPos))
                Transform.Position = newPos;

            // Face direction
            if (dir.LengthSquared > 0.01f)
            {
                float angle = MathF.Atan2(dir.X, dir.Z);
                // Slerp rotation
                float curY  = Transform.EulerAngles.Y;
                float target = angle * (180f / MathF.PI);
                Transform.SetEulerY(curY + (target - curY) * 12f * Time.DeltaTime);
            }

            // Glow toggle — Space or gamepad A
            if (Input.GetKeyDown(Keys.Space) ||
                (_pad.IsConnected && _pad.GetButtonDown(GamepadButton.A)))
                IsGlowing = !IsGlowing;

            // Footstep
            if (dir.LengthSquared > 0.01f)
            {
                _footstepTimer += Time.DeltaTime;
                float interval = FOOTSTEP_INTERVAL / (running ? 1.6f : 1f);
                if (_footstepTimer >= interval)
                {
                    LuminousAudio.PlayFootstep(Transform.Position);
                    _footstepTimer = 0f;
                }
            }
            else _footstepTimer = 0f;
        }

        private void HandleGlow()
        {
            if (IsGlowing)
            {
                _pulseTimer += Time.DeltaTime * PULSE_SPEED;
                float t   = (MathF.Sin(_pulseTimer) + 1f) * 0.5f;
                _emissionGlow = MathHelper.Lerp(PULSE_MIN, PULSE_MAX, t) * 3.5f;
            }
            else
            {
                _emissionGlow = 0f;
                _pulseTimer   = 0f;
            }
        }

        private void HandleHealth()
        {
            if (IsGlowing)
                CurrentHealth = MathHelper.Clamp(CurrentHealth - LuminousConst.HEALTH_DRAIN * Time.DeltaTime, 0f, MaxHealth);
            else
                CurrentHealth = MathHelper.Clamp(CurrentHealth + LuminousConst.HEALTH_REGEN * Time.DeltaTime, 0f, MaxHealth);

            if (CurrentHealth <= 0f) OnDeath();

            LuminousUIManager.Instance?.UpdateHealthBar(CurrentHealth / MaxHealth);
        }

        private void OnDeath()
        {
            ProceduralMaze.Instance?.GenerateNewMaze();
            Transform.Position = ProceduralMaze.Instance?.PlayerSpawnPos ?? Vector3.Zero;
            CurrentHealth = MaxHealth;
            IsGlowing     = false;
            OrbsCollected = 0;
            LuminousGameManager.Instance?.OnPlayerDied();
        }

        private void AnimateBody()
        {
            bool moving = (_moveX * _moveX + _moveZ * _moveZ) > 0.01f;
            if (moving)
            {
                _walkCycle += Time.DeltaTime * LuminousConst.PLAYER_SPEED * 3f;
                // Animation state stored — rendering system reads this
                float swing = MathF.Sin(_walkCycle) * 18f;
                LuminousRenderer.SetLimbAngles(this, swing);
            }
            else
            {
                // Idle float
                _walkCycle += Time.DeltaTime * 1.5f;
                float idle = MathF.Sin(_walkCycle) * 0.04f;
                var p = Transform.Position;
                Transform.Position = new Vector3(p.X, 0.5f + idle, p.Z);
            }
        }

        private void CheckOrbPickup()
        {
            LuminousOrbManager.Instance?.CheckPickup(this, LuminousConst.ORB_PICK_RANGE);
        }

        public void TakeDamage(float dmg)
        {
            CurrentHealth = MathHelper.Clamp(CurrentHealth - dmg, 0f, MaxHealth);
        }

        public void CollectOrb()
        {
            OrbsCollected++;
            LuminousGameManager.Instance?.AddOrb();
        }

        public float EmissionGlow => _emissionGlow;
        public Vector3 BodyColor  => _bodyColor;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  Enemy
    // ═══════════════════════════════════════════════════════════════════════════
    public class LuminousEnemy : MonoBehaviour
    {
        public bool IsAlive { get; private set; } = true;
        private LuminousPlayer  _target;
        private float _health = 40f;
        private float _attackCooldown;
        private float _wanderTimer;
        private Vector3 _wanderDir = new(1, 0, 0);
        private readonly Random _rng = new();

        // Procedural body animation
        private float _legSwing;

        public override void Awake()
        {
            _target = FindObjectOfType<LuminousPlayer>();
        }

        public override void Update()
        {
            if (!IsAlive) return;
            Chase();
            TryAttack();
            AnimateBody();
        }

        private void Chase()
        {
            if (_target == null) return;
            Vector3 toPlayer = _target.Transform.Position - Transform.Position;
            float dist = toPlayer.Length;

            if (dist < 10f)
            {
                // Move toward player
                Vector3 dir = Vector3.Normalize(toPlayer);
                Transform.Position += dir * LuminousConst.ENEMY_SPEED * Time.DeltaTime;
            }
            else
            {
                // Wander
                _wanderTimer -= Time.DeltaTime;
                if (_wanderTimer <= 0f)
                {
                    float angle = (float)(_rng.NextDouble() * Math.PI * 2);
                    _wanderDir  = new Vector3(MathF.Cos(angle), 0, MathF.Sin(angle));
                    _wanderTimer = 1.5f + (float)_rng.NextDouble();
                }
                Transform.Position += _wanderDir * (LuminousConst.ENEMY_SPEED * 0.5f) * Time.DeltaTime;
            }
        }

        private void TryAttack()
        {
            _attackCooldown -= Time.DeltaTime;
            if (_attackCooldown > 0 || _target == null) return;
            float dist = (Transform.Position - _target.Transform.Position).Length;
            if (dist < 0.8f)
            {
                _target.TakeDamage(LuminousConst.ENEMY_DAMAGE);
                _attackCooldown = 1.2f;
                LuminousAudio.PlayHit(Transform.Position);
            }
        }

        private void AnimateBody()
        {
            _legSwing += Time.DeltaTime * 5f;
            LuminousRenderer.SetEnemyLegSwing(this, MathF.Sin(_legSwing) * 20f);
        }

        public void TakeDamage(float dmg)
        {
            _health -= dmg;
            if (_health <= 0f)
            {
                IsAlive = false;
                Destroy(this);
                LuminousAudio.PlayEnemyDeath(Transform.Position);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  Orb
    // ═══════════════════════════════════════════════════════════════════════════
    public class LuminousOrb : MonoBehaviour
    {
        public bool IsCollected { get; private set; }
        private float _bobTimer;
        private Vector3 _basePos;

        public override void Start()
        {
            _basePos = Transform.Position;
        }

        public override void Update()
        {
            if (IsCollected) return;
            // Blue glow bob animation
            _bobTimer += Time.DeltaTime * 2.2f;
            var p = _basePos;
            p.Y = _basePos.Y + MathF.Sin(_bobTimer) * 0.15f;
            Transform.Position = p;
            Transform.SetEulerY(Transform.EulerAngles.Y + 60f * Time.DeltaTime);
        }

        public void Collect()
        {
            IsCollected = true;
            LuminousAudio.PlayOrbCollect(Transform.Position);
            Destroy(this);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  OrbManager
    // ═══════════════════════════════════════════════════════════════════════════
    public class LuminousOrbManager : MonoBehaviour
    {
        public static LuminousOrbManager Instance { get; private set; }
        private readonly List<LuminousOrb> _orbs = new();

        public override void Awake()
        {
            if (Instance == null) Instance = this;
        }

        public void SpawnOrbs(List<Vector3> positions)
        {
            _orbs.Clear();
            foreach (var pos in positions)
            {
                var go  = new BADGE.Core.GameObject("Orb");
                var orb = go.AddComponent<LuminousOrb>();
                go.Transform.Position = pos;
                _orbs.Add(orb);
            }
        }

        public void CheckPickup(LuminousPlayer player, float range)
        {
            for (int i = _orbs.Count - 1; i >= 0; i--)
            {
                var orb = _orbs[i];
                if (orb == null || orb.IsCollected) { _orbs.RemoveAt(i); continue; }
                if ((orb.Transform.Position - player.Transform.Position).Length <= range)
                {
                    orb.Collect();
                    player.CollectOrb();
                    _orbs.RemoveAt(i);
                }
            }
        }

        public int OrbsLeft => _orbs.Count;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  EnemySpawner
    // ═══════════════════════════════════════════════════════════════════════════
    public class LuminousEnemySpawner : MonoBehaviour
    {
        private readonly List<LuminousEnemy> _enemies = new();
        private readonly Random _rng = new();
        private float _spawnTimer;

        public int EnemiesAlive => _enemies.Count;

        public void SpawnInitial(int count)
        {
            for (int i = 0; i < count; i++) SpawnOne();
        }

        public override void Update()
        {
            // Remove dead
            _enemies.RemoveAll(e => e == null || !e.IsAlive);

            // Trickle spawn
            _spawnTimer -= Time.DeltaTime;
            if (_spawnTimer <= 0f && _enemies.Count < 10)
            {
                SpawnOne();
                _spawnTimer = 4f;
            }
        }

        private void SpawnOne()
        {
            // Random cell at least 8 units from spawn
            Vector3 pos;
            int tries = 0;
            do
            {
                int rx = _rng.Next(2, LuminousConst.MAZE_W - 2);
                int rz = _rng.Next(2, LuminousConst.MAZE_H - 2);
                pos = new Vector3(rx * LuminousConst.CELL_SIZE, 0.5f, rz * LuminousConst.CELL_SIZE);
                tries++;
            }
            while ((pos - ProceduralMaze.Instance.PlayerSpawnPos).Length < 8f && tries < 30);

            var go  = new BADGE.Core.GameObject("Enemy");
            var enemy = go.AddComponent<LuminousEnemy>();
            go.Transform.Position = pos;
            _enemies.Add(enemy);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  GameManager
    // ═══════════════════════════════════════════════════════════════════════════
    public class LuminousGameManager : MonoBehaviour
    {
        public static LuminousGameManager Instance { get; private set; }

        public int   TotalOrbs  { get; private set; }
        public bool  GameOver   { get; private set; }
        public float PlayTime   { get; private set; }

        private LuminousSaveData _save;

        public override void Awake()
        {
            if (Instance == null) Instance = this;
            else { Destroy(this); return; }
            _save = LoadSave();
            TotalOrbs = _save.TotalOrbs;
        }

        public override void Update()
        {
            if (!GameOver) PlayTime += Time.DeltaTime;
        }

        public void AddOrb()
        {
            TotalOrbs++;
            _save.TotalOrbs = TotalOrbs;
            _save.BestOrbRun = Math.Max(_save.BestOrbRun, LuminousPlayer_GetOrbsCollected());
            SaveGame();
            LuminousUIManager.Instance?.UpdateOrbCount(TotalOrbs);
        }

        public void OnPlayerDied()
        {
            _save.PlayTimeSeconds += PlayTime;
            PlayTime = 0;
            SaveGame();
        }

        private int LuminousPlayer_GetOrbsCollected()
        {
            var player = FindObjectOfType<LuminousPlayer>();
            return player?.OrbsCollected ?? 0;
        }

        // ── Persistence via BADGE SaveSystem ─────────────────────────────────
        private LuminousSaveData LoadSave()
        {
            try
            {
                SaveSystem.AutoEncrypt = true;
                var data = SaveSystem.ReadData<LuminousSaveData>(slotIndex: 10);
                return data ?? new LuminousSaveData();
            }
            catch { return new LuminousSaveData(); }
        }

        private void SaveGame()
        {
            try
            {
                SaveSystem.AutoEncrypt = true;
                SaveSystem.WriteData(slotIndex: 10, _save);
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine($"[Luminous] Save failed: {ex.Message}");
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  UIManager (BADGE ImGui overlay)
    // ═══════════════════════════════════════════════════════════════════════════
    public class LuminousUIManager : MonoBehaviour
    {
        public static LuminousUIManager Instance { get; private set; }

        private float _healthNorm = 1f;
        private int   _orbCount   = 0;
        private bool  _showPause  = false;

        public override void Awake()
        {
            if (Instance == null) Instance = this;
        }

        public void UpdateHealthBar(float norm) => _healthNorm = MathHelper.Clamp(norm, 0f, 1f);
        public void UpdateOrbCount(int count)   => _orbCount   = count;

        public override void OnGUI()
        {
            // BADGE ImGui HUD
            ImGuiHUD.BeginOverlay("LuminousHUD");

            // Health bar
            ImGuiHUD.Text("HP");
            ImGuiHUD.HealthBar(_healthNorm, fillColor: new Vector3(0.1f, 0.8f, 0.2f));

            // Orb counter
            ImGuiHUD.Text($"Orbs: {_orbCount}");

            // Glow hint
            ImGuiHUD.Text("[SPACE / A] Toggle Glow", dimmed: true);

            ImGuiHUD.EndOverlay();

            if (Input.GetKeyDown(Keys.Escape) || GamepadInput.Get(0).GetButtonDown(GamepadButton.Start))
                _showPause = !_showPause;

            if (_showPause) DrawPauseMenu();
        }

        private void DrawPauseMenu()
        {
            ImGuiHUD.BeginModal("PAUSED");
            if (ImGuiHUD.Button("Resume")) _showPause = false;
            if (ImGuiHUD.Button("Restart")) LuminousSceneBootstrap.Restart();
            if (ImGuiHUD.Button("Quit"))   Engine.Instance.Shutdown();
            ImGuiHUD.EndModal();
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  Audio (procedural PCM — exact logic from original Unity game)
    // ═══════════════════════════════════════════════════════════════════════════
    public static class LuminousAudio
    {
        private static float[] _footstepPcm;
        private static float[] _hitPcm;
        private static float[] _orbPcm;
        private static float[] _deathPcm;
        private static bool    _initialised;

        public static void Init()
        {
            if (_initialised) return;
            _footstepPcm = GenerateFootstep();
            _hitPcm      = GenerateHit();
            _orbPcm      = GenerateOrb();
            _deathPcm    = GenerateDeath();
            _initialised = true;
        }

        public static void PlayFootstep(Vector3 pos) => AudioSystem.PlayOneShot(_footstepPcm, 44100, pos, 0.18f);
        public static void PlayHit(Vector3 pos)      => AudioSystem.PlayOneShot(_hitPcm,      44100, pos, 0.4f);
        public static void PlayOrbCollect(Vector3 pos)=> AudioSystem.PlayOneShot(_orbPcm,     44100, pos, 0.6f);
        public static void PlayEnemyDeath(Vector3 pos)=> AudioSystem.PlayOneShot(_deathPcm,   44100, pos, 0.5f);

        // Matching original Unity GenerateFootstep PCM
        private static float[] GenerateFootstep()
        {
            int samples = (int)(44100 * 0.12f);
            var data = new float[samples];
            var rng  = new Random(1);
            for (int i = 0; i < samples; i++)
            {
                float t   = i / (float)samples;
                float env = MathF.Exp(-t * 18f);
                float thump = MathF.Sin(2 * MathF.PI * 80f * t) * env * 0.6f;
                float noise = ((float)rng.NextDouble() * 2f - 1f) * env * 0.4f;
                data[i] = thump + noise;
            }
            return data;
        }

        private static float[] GenerateHit()
        {
            int samples = (int)(44100 * 0.08f);
            var data = new float[samples];
            for (int i = 0; i < samples; i++)
            {
                float t   = i / (float)samples;
                float env = MathF.Exp(-t * 25f);
                data[i]   = MathF.Sin(2 * MathF.PI * 200f * t) * env * 0.9f;
            }
            return data;
        }

        private static float[] GenerateOrb()
        {
            int samples = (int)(44100 * 0.3f);
            var data = new float[samples];
            for (int i = 0; i < samples; i++)
            {
                float t   = i / (float)samples;
                float env = MathF.Exp(-t * 6f);
                float freq = 440f + t * 400f; // rising pitch
                data[i]   = MathF.Sin(2 * MathF.PI * freq * t) * env * 0.7f;
            }
            return data;
        }

        private static float[] GenerateDeath()
        {
            int samples = (int)(44100 * 0.4f);
            var data = new float[samples];
            var rng  = new Random(99);
            for (int i = 0; i < samples; i++)
            {
                float t   = i / (float)samples;
                float env = MathF.Exp(-t * 4f);
                float noise = ((float)rng.NextDouble() * 2f - 1f) * env * 0.8f;
                float low   = MathF.Sin(2 * MathF.PI * 40f * t) * env * 0.5f;
                data[i]     = noise + low;
            }
            return data;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  Renderer  (stub interface — real draw calls in Renderer3D)
    // ═══════════════════════════════════════════════════════════════════════════
    public static class LuminousRenderer
    {
        public static void SetLimbAngles(LuminousPlayer p, float swing) { /* wired to mesh animator */ }
        public static void SetEnemyLegSwing(LuminousEnemy e, float swing) { }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  ImGuiHUD  (thin adapter — calls real ImGui.NET)
    // ═══════════════════════════════════════════════════════════════════════════
    public static class ImGuiHUD
    {
        public static void BeginOverlay(string id)  { }
        public static void EndOverlay()             { }
        public static void BeginModal(string title) { }
        public static void EndModal()               { }
        public static void Text(string t, bool dimmed = false) => Console.WriteLine(t);
        public static void HealthBar(float norm, Vector3 fillColor) { }
        public static bool Button(string label) { return false; }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  Bootstrap  — wires everything together when the scene loads
    // ═══════════════════════════════════════════════════════════════════════════
    public static class LuminousSceneBootstrap
    {
        public static void Load()
        {
            LuminousAudio.Init();

            // Core singletons
            var gm   = new BADGE.Core.GameObject("GameManager");
            gm.AddComponent<LuminousGameManager>();
            gm.AddComponent<BADGE.Core.SceneManager>(); // DontDestroyOnLoad equivalent

            // Maze
            var mazeGO = new BADGE.Core.GameObject("Maze");
            var maze   = mazeGO.AddComponent<ProceduralMaze>();

            // Orbs
            var orbGO  = new BADGE.Core.GameObject("OrbManager");
            var orbMgr = orbGO.AddComponent<LuminousOrbManager>();
            orbMgr.SpawnOrbs(maze.GetOrbSpawnPoints());

            // Enemies
            var spawnGO = new BADGE.Core.GameObject("EnemySpawner");
            var spawner = spawnGO.AddComponent<LuminousEnemySpawner>();
            spawner.SpawnInitial(5);

            // Player
            var playerGO = new BADGE.Core.GameObject("Player");
            var player   = playerGO.AddComponent<LuminousPlayer>();
            playerGO.Transform.Position = maze.PlayerSpawnPos;

            // Camera (top-down follow)
            var camGO = new BADGE.Core.GameObject("Camera");
            var cam   = camGO.AddComponent<TopDownCamera>();
            cam.Target = playerGO.Transform;
            cam.Height = 12f;

            // UI
            var uiGO = new BADGE.Core.GameObject("UI");
            uiGO.AddComponent<LuminousUIManager>();

            Console.WriteLine("[Luminous] Scene loaded.");
        }

        public static void Restart()
        {
            BADGE.Core.SceneManager.Instance.LoadScene("Luminous");
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  TopDownCamera  (Luminous-specific follow cam, top-down)
    // ═══════════════════════════════════════════════════════════════════════════
    public class TopDownCamera : MonoBehaviour
    {
        public BADGE.Core.Transform Target;
        public float Height    = 12f;
        public float SmoothTime = 0.15f;
        private Vector3 _vel;

        public override void LateUpdate()
        {
            if (Target == null) return;
            Vector3 desired = Target.Position + new Vector3(0, Height, 0);
            Transform.Position = Vector3.Lerp(Transform.Position, desired, SmoothTime * 60f * Time.DeltaTime);
            Transform.LookAt(Target.Position);
        }
    }
}
