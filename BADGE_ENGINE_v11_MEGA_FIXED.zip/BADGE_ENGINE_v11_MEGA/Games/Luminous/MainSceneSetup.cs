using BADGE.Core;
using OpenTK.Mathematics;

/// <summary>
/// Bootstraps the entire MainScene at runtime.
/// ONE empty GameObject + this component = full game.
///

namespace BADGE.Games.Luminous;

/// CRITICAL: No directional light is created.
///           Pure darkness, only player's glow light provides visibility.
///           Fog is managed by FogController.
///
/// Unity 2019.4 LTS compatible.
/// </summary>
public class MainSceneSetup : MonoBehaviour
{
    void Awake()
    {
        // Destroy any pre-existing lights in scene (e.g. default directional light)
        Light[] sceneLights = FindObjectsOfType<Light>();
        foreach (Light l in sceneLights)
            Destroy(l.gameObject);

        SetupRender();
        SetupCamera();
        EnsureGameManager();
        SetupFog();
        SetupUI();
        SetupMaze();
        SetupPlayer();
        SetupOrb();
        SetupEnemies();
    }

    // ── Render Settings ───────────────────────────────────────────
    void SetupRender()
    {
        // Absolute black — no ambient at all
        RenderSettings.ambientMode  = AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0f, 0f, 0f, 1f);
        RenderSettings.ambientIntensity = 0f;
        // Fog is managed by FogController, but ensure it's on
        RenderSettings.fog = true;
    }

    // ── Camera ────────────────────────────────────────────────────
    void SetupCamera()
    {
        Camera cam = Camera.main;

        if (cam == null)
        {
            GameObject camGO = new GameObject("Main Camera");
            camGO.tag = "MainCamera";
            cam = camGO.AddComponent<Camera>();
            camGO.AddComponent<AudioListener>();
        }

        cam.clearFlags      = CameraClearFlags.SolidColor;
        cam.backgroundColor = Color.black;
        cam.farClipPlane    = 80f;
        cam.fieldOfView     = 62f;

        // Remove any lights attached to camera
        Light camLight = cam.GetComponent<Light>();
        if (camLight) Destroy(camLight);

        if (!cam.GetComponent<CameraFollow>())
            cam.gameObject.AddComponent<CameraFollow>();
    }

    // ── GameManager ───────────────────────────────────────────────
    void EnsureGameManager()
    {
        if (GameManager.Instance == null)
        {
            new GameObject("GameManager").AddComponent<GameManager>();
        }
    }

    // ── Fog Controller ────────────────────────────────────────────
    void SetupFog()
    {
        if (FindObjectOfType<FogController>() == null)
            new GameObject("FogController").AddComponent<FogController>();
    }

    // ── UI ────────────────────────────────────────────────────────
    void SetupUI()
    {
        if (UIManager.Instance == null)
            new GameObject("UIManager").AddComponent<UIManager>();

        // Refresh orb display from save
        if (UIManager.Instance && GameManager.Instance)
            UIManager.Instance.SetOrbs(
                GameManager.Instance.TotalOrbs,
                GameManager.Instance.GetTierProgress(),
                GameManager.Instance.GetTierLabel());
    }

    // ── Maze ──────────────────────────────────────────────────────
    void SetupMaze()
    {
        GameObject mazeGO = new GameObject("ProceduralMaze");
        mazeGO.AddComponent<ProceduralMaze>();
    }

    // ── Player ────────────────────────────────────────────────────
    void SetupPlayer()
    {
        GameObject p = new GameObject("Player");
        p.tag = "Player";

        ProceduralMaze maze = FindObjectOfType<ProceduralMaze>();
        p.Transform.Position = maze != null
            ? maze.PlayerSpawnPos
            : new Vector3(16f, 0.6f, 16f);

        p.AddComponent<PlayerController>();
    }

    // ── Orb ───────────────────────────────────────────────────────
    void SetupOrb()
    {
        GameObject orb = new GameObject("Orb");
        ProceduralMaze maze = FindObjectOfType<ProceduralMaze>();
        orb.Transform.Position = maze != null
            ? maze.OrbSpawnPos
            : new Vector3(24f, 1f, 24f);
        orb.AddComponent<OrbController>();
    }

    // ── Enemies ───────────────────────────────────────────────────
    void SetupEnemies()
    {
        new GameObject("EnemySpawner").AddComponent<EnemySpawner>();
    }
}
