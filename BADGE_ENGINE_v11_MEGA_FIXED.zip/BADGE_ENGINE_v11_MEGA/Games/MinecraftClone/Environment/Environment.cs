using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.ECS;
using BADGE.Rendering;
using OpenTK.Mathematics;

namespace Games.MinecraftClone.Environment
{
    // ════════════════════════════════════════════════════════════════════════
    //  DAY / NIGHT CYCLE
    // ════════════════════════════════════════════════════════════════════════
    public class DayNightCycle : MonoBehaviour
    {
        public float DayDurationSeconds { get; set; } = 1200f;  // 20 min = 1 MC day
        public float TimeOfDay { get; private set; } = 6f;       // 0-24 hours

        private float _elapsed = 0f;

        // Minecraft-accurate colour table by hour
        private static readonly (float hour, Vector3 sky, Vector3 fog, float sunIntensity, float moonIntensity)[] _timeTable =
        {
            (0f,  new(0.005f,0.005f,0.02f), new(0.005f,0.005f,0.015f), 0f,   0.1f),  // midnight
            (5f,  new(0.01f, 0.01f, 0.04f), new(0.01f, 0.01f, 0.04f),  0f,   0.05f), // pre-dawn
            (6f,  new(0.6f,  0.35f, 0.2f),  new(0.7f,  0.5f,  0.3f),   0.3f, 0f),    // sunrise
            (8f,  new(0.45f, 0.7f,  1.0f),  new(0.7f,  0.8f,  0.9f),   0.9f, 0f),    // morning
            (12f, new(0.3f,  0.6f,  1.0f),  new(0.6f,  0.75f, 0.9f),   1.0f, 0f),    // noon
            (17f, new(0.45f, 0.7f,  1.0f),  new(0.7f,  0.8f,  0.9f),   0.9f, 0f),    // afternoon
            (18f, new(0.7f,  0.45f, 0.25f), new(0.8f,  0.6f,  0.35f),  0.4f, 0f),    // sunset
            (19f, new(0.15f, 0.1f,  0.2f),  new(0.1f,  0.08f, 0.15f),  0f,   0.2f),  // dusk
            (21f, new(0.01f, 0.01f, 0.05f), new(0.008f,0.008f,0.03f),  0f,   0.3f),  // night
            (24f, new(0.005f,0.005f,0.02f), new(0.005f,0.005f,0.015f), 0f,   0.1f),  // wrap
        };

        public Vector3 CurrentSkyColor    { get; private set; }
        public Vector3 CurrentFogColor    { get; private set; }
        public float   SunIntensity       { get; private set; }
        public float   MoonIntensity      { get; private set; }
        public float   AmbientLight       { get; private set; }
        public bool    IsDay              => TimeOfDay > 6f && TimeOfDay < 19f;
        public bool    IsNight            => !IsDay;

        // Sun/moon world-space direction
        public Vector3 SunDirection       { get; private set; }
        public Vector3 MoonDirection      { get; private set; }

        public string TimeOfDayName =>
            TimeOfDay < 6 ? "Night" :
            TimeOfDay < 8 ? "Sunrise" :
            TimeOfDay < 12? "Morning" :
            TimeOfDay < 17? "Afternoon" :
            TimeOfDay < 19? "Sunset" : "Night";

        public override void Update(float dt)
        {
            _elapsed += dt;
            TimeOfDay = (_elapsed / DayDurationSeconds * 24f) % 24f;

            // Interpolate sky/fog colours
            SampleTimeTable(TimeOfDay);

            // Sun moves in an arc (0 = dawn east horizon, 12 = zenith, 19 = west horizon)
            float sunAngle = (TimeOfDay - 6f) / 14f * MathF.PI;  // 0 to PI
            SunDirection   = Vector3.Normalize(new Vector3(MathF.Cos(sunAngle), MathF.Sin(sunAngle), 0));
            MoonDirection  = -SunDirection;

            // Ambient light: 0.05 (midnight) to 1.0 (noon), with moon bump
            AmbientLight = MathHelper.Clamp(SunIntensity * 0.85f + MoonIntensity * 0.15f + 0.05f, 0f, 1f);

            // Update scene lighting
            UpdateLighting();
        }

        private void SampleTimeTable(float hour)
        {
            for (int i = 0; i < _timeTable.Length - 1; i++)
            {
                var a = _timeTable[i]; var b = _timeTable[i + 1];
                if (hour >= a.hour && hour < b.hour)
                {
                    float t = (hour - a.hour) / (b.hour - a.hour);
                    CurrentSkyColor  = Vector3.Lerp(a.sky,  b.sky,  t);
                    CurrentFogColor  = Vector3.Lerp(a.fog,  b.fog,  t);
                    SunIntensity     = a.sunIntensity  + (b.sunIntensity  - a.sunIntensity)  * t;
                    MoonIntensity    = a.moonIntensity + (b.moonIntensity - a.moonIntensity) * t;
                    return;
                }
            }
        }

        private void UpdateLighting()
        {
            // Push values to the renderer and lighting manager
            // LightingManager.Instance.SetSunDirection(SunDirection);
            // LightingManager.Instance.SetAmbient(new Vector3(AmbientLight));
            // Renderer3D.SetClearColor(CurrentSkyColor);
        }

        // Game-time helpers
        public void SetTime(float hours) { TimeOfDay = hours % 24f; _elapsed = hours / 24f * DayDurationSeconds; }
        public void SetDay()   => SetTime(6f);
        public void SetNight() => SetTime(19f);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  WEATHER SYSTEM
    // ════════════════════════════════════════════════════════════════════════
    public class WeatherSystem : MonoBehaviour
    {
        public WeatherType CurrentWeather { get; private set; } = WeatherType.Clear;

        private float _transitionTimer = 0f;
        private float _weatherDuration = 0f;
        private float _rainIntensity   = 0f;
        private float _thunderTimer    = 0f;
        private Random _rng = new();

        // Particle refs
        private BADGE.VFX.ParticleSystem? _rainParticles;
        private BADGE.VFX.ParticleSystem? _snowParticles;

        public float RainIntensity  => _rainIntensity;
        public bool  IsRaining      => CurrentWeather == WeatherType.Rain || CurrentWeather == WeatherType.Thunder;
        public bool  IsSnowing      => CurrentWeather == WeatherType.Snow;
        public bool  IsThundering   => CurrentWeather == WeatherType.Thunder;

        public override void Start()
        {
            // Create particle systems for rain and snow
            _weatherDuration = GetRandomDuration();
        }

        public override void Update(float dt)
        {
            _transitionTimer += dt;

            if (_transitionTimer >= _weatherDuration)
            {
                ChangeWeather();
                _transitionTimer = 0;
                _weatherDuration = GetRandomDuration();
            }

            // Transition rain intensity
            float targetIntensity = IsRaining || IsSnowing ? 1f : 0f;
            _rainIntensity = MathHelper.Lerp(_rainIntensity, targetIntensity, dt * 0.5f);

            // Thunder
            if (IsThundering)
            {
                _thunderTimer -= dt;
                if (_thunderTimer <= 0)
                {
                    TriggerLightning();
                    _thunderTimer = (float)(_rng.NextDouble() * 5 + 2);
                }
            }

            UpdateParticles(dt);
        }

        private void ChangeWeather()
        {
            WeatherType[] options = { WeatherType.Clear, WeatherType.Clear, WeatherType.Clear,
                                      WeatherType.Rain,  WeatherType.Thunder, WeatherType.Snow };
            CurrentWeather = options[_rng.Next(options.Length)];
            Console.WriteLine($"[Weather] Changed to {CurrentWeather}");
        }

        private float GetRandomDuration() => (float)(_rng.NextDouble() * 600 + 120); // 2-12 minutes

        private void TriggerLightning()
        {
            Console.WriteLine("[Weather] Lightning strike!");
            // Flash white screen briefly, play thunder sound with delay
        }

        private void UpdateParticles(float dt)
        {
            if (_rainParticles == null) return;

            if (IsRaining)
            {
                _rainParticles.EmissionRate = 500 * _rainIntensity;
                if (!_rainParticles.Playing) _rainParticles.Play();
            }
            else _rainParticles.Stop();
        }

        public void SetWeather(WeatherType type) { CurrentWeather = type; }
    }

    public enum WeatherType { Clear, Rain, Thunder, Snow, Fog }

    // ════════════════════════════════════════════════════════════════════════
    //  AMBIENT SOUND MANAGER
    // ════════════════════════════════════════════════════════════════════════
    public class AmbientSoundManager : MonoBehaviour
    {
        private DayNightCycle _cycle = null!;
        private WeatherSystem _weather = null!;
        private Random _rng = new();
        private float  _ambientTimer = 0f;

        // Ambient sound groups
        private static readonly string[][] _daySounds =
        {
            new[] { "birds_chirp", "leaves_rustle", "wind_light" },
            new[] { "village_ambient", "water_stream" }
        };

        private static readonly string[][] _nightSounds =
        {
            new[] { "crickets", "owl_hoot", "wolf_howl" },
            new[] { "zombie_distant", "skeleton_distant" }
        };

        public override void Update(float dt)
        {
            _ambientTimer -= dt;
            if (_ambientTimer <= 0)
            {
                PlayAmbientSound();
                _ambientTimer = (float)(_rng.NextDouble() * 20 + 10); // every 10-30s
            }
        }

        private void PlayAmbientSound()
        {
            if (_cycle == null) return;
            var sounds = _cycle.IsDay ? _daySounds : _nightSounds;
            var group  = sounds[_rng.Next(sounds.Length)];
            var sound  = group[_rng.Next(group.Length)];
            Console.WriteLine($"[Ambient] Playing '{sound}'");
            // AudioMixer.Play(sound, volume: 0.3f);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  BIOME SKY COLORS
    // ════════════════════════════════════════════════════════════════════════
    public static class BiomeSkyColors
    {
        public static Vector3 GetFogColor(World.BiomeType biome, float timeNormalized) => biome switch
        {
            World.BiomeType.Desert   => Vector3.Lerp(new(0.9f,0.8f,0.6f), new(0.1f,0.1f,0.2f), timeNormalized),
            World.BiomeType.Tundra   => Vector3.Lerp(new(0.8f,0.9f,1.0f), new(0.1f,0.15f,0.3f), timeNormalized),
            World.BiomeType.Swamp    => Vector3.Lerp(new(0.5f,0.6f,0.4f), new(0.05f,0.08f,0.05f), timeNormalized),
            _                        => Vector3.Lerp(new(0.6f,0.75f,0.9f), new(0.01f,0.01f,0.05f), timeNormalized)
        };

        public static Vector3 GetLeafColor(World.BiomeType biome) => biome switch
        {
            World.BiomeType.Desert => new(0.7f, 0.7f, 0.2f),
            World.BiomeType.Tundra => new(0.6f, 0.7f, 0.6f),
            World.BiomeType.Swamp  => new(0.3f, 0.4f, 0.2f),
            _                      => new(0.3f, 0.55f, 0.1f)
        };
    }
}
