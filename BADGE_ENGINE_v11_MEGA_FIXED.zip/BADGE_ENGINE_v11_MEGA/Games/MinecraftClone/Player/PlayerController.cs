using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.ECS;
using Games.MinecraftClone.World;
using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace Games.MinecraftClone.Player
{
    // ════════════════════════════════════════════════════════════════════════
    //  ITEM SYSTEM
    // ════════════════════════════════════════════════════════════════════════
    public enum ItemType
    {
        None,
        // Blocks (these can be placed)
        GrassBlock, DirtBlock, StoneBlock, SandBlock,
        WoodBlock, LeavesBlock, LogBlock, CobblestoneBlock,
        GlassBlock, PlanksBlock, CraftingTable, Furnace,
        TorchBlock, ChestBlock,
        // Tools
        WoodenPickaxe, StonePickaxe, IronPickaxe, GoldenPickaxe, DiamondPickaxe,
        WoodenAxe, StoneAxe, IronAxe, DiamondAxe,
        WoodenShovel, StoneShovel, IronShovel, DiamondShovel,
        WoodenSword, StoneSword, IronSword, DiamondSword,
        // Resources
        Coal, IronIngot, GoldIngot, Diamond, Emerald, Stick,
        WoodPlank, Apple, Bread, Meat
    }

    public class ItemStack
    {
        public static readonly ItemStack Empty = new ItemStack(ItemType.None, 0);

        public ItemType Type     { get; }
        public int      Count    { get; set; }
        public int      MaxStack => IsBlock ? 64 : 1;
        public bool     IsEmpty  => Type == ItemType.None || Count <= 0;
        public bool     IsBlock  => (int)Type < 20;

        // Block mapping: which block does this item place?
        public BlockType PlaceBlock => Type switch
        {
            ItemType.GrassBlock     => BlockType.Grass,
            ItemType.DirtBlock      => BlockType.Dirt,
            ItemType.StoneBlock     => BlockType.Stone,
            ItemType.SandBlock      => BlockType.Sand,
            ItemType.WoodBlock      => BlockType.Wood,
            ItemType.LeavesBlock    => BlockType.Leaves,
            ItemType.LogBlock       => BlockType.Log,
            ItemType.CobblestoneBlock=>BlockType.Cobblestone,
            ItemType.GlassBlock     => BlockType.Glass,
            ItemType.PlanksBlock    => BlockType.Planks,
            ItemType.TorchBlock     => BlockType.Torch,
            _                       => BlockType.Air
        };

        public string Name => Type.ToString();

        public ItemStack(ItemType type, int count = 1) { Type = type; Count = count; }

        public ItemStack WithCount(int count) => new ItemStack(Type, count);
        public ItemStack Decrement() => Count > 1 ? WithCount(Count - 1) : Empty;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  INVENTORY
    // ════════════════════════════════════════════════════════════════════════
    public class Inventory
    {
        public const int HOTBAR_SIZE   = 9;
        public const int MAIN_SIZE     = 27;
        public const int TOTAL_SIZE    = HOTBAR_SIZE + MAIN_SIZE;

        private ItemStack[] _slots;
        private int _hotbarIndex = 0;

        public int HotbarIndex
        {
            get => _hotbarIndex;
            set => _hotbarIndex = Math.Clamp(value, 0, HOTBAR_SIZE - 1);
        }

        public ItemStack HeldItem => _slots[_hotbarIndex];

        public Inventory()
        {
            _slots = new ItemStack[TOTAL_SIZE];
            for (int i = 0; i < TOTAL_SIZE; i++) _slots[i] = ItemStack.Empty;

            // Start with basic items
            _slots[0] = new ItemStack(ItemType.WoodenPickaxe);
            _slots[1] = new ItemStack(ItemType.WoodenAxe);
            _slots[2] = new ItemStack(ItemType.WoodenShovel);
            _slots[3] = new ItemStack(ItemType.WoodenSword);
            _slots[4] = new ItemStack(ItemType.TorchBlock, 64);
            _slots[5] = new ItemStack(ItemType.DirtBlock, 64);
            _slots[6] = new ItemStack(ItemType.StoneBlock, 64);
        }

        public ItemStack GetSlot(int idx) => idx >= 0 && idx < TOTAL_SIZE ? _slots[idx] : ItemStack.Empty;
        public void SetSlot(int idx, ItemStack item) { if (idx>=0&&idx<TOTAL_SIZE) _slots[idx]=item; }
        public IReadOnlyList<ItemStack> GetHotbarSlots() => new ArraySegment<ItemStack>(_slots, 0, HOTBAR_SIZE);

        public bool AddItem(ItemStack item)
        {
            // Try to stack with existing
            for (int i = 0; i < TOTAL_SIZE; i++)
            {
                if (_slots[i].Type == item.Type && _slots[i].Count < _slots[i].MaxStack)
                {
                    int space = _slots[i].MaxStack - _slots[i].Count;
                    int add   = Math.Min(space, item.Count);
                    _slots[i] = _slots[i].WithCount(_slots[i].Count + add);
                    item = item.WithCount(item.Count - add);
                    if (item.IsEmpty) return true;
                }
            }
            // Find empty slot
            for (int i = 0; i < TOTAL_SIZE; i++)
            {
                if (_slots[i].IsEmpty) { _slots[i] = item; return true; }
            }
            return false; // full
        }

        public void RemoveHeld(int count = 1)
        {
            var held = _slots[_hotbarIndex];
            if (held.IsEmpty) return;
            _slots[_hotbarIndex] = held.Count <= count ? ItemStack.Empty : held.Decrement();
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  PLAYER CONTROLLER
    // ════════════════════════════════════════════════════════════════════════
    public class PlayerController : MonoBehaviour
    {
        // ── References ────────────────────────────────────────────────────────
        public WorldManager World  { get; set; } = null!;
        public Inventory    Inventory { get; } = new Inventory();

        // ── Movement settings ─────────────────────────────────────────────────
        public float WalkSpeed      { get; set; } = 4.3f;
        public float SprintSpeed    { get; set; } = 5.6f;
        public float CrouchSpeed    { get; set; } = 1.3f;
        public float JumpVelocity   { get; set; } = 8.5f;
        public float Gravity        { get; set; } = -28f;
        public float BreakDistance  { get; set; } = 5f;

        // ── Player state ──────────────────────────────────────────────────────
        private Vector3 _velocity       = Vector3.Zero;
        private bool    _isGrounded     = false;
        private bool    _isSprinting    = false;
        private bool    _isCrouching    = false;
        private bool    _isFlying       = false;   // creative mode
        private float   _breakProgress  = 0f;
        private Vector3i _targetBlock    = default;
        private bool    _hasTarget      = false;

        // ── Camera ────────────────────────────────────────────────────────────
        private float _pitch = 0f;        // up/down
        private float _yaw   = 0f;        // left/right
        public float MouseSensitivity { get; set; } = 0.1f;
        public float FieldOfView      { get; set; } = 70f;

        // Player dims (matching Minecraft)
        private const float EYE_HEIGHT    = 1.62f;
        private const float PLAYER_WIDTH  = 0.6f;
        private const float PLAYER_HEIGHT = 1.8f;
        private const float CROUCH_HEIGHT = 1.5f;

        public Vector3 EyePosition => Transform.Position + Vector3.UnitY * EYE_HEIGHT;
        public Vector3 LookDirection => new Vector3(
            MathF.Cos(MathHelper.DegreesToRadians(_pitch)) * MathF.Sin(MathHelper.DegreesToRadians(_yaw)),
            MathF.Sin(MathHelper.DegreesToRadians(_pitch)),
            MathF.Cos(MathHelper.DegreesToRadians(_pitch)) * MathF.Cos(MathHelper.DegreesToRadians(_yaw)));

        public override void Start()
        {
            // Spawn at world surface
            int spawnX = 0, spawnZ = 0;
            Transform.Position = new Vector3(spawnX, World.GetBlock(spawnX, 80, spawnZ) != BlockType.Air ? 80 : 65, spawnZ);
            Console.WriteLine("[Player] Spawned at " + Transform.Position);
        }

        public override void Update(float dt)
        {
            HandleMouseLook(dt);
            HandleMovement(dt);
            HandleBlockInteraction(dt);
            HandleHotbarScroll();
        }

        // ── Mouse look ────────────────────────────────────────────────────────
        private void HandleMouseLook(float dt)
        {
            float dx = Input.MouseDeltaX * MouseSensitivity;
            float dy = Input.MouseDeltaY * MouseSensitivity;
            _yaw   = (_yaw   + dx) % 360f;
            _pitch = Math.Clamp(_pitch - dy, -89f, 89f);
        }

        // ── Movement ──────────────────────────────────────────────────────────
        private void HandleMovement(float dt)
        {
            _isSprinting = Input.GetKey(Keys.LeftControl) && !_isCrouching;
            _isCrouching = Input.GetKey(Keys.LeftShift);

            float speed = _isSprinting ? SprintSpeed : _isCrouching ? CrouchSpeed : WalkSpeed;
            if (_isFlying) speed *= 3f;

            // Input direction
            Vector3 move = Vector3.Zero;
            float yawRad = MathHelper.DegreesToRadians(_yaw);
            var forward = new Vector3(MathF.Sin(yawRad), 0, MathF.Cos(yawRad));
            var right   = new Vector3(MathF.Cos(yawRad), 0, -MathF.Sin(yawRad));

            if (Input.GetKey(Keys.W)) move += forward;
            if (Input.GetKey(Keys.S)) move -= forward;
            if (Input.GetKey(Keys.A)) move -= right;
            if (Input.GetKey(Keys.D)) move += right;

            if (move.LengthSquared > 0) move = move.Normalized();

            // Sprint FOV effect
            FieldOfView = _isSprinting && move.LengthSquared > 0
                ? MathHelper.Lerp(FieldOfView, 80f, dt * 10)
                : MathHelper.Lerp(FieldOfView, 70f, dt * 10);

            if (_isFlying)
            {
                if (Input.GetKey(Keys.Space)) move += Vector3.UnitY;
                if (Input.GetKey(Keys.LeftShift)) move -= Vector3.UnitY;
                Transform.Position += move * speed * dt;
                _velocity = Vector3.Zero;
                return;
            }

            // Apply horizontal velocity
            _velocity.X = move.X * speed;
            _velocity.Z = move.Z * speed;

            // Jump
            if (Input.GetKeyDown(Keys.Space) && _isGrounded)
                _velocity.Y = JumpVelocity;

            // Gravity
            if (!_isGrounded)
                _velocity.Y += Gravity * dt;

            // Toggle fly (double-tap space in creative)
            if (Input.GetKeyDown(Keys.F)) _isFlying = !_isFlying;

            MoveAndCollide(dt);
        }

        private void MoveAndCollide(float dt)
        {
            var pos = Transform.Position;
            var delta = _velocity * dt;

            // Axis-separated collision
            pos.X += delta.X; if (CheckCollision(pos)) { pos.X -= delta.X; _velocity.X = 0; }
            pos.Z += delta.Z; if (CheckCollision(pos)) { pos.Z -= delta.Z; _velocity.Z = 0; }
            pos.Y += delta.Y;
            if (CheckCollision(pos))
            {
                pos.Y -= delta.Y;
                _isGrounded = _velocity.Y < 0;
                _velocity.Y = 0;
            }
            else _isGrounded = false;

            // Bedrock floor
            if (pos.Y < 0) { pos.Y = 0; _velocity.Y = 0; _isGrounded = true; }

            Transform.Position = pos;
        }

        private bool CheckCollision(Vector3 pos)
        {
            float h    = _isCrouching ? CROUCH_HEIGHT : PLAYER_HEIGHT;
            float half = PLAYER_WIDTH * 0.5f;

            for (float dy = 0; dy <= h; dy += 0.5f)
            for (float dz = -half; dz <= half; dz += PLAYER_WIDTH)
            for (float dx = -half; dx <= half; dx += PLAYER_WIDTH)
            {
                int bx = (int)MathF.Floor(pos.X + dx);
                int by = (int)MathF.Floor(pos.Y + dy);
                int bz = (int)MathF.Floor(pos.Z + dz);
                if (BlockData.IsSolid(World.GetBlock(bx, by, bz))) return true;
            }
            return false;
        }

        // ── Block interaction ─────────────────────────────────────────────────
        private void HandleBlockInteraction(float dt)
        {
            // Raycast from camera
            _hasTarget = World.RaycastBlock(EyePosition, LookDirection.Normalized(), BreakDistance,
                out _targetBlock, out var placePos);

            if (!_hasTarget) { _breakProgress = 0; return; }

            // Break block (Left click)
            if (Input.GetMouseButton(0))
            {
                var block = World.GetBlock(_targetBlock.X, _targetBlock.Y, _targetBlock.Z);
                float hardness = BlockData.Get(block).Hardness;
                if (hardness < 0) return; // bedrock

                _breakProgress += dt / hardness;
                if (_breakProgress >= 1f)
                {
                    BreakBlock(_targetBlock, block);
                    _breakProgress = 0f;
                }
            }
            else _breakProgress = 0f;

            // Place block (Right click)
            if (Input.GetMouseButtonDown(1))
            {
                var held = Inventory.HeldItem;
                if (!held.IsEmpty && held.IsBlock)
                {
                    var placeBlock = held.PlaceBlock;
                    if (placeBlock != BlockType.Air)
                    {
                        World.SetBlock(placePos.X, placePos.Y, placePos.Z, placeBlock);
                        Inventory.RemoveHeld();
                    }
                }
            }
        }

        private void BreakBlock(Vector3i pos, BlockType block)
        {
            World.SetBlock(pos.X, pos.Y, pos.Z, BlockType.Air);
            // Drop item
            var item = BlockToItem(block);
            if (item != ItemType.None) Inventory.AddItem(new ItemStack(item));
            Console.WriteLine($"[Player] Broke {block} at {pos}");
        }

        private ItemType BlockToItem(BlockType b) => b switch
        {
            BlockType.Grass => ItemType.DirtBlock,
            BlockType.Dirt  => ItemType.DirtBlock,
            BlockType.Stone => ItemType.CobblestoneBlock,
            BlockType.Sand  => ItemType.SandBlock,
            BlockType.Wood  => ItemType.WoodBlock,
            BlockType.Leaves=> _rng.NextDouble()<0.05?ItemType.None:ItemType.None,
            BlockType.Log   => ItemType.LogBlock,
            BlockType.Coal  => ItemType.Coal,
            BlockType.Iron  => ItemType.IronIngot,
            BlockType.Diamond=>ItemType.Diamond,
            _ => ItemType.None
        };
        private Random _rng = new();

        private void HandleHotbarScroll()
        {
            float scroll = Input.MouseScrollDelta;
            if (scroll != 0)
                Inventory.HotbarIndex = (Inventory.HotbarIndex - Math.Sign(scroll) + 9) % 9;

            // Number keys 1-9
            for (int i = 0; i < 9; i++)
                if (Input.GetKeyDown(Keys.D1 + i)) Inventory.HotbarIndex = i;
        }
    }
}
