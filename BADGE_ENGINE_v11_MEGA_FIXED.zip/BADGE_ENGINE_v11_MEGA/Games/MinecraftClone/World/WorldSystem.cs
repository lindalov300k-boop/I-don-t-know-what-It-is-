using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.ECS;
using BADGE.Procedural.Noise;
using OpenTK.Mathematics;

namespace Games.MinecraftClone.World
{
    // ════════════════════════════════════════════════════════════════════════
    //  BLOCK TYPES
    // ════════════════════════════════════════════════════════════════════════
    public enum BlockType : byte
    {
        Air = 0,
        Grass, Dirt, Stone, Sand, Gravel, Bedrock,
        Wood, Leaves, Log,
        Water, Lava,
        Coal, Iron, Gold, Diamond, Emerald, Redstone, Lapis,
        Cobblestone, Planks, Crafting, Furnace, Chest,
        Glass, Wool, Snow, Ice,
        Cactus, SugarCane, Wheat,
        Torch, Ladder, Rail
    }

    public static class BlockData
    {
        public struct BlockProperties
        {
            public string Name;
            public bool   IsSolid;
            public bool   IsTransparent;
            public bool   IsLiquid;
            public bool   IsEmissive;
            public byte   LightLevel;       // 0-15
            public float  Hardness;         // break time multiplier
            public int    TexTop, TexSide, TexBottom; // atlas tile indices
        }

        private static readonly BlockProperties[] _props = new BlockProperties[64];

        static BlockData()
        {
            Define(BlockType.Air,       "Air",        false, true,  false, false, 0,  0f,    0,  0,  0);
            Define(BlockType.Grass,     "Grass",      true,  false, false, false, 0,  0.6f,  0,  3,  2);
            Define(BlockType.Dirt,      "Dirt",       true,  false, false, false, 0,  0.5f,  2,  2,  2);
            Define(BlockType.Stone,     "Stone",      true,  false, false, false, 0,  1.5f,  1,  1,  1);
            Define(BlockType.Sand,      "Sand",       true,  false, false, false, 0,  0.5f, 18, 18, 18);
            Define(BlockType.Gravel,    "Gravel",     true,  false, false, false, 0,  0.6f, 19, 19, 19);
            Define(BlockType.Bedrock,   "Bedrock",    true,  false, false, false, 0, -1f,   17, 17, 17);
            Define(BlockType.Wood,      "Wood",       true,  false, false, false, 0,  2f,   20, 21, 20);
            Define(BlockType.Leaves,    "Leaves",     true,  true,  false, false, 0,  0.2f, 22, 22, 22);
            Define(BlockType.Log,       "Log",        true,  false, false, false, 0,  2f,   20, 20, 20);
            Define(BlockType.Water,     "Water",      false, true,  true,  false, 0,  0f,   14, 14, 14);
            Define(BlockType.Coal,      "Coal Ore",   true,  false, false, false, 0,  3f,   16, 16, 16);
            Define(BlockType.Iron,      "Iron Ore",   true,  false, false, false, 0,  3f,   15, 15, 15);
            Define(BlockType.Gold,      "Gold Ore",   true,  false, false, false, 0,  3f,   32, 32, 32);
            Define(BlockType.Diamond,   "Diamond Ore",true,  false, false, false, 0,  3f,   33, 33, 33);
            Define(BlockType.Glass,     "Glass",      true,  true,  false, false, 0,  0.3f, 49, 49, 49);
            Define(BlockType.Torch,     "Torch",      false, true,  false, true,  14, 0.1f, 80, 80, 80);
            Define(BlockType.Snow,      "Snow",       true,  false, false, false, 0,  0.2f,  2,  3,  2);
            Define(BlockType.Ice,       "Ice",        true,  true,  false, false, 0,  0.5f, 67, 67, 67);
            Define(BlockType.Cobblestone,"Cobblestone",true, false, false, false, 0,  2f,    4,  4,  4);
            Define(BlockType.Planks,    "Planks",     true,  false, false, false, 0,  2f,    4,  4,  4);
            Define(BlockType.Lava,      "Lava",       false, false, true,  true,  15, 0f,   30, 30, 30);
        }

        private static void Define(BlockType t, string name, bool solid, bool trans, bool liq, bool emissive,
            byte light, float hardness, int top, int side, int bottom)
        {
            _props[(int)t] = new BlockProperties
            { Name=name, IsSolid=solid, IsTransparent=trans, IsLiquid=liq,
              IsEmissive=emissive, LightLevel=light, Hardness=hardness,
              TexTop=top, TexSide=side, TexBottom=bottom };
        }

        public static ref BlockProperties Get(BlockType t) => ref _props[(int)t];
        public static bool IsSolid(BlockType t)       => t != BlockType.Air && _props[(int)t].IsSolid;
        public static bool IsTransparent(BlockType t) => !_props[(int)t].IsSolid || _props[(int)t].IsTransparent;
        public static byte GetLight(BlockType t)      => _props[(int)t].LightLevel;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CHUNK
    // ════════════════════════════════════════════════════════════════════════
    public class Chunk
    {
        public const int SIZE_X = 16;
        public const int SIZE_Y = 256;
        public const int SIZE_Z = 16;

        public Vector2i ChunkPos { get; }   // in chunk coords
        public bool IsDirty { get; set; } = true;
        public bool IsGenerated { get; private set; } = false;

        private BlockType[,,] _blocks = new BlockType[SIZE_X, SIZE_Y, SIZE_Z];
        private byte[,,]      _light  = new byte[SIZE_X, SIZE_Y, SIZE_Z];

        // World-space origin of this chunk
        public Vector3 WorldOrigin => new Vector3(ChunkPos.X * SIZE_X, 0, ChunkPos.Y * SIZE_Z);

        public Chunk(Vector2i chunkPos) { ChunkPos = chunkPos; }

        // ── Block access ──────────────────────────────────────────────────────
        public BlockType GetBlock(int x, int y, int z)
        {
            if (x < 0||x>=SIZE_X||y<0||y>=SIZE_Y||z<0||z>=SIZE_Z) return BlockType.Air;
            return _blocks[x, y, z];
        }

        public void SetBlock(int x, int y, int z, BlockType type)
        {
            if (x < 0||x>=SIZE_X||y<0||y>=SIZE_Y||z<0||z>=SIZE_Z) return;
            _blocks[x, y, z] = type;
            IsDirty = true;
        }

        public void Generate(TerrainGenerator gen)
        {
            gen.PopulateChunk(this);
            IsGenerated = true;
            IsDirty = true;
        }

        /// <summary>Returns the highest solid block Y at given local X/Z.</summary>
        public int GetTopBlock(int x, int z)
        {
            for (int y = SIZE_Y - 1; y >= 0; y--)
                if (_blocks[x, y, z] != BlockType.Air) return y;
            return 0;
        }

        // ── Mesh building (greedy meshing) ────────────────────────────────────
        public ChunkMeshData BuildMesh(WorldManager world)
        {
            var data = new ChunkMeshData();

            // 6 face directions: +X -X +Y -Y +Z -Z
            int[] dx = {  1,-1, 0, 0, 0, 0 };
            int[] dy = {  0, 0, 1,-1, 0, 0 };
            int[] dz = {  0, 0, 0, 0, 1,-1 };

            for (int y = 0; y < SIZE_Y; y++)
            for (int z = 0; z < SIZE_Z; z++)
            for (int x = 0; x < SIZE_X; x++)
            {
                var block = _blocks[x, y, z];
                if (block == BlockType.Air) continue;

                for (int face = 0; face < 6; face++)
                {
                    int nx = x + dx[face], ny = y + dy[face], nz = z + dz[face];
                    BlockType neighbor = GetNeighborBlock(nx, ny, nz, world);

                    if (!BlockData.IsTransparent(neighbor)) continue;
                    if (BlockData.IsTransparent(block) && neighbor == block) continue;

                    data.AddFace(x + WorldOrigin.X, y, z + WorldOrigin.Z, face, block);
                }
            }

            IsDirty = false;
            return data;
        }

        private BlockType GetNeighborBlock(int x, int y, int z, WorldManager world)
        {
            if (y < 0) return BlockType.Stone;
            if (y >= SIZE_Y) return BlockType.Air;

            if (x >= 0 && x < SIZE_X && z >= 0 && z < SIZE_Z)
                return _blocks[x, y, z];

            // Cross-chunk neighbor
            int wx = (int)WorldOrigin.X + x;
            int wz = (int)WorldOrigin.Z + z;
            return world.GetBlock(wx, y, wz);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CHUNK MESH DATA
    // ════════════════════════════════════════════════════════════════════════
    public class ChunkMeshData
    {
        public List<Vector3> Vertices  { get; } = new();
        public List<Vector2> UVs       { get; } = new();
        public List<int>     Indices   { get; } = new();
        public List<float>   AO        { get; } = new();

        // UV atlas: 16 textures per row, 1 unit = 1/16 of atlas
        private const float ATLAS = 1f / 16f;

        public void AddFace(float wx, float wy, float wz, int face, BlockType block)
        {
            var props = BlockData.Get(block);
            int texIdx = face == 2 ? props.TexTop : face == 3 ? props.TexBottom : props.TexSide;
            float u0 = (texIdx % 16) * ATLAS,  v0 = (texIdx / 16) * ATLAS;
            float u1 = u0 + ATLAS,              v1 = v0 + ATLAS;

            int i = Vertices.Count;
            (Vector3 a, Vector3 b, Vector3 c, Vector3 d) = FaceVerts(wx, wy, wz, face);

            Vertices.AddRange(new[] { a, b, c, d });
            UVs.AddRange(new[] { new Vector2(u0,v1), new Vector2(u1,v1), new Vector2(u1,v0), new Vector2(u0,v0) });
            Indices.AddRange(new[] { i, i+1, i+2, i, i+2, i+3 });
            AO.AddRange(new float[] { 1f, 1f, 1f, 1f });
        }

        private static (Vector3,Vector3,Vector3,Vector3) FaceVerts(float x, float y, float z, int face) => face switch
        {
            0 => (new(x+1,y  ,z  ), new(x+1,y  ,z+1), new(x+1,y+1,z+1), new(x+1,y+1,z  )), // +X
            1 => (new(x  ,y  ,z+1), new(x  ,y  ,z  ), new(x  ,y+1,z  ), new(x  ,y+1,z+1)), // -X
            2 => (new(x  ,y+1,z  ), new(x  ,y+1,z+1), new(x+1,y+1,z+1), new(x+1,y+1,z  )), // +Y (top)
            3 => (new(x  ,y  ,z+1), new(x  ,y  ,z  ), new(x+1,y  ,z  ), new(x+1,y  ,z+1)), // -Y (bottom)
            4 => (new(x+1,y  ,z+1), new(x  ,y  ,z+1), new(x  ,y+1,z+1), new(x+1,y+1,z+1)), // +Z
            _ => (new(x  ,y  ,z  ), new(x+1,y  ,z  ), new(x+1,y+1,z  ), new(x  ,y+1,z  )), // -Z
        };
    }

    // ════════════════════════════════════════════════════════════════════════
    //  TERRAIN GENERATOR
    // ════════════════════════════════════════════════════════════════════════
    public class TerrainGenerator
    {
        private readonly int _seed;
        private readonly Random _rng;

        // Height ranges
        private const int SEA_LEVEL    = 62;
        private const int STONE_DEPTH  = 4;
        private const int BEDROCK_ROWS = 4;

        public TerrainGenerator(int seed = 0)
        {
            _seed = seed;
            _rng  = new Random(seed);
        }

        public void PopulateChunk(Chunk chunk)
        {
            var cp = chunk.ChunkPos;

            for (int lz = 0; lz < Chunk.SIZE_Z; lz++)
            for (int lx = 0; lx < Chunk.SIZE_X; lx++)
            {
                int wx = cp.X * Chunk.SIZE_X + lx;
                int wz = cp.Y * Chunk.SIZE_Z + lz;

                // Biome sample
                BiomeType biome = GetBiome(wx, wz);
                int surfaceHeight = GetSurfaceHeight(wx, wz, biome);

                for (int y = 0; y < Chunk.SIZE_Y; y++)
                {
                    BlockType block = DetermineBlock(wx, y, wz, surfaceHeight, biome);
                    chunk.SetBlock(lx, y, lz, block);
                }
            }

            // Decorate: trees, ores, caves
            PlaceCaves(chunk);
            PlaceOres(chunk);
            PlaceSurface(chunk);
        }

        private int GetSurfaceHeight(int x, int z, BiomeType biome)
        {
            float scale1 = 0.003f, scale2 = 0.01f, scale3 = 0.05f;
            float h = Perlin.Noise(x * scale1, z * scale1) * 40f
                    + Perlin.Noise(x * scale2, z * scale2) * 12f
                    + Perlin.Noise(x * scale3, z * scale3) * 4f;

            return biome switch
            {
                BiomeType.Mountains => (int)(SEA_LEVEL + h * 2.5f),
                BiomeType.Ocean     => (int)(SEA_LEVEL - 15 + h * 0.3f),
                BiomeType.Desert    => (int)(SEA_LEVEL + 2 + h * 0.7f),
                BiomeType.Plains    => (int)(SEA_LEVEL + 2 + h * 0.8f),
                _                   => (int)(SEA_LEVEL + h)
            };
        }

        private BlockType DetermineBlock(int x, int y, int z, int surface, BiomeType biome)
        {
            if (y == 0)                    return BlockType.Bedrock;
            if (y < BEDROCK_ROWS)
            {
                float f = Perlin.Noise(x * 0.1f, y * 0.1f, z * 0.1f);
                return f > 0 ? BlockType.Bedrock : BlockType.Stone;
            }
            if (y > surface)
            {
                if (y <= SEA_LEVEL)        return BlockType.Water;
                return BlockType.Air;
            }
            if (y == surface)              return SurfaceBlock(biome, y);
            if (y >= surface - STONE_DEPTH)return SubSurfaceBlock(biome);
            return BlockType.Stone;
        }

        private BlockType SurfaceBlock(BiomeType b, int y) => b switch
        {
            BiomeType.Desert  => BlockType.Sand,
            BiomeType.Ocean   => y < SEA_LEVEL ? BlockType.Sand : BlockType.Gravel,
            BiomeType.Tundra  => BlockType.Snow,
            _                 => BlockType.Grass
        };

        private BlockType SubSurfaceBlock(BiomeType b) => b switch
        {
            BiomeType.Desert  => BlockType.Sand,
            _                 => BlockType.Dirt
        };

        private void PlaceCaves(Chunk chunk)
        {
            var cp = chunk.ChunkPos;
            for (int lz = 0; lz < Chunk.SIZE_Z; lz++)
            for (int lx = 0; lx < Chunk.SIZE_X; lx++)
            for (int y  = 4; y  < 60;            y++)
            {
                int wx = cp.X * Chunk.SIZE_X + lx;
                int wz = cp.Y * Chunk.SIZE_Z + lz;
                // 3D Perlin cave carver
                float n = Perlin.Noise(wx*0.04f, y*0.06f, wz*0.04f);
                if (n > 0.7f && chunk.GetBlock(lx, y, lz) == BlockType.Stone)
                    chunk.SetBlock(lx, y, lz, BlockType.Air);
            }
        }

        private void PlaceOres(Chunk chunk)
        {
            PlaceOreVein(chunk, BlockType.Coal,    16,  8, 128, 17);
            PlaceOreVein(chunk, BlockType.Iron,    16,  5,  64,  9);
            PlaceOreVein(chunk, BlockType.Gold,     8,  2,  32,  9);
            PlaceOreVein(chunk, BlockType.Diamond,  8,  1,  15,  8);
            PlaceOreVein(chunk, BlockType.Emerald,  4,  1,  32, 29);
            PlaceOreVein(chunk, BlockType.Lapis,    6,  2,  31, 23);
        }

        private void PlaceOreVein(Chunk chunk, BlockType ore,
            int veins, int minY, int maxY, int veinSize)
        {
            var cp = chunk.ChunkPos;
            long chunkSeed = ((long)cp.X * 341873128712L + (long)cp.Y * 132897987541L) ^ _seed;
            var veinRng = new Random((int)(chunkSeed ^ ((long)ore * 1000003)));

            for (int v = 0; v < veins; v++)
            {
                int x  = veinRng.Next(0, Chunk.SIZE_X);
                int y  = veinRng.Next(minY, maxY);
                int z  = veinRng.Next(0, Chunk.SIZE_Z);

                for (int b = 0; b < veinSize; b++)
                {
                    if (chunk.GetBlock(x, y, z) == BlockType.Stone)
                        chunk.SetBlock(x, y, z, ore);
                    x = Math.Clamp(x + veinRng.Next(-1, 2), 0, Chunk.SIZE_X-1);
                    y = Math.Clamp(y + veinRng.Next(-1, 2), 0, Chunk.SIZE_Y-1);
                    z = Math.Clamp(z + veinRng.Next(-1, 2), 0, Chunk.SIZE_Z-1);
                }
            }
        }

        private void PlaceSurface(Chunk chunk)
        {
            var cp = chunk.ChunkPos;
            var treeRng = new Random(cp.X * 7 + cp.Y * 13 + _seed);

            for (int lz = 2; lz < Chunk.SIZE_Z - 2; lz++)
            for (int lx = 2; lx < Chunk.SIZE_X - 2; lx++)
            {
                int top = chunk.GetTopBlock(lx, lz);
                if (top == 0 || top >= Chunk.SIZE_Y - 6) continue;

                var topBlock = chunk.GetBlock(lx, top, lz);
                if (topBlock == BlockType.Grass && treeRng.NextDouble() < 0.015)
                    PlaceTree(chunk, lx, top + 1, lz, treeRng);
            }
        }

        private void PlaceTree(Chunk chunk, int x, int y, int z, Random rng)
        {
            int height = rng.Next(4, 7);
            for (int i = 0; i < height; i++)
                chunk.SetBlock(x, y + i, z, BlockType.Log);

            int leafStart = y + height - 2;
            for (int ly = leafStart; ly <= y + height + 1; ly++)
            for (int lx = -2; lx <= 2; lx++)
            for (int lz = -2; lz <= 2; lz++)
            {
                if (Math.Abs(lx) + Math.Abs(lz) > 3) continue;
                int bx = x + lx, bz = z + lz;
                if (bx < 0||bx>=Chunk.SIZE_X||bz<0||bz>=Chunk.SIZE_Z) continue;
                if (chunk.GetBlock(bx, ly, bz) == BlockType.Air)
                    chunk.SetBlock(bx, ly, bz, BlockType.Leaves);
            }
        }

        private BiomeType GetBiome(int x, int z)
        {
            float temp     = Perlin.Noise(x * 0.001f,        z * 0.001f);
            float humidity = Perlin.Noise(x * 0.001f + 1000, z * 0.001f + 1000);
            return (temp, humidity) switch
            {
                var (t, h) when t >  0.4f                => BiomeType.Desert,
                var (t, h) when t < -0.3f                => BiomeType.Tundra,
                var (t, h) when t >  0.2f && h <  -0.1f => BiomeType.Plains,
                var (t, h) when h > 0.3f                 => BiomeType.Forest,
                var (t, h) when t >  0.3f && h <  -0.3f => BiomeType.Mountains,
                _                                         => BiomeType.Plains
            };
        }
    }

    public enum BiomeType { Plains, Forest, Desert, Tundra, Mountains, Ocean, Swamp, Jungle }

    // ════════════════════════════════════════════════════════════════════════
    //  WORLD MANAGER
    // ════════════════════════════════════════════════════════════════════════
    public class WorldManager
    {
        public const int RENDER_DISTANCE = 10;   // chunks in each direction

        private Dictionary<Vector2i, Chunk> _chunks = new();
        private TerrainGenerator _gen;
        private Queue<Vector2i>  _loadQueue  = new();
        private Queue<Vector2i>  _unloadQueue = new();

        public WorldManager(int seed = 0) => _gen = new TerrainGenerator(seed);

        public Chunk GetOrCreateChunk(int cx, int cz)
        {
            var key = new Vector2i(cx, cz);
            if (!_chunks.TryGetValue(key, out var chunk))
            {
                chunk = new Chunk(key);
                chunk.Generate(_gen);
                _chunks[key] = chunk;
            }
            return chunk;
        }

        public BlockType GetBlock(int wx, int wy, int wz)
        {
            if (wy < 0 || wy >= Chunk.SIZE_Y) return BlockType.Air;
            int cx = wx >> 4, cz = wz >> 4;  // divide by 16
            int lx = wx & 15, lz = wz & 15;  // mod 16
            var key = new Vector2i(cx, cz);
            return _chunks.TryGetValue(key, out var chunk)
                ? chunk.GetBlock(lx, wy, lz)
                : BlockType.Air;
        }

        public void SetBlock(int wx, int wy, int wz, BlockType type)
        {
            int cx = wx >> 4, cz = wz >> 4;
            int lx = wx & 15, lz = wz & 15;
            var chunk = GetOrCreateChunk(cx, cz);
            chunk.SetBlock(lx, wy, lz, type);

            // Mark adjacent chunks dirty if on border
            if (lx == 0)  GetOrCreateChunk(cx-1, cz).IsDirty = true;
            if (lx == 15) GetOrCreateChunk(cx+1, cz).IsDirty = true;
            if (lz == 0)  GetOrCreateChunk(cx, cz-1).IsDirty = true;
            if (lz == 15) GetOrCreateChunk(cx, cz+1).IsDirty = true;
        }

        /// <summary>Update loaded chunks based on player position.</summary>
        public void UpdateLoadedChunks(Vector3 playerPos)
        {
            int pcx = (int)playerPos.X >> 4;
            int pcz = (int)playerPos.Z >> 4;

            // Load nearby chunks
            for (int dz = -RENDER_DISTANCE; dz <= RENDER_DISTANCE; dz++)
            for (int dx = -RENDER_DISTANCE; dx <= RENDER_DISTANCE; dx++)
            {
                var key = new Vector2i(pcx + dx, pcz + dz);
                if (!_chunks.ContainsKey(key))
                    _loadQueue.Enqueue(key);
            }

            // Process up to 2 chunks per frame to avoid hitches
            for (int i = 0; i < 2 && _loadQueue.Count > 0; i++)
            {
                var key = _loadQueue.Dequeue();
                GetOrCreateChunk(key.X, key.Y);
            }

            // Unload distant chunks
            var toUnload = new List<Vector2i>();
            foreach (var key in _chunks.Keys)
            {
                if (Math.Abs(key.X - pcx) > RENDER_DISTANCE + 2 ||
                    Math.Abs(key.Y - pcz) > RENDER_DISTANCE + 2)
                    toUnload.Add(key);
            }
            foreach (var key in toUnload) _chunks.Remove(key);
        }

        public IEnumerable<Chunk> GetVisibleChunks() => _chunks.Values;

        /// <summary>Raycast into the world for block picking.</summary>
        public bool RaycastBlock(Vector3 origin, Vector3 dir, float maxDist,
            out Vector3i hitBlock, out Vector3i faceBlock)
        {
            hitBlock = default; faceBlock = default;

            float t = 0f;
            while (t < maxDist)
            {
                var pos = origin + dir * t;
                int bx = (int)MathF.Floor(pos.X);
                int by = (int)MathF.Floor(pos.Y);
                int bz = (int)MathF.Floor(pos.Z);

                if (GetBlock(bx, by, bz) != BlockType.Air)
                {
                    hitBlock  = new Vector3i(bx, by, bz);
                    faceBlock = new Vector3i(
                        (int)MathF.Floor((origin + dir * (t - 0.05f)).X),
                        (int)MathF.Floor((origin + dir * (t - 0.05f)).Y),
                        (int)MathF.Floor((origin + dir * (t - 0.05f)).Z));
                    return true;
                }
                t += 0.05f;
            }
            return false;
        }
    }
}
