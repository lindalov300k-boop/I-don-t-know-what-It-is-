using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.ECS;
using Games.MinecraftClone.Player;
using Games.MinecraftClone.World;
using OpenTK.Mathematics;

namespace Games.MinecraftClone.UI
{
    // ════════════════════════════════════════════════════════════════════════
    //  HUD (Heads-Up Display)
    // ════════════════════════════════════════════════════════════════════════
    public class HUD : MonoBehaviour
    {
        private PlayerController _player = null!;

        // Health / Food / XP
        public float Health    { get; set; } = 20f;
        public float MaxHealth { get; set; } = 20f;
        public float Food      { get; set; } = 20f;
        public float MaxFood   { get; set; } = 20f;
        public int   XPLevel   { get; set; } = 0;
        public float XPProgress{ get; set; } = 0f;

        // UI visibility
        public bool ShowInventory { get; private set; } = false;
        public bool ShowCrafting  { get; private set; } = false;
        public bool ShowDebug     { get; private set; } = false;

        public override void Start()
        {
            _player = Entity?.GetComponent<PlayerController>()!;
        }

        public override void Update(float dt)
        {
            if (Input.GetKeyDown(OpenTK.Windowing.GraphicsLibraryFramework.Keys.E))
            {
                ShowInventory = !ShowInventory;
                Input.LockMouse = !ShowInventory;
            }
            if (Input.GetKeyDown(OpenTK.Windowing.GraphicsLibraryFramework.Keys.F3))
                ShowDebug = !ShowDebug;
        }

        public override void OnGUI()
        {
            DrawCrosshair();
            DrawHotbar();
            DrawHealthBar();
            DrawFoodBar();
            DrawXPBar();
            DrawBreathBar();
            if (ShowDebug) DrawDebugOverlay();
        }

        private void DrawCrosshair()
        {
            // Render a white + crosshair at screen centre
            // GUI.DrawLine(screenW/2-8, screenH/2, screenW/2+8, screenH/2, Color.White, 2);
            // GUI.DrawLine(screenW/2, screenH/2-8, screenW/2, screenH/2+8, Color.White, 2);
            Console.Write("+"); // placeholder
        }

        private void DrawHotbar()
        {
            // 9 slots, centred at bottom of screen
            var hotbar = _player.Inventory.GetHotbarSlots();
            for (int i = 0; i < 9; i++)
            {
                // Slot background (dark grey box)
                // Highlight active slot with bright border
                bool active = i == _player.Inventory.HotbarIndex;
                var item = hotbar[i];
                // GUI.DrawSlot(x, y, item, selected: active);
            }
        }

        private void DrawHealthBar()
        {
            // 10 heart icons (full/half/empty) above hotbar
            int full  = (int)(Health / 2f);
            int half  = (int)Health % 2 == 1 ? 1 : 0;
            int empty = 10 - full - half;
            // GUI.DrawHearts(full, half, empty, position);
        }

        private void DrawFoodBar()
        {
            // 10 meat icons to the right of health
        }

        private void DrawXPBar()
        {
            // Green progress bar above hotbar centre
            // GUI.DrawXPBar(XPProgress, XPLevel);
        }

        private void DrawBreathBar()
        {
            // Bubble icons when underwater
        }

        private void DrawDebugOverlay()
        {
            var pos = _player.Transform.Position;
            // GUI.DrawText($"XYZ: {pos.X:F2} / {pos.Y:F2} / {pos.Z:F2}", 4, 4);
            // GUI.DrawText($"Chunk: {(int)pos.X >> 4}, {(int)pos.Z >> 4}", 4, 16);
            // GUI.DrawText($"FPS: {Engine.Instance.GetPerformanceManager().CurrentFPS:F0}", 4, 28);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  INVENTORY SCREEN
    // ════════════════════════════════════════════════════════════════════════
    public class InventoryScreen : MonoBehaviour
    {
        private Inventory _inventory = null!;
        private int?      _dragFrom   = null;
        private bool      _visible    = false;

        public void Show(Inventory inv) { _inventory = inv; _visible = true; }
        public void Hide() { _visible = false; _dragFrom = null; }
        public bool IsVisible => _visible;

        public override void OnGUI()
        {
            if (!_visible) return;

            // ── Inventory grid (9x4 = 36 slots) ──────────────────────────────
            // Draw dark translucent background panel
            // DrawInventoryGrid();
            // DrawCraftingGrid();   // 2x2 crafting
            // DrawArmourSlots();    // head/chest/legs/feet
            // DrawPlayerPreview();  // mini 3D player model

            // ── Hotbar row (bottom of inventory) ─────────────────────────────
            for (int i = 0; i < 9; i++)
            {
                var item = _inventory.GetSlot(i);
                // DrawSlot(baseX + i * SLOT_SIZE, hotbarY, item, i);
            }

            // ── Main inventory grid ───────────────────────────────────────────
            for (int row = 0; row < 3; row++)
            for (int col = 0; col < 9; col++)
            {
                int idx = Inventory.HOTBAR_SIZE + row * 9 + col;
                var item = _inventory.GetSlot(idx);
                // DrawSlot(baseX + col * SLOT_SIZE, mainY + row * SLOT_SIZE, item, idx);
            }

            // ── Drag handling ─────────────────────────────────────────────────
            HandleDrag();
        }

        private void HandleDrag()
        {
            // When player clicks a slot, pick up item
            // When they click another slot, place/swap
            // Support shift-click to auto-stack
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    //  CRAFTING SCREEN
    // ════════════════════════════════════════════════════════════════════════
    public class CraftingScreen : MonoBehaviour
    {
        private ItemStack[,] _grid = new ItemStack[3, 3];
        private ItemStack    _result = ItemStack.Empty;
        private List<CraftingRecipe> _recipes;

        public CraftingScreen()
        {
            for (int y = 0; y < 3; y++)
            for (int x = 0; x < 3; x++)
                _grid[y, x] = ItemStack.Empty;

            _recipes = CraftingRecipeBook.GetAll();
        }

        public void SetIngredient(int x, int y, ItemStack item)
        {
            _grid[y, x] = item;
            _result = MatchRecipe();
        }

        private ItemStack MatchRecipe()
        {
            foreach (var recipe in _recipes)
                if (recipe.Matches(_grid)) return recipe.Result;
            return ItemStack.Empty;
        }

        public ItemStack TakeResult(Inventory inv)
        {
            if (_result.IsEmpty) return ItemStack.Empty;
            var result = _result;
            // Consume ingredients
            for (int y = 0; y < 3; y++)
            for (int x = 0; x < 3; x++)
                if (!_grid[y, x].IsEmpty)
                    _grid[y, x] = _grid[y, x].Decrement();
            _result = MatchRecipe();
            return result;
        }
    }

    public class CraftingRecipe
    {
        public ItemType[,] Grid   { get; set; } = new ItemType[3, 3];
        public ItemStack   Result { get; set; } = ItemStack.Empty;
        public bool Shapeless     { get; set; } = false;

        public bool Matches(ItemStack[,] input)
        {
            for (int y = 0; y < 3; y++)
            for (int x = 0; x < 3; x++)
                if (input[y, x].Type != Grid[y, x]) return false;
            return true;
        }
    }

    public static class CraftingRecipeBook
    {
        private static List<CraftingRecipe> _recipes = new();

        static CraftingRecipeBook()
        {
            // Planks from log
            Add(new ItemType[3, 3] {
                { ItemType.None, ItemType.None, ItemType.None },
                { ItemType.None, ItemType.LogBlock, ItemType.None },
                { ItemType.None, ItemType.None, ItemType.None }
            }, new ItemStack(ItemType.WoodPlank, 4));

            // Sticks
            Add(new ItemType[3, 3] {
                { ItemType.None, ItemType.WoodPlank, ItemType.None },
                { ItemType.None, ItemType.WoodPlank, ItemType.None },
                { ItemType.None, ItemType.None, ItemType.None }
            }, new ItemStack(ItemType.Stick, 4));

            // Wooden pickaxe
            Add(new ItemType[3, 3] {
                { ItemType.WoodPlank, ItemType.WoodPlank, ItemType.WoodPlank },
                { ItemType.None, ItemType.Stick, ItemType.None },
                { ItemType.None, ItemType.Stick, ItemType.None }
            }, new ItemStack(ItemType.WoodenPickaxe));

            // Stone pickaxe
            Add(new ItemType[3, 3] {
                { ItemType.CobblestoneBlock, ItemType.CobblestoneBlock, ItemType.CobblestoneBlock },
                { ItemType.None, ItemType.Stick, ItemType.None },
                { ItemType.None, ItemType.Stick, ItemType.None }
            }, new ItemStack(ItemType.StonePickaxe));

            // Iron pickaxe
            Add(new ItemType[3, 3] {
                { ItemType.IronIngot, ItemType.IronIngot, ItemType.IronIngot },
                { ItemType.None, ItemType.Stick, ItemType.None },
                { ItemType.None, ItemType.Stick, ItemType.None }
            }, new ItemStack(ItemType.IronPickaxe));
        }

        private static void Add(ItemType[,] grid, ItemStack result)
            => _recipes.Add(new CraftingRecipe { Grid = grid, Result = result });

        public static List<CraftingRecipe> GetAll() => _recipes;
    }
}
