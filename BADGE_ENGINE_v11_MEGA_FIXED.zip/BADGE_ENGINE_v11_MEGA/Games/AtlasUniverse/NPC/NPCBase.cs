using BADGE.Core;
using OpenTK.Mathematics;

// ─────────────────────────────────────────────────────────────────────
// Base NPC – procedural low-poly humanoid built from primitives
// ─────────────────────────────────────────────────────────────────────
public class NPCBase : MonoBehaviour

namespace BADGE.Games.AtlasUniverse;

{
    public enum NPCType { Passive, GlowingCorrector, ShadowFigure, LostSoul, Frozen, Glitching }

    public NPCType npcType = NPCType.Passive;
    public Color skinColor = new Color(0.8f, 0.65f, 0.5f);
    public Color clothColor = new Color(0.4f, 0.5f, 0.7f);
    public float moveSpeed = 1.5f;
    public float wanderRadius = 8f;

    protected Vector3 origin;
    protected Vector3 targetPos;
    protected float legSwing;
    protected bool isMoving;

    // Body parts
    protected GameObject body, head;
    protected GameObject[] arms = new GameObject[2];
    protected GameObject[] legs = new GameObject[2];
    protected Light npcLight;

    // Glitch state
    private float glitchTimer;

    void Start()
    {
        origin = Transform.Position;
        targetPos = origin;
        BuildMesh();
        OnStart();
    }

    void Update()
    {
        OnUpdate();
        AnimateLimbs();
    }

    protected virtual void OnStart() { PickNewTarget(); }

    protected virtual void OnUpdate()
    {
        switch (npcType)
        {
            case NPCType.Passive: UpdatePassive(); break;
            case NPCType.GlowingCorrector: UpdateCorrector(); break;
            case NPCType.ShadowFigure: UpdateShadow(); break;
            case NPCType.LostSoul: UpdateLostSoul(); break;
            case NPCType.Frozen: break; // stationary
            case NPCType.Glitching: UpdateGlitching(); break;
        }
    }

    void UpdatePassive()
    {
        MoveToward(targetPos, moveSpeed);
        if (Vector3.Distance(Transform.Position, targetPos) < 0.5f)
        {
            PickNewTarget();
        }
    }

    void UpdateCorrector()
    {
        // Glow and float gently
        float bob = MathF.Sin(BADGE.Core.Time.ElapsedTime * 2f) * 0.15f;
        Transform.Position = new Vector3(Transform.Position.x, origin.y + bob + 0.5f, Transform.Position.z);
        if (npcLight) npcLight.intensity = 1.5f + MathF.Sin(BADGE.Core.Time.ElapsedTime * 3f) * 0.5f;

        // Check player distance
        var player = FindObjectOfType<PlayerController>();
        if (player)
        {
            float dist = Vector3.Distance(Transform.Position, player.Transform.Position);
            if (dist < 6f)
            {
                // Face player, pulse brighter
                Vector3 dir = player.Transform.Position - Transform.Position;
                dir.y = 0;
                if (dir != Vector3.zero) Transform.Rotation = Quaternion.Slerp(Transform.Rotation, Quaternion.LookRotation(dir), BADGE.Core.Time.DeltaTime * 3f);
                if (npcLight) npcLight.intensity = 3f;
                if (dist < 3f) player.AddGlow(0.002f);
            }
        }
    }

    void UpdateShadow()
    {
        MoveToward(targetPos, moveSpeed * 0.6f);
        if (Vector3.Distance(Transform.Position, targetPos) < 0.5f) PickNewTarget();
        // Flicker
        if (npcLight) npcLight.intensity = 0.5f + MathF.Sin(BADGE.Core.Time.ElapsedTime * 8f) * 0.3f;
    }

    void UpdateLostSoul()
    {
        // Drift slowly in a sine pattern
        float t = BADGE.Core.Time.ElapsedTime * 0.4f;
        float xOff = MathF.Sin(t + origin.x) * 3f;
        float zOff = MathF.Cos(t + origin.z) * 3f;
        float yOff = MathF.Sin(t * 2f) * 0.3f;
        Vector3 target = origin + new Vector3(xOff, yOff, zOff);
        Transform.Position = Vector3.Lerp(Transform.Position, target, BADGE.Core.Time.DeltaTime * 0.8f);
        if (npcLight) npcLight.intensity = 0.8f + MathF.Sin(BADGE.Core.Time.ElapsedTime * 1.5f) * 0.4f;
    }

    void UpdateGlitching()
    {
        glitchTimer -= BADGE.Core.Time.DeltaTime;
        if (glitchTimer <= 0f)
        {
            glitchTimer = Random.Range(0.1f, 0.8f);
            // Random teleport offset
            Transform.Position = origin + new Vector3(Random.Range(-0.3f, 0.3f), 0, Random.Range(-0.3f, 0.3f));
            // Random scale tweak
            float s = Random.Range(0.7f, 1.3f);
            Transform.Scale = Vector3.one * s;
            // Random rotation
            Transform.Rotation = Quaternion.Euler(0, Random.Range(0f, 360f), 0);
        }
        MoveToward(targetPos, moveSpeed);
        if (Vector3.Distance(Transform.Position, targetPos) < 0.5f) PickNewTarget();
    }

    protected void MoveToward(Vector3 target, float speed)
    {
        Vector3 dir = (target - Transform.Position);
        dir.y = 0;
        if (dir.magnitude > 0.1f)
        {
            dir.Normalize();
            Transform.Position += dir * speed * BADGE.Core.Time.DeltaTime;
            Transform.Rotation = Quaternion.Slerp(Transform.Rotation, Quaternion.LookRotation(dir), BADGE.Core.Time.DeltaTime * 4f);
            isMoving = true;
        }
        else isMoving = false;
    }

    protected void PickNewTarget()
    {
        targetPos = origin + new Vector3(Random.Range(-wanderRadius, wanderRadius), 0, Random.Range(-wanderRadius, wanderRadius));
    }

    void AnimateLimbs()
    {
        if (npcType == NPCType.Frozen) return;
        if (npcType == NPCType.LostSoul || npcType == NPCType.GlowingCorrector) return;

        float spd = isMoving ? 4f : 0f;
        legSwing += BADGE.Core.Time.DeltaTime * spd;
        float angle = MathF.Sin(legSwing) * 30f;

        if (legs[0]) legs[0].transform.localRotation = Quaternion.Euler(angle, 0, 0);
        if (legs[1]) legs[1].transform.localRotation = Quaternion.Euler(-angle, 0, 0);
        if (arms[0]) arms[0].transform.localRotation = Quaternion.Euler(-angle * 0.8f, 0, 0);
        if (arms[1]) arms[1].transform.localRotation = Quaternion.Euler(angle * 0.8f, 0, 0);
    }

    protected virtual void BuildMesh()
    {
        Color bodyColor = clothColor;
        Color headColor = skinColor;

        if (npcType == NPCType.GlowingCorrector)
        {
            bodyColor = new Color(0.3f, 0.9f, 0.7f);
            headColor = new Color(0.5f, 1f, 0.8f);
        }
        else if (npcType == NPCType.ShadowFigure)
        {
            bodyColor = new Color(0.1f, 0.1f, 0.2f);
            headColor = new Color(0.15f, 0.15f, 0.25f);
        }
        else if (npcType == NPCType.LostSoul)
        {
            bodyColor = new Color(0.7f, 0.9f, 0.5f, 0.7f);
            headColor = new Color(0.8f, 1f, 0.6f);
        }
        else if (npcType == NPCType.Frozen)
        {
            bodyColor = new Color(0.5f, 0.6f, 0.8f);
            headColor = new Color(0.6f, 0.7f, 0.9f);
        }

        body = CreateBlock(transform, new Vector3(0, 0.8f, 0), new Vector3(0.45f, 0.65f, 0.28f), bodyColor);
        head = CreateBlock(transform, new Vector3(0, 1.4f, 0), new Vector3(0.38f, 0.38f, 0.38f), headColor);
        arms[0] = CreateBlock(transform, new Vector3(-0.38f, 0.83f, 0), new Vector3(0.18f, 0.55f, 0.18f), bodyColor);
        arms[1] = CreateBlock(transform, new Vector3(0.38f, 0.83f, 0), new Vector3(0.18f, 0.55f, 0.18f), bodyColor);
        legs[0] = CreateBlock(transform, new Vector3(-0.13f, 0.22f, 0), new Vector3(0.2f, 0.5f, 0.2f), bodyColor * 0.75f);
        legs[1] = CreateBlock(transform, new Vector3(0.13f, 0.22f, 0), new Vector3(0.2f, 0.5f, 0.2f), bodyColor * 0.75f);

        // Emissive glow for special types
        bool needsLight = npcType == NPCType.GlowingCorrector || npcType == NPCType.LostSoul || npcType == NPCType.ShadowFigure;
        if (needsLight)
        {
            GameObject lightObj = new GameObject("NPCLight");
            lightObj.transform.SetParent(transform);
            lightObj.transform.localPosition = Vector3.up * 1.5f;
            npcLight = lightObj.AddComponent<Light>();
            npcLight.type = LightType.Point;
            npcLight.range = 4f;

            if (npcType == NPCType.GlowingCorrector) { npcLight.color = new Color(0.3f, 1f, 0.7f); npcLight.intensity = 1.5f; }
            else if (npcType == NPCType.LostSoul) { npcLight.color = new Color(0.7f, 1f, 0.5f); npcLight.intensity = 0.8f; }
            else if (npcType == NPCType.ShadowFigure) { npcLight.color = new Color(0.3f, 0.2f, 0.5f); npcLight.intensity = 0.5f; }

            // Make body emissive
            if (body)
            {
                Material mat = body.GetComponent<Renderer>().material;
                mat.EnableKeyword("_EMISSION");
                mat.SetColor("_EmissionColor", bodyColor * 1.5f);
            }
        }
    }

    protected GameObject CreateBlock(Transform parent, Vector3 pos, Vector3 size, Color color)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.transform.SetParent(parent);
        go.transform.localPosition = pos;
        go.Transform.Scale = size;
        Material mat = new Material(Shader.Find("Standard"));
        mat.color = color;
        mat.SetFloat("_Glossiness", 0.05f);
        go.GetComponent<Renderer>().material = mat;
        Destroy(go.GetComponent<BoxCollider>());
        return go;
    }
}
