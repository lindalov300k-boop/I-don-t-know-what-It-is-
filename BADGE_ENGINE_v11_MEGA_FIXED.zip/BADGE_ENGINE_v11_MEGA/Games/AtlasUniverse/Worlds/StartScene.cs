using BADGE.Core;
using OpenTK.Mathematics;

namespace BADGE.Games.AtlasUniverse;

public class StartScene : MonoBehaviour
{
    private GUIStyle titleStyle;
    private GUIStyle subtitleStyle;
    private GUIStyle buttonStyle;
    private GUIStyle taglineStyle;

    private float alpha = 0f;
    private float fogDensity = 0f;
    private float time = 0f;

    private Camera cam;
    private GameObject[] fogParticles;
    private int particleCount = 60;

    void Start()
    {
        // Check if existence was terminated
        if (PlayerPrefs.GetInt("Terminated", 0) == 1)
        {
            // Show terminated screen handled in OnGUI
            return;
        }

        SetupCamera();
        SpawnFogParticles();
        BuildEnvironment();

        // Reset timescale
        BADGE.Core.Time.ElapsedTimeScale = 1f;
    }

    void SetupCamera()
    {
        cam = Camera.main;
        if (cam == null)
        {
            cam = new GameObject("MainCamera").AddComponent<Camera>();
            cam.tag = "MainCamera";
        }
        cam.backgroundColor = new Color(0.02f, 0.01f, 0.05f);
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.Transform.Position = new Vector3(0, 2, -5);
        cam.transform.LookAt(Vector3.zero);

        // Ambient dark
        RenderSettings.ambientLight = new Color(0.03f, 0.02f, 0.05f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(0.04f, 0.02f, 0.08f);
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = 0.02f;
    }

    void BuildEnvironment()
    {
        // Procedural dark ground plane
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.Transform.Position = Vector3.zero;
        ground.Transform.Scale = Vector3.one * 10f;
        Material gMat = new Material(Shader.Find("Standard"));
        gMat.color = new Color(0.03f, 0.02f, 0.06f);
        ground.GetComponent<Renderer>().material = gMat;

        // Some glowing orbs in background
        for (int i = 0; i < 8; i++)
        {
            GameObject orb = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            orb.Transform.Position = new Vector3(Random.Range(-15f, 15f), Random.Range(0.5f, 4f), Random.Range(3f, 20f));
            orb.Transform.Scale = Vector3.one * Random.Range(0.05f, 0.15f);
            Material orbMat = new Material(Shader.Find("Standard"));
            Color orbColor = new Color(Random.Range(0.3f, 0.7f), Random.Range(0.2f, 0.5f), Random.Range(0.5f, 1f));
            orbMat.color = orbColor;
            orbMat.EnableKeyword("_EMISSION");
            orbMat.SetColor("_EmissionColor", orbColor * 3f);
            orb.GetComponent<Renderer>().material = orbMat;
            Destroy(orb.GetComponent<Collider>());
            orb.AddComponent<FloatingOrb>();

            Light l = new GameObject("OrbLight").AddComponent<Light>();
            l.transform.SetParent(orb.transform);
            l.type = LightType.Point;
            l.color = orbColor;
            l.range = 3f;
            l.intensity = 0.5f;
        }
    }

    void SpawnFogParticles()
    {
        fogParticles = new GameObject[particleCount];
        for (int i = 0; i < particleCount; i++)
        {
            GameObject p = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            p.Transform.Scale = Vector3.one * Random.Range(0.05f, 0.2f);
            p.Transform.Position = new Vector3(Random.Range(-12f, 12f), Random.Range(0f, 5f), Random.Range(-5f, 15f));
            Material mat = new Material(Shader.Find("Standard"));
            mat.color = new Color(0.4f, 0.3f, 0.6f, 0.3f);
            mat.SetFloat("_Mode", 3);
            mat.SetInt("_SrcBlend", (int)BlendMode.SrcAlpha);
            mat.SetInt("_DstBlend", (int)BlendMode.OneMinusSrcAlpha);
            mat.SetInt("_ZWrite", 0);
            mat.DisableKeyword("_ALPHATEST_ON");
            mat.EnableKeyword("_ALPHABLEND_ON");
            mat.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            mat.renderQueue = 3000;
            mat.EnableKeyword("_EMISSION");
            mat.SetColor("_EmissionColor", new Color(0.2f, 0.1f, 0.4f));
            p.GetComponent<Renderer>().material = mat;
            Destroy(p.GetComponent<Collider>());
            p.AddComponent<FogDrifter>();
            fogParticles[i] = p;
        }
    }

    void Update()
    {
        time += BADGE.Core.Time.DeltaTime;
        alpha = MathF.Min(alpha + BADGE.Core.Time.DeltaTime * 0.8f, 1f);

        // Pulse fog density
        RenderSettings.fogDensity = 0.02f + MathF.Sin(time * 0.5f) * 0.008f;
    }

    void OnGUI()
    {
        if (PlayerPrefs.GetInt("Terminated", 0) == 1)
        {
            DrawTerminatedScreen();
            return;
        }

        // Dark vignette
        GUI.color = new Color(0, 0, 0, 0.5f);
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
        GUI.color = Color.white;

        // Title
        GUIStyle ts = GetTitleStyle();
        ts.normal.textColor = new Color(0.8f, 0.6f, 1f, alpha);
        GUI.Label(new Rect(0, Screen.height * 0.18f, Screen.width, 80), "ATLAS UNIVERSE", ts);

        // Subtitle
        GUIStyle ss = GetSubtitleStyle();
        ss.normal.textColor = new Color(0.6f, 0.5f, 0.9f, alpha * 0.8f);
        GUI.Label(new Rect(0, Screen.height * 0.30f, Screen.width, 40), "A Spiritual Journey Through Eight Realms", ss);

        // Tagline
        GUIStyle tl = GetTaglineStyle();
        tl.normal.textColor = new Color(0.5f, 0.4f, 0.8f, alpha * 0.6f + MathF.Sin(time * 1.5f) * 0.1f);
        GUI.Label(new Rect(0, Screen.height * 0.40f, Screen.width, 30), "Pride · Greed · Lust · Gluttony · Wrath · Envy · Sloth", tl);

        // Button
        if (alpha >= 0.8f)
        {
            GUIStyle bs = GetButtonStyle();
            Rect btnRect = new Rect((Screen.width - 320) / 2, Screen.height * 0.62f, 320, 55);
            GUI.color = new Color(1, 1, 1, alpha);
            if (GUI.Button(btnRect, "Are You Ready To Journey?", bs))
            {
                BeginJourney();
            }
            GUI.color = Color.white;
        }

        // Version
        GUIStyle vs = new GUIStyle(GUI.skin.label);
        vs.fontSize = 11;
        vs.normal.textColor = new Color(0.4f, 0.3f, 0.6f, 0.5f);
        vs.alignment = TextAnchor.LowerRight;
        GUI.Label(new Rect(0, Screen.height - 25, Screen.width - 10, 20), "Atlas Universe v1.0", vs);
    }

    void DrawTerminatedScreen()
    {
        GUI.color = Color.black;
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
        GUI.color = Color.white;

        GUIStyle ts = GetTitleStyle();
        ts.normal.textColor = new Color(0.5f, 0.1f, 0.1f, 1f);
        GUI.Label(new Rect(0, Screen.height * 0.3f, Screen.width, 80), "YOUR EXISTENCE HAS BEEN", ts);
        GUI.Label(new Rect(0, Screen.height * 0.42f, Screen.width, 80), "TERMINATED PERMANENTLY", ts);

        GUIStyle ss = GetSubtitleStyle();
        ss.normal.textColor = new Color(0.4f, 0.1f, 0.1f, 1f);
        GUI.Label(new Rect(0, Screen.height * 0.6f, Screen.width, 30), "You have chosen oblivion.", ss);

        Rect btnRect = new Rect((Screen.width - 250) / 2, Screen.height * 0.72f, 250, 45);
        if (GUI.Button(btnRect, "New Journey"))
        {
            if (GameManager.Instance) GameManager.Instance.ResetGame();
            else
            {
                PlayerPrefs.DeleteAll();
                SceneManager.Instance.LoadScene(0);
            }
        }
    }

    void BeginJourney()
    {
        if (GameManager.Instance)
        {
            int savedWorld = PlayerPrefs.GetInt("CurrentWorld", 1);
            GameManager.Instance.LoadWorld((GameManager.WorldState)savedWorld);
        }
        else
        {
            SceneManager.Instance.LoadScene(1);
        }
    }

    GUIStyle GetTitleStyle()
    {
        if (titleStyle == null)
        {
            titleStyle = new GUIStyle(GUI.skin.label);
            titleStyle.fontSize = 52;
            titleStyle.fontStyle = FontStyle.Bold;
            titleStyle.alignment = TextAnchor.MiddleCenter;
        }
        return titleStyle;
    }

    GUIStyle GetSubtitleStyle()
    {
        if (subtitleStyle == null)
        {
            subtitleStyle = new GUIStyle(GUI.skin.label);
            subtitleStyle.fontSize = 20;
            subtitleStyle.alignment = TextAnchor.MiddleCenter;
        }
        return subtitleStyle;
    }

    GUIStyle GetTaglineStyle()
    {
        if (taglineStyle == null)
        {
            taglineStyle = new GUIStyle(GUI.skin.label);
            taglineStyle.fontSize = 14;
            taglineStyle.alignment = TextAnchor.MiddleCenter;
        }
        return taglineStyle;
    }

    GUIStyle GetButtonStyle()
    {
        if (buttonStyle == null)
        {
            buttonStyle = new GUIStyle(GUI.skin.button);
            buttonStyle.fontSize = 20;
            buttonStyle.fontStyle = FontStyle.Bold;
            buttonStyle.fixedHeight = 55;
            buttonStyle.normal.textColor = new Color(0.9f, 0.8f, 1f);
            buttonStyle.hover.textColor = Color.white;
        }
        return buttonStyle;
    }
}

public class FloatingOrb : MonoBehaviour
{
    private Vector3 origin;
    private float speed;
    private float range;
    void Start() { origin = Transform.Position; speed = Random.Range(0.3f, 0.8f); range = Random.Range(0.2f, 0.8f); }
    void Update() { Transform.Position = origin + Vector3.up * MathF.Sin(BADGE.Core.Time.ElapsedTime * speed) * range; }
}

public class FogDrifter : MonoBehaviour
{
    private Vector3 origin;
    private float speed;
    void Start() { origin = Transform.Position; speed = Random.Range(0.05f, 0.2f); }
    void Update()
    {
        Transform.Position = origin + new Vector3(MathF.Sin(BADGE.Core.Time.ElapsedTime * speed + origin.x) * 1.5f, MathF.Sin(BADGE.Core.Time.ElapsedTime * speed * 0.7f) * 0.3f, 0);
    }
}
