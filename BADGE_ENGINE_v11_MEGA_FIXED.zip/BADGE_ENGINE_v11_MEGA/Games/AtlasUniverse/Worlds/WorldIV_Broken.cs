using BADGE.Core;
using OpenTK.Mathematics;


namespace BADGE.Games.AtlasUniverse;

public class WorldIV_Broken : WorldBase
{
    private float screenShakeTimer = 0f;
    private Camera mainCam;

    protected override void Setup()
    {
        worldName = "World IV – The Broken Realm";
        skyColor = new Color(0.3f, 0.1f, 0.05f);
        fogColor = new Color(0.4f, 0.15f, 0.05f);
        fogDensity = 0.02f;
        sunColor = new Color(1f, 0.4f, 0.2f);
        sunIntensity = 0.6f;
        hasDayNightCycle = false;

        AddWorldIntro();
        BuildBrokenTerrain();
        SpawnFrozenAndGlitching();
    }

    protected override void PostStart()
    {
        mainCam = Camera.main;
    }

    void BuildBrokenTerrain()
    {
        GameObject terrain = new GameObject("BrokenTerrain");
        var gen = terrain.AddComponent<ProceduralChunkTerrain>();
        gen.terrainType = ProceduralChunkTerrain.TerrainType.BrokenVoxel;
        gen.chunkSize = 16;
        gen.viewDistance = 3;
        gen.noiseScale = 0.08f;
        gen.chunkHeight = 8;
        gen.voxelColor = new Color(0.5f, 0.2f, 0.15f);
        gen.floatingBlocks = true;
        gen.floatingBlockCount = 30;
        gen.spawnTrees = false;
        gen.spawnHouses = false;
    }

    void SpawnFrozenAndGlitching()
    {
        GameObject so = new GameObject("BrokenNPCSpawner");
        var sp = so.AddComponent<NPCSpawner>();
        sp.passiveCount = 0;
        sp.correctorCount = 3;
        sp.specialCount = 8;
        sp.specialType = NPCBase.NPCType.Frozen;
        sp.spawnRadius = 25f;

        // Additional glitching NPCs
        GameObject so2 = new GameObject("GlitchNPCSpawner");
        var sp2 = so2.AddComponent<NPCSpawner>();
        sp2.passiveCount = 0;
        sp2.correctorCount = 0;
        sp2.specialCount = 5;
        sp2.specialType = NPCBase.NPCType.Glitching;
        sp2.spawnRadius = 20f;
    }

    protected override float GetPortalTimeRequirement() => 60f;

    protected override void UpdateWorld()
    {
        // Occasional screen shake (wrath effect)
        if (Random.value < 0.001f)
        {
            screenShakeTimer = 0.3f;
        }
        if (screenShakeTimer > 0f)
        {
            screenShakeTimer -= BADGE.Core.Time.DeltaTime;
            if (mainCam)
            {
                mainCam.transform.localPosition = new Vector3(
                    Random.Range(-0.05f, 0.05f),
                    Random.Range(-0.05f, 0.05f),
                    0f);
            }
        }
        else if (mainCam)
        {
            mainCam.transform.localPosition = Vector3.zero;
        }
    }
}
