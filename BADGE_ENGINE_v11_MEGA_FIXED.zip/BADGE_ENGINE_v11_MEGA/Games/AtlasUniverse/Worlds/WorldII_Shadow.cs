using BADGE.Core;
using OpenTK.Mathematics;


namespace BADGE.Games.AtlasUniverse;

public class WorldII_Shadow : WorldBase
{
    private GameObject tower;
    private Light towerLight;
    private float scanAngle = 0f;

    protected override void Setup()
    {
        worldName = "World II – The Shadow Realm";
        skyColor = new Color(0.04f, 0.03f, 0.08f);
        fogColor = new Color(0.05f, 0.04f, 0.1f);
        fogDensity = 0.025f;
        sunColor = new Color(0.3f, 0.2f, 0.5f);
        sunIntensity = 0.2f;
        hasDayNightCycle = false;

        AddWorldIntro();
        BuildDarkTerrain();
        BuildTower();
        SpawnShadowNPCs();
    }

    void BuildDarkTerrain()
    {
        GameObject terrain = new GameObject("ShadowTerrain");
        var gen = terrain.AddComponent<ProceduralChunkTerrain>();
        gen.terrainType = ProceduralChunkTerrain.TerrainType.Voxel;
        gen.chunkSize = 16;
        gen.viewDistance = 3;
        gen.noiseScale = 0.07f;
        gen.chunkHeight = 6;
        gen.voxelColor = new Color(0.1f, 0.08f, 0.18f);
        gen.groundColor = new Color(0.08f, 0.06f, 0.14f);
        gen.spawnTrees = true;
        gen.spawnHouses = false;
        gen.treesPerChunk = 2;
    }

    void BuildTower()
    {
        tower = new GameObject("LightTower");
        tower.Transform.Position = new Vector3(0, 0, 0);

        // Tower base
        for (int i = 0; i < 8; i++)
        {
            GameObject seg = GameObject.CreatePrimitive(PrimitiveType.Cube);
            seg.transform.SetParent(tower.transform);
            float s = MathF.Lerp(1.5f, 0.6f, i / 8f);
            seg.transform.localPosition = new Vector3(0, i * 2.2f + 1f, 0);
            seg.Transform.Scale = new Vector3(s, 2f, s);
            Material mat = new Material(Shader.Find("Standard"));
            mat.color = new Color(0.15f, 0.1f, 0.25f);
            seg.GetComponent<Renderer>().material = mat;
        }

        // Tower top spotlight
        GameObject lightObj = new GameObject("TowerSpot");
        lightObj.transform.SetParent(tower.transform);
        lightObj.transform.localPosition = new Vector3(0, 18f, 0);
        towerLight = lightObj.AddComponent<Light>();
        towerLight.type = LightType.Spot;
        towerLight.color = new Color(0.8f, 0.75f, 0.6f);
        towerLight.range = 40f;
        towerLight.spotAngle = 35f;
        towerLight.intensity = 4f;
        lightObj.Transform.Rotation = Quaternion.Euler(70f, 0f, 0f);

        // Ambient tower glow
        Light ambient = new GameObject("TowerAmbient").AddComponent<Light>();
        ambient.transform.SetParent(tower.transform);
        ambient.transform.localPosition = new Vector3(0, 17f, 0);
        ambient.type = LightType.Point;
        ambient.color = new Color(0.5f, 0.4f, 0.7f);
        ambient.range = 20f;
        ambient.intensity = 1.5f;
    }

    void SpawnShadowNPCs()
    {
        GameObject so = new GameObject("ShadowNPCSpawner");
        var sp = so.AddComponent<NPCSpawner>();
        sp.passiveCount = 3;
        sp.correctorCount = 4;
        sp.specialCount = 8;
        sp.specialType = NPCBase.NPCType.ShadowFigure;
        sp.spawnRadius = 30f;
    }

    protected override float GetPortalTimeRequirement() => 55f;

    protected override void UpdateWorld()
    {
        // Rotate spotlight slowly around tower
        scanAngle += BADGE.Core.Time.DeltaTime * 15f;
        if (towerLight != null)
        {
            towerLight.Transform.Rotation = Quaternion.Euler(60f, scanAngle, 0f);
            towerLight.intensity = 3.5f + MathF.Sin(BADGE.Core.Time.ElapsedTime * 0.5f) * 0.5f;
        }
    }
}
