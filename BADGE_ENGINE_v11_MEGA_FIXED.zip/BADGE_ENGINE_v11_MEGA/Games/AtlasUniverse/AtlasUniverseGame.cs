using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;
using BADGE.Core;
using BADGE.Procedural;

namespace BADGE.Games.AtlasUniverse
{
    // ═══════════════════════════════════════════════════════════════════════════
    //  ATLAS UNIVERSE  —  BADGE Engine v8 conversion
    //
    //  Original: Unity 3rd-person multi-world exploration game.
    //  9 worlds themed around sin concepts. Player grows and gains glow
    //  as they progress. Guardian companion follows player. Portals advance worlds.
    //
    //  BADGE conversion: full Unity API → BADGE API.
    //  Xbox / PS gamepad fully supported (3rd-person camera on right stick).
    // ═══════════════════════════════════════════════════════════════════════════

    // ── World state enum ─────────────────────────────────────────────────────
    public enum WorldState
    {
        StartScene   = 0,
        AlphaWorld   = 1,
        WorldI_Greed = 2,
        WorldII_Shadow = 3,
        WorldIII_Glow  = 4,
        WorldIV_Broken = 5,
        WorldV_Envy    = 6,
        WorldVI_Sloth  = 7,
        CoreWorld      = 8,
    }

    // ── Persistent game state ─────────────────────────────────────────────────
    [Serializable]
    public class AtlasSaveData
    {
        public int   CurrentWorld       = 0;
        public float PlayerGrowthScale  = 1f;
        public float PlayerGlowIntensity = 0f;
        public bool  ExistenceTerminated = false;
        public float TotalPlayTime;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  AtlasGameManager  (singleton, persists across scenes)
    // ═══════════════════════════════════════════════════════════════════════════
    public class AtlasGameManager : MonoBehaviour
    {
        public static AtlasGameManager Instance { get; private set; }

        public WorldState  CurrentWorld        { get; private set; } = WorldState.StartScene;
        public float       PlayerGrowthScale   { get; set; } = 1f;
        public float       PlayerGlowIntensity { get; set; } = 0f;
        public bool        ExistenceTerminated { get; private set; }

        private AtlasSaveData _save;
        private float         _playTime;

        public override void Awake()
        {
            if (Instance == null)
            {
                Instance = this;
                SceneManager.Instance?.DontDestroyOnLoad(this);
            }
            else { Destroy(this); return; }

            _save = LoadSave();
            CurrentWorld         = (WorldState)_save.CurrentWorld;
            PlayerGrowthScale    = _save.PlayerGrowthScale;
            PlayerGlowIntensity  = _save.PlayerGlowIntensity;
            ExistenceTerminated  = _save.ExistenceTerminated;
        }

        public override void Update() => _playTime += Time.DeltaTime;

        public void LoadWorld(WorldState world)
        {
            CurrentWorld = world;
            SaveGame();
            SceneManager.Instance.LoadScene(world.ToString());
        }

        public void NextWorld()
        {
            int next = (int)CurrentWorld + 1;
            if (next <= 8) LoadWorld((WorldState)next);
        }

        public void TerminateExistence()
        {
            ExistenceTerminated = true;
            SaveGame();
        }

        // ── Save/Load via BADGE AES-encrypted SaveSystem ─────────────────────
        public void SaveGame()
        {
            _save.CurrentWorld        = (int)CurrentWorld;
            _save.PlayerGrowthScale   = PlayerGrowthScale;
            _save.PlayerGlowIntensity = PlayerGlowIntensity;
            _save.ExistenceTerminated = ExistenceTerminated;
            _save.TotalPlayTime      += _playTime;
            _playTime = 0;
            SaveSystem.AutoEncrypt = true;
            try { SaveSystem.WriteData(slotIndex: 20, _save); }
            catch (Exception ex) { Console.Error.WriteLine($"[Atlas] Save error: {ex.Message}"); }
        }

        private AtlasSaveData LoadSave()
        {
            SaveSystem.AutoEncrypt = true;
            try { return SaveSystem.ReadData<AtlasSaveData>(slotIndex: 20) ?? new AtlasSaveData(); }
            catch { return new AtlasSaveData(); }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  AtlasPlayer  —  3rd-person character controller
    // ═══════════════════════════════════════════════════════════════════════════
    public class AtlasPlayer : MonoBehaviour
    {
        // Settings
        public float WalkSpeed     = 4f;
        public float RunSpeed      = 8f;
        public float JumpHeight    = 1.5f;
        public float Gravity       = -20f;
        public float MouseSensitivity = 2f;
        public float CameraDistance = 5f;
        public float CameraHeight   = 2f;

        // State
        public  float GlowIntensity { get; private set; }
        private bool  _isGrounded;
        private float _velY;
        private float _yaw, _pitch = 20f;
        private Vector3 _camVel;
        private bool _isMoving;
        private float _legSwing, _armSwing;

        // Body parts transform indices (managed by mesh system)
        private readonly float[] _bodyPartAngles = new float[6]; // l-leg, r-leg, l-arm, r-arm, body-bob

        // Gamepad
        private GamepadState _pad;
        private Vector2 _mouseInput;

        public override void Start()
        {
            if (AtlasGameManager.Instance != null)
            {
                GlowIntensity = AtlasGameManager.Instance.PlayerGlowIntensity;
                float scale   = AtlasGameManager.Instance.PlayerGrowthScale;
                Transform.Scale = new Vector3(scale);
            }
            Input.LockCursor(true);
        }

        public override void Update()
        {
            _pad = GamepadInput.Get(0);
            HandleMouseLook();
            HandleMovement();
            AnimateLimbs();
            UpdateGlow();

            // Pause
            if (Input.GetKeyDown(Keys.Escape) || (_pad.IsConnected && _pad.GetButtonDown(GamepadButton.Start)))
                AtlasUI.Instance?.TogglePause();
        }

        public override void LateUpdate()
        {
            FollowCamera();
        }

        // ── Mouse / right-stick look ──────────────────────────────────────────
        private void HandleMouseLook()
        {
            float mx = Input.MouseDelta.X * MouseSensitivity;
            float my = Input.MouseDelta.Y * MouseSensitivity;

            if (_pad.IsConnected)
            {
                Vector2 rs = _pad.RightStick;
                mx += rs.X * MouseSensitivity * 60f * Time.DeltaTime;
                my -= rs.Y * MouseSensitivity * 60f * Time.DeltaTime;
            }

            _yaw   += mx;
            _pitch -= my;
            _pitch  = MathHelper.Clamp(_pitch, -10f, 60f);
            Transform.SetEulerY(_yaw);
        }

        // ── Movement (keyboard + left stick) ─────────────────────────────────
        private void HandleMovement()
        {
            _isGrounded = Transform.Position.Y <= 0.02f; // simple ground check
            if (_isGrounded && _velY < 0f) _velY = -2f;

            float h = 0f, v = 0f;
            if (Input.GetKey(Keys.A)) h = -1f;
            if (Input.GetKey(Keys.D)) h =  1f;
            if (Input.GetKey(Keys.W)) v =  1f;
            if (Input.GetKey(Keys.S)) v = -1f;

            if (_pad.IsConnected)
            {
                Vector2 ls = _pad.LeftStick;
                if (MathF.Abs(ls.X) > 0.15f) h = ls.X;
                if (MathF.Abs(ls.Y) > 0.15f) v = ls.Y;
            }

            bool running = Input.GetKey(Keys.LeftShift) ||
                           (_pad.IsConnected && _pad.GetButton(GamepadButton.LeftBumper));
            float speed  = running ? RunSpeed : WalkSpeed;

            Vector3 right   = new Vector3(MathF.Sin(_yaw * MathF.PI / 180f + MathF.PI / 2f), 0,
                                           MathF.Cos(_yaw * MathF.PI / 180f + MathF.PI / 2f));
            Vector3 forward = new Vector3(MathF.Sin(_yaw * MathF.PI / 180f), 0,
                                           MathF.Cos(_yaw * MathF.PI / 180f));

            Vector3 move = right * h + forward * v;
            _isMoving    = move.LengthSquared > 0.01f;
            if (move.LengthSquared > 1f) move = Vector3.Normalize(move);
            Transform.Position += move * speed * Time.DeltaTime;

            // Jump
            bool jumpPressed = Input.GetKeyDown(Keys.Space) ||
                               (_pad.IsConnected && _pad.GetButtonDown(GamepadButton.A));
            if (jumpPressed && _isGrounded)
                _velY = MathF.Sqrt(JumpHeight * -2f * Gravity);

            _velY += Gravity * Time.DeltaTime;
            var p = Transform.Position;
            p.Y = MathF.Max(0f, p.Y + _velY * Time.DeltaTime);
            Transform.Position = p;
        }

        // ── Limb animation ────────────────────────────────────────────────────
        private void AnimateLimbs()
        {
            float swingSpeed = _isMoving ? 4f : 0f;
            _legSwing += Time.DeltaTime * swingSpeed;
            _armSwing += Time.DeltaTime * swingSpeed;

            float legAngle = MathF.Sin(_legSwing) * 30f;
            float armAngle = MathF.Sin(_armSwing) * 25f;

            _bodyPartAngles[0] =  legAngle; // L leg
            _bodyPartAngles[1] = -legAngle; // R leg
            _bodyPartAngles[2] = -armAngle; // L arm
            _bodyPartAngles[3] =  armAngle; // R arm

            if (!_isMoving)
            {
                float bob = MathF.Sin(Time.ElapsedTime * 1.5f) * 0.03f;
                _bodyPartAngles[4] = bob; // body Y offset
            }
        }

        private void UpdateGlow()
        {
            GlowIntensity = AtlasGameManager.Instance?.PlayerGlowIntensity ?? 0f;
        }

        // ── Third-person camera follow ────────────────────────────────────────
        private void FollowCamera()
        {
            float pitchRad = _pitch * MathF.PI / 180f;
            float yawRad   = _yaw   * MathF.PI / 180f;

            Vector3 offset = new Vector3(
                -MathF.Sin(yawRad)   * CameraDistance * MathF.Cos(pitchRad),
                 CameraDistance      * MathF.Sin(pitchRad) + CameraHeight,
                -MathF.Cos(yawRad)   * CameraDistance * MathF.Cos(pitchRad)
            );

            Vector3 targetPos = Transform.Position + offset;
            var cam = Camera.Main;
            if (cam == null) return;

            cam.Transform.Position = Vector3.Lerp(cam.Transform.Position, targetPos,
                                                   0.15f * 60f * Time.DeltaTime);
            cam.Transform.LookAt(Transform.Position + new Vector3(0, 1f, 0));
        }

        public void AddGlow(float amount)
        {
            GlowIntensity = MathHelper.Clamp(GlowIntensity + amount, 0f, 3f);
            if (AtlasGameManager.Instance != null)
                AtlasGameManager.Instance.PlayerGlowIntensity = GlowIntensity;
        }

        public void Grow(float amount)
        {
            float s = MathHelper.Clamp(Transform.Scale.X + amount, 0.8f, 1.5f);
            Transform.Scale = new Vector3(s);
            if (AtlasGameManager.Instance != null)
                AtlasGameManager.Instance.PlayerGrowthScale = s;
        }

        public float[] BodyPartAngles => _bodyPartAngles;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  GuardianCompanion  —  follows player, bobbing companion orb
    // ═══════════════════════════════════════════════════════════════════════════
    public class GuardianCompanion : MonoBehaviour
    {
        public BADGE.Core.Transform PlayerTransform;
        private float _glowIntensity = 1f;
        private float _bobTimer;
        private float _idleOrbitAngle;

        public override void Update()
        {
            if (PlayerTransform == null) return;

            // Bob and orbit around player
            _bobTimer        += Time.DeltaTime * 1.8f;
            _idleOrbitAngle  += Time.DeltaTime * 0.8f;

            float bobY  = MathF.Sin(_bobTimer) * 0.25f;
            float orbitR = 1.5f;

            Vector3 target = PlayerTransform.Position + new Vector3(
                MathF.Cos(_idleOrbitAngle) * orbitR,
                1.2f + bobY,
                MathF.Sin(_idleOrbitAngle) * orbitR
            );

            Transform.Position = Vector3.Lerp(Transform.Position, target, 3f * Time.DeltaTime);
        }

        public void SetGlow(float intensity) => _glowIntensity = intensity;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  Portal  —  interworld gateway
    // ═══════════════════════════════════════════════════════════════════════════
    public class AtlasPortal : MonoBehaviour
    {
        public float TimeRequired = 45f;
        public bool  IsActive     { get; private set; }

        private float _worldTime;
        private bool  _triggered;
        private float _spinAngle;
        private float _pulseTimer;

        public override void Update()
        {
            if (!_triggered)
            {
                _worldTime += Time.DeltaTime;
                if (_worldTime >= TimeRequired) Activate();
            }

            if (IsActive)
            {
                // Spin and pulse animation
                _spinAngle  += 90f * Time.DeltaTime;
                _pulseTimer += Time.DeltaTime * 2f;
                Transform.SetEulerY(_spinAngle);

                // Check player entry
                var player = FindObjectOfType<AtlasPlayer>();
                if (player != null &&
                    (Transform.Position - player.Transform.Position).Length < 1.5f)
                {
                    AtlasGameManager.Instance?.NextWorld();
                }
            }
        }

        private void Activate()
        {
            IsActive  = true;
            _triggered = true;
            AtlasAudio.PlayPortalActivate(Transform.Position);
            Console.WriteLine("[Atlas] Portal activated!");
        }

        public float GlowPulse => IsActive ? (MathF.Sin(_pulseTimer) + 1f) * 0.5f : 0f;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  NPC
    // ═══════════════════════════════════════════════════════════════════════════
    public class AtlasNPC : MonoBehaviour
    {
        public string NPCName    = "Entity";
        public string Dialogue   = "...";
        public float  GlowRadius = 2f;

        private float _idleTimer;
        private Vector3 _idleTarget;
        private bool  _talkingToPlayer;
        private readonly Random _rng = new();

        public override void Start()
        {
            _idleTarget = Transform.Position;
        }

        public override void Update()
        {
            if (_talkingToPlayer) return;

            _idleTimer -= Time.DeltaTime;
            if (_idleTimer <= 0f)
            {
                float angle = (float)(_rng.NextDouble() * Math.PI * 2);
                _idleTarget = Transform.Position + new Vector3(
                    MathF.Cos(angle) * 2f, 0, MathF.Sin(angle) * 2f);
                _idleTimer = 3f + (float)_rng.NextDouble() * 3f;
            }

            Vector3 dir = _idleTarget - Transform.Position;
            if (dir.LengthSquared > 0.1f)
                Transform.Position += Vector3.Normalize(dir) * 1.2f * Time.DeltaTime;

            // Check player proximity for interaction
            var player = FindObjectOfType<AtlasPlayer>();
            if (player != null && (Transform.Position - player.Transform.Position).Length < 2f)
            {
                bool interact = Input.GetKeyDown(Keys.E) ||
                                (GamepadInput.Get(0).IsConnected && GamepadInput.Get(0).GetButtonDown(GamepadButton.X));
                if (interact) StartDialogue(player);
            }
        }

        private void StartDialogue(AtlasPlayer player)
        {
            _talkingToPlayer = true;
            AtlasUI.Instance?.ShowDialogue(NPCName, Dialogue, () =>
            {
                _talkingToPlayer = false;
                // NPCs in glow-themed worlds grant glow on talk
                if (AtlasGameManager.Instance?.CurrentWorld == WorldState.WorldIII_Glow)
                    player.AddGlow(0.3f);
            });
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  WorldBase  —  abstract, each world inherits
    // ═══════════════════════════════════════════════════════════════════════════
    public abstract class AtlasWorldBase : MonoBehaviour
    {
        public string WorldName    = "World";
        public Vector3 SkyColor   = new(0.4f, 0.6f, 0.9f);
        public Vector3 FogColor   = new(0.5f, 0.6f, 0.8f);
        public float   FogDensity = 0.01f;
        public bool    DayNight   = true;
        public float   SunIntensity = 1f;

        protected AtlasPlayer     _player;
        protected GuardianCompanion _guardian;
        protected AtlasPortal     _portal;
        private   float           _dayTime;
        private   float           _daySpeed = 0.02f;

        public override void Awake()
        {
            SetupEnvironment();
            Setup();
        }

        public override void Start()
        {
            SpawnPlayer();
            SpawnGuardian();
            SpawnPortal();
            SpawnNPCs();
            PostStart();
        }

        public override void Update()
        {
            if (DayNight) UpdateDayNight();
            WorldUpdate();
        }

        protected virtual void Setup()     { }
        protected virtual void PostStart() { }
        protected virtual void WorldUpdate() { }
        protected virtual void SpawnNPCs()   { }
        protected virtual float PortalTimeRequired() => 45f;

        private void SetupEnvironment()
        {
            RenderSettings.AmbientLight  = SkyColor * 0.3f;
            RenderSettings.FogEnabled    = true;
            RenderSettings.FogColor      = FogColor;
            RenderSettings.FogDensity    = FogDensity;
            AtlasAudio.PlayWorldAmbient(WorldName);
        }

        private void SpawnPlayer()
        {
            var go = new BADGE.Core.GameObject("Player");
            go.Transform.Position = new Vector3(0, 1f, 0);
            _player = go.AddComponent<AtlasPlayer>();
        }

        private void SpawnGuardian()
        {
            var go = new BADGE.Core.GameObject("Guardian");
            go.Transform.Position = new Vector3(0, 1.5f, -2f);
            _guardian = go.AddComponent<GuardianCompanion>();
            _guardian.PlayerTransform = _player.Transform;
            if (AtlasGameManager.Instance != null)
                _guardian.SetGlow(AtlasGameManager.Instance.PlayerGlowIntensity * 0.5f + 1f);
        }

        private void SpawnPortal()
        {
            var go = new BADGE.Core.GameObject("Portal");
            go.Transform.Position = new Vector3(20f, 1f, 20f);
            _portal = go.AddComponent<AtlasPortal>();
            _portal.TimeRequired = PortalTimeRequired();
        }

        private void UpdateDayNight()
        {
            _dayTime += Time.DeltaTime * _daySpeed;
            float t = MathF.Sin(_dayTime * MathF.PI);
            RenderSettings.SunAngle   = _dayTime * 360f;
            RenderSettings.SunIntensity = MathHelper.Lerp(0.1f, SunIntensity, t);

            // Lerp sky from night to day
            RenderSettings.AmbientLight = Vector3.Lerp(
                SkyColor * 0.05f, SkyColor * 0.3f, t);
        }
    }

    // ── World implementations ─────────────────────────────────────────────────

    public class StartScene : AtlasWorldBase
    {
        public StartScene() { WorldName="Start"; SkyColor=new(0.2f,0.2f,0.35f); DayNight=false; }
        protected override void Setup() => AtlasUI.Instance?.ShowTitle("ATLAS UNIVERSE", "Press A / Space to begin");
        protected override void SpawnNPCs()
        {
            var go = new BADGE.Core.GameObject("Guide_NPC");
            var npc = go.AddComponent<AtlasNPC>();
            npc.NPCName = "The Guide";
            npc.Dialogue = "Welcome, traveller. Six worlds await. Find the portals.";
            go.Transform.Position = new Vector3(3f, 0f, 3f);
        }
        protected override float PortalTimeRequired() => 10f;
    }

    public class AlphaWorld : AtlasWorldBase
    {
        public AlphaWorld() { WorldName="Alpha"; SkyColor=new(0.5f,0.7f,0.9f); }
        protected override void Setup() => BuildOpenTerrain(grassColor: new(0.2f,0.5f,0.15f));
        protected override void SpawnNPCs() { SpawnNPC("Alpha Entity", "This place is the beginning.", new Vector3(10,0,10)); }
        private void BuildOpenTerrain(Vector3 grassColor) { /* flat terrain placeholder */ }
        private void SpawnNPC(string name, string dialogue, Vector3 pos)
        {
            var go = new BADGE.Core.GameObject($"NPC_{name}");
            var npc = go.AddComponent<AtlasNPC>();
            npc.NPCName = name; npc.Dialogue = dialogue;
            go.Transform.Position = pos;
        }
    }

    public class WorldI_Greed : AtlasWorldBase
    {
        public WorldI_Greed() { WorldName="World I: Greed"; SkyColor=new(0.8f,0.6f,0.1f); FogDensity=0.02f; }
        protected override void Setup() => SpawnCoins(50);
        protected override void SpawnNPCs() { SpawnNPC("Midas", "Take all you can. It will never be enough.", new Vector3(15,0,5)); }
        private void SpawnCoins(int count)
        {
            var rng = new Random(1);
            for (int i = 0; i < count; i++)
            {
                var go = new BADGE.Core.GameObject("Coin");
                go.Transform.Position = new Vector3((float)rng.NextDouble() * 40f - 20f, 0.5f,
                                                     (float)rng.NextDouble() * 40f - 20f);
                go.AddComponent<CoinPickup>();
            }
        }
        private void SpawnNPC(string n, string d, Vector3 p)
        {
            var go = new BADGE.Core.GameObject($"NPC_{n}");
            var npc = go.AddComponent<AtlasNPC>(); npc.NPCName=n; npc.Dialogue=d;
            go.Transform.Position = p;
        }
    }

    public class WorldII_Shadow : AtlasWorldBase
    {
        public WorldII_Shadow() { WorldName="World II: Shadow"; SkyColor=new(0.05f,0.05f,0.1f); FogDensity=0.05f; }
        protected override void Setup() => SpawnShadowCreatures(8);
        private void SpawnShadowCreatures(int n)
        {
            var rng = new Random(2);
            for (int i = 0; i < n; i++)
            {
                var go  = new BADGE.Core.GameObject("Shadow");
                var sc  = go.AddComponent<ShadowCreature>();
                go.Transform.Position = new Vector3((float)rng.NextDouble()*30f-15f, 0.5f, (float)rng.NextDouble()*30f-15f);
            }
        }
    }

    public class WorldIII_Glow : AtlasWorldBase
    {
        public WorldIII_Glow() { WorldName="World III: Glow"; SkyColor=new(0.1f,0.3f,0.5f); DayNight=false; }
        protected override void Setup() => SpawnGlowNodes(12);
        private void SpawnGlowNodes(int n)
        {
            var rng = new Random(3);
            for (int i = 0; i < n; i++)
            {
                var go = new BADGE.Core.GameObject("GlowNode");
                go.AddComponent<GlowPickup>();
                go.Transform.Position = new Vector3((float)rng.NextDouble()*40f-20f, 0.5f, (float)rng.NextDouble()*40f-20f);
            }
        }
    }

    public class WorldIV_Broken : AtlasWorldBase
    {
        public WorldIV_Broken() { WorldName="World IV: Broken"; SkyColor=new(0.4f,0.2f,0.1f); }
        protected override void Setup()
        {
            // Broken terrain — floating islands
            var rng = new Random(4);
            for (int i = 0; i < 20; i++)
            {
                var go = new BADGE.Core.GameObject("FloatingPlatform");
                go.Transform.Position = new Vector3((float)rng.NextDouble()*40f-20f,
                                                     1f + (float)rng.NextDouble()*4f,
                                                     (float)rng.NextDouble()*40f-20f);
                go.Transform.Scale = new Vector3(2f+(float)rng.NextDouble()*3f, 0.4f, 2f+(float)rng.NextDouble()*3f);
            }
        }
    }

    public class WorldV_Envy  : AtlasWorldBase
    {
        public WorldV_Envy()  { WorldName="World V: Envy";  SkyColor=new(0.1f,0.4f,0.15f); }
    }
    public class WorldVI_Sloth : AtlasWorldBase
    {
        public WorldVI_Sloth(){ WorldName="World VI: Sloth"; SkyColor=new(0.3f,0.3f,0.4f); FogDensity=0.03f; }
    }
    public class CoreWorld : AtlasWorldBase
    {
        public CoreWorld()    { WorldName="Core World"; SkyColor=new(0.8f,0.8f,1f); DayNight=false; }
        protected override void Setup()
        {
            // Final world — show ending
            AtlasUI.Instance?.ShowEnding(AtlasGameManager.Instance?.ExistenceTerminated ?? false);
        }
    }

    // ── Pickups / helpers ──────────────────────────────────────────────────────
    public class CoinPickup : MonoBehaviour
    {
        private float _bobTimer;
        public override void Update()
        {
            _bobTimer += Time.DeltaTime * 2f;
            Transform.Position = new Vector3(Transform.Position.X,
                                              0.5f + MathF.Sin(_bobTimer) * 0.1f,
                                              Transform.Position.Z);
            Transform.SetEulerY(Transform.EulerAngles.Y + 90f * Time.DeltaTime);

            var player = FindObjectOfType<AtlasPlayer>();
            if (player != null && (Transform.Position - player.Transform.Position).Length < 0.8f)
            {
                player.Grow(0.02f);
                Destroy(this);
            }
        }
    }

    public class GlowPickup : MonoBehaviour
    {
        private float _bobTimer;
        public override void Update()
        {
            _bobTimer += Time.DeltaTime * 3f;
            Transform.Position = new Vector3(Transform.Position.X,
                                              0.5f + MathF.Sin(_bobTimer) * 0.15f,
                                              Transform.Position.Z);

            var player = FindObjectOfType<AtlasPlayer>();
            if (player != null && (Transform.Position - player.Transform.Position).Length < 1f)
            {
                player.AddGlow(0.4f);
                AtlasAudio.PlayGlowPickup(Transform.Position);
                Destroy(this);
            }
        }
    }

    public class ShadowCreature : MonoBehaviour
    {
        private float _health = 30f;
        private readonly Random _rng = new();
        private float _wanderTimer;
        private Vector3 _dir = new(1,0,0);

        public override void Update()
        {
            _wanderTimer -= Time.DeltaTime;
            if (_wanderTimer <= 0f)
            {
                float a = (float)(_rng.NextDouble() * Math.PI * 2);
                _dir = new Vector3(MathF.Cos(a), 0, MathF.Sin(a));
                _wanderTimer = 1f + (float)_rng.NextDouble() * 2f;
            }
            Transform.Position += _dir * 2f * Time.DeltaTime;

            var player = FindObjectOfType<AtlasPlayer>();
            if (player != null && (Transform.Position - player.Transform.Position).Length < 0.8f)
            {
                player.AddGlow(-0.1f); // shadow drains glow
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  UI
    // ═══════════════════════════════════════════════════════════════════════════
    public class AtlasUI : MonoBehaviour
    {
        public static AtlasUI Instance { get; private set; }
        private bool _paused;
        private bool _showDialogue;
        private string _dlgTitle, _dlgText;
        private Action _dlgCallback;

        public override void Awake()
        {
            if (Instance == null) Instance = this;
        }

        public void TogglePause()   => _paused = !_paused;
        public void ShowTitle(string title, string sub) => Console.WriteLine($"[Atlas] {title} — {sub}");

        public void ShowDialogue(string npcName, string text, Action callback)
        {
            _showDialogue = true;
            _dlgTitle     = npcName;
            _dlgText      = text;
            _dlgCallback  = callback;
        }

        public void ShowEnding(bool terminated) =>
            Console.WriteLine(terminated ? "[Atlas] EXISTENCE TERMINATED." : "[Atlas] You reached the Core.");

        public override void OnGUI()
        {
            var gm  = AtlasGameManager.Instance;
            if (gm == null) return;

            ImGuiHUD.BeginOverlay("AtlasHUD");
            ImGuiHUD.Text($"World: {gm.CurrentWorld}");
            ImGuiHUD.Text($"Glow: {gm.PlayerGlowIntensity:F1}");
            ImGuiHUD.Text("[E / X] Interact", dimmed: true);
            ImGuiHUD.EndOverlay();

            if (_paused) DrawPause();
            if (_showDialogue) DrawDialogue();
        }

        private void DrawPause()
        {
            ImGuiHUD.BeginModal("PAUSED");
            if (ImGuiHUD.Button("Resume"))  _paused = false;
            if (ImGuiHUD.Button("Save"))    AtlasGameManager.Instance?.SaveGame();
            if (ImGuiHUD.Button("Quit"))    Engine.Instance.Shutdown();
            ImGuiHUD.EndModal();
        }

        private void DrawDialogue()
        {
            ImGuiHUD.BeginModal(_dlgTitle);
            ImGuiHUD.Text(_dlgText);
            if (ImGuiHUD.Button("Continue"))
            {
                _showDialogue = false;
                _dlgCallback?.Invoke();
            }
            ImGuiHUD.EndModal();
        }
    }

    // ── Atlas Audio ───────────────────────────────────────────────────────────
    public static class AtlasAudio
    {
        public static void PlayPortalActivate(Vector3 pos)  => Console.WriteLine("[Atlas] Portal hum");
        public static void PlayGlowPickup(Vector3 pos)      => Console.WriteLine("[Atlas] Glow pickup");
        public static void PlayWorldAmbient(string world)   => Console.WriteLine($"[Atlas] Ambient: {world}");
    }

    // ── Atlas ImGuiHUD adapter ────────────────────────────────────────────────
    public static class ImGuiHUD
    {
        public static void BeginOverlay(string id)  { }
        public static void EndOverlay()             { }
        public static void BeginModal(string t)     { }
        public static void EndModal()               { }
        public static void Text(string t, bool dimmed=false) => Console.WriteLine(t);
        public static bool Button(string l)         => false;
    }

    // ── Static render settings wrapper ────────────────────────────────────────
    public static class RenderSettings
    {
        public static Vector3 AmbientLight   { get; set; }
        public static bool    FogEnabled     { get; set; }
        public static Vector3 FogColor       { get; set; }
        public static float   FogDensity     { get; set; }
        public static float   SunAngle       { get; set; }
        public static float   SunIntensity   { get; set; }
    }
}
