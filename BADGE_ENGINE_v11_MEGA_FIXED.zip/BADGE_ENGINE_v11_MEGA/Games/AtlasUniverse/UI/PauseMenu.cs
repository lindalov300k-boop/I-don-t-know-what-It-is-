using BADGE.Core;
using OpenTK.Mathematics;


namespace BADGE.Games.AtlasUniverse;

public class PauseMenu : MonoBehaviour
{
    private bool isPaused = false;
    private GUIStyle titleStyle;
    private GUIStyle buttonStyle;
    private Rect menuRect = new Rect(0, 0, 300, 200);

    void Start()
    {
        menuRect = new Rect((Screen.width - 300) / 2, (Screen.height - 200) / 2, 300, 200);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            isPaused = !isPaused;
            BADGE.Core.Time.ElapsedTimeScale = isPaused ? 0f : 1f;
        }
    }

    void OnGUI()
    {
        if (!isPaused) return;

        // Dim overlay
        GUI.color = new Color(0, 0, 0, 0.7f);
        GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
        GUI.color = Color.white;

        GUILayout.BeginArea(menuRect);
        GUILayout.Space(20);
        GUILayout.Label("PAUSED", GetTitleStyle());
        GUILayout.Space(20);

        if (GUILayout.Button("Resume", GetButtonStyle()))
        {
            isPaused = false;
            BADGE.Core.Time.ElapsedTimeScale = 1f;
        }
        GUILayout.Space(10);
        if (GUILayout.Button("Exit to Desktop", GetButtonStyle()))
        {
            BADGE.Core.Time.ElapsedTimeScale = 1f;
            GameManager.Instance?.SaveGame();
            Engine.Instance.Shutdown();
        }
        GUILayout.EndArea();
    }

    GUIStyle GetTitleStyle()
    {
        if (titleStyle == null)
        {
            titleStyle = new GUIStyle(GUI.skin.label);
            titleStyle.fontSize = 28;
            titleStyle.fontStyle = FontStyle.Bold;
            titleStyle.normal.textColor = Color.white;
            titleStyle.alignment = TextAnchor.MiddleCenter;
        }
        return titleStyle;
    }

    GUIStyle GetButtonStyle()
    {
        if (buttonStyle == null)
        {
            buttonStyle = new GUIStyle(GUI.skin.button);
            buttonStyle.fontSize = 18;
            buttonStyle.fixedHeight = 40;
        }
        return buttonStyle;
    }
}
