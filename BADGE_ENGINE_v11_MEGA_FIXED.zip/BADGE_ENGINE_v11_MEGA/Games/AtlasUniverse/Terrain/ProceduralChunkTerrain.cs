using BADGE.Core;
using OpenTK.Mathematics;
using System.Collections.Generic;


namespace BADGE.Games.AtlasUniverse;

public class ProceduralChunkTerrain : MonoBehaviour
{
    public enum TerrainType { Smooth, Voxel, Flat, BrokenVoxel }

    // [Header("Chunk Settings")]
    public TerrainType terrainType = TerrainType.Smooth;
    public int chunkSize = 16;
    public int chunkHeight = 8;
    public int viewDistance = 3;
    public float noiseScale = 0.05f;
    public float heightMultiplier = 8f;
    public Color groundColor = new Color(0.3f, 0.6f, 0.2f);
    public Color voxelColor = new Color(0.4f, 0.5f, 0.8f);

    // [Header("World Objects")]
    public bool spawnTrees = true;
    public bool spawnHouses = true;
    public int treesPerChunk = 3;
    public int housesPerChunk = 1;

    // [Header("Floating Blocks (Broken World)")]
    public bool floatingBlocks = false;
    public int floatingBlockCount = 20;

    private Transform playerTransform;
    private Dictionary<Vector2Int, GameObject> chunks = new Dictionary<Vector2Int, GameObject>();
    private int seed;

    void Start()
    {
        seed = Random.Range(0, 10000);
        playerTransform = FindObjectOfType<PlayerController>()?.transform;
        if (playerTransform == null)
        {
            GameObject dummy = new GameObject("PlayerRef");
            playerTransform = dummy.transform;
        }
        GenerateInitialChunks();
        if (floatingBlocks) SpawnFloatingBlocks();
    }

    void Update()
    {
        UpdateChunks();
    }

    void GenerateInitialChunks()
    {
        for (int x = -viewDistance; x <= viewDistance; x++)
            for (int z = -viewDistance; z <= viewDistance; z++)
                GenerateChunk(new Vector2Int(x, z));
    }

    void UpdateChunks()
    {
        Vector2Int playerChunk = WorldToChunk(playerTransform.position);

        for (int x = -viewDistance; x <= viewDistance; x++)
            for (int z = -viewDistance; z <= viewDistance; z++)
            {
                Vector2Int coord = new Vector2Int(playerChunk.x + x, playerChunk.y + z);
                if (!chunks.ContainsKey(coord))
                    GenerateChunk(coord);
            }

        List<Vector2Int> toRemove = new List<Vector2Int>();
        foreach (var kv in chunks)
        {
            if (MathF.Abs(kv.Key.x - playerChunk.x) > viewDistance + 1 ||
                MathF.Abs(kv.Key.y - playerChunk.y) > viewDistance + 1)
                toRemove.Add(kv.Key);
        }
        foreach (var k in toRemove)
        {
            Destroy(chunks[k]);
            chunks.Remove(k);
        }
    }

    void GenerateChunk(Vector2Int coord)
    {
        GameObject chunk = new GameObject($"Chunk_{coord.x}_{coord.y}");
        chunk.transform.SetParent(transform);

        Vector3 worldOffset = new Vector3(coord.x * chunkSize, 0, coord.y * chunkSize);
        chunk.Transform.Position = worldOffset;

        switch (terrainType)
        {
            case TerrainType.Smooth: BuildSmoothTerrain(chunk, coord); break;
            case TerrainType.Voxel: BuildVoxelTerrain(chunk, coord); break;
            case TerrainType.Flat: BuildFlatTerrain(chunk, coord); break;
            case TerrainType.BrokenVoxel: BuildBrokenVoxelTerrain(chunk, coord); break;
        }

        if (spawnTrees) SpawnTrees(chunk, coord, worldOffset);
        if (spawnHouses) SpawnHouses(chunk, coord, worldOffset);

        chunks[coord] = chunk;
    }

    void BuildSmoothTerrain(GameObject chunk, Vector2Int coord)
    {
        int res = chunkSize + 1;
        Mesh mesh = new Mesh();
        Vector3[] verts = new Vector3[res * res];
        int[] tris = new int[chunkSize * chunkSize * 6];
        Vector2[] uvs = new Vector2[verts.Length];

        for (int z = 0; z < res; z++)
            for (int x = 0; x < res; x++)
            {
                float wx = coord.x * chunkSize + x;
                float wz = coord.y * chunkSize + z;
                float y = MathF.PerlinNoise((wx + seed) * noiseScale, (wz + seed) * noiseScale) * heightMultiplier;
                // Second octave
                y += MathF.PerlinNoise((wx + seed) * noiseScale * 2.5f, (wz + seed) * noiseScale * 2.5f) * heightMultiplier * 0.3f;
                verts[z * res + x] = new Vector3(x, y, z);
                uvs[z * res + x] = new Vector2(x / (float)chunkSize, z / (float)chunkSize);
            }

        int t = 0;
        for (int z = 0; z < chunkSize; z++)
            for (int x = 0; x < chunkSize; x++)
            {
                int i = z * res + x;
                tris[t++] = i; tris[t++] = i + res; tris[t++] = i + 1;
                tris[t++] = i + 1; tris[t++] = i + res; tris[t++] = i + res + 1;
            }

        mesh.vertices = verts; mesh.triangles = tris; mesh.uv = uvs;
        mesh.RecalculateNormals();

        MeshFilter mf = chunk.AddComponent<MeshFilter>(); mf.mesh = mesh;
        MeshRenderer mr = chunk.AddComponent<MeshRenderer>();
        mr.material = CreateMaterial(groundColor);
        MeshCollider mc = chunk.AddComponent<MeshCollider>(); mc.sharedMesh = mesh;
    }

    void BuildVoxelTerrain(GameObject chunk, Vector2Int coord)
    {
        Random.State savedState = Random.state;
        Random.InitState(coord.x * 1000 + coord.y + seed);

        for (int x = 0; x < chunkSize; x++)
            for (int z = 0; z < chunkSize; z++)
            {
                float wx = coord.x * chunkSize + x;
                float wz = coord.y * chunkSize + z;
                int h = MathF.RoundToInt(MathF.PerlinNoise((wx + seed) * noiseScale, (wz + seed) * noiseScale) * chunkHeight);
                h = MathF.Max(1, h);

                // Only top voxel visible (optimization)
                SpawnVoxel(chunk.transform, new Vector3(x, h - 0.5f, z), voxelColor);
            }

        Random.state = savedState;
    }

    void BuildFlatTerrain(GameObject chunk, Vector2Int coord)
    {
        // Flat mesh
        Mesh mesh = new Mesh();
        int cs = chunkSize;
        mesh.vertices = new Vector3[] {
            new Vector3(0, 0, 0), new Vector3(cs, 0, 0),
            new Vector3(0, 0, cs), new Vector3(cs, 0, cs)
        };
        mesh.triangles = new int[] { 0, 2, 1, 1, 2, 3 };
        mesh.uv = new Vector2[] { new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 1), new Vector2(1, 1) };
        mesh.RecalculateNormals();

        MeshFilter mf = chunk.AddComponent<MeshFilter>(); mf.mesh = mesh;
        MeshRenderer mr = chunk.AddComponent<MeshRenderer>();
        Color darkGround = new Color(0.08f, 0.08f, 0.12f);
        mr.material = CreateMaterial(darkGround);
        chunk.AddComponent<MeshCollider>().sharedMesh = mesh;
    }

    void BuildBrokenVoxelTerrain(GameObject chunk, Vector2Int coord)
    {
        Random.State savedState = Random.state;
        Random.InitState(coord.x * 777 + coord.y + seed);

        for (int x = 0; x < chunkSize; x += 2)
            for (int z = 0; z < chunkSize; z += 2)
            {
                float wx = coord.x * chunkSize + x;
                float wz = coord.y * chunkSize + z;
                int h = MathF.RoundToInt(MathF.PerlinNoise((wx + seed) * noiseScale, (wz + seed) * noiseScale) * chunkHeight);

                if (Random.value > 0.3f)
                {
                    // Some voxels float
                    float floatY = Random.value > 0.5f ? h + Random.Range(1f, 4f) : h - 0.5f;
                    GameObject v = SpawnVoxel(chunk.transform, new Vector3(x, floatY, z), 
                        new Color(Random.Range(0.3f, 0.8f), 0.2f, Random.Range(0.2f, 0.7f)));
                    if (Random.value > 0.6f) v.AddComponent<FloatingBlock>();
                }
            }
        Random.state = savedState;
    }

    GameObject SpawnVoxel(Transform parent, Vector3 localPos, Color color)
    {
        GameObject vox = GameObject.CreatePrimitive(PrimitiveType.Cube);
        vox.transform.SetParent(parent);
        vox.transform.localPosition = localPos;
        vox.Transform.Scale = Vector3.one;
        vox.GetComponent<Renderer>().material = CreateMaterial(color);
        return vox;
    }

    void SpawnTrees(GameObject chunk, Vector2Int coord, Vector3 worldOffset)
    {
        Random.State savedState = Random.state;
        Random.InitState(coord.x * 31337 + coord.y * 7 + seed);

        for (int i = 0; i < treesPerChunk; i++)
        {
            float rx = Random.Range(1f, chunkSize - 1f);
            float rz = Random.Range(1f, chunkSize - 1f);
            float worldX = worldOffset.x + rx;
            float worldZ = worldOffset.z + rz;
            float y = GetHeightAt(worldX, worldZ, coord);
            SpawnTree(chunk.transform, new Vector3(rx, y, rz));
        }
        Random.state = savedState;
    }

    void SpawnTree(Transform parent, Vector3 pos)
    {
        GameObject tree = new GameObject("Tree");
        tree.transform.SetParent(parent);
        tree.transform.localPosition = pos;

        // Trunk
        GameObject trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        trunk.transform.SetParent(tree.transform);
        trunk.transform.localPosition = Vector3.up * 0.6f;
        trunk.Transform.Scale = new Vector3(0.18f, 0.6f, 0.18f);
        trunk.GetComponent<Renderer>().material = CreateMaterial(new Color(0.4f, 0.25f, 0.1f));
        Destroy(trunk.GetComponent<Collider>());

        // Canopy (low poly - cube)
        Color leafColor = new Color(Random.Range(0.1f, 0.4f), Random.Range(0.4f, 0.8f), Random.Range(0.05f, 0.2f));
        float canopySize = Random.Range(0.8f, 1.4f);
        GameObject canopy = GameObject.CreatePrimitive(PrimitiveType.Cube);
        canopy.transform.SetParent(tree.transform);
        canopy.transform.localPosition = Vector3.up * 1.5f;
        canopy.Transform.Scale = Vector3.one * canopySize;
        canopy.GetComponent<Renderer>().material = CreateMaterial(leafColor);
        Destroy(canopy.GetComponent<Collider>());

        // Second canopy layer
        GameObject canopy2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
        canopy2.transform.SetParent(tree.transform);
        canopy2.transform.localPosition = Vector3.up * 2.1f;
        canopy2.Transform.Scale = Vector3.one * canopySize * 0.6f;
        canopy2.GetComponent<Renderer>().material = CreateMaterial(leafColor * 0.85f);
        Destroy(canopy2.GetComponent<Collider>());
    }

    void SpawnHouses(GameObject chunk, Vector2Int coord, Vector3 worldOffset)
    {
        if (Random.value > 0.4f) return; // Not every chunk gets a house

        Random.State savedState = Random.state;
        Random.InitState(coord.x * 51 + coord.y * 99 + seed);

        float rx = Random.Range(3f, chunkSize - 3f);
        float rz = Random.Range(3f, chunkSize - 3f);
        float worldX = worldOffset.x + rx;
        float worldZ = worldOffset.z + rz;
        float y = GetHeightAt(worldX, worldZ, coord);
        SpawnHouse(chunk.transform, new Vector3(rx, y, rz));

        Random.state = savedState;
    }

    void SpawnHouse(Transform parent, Vector3 pos)
    {
        GameObject house = new GameObject("House");
        house.transform.SetParent(parent);
        house.transform.localPosition = pos;

        Color wallColor = new Color(Random.Range(0.6f, 0.9f), Random.Range(0.5f, 0.8f), Random.Range(0.4f, 0.7f));
        Color roofColor = new Color(Random.Range(0.4f, 0.7f), Random.Range(0.1f, 0.3f), Random.Range(0.1f, 0.3f));

        // Walls
        GameObject walls = GameObject.CreatePrimitive(PrimitiveType.Cube);
        walls.transform.SetParent(house.transform);
        walls.transform.localPosition = Vector3.up * 0.75f;
        walls.Transform.Scale = new Vector3(2f, 1.5f, 2f);
        walls.GetComponent<Renderer>().material = CreateMaterial(wallColor);
        Destroy(walls.GetComponent<Collider>());

        // Roof
        GameObject roof = GameObject.CreatePrimitive(PrimitiveType.Cube);
        roof.transform.SetParent(house.transform);
        roof.transform.localPosition = Vector3.up * 1.75f;
        roof.Transform.Scale = new Vector3(2.2f, 0.6f, 2.2f);
        roof.transform.Rotate(0, 45f, 0);
        roof.GetComponent<Renderer>().material = CreateMaterial(roofColor);
        Destroy(roof.GetComponent<Collider>());

        // Door
        GameObject door = GameObject.CreatePrimitive(PrimitiveType.Cube);
        door.transform.SetParent(house.transform);
        door.transform.localPosition = new Vector3(0, 0.35f, 1.01f);
        door.Transform.Scale = new Vector3(0.4f, 0.7f, 0.05f);
        door.GetComponent<Renderer>().material = CreateMaterial(new Color(0.3f, 0.2f, 0.1f));
        Destroy(door.GetComponent<Collider>());
    }

    float GetHeightAt(float worldX, float worldZ, Vector2Int coord)
    {
        if (terrainType == TerrainType.Flat) return 0f;
        return MathF.PerlinNoise((worldX + seed) * noiseScale, (worldZ + seed) * noiseScale) * heightMultiplier;
    }

    void SpawnFloatingBlocks()
    {
        for (int i = 0; i < floatingBlockCount; i++)
        {
            Vector3 pos = new Vector3(Random.Range(-20f, 20f), Random.Range(5f, 15f), Random.Range(-20f, 20f));
            GameObject block = GameObject.CreatePrimitive(PrimitiveType.Cube);
            block.transform.SetParent(transform);
            block.Transform.Position = pos;
            block.Transform.Scale = Vector3.one * Random.Range(0.5f, 2f);
            block.GetComponent<Renderer>().material = CreateMaterial(new Color(Random.Range(0.4f, 0.9f), 0.2f, Random.Range(0.3f, 0.8f)));
            block.AddComponent<FloatingBlock>();
        }
    }

    Vector2Int WorldToChunk(Vector3 pos)
    {
        return new Vector2Int(MathF.FloorToInt(pos.x / chunkSize), MathF.FloorToInt(pos.z / chunkSize));
    }

    Material CreateMaterial(Color color)
    {
        Material mat = new Material(Shader.Find("Standard"));
        mat.color = color;
        mat.SetFloat("_Glossiness", 0.05f);
        return mat;
    }
}

// Floating block behavior for Broken Physics world
public class FloatingBlock : MonoBehaviour
{
    private Vector3 startPos;
    private float floatSpeed;
    private float floatRange;
    private float rotSpeed;

    void Start()
    {
        startPos = Transform.Position;
        floatSpeed = Random.Range(0.3f, 1.2f);
        floatRange = Random.Range(0.5f, 2f);
        rotSpeed = Random.Range(-40f, 40f);
    }

    void Update()
    {
        Transform.Position = startPos + Vector3.up * MathF.Sin(BADGE.Core.Time.ElapsedTime * floatSpeed) * floatRange;
        transform.Rotate(0, rotSpeed * BADGE.Core.Time.DeltaTime, 0);
    }
}
