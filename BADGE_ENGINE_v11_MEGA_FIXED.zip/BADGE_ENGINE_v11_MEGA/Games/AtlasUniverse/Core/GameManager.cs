using BADGE.Core;
using OpenTK.Mathematics;


namespace BADGE.Games.AtlasUniverse;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public enum WorldState
    {
        StartScene = 0,
        AlphaWorld = 1,
        WorldI_Greed = 2,
        WorldII_Shadow = 3,
        WorldIII_Glow = 4,
        WorldIV_Broken = 5,
        WorldV_Envy = 6,
        WorldVI_Sloth = 7,
        CoreWorld = 8
    }

    public WorldState CurrentWorld = WorldState.StartScene;
    public bool ExistenceTerminated = false;
    public float PlayerGrowthScale = 1f;
    public float PlayerGlowIntensity = 0f;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            SceneManager.Instance.DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
        LoadSave();
    }

    public void LoadWorld(WorldState world)
    {
        CurrentWorld = world;
        SaveGame();
        SceneManager.Instance.LoadScene((int)world);
    }

    public void NextWorld()
    {
        int next = (int)CurrentWorld + 1;
        if (next <= 8)
            LoadWorld((WorldState)next);
    }

    public void SaveGame()
    {
        PlayerPrefs.SetInt("CurrentWorld", (int)CurrentWorld);
        PlayerPrefs.SetFloat("GrowthScale", PlayerGrowthScale);
        PlayerPrefs.SetFloat("GlowIntensity", PlayerGlowIntensity);
        PlayerPrefs.SetInt("Terminated", ExistenceTerminated ? 1 : 0);
        PlayerPrefs.Save();
    }

    public void LoadSave()
    {
        if (PlayerPrefs.HasKey("CurrentWorld"))
        {
            CurrentWorld = (WorldState)PlayerPrefs.GetInt("CurrentWorld");
            PlayerGrowthScale = PlayerPrefs.GetFloat("GrowthScale", 1f);
            PlayerGlowIntensity = PlayerPrefs.GetFloat("GlowIntensity", 0f);
            ExistenceTerminated = PlayerPrefs.GetInt("Terminated", 0) == 1;
        }
    }

    public void TerminateExistence()
    {
        ExistenceTerminated = true;
        PlayerPrefs.SetInt("Terminated", 1);
        PlayerPrefs.Save();
    }

    public void ResetGame()
    {
        PlayerPrefs.DeleteAll();
        ExistenceTerminated = false;
        CurrentWorld = WorldState.StartScene;
        PlayerGrowthScale = 1f;
        PlayerGlowIntensity = 0f;
        LoadWorld(WorldState.StartScene);
    }
}
