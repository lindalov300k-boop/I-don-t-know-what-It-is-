using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace BADGE.Hardware
{
    /// <summary>
    /// Hardware Interface — detects and monitors system hardware capabilities,
    /// and provides a communication bridge between the engine and the OS/drivers.
    ///
    /// Responsibilities
    /// ────────────────
    ///  • Enumerate CPU, GPU (via OpenGL strings), RAM at startup.
    ///  • Expose capability flags that subsystems query (HasHardwareShadows, etc.).
    ///  • Emit HardwareEvents (thermal throttling, GPU context lost, low memory).
    ///  • Provide a cross-platform P/Invoke layer for OS-level operations
    ///    (window, memory, process priority).
    ///  • Feed metrics to PerformanceManager for adaptive quality scaling.
    /// </summary>
    public sealed class HardwareInterface
    {
        // ── Singleton ─────────────────────────────────────────────────────
        private static readonly Lazy<HardwareInterface> _lazy = new(() => new HardwareInterface());
        public static HardwareInterface Instance => _lazy.Value;

        // ─────────────────────────────────────────────────────────────────
        //  HARDWARE INFO  (populated during Initialize)
        // ─────────────────────────────────────────────────────────────────

        public CpuInfo   CPU    { get; private set; } = new();
        public GpuInfo   GPU    { get; private set; } = new();
        public MemoryInfo Memory { get; private set; } = new();
        public OsInfo    OS     { get; private set; } = new();

        // ── Capability flags ─────────────────────────────────────────────
        public bool HasHardwareShadows     => GPU.SupportsShadowMaps;
        public bool HasComputeShaders      => GPU.SupportsCompute;
        public bool HasHardwareOcclusion   => GPU.SupportsOcclusionQuery;
        public bool IsLowEndDevice         => CPU.LogicalCores <= 2 || Memory.TotalMB < 2048;
        public bool IsHighEndDevice        => CPU.LogicalCores >= 8 && Memory.TotalMB >= 8192;

        // ─────────────────────────────────────────────────────────────────
        //  EVENTS
        // ─────────────────────────────────────────────────────────────────
        public event Action<HardwareEvent>? OnEvent;

        private void Emit(HardwareEventType type, string msg)
        {
            var ev = new HardwareEvent(type, msg);
            Console.WriteLine($"[Hardware] {type}: {msg}");
            OnEvent?.Invoke(ev);
        }

        // ─────────────────────────────────────────────────────────────────
        //  INITIALIZE
        // ─────────────────────────────────────────────────────────────────

        private HardwareInterface() { }

        public void Initialize()
        {
            Console.WriteLine("[Hardware] Detecting system hardware…");
            DetectCpu();
            DetectMemory();
            DetectOs();
            // GPU detection happens after OpenGL context creation — call
            // RefreshGpuInfo() from the renderer once the context is ready.

            SetProcessPriority(ProcessPriorityClass.AboveNormal);
            Console.WriteLine($"[Hardware] CPU: {CPU.Name}  Cores: {CPU.LogicalCores}  Arch: {CPU.Architecture}");
            Console.WriteLine($"[Hardware] RAM: {Memory.TotalMB} MB available {Memory.AvailableMB} MB");
            Console.WriteLine($"[Hardware] OS:  {OS.Name} {OS.Architecture}");

            StartMonitor();
        }

        // ─────────────────────────────────────────────────────────────────
        //  CPU DETECTION
        // ─────────────────────────────────────────────────────────────────

        private void DetectCpu()
        {
            CPU = new CpuInfo
            {
                Name         = GetCpuName(),
                LogicalCores = Environment.ProcessorCount,
                Architecture = RuntimeInformation.ProcessArchitecture.ToString(),
                IsArm        = RuntimeInformation.ProcessArchitecture is
                                   Architecture.Arm or Architecture.Arm64,
            };

            // On Linux, check /proc/cpuinfo for frequency
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    string info = System.IO.File.ReadAllText("/proc/cpuinfo");
                    var match   = System.Text.RegularExpressions.Regex.Match(
                                      info, @"cpu MHz\s*:\s*(\d+)");
                    if (match.Success)
                        CPU.ClockMhz = int.Parse(match.Groups[1].Value);
                }
                catch { /* non-fatal */ }
            }
        }

        private static string GetCpuName()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                try
                {
                    // WMI via psi — avoids PInvoke complexity
                    using var psi = new ProcessStartInfo("wmic", "cpu get Name /FORMAT:value")
                    { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                    using var p = Process.Start(psi)!;
                    string output = p.StandardOutput.ReadToEnd();
                    p.WaitForExit(2000);
                    var m = System.Text.RegularExpressions.Regex.Match(output, @"Name=(.+)");
                    if (m.Success) return m.Groups[1].Value.Trim();
                }
                catch { /* fall through */ }
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    string info = System.IO.File.ReadAllText("/proc/cpuinfo");
                    var m = System.Text.RegularExpressions.Regex.Match(info, @"model name\s*:\s*(.+)");
                    if (m.Success) return m.Groups[1].Value.Trim();
                }
                catch { /* fall through */ }
            }
            return $"{RuntimeInformation.ProcessArchitecture} CPU ({Environment.ProcessorCount} cores)";
        }

        // ─────────────────────────────────────────────────────────────────
        //  MEMORY DETECTION
        // ─────────────────────────────────────────────────────────────────

        private void DetectMemory()
        {
            long totalBytes     = GetTotalPhysicalMemory();
            long availableBytes = GetAvailablePhysicalMemory();

            Memory = new MemoryInfo
            {
                TotalMB     = (int)(totalBytes     / 1_048_576),
                AvailableMB = (int)(availableBytes / 1_048_576),
            };
        }

        private static long GetTotalPhysicalMemory()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                try
                {
                    var info = new MEMORYSTATUSEX();
                    info.dwLength = (uint)Marshal.SizeOf(info);
                    GlobalMemoryStatusEx(ref info);
                    return (long)info.ullTotalPhys;
                }
                catch { /* fall through */ }
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    string meminfo = System.IO.File.ReadAllText("/proc/meminfo");
                    var m = System.Text.RegularExpressions.Regex.Match(meminfo, @"MemTotal:\s+(\d+) kB");
                    if (m.Success) return long.Parse(m.Groups[1].Value) * 1024L;
                }
                catch { /* fall through */ }
            }
            // Fallback: GC tells us the heap limit as a proxy
            return GC.GetGCMemoryInfo().TotalAvailableMemoryBytes;
        }

        private static long GetAvailablePhysicalMemory()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                try
                {
                    var info = new MEMORYSTATUSEX();
                    info.dwLength = (uint)Marshal.SizeOf(info);
                    GlobalMemoryStatusEx(ref info);
                    return (long)info.ullAvailPhys;
                }
                catch { }
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    string meminfo = System.IO.File.ReadAllText("/proc/meminfo");
                    var m = System.Text.RegularExpressions.Regex.Match(meminfo, @"MemAvailable:\s+(\d+) kB");
                    if (m.Success) return long.Parse(m.Groups[1].Value) * 1024L;
                }
                catch { }
            }
            return GC.GetGCMemoryInfo().TotalAvailableMemoryBytes;
        }

        // ─────────────────────────────────────────────────────────────────
        //  GPU DETECTION  (call after OpenGL context is ready)
        // ─────────────────────────────────────────────────────────────────

        /// <summary>
        /// Must be called by the renderer AFTER the OpenGL context is created.
        /// Reads GL_RENDERER, GL_VERSION, GL_EXTENSIONS.
        /// </summary>
        public void RefreshGpuInfo(string renderer, string version, string extensions)
        {
            var gpu = new GpuInfo
            {
                Renderer          = renderer,
                Version           = version,
                SupportsShadowMaps= extensions.Contains("shadow"),
                SupportsCompute   = extensions.Contains("compute_shader") ||
                                    extensions.Contains("GL_ARB_compute"),
                SupportsOcclusionQuery = extensions.Contains("occlusion_query"),
                SupportsInstancing= extensions.Contains("instanced_arrays") ||
                                    extensions.Contains("GL_ARB_instanced"),
                IsIntegrated      = renderer.Contains("Intel") ||
                                    renderer.Contains("HD Graphics") ||
                                    renderer.Contains("UHD Graphics"),
            };
            GPU = gpu;
            Console.WriteLine($"[Hardware] GPU: {GPU.Renderer}  GL: {GPU.Version}");
            Console.WriteLine($"[Hardware] GPU Caps: shadows={GPU.SupportsShadowMaps} " +
                              $"compute={GPU.SupportsCompute} occlusion={GPU.SupportsOcclusionQuery}");

            if (GPU.IsIntegrated)
                Emit(HardwareEventType.Warning, "Integrated GPU detected — quality scaled down.");
        }

        // ─────────────────────────────────────────────────────────────────
        //  OS INFO
        // ─────────────────────────────────────────────────────────────────

        private void DetectOs()
        {
            OS = new OsInfo
            {
                Name         = RuntimeInformation.OSDescription,
                Architecture = RuntimeInformation.OSArchitecture.ToString(),
                IsWindows    = RuntimeInformation.IsOSPlatform(OSPlatform.Windows),
                IsLinux      = RuntimeInformation.IsOSPlatform(OSPlatform.Linux),
                IsMacOs      = RuntimeInformation.IsOSPlatform(OSPlatform.OSX),
            };
        }

        // ─────────────────────────────────────────────────────────────────
        //  PROCESS PRIORITY  (hardware-software communication)
        // ─────────────────────────────────────────────────────────────────

        public void SetProcessPriority(ProcessPriorityClass priority)
        {
            try
            {
                Process.GetCurrentProcess().PriorityClass = priority;
                Console.WriteLine($"[Hardware] Process priority set to {priority}.");
            }
            catch { Console.WriteLine("[Hardware] Could not set process priority."); }
        }

        // ─────────────────────────────────────────────────────────────────
        //  LIVE MONITOR  (background thread, polls every 5 s)
        // ─────────────────────────────────────────────────────────────────

        private Thread? _monitorThread;
        private bool    _monitoring;

        private void StartMonitor()
        {
            _monitoring  = true;
            _monitorThread = new Thread(MonitorLoop)
            { IsBackground = true, Name = "HardwareMonitor" };
            _monitorThread.Start();
        }

        public void StopMonitor() => _monitoring = false;

        private void MonitorLoop()
        {
            while (_monitoring)
            {
                Thread.Sleep(5000);
                if (!_monitoring) break;

                // Update live memory
                long avail = GetAvailablePhysicalMemory();
                Memory = Memory with { AvailableMB = (int)(avail / 1_048_576) };

                // Warn on low memory
                if (Memory.AvailableMB < 256)
                    Emit(HardwareEventType.LowMemory, $"Only {Memory.AvailableMB} MB RAM available.");

                // Warn on GC pressure
                long heapUsed = GC.GetTotalMemory(false) / 1_048_576;
                if (heapUsed > 512)
                    Emit(HardwareEventType.HighHeapUsage, $"Managed heap at {heapUsed} MB.");
            }
        }

        public HardwareMetrics GetMetrics() => new()
        {
            CpuCores    = CPU.LogicalCores,
            TotalRamMB  = Memory.TotalMB,
            AvailRamMB  = Memory.AvailableMB,
            HeapUsedMB  = (int)(GC.GetTotalMemory(false) / 1_048_576),
            GpuRenderer = GPU.Renderer,
        };

        // ─────────────────────────────────────────────────────────────────
        //  WIN32 P/INVOKE  (Windows only)
        // ─────────────────────────────────────────────────────────────────

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct MEMORYSTATUSEX
        {
            public uint  dwLength;
            public uint  dwMemoryLoad;
            public ulong ullTotalPhys;
            public ulong ullAvailPhys;
            public ulong ullTotalPageFile;
            public ulong ullAvailPageFile;
            public ulong ullTotalVirtual;
            public ulong ullAvailVirtual;
            public ulong ullAvailExtendedVirtual;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX lpBuffer);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  HARDWARE COMMUNICATION BRIDGE
    //  Routes hardware events to engine subsystems without tight coupling.
    // ─────────────────────────────────────────────────────────────────────────
    public static class HardwareCommunicationBridge
    {
        private static readonly Dictionary<HardwareEventType, List<Action<HardwareEvent>>> _handlers = new();

        public static void Register(HardwareEventType type, Action<HardwareEvent> handler)
        {
            if (!_handlers.TryGetValue(type, out var list))
                _handlers[type] = list = new();
            list.Add(handler);
        }

        public static void Dispatch(HardwareEvent ev)
        {
            if (_handlers.TryGetValue(ev.Type, out var list))
                foreach (var h in list) h(ev);
        }

        /// <summary>Wire HardwareInterface events into the bridge at startup.</summary>
        public static void ConnectToInterface()
        {
            HardwareInterface.Instance.OnEvent += Dispatch;
            Console.WriteLine("[Hardware] Communication bridge connected.");
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  DATA TYPES
    // ─────────────────────────────────────────────────────────────────────────

    public sealed record CpuInfo
    {
        public string Name         { get; init; } = "Unknown CPU";
        public int    LogicalCores { get; init; } = Environment.ProcessorCount;
        public string Architecture { get; init; } = "x64";
        public bool   IsArm        { get; init; }
        public int    ClockMhz     { get; set; }
    }

    public sealed record GpuInfo
    {
        public string Renderer              { get; init; } = "Unknown GPU";
        public string Version               { get; init; } = "";
        public bool   SupportsShadowMaps    { get; init; }
        public bool   SupportsCompute       { get; init; }
        public bool   SupportsOcclusionQuery{ get; init; }
        public bool   SupportsInstancing    { get; init; }
        public bool   IsIntegrated          { get; init; }
    }

    public sealed record MemoryInfo
    {
        public int TotalMB     { get; init; }
        public int AvailableMB { get; set; }
    }

    public sealed record OsInfo
    {
        public string Name         { get; init; } = "Unknown OS";
        public string Architecture { get; init; } = "x64";
        public bool   IsWindows    { get; init; }
        public bool   IsLinux      { get; init; }
        public bool   IsMacOs      { get; init; }
    }

    public sealed class HardwareEvent
    {
        public HardwareEventType Type    { get; }
        public string            Message { get; }
        public DateTimeOffset    Time    { get; } = DateTimeOffset.UtcNow;

        public HardwareEvent(HardwareEventType type, string msg) { Type = type; Message = msg; }
    }

    public enum HardwareEventType
    {
        Info, Warning, Error,
        LowMemory, HighHeapUsage,
        GpuContextLost, ThermalThrottle,
        DisplayChanged, DeviceConnected, DeviceDisconnected,
    }

    public sealed class HardwareMetrics
    {
        public int    CpuCores    { get; init; }
        public int    TotalRamMB  { get; init; }
        public int    AvailRamMB  { get; init; }
        public int    HeapUsedMB  { get; init; }
        public string GpuRenderer { get; init; } = "";
    }
}
