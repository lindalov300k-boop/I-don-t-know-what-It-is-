using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Cinematic
{
    // ═══════════════════════════════════════════════════════════════════════
    //  CINEMATIC DIRECTOR
    //
    //  Full cutscene / in-engine cinematic authoring system.
    //
    //  Tracks per sequence:
    //    • CameraTrack        — position/rotation/FOV keyframes with easing
    //    • ActorAnimTrack     — trigger animation clips per actor
    //    • ActorMoveTrack     — move actors along bezier paths
    //    • DialogueTrack      — fire dialogue lines with subtitles
    //    • AudioTrack         — play/stop audio clips, fade music
    //    • PostFXTrack        — animate vignette, DOF, color grading
    //    • SubtitleTrack      — timed subtitle strings
    //    • EventTrack         — fire arbitrary game events at timestamps
    //    • FadeTrack          — screen fade in/out
    //    • ParticleTrack      — spawn/stop particle systems
    //    • ShakeTrack         — camera shake bursts
    //    • DOFTrack           — depth-of-field focus target animation
    //    • SlowMoTrack        — TimeScale ramps
    //
    //  Features:
    //    • Skippable (with skip confirmation)
    //    • Can lock player input during playback
    //    • Blends from gameplay camera to cinematic camera
    //    • Playback rate (slow-mo, fast-forward)
    //    • CanvasGroup fade (UI hide during cutscene)
    //    • Scene-embedded or asset-file driven
    //    • OnComplete / OnSkipped callbacks
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  EASING
    // ─────────────────────────────────────────────────────────────────────
    public enum CinematicEase
    {
        Linear, EaseIn, EaseOut, EaseInOut, Spring, Bounce, BackIn, BackOut
    }

    public static class CinematicEaser
    {
        public static float Evaluate(float t, CinematicEase ease) => ease switch
        {
            CinematicEase.EaseIn    => t * t,
            CinematicEase.EaseOut   => t * (2f - t),
            CinematicEase.EaseInOut => t < 0.5f ? 2f * t * t : -1f + (4f - 2f * t) * t,
            CinematicEase.Spring    => MathF.Sin(t * MathF.PI * (0.2f + 2.5f * t * t * t))
                                       * MathF.Pow(1f - t, 2.2f) + t,
            CinematicEase.Bounce    => 1f - BounceOut(1f - t),
            CinematicEase.BackOut   => { float c1 = 1.70158f; float c3 = c1 + 1f;
                                          return 1f + c3 * MathF.Pow(t - 1f, 3) + c1 * MathF.Pow(t - 1f, 2); },
            _                        => t
        };

        private static float BounceOut(float x)
        {
            const float n1 = 7.5625f, d1 = 2.75f;
            if (x < 1f / d1)        return n1 * x * x;
            if (x < 2f / d1)        return n1 * (x -= 1.5f / d1) * x + 0.75f;
            if (x < 2.5f / d1)      return n1 * (x -= 2.25f / d1) * x + 0.9375f;
            return n1 * (x -= 2.625f / d1) * x + 0.984375f;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  KEYFRAMES
    // ─────────────────────────────────────────────────────────────────────

    public struct CameraKeyframe
    {
        public float         Time;
        public Vector3       Position;
        public Quaternion    Rotation;
        public float         FOV;
        public float         NearClip;
        public float         FarClip;
        public CinematicEase Ease;
    }

    public struct FloatKeyframe
    {
        public float         Time;
        public float         Value;
        public CinematicEase Ease;
    }

    public struct ColorKeyframe
    {
        public float         Time;
        public Vector4       Color; // RGBA
        public CinematicEase Ease;
    }

    public struct Vector3Keyframe
    {
        public float         Time;
        public Vector3       Value;
        public CinematicEase Ease;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  BASE TRACK
    // ─────────────────────────────────────────────────────────────────────
    public abstract class CinematicTrack
    {
        public string Name    { get; init; } = "";
        public float  StartAt { get; set; } = 0f;
        public float  EndAt   { get; set; } = 5f;
        public float  Duration => EndAt - StartAt;
        public bool   Muted   { get; set; }

        public abstract void Sample(float sequenceTime, CinematicDirector director);
        public abstract void OnBegin(CinematicDirector director);
        public abstract void OnEnd(CinematicDirector director);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  CAMERA TRACK
    // ─────────────────────────────────────────────────────────────────────
    public class CameraTrack : CinematicTrack
    {
        public List<CameraKeyframe> Keyframes { get; } = new();
        public bool                  BlendFromGameplay { get; set; } = true;
        public float                 BlendInTime       { get; set; } = 0.5f;
        public float                 BlendOutTime      { get; set; } = 0.5f;

        public override void OnBegin(CinematicDirector d) =>
            d.NotifyCameraOverride(true);

        public override void OnEnd(CinematicDirector d) =>
            d.NotifyCameraOverride(false);

        public override void Sample(float t, CinematicDirector d)
        {
            if (Muted || Keyframes.Count == 0) return;
            float localT = t - StartAt;
            var (a, b, alpha) = FindKeyframePair(localT);

            float ea = CinematicEaser.Evaluate(alpha, b.Ease);
            var pos = Vector3.Lerp(a.Position, b.Position, ea);
            var rot = Quaternion.Slerp(a.Rotation, b.Rotation, ea);
            float fov = MathHelper.Lerp(a.FOV, b.FOV, ea);

            d.SetCinematicCamera(pos, rot, fov);
        }

        private (CameraKeyframe a, CameraKeyframe b, float alpha) FindKeyframePair(float localT)
        {
            if (Keyframes.Count == 1)
                return (Keyframes[0], Keyframes[0], 0f);

            for (int i = 0; i < Keyframes.Count - 1; i++)
            {
                if (localT <= Keyframes[i + 1].Time)
                {
                    float range = Keyframes[i + 1].Time - Keyframes[i].Time;
                    float alpha = range > 0f ? (localT - Keyframes[i].Time) / range : 1f;
                    return (Keyframes[i], Keyframes[i + 1], alpha);
                }
            }
            return (Keyframes[^1], Keyframes[^1], 0f);
        }

        // ── Builder helpers ────────────────────────────────────────────────
        public CameraTrack AddKeyframe(float time, Vector3 pos, Quaternion rot,
                                        float fov = 60f, CinematicEase ease = CinematicEase.EaseInOut)
        {
            Keyframes.Add(new CameraKeyframe { Time=time, Position=pos, Rotation=rot,
                                               FOV=fov, Ease=ease });
            Keyframes.Sort((a, b) => a.Time.CompareTo(b.Time));
            return this;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DIALOGUE TRACK
    // ─────────────────────────────────────────────────────────────────────
    public struct DialogueCue
    {
        public float  Time;
        public string SpeakerID;
        public string LineKey;      // localization key
        public string? AudioClip;
        public bool   AutoAdvance;
        public float  DisplayDuration;
    }

    public class DialogueTrack : CinematicTrack
    {
        public List<DialogueCue> Cues { get; } = new();
        private int _lastFired = -1;

        public override void OnBegin(CinematicDirector d) { _lastFired = -1; }
        public override void OnEnd(CinematicDirector d)   { }

        public override void Sample(float t, CinematicDirector d)
        {
            if (Muted) return;
            float localT = t - StartAt;
            for (int i = _lastFired + 1; i < Cues.Count; i++)
            {
                if (Cues[i].Time <= localT)
                {
                    d.FireDialogueLine(Cues[i]);
                    _lastFired = i;
                }
            }
        }

        public DialogueTrack AddCue(float time, string speakerId, string lineKey,
                                     string? audioClip = null, float duration = 3f)
        {
            Cues.Add(new DialogueCue
            {
                Time = time, SpeakerID = speakerId, LineKey = lineKey,
                AudioClip = audioClip, DisplayDuration = duration, AutoAdvance = true
            });
            return this;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  EVENT TRACK
    // ─────────────────────────────────────────────────────────────────────
    public struct CinematicEvent
    {
        public float   Time;
        public string  Name;
        public object? Data;
    }

    public class EventTrack : CinematicTrack
    {
        public List<CinematicEvent> Events { get; } = new();
        private int _lastFired = -1;

        public override void OnBegin(CinematicDirector d) { _lastFired = -1; }
        public override void OnEnd(CinematicDirector d) { }

        public override void Sample(float t, CinematicDirector d)
        {
            if (Muted) return;
            float localT = t - StartAt;
            for (int i = _lastFired + 1; i < Events.Count; i++)
            {
                if (Events[i].Time <= localT)
                {
                    d.FireEvent(Events[i]);
                    _lastFired = i;
                }
            }
        }

        public EventTrack At(float time, string name, object? data = null)
        {
            Events.Add(new CinematicEvent { Time = time, Name = name, Data = data });
            return this;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  FLOAT PARAM TRACK  (reusable for FOV, vignette, blur amount, etc.)
    // ─────────────────────────────────────────────────────────────────────
    public class FloatParamTrack : CinematicTrack
    {
        public List<FloatKeyframe>  Keyframes { get; } = new();
        public Action<float>?       Apply     { get; set; }

        public override void OnBegin(CinematicDirector d) { }
        public override void OnEnd(CinematicDirector d) { }

        public override void Sample(float t, CinematicDirector d)
        {
            if (Muted || Keyframes.Count == 0 || Apply == null) return;
            float localT = t - StartAt;
            float value  = SampleKeyframes(localT);
            Apply(value);
        }

        private float SampleKeyframes(float localT)
        {
            if (Keyframes.Count == 1) return Keyframes[0].Value;
            for (int i = 0; i < Keyframes.Count - 1; i++)
            {
                if (localT <= Keyframes[i + 1].Time)
                {
                    float range = Keyframes[i + 1].Time - Keyframes[i].Time;
                    float alpha = range > 0f ? (localT - Keyframes[i].Time) / range : 1f;
                    float ea    = CinematicEaser.Evaluate(alpha, Keyframes[i + 1].Ease);
                    return MathHelper.Lerp(Keyframes[i].Value, Keyframes[i + 1].Value, ea);
                }
            }
            return Keyframes[^1].Value;
        }

        public FloatParamTrack Key(float time, float value,
                                    CinematicEase ease = CinematicEase.EaseInOut)
        {
            Keyframes.Add(new FloatKeyframe { Time = time, Value = value, Ease = ease });
            return this;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  SHAKE TRACK
    // ─────────────────────────────────────────────────────────────────────
    public struct ShakeCue
    {
        public float Time;
        public float Magnitude;
        public float DurationSec;
        public float FrequencyHz;
    }

    public class ShakeTrack : CinematicTrack
    {
        public List<ShakeCue> Cues { get; } = new();
        private int _lastFired = -1;

        public override void OnBegin(CinematicDirector d) { _lastFired = -1; }
        public override void OnEnd(CinematicDirector d) { }

        public override void Sample(float t, CinematicDirector d)
        {
            if (Muted) return;
            float localT = t - StartAt;
            for (int i = _lastFired + 1; i < Cues.Count; i++)
            {
                if (Cues[i].Time <= localT)
                {
                    d.FireShake(Cues[i]);
                    _lastFired = i;
                }
            }
        }

        public ShakeTrack Shake(float time, float mag = 0.5f, float dur = 0.4f, float freq = 15f)
        {
            Cues.Add(new ShakeCue { Time = time, Magnitude = mag,
                                     DurationSec = dur, FrequencyHz = freq });
            return this;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  FADE TRACK
    // ─────────────────────────────────────────────────────────────────────
    public class FadeTrack : CinematicTrack
    {
        public List<FloatKeyframe>  AlphaKeyframes { get; } = new();
        public Vector4              FadeColor      { get; set; } = Vector4.Zero; // black

        public override void OnBegin(CinematicDirector d) { }
        public override void OnEnd(CinematicDirector d)   { }

        public override void Sample(float t, CinematicDirector d)
        {
            if (Muted || AlphaKeyframes.Count == 0) return;
            float localT = t - StartAt;
            float alpha  = SampleAlpha(localT);
            d.SetFadeOverlay(new Vector4(FadeColor.X, FadeColor.Y, FadeColor.Z, alpha));
        }

        private float SampleAlpha(float lt)
        {
            if (AlphaKeyframes.Count == 1) return AlphaKeyframes[0].Value;
            for (int i = 0; i < AlphaKeyframes.Count - 1; i++)
            {
                if (lt <= AlphaKeyframes[i + 1].Time)
                {
                    float r = AlphaKeyframes[i + 1].Time - AlphaKeyframes[i].Time;
                    float a = r > 0f ? (lt - AlphaKeyframes[i].Time) / r : 1f;
                    return MathHelper.Lerp(AlphaKeyframes[i].Value, AlphaKeyframes[i + 1].Value,
                                           CinematicEaser.Evaluate(a, AlphaKeyframes[i + 1].Ease));
                }
            }
            return AlphaKeyframes[^1].Value;
        }

        public FadeTrack FadeIn(float fromTime, float toTime)  =>
            Key(fromTime, 1f).Key(toTime, 0f);
        public FadeTrack FadeOut(float fromTime, float toTime) =>
            Key(fromTime, 0f).Key(toTime, 1f);
        public FadeTrack Key(float time, float alpha, CinematicEase ease = CinematicEase.EaseInOut)
        {
            AlphaKeyframes.Add(new FloatKeyframe { Time = time, Value = alpha, Ease = ease });
            return this;
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  SEQUENCE  (a complete cinematic)
    // ─────────────────────────────────────────────────────────────────────
    public class CinematicSequence
    {
        public string               ID          { get; init; } = Guid.NewGuid().ToString("N")[..8];
        public string               Name        { get; init; } = "Cutscene";
        public float                Duration    { get; set; }  = 10f;
        public bool                 Skippable   { get; set; }  = true;
        public bool                 LockInput   { get; set; }  = true;
        public bool                 HideHUD     { get; set; }  = true;
        public List<CinematicTrack> Tracks      { get; }       = new();

        public event Action<CinematicSequence>? OnComplete;
        public event Action<CinematicSequence>? OnSkip;

        internal void NotifyComplete() => OnComplete?.Invoke(this);
        internal void NotifySkip()     => OnSkip?.Invoke(this);

        public T AddTrack<T>(T track) where T : CinematicTrack
        {
            Tracks.Add(track);
            Duration = Math.Max(Duration, track.EndAt);
            return track;
        }

        // ── Convenience builders ──────────────────────────────────────────
        public CameraTrack    AddCamera()   => AddTrack(new CameraTrack   { Name = "Camera" });
        public DialogueTrack  AddDialogue() => AddTrack(new DialogueTrack { Name = "Dialogue" });
        public EventTrack     AddEvents()   => AddTrack(new EventTrack    { Name = "Events" });
        public ShakeTrack     AddShakes()   => AddTrack(new ShakeTrack    { Name = "Camera Shake" });
        public FadeTrack      AddFade()     => AddTrack(new FadeTrack     { Name = "Fade" });
        public FloatParamTrack AddFloat(string name, Action<float> apply) =>
            AddTrack(new FloatParamTrack { Name = name, Apply = apply });
    }

    // ─────────────────────────────────────────────────────────────────────
    //  CINEMATIC DIRECTOR  (runtime player)
    // ─────────────────────────────────────────────────────────────────────
    public class CinematicDirector
    {
        // ── State ──────────────────────────────────────────────────────────
        public bool   IsPlaying   { get; private set; }
        public float  CurrentTime { get; private set; }
        public float  PlaybackRate{ get; set; } = 1f;
        public CinematicSequence? CurrentSequence { get; private set; }

        // ── Camera output ──────────────────────────────────────────────────
        public Vector3   CameraPosition { get; private set; }
        public Quaternion CameraRotation{ get; private set; }
        public float      CameraFOV     { get; private set; } = 60f;
        public bool       HasCameraOverride { get; private set; }
        public Vector4    FadeOverlay   { get; private set; } // RGBA

        // ── Events ─────────────────────────────────────────────────────────
        public event Action<DialogueCue>?  OnDialogueLine;
        public event Action<CinematicEvent>? OnEvent;
        public event Action<ShakeCue>?     OnShake;
        public event Action<bool>?         OnHUDToggle;   // true=hide
        public event Action<bool>?         OnInputLock;   // true=locked

        // ── Sequence registry ──────────────────────────────────────────────
        private readonly Dictionary<string, CinematicSequence> _sequences = new();

        public void RegisterSequence(CinematicSequence seq) =>
            _sequences[seq.ID] = seq;

        public bool TryGetSequence(string id, out CinematicSequence? seq) =>
            _sequences.TryGetValue(id, out seq);

        // ── Playback ───────────────────────────────────────────────────────
        public void Play(CinematicSequence sequence)
        {
            if (IsPlaying) Stop();
            CurrentSequence = sequence;
            CurrentTime     = 0f;
            IsPlaying       = true;

            if (sequence.LockInput) OnInputLock?.Invoke(true);
            if (sequence.HideHUD)   OnHUDToggle?.Invoke(true);

            foreach (var track in sequence.Tracks)
                track.OnBegin(this);
        }

        public void Play(string sequenceId)
        {
            if (_sequences.TryGetValue(sequenceId, out var seq))
                Play(seq);
        }

        public void Skip()
        {
            if (!IsPlaying || CurrentSequence == null) return;
            if (!CurrentSequence.Skippable) return;
            var seq = CurrentSequence;
            Stop();
            seq.NotifySkip();
        }

        public void Pause() => IsPlaying = false;
        public void Resume() { if (CurrentSequence != null) IsPlaying = true; }

        public void Stop()
        {
            if (CurrentSequence == null) return;
            foreach (var track in CurrentSequence.Tracks)
                track.OnEnd(this);

            if (CurrentSequence.LockInput) OnInputLock?.Invoke(false);
            if (CurrentSequence.HideHUD)   OnHUDToggle?.Invoke(false);
            HasCameraOverride = false;
            FadeOverlay       = Vector4.Zero;

            IsPlaying       = false;
            CurrentSequence = null;
            CurrentTime     = 0f;
        }

        public void Tick(float dt)
        {
            if (!IsPlaying || CurrentSequence == null) return;
            CurrentTime += dt * PlaybackRate;

            // Sample all active tracks
            foreach (var track in CurrentSequence.Tracks)
            {
                if (track.Muted) continue;
                if (CurrentTime >= track.StartAt && CurrentTime <= track.EndAt)
                    track.Sample(CurrentTime, this);
            }

            // End
            if (CurrentTime >= CurrentSequence.Duration)
            {
                var seq = CurrentSequence;
                Stop();
                seq.NotifyComplete();
            }
        }

        // ── Internal feed methods (called by tracks) ───────────────────────
        internal void SetCinematicCamera(Vector3 pos, Quaternion rot, float fov)
        {
            CameraPosition = pos;
            CameraRotation = rot;
            CameraFOV      = fov;
        }

        internal void NotifyCameraOverride(bool active) =>
            HasCameraOverride = active;

        internal void FireDialogueLine(DialogueCue cue) =>
            OnDialogueLine?.Invoke(cue);

        internal void FireEvent(CinematicEvent ev) =>
            OnEvent?.Invoke(ev);

        internal void FireShake(ShakeCue cue) =>
            OnShake?.Invoke(cue);

        internal void SetFadeOverlay(Vector4 rgba) =>
            FadeOverlay = rgba;

        // ── Async wrapper (await a sequence completion) ────────────────────
        public Task PlayAsync(CinematicSequence sequence)
        {
            var tcs = new TaskCompletionSource<bool>();
            sequence.OnComplete += _ => tcs.TrySetResult(true);
            sequence.OnSkip     += _ => tcs.TrySetResult(false);
            Play(sequence);
            return tcs.Task;
        }

        // ── Global director singleton ──────────────────────────────────────
        public static CinematicDirector Instance { get; } = new();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  CUTSCENE BUILDER  (fluent API for code-defined cutscenes)
    // ─────────────────────────────────────────────────────────────────────
    public class CutsceneBuilder
    {
        private readonly CinematicSequence _seq;

        public CutsceneBuilder(string name, float duration)
        {
            _seq = new CinematicSequence { Name = name, Duration = duration };
        }

        public static CutsceneBuilder Create(string name, float duration) =>
            new(name, duration);

        public CutsceneBuilder Camera(Action<CameraTrack> configure)
        {
            var track = _seq.AddCamera();
            configure(track);
            return this;
        }

        public CutsceneBuilder Dialogue(Action<DialogueTrack> configure)
        {
            var track = _seq.AddDialogue();
            configure(track);
            return this;
        }

        public CutsceneBuilder Events(Action<EventTrack> configure)
        {
            var track = _seq.AddEvents();
            configure(track);
            return this;
        }

        public CutsceneBuilder Fade(Action<FadeTrack> configure)
        {
            var track = _seq.AddFade();
            configure(track);
            return this;
        }

        public CutsceneBuilder Shakes(Action<ShakeTrack> configure)
        {
            var track = _seq.AddShakes();
            configure(track);
            return this;
        }

        public CutsceneBuilder Skippable(bool val = true)  { _seq.Skippable = val; return this; }
        public CutsceneBuilder LockInput(bool val = true)  { _seq.LockInput = val; return this; }
        public CutsceneBuilder HideHUD(bool val = true)    { _seq.HideHUD   = val; return this; }

        public CinematicSequence Build() => _seq;

        public void PlayNow() => CinematicDirector.Instance.Play(_seq);
    }
}
