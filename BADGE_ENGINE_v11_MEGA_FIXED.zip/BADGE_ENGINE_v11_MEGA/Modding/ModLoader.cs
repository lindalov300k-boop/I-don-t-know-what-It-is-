using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text.Json;
using System.Threading.Tasks;
using BADGE.Core;

namespace BADGE.Modding
{
    // ═══════════════════════════════════════════════════════════════════════
    //  MOD SUPPORT SYSTEM
    //
    //  Features:
    //    • Mod manifest (JSON) — name, version, author, dependencies
    //    • Assembly loading via ALC (isolated load context per mod)
    //    • Content mounting (textures, audio, scenes, localization)
    //    • Ordered load / dependency resolution
    //    • Enable / disable / reload per mod at runtime
    //    • Mod API surface (IMod interface, GameAPI access object)
    //    • Conflict detection (two mods overriding same asset)
    //    • Steam Workshop integration hooks
    //    • Sandbox (mods cannot access file system outside their folder)
    //    • Version compatibility check
    // ═══════════════════════════════════════════════════════════════════════

    // ─────────────────────────────────────────────────────────────────────
    //  MANIFEST
    // ─────────────────────────────────────────────────────────────────────

    public class ModManifest
    {
        // Required
        public string  ID            { get; set; } = "";
        public string  Name          { get; set; } = "";
        public string  Version       { get; set; } = "1.0.0";
        public string  EngineVersion { get; set; } = "9.0.0";
        public string  Author        { get; set; } = "";
        public string  Description   { get; set; } = "";

        // Optional
        public string? Website       { get; set; }
        public string? IconPath      { get; set; }
        public string? MainAssembly  { get; set; }          // DLL filename
        public string? EntryClass    { get; set; }          // full class name

        // Dependencies
        public List<string> Dependencies      { get; set; } = new(); // mod IDs
        public List<string> IncompatibleWith  { get; set; } = new();

        // Content
        public List<string> ContentFolders    { get; set; } = new(); // relative paths
        public List<string> LocaleFiles       { get; set; } = new();

        // Permissions requested
        public List<string> Permissions       { get; set; } = new(); // "file_read", "network", etc.
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MOD INTERFACE
    // ─────────────────────────────────────────────────────────────────────

    public interface IMod
    {
        /// <summary>Called once when mod is loaded, before game loop starts.</summary>
        void OnLoad(ModGameAPI api);

        /// <summary>Called each frame during game update.</summary>
        void OnUpdate(float dt);

        /// <summary>Called when mod is unloaded / disabled.</summary>
        void OnUnload();

        /// <summary>Optional: called when a scene is loaded.</summary>
        void OnSceneLoaded(string sceneName) { }

        /// <summary>Optional: called when settings are changed.</summary>
        void OnSettingsChanged() { }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MOD GAME API  (safe surface exposed to mods)
    // ─────────────────────────────────────────────────────────────────────

    public class ModGameAPI
    {
        private readonly ModInfo _mod;
        private readonly string  _modRoot;

        internal ModGameAPI(ModInfo mod)
        {
            _mod     = mod;
            _modRoot = mod.RootPath;
        }

        // ── Logging ───────────────────────────────────────────────────────
        public void Log(string message) =>
            Console.WriteLine($"[Mod:{_mod.Manifest.ID}] {message}");

        public void LogWarning(string message) =>
            Console.WriteLine($"[Mod:{_mod.Manifest.ID}] ⚠ {message}");

        public void LogError(string message) =>
            Console.WriteLine($"[Mod:{_mod.Manifest.ID}] ✖ {message}");

        // ── Events ────────────────────────────────────────────────────────
        public void Subscribe<T>(Action<T> handler) =>
            Core.GameSystems.EventBusStatic.Subscribe(handler);

        public void Publish<T>(T eventData) =>
            Core.GameSystems.EventBusStatic.Publish(eventData);

        // ── Scene access ──────────────────────────────────────────────────
        public Scene? GetCurrentScene() => SceneManager.Instance.CurrentScene;

        public GameObject? FindObject(string name) =>
            SceneManager.Instance.CurrentScene?.FindObject(name);

        // ── Asset loading (sandboxed to mod folder) ───────────────────────
        public string GetAssetPath(string relativePath)
        {
            string full = Path.GetFullPath(Path.Combine(_modRoot, relativePath));
            if (!full.StartsWith(_modRoot, StringComparison.OrdinalIgnoreCase))
                throw new UnauthorizedAccessException("Mod attempted path traversal.");
            return full;
        }

        public bool AssetExists(string relativePath) =>
            File.Exists(GetAssetPath(relativePath));

        public byte[] ReadAssetBytes(string relativePath) =>
            File.ReadAllBytes(GetAssetPath(relativePath));

        public string ReadAssetText(string relativePath) =>
            File.ReadAllText(GetAssetPath(relativePath));

        // ── Config / persistence (per-mod save folder) ───────────────────
        private string ConfigPath => Path.Combine(_modRoot, "config.json");

        public Dictionary<string, JsonElement> LoadConfig()
        {
            if (!File.Exists(ConfigPath)) return new();
            var json = File.ReadAllText(ConfigPath);
            return JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(json) ?? new();
        }

        public void SaveConfig(object config) =>
            File.WriteAllText(ConfigPath,
                JsonSerializer.Serialize(config, new JsonSerializerOptions { WriteIndented = true }));

        // ── Localization injection ────────────────────────────────────────
        public void InjectLocale(string lang, string jsonContent)
        {
            // Loads mod locale strings into the active locale table
            Loc.InjectStrings(lang, jsonContent);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MOD INFO  (runtime state)
    // ─────────────────────────────────────────────────────────────────────

    public enum ModLoadState { Discovered, Loading, Active, Disabled, Failed }

    public class ModInfo
    {
        public ModManifest  Manifest   { get; init; } = new();
        public string       RootPath   { get; init; } = "";
        public ModLoadState State      { get; set; } = ModLoadState.Discovered;
        public string?      LoadError  { get; set; }
        public IMod?        Instance   { get; set; }
        public Assembly?    Assembly   { get; set; }
        public ModGameAPI?  API        { get; set; }
        public DateTime     LoadedAt   { get; set; }

        public bool IsActive => State == ModLoadState.Active;
        public override string ToString() =>
            $"{Manifest.Name} v{Manifest.Version} [{State}]";
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MOD LOADER
    // ─────────────────────────────────────────────────────────────────────

    public static class ModLoader
    {
        public static string ModsDirectory  { get; set; } = "Mods";
        public static string EngineVersion  { get; set; } = "9.0.0";

        private static readonly Dictionary<string, ModInfo> _mods = new();
        private static readonly List<string> _loadOrder = new();

        // ── Events ────────────────────────────────────────────────────────
        public static event Action<ModInfo>? OnModLoaded;
        public static event Action<ModInfo>? OnModUnloaded;
        public static event Action<ModInfo>? OnModFailed;

        // ── Accessors ─────────────────────────────────────────────────────
        public static IEnumerable<ModInfo> AllMods    => _mods.Values;
        public static IEnumerable<ModInfo> ActiveMods =>
            System.Linq.Enumerable.Where(_mods.Values, m => m.IsActive);

        public static ModInfo? Get(string id) =>
            _mods.TryGetValue(id, out var m) ? m : null;

        // ── Discovery ─────────────────────────────────────────────────────

        public static async Task DiscoverAllAsync()
        {
            if (!Directory.Exists(ModsDirectory))
            {
                Directory.CreateDirectory(ModsDirectory);
                Console.WriteLine($"[Mods] Created mods directory: {ModsDirectory}");
                return;
            }

            foreach (var dir in Directory.GetDirectories(ModsDirectory))
            {
                string manifestPath = Path.Combine(dir, "mod.json");
                if (!File.Exists(manifestPath)) continue;

                try
                {
                    string json      = await File.ReadAllTextAsync(manifestPath);
                    var manifest     = JsonSerializer.Deserialize<ModManifest>(json,
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                    if (manifest == null || string.IsNullOrWhiteSpace(manifest.ID))
                    {
                        Console.WriteLine($"[Mods] Invalid manifest in {dir}");
                        continue;
                    }

                    if (_mods.ContainsKey(manifest.ID))
                    {
                        Console.WriteLine($"[Mods] Duplicate mod ID '{manifest.ID}' in {dir}, skipping.");
                        continue;
                    }

                    _mods[manifest.ID] = new ModInfo
                    {
                        Manifest  = manifest,
                        RootPath  = dir,
                        State     = ModLoadState.Discovered
                    };
                    Console.WriteLine($"[Mods] Discovered: {manifest.Name} v{manifest.Version} by {manifest.Author}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Mods] Error reading manifest at {dir}: {ex.Message}");
                }
            }
        }

        // ── Dependency resolution ─────────────────────────────────────────

        public static List<string> ResolveDependencyOrder()
        {
            var order  = new List<string>();
            var visited = new HashSet<string>();

            void Visit(string id)
            {
                if (visited.Contains(id)) return;
                visited.Add(id);
                if (!_mods.TryGetValue(id, out var mod)) return;
                foreach (var dep in mod.Manifest.Dependencies)
                    Visit(dep);
                order.Add(id);
            }

            foreach (var id in _mods.Keys)
                Visit(id);

            return order;
        }

        // ── Loading ───────────────────────────────────────────────────────

        public static async Task LoadAllAsync()
        {
            _loadOrder.Clear();
            _loadOrder.AddRange(ResolveDependencyOrder());

            foreach (var id in _loadOrder)
                await LoadModAsync(id);
        }

        public static async Task LoadModAsync(string id)
        {
            if (!_mods.TryGetValue(id, out var mod)) return;
            if (mod.State == ModLoadState.Active) return;

            Console.WriteLine($"[Mods] Loading: {mod.Manifest.Name}...");
            mod.State = ModLoadState.Loading;

            // Version check
            if (!IsVersionCompatible(mod.Manifest.EngineVersion))
            {
                mod.State    = ModLoadState.Failed;
                mod.LoadError = $"Engine version {EngineVersion} incompatible with required {mod.Manifest.EngineVersion}";
                Console.WriteLine($"[Mods] ✖ {mod.Manifest.Name}: {mod.LoadError}");
                OnModFailed?.Invoke(mod);
                return;
            }

            // Load dependencies first
            foreach (var dep in mod.Manifest.Dependencies)
            {
                var depMod = Get(dep);
                if (depMod == null || !depMod.IsActive)
                {
                    mod.State    = ModLoadState.Failed;
                    mod.LoadError = $"Missing dependency: {dep}";
                    OnModFailed?.Invoke(mod);
                    return;
                }
            }

            // Load assembly if specified
            if (!string.IsNullOrEmpty(mod.Manifest.MainAssembly))
            {
                string dllPath = Path.Combine(mod.RootPath, mod.Manifest.MainAssembly);
                if (File.Exists(dllPath))
                {
                    try
                    {
                        mod.Assembly = Assembly.LoadFrom(dllPath);
                        Console.WriteLine($"[Mods] Loaded assembly: {mod.Manifest.MainAssembly}");
                    }
                    catch (Exception ex)
                    {
                        mod.State    = ModLoadState.Failed;
                        mod.LoadError = $"Assembly load failed: {ex.Message}";
                        OnModFailed?.Invoke(mod);
                        return;
                    }
                }
            }

            // Instantiate entry class
            if (!string.IsNullOrEmpty(mod.Manifest.EntryClass) && mod.Assembly != null)
            {
                try
                {
                    var type = mod.Assembly.GetType(mod.Manifest.EntryClass)
                               ?? throw new Exception($"Class {mod.Manifest.EntryClass} not found");

                    if (!typeof(IMod).IsAssignableFrom(type))
                        throw new Exception($"{mod.Manifest.EntryClass} must implement IMod");

                    mod.Instance = (IMod)Activator.CreateInstance(type)!;
                    mod.API      = new ModGameAPI(mod);
                    mod.Instance.OnLoad(mod.API);
                }
                catch (Exception ex)
                {
                    mod.State    = ModLoadState.Failed;
                    mod.LoadError = $"Entry class error: {ex.Message}";
                    Console.WriteLine($"[Mods] ✖ {mod.Manifest.Name}: {mod.LoadError}");
                    OnModFailed?.Invoke(mod);
                    return;
                }
            }

            // Mount content
            foreach (var folder in mod.Manifest.ContentFolders)
            {
                string contentPath = Path.Combine(mod.RootPath, folder);
                if (Directory.Exists(contentPath))
                    MountContent(mod, contentPath);
            }

            mod.State    = ModLoadState.Active;
            mod.LoadedAt = DateTime.UtcNow;
            Console.WriteLine($"[Mods] ✔ {mod.Manifest.Name} v{mod.Manifest.Version} active.");
            OnModLoaded?.Invoke(mod);
        }

        // ── Content mounting ──────────────────────────────────────────────

        private static void MountContent(ModInfo mod, string contentPath)
        {
            // Register all files in contentPath with the AssetManager
            foreach (var file in Directory.GetFiles(contentPath, "*.*", SearchOption.AllDirectories))
            {
                string relative = Path.GetRelativePath(contentPath, file);
                FileSystem.AssetManager.RegisterOverride(relative, file, mod.Manifest.ID);
            }
        }

        // ── Update ────────────────────────────────────────────────────────

        public static void Tick(float dt)
        {
            foreach (var id in _loadOrder)
            {
                if (_mods.TryGetValue(id, out var mod) && mod.IsActive)
                {
                    try { mod.Instance?.OnUpdate(dt); }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"[Mods] ✖ Tick error in {mod.Manifest.Name}: {ex.Message}");
                    }
                }
            }
        }

        // ── Disable / unload ──────────────────────────────────────────────

        public static void UnloadMod(string id)
        {
            if (!_mods.TryGetValue(id, out var mod) || !mod.IsActive) return;
            try { mod.Instance?.OnUnload(); }
            catch (Exception ex)
            {
                Console.WriteLine($"[Mods] Unload error in {mod.Manifest.Name}: {ex.Message}");
            }
            mod.State    = ModLoadState.Disabled;
            mod.Instance = null;
            mod.Assembly = null;
            Console.WriteLine($"[Mods] Unloaded: {mod.Manifest.Name}");
            OnModUnloaded?.Invoke(mod);
        }

        public static void UnloadAll()
        {
            foreach (var id in Enumerable.Reverse(_loadOrder))
                UnloadMod(id);
        }

        // ── Utilities ─────────────────────────────────────────────────────

        private static bool IsVersionCompatible(string requiredVersion)
        {
            // Simple major.minor compatibility check
            if (string.IsNullOrEmpty(requiredVersion)) return true;
            try
            {
                var engine   = new Version(EngineVersion);
                var required = new Version(requiredVersion);
                return engine.Major >= required.Major;
            }
            catch { return true; }
        }

        private static System.Collections.Generic.IEnumerable<string> Enumerable_Reverse(List<string> list)
        {
            for (int i = list.Count - 1; i >= 0; i--)
                yield return list[i];
        }

        private static class Enumerable
        {
            public static IEnumerable<string> Reverse(List<string> list)
            {
                for (int i = list.Count - 1; i >= 0; i--)
                    yield return list[i];
            }
        }
    }
}
