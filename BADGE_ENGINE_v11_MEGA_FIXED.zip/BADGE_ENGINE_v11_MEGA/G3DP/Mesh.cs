using System;
using System.Collections.Generic;
using BADGE.Core;
namespace BADGE.G3DP
{
    /// <summary>
    /// Core mesh data class.
    ///
    /// UPGRADED: Added SetVertices/SetNormals/SetUVs/SetTriangles array setters,
    /// RecalculateBounds, Name property, and ToArray accessors so both
    /// old List-style code and new array-style code (PrimitiveMesh, ProceduralMaze)
    /// compile against the same type.
    /// </summary>
    public class Mesh
    {
        public string Name { get; set; } = "Mesh";

        // ── Internal storage (arrays for GL upload speed) ─────────
        private Vector3[] _vertices  = Array.Empty<Vector3>();
        private int[]     _triangles = Array.Empty<int>();
        private Vector2[] _uvs       = Array.Empty<Vector2>();
        private Vector3[] _normals   = Array.Empty<Vector3>();

        // ── List-style accessors (legacy compat) ──────────────────
        public List<Vector3> Vertices  { get => new(_vertices);  set => _vertices  = value.ToArray(); }
        public List<int>     Triangles { get => new(_triangles); set => _triangles = value.ToArray(); }
        public List<Vector2> UVs       { get => new(_uvs);       set => _uvs       = value.ToArray(); }
        public List<Vector3> Normals   { get => new(_normals);   set => _normals   = value.ToArray(); }

        // ── Array setters (new API) ───────────────────────────────
        public void SetVertices(Vector3[] verts)  => _vertices  = verts;
        public void SetTriangles(int[] tris)      => _triangles = tris;
        public void SetUVs(Vector2[] uvs)         => _uvs       = uvs;
        public void SetNormals(Vector3[] normals) => _normals   = normals;

        // ── Array getters ─────────────────────────────────────────
        public Vector3[] GetVertices()  => _vertices;
        public int[]     GetTriangles() => _triangles;
        public Vector2[] GetUVs()       => _uvs;
        public Vector3[] GetNormals()   => _normals;

        public int VertexCount   => _vertices.Length;
        public int TriangleCount => _triangles.Length / 3;

        // ── Bounds ────────────────────────────────────────────────
        public Vector3 BoundsCenter { get; private set; }
        public Vector3 BoundsExtents { get; private set; }

        public void RecalculateBounds()
        {
            if (_vertices.Length == 0) return;
            var min = _vertices[0]; var max = _vertices[0];
            foreach (var v in _vertices)
            {
                min = new Vector3(Math.Min(min.X, v.X), Math.Min(min.Y, v.Y), Math.Min(min.Z, v.Z));
                max = new Vector3(Math.Max(max.X, v.X), Math.Max(max.Y, v.Y), Math.Max(max.Z, v.Z));
            }
            BoundsCenter  = (min + max) * 0.5f;
            BoundsExtents = (max - min) * 0.5f;
        }

        // ── Normal recalculation ──────────────────────────────────
        public void RecalculateNormals()
        {
            _normals = new Vector3[_vertices.Length];
            for (int i = 0; i < _triangles.Length; i += 3)
            {
                int i0 = _triangles[i], i1 = _triangles[i+1], i2 = _triangles[i+2];
                if (i0 >= _vertices.Length || i1 >= _vertices.Length || i2 >= _vertices.Length) continue;
                var edge1  = _vertices[i1] - _vertices[i0];
                var edge2  = _vertices[i2] - _vertices[i0];
                var normal = Vector3.Cross(edge1, edge2).Normalized();
                _normals[i0] += normal;
                _normals[i1] += normal;
                _normals[i2] += normal;
            }
            for (int i = 0; i < _normals.Length; i++)
                if (_normals[i].LengthSquared > 0.0001f)
                    _normals[i] = _normals[i].Normalized();
        }

        // ── Factory methods ───────────────────────────────────────
        public static Mesh CreateCube(float size = 1.0f)
        {
            var m = new Mesh { Name = "Cube" };
            float h = size / 2;
            m.SetVertices(new[] {
                new Vector3(-h,-h,-h), new Vector3(h,-h,-h), new Vector3(h,h,-h), new Vector3(-h,h,-h),
                new Vector3(-h,-h, h), new Vector3(h,-h, h), new Vector3(h,h, h), new Vector3(-h,h, h)
            });
            m.SetTriangles(new[] { 0,2,1, 0,3,2, 1,6,5, 1,2,6, 5,7,4, 5,6,7, 4,3,0, 4,7,3, 3,6,2, 3,7,6, 4,1,5, 4,0,1 });
            m.RecalculateNormals();
            return m;
        }
    }

    // ── Static factory methods used by StarterAssets ─────────────────────
    public static class PrimitiveMeshes
    {
        public static Mesh CreateCube(float size = 1f)      => Mesh.CreateCube(size);
        public static Mesh CreateSphere(float r, int lat, int lon)
        {
            var m = new Mesh();
            var pos = new System.Collections.Generic.List<OpenTK.Mathematics.Vector3>();
            var uv  = new System.Collections.Generic.List<OpenTK.Mathematics.Vector2>();
            var idx = new System.Collections.Generic.List<int>();

            for (int i = 0; i <= lat; i++)
            {
                float phi = MathF.PI * i / lat;
                for (int j = 0; j <= lon; j++)
                {
                    float theta = 2f * MathF.PI * j / lon;
                    pos.Add(new OpenTK.Mathematics.Vector3(
                        r * MathF.Sin(phi) * MathF.Cos(theta),
                        r * MathF.Cos(phi),
                        r * MathF.Sin(phi) * MathF.Sin(theta)));
                    uv.Add(new OpenTK.Mathematics.Vector2((float)j / lon, (float)i / lat));
                }
            }
            for (int i = 0; i < lat; i++)
            for (int j = 0; j < lon; j++)
            {
                int a = i * (lon + 1) + j, b = a + lon + 1;
                idx.Add(a); idx.Add(b);   idx.Add(a + 1);
                idx.Add(a + 1); idx.Add(b); idx.Add(b + 1);
            }
            m.SetVertices(pos.ToArray());
            m.SetUVs(uv.ToArray());
            m.SetTriangles(idx.ToArray());
            m.RecalculateNormals();
            return m;
        }

        public static Mesh CreateCapsule(float radius, float height, int segments)
            => BADGE.Core.RenderingComponents.CreateCapsuleMesh(radius, height, segments);
        public static Mesh CreateCylinder(float radius, float height, int segments)
            => BADGE.Core.RenderingComponents.CreateCylinderMesh(radius, height, segments);
        public static Mesh CreatePlane(float width, float depth, int segW, int segD)
        {
            var m   = new Mesh();
            int vw  = segW + 1, vd = segD + 1;
            var pos = new OpenTK.Mathematics.Vector3[vw * vd];
            var uvs = new OpenTK.Mathematics.Vector2[vw * vd];
            for (int z = 0; z < vd; z++)
            for (int x = 0; x < vw; x++)
            {
                int i = z * vw + x;
                pos[i] = new OpenTK.Mathematics.Vector3(x * (width / segW) - width * 0.5f,
                                                         0,
                                                         z * (depth / segD) - depth * 0.5f);
                uvs[i] = new OpenTK.Mathematics.Vector2((float)x / segW, (float)z / segD);
            }
            var idx = new System.Collections.Generic.List<int>();
            for (int z = 0; z < segD; z++)
            for (int x = 0; x < segW; x++)
            {
                int tl = z * vw + x;
                idx.Add(tl); idx.Add(tl + vw); idx.Add(tl + 1);
                idx.Add(tl + 1); idx.Add(tl + vw); idx.Add(tl + vw + 1);
            }
            m.SetVertices(pos); m.SetUVs(uvs); m.SetTriangles(idx.ToArray());
            m.RecalculateNormals();
            return m;
        }

        public static Mesh CreateIcoSphere(float radius, int subdivisions)
        {
            // Start from icosahedron and subdivide
            var mesh = CreateIcosahedron(radius);
            for (int i = 0; i < subdivisions; i++)
                mesh = BADGE.G3DP.MeshFilterStack.Subdivide(mesh);
            // Project onto sphere
            var verts = mesh.GetVertices();
            for (int i = 0; i < verts.Length; i++)
                verts[i] = OpenTK.Mathematics.Vector3.Normalize(verts[i]) * radius;
            mesh.SetVertices(verts);
            mesh.RecalculateNormals();
            return mesh;
        }

        private static Mesh CreateIcosahedron(float r)
        {
            float t = (1f + MathF.Sqrt(5f)) / 2f;
            var v = new OpenTK.Mathematics.Vector3[]
            {
                N(-1,  t, 0)*r, N( 1,  t, 0)*r, N(-1, -t, 0)*r, N( 1, -t, 0)*r,
                N( 0, -1, t)*r, N( 0,  1, t)*r, N( 0, -1,-t)*r, N( 0,  1,-t)*r,
                N( t,  0,-1)*r, N( t,  0, 1)*r, N(-t,  0,-1)*r, N(-t,  0, 1)*r,
            };
            var idx = new[]
            {
                0,11,5, 0,5,1, 0,1,7, 0,7,10, 0,10,11,
                1,5,9,  5,11,4, 11,10,2, 10,7,6, 7,1,8,
                3,9,4,  3,4,2, 3,2,6, 3,6,8, 3,8,9,
                4,9,5,  2,4,11, 6,2,10, 8,6,7, 9,8,1
            };
            var m = new Mesh();
            m.SetVertices(v); m.SetTriangles(idx); m.RecalculateNormals();
            return m;
        }
        private static OpenTK.Mathematics.Vector3 N(float x, float y, float z)
            => OpenTK.Mathematics.Vector3.Normalize(new OpenTK.Mathematics.Vector3(x, y, z));

        public static Mesh CreateTorus(float outerR, float innerR, int segsOuter, int segsInner)
        {
            var pos = new System.Collections.Generic.List<OpenTK.Mathematics.Vector3>();
            var uvs = new System.Collections.Generic.List<OpenTK.Mathematics.Vector2>();
            var idx = new System.Collections.Generic.List<int>();

            for (int i = 0; i <= segsOuter; i++)
            {
                float u    = 2 * MathF.PI * i / segsOuter;
                float cosU = MathF.Cos(u), sinU = MathF.Sin(u);
                for (int j = 0; j <= segsInner; j++)
                {
                    float v    = 2 * MathF.PI * j / segsInner;
                    float cosV = MathF.Cos(v), sinV = MathF.Sin(v);
                    float r    = outerR + innerR * cosV;
                    pos.Add(new OpenTK.Mathematics.Vector3(r * cosU, innerR * sinV, r * sinU));
                    uvs.Add(new OpenTK.Mathematics.Vector2((float)i / segsOuter, (float)j / segsInner));
                }
            }
            int ring = segsInner + 1;
            for (int i = 0; i < segsOuter; i++)
            for (int j = 0; j < segsInner; j++)
            {
                int a = i * ring + j;
                idx.Add(a); idx.Add(a + ring); idx.Add(a + 1);
                idx.Add(a + 1); idx.Add(a + ring); idx.Add(a + ring + 1);
            }
            var m = new Mesh();
            m.SetVertices(pos.ToArray()); m.SetUVs(uvs.ToArray());
            m.SetTriangles(idx.ToArray()); m.RecalculateNormals();
            return m;
        }

        public static Mesh CreatePyramid(float baseSize, float height)
        {
            float h = baseSize * 0.5f;
            var v = new OpenTK.Mathematics.Vector3[]
            {
                new(-h, 0,  h), new( h, 0,  h),
                new( h, 0, -h), new(-h, 0, -h),
                new( 0, height, 0)
            };
            var idx = new[] { 0,1,4, 1,2,4, 2,3,4, 3,0,4, 0,2,1, 0,3,2 };
            var m = new Mesh();
            m.SetVertices(v); m.SetTriangles(idx); m.RecalculateNormals();
            return m;
        }

        public static Mesh CreateDiamond(float width, float height)
        {
            float h = width * 0.5f, topH = height * 0.6f, botH = height * 0.4f;
            var v = new OpenTK.Mathematics.Vector3[]
            {
                new(0,  topH, 0),
                new(-h, 0,  h), new( h, 0,  h),
                new( h, 0, -h), new(-h, 0, -h),
                new(0, -botH, 0)
            };
            var idx = new[] { 0,1,2, 0,2,3, 0,3,4, 0,4,1, 5,2,1, 5,3,2, 5,4,3, 5,1,4 };
            var m = new Mesh();
            m.SetVertices(v); m.SetTriangles(idx); m.RecalculateNormals();
            return m;
        }
    }
}
