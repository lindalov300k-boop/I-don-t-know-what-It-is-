using System;
using OpenTK.Mathematics;

namespace BADGE.Physics.Vehicle;

// ═══════════════════════════════════════════════════════════════════════
//  VEHICLE PHYSICS
//  GTA SA: cars, bikes, trucks, boats
//  Simulators: driving, farming, racing
//  Payback: top-down but uses the same wheel torque model
// ═══════════════════════════════════════════════════════════════════════

public class VehicleController : Core.Component
{
    // ── Spec ──────────────────────────────────────────────────────
    public float MaxEngineTorque   { get; set; } = 1200f;  // N·m
    public float MaxSpeed          { get; set; } = 40f;    // m/s (~144 km/h)
    public float BrakeForce        { get; set; } = 3000f;
    public float HandbrakeForce    { get; set; } = 5000f;
    public float MaxSteerAngle     { get; set; } = 35f;    // degrees
    public float SteerSpeed        { get; set; } = 180f;   // degrees/sec
    public float Mass              { get; set; } = 1400f;  // kg
    public float GravityScale      { get; set; } = 1f;
    public float AeroDrag          { get; set; } = 0.35f;
    public float RollingResistance { get; set; } = 0.015f;
    public float WheelBase         { get; set; } = 2.8f;   // metres

    // ── Runtime state ─────────────────────────────────────────────
    public Vector3 Velocity        { get; private set; } = Vector3.Zero;
    public float   AngularVelocity { get; private set; } = 0f;
    public float   Speed           => Velocity.Length;
    public float   CurrentGear     { get; private set; } = 1;
    public float   RPM             { get; private set; } = 800f;
    public bool    IsGrounded      { get; private set; } = true;
    public bool    IsDrifting      { get; private set; } = false;
    public float   SteerAngle      { get; private set; } = 0f;

    // ── Wheel data ────────────────────────────────────────────────
    private readonly Wheel[] _wheels = new Wheel[4];
    public  Wheel FrontLeft  => _wheels[0];
    public  Wheel FrontRight => _wheels[1];
    public  Wheel RearLeft   => _wheels[2];
    public  Wheel RearRight  => _wheels[3];

    // ── Gear ratios (GTA-style 6-speed + reverse) ─────────────────
    private static readonly float[] GearRatios = { -3.5f, 0f, 3.36f, 1.94f, 1.28f, 0.92f, 0.71f };
    // Index: 0=reverse, 1=neutral, 2=1st ... 6=6th

    // ── Input (set by controller code) ───────────────────────────
    public float ThrottleInput { get; set; } = 0f;  // 0..1
    public float BrakeInput    { get; set; } = 0f;  // 0..1
    public float SteerInput    { get; set; } = 0f;  // -1..1
    public bool  HandbrakeOn   { get; set; } = false;
    public bool  ReverseGear   { get; set; } = false;

    public VehicleController()
    {
        for (int i = 0; i < 4; i++)
            _wheels[i] = new Wheel
            {
                IsFront    = i < 2,
                IsDriving  = i >= 2,  // rear-wheel drive by default
                Offset     = i switch
                {
                    0 => new Vector3(-0.85f, -0.4f,  1.3f),
                    1 => new Vector3( 0.85f, -0.4f,  1.3f),
                    2 => new Vector3(-0.85f, -0.4f, -1.3f),
                    _ => new Vector3( 0.85f, -0.4f, -1.3f)
                }
            };
    }

    public override void Update(float dt)
    {
        if (Transform == null) return;

        // ── Steering ──────────────────────────────────────────────
        float targetSteer = SteerInput * MaxSteerAngle;
        // Reduce steer at high speed (stability)
        float speedFactor = 1f - Math.Clamp(Speed / MaxSpeed, 0f, 0.7f);
        targetSteer *= speedFactor;
        float steerDelta = SteerSpeed * dt;
        SteerAngle = MathHelper.Lerp(SteerAngle, targetSteer, Math.Min(1f, steerDelta / MathF.Max(1f, MathF.Abs(targetSteer - SteerAngle))));
        _wheels[0].SteerAngle = SteerAngle;
        _wheels[1].SteerAngle = SteerAngle;

        // ── Engine torque ─────────────────────────────────────────
        int gearIdx  = ReverseGear ? 0 : (int)Math.Clamp(CurrentGear + 1, 2, 6);
        float ratio  = GearRatios[gearIdx];
        float torque = ThrottleInput * MaxEngineTorque * ratio;

        // ── Drivetrain → wheel forces ─────────────────────────────
        var forward = Transform.Forward;
        forward.Y = 0; if (forward.LengthSquared > 0.0001f) forward = forward.Normalized();

        float driveForce = 0f;
        int   driveWheels = 0;
        foreach (var w in _wheels)
        {
            if (!w.IsDriving) continue;
            float slip  = CalcLongSlip(w, dt);
            float tireF = TireForce(slip) * w.NormalForce;
            driveForce += tireF;
            driveWheels++;
        }
        if (driveWheels > 0) driveForce /= driveWheels;
        driveForce *= MathF.Sign(torque) * Math.Abs(torque) / MaxEngineTorque;

        // ── Braking ───────────────────────────────────────────────
        float brakeForce = (HandbrakeOn ? HandbrakeForce : BrakeForce) * BrakeInput;
        float brakeAcc   = brakeForce / Mass;
        if (Speed > 0.1f) driveForce -= brakeAcc * MathF.Sign(Vector3.Dot(Velocity, forward));

        // ── Aero drag + rolling resistance ────────────────────────
        float drag = (AeroDrag * Speed * Speed + RollingResistance * Mass * 9.81f);
        if (Speed > 0.01f) driveForce -= drag / Mass * MathF.Sign(Vector3.Dot(Velocity, forward));

        // ── Integrate ─────────────────────────────────────────────
        var acceleration = forward * (driveForce / Mass);
        if (IsGrounded) Velocity += acceleration * dt;
        Velocity -= new Vector3(Velocity.X, 0, Velocity.Z) * (RollingResistance * dt);

        // Clamp speed
        if (Speed > MaxSpeed) Velocity = Velocity.Normalized() * MaxSpeed;

        // ── Lateral grip (prevents infinite sliding) ──────────────
        var right = Transform.Right; right.Y = 0;
        if (right.LengthSquared > 0.0001f) right = right.Normalized();
        float lateralVel = Vector3.Dot(Velocity, right);
        float gripForce  = HandbrakeOn ? 0.3f : 0.85f;
        Velocity -= right * lateralVel * (1f - gripForce) * Math.Min(1f, dt * 10f);

        IsDrifting = MathF.Abs(lateralVel) > 2f;

        // ── Yaw from steering ─────────────────────────────────────
        if (Speed > 0.5f)
        {
            float turnRadius = WheelBase / MathF.Max(0.01f, MathF.Tan(MathHelper.DegreesToRadians(MathF.Abs(SteerAngle))));
            float yawRate    = Speed / turnRadius * MathF.Sign(SteerAngle);
            AngularVelocity  = MathHelper.Lerp(AngularVelocity, yawRate, Math.Min(1f, dt * 5f));
        }
        else AngularVelocity = MathHelper.Lerp(AngularVelocity, 0f, dt * 10f);

        // ── Apply to transform ────────────────────────────────────
        Transform.Position += Velocity * dt;
        var euler = Transform.LocalEulerAngles;
        Transform.LocalEulerAngles = new Vector3(euler.X, euler.Y + MathHelper.RadiansToDegrees(AngularVelocity * dt), euler.Z);

        // ── Update wheels visual spin ─────────────────────────────
        foreach (var w in _wheels)
        {
            w.SpinAngle += Speed / w.Radius * MathHelper.RadiansToDegrees(dt) * (ReverseGear ? -1f : 1f);
            w.NormalForce = Mass * 9.81f * GravityScale / 4f;  // even weight dist (simplified)
        }

        // ── Auto gear shift ───────────────────────────────────────
        float speedNorm = Speed / MaxSpeed;
        if      (speedNorm < 0.15f) CurrentGear = 1;
        else if (speedNorm < 0.30f) CurrentGear = 2;
        else if (speedNorm < 0.50f) CurrentGear = 3;
        else if (speedNorm < 0.70f) CurrentGear = 4;
        else if (speedNorm < 0.88f) CurrentGear = 5;
        else                        CurrentGear = 6;

        RPM = 800f + (Speed / MaxSpeed) * 6500f;
    }

    // ── Tire model (simplified Pacejka) ──────────────────────────
    private static float TireForce(float slip)
    {
        float B = 10f, C = 1.9f, D = 1f, E = 0.97f;
        return D * MathF.Sin(C * MathF.Atan(B * slip - E * (B * slip - MathF.Atan(B * slip))));
    }

    private static float CalcLongSlip(Wheel w, float dt)
        => Math.Clamp((w.SpinSpeed - w.GroundSpeed) / MathF.Max(0.1f, MathF.Abs(w.GroundSpeed)), -1f, 1f);
}

public class Wheel
{
    public Vector3 Offset      { get; set; }
    public bool    IsFront     { get; set; }
    public bool    IsDriving   { get; set; }
    public float   Radius      { get; set; } = 0.35f;
    public float   SteerAngle  { get; set; } = 0f;
    public float   SpinAngle   { get; set; } = 0f;    // visual
    public float   SpinSpeed   { get; set; } = 0f;    // rad/s
    public float   GroundSpeed { get; set; } = 0f;
    public float   NormalForce { get; set; } = 3430f;  // N (350kg / wheel)
    public bool    IsGrounded  { get; set; } = true;
}
