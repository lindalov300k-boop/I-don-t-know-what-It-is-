using System;
using System.Collections.Generic;
using OpenTK.Graphics.OpenGL4;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Rendering
{
    /// <summary>
    /// Advanced 2D rendering features:
    /// sprite atlasing, 2D normal-map lighting, pixel-perfect rendering,
    /// parallax scrolling, auto-tiling, 2D skeletal animation support.
    /// </summary>
    public static class Advanced2D
    {
        // ── Sprite Atlas ──────────────────────────────────────────────────
        /// <summary>
        /// Packs multiple texture regions into a single atlas texture.
        /// Returns UV rectangles for each sprite.
        /// </summary>
        public class SpriteAtlas
        {
            public int TextureHandle   { get; private set; }
            public int AtlasWidth      { get; }
            public int AtlasHeight     { get; }

            private readonly List<AtlasEntry> _entries = new();
            private int _cursorX, _cursorY, _rowHeight;

            public SpriteAtlas(int width = 2048, int height = 2048)
            {
                AtlasWidth = width; AtlasHeight = height;
                TextureHandle = GL.GenTexture();
                GL.BindTexture(TextureTarget.Texture2D, TextureHandle);
                GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba8,
                              width, height, 0, PixelFormat.Rgba, PixelType.UnsignedByte, IntPtr.Zero);
                GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Nearest);
                GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Nearest);
                GL.BindTexture(TextureTarget.Texture2D, 0);
            }

            /// <summary>Pack a sprite into the atlas; returns its UV rect.</summary>
            public Box2 Pack(byte[] rgba, int w, int h, string name)
            {
                if (_cursorX + w > AtlasWidth) { _cursorX = 0; _cursorY += _rowHeight; _rowHeight = 0; }

                GL.BindTexture(TextureTarget.Texture2D, TextureHandle);
                GL.TexSubImage2D(TextureTarget.Texture2D, 0,
                                 _cursorX, _cursorY, w, h,
                                 PixelFormat.Rgba, PixelType.UnsignedByte, rgba);
                GL.BindTexture(TextureTarget.Texture2D, 0);

                var uv = new Box2(
                    (float)_cursorX / AtlasWidth,
                    (float)_cursorY / AtlasHeight,
                    (float)(_cursorX + w) / AtlasWidth,
                    (float)(_cursorY + h) / AtlasHeight);

                _entries.Add(new AtlasEntry(name, uv));
                _cursorX += w;
                _rowHeight = Math.Max(_rowHeight, h);
                return uv;
            }

            public Box2? GetUV(string name)
            {
                foreach (var e in _entries)
                    if (e.Name == name) return e.UV;
                return null;
            }

            private record AtlasEntry(string Name, Box2 UV);
        }

        // ── 2D Normal-map lighting ────────────────────────────────────────
        public class Light2D : Component
        {
            public Vector2 WorldPosition { get; set; }
            public OpenTK.Mathematics.Color4 Color     { get; set; } = OpenTK.Mathematics.Color4.White;
            public float   Radius        { get; set; } = 200f;
            public float   Intensity     { get; set; } = 1f;
        }

        /// <summary>Collect all active 2D lights from the scene.</summary>
        public static List<Light2D> GetActiveLights(Scene scene)
            => scene.FindAllComponents<Light2D>();

        // ── Pixel-perfect rendering ───────────────────────────────────────
        /// <summary>
        /// Round a world position to the nearest pixel grid.
        /// Prevents sub-pixel jitter on low-resolution sprites.
        /// </summary>
        public static Vector2 SnapToPixel(Vector2 worldPos, float pixelsPerUnit = 16f)
        {
            return new Vector2(
                MathF.Round(worldPos.X * pixelsPerUnit) / pixelsPerUnit,
                MathF.Round(worldPos.Y * pixelsPerUnit) / pixelsPerUnit);
        }

        // ── Parallax scrolling ────────────────────────────────────────────
        /// <summary>
        /// Calculate the camera-relative offset for a parallax layer.
        /// depth = 0 → foreground (moves 1:1 with camera).
        /// depth = 1 → background (doesn't move).
        /// </summary>
        public static Vector2 ParallaxOffset(Vector2 cameraPos, float depth)
            => cameraPos * (1f - depth);

        // ── Auto-tiling ───────────────────────────────────────────────────
        /// <summary>
        /// 47-tile bitmask auto-tiling (Wang tiles).
        /// Given a 2D bool grid, returns the tile index for position (x, y).
        /// </summary>
        public static int GetAutoTileIndex(bool[,] grid, int x, int y)
        {
            int rows = grid.GetLength(0);
            int cols = grid.GetLength(1);
            bool S(int dx, int dy)
            {
                int nx = x + dx, ny = y + dy;
                return nx >= 0 && nx < rows && ny >= 0 && ny < cols && grid[nx, ny];
            }

            int mask = 0;
            if (S(-1, 0)) mask |= 1;   // top
            if (S( 1, 0)) mask |= 2;   // bottom
            if (S( 0,-1)) mask |= 4;   // left
            if (S( 0, 1)) mask |= 8;   // right
            if (S(-1,-1) && (mask & 5) == 5) mask |= 16;   // top-left corner
            if (S(-1, 1) && (mask & 9) == 9) mask |= 32;   // top-right corner
            if (S( 1,-1) && (mask & 6) == 6) mask |= 64;   // bottom-left corner
            if (S( 1, 1) && (mask & 10)== 10) mask |= 128; // bottom-right corner

            return TileBitmaskToIndex(mask);
        }

        private static int TileBitmaskToIndex(int mask)
        {
            // Simplified lookup — replace with full 47-tile table for production
            return mask & 0xF;
        }

        // ── Sorting layers ────────────────────────────────────────────────
        /// <summary>Sort a list of SpriteRenderers for painter's algorithm rendering.</summary>
        public static void SortByLayer(List<SpriteRenderer> renderers)
        {
            renderers.Sort((a, b) =>
            {
                int cmp = a.SortingOrder.CompareTo(b.SortingOrder);
                if (cmp != 0) return cmp;
                // Secondary sort: Y-axis for top-down perspective
                return b.Transform.Position.Y.CompareTo(a.Transform.Position.Y);
            });
        }
    }
}
