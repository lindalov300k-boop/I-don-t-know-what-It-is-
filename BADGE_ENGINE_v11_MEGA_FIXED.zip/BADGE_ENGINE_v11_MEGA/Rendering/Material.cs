using System;
using System.Numerics;
using OpenTK.Mathematics;

namespace BADGE.Rendering
{
    // ══════════════════════════════════════════════════════════════════════
    //  Material — GPU material with shader, textures, and PBR properties.
    // ══════════════════════════════════════════════════════════════════════
    public class Material
    {
        public string  Name       { get; set; } = "New Material";
        public Shader? Shader     { get; set; }
        public Texture? Albedo    { get; set; }
        public Texture? Normal    { get; set; }
        public Texture? Roughness { get; set; }
        public Texture? Metallic  { get; set; }
        public Texture? Emission  { get; set; }
        public Texture? AO        { get; set; }

        // PBR scalars
        public Vector4 BaseColor     { get; set; } = Vector4.One;
        public float   MetallicValue { get; set; } = 0f;
        public float   RoughnessValue{ get; set; } = 0.5f;
        public Vector3 EmissionColor { get; set; } = Vector3.Zero;
        public float   EmissionStrength { get; set; } = 0f;
        public float   AlphaClip     { get; set; } = 0.5f;
        public bool    IsTransparent { get; set; } = false;
        public bool    DoubleSided   { get; set; } = false;
        public RenderQueue Queue     { get; set; } = RenderQueue.Opaque;

        // Int properties (texture slots, etc.)
        private readonly System.Collections.Generic.Dictionary<string, float>   _floats  = new();
        private readonly System.Collections.Generic.Dictionary<string, Vector4> _vectors = new();
        private readonly System.Collections.Generic.Dictionary<string, int>     _ints    = new();
        private readonly System.Collections.Generic.Dictionary<string, Texture?> _textures = new();

        public void SetFloat  (string name, float   v) => _floats[name]   = v;
        public void SetVector (string name, Vector4 v) => _vectors[name]  = v;
        public void SetInt    (string name, int     v) => _ints[name]     = v;
        public void SetTexture(string name, Texture? t)=> _textures[name] = t;
        public float   GetFloat  (string name, float   def = 0f)         => _floats.GetValueOrDefault(name, def);
        public Vector4 GetVector (string name, Vector4 def = default)    => _vectors.GetValueOrDefault(name, def);
        public int     GetInt    (string name, int     def = 0)          => _ints.GetValueOrDefault(name, def);
        public Texture? GetTexture(string name)                          => _textures.GetValueOrDefault(name);

        public void Bind()   => Shader?.Use();
        public void Unbind() => Shader?.Unbind();

        public static Material Default => new() { Name = "Default" };
        public static Material Unlit   => new() { Name = "Unlit",   MetallicValue = 0f, RoughnessValue = 1f };
        public static Material PBR     => new() { Name = "PBR",     MetallicValue = 0f, RoughnessValue = 0.5f };
    }

    public enum RenderQueue { Background = 1000, Opaque = 2000, AlphaTest = 2450, Transparent = 3000, Overlay = 4000 }

    // ── Shader ─────────────────────────────────────────────────────────────
    public class Shader
    {
        public int    ProgramId { get; private set; }
        public string Name      { get; set; } = "";
        public bool   IsValid   { get; private set; }

        public Shader(string name) { Name = name; IsValid = true; }

        public void Use()    => Console.WriteLine($"[Shader] Bind: {Name}");
        public void Unbind() { }

        // NullShader — silently accepts uniform calls so code using it won't crash.
        public void SetInt   (string n, int     v) { _uniforms[n] = v; }
        public void SetFloat (string n, float   v) { _uniforms[n] = v; }
        public void SetVec2  (string n, System.Numerics.Vector2 v) { _uniforms[n] = v; }
        public void SetVec3  (string n, Vector3 v) { _uniforms[n] = v; }
        public void SetVec4  (string n, Vector4 v) { _uniforms[n] = v; }
        public void SetMat4  (string n, Matrix4 v) { _uniforms[n] = v; }
        public void SetBool  (string n, bool    v) { _uniforms[n] = v; }
        private readonly System.Collections.Generic.Dictionary<string, object> _uniforms = new();
    }

    // ── Texture ────────────────────────────────────────────────────────────
    public class Texture
    {
        public int    TextureId { get; private set; }
        public string Path      { get; set; } = "";
        public int    Width     { get; set; }
        public int    Height    { get; set; }
        public bool   HasAlpha  { get; set; }

        public Texture(string path) { Path = path; }
        public void   Bind(int unit = 0) { }
        public void   Unbind() { }
        public void   Dispose() { }
    }
}
