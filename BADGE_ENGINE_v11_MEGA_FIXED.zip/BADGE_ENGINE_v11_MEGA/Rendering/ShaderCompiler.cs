using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using OpenTK.Graphics.OpenGL4;
using BADGE.Core;

namespace BADGE.Rendering
{
    /// <summary>
    /// GLSL shader compiler with error reporting, hot-reload support,
    /// and a simple preprocessor (include directives).
    /// </summary>
    public static class ShaderCompiler
    {
        // ── Compile API ───────────────────────────────────────────────────
        /// <summary>
        /// Compile a vertex + fragment source pair into an OpenGL program.
        /// Throws <see cref="ShaderCompileException"/> if compilation fails.
        /// </summary>
        public static int Compile(string vertSrc, string fragSrc, string label = "Shader")
        {
            int vert = CompileStage(ShaderType.VertexShader,   Preprocess(vertSrc), label + ".vert");
            int frag = CompileStage(ShaderType.FragmentShader, Preprocess(fragSrc), label + ".frag");
            int prog = Link(vert, frag, label);

            GL.DeleteShader(vert);
            GL.DeleteShader(frag);

            return prog;
        }

        /// <summary>Compile from files on disk. Supports #include.</summary>
        public static int CompileFiles(string vertPath, string fragPath)
        {
            string vertSrc = File.ReadAllText(vertPath);
            string fragSrc = File.ReadAllText(fragPath);
            return Compile(vertSrc, fragSrc, Path.GetFileNameWithoutExtension(vertPath));
        }

        // ── Validate (no GPU — parse for obvious errors) ──────────────────
        public static List<ShaderDiagnostic> Validate(string source)
        {
            var diagnostics = new List<ShaderDiagnostic>();
            var lines = source.Split('\n');

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();
                int lineNum = i + 1;

                // Require version directive on line 1
                if (i == 0 && !line.StartsWith("#version"))
                    diagnostics.Add(new ShaderDiagnostic(lineNum, DiagnosticLevel.Warning,
                        "First line should be a #version directive."));

                // Detect common mistakes
                if (line.EndsWith(";") && line.StartsWith("void main"))
                    diagnostics.Add(new ShaderDiagnostic(lineNum, DiagnosticLevel.Error,
                        "main() declared with semicolon — likely a typo."));

                if (line.Contains("gl_Position") && !line.Contains("="))
                    diagnostics.Add(new ShaderDiagnostic(lineNum, DiagnosticLevel.Warning,
                        "gl_Position referenced without assignment."));

                if (line.Contains("texture2D("))
                    diagnostics.Add(new ShaderDiagnostic(lineNum, DiagnosticLevel.Warning,
                        "texture2D() is deprecated in GLSL 130+; use texture() instead."));
            }

            return diagnostics;
        }

        // ── Hot-reload watcher ────────────────────────────────────────────
        private static readonly Dictionary<string, HotReloadEntry> _watching = new();

        public static void WatchFile(string vertPath, string fragPath,
                                      Action<int> onReloaded)
        {
            var entry = new HotReloadEntry(vertPath, fragPath, onReloaded);
            _watching[vertPath] = entry;
        }

        /// <summary>Call each frame or on a timer to detect changed files.</summary>
        public static void PollHotReload()
        {
            foreach (var entry in _watching.Values)
                entry.Poll();
        }

        // ── Preprocessor (#include) ───────────────────────────────────────
        private static string Preprocess(string source, string? baseDir = null,
                                          HashSet<string>? included = null)
        {
            included ??= new HashSet<string>();
            var sb = new StringBuilder();
            foreach (var line in source.Split('\n'))
            {
                string trimmed = line.Trim();
                if (trimmed.StartsWith("#include"))
                {
                    int a = trimmed.IndexOf('"');
                    int b = trimmed.LastIndexOf('"');
                    if (a >= 0 && b > a)
                    {
                        string incFile = trimmed.Substring(a + 1, b - a - 1);
                        string incPath = baseDir != null
                            ? Path.Combine(baseDir, incFile)
                            : Path.Combine("Assets", "Shaders", incFile);
                        if (File.Exists(incPath) && !included.Contains(incPath))
                        {
                            included.Add(incPath);
                            sb.AppendLine(Preprocess(File.ReadAllText(incPath),
                                          Path.GetDirectoryName(incPath), included));
                        }
                        continue;
                    }
                }
                sb.AppendLine(line);
            }
            return sb.ToString();
        }

        // ── Internal helpers ──────────────────────────────────────────────
        private static int CompileStage(ShaderType type, string source, string label)
        {
            int shader = GL.CreateShader(type);
            GL.ShaderSource(shader, source);
            GL.CompileShader(shader);

            GL.GetShader(shader, ShaderParameter.CompileStatus, out int status);
            if (status == 0)
            {
                string log = GL.GetShaderInfoLog(shader);
                GL.DeleteShader(shader);
                throw new ShaderCompileException(label, log);
            }
            return shader;
        }

        private static int Link(int vert, int frag, string label)
        {
            int prog = GL.CreateProgram();
            GL.AttachShader(prog, vert);
            GL.AttachShader(prog, frag);
            GL.LinkProgram(prog);

            GL.GetProgram(prog, GetProgramParameterName.LinkStatus, out int status);
            if (status == 0)
            {
                string log = GL.GetProgramInfoLog(prog);
                GL.DeleteProgram(prog);
                throw new ShaderCompileException(label, $"Link error: {log}");
            }
            return prog;
        }
    }

    // ── Supporting types ─────────────────────────────────────────────────
    public class ShaderCompileException : Exception
    {
        public string ShaderLabel { get; }
        public string CompilerLog { get; }
        public ShaderCompileException(string label, string log)
            : base($"[{label}] {log}") { ShaderLabel = label; CompilerLog = log; }
    }

    public class ShaderDiagnostic
    {
        public int              Line    { get; }
        public DiagnosticLevel  Level   { get; }
        public string           Message { get; }

        public ShaderDiagnostic(int line, DiagnosticLevel level, string message)
        { Line = line; Level = level; Message = message; }

        public override string ToString() => $"[{Level}] Line {Line}: {Message}";
    }

    public enum DiagnosticLevel { Info, Warning, Error }

    internal class HotReloadEntry
    {
        private readonly string         _vertPath, _fragPath;
        private readonly Action<int>    _callback;
        private DateTime                _lastVert, _lastFrag;

        public HotReloadEntry(string v, string f, Action<int> cb)
        {
            _vertPath = v; _fragPath = f; _callback = cb;
            _lastVert = File.Exists(v) ? File.GetLastWriteTime(v) : default;
            _lastFrag = File.Exists(f) ? File.GetLastWriteTime(f) : default;
        }

        public void Poll()
        {
            if (!File.Exists(_vertPath) || !File.Exists(_fragPath)) return;
            var vt = File.GetLastWriteTime(_vertPath);
            var ft = File.GetLastWriteTime(_fragPath);
            if (vt != _lastVert || ft != _lastFrag)
            {
                _lastVert = vt; _lastFrag = ft;
                try
                {
                    int prog = ShaderCompiler.CompileFiles(_vertPath, _fragPath);
                    _callback(prog);
                }
                catch (ShaderCompileException ex)
                {
                    Console.WriteLine($"[HotReload] {ex.Message}");
                }
            }
        }
    }
}
