using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Rendering;

// ═══════════════════════════════════════════════════════════════════════
//  TILE DEFINITION
// ═══════════════════════════════════════════════════════════════════════
public class TileDefinition
{
    public int    Id             { get; set; }
    public string Name           { get; set; } = "";
    public bool   IsSolid        { get; set; } = true;
    public bool   IsDestructible { get; set; } = true;
    public int    MaxHealth      { get; set; } = 100;
    public float  Friction       { get; set; } = 0.5f;
    public Color4 MapColor       { get; set; } = Color4.Gray;
    public string SpritePath     { get; set; } = "";
    public string DropItemId     { get; set; } = "";    // item dropped when broken
    public int    DropCount      { get; set; } = 1;
    public bool   EmitsLight     { get; set; } = false;
    public float  LightRadius    { get; set; } = 0f;
    public Color4 LightColor     { get; set; } = Color4.White;
    public int    TextureVariants { get; set; } = 1;    // for auto-tiling
}

// ═══════════════════════════════════════════════════════════════════════
//  TILE INSTANCE  (runtime per-cell data)
// ═══════════════════════════════════════════════════════════════════════
public struct TileCell
{
    public int   TileId;
    public byte  Variant;      // which auto-tile variant (0-15)
    public short Health;
    public byte  Light;        // 0-255 light level
    public bool  HasWall;
    public int   WallId;

    public static readonly TileCell Empty = new TileCell { TileId = 0 };
    public bool IsEmpty => TileId == 0;
}

// ═══════════════════════════════════════════════════════════════════════
//  TILE MAP 2D
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Chunked, destructible 2D tilemap.
/// Terraria-style: foreground tiles + wall layer + lighting propagation.
/// Each chunk is 16×16 tiles. Only dirty chunks rebuild their mesh.
/// </summary>
public class TileMap2D : Core.Component
{
    public const int CHUNK_SIZE   = 16;
    public const int AIR_TILE     = 0;

    // ── Map dimensions ────────────────────────────────────────────
    public int   Width     { get; private set; }
    public int   Height    { get; private set; }
    public float TileSize  { get; set; } = 1f;

    // ── Storage ───────────────────────────────────────────────────
    private TileCell[,] _cells;
    private readonly Dictionary<(int,int), bool> _dirtyChunks = new();
    private static readonly Dictionary<int, TileDefinition> _defs = new();

    // ── Events ────────────────────────────────────────────────────
    public event Action<int, int, int>? OnTileChanged;   // (x, y, newTileId)
    public event Action<int, int>?      OnTileDestroyed; // (x, y)

    public TileMap2D(int width, int height)
    {
        Width  = width;
        Height = height;
        _cells = new TileCell[width, height];
    }

    // ── Registration ──────────────────────────────────────────────
    public static void RegisterTile(TileDefinition def) => _defs[def.Id] = def;
    public static TileDefinition? GetDef(int id)        => _defs.GetValueOrDefault(id);

    // ── Get / Set ─────────────────────────────────────────────────
    public TileCell GetCell(int x, int y)
    {
        if (!InBounds(x, y)) return TileCell.Empty;
        return _cells[x, y];
    }

    public void SetTile(int x, int y, int tileId, int wallId = -1)
    {
        if (!InBounds(x, y)) return;
        var def  = GetDef(tileId);
        var prev = _cells[x, y].TileId;
        _cells[x, y].TileId  = tileId;
        _cells[x, y].Health  = (short)(def?.MaxHealth ?? 100);
        if (wallId >= 0) { _cells[x, y].HasWall = true; _cells[x, y].WallId = wallId; }
        MarkChunkDirty(x, y);
        UpdateAutoTile(x, y);
        // Update neighbours for auto-tile
        for (int dx = -1; dx <= 1; dx++)
        for (int dy = -1; dy <= 1; dy++)
            if (dx != 0 || dy != 0) UpdateAutoTile(x + dx, y + dy);
        OnTileChanged?.Invoke(x, y, tileId);
    }

    public void SetTileRect(int x, int y, int w, int h, int tileId)
    {
        for (int cx = x; cx < x + w; cx++)
        for (int cy = y; cy < y + h; cy++)
            SetTile(cx, cy, tileId);
    }

    // ── Damage / Destroy ──────────────────────────────────────────
    public bool DamageTile(int x, int y, int damage, out string droppedItemId, out int dropCount)
    {
        droppedItemId = "";
        dropCount     = 0;
        if (!InBounds(x, y) || _cells[x, y].IsEmpty) return false;

        _cells[x, y].Health -= (short)damage;
        if (_cells[x, y].Health <= 0)
        {
            var def       = GetDef(_cells[x, y].TileId);
            droppedItemId = def?.DropItemId ?? "";
            dropCount     = def?.DropCount  ?? 0;
            SetTile(x, y, AIR_TILE);
            OnTileDestroyed?.Invoke(x, y);
            return true;
        }
        return false;
    }

    // ── Queries ───────────────────────────────────────────────────
    public bool IsSolid(int x, int y) => !InBounds(x, y) || (GetDef(_cells[x,y].TileId)?.IsSolid ?? false);
    public bool IsEmpty(int x, int y) => !InBounds(x, y) || _cells[x, y].IsEmpty;
    public bool InBounds(int x, int y)=> x >= 0 && y >= 0 && x < Width && y < Height;

    /// <summary>Convert world position to tile coordinates.</summary>
    public (int x, int y) WorldToTile(Vector3 worldPos)
        => ((int)MathF.Floor(worldPos.X / TileSize), (int)MathF.Floor(worldPos.Y / TileSize));

    public Vector3 TileToWorld(int x, int y)
        => new Vector3(x * TileSize + TileSize * 0.5f, y * TileSize + TileSize * 0.5f, 0f);

    /// <summary>AABB tile collision — returns list of solid tiles overlapping the rect.</summary>
    public List<(int x, int y)> GetSolidTilesInRect(float wx, float wy, float ww, float wh)
    {
        var result = new List<(int, int)>();
        int x0 = (int)MathF.Floor(wx / TileSize);
        int y0 = (int)MathF.Floor(wy / TileSize);
        int x1 = (int)MathF.Ceiling((wx + ww) / TileSize);
        int y1 = (int)MathF.Ceiling((wy + wh) / TileSize);
        for (int x = x0; x <= x1; x++)
        for (int y = y0; y <= y1; y++)
            if (IsSolid(x, y)) result.Add((x, y));
        return result;
    }

    // ── Light propagation (BFS flood fill) ────────────────────────
    public void RecalculateLighting()
    {
        // Reset
        for (int x = 0; x < Width; x++)
        for (int y = 0; y < Height; y++)
            _cells[x, y].Light = 0;

        var queue = new Queue<(int x, int y, byte light)>();

        // Sunlight from top row
        for (int x = 0; x < Width; x++)
        {
            _cells[x, Height - 1].Light = 255;
            queue.Enqueue((x, Height - 1, 255));
        }

        // Light-emitting tiles
        for (int x = 0; x < Width; x++)
        for (int y = 0; y < Height; y++)
        {
            var def = GetDef(_cells[x, y].TileId);
            if (def?.EmitsLight == true)
            {
                byte l = (byte)(def.LightRadius * 25.5f);
                _cells[x, y].Light = l;
                queue.Enqueue((x, y, l));
            }
        }

        // BFS propagation
        int[] dx = { 0, 0, 1, -1 };
        int[] dy = { 1, -1, 0, 0 };
        while (queue.Count > 0)
        {
            var (cx, cy, light) = queue.Dequeue();
            if (light <= 10) continue;
            byte next = (byte)(light - 15);
            for (int d = 0; d < 4; d++)
            {
                int nx = cx + dx[d], ny = cy + dy[d];
                if (!InBounds(nx, ny)) continue;
                if (IsSolid(nx, ny)) next = (byte)(next * 0.7f);
                if (_cells[nx, ny].Light >= next) continue;
                _cells[nx, ny].Light = next;
                queue.Enqueue((nx, ny, next));
            }
        }
        MarkAllDirty();
    }

    // ── Auto-tiling (bitmask method) ──────────────────────────────
    private void UpdateAutoTile(int x, int y)
    {
        if (!InBounds(x, y) || _cells[x, y].IsEmpty) return;
        int id = _cells[x, y].TileId;
        byte mask = 0;
        if (!IsEmpty(x,     y + 1)) mask |= 1;
        if (!IsEmpty(x + 1, y    )) mask |= 2;
        if (!IsEmpty(x,     y - 1)) mask |= 4;
        if (!IsEmpty(x - 1, y    )) mask |= 8;
        _cells[x, y].Variant = mask;
    }

    // ── Chunk dirty tracking ──────────────────────────────────────
    private void MarkChunkDirty(int tileX, int tileY)
    {
        int cx = tileX / CHUNK_SIZE, cy = tileY / CHUNK_SIZE;
        _dirtyChunks[(cx, cy)] = true;
    }

    private void MarkAllDirty()
    {
        for (int cx = 0; cx < (Width + CHUNK_SIZE - 1) / CHUNK_SIZE; cx++)
        for (int cy = 0; cy < (Height + CHUNK_SIZE - 1) / CHUNK_SIZE; cy++)
            _dirtyChunks[(cx, cy)] = true;
    }

    public IEnumerable<(int cx, int cy)> GetDirtyChunks()
    {
        var list = new List<(int, int)>(_dirtyChunks.Keys);
        _dirtyChunks.Clear();
        return list;
    }

    // ── Serialization ─────────────────────────────────────────────
    public int[,] GetTileIds()
    {
        var arr = new int[Width, Height];
        for (int x = 0; x < Width; x++)
        for (int y = 0; y < Height; y++)
            arr[x, y] = _cells[x, y].TileId;
        return arr;
    }

    public void LoadFromIds(int[,] ids)
    {
        for (int x = 0; x < Width; x++)
        for (int y = 0; y < Height; y++)
            if (x < ids.GetLength(0) && y < ids.GetLength(1))
                SetTile(x, y, ids[x, y]);
    }
}
