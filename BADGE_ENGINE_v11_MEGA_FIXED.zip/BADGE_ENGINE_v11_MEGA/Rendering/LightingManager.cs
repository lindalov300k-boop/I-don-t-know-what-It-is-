using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.ECS;

namespace BADGE.Rendering
{
    public static class LightingManager
    {
        private static List<Light> _lights = new List<Light>();
        public static Color AmbientColor { get; set; } = new Color(0.2f, 0.2f, 0.2f);

        public static void RegisterLight(Light light)
        {
            _lights.Add(light);
        }

        public static void UnregisterLight(Light light)
        {
            _lights.Remove(light);
        }

        public static List<Light> GetActiveLights()
        {
            return new List<Light>(_lights);
        }

        public static void Clear()
        {
            _lights.Clear();
        }
    }

    public class Light : Component
    {
        public LightType Type { get; set; } = LightType.Point;
        public Color Color { get; set; } = Color.White;
        public float Intensity { get; set; } = 1.0f;
        public float Range { get; set; } = 10.0f;
        public float SpotAngle { get; set; } = 30.0f;

        public override void OnAttach()
        {
            LightingManager.RegisterLight(this);
        }

        public override void OnDetach()
        {
            LightingManager.UnregisterLight(this);
        }
    }

    public enum LightType
    {
        Directional,
        Point,
        Spot
    }
}
