using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace BADGE.Security
{
    // ─────────────────────────────────────────────────────────────────────────
    //  ENGINE PERMISSIONS & ACCESS CONTROL
    //
    //  Architecture
    //  ────────────
    //  Permission   — a named capability string, e.g. "editor.scene.write"
    //  Role         — a named set of permissions (Admin, Developer, Tester, ReadOnly)
    //  Principal    — an identity (user, plugin, remote client) that holds roles
    //  AccessToken  — a short-lived HMAC-signed credential tied to a principal
    //  PermissionGate — enforces access at call sites (throw or return bool)
    //
    //  All sensitive operations in the engine call PermissionGate.Require() so
    //  that unauthorized plugins, network clients, or editor users are blocked.
    // ─────────────────────────────────────────────────────────────────────────

    // ── Well-known permission strings ─────────────────────────────────────
    public static class Permissions
    {
        // Engine core
        public const string EngineShutdown     = "engine.shutdown";
        public const string EngineModeSwitch   = "engine.mode.switch";     // play ↔ edit

        // Scene management
        public const string SceneRead          = "editor.scene.read";
        public const string SceneWrite         = "editor.scene.write";
        public const string SceneDelete        = "editor.scene.delete";

        // Asset management
        public const string AssetImport        = "asset.import";
        public const string AssetExport        = "asset.export";
        public const string AssetDelete        = "asset.delete";

        // Build pipeline
        public const string BuildRun           = "build.run";
        public const string BuildObfuscate     = "build.obfuscate";

        // Networking
        public const string NetworkHost        = "network.host";
        public const string NetworkConnect     = "network.connect";
        public const string NetworkAdmin       = "network.admin";          // kick, ban

        // Scripting / plugins
        public const string PluginLoad         = "plugin.load";
        public const string PluginUnload       = "plugin.unload";
        public const string ScriptExecute      = "script.execute";

        // Save system
        public const string SaveWrite          = "save.write";
        public const string SaveDelete         = "save.delete";

        // Security (meta)
        public const string SecurityAdmin      = "security.admin";         // manage roles
    }

    // ── Built-in roles ────────────────────────────────────────────────────
    public static class Roles
    {
        public const string Admin       = "Admin";
        public const string Developer   = "Developer";
        public const string Tester      = "Tester";
        public const string ReadOnly    = "ReadOnly";
        public const string NetworkPeer = "NetworkPeer";  // remote client
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  PRINCIPAL  (identity)
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class Principal
    {
        public string             Id          { get; }
        public string             DisplayName { get; }
        public HashSet<string>    Roles       { get; } = new();
        public PrincipalType      Type        { get; }
        public DateTimeOffset     CreatedAt   { get; } = DateTimeOffset.UtcNow;

        public Principal(string id, string displayName, PrincipalType type = PrincipalType.User)
        {
            Id          = id;
            DisplayName = displayName;
            Type        = type;
        }

        public void AddRole(string role)    => Roles.Add(role);
        public void RemoveRole(string role) => Roles.Remove(role);
        public bool HasRole(string role)    => Roles.Contains(role);

        public override string ToString() => $"[{Type}] {DisplayName} ({Id})";
    }

    public enum PrincipalType { User, Plugin, NetworkClient, System }

    // ─────────────────────────────────────────────────────────────────────────
    //  PERMISSION SYSTEM  (singleton)
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class PermissionSystem
    {
        // ── Singleton ────────────────────────────────────────────────────
        private static readonly Lazy<PermissionSystem> _lazy = new(() => new PermissionSystem());
        public static PermissionSystem Instance => _lazy.Value;

        // ── Storage ──────────────────────────────────────────────────────
        private readonly Dictionary<string, HashSet<string>> _rolePermissions = new();
        private readonly Dictionary<string, Principal>       _principals       = new();
        private Principal? _currentPrincipal;

        // ── HMAC token signing key (random at startup) ────────────────────
        private readonly byte[] _tokenSigningKey;

        // ── Constructor ──────────────────────────────────────────────────
        private PermissionSystem()
        {
            _tokenSigningKey = new byte[32];
            RandomNumberGenerator.Fill(_tokenSigningKey);
            RegisterDefaultRoles();
            Console.WriteLine("[Security] PermissionSystem initialized.");
        }

        // ─────────────────────────────────────────────────────────────────
        //  ROLE DEFINITIONS
        // ─────────────────────────────────────────────────────────────────

        private void RegisterDefaultRoles()
        {
            // Admin — full access
            DefineRole(Roles.Admin, new[]
            {
                Permissions.EngineShutdown, Permissions.EngineModeSwitch,
                Permissions.SceneRead,  Permissions.SceneWrite,  Permissions.SceneDelete,
                Permissions.AssetImport, Permissions.AssetExport, Permissions.AssetDelete,
                Permissions.BuildRun,   Permissions.BuildObfuscate,
                Permissions.NetworkHost, Permissions.NetworkConnect, Permissions.NetworkAdmin,
                Permissions.PluginLoad,  Permissions.PluginUnload,   Permissions.ScriptExecute,
                Permissions.SaveWrite,   Permissions.SaveDelete,
                Permissions.SecurityAdmin
            });

            // Developer — everything except security admin
            DefineRole(Roles.Developer, new[]
            {
                Permissions.EngineModeSwitch,
                Permissions.SceneRead, Permissions.SceneWrite, Permissions.SceneDelete,
                Permissions.AssetImport, Permissions.AssetExport,
                Permissions.BuildRun,
                Permissions.NetworkHost, Permissions.NetworkConnect,
                Permissions.PluginLoad,  Permissions.ScriptExecute,
                Permissions.SaveWrite
            });

            // Tester — read/play only
            DefineRole(Roles.Tester, new[]
            {
                Permissions.EngineModeSwitch,
                Permissions.SceneRead,
                Permissions.AssetImport,
                Permissions.NetworkConnect,
                Permissions.SaveWrite
            });

            // ReadOnly — view only
            DefineRole(Roles.ReadOnly, new[]
            {
                Permissions.SceneRead,
                Permissions.AssetImport
            });

            // NetworkPeer — minimal remote client rights
            DefineRole(Roles.NetworkPeer, new[]
            {
                Permissions.NetworkConnect,
                Permissions.SaveWrite
            });
        }

        public void DefineRole(string role, IEnumerable<string> permissions)
        {
            _rolePermissions[role] = new HashSet<string>(permissions);
        }

        public void GrantPermission(string role, string permission)
        {
            if (!_rolePermissions.TryGetValue(role, out var set))
                _rolePermissions[role] = set = new HashSet<string>();
            set.Add(permission);
        }

        public void RevokePermission(string role, string permission)
        {
            if (_rolePermissions.TryGetValue(role, out var set))
                set.Remove(permission);
        }

        // ─────────────────────────────────────────────────────────────────
        //  PRINCIPAL MANAGEMENT
        // ─────────────────────────────────────────────────────────────────

        public Principal CreatePrincipal(string id, string name,
                                         PrincipalType type = PrincipalType.User,
                                         string? defaultRole = null)
        {
            var p = new Principal(id, name, type);
            if (defaultRole != null) p.AddRole(defaultRole);
            _principals[id] = p;
            return p;
        }

        public Principal? GetPrincipal(string id)
            => _principals.TryGetValue(id, out var p) ? p : null;

        /// <summary>Set the identity for the current editor session.</summary>
        public void SetCurrentPrincipal(Principal p) => _currentPrincipal = p;

        public Principal? CurrentPrincipal => _currentPrincipal;

        // ─────────────────────────────────────────────────────────────────
        //  PERMISSION CHECK
        // ─────────────────────────────────────────────────────────────────

        public bool HasPermission(Principal principal, string permission)
        {
            foreach (var role in principal.Roles)
            {
                if (_rolePermissions.TryGetValue(role, out var perms) &&
                    perms.Contains(permission))
                    return true;
            }
            return false;
        }

        /// <summary>Check using the current session principal.</summary>
        public bool CurrentHas(string permission)
            => _currentPrincipal != null && HasPermission(_currentPrincipal, permission);

        // ─────────────────────────────────────────────────────────────────
        //  ACCESS TOKENS  (short-lived HMAC-signed credentials)
        // ─────────────────────────────────────────────────────────────────

        public AccessToken IssueToken(Principal principal, TimeSpan validity, string[]? scopes = null)
        {
            var token = new AccessToken
            {
                TokenId  = Guid.NewGuid().ToString("N"),
                Subject  = principal.Id,
                Roles    = new List<string>(principal.Roles),
                Scopes   = scopes != null ? new List<string>(scopes) : null,
                IssuedAt = DateTimeOffset.UtcNow,
                ExpiresAt= DateTimeOffset.UtcNow.Add(validity)
            };
            token.Signature = SignToken(token);
            return token;
        }

        public TokenValidationResult ValidateToken(AccessToken token)
        {
            if (token == null)            return TokenValidationResult.Invalid("Null token");
            if (token.ExpiresAt < DateTimeOffset.UtcNow) return TokenValidationResult.Invalid("Expired");

            string expected = SignToken(token);
            if (!CryptographicOperations.FixedTimeEquals(
                    Encoding.UTF8.GetBytes(token.Signature),
                    Encoding.UTF8.GetBytes(expected)))
                return TokenValidationResult.Invalid("Signature mismatch");

            return TokenValidationResult.Valid(token);
        }

        private string SignToken(AccessToken t)
        {
            string payload = $"{t.TokenId}|{t.Subject}|{t.IssuedAt.ToUnixTimeSeconds()}|{t.ExpiresAt.ToUnixTimeSeconds()}";
            using var hmac = new HMACSHA256(_tokenSigningKey);
            byte[] hash   = hmac.ComputeHash(Encoding.UTF8.GetBytes(payload));
            return Convert.ToBase64String(hash);
        }

        // ─────────────────────────────────────────────────────────────────
        //  AUDIT LOG
        // ─────────────────────────────────────────────────────────────────
        private readonly List<AuditEntry> _auditLog = new();

        public void Audit(string principalId, string action, bool granted)
        {
            _auditLog.Add(new AuditEntry(principalId, action, granted));
            if (!granted)
                Console.WriteLine($"[Security] ACCESS DENIED — {principalId} → {action}");
        }

        public IReadOnlyList<AuditEntry> GetAuditLog() => _auditLog.AsReadOnly();
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  PERMISSION GATE  (call-site enforcer)
    // ─────────────────────────────────────────────────────────────────────────
    public static class PermissionGate
    {
        /// <summary>Throws UnauthorizedAccessException if the current principal lacks permission.</summary>
        public static void Require(string permission)
        {
            var sys = PermissionSystem.Instance;
            bool ok = sys.CurrentHas(permission);
            sys.Audit(sys.CurrentPrincipal?.Id ?? "anonymous", permission, ok);
            if (!ok) throw new UnauthorizedAccessException(
                $"[BADGE] Permission denied: '{permission}'. " +
                $"Current user: {sys.CurrentPrincipal?.DisplayName ?? "none"}");
        }

        /// <summary>Returns true if the current principal has permission (no throw).</summary>
        public static bool Check(string permission)
        {
            var sys = PermissionSystem.Instance;
            bool ok = sys.CurrentHas(permission);
            sys.Audit(sys.CurrentPrincipal?.Id ?? "anonymous", permission, ok);
            return ok;
        }

        /// <summary>Require permission for a specific principal (e.g. a plugin).</summary>
        public static void RequireFor(Principal principal, string permission)
        {
            var sys = PermissionSystem.Instance;
            bool ok = sys.HasPermission(principal, permission);
            sys.Audit(principal.Id, permission, ok);
            if (!ok) throw new UnauthorizedAccessException(
                $"[BADGE] Permission denied: '{permission}' for {principal.DisplayName}");
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  SUPPORTING TYPES
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AccessToken
    {
        public string          TokenId   { get; set; } = "";
        public string          Subject   { get; set; } = "";
        public List<string>    Roles     { get; set; } = new();
        public List<string>?   Scopes    { get; set; }
        public DateTimeOffset  IssuedAt  { get; set; }
        public DateTimeOffset  ExpiresAt { get; set; }
        public string          Signature { get; set; } = "";
        public bool            IsExpired => DateTimeOffset.UtcNow > ExpiresAt;
    }

    public sealed class TokenValidationResult
    {
        public bool        IsValid { get; private init; }
        public string?     Error   { get; private init; }
        public AccessToken? Token  { get; private init; }

        public static TokenValidationResult Valid(AccessToken t)
            => new() { IsValid = true, Token = t };
        public static TokenValidationResult Invalid(string err)
            => new() { IsValid = false, Error = err };
    }

    public sealed class AuditEntry
    {
        public string        PrincipalId { get; }
        public string        Action      { get; }
        public bool          Granted     { get; }
        public DateTimeOffset Timestamp  { get; }

        public AuditEntry(string principal, string action, bool granted)
        {
            PrincipalId = principal;
            Action      = action;
            Granted     = granted;
            Timestamp   = DateTimeOffset.UtcNow;
        }

        public override string ToString()
            => $"[{Timestamp:HH:mm:ss.fff}] {(Granted ? "ALLOW" : "DENY ")} {PrincipalId} → {Action}";
    }
}
