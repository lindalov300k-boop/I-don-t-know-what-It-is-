using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Animation
{
    /// <summary>
    /// Central animation system:
    /// • IK (FABRIK) for procedural foot placement and arm reach
    /// • Animation blend tree (1D blend space)
    /// • Animation layers with masks
    /// • Root motion extraction
    /// • Curve editor data model
    /// </summary>

    // ── FABRIK IK Solver ─────────────────────────────────────────────────
    /// <summary>
    /// Forward And Backward Reaching IK (FABRIK).
    /// Works on a chain of joint positions; root is fixed.
    /// </summary>
    public class FABRIKSolver
    {
        private Vector3[] _joints;
        private float[]   _lengths;
        private int       _iterations;
        private float     _tolerance;

        public Vector3 Root   { get => _joints[0]; set => _joints[0] = value; }
        public Vector3 Target { get; set; }

        public FABRIKSolver(Vector3[] joints, int iterations = 10, float tolerance = 0.01f)
        {
            _joints     = (Vector3[])joints.Clone();
            _lengths    = new float[joints.Length - 1];
            _iterations = iterations;
            _tolerance  = tolerance;

            float totalLen = 0f;
            for (int i = 0; i < _lengths.Length; i++)
            {
                _lengths[i] = Vector3.Distance(joints[i], joints[i + 1]);
                totalLen += _lengths[i];
            }
        }

        /// <summary>Solve the chain toward Target. Returns solved joint positions.</summary>
        public Vector3[] Solve()
        {
            int n = _joints.Length;
            var root = _joints[0];

            for (int iter = 0; iter < _iterations; iter++)
            {
                // Check if target is reachable
                if (Vector3.Distance(root, Target) > _lengths.Sum())
                {
                    // Stretch straight toward target
                    for (int i = 0; i < n - 1; i++)
                    {
                        var dir = Vector3.Normalize(Target - _joints[i]);
                        _joints[i + 1] = _joints[i] + dir * _lengths[i];
                    }
                    break;
                }

                // Forward pass
                _joints[n - 1] = Target;
                for (int i = n - 2; i >= 0; i--)
                {
                    var dir = Vector3.Normalize(_joints[i] - _joints[i + 1]);
                    _joints[i] = _joints[i + 1] + dir * _lengths[i];
                }

                // Backward pass
                _joints[0] = root;
                for (int i = 0; i < n - 1; i++)
                {
                    var dir = Vector3.Normalize(_joints[i + 1] - _joints[i]);
                    _joints[i + 1] = _joints[i] + dir * _lengths[i];
                }

                if (Vector3.Distance(_joints[n - 1], Target) < _tolerance)
                    break;
            }

            return _joints;
        }

        private float Sum(float[] arr) { float s = 0; foreach (var x in arr) s += x; return s; }
    }

    // ── 1D Blend Tree ─────────────────────────────────────────────────────
    /// <summary>
    /// Blend tree: interpolates between clips by a float parameter.
    /// Example: "Speed" 0 → idle, 0.5 → walk, 1 → run.
    /// </summary>
    public class BlendTree1D
    {
        private readonly List<BlendNode1D> _nodes = new();
        private string _paramName;

        public BlendTree1D(string paramName) => _paramName = paramName;

        public void AddNode(AnimationClip clip, float threshold)
            => _nodes.Add(new BlendNode1D(clip, threshold));

        public Dictionary<string, BonePose> Sample(float paramValue, float time)
        {
            _nodes.Sort((a, b) => a.Threshold.CompareTo(b.Threshold));

            if (_nodes.Count == 0) return new();
            if (_nodes.Count == 1) return _nodes[0].Clip.Sample(time);

            // Find bracket
            for (int i = 0; i < _nodes.Count - 1; i++)
            {
                var lo = _nodes[i]; var hi = _nodes[i + 1];
                if (paramValue >= lo.Threshold && paramValue <= hi.Threshold)
                {
                    float t = (paramValue - lo.Threshold) / (hi.Threshold - lo.Threshold);
                    return BlendPoses(lo.Clip.Sample(time), hi.Clip.Sample(time), t);
                }
            }

            return paramValue < _nodes[0].Threshold
                ? _nodes[0].Clip.Sample(time)
                : _nodes[^1].Clip.Sample(time);
        }

        private Dictionary<string, BonePose> BlendPoses(
            Dictionary<string, BonePose> a,
            Dictionary<string, BonePose> b,
            float t)
        {
            var result = new Dictionary<string, BonePose>();
            foreach (var (bone, poseA) in a)
            {
                var poseB = b.TryGetValue(bone, out var pb) ? pb : poseA;
                result[bone] = new BonePose
                {
                    Position = Vector3.Lerp(poseA.Position, poseB.Position, t),
                    Rotation = Quaternion.Slerp(poseA.Rotation, poseB.Rotation, t),
                    Scale    = Vector3.Lerp(poseA.Scale, poseB.Scale, t)
                };
            }
            return result;
        }

        private record BlendNode1D(AnimationClip Clip, float Threshold);
    }

    // ── Animation Layer ───────────────────────────────────────────────────
    /// <summary>
    /// An animation layer plays a clip/blend-tree and blends with a base layer.
    /// A mask controls which bones are affected.
    /// </summary>
    public class AnimationLayer
    {
        public string      Name      { get; set; } = "Layer";
        public float       Weight    { get; set; } = 1f;
        public bool        Additive  { get; set; } = false;
        public HashSet<string> Mask  { get; } = new();   // bones affected; empty = all

        private AnimationClip? _clip;
        private float          _time;

        public void SetClip(AnimationClip clip) => _clip = clip;

        public Dictionary<string, BonePose>? Evaluate(float dt)
        {
            if (_clip == null) return null;
            _time += dt;
            var poses = _clip.Sample(_time);

            if (Mask.Count > 0)
            {
                var filtered = new Dictionary<string, BonePose>();
                foreach (var (bone, pose) in poses)
                    if (Mask.Contains(bone)) filtered[bone] = pose;
                return filtered;
            }

            return poses;
        }
    }

    // ── Root Motion Extractor ─────────────────────────────────────────────
    public static class RootMotion
    {
        /// <summary>
        /// Extract delta translation/rotation from the "Root" bone between frames
        /// and apply it to the transform, removing it from the bone pose.
        /// </summary>
        public static void Apply(Transform transform,
                                  Dictionary<string, BonePose> poses,
                                  float dt,
                                  string rootBoneName = "Root")
        {
            if (!poses.TryGetValue(rootBoneName, out var rootPose)) return;

            transform.Position += rootPose.Position * dt;
            transform.Rotation  = transform.Rotation * rootPose.Rotation;

            // Zero out root bone so it doesn't move the mesh independently
            poses[rootBoneName] = new BonePose
            {
                Position = Vector3.Zero,
                Rotation = Quaternion.Identity,
                Scale    = rootPose.Scale
            };
        }
    }

    // ── Animation Curve ───────────────────────────────────────────────────
    /// <summary>
    /// Cubic Bezier animation curve.  Add keyframes then call Evaluate(t).
    /// </summary>
    public class AnimationCurve
    {
        private readonly List<CurveKey> _keys = new();

        public void AddKey(float time, float value,
                            float inTangent = 0f, float outTangent = 0f)
            => _keys.Add(new CurveKey(time, value, inTangent, outTangent));

        public float Evaluate(float t)
        {
            if (_keys.Count == 0) return 0f;
            if (_keys.Count == 1 || t <= _keys[0].Time)    return _keys[0].Value;
            if (t >= _keys[^1].Time)                        return _keys[^1].Value;

            for (int i = 0; i < _keys.Count - 1; i++)
            {
                var lo = _keys[i]; var hi = _keys[i + 1];
                if (t >= lo.Time && t <= hi.Time)
                {
                    float u = (t - lo.Time) / (hi.Time - lo.Time);
                    return CubicBezier(lo.Value, hi.Value,
                                        lo.OutTangent, hi.InTangent, u);
                }
            }
            return _keys[^1].Value;
        }

        private static float CubicBezier(float p0, float p3, float m0, float m1, float t)
        {
            // Hermite cubic
            float t2 = t * t, t3 = t2 * t;
            return (2*t3 - 3*t2 + 1) * p0
                 + (t3 - 2*t2 + t)   * m0
                 + (-2*t3 + 3*t2)    * p3
                 + (t3 - t2)         * m1;
        }

        private record CurveKey(float Time, float Value, float InTangent, float OutTangent);
    }

    // ── Bone Pose ─────────────────────────────────────────────────────────
    public class BonePose
    {
        public Vector3    Position { get; set; } = Vector3.Zero;
        public Quaternion Rotation { get; set; } = Quaternion.Identity;
        public Vector3    Scale    { get; set; } = Vector3.One;

        public Matrix4 ToMatrix()
        {
            return Matrix4.CreateScale(Scale)
                 * Matrix4.CreateFromQuaternion(Rotation)
                 * Matrix4.CreateTranslation(Position);
        }
    }
}
