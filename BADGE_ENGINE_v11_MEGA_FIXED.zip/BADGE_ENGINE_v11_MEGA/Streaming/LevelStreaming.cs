using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.Streaming
{
    // ═══════════════════════════════════════════════════════════════════════
    //  LEVEL STREAMING SYSTEM
    //
    //  Supports:
    //    • Async scene chunk loading / unloading in the background
    //    • Distance-based streaming (load chunks near player)
    //    • Portal-based streaming (load what portals reveal)
    //    • World composition (large world split into sublevel tiles)
    //    • Streaming volume triggers (load/unload on overlap)
    //    • LOD level streaming (swap low-res with hi-res as player approaches)
    //    • Priority queue (nearby chunks first)
    //    • Memory budget enforcement (unload far chunks when over budget)
    //    • Progress reporting and loading screen integration
    //    • Hot-reload support (swap scene chunk without full scene restart)
    // ═══════════════════════════════════════════════════════════════════════

    public enum StreamingState { Unloaded, Queued, Loading, Active, Unloading }

    // ─────────────────────────────────────────────────────────────────────
    //  WORLD CHUNK  (a rectangular tile of the world)
    // ─────────────────────────────────────────────────────────────────────

    public class WorldChunk
    {
        public string    ID          { get; init; } = "";
        public string    ScenePath   { get; init; } = ""; // path to scene file
        public Vector3   WorldOrigin { get; init; }
        public Vector3   Size        { get; init; } = new(256, 512, 256);
        public float     LoadRadius  { get; set; }  = 300f;
        public float     UnloadRadius{ get; set; }  = 400f;
        public int       Priority    { get; set; }  = 0;     // higher = loads first
        public long      MemoryEstimateBytes { get; set; } = 50 * 1024 * 1024; // 50 MB default

        public StreamingState   State     { get; internal set; } = StreamingState.Unloaded;
        public Scene?           LoadedScene { get; internal set; }
        public float            LoadProgress{ get; internal set; } // 0-1
        public CancellationTokenSource? CancelSource { get; internal set; }

        public Box3 Bounds => new(WorldOrigin - Size / 2f, WorldOrigin + Size / 2f);

        public bool ContainsPoint(Vector3 point) =>
            point.X >= Bounds.Min.X && point.X <= Bounds.Max.X &&
            point.Y >= Bounds.Min.Y && point.Y <= Bounds.Max.Y &&
            point.Z >= Bounds.Min.Z && point.Z <= Bounds.Max.Z;

        public float DistanceTo(Vector3 point) =>
            Vector3.Distance(WorldOrigin, point);
    }

    // ─────────────────────────────────────────────────────────────────────
    //  STREAMING VOLUME  (trigger zone)
    // ─────────────────────────────────────────────────────────────────────

    public class StreamingVolume
    {
        public string   ID          { get; init; } = "";
        public Box3     Bounds      { get; init; }
        public List<string> LoadChunks   { get; init; } = new(); // chunk IDs to load when entered
        public List<string> UnloadChunks { get; init; } = new(); // chunk IDs to unload when entered
        public bool     WasOccupied { get; internal set; }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  LOD STREAMING ENTRY
    // ─────────────────────────────────────────────────────────────────────

    public class LODStreamingAsset
    {
        public string  ID          { get; init; } = "";
        public Vector3 WorldPos    { get; init; }
        public float[] LODDistances { get; init; } = { 50f, 150f, 400f, float.MaxValue };
        public string[]  LODMeshPaths{ get; init; } = Array.Empty<string>();
        public int     CurrentLOD  { get; internal set; } = -1;

        public int GetLODForDistance(float dist)
        {
            for (int i = 0; i < LODDistances.Length; i++)
                if (dist < LODDistances[i]) return i;
            return LODDistances.Length; // culled
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  LEVEL STREAMING MANAGER
    // ─────────────────────────────────────────────────────────────────────

    public static class LevelStreamingManager
    {
        // ── Settings ──────────────────────────────────────────────────────
        public static long   MemoryBudgetBytes { get; set; } = 512 * 1024 * 1024; // 512 MB
        public static int    MaxConcurrentLoads { get; set; } = 2;
        public static bool   EnablePortalStreaming { get; set; } = true;
        public static float  UpdateInterval  { get; set; } = 0.25f; // seconds between checks

        // ── World chunks registry ─────────────────────────────────────────
        private static readonly Dictionary<string, WorldChunk>    _chunks  = new();
        private static readonly Dictionary<string, StreamingVolume> _volumes = new();
        private static readonly Dictionary<string, LODStreamingAsset> _lods  = new();

        private static Vector3 _playerPos;
        private static float   _updateTimer;
        private static int     _activeLoads;
        private static long    _currentMemoryUse;

        // ── Events ────────────────────────────────────────────────────────
        public static event Action<WorldChunk>? OnChunkLoadStarted;
        public static event Action<WorldChunk>? OnChunkLoaded;
        public static event Action<WorldChunk>? OnChunkUnloaded;
        public static event Action<float>?      OnLoadingProgress; // 0-1 aggregate

        // ── Registration ──────────────────────────────────────────────────
        public static void RegisterChunk(WorldChunk chunk)   => _chunks[chunk.ID]  = chunk;
        public static void RegisterVolume(StreamingVolume v) => _volumes[v.ID]     = v;
        public static void RegisterLODAsset(LODStreamingAsset a) => _lods[a.ID]   = a;

        public static WorldChunk? GetChunk(string id) =>
            _chunks.TryGetValue(id, out var c) ? c : null;

        public static IEnumerable<WorldChunk> AllChunks => _chunks.Values;
        public static IEnumerable<WorldChunk> ActiveChunks =>
            System.Linq.Enumerable.Where(_chunks.Values, c => c.State == StreamingState.Active);

        // ── Update (call every frame) ─────────────────────────────────────
        public static void Update(Vector3 playerPosition, float dt)
        {
            _playerPos = playerPosition;
            _updateTimer += dt;
            if (_updateTimer < UpdateInterval) return;
            _updateTimer = 0f;

            EvaluateChunks();
            EvaluateVolumes();
            EvaluateLODs();
            EnforceMemoryBudget();
        }

        // ── Distance-based evaluation ──────────────────────────────────────
        private static void EvaluateChunks()
        {
            // Sort by priority + distance
            var sorted = new List<WorldChunk>(_chunks.Values);
            sorted.Sort((a, b) =>
            {
                float da = a.DistanceTo(_playerPos);
                float db = b.DistanceTo(_playerPos);
                int   pa = -(a.Priority - b.Priority); // higher priority first
                return pa != 0 ? pa : da.CompareTo(db);
            });

            foreach (var chunk in sorted)
            {
                float dist = chunk.DistanceTo(_playerPos);

                if (dist <= chunk.LoadRadius && chunk.State == StreamingState.Unloaded)
                {
                    if (_activeLoads < MaxConcurrentLoads)
                        QueueChunkLoad(chunk);
                }
                else if (dist > chunk.UnloadRadius && chunk.State == StreamingState.Active)
                {
                    QueueChunkUnload(chunk);
                }
            }
        }

        // ── Volume-based evaluation ────────────────────────────────────────
        private static void EvaluateVolumes()
        {
            foreach (var vol in _volumes.Values)
            {
                bool inside = vol.Bounds.Contains(_playerPos);
                if (inside && !vol.WasOccupied)
                {
                    vol.WasOccupied = true;
                    foreach (var id in vol.LoadChunks)
                        if (_chunks.TryGetValue(id, out var c) && c.State == StreamingState.Unloaded)
                            QueueChunkLoad(c);
                    foreach (var id in vol.UnloadChunks)
                        if (_chunks.TryGetValue(id, out var c) && c.State == StreamingState.Active)
                            QueueChunkUnload(c);
                }
                else if (!inside)
                {
                    vol.WasOccupied = false;
                }
            }
        }

        // ── LOD evaluation ─────────────────────────────────────────────────
        private static void EvaluateLODs()
        {
            foreach (var asset in _lods.Values)
            {
                float dist    = Vector3.Distance(_playerPos, asset.WorldPos);
                int   newLOD  = asset.GetLODForDistance(dist);
                if (newLOD != asset.CurrentLOD)
                {
                    asset.CurrentLOD = newLOD;
                    OnLODChanged?.Invoke(asset, newLOD);
                }
            }
        }

        public static event Action<LODStreamingAsset, int>? OnLODChanged;

        // ── Memory budget ──────────────────────────────────────────────────
        private static void EnforceMemoryBudget()
        {
            _currentMemoryUse = 0;
            foreach (var c in _chunks.Values)
                if (c.State == StreamingState.Active)
                    _currentMemoryUse += c.MemoryEstimateBytes;

            if (_currentMemoryUse <= MemoryBudgetBytes) return;

            // Unload furthest active chunks until under budget
            var active = new List<WorldChunk>(
                System.Linq.Enumerable.Where(_chunks.Values, c => c.State == StreamingState.Active));
            active.Sort((a, b) => b.DistanceTo(_playerPos).CompareTo(a.DistanceTo(_playerPos)));

            foreach (var chunk in active)
            {
                if (_currentMemoryUse <= MemoryBudgetBytes) break;
                if (chunk.DistanceTo(_playerPos) <= chunk.LoadRadius) continue; // keep nearby
                QueueChunkUnload(chunk);
                _currentMemoryUse -= chunk.MemoryEstimateBytes;
            }
        }

        // ── Async load / unload ────────────────────────────────────────────
        private static void QueueChunkLoad(WorldChunk chunk)
        {
            chunk.State       = StreamingState.Queued;
            chunk.CancelSource = new CancellationTokenSource();
            var token = chunk.CancelSource.Token;
            _activeLoads++;
            OnChunkLoadStarted?.Invoke(chunk);

            Task.Run(async () =>
            {
                chunk.State = StreamingState.Loading;
                try
                {
                    // Simulate async scene load (real: SceneManager.LoadSceneAsync)
                    for (int i = 0; i <= 10; i++)
                    {
                        if (token.IsCancellationRequested) { chunk.State = StreamingState.Unloaded; return; }
                        chunk.LoadProgress = i / 10f;
                        await Task.Delay(50, token); // real: yield per frame until loaded
                    }

                    // In real engine: chunk.LoadedScene = await SceneManager.Instance.LoadAsync(chunk.ScenePath);
                    chunk.LoadedScene = null; // placeholder

                    if (!token.IsCancellationRequested)
                    {
                        chunk.State = StreamingState.Active;
                        OnChunkLoaded?.Invoke(chunk);
                    }
                }
                catch (TaskCanceledException) { chunk.State = StreamingState.Unloaded; }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Streaming] Failed to load {chunk.ID}: {ex.Message}");
                    chunk.State = StreamingState.Unloaded;
                }
                finally
                {
                    _activeLoads = Math.Max(0, _activeLoads - 1);
                }
            });
        }

        private static void QueueChunkUnload(WorldChunk chunk)
        {
            chunk.CancelSource?.Cancel();
            chunk.State       = StreamingState.Unloading;

            Task.Run(() =>
            {
                // Real: SceneManager.UnloadScene(chunk.LoadedScene)
                chunk.LoadedScene = null;
                chunk.State       = StreamingState.Unloaded;
                OnChunkUnloaded?.Invoke(chunk);
            });
        }

        // ── Force load / unload ────────────────────────────────────────────
        public static void ForceLoadAll()
        {
            foreach (var c in _chunks.Values)
                if (c.State == StreamingState.Unloaded) QueueChunkLoad(c);
        }

        public static void ForceUnloadAll()
        {
            foreach (var c in _chunks.Values)
                if (c.State == StreamingState.Active) QueueChunkUnload(c);
        }

        // ── Aggregate loading progress ─────────────────────────────────────
        public static float GetAggregateProgress()
        {
            var loading = System.Linq.Enumerable.Where(_chunks.Values,
                c => c.State is StreamingState.Loading or StreamingState.Queued).ToList();
            if (loading.Count == 0) return 1f;
            float sum = 0f;
            foreach (var c in loading) sum += c.LoadProgress;
            return sum / loading.Count;
        }

        // ── World composition builder ──────────────────────────────────────
        public static WorldChunk[,] CreateGridWorld(string namePrefix, int cols, int rows,
                                                      float chunkSize, Vector3 worldOrigin)
        {
            var grid = new WorldChunk[cols, rows];
            for (int x = 0; x < cols; x++)
            for (int z = 0; z < rows; z++)
            {
                string id = $"{namePrefix}_{x}_{z}";
                var chunk = new WorldChunk
                {
                    ID          = id,
                    ScenePath   = $"Scenes/World/{id}.scene",
                    WorldOrigin = worldOrigin + new Vector3(x * chunkSize, 0, z * chunkSize),
                    Size        = new Vector3(chunkSize, chunkSize * 2f, chunkSize),
                    LoadRadius  = chunkSize * 1.2f,
                    UnloadRadius = chunkSize * 1.6f
                };
                grid[x, z] = chunk;
                RegisterChunk(chunk);
            }
            return grid;
        }
    }

    // Box3 helper (if not in OpenTK.Mathematics version being used)
    public struct Box3
    {
        public Vector3 Min, Max;
        public Box3(Vector3 min, Vector3 max) { Min = min; Max = max; }
        public bool Contains(Vector3 p) =>
            p.X >= Min.X && p.X <= Max.X &&
            p.Y >= Min.Y && p.Y <= Max.Y &&
            p.Z >= Min.Z && p.Z <= Max.Z;
    }
}
