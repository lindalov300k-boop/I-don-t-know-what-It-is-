using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using OpenTK.Mathematics;

namespace BADGE.Platform
{
    // ═══════════════════════════════════════════════════════════════════════
    //  PLATFORM SERVICES
    //
    //  Unified abstraction over:
    //    • Steam (Steamworks.NET)
    //    • Epic Games Store (EOS SDK)
    //    • Xbox / Microsoft Gaming (GDK)
    //    • PlayStation (PS4/PS5 SDK stubs — NDA, wire your own impl)
    //    • Nintendo Switch (NX SDK stubs)
    //    • iOS (Game Center / StoreKit)
    //    • Android (Google Play Games / Billing)
    //    • GOG Galaxy
    //    • Itch.io (no SDK, local only)
    //
    //  Features:
    //    • Achievements (unlock, progress, batch)
    //    • Leaderboards (upload score, download range/friends)
    //    • Cloud Save (read / write arbitrary blobs per slot)
    //    • DLC / IAP detection
    //    • Rich Presence / status strings
    //    • Friends list + invite
    //    • Overlay (in-game browser/community hub)
    //    • Platform identity (username, user ID, avatar)
    //    • Trophy / achievement art URLs
    //    • Input glyphs (controller icons per platform)
    // ═══════════════════════════════════════════════════════════════════════

    public enum PlatformTarget
    {
        None, Steam, EpicGames, Xbox, PlayStation4, PlayStation5,
        NintendoSwitch, IOSGameCenter, AndroidPlayGames, GOGGalaxy, ItchIO
    }

    // ─────────────────────────────────────────────────────────────────────
    //  DATA TYPES
    // ─────────────────────────────────────────────────────────────────────

    public class Achievement
    {
        public string  ID           { get; init; } = "";
        public string  Name         { get; init; } = "";
        public string  Description  { get; init; } = "";
        public bool    IsUnlocked   { get; set; }
        public float   Progress     { get; set; }  // 0-1 for progressive achievements
        public float   MaxProgress  { get; init; } = 1f;
        public string? IconUnlocked { get; init; }
        public string? IconLocked   { get; init; }
        public DateTime? UnlockedAt { get; set; }
        public bool    IsHidden     { get; init; }  // hidden until unlocked
        public bool    IsProgressiveComplete => Progress >= MaxProgress;
    }

    public class LeaderboardEntry
    {
        public string  UserID       { get; init; } = "";
        public string  DisplayName  { get; init; } = "";
        public long    Score        { get; init; }
        public int     Rank         { get; init; }
        public string? AvatarUrl    { get; init; }
        public Dictionary<string, string> ExtraData { get; init; } = new();
    }

    public enum LeaderboardSortOrder   { Ascending, Descending }
    public enum LeaderboardDisplayType { Numeric, TimeSeconds, TimeMilliseconds }
    public enum LeaderboardDataRequest { Global, GlobalAroundUser, Friends }

    public class Leaderboard
    {
        public string               ID          { get; init; } = "";
        public string               Name        { get; init; } = "";
        public LeaderboardSortOrder  SortOrder   { get; init; }
        public LeaderboardDisplayType DisplayType{ get; init; }
        public long                 PlayerScore { get; set; }
        public int                  PlayerRank  { get; set; }
    }

    public class CloudSaveSlot
    {
        public int    SlotIndex    { get; init; }
        public string DisplayName  { get; init; } = "";
        public byte[] Data         { get; set; }  = Array.Empty<byte>();
        public long   SizeBytes    => Data.Length;
        public DateTime LastSaved  { get; set; }
        public bool   HasData      => Data.Length > 0;
    }

    public class DLCItem
    {
        public string ID          { get; init; } = "";
        public string Name        { get; init; } = "";
        public bool   IsOwned     { get; set; }
        public bool   IsInstalled { get; set; }
        public string? StoreUrl   { get; init; }
    }

    public class PlatformUser
    {
        public string  ID          { get; init; } = "";
        public string  DisplayName { get; init; } = "";
        public string? AvatarUrl   { get; init; }
        public bool    IsGuest     { get; init; }
        public PlatformTarget Platform { get; init; }
    }

    public class Friend
    {
        public string  ID           { get; init; } = "";
        public string  DisplayName  { get; init; } = "";
        public bool    IsOnline     { get; set; }
        public string? RichPresence { get; set; }
        public string? AvatarUrl    { get; init; }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  PLATFORM PROVIDER INTERFACE
    // ─────────────────────────────────────────────────────────────────────

    public interface IPlatformProvider
    {
        PlatformTarget Target { get; }
        bool IsAvailable { get; }
        Task<bool> InitializeAsync();
        void Tick(float dt);
        void Shutdown();

        // Identity
        Task<PlatformUser?> GetCurrentUserAsync();
        Task<List<Friend>>  GetFriendsAsync();

        // Achievements
        Task<List<Achievement>> GetAchievementsAsync();
        Task<bool> UnlockAchievementAsync(string id);
        Task<bool> SetAchievementProgressAsync(string id, float progress);
        Task        ResetAchievementsAsync();  // dev-only

        // Leaderboards
        Task<bool> UploadScoreAsync(string leaderboardId, long score);
        Task<List<LeaderboardEntry>> DownloadLeaderboardAsync(
            string leaderboardId, LeaderboardDataRequest request,
            int rangeStart = 1, int rangeEnd = 10);

        // Cloud Save
        Task<byte[]?>  ReadCloudSlotAsync(int slotIndex);
        Task<bool>     WriteCloudSlotAsync(int slotIndex, byte[] data);
        Task<bool>     DeleteCloudSlotAsync(int slotIndex);

        // DLC / IAP
        Task<List<DLCItem>> GetDLCAsync();
        Task<bool>          IsDLCOwnedAsync(string dlcId);

        // Rich Presence
        void SetRichPresence(string key, string value);
        void ClearRichPresence();

        // Overlay
        void OpenOverlay(string page = "");    // "store", "achievements", "community"
        void OpenStoreUrl(string itemId = "");
        bool IsOverlayOpen { get; }

        // Invite
        Task SendInviteAsync(string userId);
        string GetJoinSecret();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  STEAM PROVIDER
    // ─────────────────────────────────────────────────────────────────────

    public class SteamProvider : IPlatformProvider
    {
        public PlatformTarget Target      => PlatformTarget.Steam;
        public bool           IsAvailable { get; private set; }
        public bool           IsOverlayOpen { get; private set; }

        private readonly string _appId;
        private PlatformUser?   _currentUser;
        private readonly Dictionary<string, Achievement> _achievements = new();
        private readonly Dictionary<string, Leaderboard> _leaderboards = new();

        public SteamProvider(string appId) { _appId = appId; }

        public async Task<bool> InitializeAsync()
        {
            // Real impl: Steamworks.SteamAPI.Init()
            // For BADGE engine, we expose the bridge surface:
            Console.WriteLine($"[Steam] Initializing AppID={_appId}");
            IsAvailable = TryBindSteamworks();
            if (IsAvailable)
                Console.WriteLine("[Steam] Steamworks initialized successfully.");
            else
                Console.WriteLine("[Steam] Steamworks not found — running without Steam services.");
            return IsAvailable;
        }

        private bool TryBindSteamworks()
        {
            // Runtime detection: try to load steam_api64.dll / libsteam_api.so
            try
            {
                // Steamworks.SteamAPI.Init() would go here
                // We set to false as we can't ship Steamworks.NET in the engine itself
                return false;
            }
            catch { return false; }
        }

        public void Tick(float dt)
        {
            if (!IsAvailable) return;
            // Steamworks.SteamAPI.RunCallbacks();
        }

        public void Shutdown()
        {
            if (!IsAvailable) return;
            // Steamworks.SteamAPI.Shutdown();
        }

        public async Task<PlatformUser?> GetCurrentUserAsync()
        {
            if (!IsAvailable) return null;
            // Real: SteamFriends.GetPersonaName(), SteamUser.GetSteamID()
            return _currentUser ??= new PlatformUser
            {
                ID = "steam_76561198000000000",
                DisplayName = "SteamUser",
                Platform = PlatformTarget.Steam
            };
        }

        public async Task<List<Friend>> GetFriendsAsync()
        {
            if (!IsAvailable) return new();
            // Real: SteamFriends.GetFriendCount() + GetFriendByIndex()
            return new();
        }

        public async Task<List<Achievement>> GetAchievementsAsync()
        {
            if (!IsAvailable) return new();
            // Real: SteamUserStats.RequestCurrentStats() callback, then GetAchievement()
            return new List<Achievement>(_achievements.Values);
        }

        public async Task<bool> UnlockAchievementAsync(string id)
        {
            if (!IsAvailable) return false;
            Console.WriteLine($"[Steam] Achievement unlocked: {id}");
            // Real: SteamUserStats.SetAchievement(id) + StoreStats()
            if (_achievements.TryGetValue(id, out var ach))
            {
                ach.IsUnlocked = true;
                ach.UnlockedAt = DateTime.UtcNow;
            }
            return true;
        }

        public async Task<bool> SetAchievementProgressAsync(string id, float progress)
        {
            if (!IsAvailable) return false;
            // Real: SteamUserStats.IndicateAchievementProgress()
            if (_achievements.TryGetValue(id, out var ach))
                ach.Progress = Math.Min(progress, ach.MaxProgress);
            return true;
        }

        public async Task ResetAchievementsAsync()
        {
            // Real: SteamUserStats.ResetAllStats(true)
            foreach (var a in _achievements.Values)
            { a.IsUnlocked = false; a.Progress = 0f; }
        }

        public async Task<bool> UploadScoreAsync(string leaderboardId, long score)
        {
            if (!IsAvailable) return false;
            Console.WriteLine($"[Steam] Score {score} → leaderboard {leaderboardId}");
            // Real: FindLeaderboard → UploadLeaderboardScore callback chain
            return true;
        }

        public async Task<List<LeaderboardEntry>> DownloadLeaderboardAsync(
            string leaderboardId, LeaderboardDataRequest request,
            int rangeStart = 1, int rangeEnd = 10)
        {
            if (!IsAvailable) return new();
            return new();
        }

        public async Task<byte[]?> ReadCloudSlotAsync(int slotIndex)
        {
            if (!IsAvailable) return null;
            string filename = $"badge_save_{slotIndex:D2}.bin";
            // Real: SteamRemoteStorage.FileRead(filename, ...)
            return null;
        }

        public async Task<bool> WriteCloudSlotAsync(int slotIndex, byte[] data)
        {
            if (!IsAvailable) return false;
            string filename = $"badge_save_{slotIndex:D2}.bin";
            // Real: SteamRemoteStorage.FileWrite(filename, data, data.Length)
            return false;
        }

        public async Task<bool> DeleteCloudSlotAsync(int slotIndex)
        {
            string filename = $"badge_save_{slotIndex:D2}.bin";
            // Real: SteamRemoteStorage.FileDelete(filename)
            return false;
        }

        public async Task<List<DLCItem>> GetDLCAsync()
        {
            // Real: SteamApps.GetDLCCount() + BGetDLCDataByIndex()
            return new();
        }

        public async Task<bool> IsDLCOwnedAsync(string dlcId)
        {
            // Real: SteamApps.IsDlcInstalled(uint.Parse(dlcId))
            return false;
        }

        public void SetRichPresence(string key, string value)
        {
            // Real: SteamFriends.SetRichPresence(key, value)
        }
        public void ClearRichPresence()
        {
            // Real: SteamFriends.ClearRichPresence()
        }

        public void OpenOverlay(string page = "")
        {
            // Real: SteamFriends.ActivateGameOverlay(page)
        }
        public void OpenStoreUrl(string itemId = "")
        {
            // Real: SteamFriends.ActivateGameOverlayToStore(uint.Parse(itemId))
        }

        public async Task SendInviteAsync(string userId)
        {
            // Real: SteamMatchmaking.InviteUserToLobby()
        }

        public string GetJoinSecret() => "";

        // ── Steam-specific extras ──────────────────────────────────────────
        public void RegisterAchievement(Achievement achievement) =>
            _achievements[achievement.ID] = achievement;

        public string GetAppID() => _appId;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  EPIC GAMES PROVIDER
    // ─────────────────────────────────────────────────────────────────────

    public class EpicGamesProvider : IPlatformProvider
    {
        public PlatformTarget Target      => PlatformTarget.EpicGames;
        public bool           IsAvailable { get; private set; }
        public bool           IsOverlayOpen { get; private set; }

        private readonly string _productId;
        private readonly string _sandboxId;
        private readonly string _deploymentId;

        public EpicGamesProvider(string productId, string sandboxId, string deploymentId)
        {
            _productId    = productId;
            _sandboxId    = sandboxId;
            _deploymentId = deploymentId;
        }

        public async Task<bool> InitializeAsync()
        {
            Console.WriteLine($"[EOS] Initializing ProductID={_productId}");
            // Real: EOS_Initialize(), EOS_Platform_Create()
            IsAvailable = false; // requires EOS SDK dlls
            return IsAvailable;
        }

        public void Tick(float dt) { /* EOS_Platform_Tick() */ }
        public void Shutdown()     { /* EOS_Shutdown() */ }

        public async Task<PlatformUser?> GetCurrentUserAsync() => null;
        public async Task<List<Friend>>  GetFriendsAsync()     => new();
        public async Task<List<Achievement>> GetAchievementsAsync() => new();
        public async Task<bool> UnlockAchievementAsync(string id)
        {
            Console.WriteLine($"[EOS] Achievement unlocked: {id}");
            return false;
        }
        public async Task<bool> SetAchievementProgressAsync(string id, float p) => false;
        public async Task ResetAchievementsAsync() { }
        public async Task<bool> UploadScoreAsync(string lb, long score) => false;
        public async Task<List<LeaderboardEntry>> DownloadLeaderboardAsync(
            string lb, LeaderboardDataRequest req, int s = 1, int e = 10) => new();
        public async Task<byte[]?> ReadCloudSlotAsync(int slot) => null;
        public async Task<bool> WriteCloudSlotAsync(int slot, byte[] data) => false;
        public async Task<bool> DeleteCloudSlotAsync(int slot) => false;
        public async Task<List<DLCItem>> GetDLCAsync()           => new();
        public async Task<bool> IsDLCOwnedAsync(string id)       => false;
        public void SetRichPresence(string key, string val)       { }
        public void ClearRichPresence()                           { }
        public void OpenOverlay(string page = "")                 { }
        public void OpenStoreUrl(string itemId = "")              { }
        public async Task SendInviteAsync(string userId)          { }
        public string GetJoinSecret()                             => "";
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MOBILE PROVIDERS (Google Play / Game Center)
    // ─────────────────────────────────────────────────────────────────────

    public class GooglePlayProvider : IPlatformProvider
    {
        public PlatformTarget Target => PlatformTarget.AndroidPlayGames;
        public bool IsAvailable { get; private set; }
        public bool IsOverlayOpen => false;

        public async Task<bool> InitializeAsync()
        {
            Console.WriteLine("[GooglePlay] Initializing Google Play Games SDK");
            IsAvailable = false; // requires Android runtime
            return IsAvailable;
        }

        public void Tick(float dt)  { }
        public void Shutdown()      { }
        public async Task<PlatformUser?> GetCurrentUserAsync() => null;
        public async Task<List<Friend>>  GetFriendsAsync()     => new();
        public async Task<List<Achievement>> GetAchievementsAsync() => new();
        public async Task<bool> UnlockAchievementAsync(string id)
        {
            Console.WriteLine($"[GooglePlay] Unlock achievement: {id}");
            return false;
        }
        public async Task<bool> SetAchievementProgressAsync(string id, float p) => false;
        public async Task ResetAchievementsAsync() { }
        public async Task<bool> UploadScoreAsync(string lb, long score)
        {
            Console.WriteLine($"[GooglePlay] Submit score {score} to {lb}");
            return false;
        }
        public async Task<List<LeaderboardEntry>> DownloadLeaderboardAsync(
            string lb, LeaderboardDataRequest req, int s = 1, int e = 10) => new();
        public async Task<byte[]?> ReadCloudSlotAsync(int slot) => null;
        public async Task<bool> WriteCloudSlotAsync(int slot, byte[] data) => false;
        public async Task<bool> DeleteCloudSlotAsync(int slot) => false;
        public async Task<List<DLCItem>> GetDLCAsync() => new();
        public async Task<bool> IsDLCOwnedAsync(string id) => false;
        public void SetRichPresence(string k, string v) { }
        public void ClearRichPresence() { }
        public void OpenOverlay(string page = "") { /* Google Play Games overlay */ }
        public void OpenStoreUrl(string id = "") { }
        public async Task SendInviteAsync(string userId) { }
        public string GetJoinSecret() => "";
    }

    public class GameCenterProvider : IPlatformProvider
    {
        public PlatformTarget Target => PlatformTarget.IOSGameCenter;
        public bool IsAvailable { get; private set; }
        public bool IsOverlayOpen => false;

        public async Task<bool> InitializeAsync()
        {
            Console.WriteLine("[GameCenter] Initializing Apple Game Center");
            IsAvailable = false; // requires iOS/macOS runtime
            return IsAvailable;
        }

        public void Tick(float dt)  { }
        public void Shutdown()      { }
        public async Task<PlatformUser?> GetCurrentUserAsync() => null;
        public async Task<List<Friend>>  GetFriendsAsync()     => new();
        public async Task<List<Achievement>> GetAchievementsAsync() => new();
        public async Task<bool> UnlockAchievementAsync(string id) => false;
        public async Task<bool> SetAchievementProgressAsync(string id, float p) => false;
        public async Task ResetAchievementsAsync() { }
        public async Task<bool> UploadScoreAsync(string lb, long score) => false;
        public async Task<List<LeaderboardEntry>> DownloadLeaderboardAsync(
            string lb, LeaderboardDataRequest req, int s = 1, int e = 10) => new();
        public async Task<byte[]?> ReadCloudSlotAsync(int slot) => null;
        public async Task<bool> WriteCloudSlotAsync(int slot, byte[] data) => false;
        public async Task<bool> DeleteCloudSlotAsync(int slot) => false;
        public async Task<List<DLCItem>> GetDLCAsync() => new();
        public async Task<bool> IsDLCOwnedAsync(string id) => false;
        public void SetRichPresence(string k, string v) { }
        public void ClearRichPresence() { }
        public void OpenOverlay(string page = "") { }
        public void OpenStoreUrl(string id = "") { }
        public async Task SendInviteAsync(string userId) { }
        public string GetJoinSecret() => "";
    }

    // ─────────────────────────────────────────────────────────────────────
    //  UNIFIED PLATFORM SERVICE MANAGER
    // ─────────────────────────────────────────────────────────────────────

    public static class PlatformServices
    {
        public static IPlatformProvider? Active { get; private set; }
        public static PlatformTarget     Platform => Active?.Target ?? PlatformTarget.None;
        public static bool               IsOnline  { get; private set; }

        // All registered providers (multi-platform builds may have several)
        private static readonly List<IPlatformProvider> _providers = new();

        // Cached local achievement state (fallback when offline)
        private static readonly Dictionary<string, Achievement> _localAchievements = new();
        private static readonly Dictionary<string, long>        _localLeaderboard  = new();

        // Events
        public static event Action<Achievement>?         OnAchievementUnlocked;
        public static event Action<string, long, int>?   OnLeaderboardScoreUploaded; // id, score, rank

        // ── Setup ─────────────────────────────────────────────────────────
        public static async Task InitializeAsync(IPlatformProvider provider,
                                                  bool allowOfflineFallback = true)
        {
            _providers.Add(provider);
            bool ok = await provider.InitializeAsync();
            if (ok)
            {
                Active   = provider;
                IsOnline = true;
                Console.WriteLine($"[Platform] Active: {provider.Target}");
            }
            else if (allowOfflineFallback)
            {
                Console.WriteLine($"[Platform] {provider.Target} unavailable — offline mode.");
                IsOnline = false;
            }
        }

        public static void Tick(float dt) => Active?.Tick(dt);
        public static void Shutdown()     => Active?.Shutdown();

        // ── Achievements ──────────────────────────────────────────────────
        public static void RegisterAchievement(Achievement ach) =>
            _localAchievements[ach.ID] = ach;

        public static async Task<bool> UnlockAsync(string id)
        {
            if (!_localAchievements.TryGetValue(id, out var ach)) return false;
            if (ach.IsUnlocked) return true;
            ach.IsUnlocked = true;
            ach.UnlockedAt = DateTime.UtcNow;
            OnAchievementUnlocked?.Invoke(ach);
            Console.WriteLine($"[Achievement] 🏆 Unlocked: {ach.Name}");
            if (Active != null)
                await Active.UnlockAchievementAsync(id);
            return true;
        }

        public static async Task<bool> SetProgressAsync(string id, float progress, float max = 1f)
        {
            if (!_localAchievements.TryGetValue(id, out var ach)) return false;
            ach.MaxProgress = max;
            ach.Progress    = Math.Min(progress, max);
            if (ach.IsProgressiveComplete)
                return await UnlockAsync(id);
            if (Active != null)
                await Active.SetAchievementProgressAsync(id, progress);
            return true;
        }

        public static bool IsUnlocked(string id) =>
            _localAchievements.TryGetValue(id, out var a) && a.IsUnlocked;

        public static IEnumerable<Achievement> GetAllAchievements() =>
            _localAchievements.Values;

        // ── Leaderboards ──────────────────────────────────────────────────
        public static async Task<bool> SubmitScoreAsync(string leaderboardId, long score)
        {
            // Local cache
            if (!_localLeaderboard.TryGetValue(leaderboardId, out long best) || score > best)
                _localLeaderboard[leaderboardId] = score;
            OnLeaderboardScoreUploaded?.Invoke(leaderboardId, score, 0);

            if (Active != null)
                return await Active.UploadScoreAsync(leaderboardId, score);
            return true;
        }

        public static async Task<List<LeaderboardEntry>> GetLeaderboardAsync(
            string id, LeaderboardDataRequest request = LeaderboardDataRequest.Global,
            int start = 1, int end = 10)
        {
            if (Active != null)
                return await Active.DownloadLeaderboardAsync(id, request, start, end);
            return new();
        }

        public static long GetLocalBestScore(string leaderboardId) =>
            _localLeaderboard.TryGetValue(leaderboardId, out long s) ? s : 0;

        // ── Cloud Save ────────────────────────────────────────────────────
        public static async Task<byte[]?> CloudReadAsync(int slot) =>
            Active != null ? await Active.ReadCloudSlotAsync(slot) : null;

        public static async Task<bool> CloudWriteAsync(int slot, byte[] data) =>
            Active != null && await Active.WriteCloudSlotAsync(slot, data);

        // ── Rich Presence ─────────────────────────────────────────────────
        public static void SetStatus(string status)       => Active?.SetRichPresence("status", status);
        public static void SetDetails(string details)     => Active?.SetRichPresence("details", details);
        public static void SetPartySize(int cur, int max) => Active?.SetRichPresence("party", $"{cur}/{max}");
        public static void ClearPresence()                => Active?.ClearRichPresence();

        // ── DLC ───────────────────────────────────────────────────────────
        public static async Task<bool> IsDLCAvailableAsync(string dlcId) =>
            Active != null && await Active.IsDLCOwnedAsync(dlcId);

        // ── Overlay ───────────────────────────────────────────────────────
        public static void OpenStore()        => Active?.OpenStoreUrl();
        public static void OpenAchievements() => Active?.OpenOverlay("achievements");
        public static void OpenCommunity()    => Active?.OpenOverlay("community");
        public static bool IsOverlayOpen      => Active?.IsOverlayOpen ?? false;

        // ── Identity ──────────────────────────────────────────────────────
        public static async Task<PlatformUser?> GetCurrentUserAsync() =>
            Active != null ? await Active.GetCurrentUserAsync() : null;

        public static async Task<List<Friend>> GetFriendsAsync() =>
            Active != null ? await Active.GetFriendsAsync() : new();

        // ── Input glyphs helper ───────────────────────────────────────────
        /// <summary>Returns a text glyph for a button on the current platform.</summary>
        public static string GetButtonGlyph(string action) =>
            Platform switch
            {
                PlatformTarget.PlayStation4 or PlatformTarget.PlayStation5 => action switch
                {
                    "Confirm" => "✕", "Cancel" => "◯", "Action1" => "△", "Action2" => "□", _ => action
                },
                PlatformTarget.NintendoSwitch => action switch
                {
                    "Confirm" => "Ⓑ", "Cancel" => "Ⓐ", "Action1" => "Ⓧ", "Action2" => "Ⓨ", _ => action
                },
                _ => action switch // Xbox / PC default
                {
                    "Confirm" => "Ⓐ", "Cancel" => "Ⓑ", "Action1" => "Ⓨ", "Action2" => "Ⓧ", _ => action
                }
            };
    }
}
