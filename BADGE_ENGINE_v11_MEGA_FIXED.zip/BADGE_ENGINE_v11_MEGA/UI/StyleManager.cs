using System;
using System.Collections.Generic;
using System.IO;
using OpenTK.Mathematics;

namespace BADGE.UI
{
    /// <summary>
    /// UI Styling System - CSS-like styling for the BADGE Engine
    /// Allows complete customization of the engine's appearance
    /// </summary>
    public class StyleManager
    {
        private static StyleManager _instance;
        public static StyleManager Instance => _instance ??= new StyleManager();

        private Dictionary<string, StyleSheet> _styleSheets;
        private StyleSheet _activeTheme;
        private Dictionary<string, Style> _globalStyles;

        public StyleManager()
        {
            _styleSheets = new Dictionary<string, StyleSheet>();
            _globalStyles = new Dictionary<string, Style>();
            InitializeDefaultThemes();
        }

        private void InitializeDefaultThemes()
        {
            // Dark Theme
            var darkTheme = new StyleSheet("Dark");
            darkTheme.AddStyle("background", new Style
            {
                BackgroundColor = new Color4(30, 30, 30, 255),
                ForegroundColor = new Color4(220, 220, 220, 255),
                BorderColor = new Color4(60, 60, 60, 255),
                BorderWidth = 1f
            });
            darkTheme.AddStyle("panel", new Style
            {
                BackgroundColor = new Color4(45, 45, 48, 255),
                ForegroundColor = new Color4(240, 240, 240, 255),
                BorderColor = new Color4(70, 70, 70, 255),
                BorderWidth = 1f,
                Padding = new Vector4(8, 8, 8, 8),
                Margin = new Vector4(4, 4, 4, 4),
                BorderRadius = 4f
            });
            darkTheme.AddStyle("button", new Style
            {
                BackgroundColor = new Color4(0, 122, 204, 255),
                ForegroundColor = Color4.White,
                BorderColor = new Color4(0, 100, 180, 255),
                BorderWidth = 1f,
                Padding = new Vector4(12, 6, 12, 6),
                BorderRadius = 3f,
                FontSize = 14f
            });
            darkTheme.AddStyle("button:hover", new Style
            {
                BackgroundColor = new Color4(28, 151, 234, 255)
            });
            darkTheme.AddStyle("input", new Style
            {
                BackgroundColor = new Color4(60, 60, 60, 255),
                ForegroundColor = Color4.White,
                BorderColor = new Color4(90, 90, 90, 255),
                BorderWidth = 1f,
                Padding = new Vector4(8, 4, 8, 4),
                BorderRadius = 2f,
                FontSize = 13f
            });
            darkTheme.AddStyle("menu", new Style
            {
                BackgroundColor = new Color4(50, 50, 50, 255),
                ForegroundColor = new Color4(230, 230, 230, 255),
                BorderColor = new Color4(80, 80, 80, 255),
                BorderWidth = 1f,
                FontSize = 13f
            });
            darkTheme.AddStyle("tab", new Style
            {
                BackgroundColor = new Color4(40, 40, 40, 255),
                ForegroundColor = new Color4(200, 200, 200, 255),
                BorderWidth = 0f,
                Padding = new Vector4(16, 8, 16, 8)
            });
            darkTheme.AddStyle("tab:active", new Style
            {
                BackgroundColor = new Color4(45, 45, 48, 255),
                ForegroundColor = Color4.White,
                BorderBottomWidth = 2f,
                BorderBottomColor = new Color4(0, 122, 204, 255)
            });
            _styleSheets["Dark"] = darkTheme;

            // Light Theme
            var lightTheme = new StyleSheet("Light");
            lightTheme.AddStyle("background", new Style
            {
                BackgroundColor = new Color4(245, 245, 245, 255),
                ForegroundColor = new Color4(30, 30, 30, 255),
                BorderColor = new Color4(200, 200, 200, 255),
                BorderWidth = 1f
            });
            lightTheme.AddStyle("panel", new Style
            {
                BackgroundColor = Color4.White,
                ForegroundColor = new Color4(30, 30, 30, 255),
                BorderColor = new Color4(220, 220, 220, 255),
                BorderWidth = 1f,
                Padding = new Vector4(8, 8, 8, 8),
                Margin = new Vector4(4, 4, 4, 4),
                BorderRadius = 4f
            });
            lightTheme.AddStyle("button", new Style
            {
                BackgroundColor = new Color4(0, 122, 204, 255),
                ForegroundColor = Color4.White,
                BorderColor = new Color4(0, 100, 180, 255),
                BorderWidth = 1f,
                Padding = new Vector4(12, 6, 12, 6),
                BorderRadius = 3f,
                FontSize = 14f
            });
            lightTheme.AddStyle("input", new Style
            {
                BackgroundColor = Color4.White,
                ForegroundColor = new Color4(30, 30, 30, 255),
                BorderColor = new Color4(180, 180, 180, 255),
                BorderWidth = 1f,
                Padding = new Vector4(8, 4, 8, 4),
                BorderRadius = 2f,
                FontSize = 13f
            });
            _styleSheets["Light"] = lightTheme;

            // Blue Theme (Unity-like)
            var blueTheme = new StyleSheet("Blue");
            blueTheme.AddStyle("background", new Style
            {
                BackgroundColor = new Color4(56, 56, 56, 255),
                ForegroundColor = new Color4(210, 210, 210, 255)
            });
            blueTheme.AddStyle("panel", new Style
            {
                BackgroundColor = new Color4(64, 64, 64, 255),
                ForegroundColor = Color4.White,
                BorderColor = new Color4(35, 35, 35, 255),
                BorderWidth = 1f
            });
            blueTheme.AddStyle("button", new Style
            {
                BackgroundColor = new Color4(70, 100, 150, 255),
                ForegroundColor = Color4.White,
                Padding = new Vector4(12, 6, 12, 6),
                BorderRadius = 2f
            });
            _styleSheets["Blue"] = blueTheme;

            // Set default theme
            _activeTheme = darkTheme;
        }

        public void ApplyTheme(string themeName)
        {
            if (_styleSheets.TryGetValue(themeName, out var theme))
            {
                _activeTheme = theme;
                Console.WriteLine($"[Style] Applied theme: {themeName}");
                
                // Trigger UI refresh
                RefreshAllUI();
            }
        }

        public Style GetStyle(string elementType, string state = "")
        {
            string fullName = string.IsNullOrEmpty(state) ? elementType : $"{elementType}:{state}";
            
            if (_activeTheme != null && _activeTheme.Styles.TryGetValue(fullName, out var style))
            {
                return style;
            }

            // Fallback to default
            return Style.Default;
        }

        public void LoadStyleSheetFromFile(string path)
        {
            if (!File.Exists(path))
            {
                Console.WriteLine($"[Style] Style sheet not found: {path}");
                return;
            }

            var styleSheet = ParseStyleSheet(File.ReadAllText(path));
            _styleSheets[styleSheet.Name] = styleSheet;
        }

        private StyleSheet ParseStyleSheet(string content)
        {
            var styleSheet = new StyleSheet("Custom");
            
            // Parse CSS-like syntax
            string[] blocks = content.Split('}');
            
            foreach (string block in blocks)
            {
                if (string.IsNullOrWhiteSpace(block)) continue;

                string[] parts = block.Split('{');
                if (parts.Length != 2) continue;

                string selector = parts[0].Trim();
                string properties = parts[1].Trim();

                var style = ParseStyleProperties(properties);
                styleSheet.AddStyle(selector, style);
            }

            return styleSheet;
        }

        private Style ParseStyleProperties(string properties)
        {
            var style = new Style();
            string[] declarations = properties.Split(';');

            foreach (string declaration in declarations)
            {
                if (string.IsNullOrWhiteSpace(declaration)) continue;

                string[] parts = declaration.Split(':');
                if (parts.Length != 2) continue;

                string property = parts[0].Trim();
                string value = parts[1].Trim();

                ApplyStyleProperty(style, property, value);
            }

            return style;
        }

        private void ApplyStyleProperty(Style style, string property, string value)
        {
            switch (property.ToLower())
            {
                case "background-color":
                    style.BackgroundColor = ParseColor(value);
                    break;
                case "color":
                case "foreground-color":
                    style.ForegroundColor = ParseColor(value);
                    break;
                case "border-color":
                    style.BorderColor = ParseColor(value);
                    break;
                case "border-width":
                    style.BorderWidth = float.Parse(value.Replace("px", ""));
                    break;
                case "border-radius":
                    style.BorderRadius = float.Parse(value.Replace("px", ""));
                    break;
                case "padding":
                    style.Padding = ParsePadding(value);
                    break;
                case "margin":
                    style.Margin = ParsePadding(value);
                    break;
                case "font-size":
                    style.FontSize = float.Parse(value.Replace("px", ""));
                    break;
                case "font-weight":
                    style.FontWeight = value;
                    break;
                case "font-family":
                    style.FontFamily = value;
                    break;
                case "opacity":
                    style.Opacity = float.Parse(value);
                    break;
            }
        }

        private Color4 ParseColor(string value)
        {
            if (value.StartsWith("#"))
            {
                string hex = value.Substring(1);
                if (hex.Length == 6)
                {
                    byte r = Convert.ToByte(hex.Substring(0, 2), 16);
                    byte g = Convert.ToByte(hex.Substring(2, 2), 16);
                    byte b = Convert.ToByte(hex.Substring(4, 2), 16);
                    return new Color4(r, g, b, 255);
                }
            }
            else if (value.StartsWith("rgb"))
            {
                // Parse rgb(r, g, b) or rgba(r, g, b, a)
                string[] parts = value.Replace("rgb(", "").Replace("rgba(", "").Replace(")", "").Split(',');
                if (parts.Length >= 3)
                {
                    byte r = byte.Parse(parts[0].Trim());
                    byte g = byte.Parse(parts[1].Trim());
                    byte b = byte.Parse(parts[2].Trim());
                    byte a = parts.Length > 3 ? byte.Parse(parts[3].Trim()) : (byte)255;
                    return new Color4(r, g, b, a);
                }
            }

            return Color4.White;
        }

        private Vector4 ParsePadding(string value)
        {
            string[] parts = value.Replace("px", "").Split(' ');
            
            if (parts.Length == 1)
            {
                float all = float.Parse(parts[0]);
                return new Vector4(all, all, all, all);
            }
            else if (parts.Length == 2)
            {
                float vertical = float.Parse(parts[0]);
                float horizontal = float.Parse(parts[1]);
                return new Vector4(horizontal, vertical, horizontal, vertical);
            }
            else if (parts.Length == 4)
            {
                return new Vector4(
                    float.Parse(parts[3]), // left
                    float.Parse(parts[0]), // top
                    float.Parse(parts[1]), // right
                    float.Parse(parts[2])  // bottom
                );
            }

            return Vector4.Zero;
        }

        private void RefreshAllUI()
        {
            // Trigger all UI elements to refresh with new theme
            Console.WriteLine("[Style] Refreshing all UI elements with new theme");
        }

        public void ExportTheme(string themeName, string path)
        {
            if (_styleSheets.TryGetValue(themeName, out var theme))
            {
                string css = GenerateCSS(theme);
                File.WriteAllText(path, css);
                Console.WriteLine($"[Style] Exported theme '{themeName}' to {path}");
            }
        }

        private string GenerateCSS(StyleSheet theme)
        {
            var css = new System.Text.StringBuilder();
            css.AppendLine($"/* BADGE Engine Theme: {theme.Name} */");
            css.AppendLine();

            foreach (var kvp in theme.Styles)
            {
                css.AppendLine($"{kvp.Key} {{");
                css.AppendLine($"    background-color: {ColorToCSS(kvp.Value.BackgroundColor)};");
                css.AppendLine($"    color: {ColorToCSS(kvp.Value.ForegroundColor)};");
                css.AppendLine($"    border-color: {ColorToCSS(kvp.Value.BorderColor)};");
                css.AppendLine($"    border-width: {kvp.Value.BorderWidth}px;");
                css.AppendLine($"    border-radius: {kvp.Value.BorderRadius}px;");
                css.AppendLine($"    padding: {kvp.Value.Padding.Y}px {kvp.Value.Padding.Z}px {kvp.Value.Padding.W}px {kvp.Value.Padding.X}px;");
                css.AppendLine($"    font-size: {kvp.Value.FontSize}px;");
                css.AppendLine($"    opacity: {kvp.Value.Opacity};");
                css.AppendLine("}");
                css.AppendLine();
            }

            return css.ToString();
        }

        private string ColorToCSS(Color4 color)
        {
            return $"rgba({(int)(color.R * 255)}, {(int)(color.G * 255)}, {(int)(color.B * 255)}, {color.A})";
        }

        public IEnumerable<string> GetThemeNames() => _styleSheets.Keys;
        public string GetActiveThemeName() => _activeTheme?.Name ?? "None";
    }

    public class StyleSheet
    {
        public string Name { get; set; }
        public Dictionary<string, Style> Styles { get; set; }

        public StyleSheet(string name)
        {
            Name = name;
            Styles = new Dictionary<string, Style>();
        }

        public void AddStyle(string selector, Style style)
        {
            Styles[selector] = style;
        }
    }

    public class Style
    {
        public Color4 BackgroundColor { get; set; } = new Color4(45, 45, 48, 255);
        public Color4 ForegroundColor { get; set; } = Color4.White;
        public Color4 BorderColor { get; set; } = new Color4(70, 70, 70, 255);
        public float BorderWidth { get; set; } = 1f;
        public float BorderRadius { get; set; } = 0f;
        public float BorderTopWidth { get; set; }
        public float BorderBottomWidth { get; set; }
        public Color4 BorderBottomColor { get; set; }
        public Vector4 Padding { get; set; } = Vector4.Zero; // Left, Top, Right, Bottom
        public Vector4 Margin { get; set; } = Vector4.Zero;
        public float FontSize { get; set; } = 13f;
        public string FontFamily { get; set; } = "Arial";
        public string FontWeight { get; set; } = "normal";
        public float Opacity { get; set; } = 1.0f;
        public ShadowStyle Shadow { get; set; }
        
        public static Style Default => new Style();
    }

    public class ShadowStyle
    {
        public Color4 Color { get; set; } = new Color4(0, 0, 0, 128);
        public Vector2 Offset { get; set; } = new Vector2(2, 2);
        public float Blur { get; set; } = 4f;
    }
}
}
