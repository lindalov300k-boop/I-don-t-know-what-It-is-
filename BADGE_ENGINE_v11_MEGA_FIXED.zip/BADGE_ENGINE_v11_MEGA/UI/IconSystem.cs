using System;
using System.Collections.Generic;

namespace BADGE.UI
{
    /// <summary>
    /// Icon System - NO EMOJIS - Uses proper icon names and rendering
    /// All icons are referenced by name, not unicode characters
    /// </summary>
    public static class IconSystem
    {
        // Icon database - maps semantic names to icon IDs
        private static readonly Dictionary<string, IconDefinition> _icons = new Dictionary<string, IconDefinition>();

        static IconSystem()
        {
            InitializeIcons();
        }

        private static void InitializeIcons()
        {
            // ================ CORE ENGINE ICONS ================
            RegisterIcon("engine", new IconDefinition("engine", "Engine", IconCategory.Core));
            RegisterIcon("play", new IconDefinition("play", "Play", IconCategory.Core));
            RegisterIcon("pause", new IconDefinition("pause", "Pause", IconCategory.Core));
            RegisterIcon("stop", new IconDefinition("stop", "Stop", IconCategory.Core));
            RegisterIcon("save", new IconDefinition("save", "Save", IconCategory.Core));
            RegisterIcon("load", new IconDefinition("load", "Load", IconCategory.Core));
            RegisterIcon("settings", new IconDefinition("settings", "Settings", IconCategory.Core));

            // ================ FILE OPERATIONS ================
            RegisterIcon("file", new IconDefinition("file", "File", IconCategory.File));
            RegisterIcon("folder", new IconDefinition("folder", "Folder", IconCategory.File));
            RegisterIcon("open_folder", new IconDefinition("open_folder", "Open Folder", IconCategory.File));
            RegisterIcon("new_file", new IconDefinition("new_file", "New File", IconCategory.File));
            RegisterIcon("upload", new IconDefinition("upload", "Upload", IconCategory.File));
            RegisterIcon("download", new IconDefinition("download", "Download", IconCategory.File));
            RegisterIcon("attach", new IconDefinition("attach", "Attach", IconCategory.File));
            RegisterIcon("delete", new IconDefinition("delete", "Delete", IconCategory.File));
            RegisterIcon("copy", new IconDefinition("copy", "Copy", IconCategory.File));
            RegisterIcon("paste", new IconDefinition("paste", "Paste", IconCategory.File));

            // ================ EDITOR ICONS ================
            RegisterIcon("hierarchy", new IconDefinition("hierarchy", "Hierarchy", IconCategory.Editor));
            RegisterIcon("inspector", new IconDefinition("inspector", "Inspector", IconCategory.Editor));
            RegisterIcon("project", new IconDefinition("project", "Project", IconCategory.Editor));
            RegisterIcon("console", new IconDefinition("console", "Console", IconCategory.Editor));
            RegisterIcon("scene_view", new IconDefinition("scene_view", "Scene View", IconCategory.Editor));
            RegisterIcon("game_view", new IconDefinition("game_view", "Game View", IconCategory.Editor));

            // ================ ASSET ICONS ================
            RegisterIcon("script", new IconDefinition("script", "Script", IconCategory.Asset));
            RegisterIcon("audio", new IconDefinition("audio", "Audio", IconCategory.Asset));
            RegisterIcon("sprite", new IconDefinition("sprite", "Sprite", IconCategory.Asset));
            RegisterIcon("texture", new IconDefinition("texture", "Texture", IconCategory.Asset));
            RegisterIcon("material", new IconDefinition("material", "Material", IconCategory.Asset));
            RegisterIcon("model_3d", new IconDefinition("model_3d", "3D Model", IconCategory.Asset));
            RegisterIcon("animation", new IconDefinition("animation", "Animation", IconCategory.Asset));
            RegisterIcon("scene", new IconDefinition("scene", "Scene", IconCategory.Asset));
            RegisterIcon("prefab", new IconDefinition("prefab", "Prefab", IconCategory.Asset));
            RegisterIcon("shader", new IconDefinition("shader", "Shader", IconCategory.Asset));
            RegisterIcon("font", new IconDefinition("font", "Font", IconCategory.Asset));

            // ================ COMPONENT ICONS ================
            RegisterIcon("transform", new IconDefinition("transform", "Transform", IconCategory.Component));
            RegisterIcon("camera", new IconDefinition("camera", "Camera", IconCategory.Component));
            RegisterIcon("light_directional", new IconDefinition("light_directional", "Directional Light", IconCategory.Component));
            RegisterIcon("light_point", new IconDefinition("light_point", "Point Light", IconCategory.Component));
            RegisterIcon("light_spot", new IconDefinition("light_spot", "Spot Light", IconCategory.Component));
            RegisterIcon("mesh_renderer", new IconDefinition("mesh_renderer", "Mesh Renderer", IconCategory.Component));
            RegisterIcon("rigidbody", new IconDefinition("rigidbody", "Rigidbody", IconCategory.Component));
            RegisterIcon("collider", new IconDefinition("collider", "Collider", IconCategory.Component));
            RegisterIcon("audio_source", new IconDefinition("audio_source", "Audio Source", IconCategory.Component));
            RegisterIcon("particle_system", new IconDefinition("particle_system", "Particle System", IconCategory.Component));

            // ================ TOOL ICONS ================
            RegisterIcon("move", new IconDefinition("move", "Move Tool", IconCategory.Tool));
            RegisterIcon("rotate", new IconDefinition("rotate", "Rotate Tool", IconCategory.Tool));
            RegisterIcon("scale", new IconDefinition("scale", "Scale Tool", IconCategory.Tool));
            RegisterIcon("brush", new IconDefinition("brush", "Brush", IconCategory.Tool));
            RegisterIcon("eraser", new IconDefinition("eraser", "Eraser", IconCategory.Tool));
            RegisterIcon("eyedropper", new IconDefinition("eyedropper", "Eyedropper", IconCategory.Tool));
            RegisterIcon("fill", new IconDefinition("fill", "Fill", IconCategory.Tool));

            // ================ UI ICONS ================
            RegisterIcon("add", new IconDefinition("add", "Add", IconCategory.UI));
            RegisterIcon("remove", new IconDefinition("remove", "Remove", IconCategory.UI));
            RegisterIcon("search", new IconDefinition("search", "Search", IconCategory.UI));
            RegisterIcon("filter", new IconDefinition("filter", "Filter", IconCategory.UI));
            RegisterIcon("sort", new IconDefinition("sort", "Sort", IconCategory.UI));
            RegisterIcon("expand", new IconDefinition("expand", "Expand", IconCategory.UI));
            RegisterIcon("collapse", new IconDefinition("collapse", "Collapse", IconCategory.UI));
            RegisterIcon("maximize", new IconDefinition("maximize", "Maximize", IconCategory.UI));
            RegisterIcon("minimize", new IconDefinition("minimize", "Minimize", IconCategory.UI));
            RegisterIcon("close", new IconDefinition("close", "Close", IconCategory.UI));
            RegisterIcon("info", new IconDefinition("info", "Info", IconCategory.UI));
            RegisterIcon("warning", new IconDefinition("warning", "Warning", IconCategory.UI));
            RegisterIcon("error", new IconDefinition("error", "Error", IconCategory.UI));
            RegisterIcon("success", new IconDefinition("success", "Success", IconCategory.UI));

            // ================ GAMEPLAY ICONS ================
            RegisterIcon("player", new IconDefinition("player", "Player", IconCategory.Gameplay));
            RegisterIcon("enemy", new IconDefinition("enemy", "Enemy", IconCategory.Gameplay));
            RegisterIcon("npc", new IconDefinition("npc", "NPC", IconCategory.Gameplay));
            RegisterIcon("weapon", new IconDefinition("weapon", "Weapon", IconCategory.Gameplay));
            RegisterIcon("item", new IconDefinition("item", "Item", IconCategory.Gameplay));
            RegisterIcon("quest", new IconDefinition("quest", "Quest", IconCategory.Gameplay));
            RegisterIcon("inventory", new IconDefinition("inventory", "Inventory", IconCategory.Gameplay));
            RegisterIcon("health", new IconDefinition("health", "Health", IconCategory.Gameplay));
            RegisterIcon("shield", new IconDefinition("shield", "Shield", IconCategory.Gameplay));
            RegisterIcon("magic", new IconDefinition("magic", "Magic", IconCategory.Gameplay));

            // ================ SYSTEM ICONS ================
            RegisterIcon("cpu", new IconDefinition("cpu", "CPU", IconCategory.System));
            RegisterIcon("gpu", new IconDefinition("gpu", "GPU", IconCategory.System));
            RegisterIcon("memory", new IconDefinition("memory", "Memory", IconCategory.System));
            RegisterIcon("performance", new IconDefinition("performance", "Performance", IconCategory.System));
            RegisterIcon("profiler", new IconDefinition("profiler", "Profiler", IconCategory.System));
            RegisterIcon("network", new IconDefinition("network", "Network", IconCategory.System));

            // ================ AI ICONS ================
            RegisterIcon("ai", new IconDefinition("ai", "AI", IconCategory.AI));
            RegisterIcon("brain", new IconDefinition("brain", "Brain", IconCategory.AI));
            RegisterIcon("pathfinding", new IconDefinition("pathfinding", "Pathfinding", IconCategory.AI));
            RegisterIcon("behavior_tree", new IconDefinition("behavior_tree", "Behavior Tree", IconCategory.AI));
            RegisterIcon("neural_network", new IconDefinition("neural_network", "Neural Network", IconCategory.AI));

            // ================ PLUGIN ICONS ================
            RegisterIcon("plugin", new IconDefinition("plugin", "Plugin", IconCategory.Plugin));
            RegisterIcon("addon", new IconDefinition("addon", "Addon", IconCategory.Plugin));
            RegisterIcon("extension", new IconDefinition("extension", "Extension", IconCategory.Plugin));
            RegisterIcon("module", new IconDefinition("module", "Module", IconCategory.Plugin));
        }

        private static void RegisterIcon(string id, IconDefinition definition)
        {
            _icons[id] = definition;
        }

        // ================ PUBLIC API ================

        public static IconDefinition GetIcon(string id)
        {
            return _icons.TryGetValue(id, out var icon) ? icon : null;
        }

        public static bool HasIcon(string id)
        {
            return _icons.ContainsKey(id);
        }

        public static IEnumerable<IconDefinition> GetIconsByCategory(IconCategory category)
        {
            foreach (var icon in _icons.Values)
            {
                if (icon.Category == category)
                    yield return icon;
            }
        }

        public static IEnumerable<IconDefinition> GetAllIcons()
        {
            return _icons.Values;
        }

        // ================ ICON RENDERING ================

        public static void RenderIcon(string iconId, float x, float y, float size, IconStyle style = IconStyle.Normal)
        {
            var icon = GetIcon(iconId);
            if (icon == null)
            {
                Console.WriteLine($"[Icon] Icon not found: {iconId}");
                return;
            }

            // Render the icon using OpenGL/ImGui
            // This is a placeholder - actual rendering depends on your UI system
            RenderIconInternal(icon, x, y, size, style);
        }

        private static void RenderIconInternal(IconDefinition icon, float x, float y, float size, IconStyle style)
        {
            // Actual rendering implementation
            // For now, just log
            // Console.WriteLine($"[Icon] Rendering {icon.Name} at ({x}, {y}) size {size}");
        }

        // ================ ICON UTILITIES ================

        public static string GetIconText(string iconId)
        {
            var icon = GetIcon(iconId);
            return icon?.GetDisplayText() ?? $"[{iconId}]";
        }

        public static string[] GetIconNames()
        {
            return new List<string>(_icons.Keys).ToArray();
        }
    }

    // ================ ICON DATA STRUCTURES ================

    public class IconDefinition
    {
        public string ID { get; private set; }
        public string Name { get; private set; }
        public IconCategory Category { get; private set; }
        public string Description { get; set; }
        public string GlyphCode { get; set; } // For font-based icons
        public byte[] ImageData { get; set; } // For bitmap icons

        public IconDefinition(string id, string name, IconCategory category)
        {
            ID = id;
            Name = name;
            Category = category;
        }

        public string GetDisplayText()
        {
            // Returns the icon name in brackets for text display
            return $"[{Name}]";
        }
    }

    public enum IconCategory
    {
        Core,
        File,
        Editor,
        Asset,
        Component,
        Tool,
        UI,
        Gameplay,
        System,
        AI,
        Plugin
    }

    public enum IconStyle
    {
        Normal,
        Active,
        Disabled,
        Hover,
        Selected
    }

    // ================ ICON HELPER CLASSES ================

    /// <summary>
    /// Helper class for displaying icons in UI
    /// </summary>
    public static class IconUI
    {
        public static void Button(string iconId, string label, Action onClick)
        {
            string display = $"{IconSystem.GetIconText(iconId)} {label}";
            // Render button with icon
            Console.WriteLine($"[IconUI] Button: {display}");
            // onClick?.Invoke(); // Would be called on click
        }

        public static void MenuItem(string iconId, string label, bool enabled = true)
        {
            string display = $"{IconSystem.GetIconText(iconId)} {label}";
            // Render menu item with icon
            Console.WriteLine($"[IconUI] MenuItem: {display} (Enabled: {enabled})");
        }

        public static void Label(string iconId, string text)
        {
            string display = $"{IconSystem.GetIconText(iconId)} {text}";
            // Render label with icon
            Console.WriteLine($"[IconUI] Label: {display}");
        }

        public static void AssetIcon(string assetType)
        {
            string iconId = assetType.ToLower() switch
            {
                "script" => "script",
                "audio" => "audio",
                "sprite" => "sprite",
                "texture" => "texture",
                "material" => "material",
                "model" or "3dmodel" => "model_3d",
                "shader" => "shader",
                "scene" => "scene",
                "prefab" => "prefab",
                _ => "file"
            };

            IconSystem.RenderIcon(iconId, 0, 0, 16);
        }
    }

    /// <summary>
    /// Icon manifest for external icon packs
    /// </summary>
    public class IconPack
    {
        public string Name { get; set; }
        public string Version { get; set; }
        public string Author { get; set; }
        public Dictionary<string, IconDefinition> Icons { get; set; }

        public IconPack()
        {
            Icons = new Dictionary<string, IconDefinition>();
        }

        public void LoadFromFile(string path)
        {
            // Load icon pack from JSON/XML
            Console.WriteLine($"[IconPack] Loading icon pack from: {path}");
        }

        public void InstallToSystem()
        {
            foreach (var icon in Icons)
            {
                // Register each icon in the system
                Console.WriteLine($"[IconPack] Installing icon: {icon.Key}");
            }
        }
    }
}
