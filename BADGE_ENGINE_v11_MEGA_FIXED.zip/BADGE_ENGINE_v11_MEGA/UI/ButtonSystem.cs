using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using OpenTK.Windowing.GraphicsLibraryFramework;

namespace BADGE.UI
{
    /// <summary>
    /// Complete UI Button System with onClick events
    /// Supports normal clicks, double clicks, long press, hover effects
    /// </summary>
    public class Button : UIComponent
    {
        // ================ PROPERTIES ================
        public string Text { get; set; } = "Button";
        public TextMeshPro TextComponent { get; set; }
        public Style NormalStyle { get; set; }
        public Style HoverStyle { get; set; }
        public Style PressedStyle { get; set; }
        public Style DisabledStyle { get; set; }
        public bool Interactable { get; set; } = true;
        
        // ================ EVENTS ================
        public event Action OnClick;
        public event Action OnDoubleClick;
        public event Action OnLongPress;
        public event Action OnHoverEnter;
        public event Action OnHoverExit;
        public event Action<Vector2> OnRightClick;
        
        // ================ STATE ================
        private ButtonState _state = ButtonState.Normal;
        private bool _isHovered = false;
        private bool _isPressed = false;
        private float _pressTime = 0f;
        private float _lastClickTime = 0f;
        private const float DOUBLE_CLICK_TIME = 0.3f;
        private const float LONG_PRESS_TIME = 0.5f;

        public Button()
        {
            NormalStyle = StyleManager.Instance.GetStyle("button");
            HoverStyle = StyleManager.Instance.GetStyle("button", "hover");
            PressedStyle = StyleManager.Instance.GetStyle("button", "pressed");
            DisabledStyle = StyleManager.Instance.GetStyle("button", "disabled");
        }

        public override void OnUpdate(float deltaTime)
        {
            if (!Interactable)
            {
                _state = ButtonState.Disabled;
                return;
            }

            Vector2 mousePos = Input.GetMousePosition();
            bool wasHovered = _isHovered;
            _isHovered = IsPointInside(mousePos);

            // Hover enter/exit
            if (_isHovered && !wasHovered)
            {
                OnHoverEnter?.Invoke();
                _state = ButtonState.Hover;
                AdvancedCursor.SetCursor(CursorType.Hand);
            }
            else if (!_isHovered && wasHovered)
            {
                OnHoverExit?.Invoke();
                _state = ButtonState.Normal;
                AdvancedCursor.SetCursor(CursorType.Arrow);
            }

            // Button press
            if (_isHovered && Input.GetMouseButtonDown(MouseButton.Left))
            {
                _isPressed = true;
                _pressTime = 0f;
                _state = ButtonState.Pressed;
            }

            // Long press detection
            if (_isPressed)
            {
                _pressTime += deltaTime;
                if (_pressTime >= LONG_PRESS_TIME && OnLongPress != null)
                {
                    OnLongPress?.Invoke();
                    _isPressed = false;
                }
            }

            // Button release
            if (_isPressed && Input.GetMouseButtonUp(MouseButton.Left))
            {
                if (_isHovered && _pressTime < LONG_PRESS_TIME)
                {
                    // Check for double click
                    float timeSinceLastClick = Time.Time - _lastClickTime;
                    if (timeSinceLastClick < DOUBLE_CLICK_TIME && OnDoubleClick != null)
                    {
                        OnDoubleClick?.Invoke();
                        _lastClickTime = 0f;
                    }
                    else
                    {
                        OnClick?.Invoke();
                        _lastClickTime = Time.Time;
                    }
                }
                
                _isPressed = false;
                _state = _isHovered ? ButtonState.Hover : ButtonState.Normal;
            }

            // Right click
            if (_isHovered && Input.GetMouseButtonDown(MouseButton.Right))
            {
                OnRightClick?.Invoke(mousePos);
            }
        }

        public override void OnRender()
        {
            // Get appropriate style
            Style currentStyle = _state switch
            {
                ButtonState.Hover => HoverStyle,
                ButtonState.Pressed => PressedStyle,
                ButtonState.Disabled => DisabledStyle,
                _ => NormalStyle
            };

            // Render button background
            RenderBackground(currentStyle);
            
            // Render text
            if (TextComponent != null)
            {
                TextComponent.OnRender();
            }
        }

        private void RenderBackground(Style style)
        {
            // Background rendering with style
        }

        private bool IsPointInside(Vector2 point)
        {
            return point.X >= Transform.Position.X &&
                   point.X <= Transform.Position.X + Width &&
                   point.Y >= Transform.Position.Y &&
                   point.Y <= Transform.Position.Y + Height;
        }

        private enum ButtonState
        {
            Normal,
            Hover,
            Pressed,
            Disabled
        }
    }

    /// <summary>
    /// Advanced Cursor System
    /// Supports custom cursors, cursor modes, and cursor actions
    /// </summary>
    public static class AdvancedCursor
    {
        private static CursorType _currentCursor = CursorType.Arrow;
        private static Dictionary<CursorType, CursorData> _cursors = new Dictionary<CursorType, CursorData>();
        private static Vector2 _position;
        private static Vector2 _delta;
        private static bool _isVisible = true;
        private static CursorMode _mode = CursorMode.Normal;
        
        // Drawing state
        private static bool _isDrawing = false;
        private static List<Vector2> _drawPath = new List<Vector2>();
        
        // Animation
        private static bool _isRigging = false;
        private static List<BonePoint> _rigPoints = new List<BonePoint>();

        static AdvancedCursor()
        {
            InitializeCursors();
        }

        private static void InitializeCursors()
        {
            // Standard cursors
            _cursors[CursorType.Arrow] = new CursorData { Name = "Arrow", HotspotX = 0, HotspotY = 0 };
            _cursors[CursorType.Hand] = new CursorData { Name = "Hand", HotspotX = 8, HotspotY = 0 };
            _cursors[CursorType.IBeam] = new CursorData { Name = "IBeam", HotspotX = 8, HotspotY = 8 };
            _cursors[CursorType.Crosshair] = new CursorData { Name = "Crosshair", HotspotX = 8, HotspotY = 8 };
            _cursors[CursorType.ResizeNS] = new CursorData { Name = "ResizeNS", HotspotX = 8, HotspotY = 8 };
            _cursors[CursorType.ResizeEW] = new CursorData { Name = "ResizeEW", HotspotX = 8, HotspotY = 8 };
            _cursors[CursorType.ResizeNESW] = new CursorData { Name = "ResizeNESW", HotspotX = 8, HotspotY = 8 };
            _cursors[CursorType.ResizeNWSE] = new CursorData { Name = "ResizeNWSE", HotspotX = 8, HotspotY = 8 };
            
            // Special tool cursors
            _cursors[CursorType.Pencil] = new CursorData { Name = "Pencil", HotspotX = 2, HotspotY = 14 };
            _cursors[CursorType.Brush] = new CursorData { Name = "Brush", HotspotX = 8, HotspotY = 8 };
            _cursors[CursorType.Eraser] = new CursorData { Name = "Eraser", HotspotX = 8, HotspotY = 8 };
            _cursors[CursorType.Eyedropper] = new CursorData { Name = "Eyedropper", HotspotX = 2, HotspotY = 14 };
            _cursors[CursorType.PaintBucket] = new CursorData { Name = "PaintBucket", HotspotX = 4, HotspotY = 12 };
            _cursors[CursorType.Move] = new CursorData { Name = "Move", HotspotX = 8, HotspotY = 8 };
            _cursors[CursorType.Rotate] = new CursorData { Name = "Rotate", HotspotX = 8, HotspotY = 8 };
            _cursors[CursorType.Scale] = new CursorData { Name = "Scale", HotspotX = 8, HotspotY = 8 };
        }

        // ================ CURSOR MANAGEMENT ================

        public static void SetCursor(CursorType type)
        {
            if (_currentCursor != type)
            {
                _currentCursor = type;
                ApplyCursor();
            }
        }

        public static void SetMode(CursorMode mode)
        {
            _mode = mode;
            
            switch (mode)
            {
                case CursorMode.Drawing:
                    SetCursor(CursorType.Pencil);
                    _isDrawing = true;
                    break;
                case CursorMode.Rigging:
                    SetCursor(CursorType.Crosshair);
                    _isRigging = true;
                    break;
                case CursorMode.Animation:
                    SetCursor(CursorType.Move);
                    break;
                default:
                    SetCursor(CursorType.Arrow);
                    _isDrawing = false;
                    _isRigging = false;
                    break;
            }
        }

        public static void Show() => _isVisible = true;
        public static void Hide() => _isVisible = false;

        public static void Update()
        {
            Vector2 newPos = Input.GetMousePosition();
            _delta = newPos - _position;
            _position = newPos;

            // Handle drawing mode
            if (_isDrawing && Input.GetMouseButton(MouseButton.Left))
            {
                _drawPath.Add(_position);
            }
            else if (_isDrawing && Input.GetMouseButtonUp(MouseButton.Left))
            {
                FinalizeDraw();
            }

            // Handle rigging mode
            if (_isRigging && Input.GetMouseButtonDown(MouseButton.Left))
            {
                AddRigPoint(_position);
            }

            // Handle scroll for tools
            float scroll = Input.GetMouseScroll();
            if (Math.Abs(scroll) > 0.01f)
            {
                OnScroll(scroll);
            }

            // Right-click drag
            if (Input.GetMouseButton(MouseButton.Right))
            {
                OnDrag(_delta);
            }
        }

        // ================ DRAWING FEATURES ================

        private static void FinalizeDraw()
        {
            if (_drawPath.Count > 1)
            {
                Console.WriteLine($"[Cursor] Drew path with {_drawPath.Count} points");
                // Process draw path (create sprite, apply to texture, etc.)
            }
            _drawPath.Clear();
        }

        private static void AddRigPoint(Vector2 position)
        {
            var point = new BonePoint
            {
                Position = position,
                Index = _rigPoints.Count
            };
            _rigPoints.Add(point);
            Console.WriteLine($"[Cursor] Added rig point {point.Index} at {position}");
        }

        // ================ TOOL ACTIONS ================

        private static void OnScroll(float delta)
        {
            switch (_mode)
            {
                case CursorMode.Drawing:
                    // Adjust brush size
                    Console.WriteLine($"[Cursor] Brush size change: {delta}");
                    break;
                case CursorMode.Animation:
                    // Scrub timeline
                    Console.WriteLine($"[Cursor] Timeline scrub: {delta}");
                    break;
            }
        }

        private static void OnDrag(Vector2 delta)
        {
            switch (_mode)
            {
                case CursorMode.Normal:
                    // Pan view
                    Console.WriteLine($"[Cursor] Pan: {delta}");
                    break;
                case CursorMode.Rigging:
                    // Move rig point
                    Console.WriteLine($"[Cursor] Move rig: {delta}");
                    break;
            }
        }

        private static void ApplyCursor()
        {
            // Apply cursor to window (platform-specific)
            Console.WriteLine($"[Cursor] Changed to: {_currentCursor}");
        }

        // ================ PUBLIC API ================

        public static Vector2 GetPosition() => _position;
        public static Vector2 GetDelta() => _delta;
        public static CursorType GetCurrentCursor() => _currentCursor;
        public static bool IsVisible() => _isVisible;
        public static List<Vector2> GetDrawPath() => new List<Vector2>(_drawPath);
        public static List<BonePoint> GetRigPoints() => new List<BonePoint>(_rigPoints);
        public static void ClearDrawPath() => _drawPath.Clear();
        public static void ClearRigPoints() => _rigPoints.Clear();
    }

    // ================ ENUMS & DATA CLASSES ================

    public enum CursorType
    {
        Arrow,
        Hand,
        IBeam,
        Crosshair,
        ResizeNS,
        ResizeEW,
        ResizeNESW,
        ResizeNWSE,
        Pencil,
        Brush,
        Eraser,
        Eyedropper,
        PaintBucket,
        Move,
        Rotate,
        Scale,
        Custom
    }

    public enum CursorMode
    {
        Normal,
        Drawing,
        Rigging,
        Animation,
        Modeling
    }

    public class CursorData
    {
        public string Name { get; set; }
        public int HotspotX { get; set; }
        public int HotspotY { get; set; }
        public byte[] ImageData { get; set; }
    }

    public class BonePoint
    {
        public Vector2 Position { get; set; }
        public int Index { get; set; }
        public BonePoint Parent { get; set; }
        public List<BonePoint> Children { get; set; } = new List<BonePoint>();
    }
}
