# BADGE Engine v10 — Mega Fixed Edition
> **v10 Mega Fixed Edition** — All scripts completed, all stubs replaced, all "unusual" systems normalized.

## Basic Atlas Dimensional Game Engine

**Created by Frederick Atiase Kodjo Eli (Fake)**  
**Atlas Network Club**

---

BADGE is a full-featured, solo-built C# game engine. Not a prototype. Not a demo. The real deal.

### Minimum Spec
| Component | Minimum |
|-----------|---------|
| CPU | Intel Pentium / AMD equivalent, dual-core |
| RAM | **4 GB** — This is the design target |
| GPU | OpenGL 3.3 (Intel HD integrated supported) |
| OS  | Windows 10 / Ubuntu 20.04 / macOS 11+ |
| Disk | 500 MB |

BADGE is engineered to run smoothly on this hardware. If it lags on 4 GB, that is a bug. This engine does not have that bug.

---

### What Is New in v8
- ThemeSystem: Dark, Light, High Contrast, Ocean, Forest, Sunset, Midnight, Nord, Dracula, Monokai, Solarized Dark, + Theme Editor
- AudioTab: Complete DAW with Arrange, Mixer, Piano Roll, Step Sequencer, Effects Rack (18 effect types), File I/O
- DesignTab: Full image processing, Curves, Levels, 15 filters, Dithering, all blend modes, import/export
- G3DPTab: Blender-style mesh editor with Edit Mode, Modifier Stack, UV Editor, Material Slots, LOD Generation
- NotesSystem: Delta-time journaling, Todo lists, Journey Log, 4-format export
- FileManager: Unified asset library for all editors, hot-reload, ZIP package import/export/extract
- PerformanceProfile: Hardware tier auto-detection and optimisation (Minimum=Pentium 4GB target)
- ImageProcessing: 40+ software image processing operations
- Complete Manual: Full Word document covering every system, API, troubleshooting, credits

### Quick Start
```
dotnet BADGE.dll
```

### Acknowledgements
Unity Technologies, Notch/Minecraft, Hatcher's Studio, YouTube, GitHub, ChatGPT

---
Atlas Network Club — Frederick Atiase Kodjo Eli (Fake)
BADGE Engine v9.0

---

## v9 Fix Log

### Bugs Fixed
- **CS0101 compile error**: `CrashRecovery` was defined twice in `BADGE.Core` namespace (in `PerformanceManager.cs` and `EventBusSaveSystems.cs`). The duplicate stub has been removed; the complete implementation in `PerformanceManager.cs` is the canonical version.
- **CS0101 compile error**: `Physics2D` class was defined twice in `BADGE.Physics` namespace (`Physics2D.cs` and `Physics2D_old.cs`). `Physics2D_old.cs` is now excluded from compilation via `.csproj`.
- **Build failure**: Two `.csproj` files (`BADGE.csproj` and `BADGE_Engine_v7.csproj`) existed in the same directory, causing `dotnet build` to fail with MSB1011. The stale v7 file has been removed.
- **Cross-platform `OutputType`**: Changed from `WinExe` to `Exe` so the engine builds and runs on Linux and macOS (not just Windows).
- **Engine boot step numbering**: Steps counted as `[1/7]`…`[5/7]` then jumped to `[6/9]`. Now consistently `[1/9]`…`[9/9]`.
- **Version doc inconsistency**: `IMPROVEMENTS.md` incorrectly labelled the engine as "v1.5". Fixed to "v8".

### Improvements Added
- `BADGE_Engine.sln` — Visual Studio / Rider solution file for IDE project loading.
- `.gitignore` — covers build output, IDE files, NuGet cache, OS junk.
- `<RuntimeIdentifiers>` — added to `BADGE.csproj` so `dotnet publish -r win-x64|linux-x64|osx-x64` works out of the box.
- `<GenerateDocumentationFile>` — XML IntelliSense docs now generated on build.
