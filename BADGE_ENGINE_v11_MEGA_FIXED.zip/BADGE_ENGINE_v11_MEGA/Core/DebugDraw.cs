using System;
using System.Collections.Generic;
using OpenTK.Mathematics;
using OpenTK.Graphics.OpenGL4;
using BADGE.Core;

namespace BADGE.Core
{
    /// <summary>
    /// Runtime debug visualiser — draw lines, boxes, spheres, rays, and text
    /// in world space for a single frame without allocating GameObjects.
    ///
    /// Usage (call anywhere in Update/OnDrawGizmos):
    ///   DebugDraw.Line(from, to, Color4.Red);
    ///   DebugDraw.Box(center, halfExtents, Color4.Yellow);
    ///   DebugDraw.Sphere(center, radius, Color4.Green);
    ///   DebugDraw.Ray(origin, direction * 10f, Color4.Cyan);
    ///   DebugDraw.Text(worldPos, "HP: 100", Color4.White);
    ///
    /// The engine calls DebugDraw.Flush(view, proj) once per frame in Render().
    /// Everything is cleared automatically — no cleanup needed.
    /// Disable in Release builds: DebugDraw.Enabled = false.
    /// </summary>
    public static class DebugDraw
    {
        // ── Config ────────────────────────────────────────────────────────
        public static bool   Enabled    { get; set; } = true;
        public static float  LineWidth  { get; set; } = 1.5f;
        public static int    SphereSeg  { get; set; } = 16;

        // ── Internal buffers (cleared each frame) ─────────────────────────
        private static readonly List<LineEntry>  _lines   = new(256);
        private static readonly List<TextEntry>  _texts   = new(64);
        private static bool _glReady;
        private static int  _vao, _vbo, _shaderProg;

        // ── Draw API ──────────────────────────────────────────────────────

        public static void Line(Vector3 a, Vector3 b, Color4 color, float duration = 0f)
        {
            if (!Enabled) return;
            _lines.Add(new LineEntry(a, b, color));
        }

        public static void Ray(Vector3 origin, Vector3 direction, Color4 color)
            => Line(origin, origin + direction, color);

        public static void Box(Vector3 center, Vector3 halfExtents,
                                Color4 color, Quaternion? rotation = null)
        {
            if (!Enabled) return;
            var r = rotation ?? Quaternion.Identity;
            // 8 corners
            Vector3[] c =
            {
                center + r * new Vector3(-halfExtents.X, -halfExtents.Y, -halfExtents.Z),
                center + r * new Vector3( halfExtents.X, -halfExtents.Y, -halfExtents.Z),
                center + r * new Vector3( halfExtents.X, -halfExtents.Y,  halfExtents.Z),
                center + r * new Vector3(-halfExtents.X, -halfExtents.Y,  halfExtents.Z),
                center + r * new Vector3(-halfExtents.X,  halfExtents.Y, -halfExtents.Z),
                center + r * new Vector3( halfExtents.X,  halfExtents.Y, -halfExtents.Z),
                center + r * new Vector3( halfExtents.X,  halfExtents.Y,  halfExtents.Z),
                center + r * new Vector3(-halfExtents.X,  halfExtents.Y,  halfExtents.Z),
            };
            // Bottom face
            Line(c[0],c[1],color); Line(c[1],c[2],color); Line(c[2],c[3],color); Line(c[3],c[0],color);
            // Top face
            Line(c[4],c[5],color); Line(c[5],c[6],color); Line(c[6],c[7],color); Line(c[7],c[4],color);
            // Pillars
            Line(c[0],c[4],color); Line(c[1],c[5],color); Line(c[2],c[6],color); Line(c[3],c[7],color);
        }

        public static void Sphere(Vector3 center, float radius, Color4 color)
        {
            if (!Enabled) return;
            DrawCircle(center, radius, Vector3.UnitX, Vector3.UnitY, color);
            DrawCircle(center, radius, Vector3.UnitY, Vector3.UnitZ, color);
            DrawCircle(center, radius, Vector3.UnitX, Vector3.UnitZ, color);
        }

        public static void Capsule(Vector3 bottom, Vector3 top, float radius, Color4 color)
        {
            if (!Enabled) return;
            Vector3 mid = (top + bottom) * 0.5f;
            float h = (top - bottom).Length * 0.5f;
            Line(bottom - new Vector3(radius,0,0), top - new Vector3(radius,0,0), color);
            Line(bottom + new Vector3(radius,0,0), top + new Vector3(radius,0,0), color);
            Line(bottom - new Vector3(0,0,radius), top - new Vector3(0,0,radius), color);
            Line(bottom + new Vector3(0,0,radius), top + new Vector3(0,0,radius), color);
            DrawCircle(bottom, radius, Vector3.UnitX, Vector3.UnitZ, color);
            DrawCircle(top,    radius, Vector3.UnitX, Vector3.UnitZ, color);
        }

        public static void Cross(Vector3 center, float size, Color4 color)
        {
            if (!Enabled) return;
            var h = new Vector3(size, 0, 0);
            var v = new Vector3(0, size, 0);
            var d = new Vector3(0, 0, size);
            Line(center - h, center + h, color);
            Line(center - v, center + v, color);
            Line(center - d, center + d, color);
        }

        public static void Arrow(Vector3 from, Vector3 to, Color4 color)
        {
            if (!Enabled) return;
            Line(from, to, color);
            var dir  = Vector3.Normalize(to - from);
            var perp = Vector3.Normalize(Vector3.Cross(dir,
                MathF.Abs(dir.Y) < 0.9f ? Vector3.UnitY : Vector3.UnitX));
            float headLen = (to - from).Length * 0.15f;
            Line(to, to - dir * headLen + perp * headLen * 0.4f, color);
            Line(to, to - dir * headLen - perp * headLen * 0.4f, color);
        }

        public static void Grid(Vector3 center, float size, int divisions, Color4 color)
        {
            if (!Enabled) return;
            float step = size / divisions;
            float half = size * 0.5f;
            for (int i = 0; i <= divisions; i++)
            {
                float p = -half + i * step;
                Line(center + new Vector3(p, 0, -half), center + new Vector3(p, 0, half), color);
                Line(center + new Vector3(-half, 0, p), center + new Vector3(half, 0, p), color);
            }
        }

        public static void Frustum(Matrix4 invVP, Color4 color)
        {
            if (!Enabled) return;
            // NDC corners
            Vector4[] ndc =
            {
                new(-1,-1,-1,1), new(1,-1,-1,1), new(1,1,-1,1), new(-1,1,-1,1),  // near
                new(-1,-1, 1,1), new(1,-1, 1,1), new(1,1, 1,1), new(-1,1, 1,1),  // far
            };
            var w = new Vector3[8];
            for (int i = 0; i < 8; i++)
            {
                var v = invVP * ndc[i];
                w[i]  = new Vector3(v.X, v.Y, v.Z) / v.W;
            }
            for (int i = 0; i < 4; i++)
            {
                Line(w[i], w[(i+1)%4], color);
                Line(w[i+4], w[(i+1)%4+4], color);
                Line(w[i], w[i+4], color);
            }
        }

        public static void Text(Vector3 worldPos, string message, Color4 color)
        {
            if (!Enabled) return;
            _texts.Add(new TextEntry(worldPos, message, color));
        }

        // ── Internal ──────────────────────────────────────────────────────

        private static void DrawCircle(Vector3 center, float radius,
                                        Vector3 axisA, Vector3 axisB, Color4 color)
        {
            int segs = SphereSeg;
            Vector3? prev = null;
            for (int i = 0; i <= segs; i++)
            {
                float angle = BMath.TAU * i / segs;
                var   pt    = center + (axisA * MathF.Cos(angle) + axisB * MathF.Sin(angle)) * radius;
                if (prev.HasValue) Line(prev.Value, pt, color);
                prev = pt;
            }
        }

        // ── Engine calls this once per frame in Render() ──────────────────
        public static void Flush(Matrix4 view, Matrix4 projection)
        {
            if (!Enabled || _lines.Count == 0) return;

            EnsureGL();
            GL.Disable(EnableCap.DepthTest);
            GL.LineWidth(LineWidth);
            GL.UseProgram(_shaderProg);

            var vp = view * projection;
            int vpLoc = GL.GetUniformLocation(_shaderProg, "uVP");
            GL.UniformMatrix4(vpLoc, false, ref vp);

            // Pack line data: 2 verts per line × 6 floats (xyz rgb)
            int  vertCount = _lines.Count * 2;
            var  data      = new float[vertCount * 6];
            int  di        = 0;

            foreach (var l in _lines)
            {
                data[di++] = l.A.X; data[di++] = l.A.Y; data[di++] = l.A.Z;
                data[di++] = l.Color.R; data[di++] = l.Color.G; data[di++] = l.Color.B;
                data[di++] = l.B.X; data[di++] = l.B.Y; data[di++] = l.B.Z;
                data[di++] = l.Color.R; data[di++] = l.Color.G; data[di++] = l.Color.B;
            }

            GL.BindVertexArray(_vao);
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
            GL.BufferData(BufferTarget.ArrayBuffer, data.Length * 4, data,
                           BufferUsageHint.DynamicDraw);
            GL.DrawArrays(PrimitiveType.Lines, 0, vertCount);
            GL.BindVertexArray(0);
            GL.UseProgram(0);
            GL.Enable(EnableCap.DepthTest);

            _lines.Clear();
            _texts.Clear();
        }

        private static void EnsureGL()
        {
            if (_glReady) return;
            _glReady = true;

            string vert = @"#version 330 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aColor;
uniform mat4 uVP;
out vec3 vColor;
void main() { gl_Position = uVP * vec4(aPos,1.0); vColor = aColor; }";

            string frag = @"#version 330 core
in vec3 vColor;
out vec4 FragColor;
void main() { FragColor = vec4(vColor, 1.0); }";

            int vs = GL.CreateShader(ShaderType.VertexShader);
            GL.ShaderSource(vs, vert);
            GL.CompileShader(vs);

            int fs = GL.CreateShader(ShaderType.FragmentShader);
            GL.ShaderSource(fs, frag);
            GL.CompileShader(fs);

            _shaderProg = GL.CreateProgram();
            GL.AttachShader(_shaderProg, vs);
            GL.AttachShader(_shaderProg, fs);
            GL.LinkProgram(_shaderProg);
            GL.DeleteShader(vs);
            GL.DeleteShader(fs);

            _vao = GL.GenVertexArray();
            _vbo = GL.GenBuffer();
            GL.BindVertexArray(_vao);
            GL.BindBuffer(BufferTarget.ArrayBuffer, _vbo);
            GL.BufferData(BufferTarget.ArrayBuffer, 1024 * 1024, IntPtr.Zero,
                           BufferUsageHint.DynamicDraw);
            // pos
            GL.EnableVertexAttribArray(0);
            GL.VertexAttribPointer(0, 3, VertexAttribPointerType.Float, false, 24, 0);
            // color
            GL.EnableVertexAttribArray(1);
            GL.VertexAttribPointer(1, 3, VertexAttribPointerType.Float, false, 24, 12);
            GL.BindVertexArray(0);
        }

        // ── Data types ────────────────────────────────────────────────────
        private readonly struct LineEntry
        {
            public readonly Vector3 A, B;
            public readonly Color4  Color;
            public LineEntry(Vector3 a, Vector3 b, Color4 c) { A=a; B=b; Color=c; }
        }

        private readonly struct TextEntry
        {
            public readonly Vector3 WorldPos;
            public readonly string  Message;
            public readonly Color4  Color;
            public TextEntry(Vector3 p, string m, Color4 c) { WorldPos=p; Message=m; Color=c; }
        }
    }
}
