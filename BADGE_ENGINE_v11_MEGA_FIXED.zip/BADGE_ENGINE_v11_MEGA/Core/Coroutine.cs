using System;
using System.Collections;
using System.Collections.Generic;

namespace BADGE.Core;

// ═══════════════════════════════════════════════════════════════════════
//  YIELD INSTRUCTIONS  (mirrors Unity's API)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>Base class for coroutine yield instructions.</summary>
public abstract class YieldInstruction
{
    /// <summary>Returns true when the instruction is complete and the coroutine should resume.</summary>
    internal abstract bool IsDone(float dt);
}

/// <summary>Waits a given number of real seconds.</summary>
public class WaitForSeconds : YieldInstruction
{
    private float _remaining;
    public WaitForSeconds(float seconds) => _remaining = seconds;
    internal override bool IsDone(float dt) { _remaining -= dt; return _remaining <= 0f; }
}

/// <summary>Waits until the end of the current frame.</summary>
public class WaitForEndOfFrame : YieldInstruction
{
    private bool _done = false;
    internal override bool IsDone(float dt) { if (_done) return true; _done = true; return false; }
}

/// <summary>Waits until the predicate returns true.</summary>
public class WaitUntil : YieldInstruction
{
    private readonly Func<bool> _predicate;
    public WaitUntil(Func<bool> predicate) => _predicate = predicate;
    internal override bool IsDone(float dt) => _predicate();
}

/// <summary>Waits while the predicate returns true.</summary>
public class WaitWhile : YieldInstruction
{
    private readonly Func<bool> _predicate;
    public WaitWhile(Func<bool> predicate) => _predicate = predicate;
    internal override bool IsDone(float dt) => !_predicate();
}

/// <summary>Yield return null — advance exactly one frame.</summary>
public class WaitForFrame : YieldInstruction
{
    private bool _waited = false;
    internal override bool IsDone(float dt) { if (_waited) return true; _waited = true; return false; }
}

// ═══════════════════════════════════════════════════════════════════════
//  COROUTINE HANDLE
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Handle returned from StartCoroutine — can be passed to StopCoroutine.
/// </summary>
public class Coroutine
{
    internal IEnumerator Enumerator { get; }
    internal bool        IsDone     { get; private set; }
    internal YieldInstruction? CurrentInstruction { get; private set; }

    internal Coroutine(IEnumerator enumerator) => Enumerator = enumerator;

    /// <summary>Step one yield — returns false when the coroutine is finished.</summary>
    internal bool Step(float dt)
    {
        // If waiting on a yield instruction, check if it's done
        if (CurrentInstruction != null)
        {
            if (!CurrentInstruction.IsDone(dt)) return true;  // still waiting
            CurrentInstruction = null;
        }

        // Advance the iterator
        if (!Enumerator.MoveNext())
        {
            IsDone = true;
            return false;
        }

        // Grab the new yield value
        var yielded = Enumerator.Current;

        CurrentInstruction = yielded switch
        {
            YieldInstruction yi => yi,
            null               => new WaitForFrame(),
            _                  => null
        };

        return true;
    }

    internal void Stop() => IsDone = true;
}

// ═══════════════════════════════════════════════════════════════════════
//  COROUTINE RUNNER  (singleton, driven by the engine each frame)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Global coroutine scheduler.
/// NEW: Was completely absent. LUMINOUS had to replace every coroutine
///      with manual float timers. This system restores the coroutine pattern.
/// </summary>
public static class CoroutineRunner
{
    private static readonly List<Coroutine> _running   = new();
    private static readonly List<Coroutine> _toAdd     = new();
    private static readonly List<Coroutine> _toRemove  = new();

    /// <summary>Start a coroutine (IEnumerator method).</summary>
    public static Coroutine Start(IEnumerator routine)
    {
        var c = new Coroutine(routine);
        _toAdd.Add(c);
        return c;
    }

    /// <summary>Stop a running coroutine.</summary>
    public static void Stop(Coroutine? coroutine)
    {
        if (coroutine == null) return;
        coroutine.Stop();
        _toRemove.Add(coroutine);
    }

    /// <summary>Stop all coroutines.</summary>
    public static void StopAll()
    {
        foreach (var c in _running) c.Stop();
        _running.Clear();
        _toAdd.Clear();
        _toRemove.Clear();
    }

    /// <summary>Called by the engine each frame.</summary>
    public static void Tick(float dt)
    {
        // Flush additions
        _running.AddRange(_toAdd);
        _toAdd.Clear();

        // Step all coroutines
        foreach (var c in _running)
        {
            if (!c.IsDone && !c.Step(dt))
                _toRemove.Add(c);
        }

        // Remove finished / stopped
        foreach (var c in _toRemove)
            _running.Remove(c);
        _toRemove.Clear();
    }

    public static int RunningCount => _running.Count;
}
