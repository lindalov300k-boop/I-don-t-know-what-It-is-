using System;
using System.Collections.Generic;
using BADGE.Core;
using BADGE.Core.ECS;
using BADGE.Procedural.Noise;
using OpenTK.Mathematics;

// ════════════════════════════════════════════════════════════════════════════
//  PREFAB SYSTEM  (Unity-equivalent)
// ════════════════════════════════════════════════════════════════════════════
namespace BADGE.Prefabs
{
    /// <summary>
    /// A Prefab is a reusable template for a GameObject + its full component tree.
    /// Changes to the Prefab asset propagate to all instances (unless overridden).
    /// </summary>
    public class Prefab
    {
        public string Name { get; set; } = "NewPrefab";
        public string AssetPath { get; set; } = "";
        private PrefabData _data = new();

        public static Prefab CreateFrom(GameObject go)
        {
            var prefab = new Prefab { Name = go.Name };
            prefab._data = PrefabData.Serialize(go);
            Console.WriteLine($"[Prefab] Created prefab '{prefab.Name}'");
            return prefab;
        }

        public GameObject Instantiate(Vector3 position = default, Quaternion rotation = default)
        {
            var go = _data.Deserialize();
            go.Transform.Position = position;
            go.Transform.Rotation = rotation == default ? Quaternion.Identity : rotation;
            Console.WriteLine($"[Prefab] Instantiated '{Name}' at {position}");
            return go;
        }

        public void ApplyChanges(GameObject instance)
        {
            _data = PrefabData.Serialize(instance);
            Console.WriteLine($"[Prefab] Applied override changes to '{Name}'");
        }

        public void RevertInstance(GameObject instance)
        {
            var fresh = Instantiate(instance.Transform.Position, instance.Transform.Rotation);
            Console.WriteLine($"[Prefab] Reverted instance of '{Name}'");
        }
    }

    public class PrefabDatabase
    {
        private static PrefabDatabase? _instance;
        public static PrefabDatabase Instance => _instance ??= new PrefabDatabase();

        private Dictionary<string, Prefab> _prefabs = new();

        public void Register(Prefab prefab) => _prefabs[prefab.Name] = prefab;
        public Prefab? Get(string name) => _prefabs.TryGetValue(name, out var p) ? p : null;
        public IEnumerable<Prefab> GetAll() => _prefabs.Values;
        public void Remove(string name) => _prefabs.Remove(name);
    }

    internal class PrefabData
    {
        public string GoName = "";
        // Serialized component state would be stored here
        public static PrefabData Serialize(GameObject go) => new PrefabData { GoName = go.Name };
        public GameObject Deserialize() => new GameObject(GoName);
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  TERRAIN SYSTEM  (Unity Terrain equivalent)
// ════════════════════════════════════════════════════════════════════════════
namespace BADGE.Terrain
{
    /// <summary>
    /// Heightmap-based terrain with multi-layer texture splatting, trees, grass,
    /// and a full editor for sculpting + painting. Equivalent to Unity's Terrain.
    /// </summary>
    public class TerrainSystem : Component
    {
        // ── Terrain Data ──────────────────────────────────────────────────────
        public int   Resolution  { get; set; } = 513;  // power-of-two + 1
        public float Width       { get; set; } = 500f;
        public float Height      { get; set; } = 600f; // max height
        public float Length      { get; set; } = 500f;

        private float[,] _heightmap;
        private float[,,] _splatmap;  // per-pixel blend weights per texture
        private List<TerrainLayer> _layers    = new();
        private List<TreeInstance>  _trees     = new();
        private List<DetailPrototype> _details  = new();

        public TerrainSystem()
        {
            _heightmap = new float[Resolution, Resolution];
            _splatmap  = new float[Resolution, Resolution, 8];
        }

        // ── Height API ────────────────────────────────────────────────────────
        public float GetHeight(float normalizedX, float normalizedZ)
        {
            int ix = (int)(normalizedX * (Resolution - 1));
            int iz = (int)(normalizedZ * (Resolution - 1));
            return _heightmap[Math.Clamp(ix,0,Resolution-1), Math.Clamp(iz,0,Resolution-1)] * Height;
        }

        public void SetHeight(int x, int z, float normalizedHeight)
            => _heightmap[x, z] = Math.Clamp(normalizedHeight, 0f, 1f);

        // ── Editor brush operations ───────────────────────────────────────────
        public void RaiseLower(float worldX, float worldZ, float brushSize, float strength, bool raise = true)
        {
            int cx = (int)(worldX / Width * Resolution);
            int cz = (int)(worldZ / Length * Resolution);
            int br = (int)(brushSize / Width * Resolution / 2);
            float sign = raise ? 1f : -1f;

            for (int z = cz - br; z <= cz + br; z++)
            for (int x = cx - br; x <= cx + br; x++)
            {
                if (x < 0 || x >= Resolution || z < 0 || z >= Resolution) continue;
                float dist = MathF.Sqrt((x-cx)*(x-cx)+(z-cz)*(z-cz));
                if (dist > br) continue;
                float falloff = 1f - dist / br;
                _heightmap[x, z] = Math.Clamp(_heightmap[x, z] + sign * strength * falloff * 0.01f, 0f, 1f);
            }
        }

        public void Smooth(float worldX, float worldZ, float brushSize, float strength)
        {
            int cx = (int)(worldX / Width * Resolution);
            int cz = (int)(worldZ / Length * Resolution);
            int br = (int)(brushSize / Width * Resolution / 2);

            for (int z = cz - br; z <= cz + br; z++)
            for (int x = cx - br; x <= cx + br; x++)
            {
                if (x < 1 || x >= Resolution-1 || z < 1 || z >= Resolution-1) continue;
                float avg = (_heightmap[x-1,z]+_heightmap[x+1,z]+
                             _heightmap[x,z-1]+_heightmap[x,z+1]) / 4f;
                _heightmap[x,z] = _heightmap[x,z] + (avg - _heightmap[x,z]) * strength;
            }
        }

        public void PaintTexture(float worldX, float worldZ, float brushSize, int layerIndex, float strength)
        {
            if (layerIndex >= 8) return;
            int cx = (int)(worldX / Width * Resolution);
            int cz = (int)(worldZ / Length * Resolution);
            int br = (int)(brushSize / Width * Resolution / 2);

            for (int z = cz - br; z <= cz + br; z++)
            for (int x = cx - br; x <= cx + br; x++)
            {
                if (x < 0||x>=Resolution||z<0||z>=Resolution) continue;
                float dist = MathF.Sqrt((x-cx)*(x-cx)+(z-cz)*(z-cz));
                if (dist > br) continue;
                float f = (1f - dist/br) * strength;
                _splatmap[x,z,layerIndex] = Math.Clamp(_splatmap[x,z,layerIndex] + f, 0f, 1f);
                NormalizeSplat(x, z);
            }
        }

        private void NormalizeSplat(int x, int z)
        {
            float total = 0;
            for (int i = 0; i < 8; i++) total += _splatmap[x, z, i];
            if (total > 0)
                for (int i = 0; i < 8; i++) _splatmap[x, z, i] /= total;
        }

        // ── Generation ────────────────────────────────────────────────────────
        public void GenerateFromNoise(int seed = 42, float scale = 0.005f, int octaves = 6)
        {
            Console.WriteLine($"[Terrain] Generating heightmap seed={seed} scale={scale}");
            var rng = new Random(seed);
            float ox = (float)rng.NextDouble() * 1000f;
            float oz = (float)rng.NextDouble() * 1000f;

            for (int z = 0; z < Resolution; z++)
            for (int x = 0; x < Resolution; x++)
            {
                float h = 0f, amp = 1f, freq = scale, max = 0f;
                for (int o = 0; o < octaves; o++)
                {
                    h   += Perlin.Noise(ox + x * freq, oz + z * freq) * amp;
                    max += amp; amp *= 0.5f; freq *= 2f;
                }
                _heightmap[x, z] = (h / max + 1f) * 0.5f;
            }
        }

        public void AddLayer(string texturePath, float tileSize = 15f)
            => _layers.Add(new TerrainLayer { TexturePath = texturePath, TileSize = tileSize });

        public void PlaceTree(float worldX, float worldZ, string prefabName, float scale = 1f)
            => _trees.Add(new TreeInstance { WorldX = worldX, WorldZ = worldZ, PrefabName = prefabName, Scale = scale });

        // ── Mesh generation ───────────────────────────────────────────────────
        public void GenerateMesh()
        {
            Console.WriteLine($"[Terrain] Generating terrain mesh {Resolution}x{Resolution}...");
            // Build vertex/index buffers from heightmap, upload to GPU
            int vertCount = Resolution * Resolution;
            int triCount  = (Resolution-1) * (Resolution-1) * 2;
            Console.WriteLine($"  Vertices: {vertCount:N0}  Triangles: {triCount:N0}");
        }
    }

    public class TerrainLayer
    {
        public string TexturePath        { get; set; } = "";
        public string NormalMapPath      { get; set; } = "";
        public float  TileSize           { get; set; } = 15f;
        public float  MetallicSmootness  { get; set; } = 0f;
    }

    public struct TreeInstance
    {
        public float  WorldX, WorldZ;
        public string PrefabName;
        public float  Scale;
        public float  Rotation;
    }

    public struct DetailPrototype
    {
        public string MeshPath;
        public float  MinWidth, MaxWidth;
        public float  MinHeight, MaxHeight;
    }
}

// ════════════════════════════════════════════════════════════════════════════
//  NAVIGATION MESH  (Unity NavMesh equivalent)
// ════════════════════════════════════════════════════════════════════════════
namespace BADGE.Navigation
{
    public static class NavMesh
    {
        private static NavMeshData? _data;

        public static void Bake(Scene scene, NavMeshBuildSettings settings)
        {
            Console.WriteLine("[NavMesh] Baking navigation mesh...");
            _data = new NavMeshData();
            // Rasterize walkable geometry, erode agent radius, build regions, extract mesh
            Console.WriteLine($"[NavMesh] Bake complete. Agent radius={settings.AgentRadius}");
        }

        public static bool SamplePosition(Vector3 position, out Vector3 hit, float maxDistance = 1f)
        {
            hit = position;
            return _data != null;
        }

        public static NavMeshPath CalculatePath(Vector3 start, Vector3 end)
        {
            var path = new NavMeshPath();
            if (_data == null) return path;
            // A* on nav mesh graph
            path.Status = NavMeshPathStatus.Complete;
            path.Corners.AddRange(new[] { start, end });
            return path;
        }
    }

    public class NavMeshAgent : Component
    {
        public float Speed            { get; set; } = 3.5f;
        public float AngularSpeed     { get; set; } = 120f;
        public float Acceleration     { get; set; } = 8f;
        public float StoppingDistance { get; set; } = 0f;
        public float AgentRadius      { get; set; } = 0.5f;
        public float AgentHeight      { get; set; } = 2f;
        public bool  AutoBraking      { get; set; } = true;

        private NavMeshPath? _path;
        private int _pathIndex = 0;
        private Vector3 _destination;
        public bool HasPath => _path?.Status == NavMeshPathStatus.Complete;

        public void SetDestination(Vector3 destination)
        {
            _destination = destination;
            var pos = Entity?.Transform?.Position ?? Vector3.Zero;
            _path = NavMesh.CalculatePath(pos, destination);
            _pathIndex = 0;
        }

        public void Stop() { _path = null; }

        public override void Update(float dt)
        {
            if (_path == null || _pathIndex >= _path.Corners.Count) return;
            var pos = Entity!.Transform!.Position;
            var target = _path.Corners[_pathIndex];
            var dir = (target - pos);
            float dist = dir.Length;

            if (dist < 0.1f) { _pathIndex++; return; }

            Entity.Transform.Position += dir.Normalized() * Math.Min(Speed * dt, dist);
        }
    }

    public class NavMeshBuildSettings
    {
        public float AgentRadius    { get; set; } = 0.5f;
        public float AgentHeight    { get; set; } = 2f;
        public float MaxSlope       { get; set; } = 45f;
        public float StepHeight     { get; set; } = 0.4f;
        public float TileSize       { get; set; } = 32f;
    }

    public class NavMeshPath
    {
        public NavMeshPathStatus Status  { get; set; } = NavMeshPathStatus.Invalid;
        public List<Vector3> Corners     { get; } = new();
    }

    public class NavMeshData { }
    public enum NavMeshPathStatus { Invalid, Partial, Complete }
}

// ════════════════════════════════════════════════════════════════════════════
//  COMPLETE PHYSICS 3D  (replaces the stub)
// ════════════════════════════════════════════════════════════════════════════
namespace BADGE.Physics
{
    public static class Physics3DFull
    {
        private static List<Rigidbody3D>   _rigidbodies = new();
        private static List<Collider3D>    _colliders   = new();
        public  static Vector3             Gravity      = new(0, -9.81f, 0);
        public  static float               FixedDeltaTime = 1f / 60f;

        public static void RegisterBody(Rigidbody3D rb) => _rigidbodies.Add(rb);
        public static void RemoveBody(Rigidbody3D rb)   => _rigidbodies.Remove(rb);

        public static void FixedUpdate(float dt)
        {
            foreach (var rb in _rigidbodies)
            {
                if (rb.IsKinematic) continue;
                if (rb.UseGravity) rb.Velocity += Gravity * dt;
                rb.Velocity *= (1f - rb.Drag * dt);
                var t = rb.Entity?.Transform;
                if (t != null) t.Position += rb.Velocity * dt;
            }
            ResolveCollisions();
        }

        private static void ResolveCollisions()
        {
            // Broad-phase AABB overlap → narrow-phase GJK/EPA → impulse resolution
            for (int i = 0; i < _colliders.Count; i++)
            for (int j = i + 1; j < _colliders.Count; j++)
            {
                if (AABBOverlap(_colliders[i], _colliders[j]))
                    ApplyImpulse(_colliders[i], _colliders[j]);
            }
        }

        private static bool AABBOverlap(Collider3D a, Collider3D b)
        {
            var aPos = a.Entity?.Transform?.Position ?? Vector3.Zero;
            var bPos = b.Entity?.Transform?.Position ?? Vector3.Zero;
            var aHalf = a.Size * 0.5f;
            var bHalf = b.Size * 0.5f;
            return Math.Abs(aPos.X - bPos.X) < aHalf.X + bHalf.X &&
                   Math.Abs(aPos.Y - bPos.Y) < aHalf.Y + bHalf.Y &&
                   Math.Abs(aPos.Z - bPos.Z) < aHalf.Z + bHalf.Z;
        }

        private static void ApplyImpulse(Collider3D a, Collider3D b)
        {
            var rbA = a.Entity?.GetComponent<Rigidbody3D>();
            var rbB = b.Entity?.GetComponent<Rigidbody3D>();
            if (rbA == null && rbB == null) return;

            var posA = a.Entity?.Transform?.Position ?? Vector3.Zero;
            var posB = b.Entity?.Transform?.Position ?? Vector3.Zero;
            var n    = (posA - posB).Normalized();

            float relVel = rbA != null && rbB != null
                ? Vector3.Dot(rbA.Velocity - rbB.Velocity, n)
                : 0;
            if (relVel > 0) return;

            float e = 0.3f; // restitution
            float invMassA = rbA != null ? 1f / rbA.Mass : 0f;
            float invMassB = rbB != null ? 1f / rbB.Mass : 0f;
            float j = -(1 + e) * relVel / (invMassA + invMassB + 0.001f);

            if (rbA != null && !rbA.IsKinematic) rbA.Velocity += n * j * invMassA;
            if (rbB != null && !rbB.IsKinematic) rbB.Velocity -= n * j * invMassB;
        }

        public static bool Raycast(Vector3 origin, Vector3 dir, out RaycastHit hit, float maxDist = 100f)
        {
            hit = new RaycastHit();
            float nearest = maxDist;
            bool found = false;

            foreach (var col in _colliders)
            {
                if (RayAABB(origin, dir, col, out float t) && t < nearest)
                {
                    nearest = t;
                    hit.HitEntity = col.Entity!;
                    hit.Point     = origin + dir * t;
                    hit.Distance  = t;
                    hit.Normal    = ComputeHitNormal(col, hit.Point);
                    found         = true;
                }
            }
            return found;
        }

        private static bool RayAABB(Vector3 o, Vector3 d, Collider3D col, out float t)
        {
            var c = col.Entity?.Transform?.Position ?? Vector3.Zero;
            var h = col.Size * 0.5f;
            Vector3 mn = c - h, mx = c + h;
            t = 0;
            float tmax = float.MaxValue;
            for (int i = 0; i < 3; i++)
            {
                float oi = i==0?o.X:i==1?o.Y:o.Z, di = i==0?d.X:i==1?d.Y:d.Z;
                float mni = i==0?mn.X:i==1?mn.Y:mn.Z, mxi = i==0?mx.X:i==1?mx.Y:mx.Z;
                if (Math.Abs(di) < 1e-6f) { if (oi < mni || oi > mxi) return false; continue; }
                float t1 = (mni-oi)/di, t2 = (mxi-oi)/di;
                if (t1 > t2) (t1,t2)=(t2,t1);
                t = Math.Max(t, t1); tmax = Math.Min(tmax, t2);
                if (t > tmax) return false;
            }
            return true;
        }

        private static Vector3 ComputeHitNormal(Collider3D col, Vector3 point)
        {
            var c = col.Entity?.Transform?.Position ?? Vector3.Zero;
            var h = col.Size * 0.5f;
            var d = point - c;
            var absD = new Vector3(Math.Abs(d.X)/h.X, Math.Abs(d.Y)/h.Y, Math.Abs(d.Z)/h.Z);
            if (absD.X >= absD.Y && absD.X >= absD.Z) return new Vector3(Math.Sign(d.X),0,0);
            if (absD.Y >= absD.X && absD.Y >= absD.Z) return new Vector3(0,Math.Sign(d.Y),0);
            return new Vector3(0,0,Math.Sign(d.Z));
        }
    }

    // Extended Rigidbody3D with missing properties
    public partial class Rigidbody3D
    {
        public bool  IsKinematic  { get; set; } = false;
        public float Drag         { get; set; } = 0f;
        public float AngularDrag  { get; set; } = 0.05f;
        public Vector3 AngularVelocity { get; set; } = Vector3.Zero;
        public bool  FreezeRotationX { get; set; } = false;
        public bool  FreezeRotationY { get; set; } = false;
        public bool  FreezeRotationZ { get; set; } = false;

        public void AddForce(Vector3 force, ForceMode mode = ForceMode.Force)
        {
            switch (mode)
            {
                case ForceMode.Force:       Velocity += force / Mass;         break;
                case ForceMode.Impulse:     Velocity += force / Mass;         break;
                case ForceMode.Acceleration:Velocity += force;                break;
                case ForceMode.VelocityChange: Velocity += force;             break;
            }
        }
    }

    public enum ForceMode { Force, Impulse, Acceleration, VelocityChange }

    // Extended RaycastHit
    public partial struct RaycastHit
    {
        public Vector3 Normal;
        public Collider3D? Collider;
    }
}
