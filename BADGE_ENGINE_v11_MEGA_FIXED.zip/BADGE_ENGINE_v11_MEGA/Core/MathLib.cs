using System;
using OpenTK.Mathematics;

namespace BADGE.Core
{
    /// <summary>
    /// BADGE Math Library — fills the gap between raw System.Math / OpenTK.Mathematics
    /// and what a game engine actually needs every day.
    ///
    /// Covers: easing, interpolation, geometry, colour math, noise helpers,
    /// random utilities, and fast approximations.
    ///
    /// All methods are static and inlineable (no heap allocation).
    /// </summary>
    public static class BMath
    {
        // ── Constants ─────────────────────────────────────────────────────
        public const float PI        = MathF.PI;
        public const float TAU       = MathF.PI * 2f;
        public const float Deg2Rad   = MathF.PI / 180f;
        public const float Rad2Deg   = 180f / MathF.PI;
        public const float Epsilon   = 1e-6f;
        public const float GoldenRatio = 1.6180339887f;

        // ── Basic ─────────────────────────────────────────────────────────
        public static float Clamp(float v, float lo, float hi)
            => v < lo ? lo : v > hi ? hi : v;

        public static float Clamp01(float v) => Clamp(v, 0f, 1f);

        public static float Lerp(float a, float b, float t) => a + (b - a) * t;

        public static float LerpClamped(float a, float b, float t)
            => Lerp(a, b, Clamp01(t));

        public static float InverseLerp(float a, float b, float v)
            => MathF.Abs(b - a) < Epsilon ? 0f : (v - a) / (b - a);

        public static float Remap(float v, float inA, float inB, float outA, float outB)
            => Lerp(outA, outB, InverseLerp(inA, inB, v));

        public static float MoveTowards(float cur, float target, float step)
        {
            float d = target - cur;
            return MathF.Abs(d) <= step ? target : cur + MathF.Sign(d) * step;
        }

        public static float SmoothStep(float a, float b, float t)
        {
            t = Clamp01((t - a) / (b - a));
            return t * t * (3f - 2f * t);
        }

        public static float SmootherStep(float a, float b, float t)
        {
            t = Clamp01((t - a) / (b - a));
            return t * t * t * (t * (t * 6f - 15f) + 10f);
        }

        public static float PingPong(float t, float length)
        {
            t = Repeat(t, length * 2f);
            return length - MathF.Abs(t - length);
        }

        public static float Repeat(float t, float length)
            => t - MathF.Floor(t / length) * length;

        // ── Angles ────────────────────────────────────────────────────────
        public static float WrapAngle(float degrees)
        {
            degrees %= 360f;
            return degrees < 0f ? degrees + 360f : degrees;
        }

        public static float DeltaAngle(float from, float to)
        {
            float d = WrapAngle(to - from);
            return d > 180f ? d - 360f : d;
        }

        public static float LerpAngle(float a, float b, float t)
            => a + DeltaAngle(a, b) * t;

        // ── Easing functions (Robert Penner style) ─────────────────────────
        public static float EaseInQuad(float t)    => t * t;
        public static float EaseOutQuad(float t)   => 1f - (1f - t) * (1f - t);
        public static float EaseInOutQuad(float t) => t < 0.5f ? 2 * t * t : 1 - 2 * (1 - t) * (1 - t);

        public static float EaseInCubic(float t)    => t * t * t;
        public static float EaseOutCubic(float t)   => 1f - MathF.Pow(1f - t, 3f);
        public static float EaseInOutCubic(float t) => t < 0.5f ? 4 * t * t * t : 1 - MathF.Pow(-2 * t + 2, 3) / 2;

        public static float EaseInSine(float t)    => 1f - MathF.Cos(t * PI / 2f);
        public static float EaseOutSine(float t)   => MathF.Sin(t * PI / 2f);
        public static float EaseInOutSine(float t) => -(MathF.Cos(PI * t) - 1f) / 2f;

        public static float EaseInExpo(float t)    => t == 0f ? 0f : MathF.Pow(2f, 10 * t - 10);
        public static float EaseOutExpo(float t)   => t == 1f ? 1f : 1f - MathF.Pow(2f, -10 * t);

        public static float EaseInElastic(float t)
        {
            if (t == 0f || t == 1f) return t;
            return -MathF.Pow(2f, 10 * t - 10) * MathF.Sin((t * 10f - 10.75f) * TAU / 3f);
        }

        public static float EaseOutElastic(float t)
        {
            if (t == 0f || t == 1f) return t;
            return MathF.Pow(2f, -10 * t) * MathF.Sin((t * 10f - 0.75f) * TAU / 3f) + 1f;
        }

        public static float EaseOutBounce(float t)
        {
            const float n1 = 7.5625f, d1 = 2.75f;
            if      (t < 1f / d1)    return n1 * t * t;
            else if (t < 2f / d1)  { t -= 1.5f / d1;   return n1 * t * t + 0.75f; }
            else if (t < 2.5f / d1){ t -= 2.25f / d1;  return n1 * t * t + 0.9375f; }
            else                   { t -= 2.625f / d1;  return n1 * t * t + 0.984375f; }
        }

        public static float EaseInBounce(float t) => 1f - EaseOutBounce(1f - t);

        // ── Spring / Damping ──────────────────────────────────────────────
        /// <summary>
        /// Critically-damped spring toward target. Immune to frame rate.
        /// </summary>
        public static float Spring(float current, float target, ref float velocity,
                                    float smoothTime, float dt, float maxSpeed = float.MaxValue)
        {
            float omega = 2f / Math.Max(smoothTime, Epsilon);
            float x     = omega * dt;
            float exp   = 1f / (1f + x + 0.48f * x * x + 0.235f * x * x * x);
            float change = current - target;
            float orig   = target;

            float maxChange = maxSpeed * smoothTime;
            change    = Clamp(change, -maxChange, maxChange);
            target    = current - change;

            float temp = (velocity + omega * change) * dt;
            velocity   = (velocity - omega * temp) * exp;
            float res  = target + (change + temp) * exp;

            // Overshoot correction
            if (orig - current > 0f == res > orig)
            { res = orig; velocity = 0f; }
            return res;
        }

        // ── Vector helpers ────────────────────────────────────────────────
        public static Vector2 Lerp(Vector2 a, Vector2 b, float t) => a + (b - a) * t;
        public static Vector3 Lerp(Vector3 a, Vector3 b, float t) => a + (b - a) * t;
        public static Vector4 Lerp(Vector4 a, Vector4 b, float t) => a + (b - a) * t;

        public static Vector3 MoveTowards(Vector3 cur, Vector3 target, float step)
        {
            Vector3 d  = target - cur;
            float   mag = d.Length;
            return mag <= step || mag < Epsilon ? target : cur + d / mag * step;
        }

        public static Vector3 SmoothDamp(Vector3 current, Vector3 target,
                                          ref Vector3 velocity,
                                          float smoothTime, float dt,
                                          float maxSpeed = float.MaxValue)
        {
            float x = Spring(current.X, target.X, ref velocity.X, smoothTime, dt, maxSpeed);
            float y = Spring(current.Y, target.Y, ref velocity.Y, smoothTime, dt, maxSpeed);
            float z = Spring(current.Z, target.Z, ref velocity.Z, smoothTime, dt, maxSpeed);
            return new Vector3(x, y, z);
        }

        public static bool Approximately(float a, float b) => MathF.Abs(a - b) < Epsilon;

        public static Vector3 ProjectOnPlane(Vector3 v, Vector3 normal)
            => v - normal * Vector3.Dot(v, normal);

        public static Vector3 Reflect(Vector3 v, Vector3 normal)
            => v - 2f * Vector3.Dot(v, normal) * normal;

        public static float SignedAngle(Vector3 from, Vector3 to, Vector3 axis)
        {
            float angle = MathF.Acos(MathHelper.Clamp(Vector3.Dot(
                Vector3.Normalize(from), Vector3.Normalize(to)), -1f, 1f)) * Rad2Deg;
            return MathF.Sign(Vector3.Dot(axis, Vector3.Cross(from, to))) * angle;
        }

        // ── Geometry ──────────────────────────────────────────────────────
        /// <summary>Point is inside AABB.</summary>
        public static bool PointInAABB(Vector3 p, Vector3 min, Vector3 max)
            => p.X >= min.X && p.X <= max.X &&
               p.Y >= min.Y && p.Y <= max.Y &&
               p.Z >= min.Z && p.Z <= max.Z;

        /// <summary>Point on ray closest to another point.</summary>
        public static Vector3 ClosestPointOnRay(Vector3 origin, Vector3 dir, Vector3 point)
        {
            float t = Vector3.Dot(point - origin, dir);
            return origin + dir * MathF.Max(0f, t);
        }

        /// <summary>Closest point on a line segment to a point.</summary>
        public static Vector3 ClosestPointOnSegment(Vector3 a, Vector3 b, Vector3 p)
        {
            Vector3 ab = b - a;
            float   t  = Vector3.Dot(p - a, ab) / Vector3.Dot(ab, ab);
            return a + ab * Clamp01(t);
        }

        /// <summary>Signed area of 2D triangle (positive = counter-clockwise).</summary>
        public static float TriangleArea2D(Vector2 a, Vector2 b, Vector2 c)
            => ((b.X - a.X) * (c.Y - a.Y) - (c.X - a.X) * (b.Y - a.Y)) * 0.5f;

        /// <summary>Barycentric coordinates of point P in triangle ABC.</summary>
        public static Vector3 Barycentric(Vector3 p, Vector3 a, Vector3 b, Vector3 c)
        {
            Vector3 v0 = b - a, v1 = c - a, v2 = p - a;
            float   d00 = Vector3.Dot(v0, v0);
            float   d01 = Vector3.Dot(v0, v1);
            float   d11 = Vector3.Dot(v1, v1);
            float   d20 = Vector3.Dot(v2, v0);
            float   d21 = Vector3.Dot(v2, v1);
            float   inv = 1f / (d00 * d11 - d01 * d01);
            float   v   = (d11 * d20 - d01 * d21) * inv;
            float   w   = (d00 * d21 - d01 * d20) * inv;
            return new Vector3(1f - v - w, v, w);
        }

        // ── Colour math ───────────────────────────────────────────────────
        public static Color4 LerpColor(Color4 a, Color4 b, float t)
            => new(Lerp(a.R, b.R, t), Lerp(a.G, b.G, t),
                   Lerp(a.B, b.B, t), Lerp(a.A, b.A, t));

        public static Color4 ColorFromHSV(float h, float s, float v, float a = 1f)
        {
            h = WrapAngle(h) / 360f;
            float r = 0, g = 0, b = 0;
            if (s == 0) { r = g = b = v; }
            else
            {
                int   i  = (int)(h * 6f);
                float f  = h * 6f - i;
                float p  = v * (1f - s);
                float q  = v * (1f - f * s);
                float t2 = v * (1f - (1f - f) * s);
                switch (i % 6)
                {
                    case 0: r=v; g=t2; b=p;  break;
                    case 1: r=q; g=v;  b=p;  break;
                    case 2: r=p; g=v;  b=t2; break;
                    case 3: r=p; g=q;  b=v;  break;
                    case 4: r=t2;g=p;  b=v;  break;
                    case 5: r=v; g=p;  b=q;  break;
                }
            }
            return new Color4(r, g, b, a);
        }

        public static (float h, float s, float v) ColorToHSV(Color4 c)
        {
            float max = MathF.Max(c.R, MathF.Max(c.G, c.B));
            float min = MathF.Min(c.R, MathF.Min(c.G, c.B));
            float d   = max - min;
            float h   = 0;
            if (d > 0)
            {
                if (max == c.R) h = (c.G - c.B) / d % 6f;
                else if (max == c.G) h = (c.B - c.R) / d + 2f;
                else h = (c.R - c.G) / d + 4f;
                h *= 60f;
                if (h < 0) h += 360f;
            }
            return (h, max > 0 ? d / max : 0, max);
        }

        // ── Fast approximations ───────────────────────────────────────────
        /// <summary>Fast inverse square root (Quake-style, ~0.1% error).</summary>
        public static float FastInvSqrt(float x)
        {
            float xhalf = 0.5f * x;
            int   i     = BitConverter.SingleToInt32Bits(x);
            i = 0x5f3759df - (i >> 1);
            x = BitConverter.Int32BitsToSingle(i);
            return x * (1.5f - xhalf * x * x);
        }

        public static float FastSqrt(float x) => x * FastInvSqrt(x);

        /// <summary>Branchless sign: returns -1, 0, or +1.</summary>
        public static int Sign(float v) => (v > 0f ? 1 : 0) - (v < 0f ? 1 : 0);

        // ── Bezier curves ─────────────────────────────────────────────────
        public static Vector3 BezierQuadratic(Vector3 p0, Vector3 p1, Vector3 p2, float t)
        {
            float u = 1f - t;
            return u * u * p0 + 2f * u * t * p1 + t * t * p2;
        }

        public static Vector3 BezierCubic(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float t)
        {
            float u = 1f - t;
            return u*u*u*p0 + 3*u*u*t*p1 + 3*u*t*t*p2 + t*t*t*p3;
        }

        public static Vector3 BezierCubicDerivative(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float t)
        {
            float u = 1f - t;
            return 3*u*u*(p1-p0) + 6*u*t*(p2-p1) + 3*t*t*(p3-p2);
        }

        // ── Catmull-Rom spline ────────────────────────────────────────────
        public static Vector3 CatmullRom(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float t)
        {
            float t2 = t * t, t3 = t2 * t;
            return 0.5f * (
                2*p1 +
                (-p0 + p2) * t +
                (2*p0 - 5*p1 + 4*p2 - p3) * t2 +
                (-p0 + 3*p1 - 3*p2 + p3) * t3);
        }

        // ── Random helpers ────────────────────────────────────────────────
        private static readonly Random _rng = new();

        public static float RandomRange(float min, float max)
            => min + (float)_rng.NextDouble() * (max - min);

        public static int RandomRange(int min, int maxExclusive)
            => _rng.Next(min, maxExclusive);

        public static Vector2 RandomInsideUnitCircle()
        {
            float angle = RandomRange(0f, TAU);
            float r     = MathF.Sqrt((float)_rng.NextDouble());
            return new Vector2(r * MathF.Cos(angle), r * MathF.Sin(angle));
        }

        public static Vector3 RandomInsideUnitSphere()
        {
            // Rejection sampling
            Vector3 v;
            do
            {
                v = new Vector3(RandomRange(-1f,1f), RandomRange(-1f,1f), RandomRange(-1f,1f));
            } while (v.LengthSquared > 1f);
            return v;
        }

        public static Vector3 RandomOnUnitSphere()
            => Vector3.Normalize(RandomInsideUnitSphere());

        // ── Matrix helpers ────────────────────────────────────────────────
        public static Matrix4 TRS(Vector3 pos, Quaternion rot, Vector3 scale)
        {
            Matrix4 t = Matrix4.CreateTranslation(pos);
            Matrix4 r = Matrix4.CreateFromQuaternion(rot);
            Matrix4 s = Matrix4.CreateScale(scale);
            return s * r * t;
        }

        public static Vector3 ExtractTranslation(Matrix4 m)
            => new(m.M41, m.M42, m.M43);

        public static Vector3 ExtractScale(Matrix4 m)
            => new(
                new Vector3(m.M11, m.M12, m.M13).Length,
                new Vector3(m.M21, m.M22, m.M23).Length,
                new Vector3(m.M31, m.M32, m.M33).Length);

        public static Quaternion ExtractRotation(Matrix4 m, Vector3 scale)
        {
            var r = new Matrix3(
                m.M11 / scale.X, m.M12 / scale.X, m.M13 / scale.X,
                m.M21 / scale.Y, m.M22 / scale.Y, m.M23 / scale.Y,
                m.M31 / scale.Z, m.M32 / scale.Z, m.M33 / scale.Z);
            return Quaternion.FromMatrix(r);
        }

        // ── Frustum culling ───────────────────────────────────────────────
        /// <summary>
        /// Returns true if a sphere (centre, radius) is inside the 6 frustum planes.
        /// Planes should be in the format extracted from the VP matrix.
        /// </summary>
        public static bool SphereInFrustum(Vector4[] planes, Vector3 centre, float radius)
        {
            foreach (var p in planes)
                if (p.X * centre.X + p.Y * centre.Y + p.Z * centre.Z + p.W < -radius)
                    return false;
            return true;
        }

        /// <summary>Extract 6 frustum planes from a view-projection matrix.</summary>
        public static Vector4[] ExtractFrustumPlanes(Matrix4 vp)
        {
            var p = new Vector4[6];
            // Left
            p[0] = new Vector4(vp.M14+vp.M11, vp.M24+vp.M21, vp.M34+vp.M31, vp.M44+vp.M41);
            // Right
            p[1] = new Vector4(vp.M14-vp.M11, vp.M24-vp.M21, vp.M34-vp.M31, vp.M44-vp.M41);
            // Bottom
            p[2] = new Vector4(vp.M14+vp.M12, vp.M24+vp.M22, vp.M34+vp.M32, vp.M44+vp.M42);
            // Top
            p[3] = new Vector4(vp.M14-vp.M12, vp.M24-vp.M22, vp.M34-vp.M32, vp.M44-vp.M42);
            // Near
            p[4] = new Vector4(vp.M14+vp.M13, vp.M24+vp.M23, vp.M34+vp.M33, vp.M44+vp.M43);
            // Far
            p[5] = new Vector4(vp.M14-vp.M13, vp.M24-vp.M23, vp.M34-vp.M33, vp.M44-vp.M43);

            // Normalise
            for (int i = 0; i < 6; i++)
            {
                float len = new Vector3(p[i].X, p[i].Y, p[i].Z).Length;
                if (len > 0) p[i] /= len;
            }
            return p;
        }
    }
}
