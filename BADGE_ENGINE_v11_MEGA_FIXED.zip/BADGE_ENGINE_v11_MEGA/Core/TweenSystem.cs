using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Core;

// ═══════════════════════════════════════════════════════════════════════
//  EASING FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════
public enum Ease
{
    Linear,
    InSine,    OutSine,    InOutSine,
    InQuad,    OutQuad,    InOutQuad,
    InCubic,   OutCubic,   InOutCubic,
    InQuart,   OutQuart,   InOutQuart,
    InExpo,    OutExpo,    InOutExpo,
    InBack,    OutBack,    InOutBack,
    InElastic, OutElastic, InOutElastic,
    InBounce,  OutBounce,  InOutBounce,
}

public static class EaseFunc
{
    public static float Evaluate(float t, Ease ease)
    {
        t = Math.Clamp(t, 0f, 1f);
        return ease switch
        {
            Ease.Linear      => t,
            Ease.InSine      => 1f - MathF.Cos(t * MathF.PI * 0.5f),
            Ease.OutSine     => MathF.Sin(t * MathF.PI * 0.5f),
            Ease.InOutSine   => -(MathF.Cos(MathF.PI * t) - 1f) * 0.5f,
            Ease.InQuad      => t * t,
            Ease.OutQuad     => 1f - (1f - t) * (1f - t),
            Ease.InOutQuad   => t < 0.5f ? 2f * t * t : 1f - MathF.Pow(-2f * t + 2f, 2) * 0.5f,
            Ease.InCubic     => t * t * t,
            Ease.OutCubic    => 1f - MathF.Pow(1f - t, 3),
            Ease.InOutCubic  => t < 0.5f ? 4f * t * t * t : 1f - MathF.Pow(-2f * t + 2f, 3) * 0.5f,
            Ease.InQuart     => t * t * t * t,
            Ease.OutQuart    => 1f - MathF.Pow(1f - t, 4),
            Ease.InOutQuart  => t < 0.5f ? 8f * t * t * t * t : 1f - MathF.Pow(-2f * t + 2f, 4) * 0.5f,
            Ease.InExpo      => t == 0f ? 0f : MathF.Pow(2f, 10f * t - 10f),
            Ease.OutExpo     => t == 1f ? 1f : 1f - MathF.Pow(2f, -10f * t),
            Ease.InOutExpo   => t == 0f ? 0f : t == 1f ? 1f : t < 0.5f
                ? MathF.Pow(2f, 20f * t - 10f) * 0.5f
                : (2f - MathF.Pow(2f, -20f * t + 10f)) * 0.5f,
            Ease.InBack      => { const float c = 1.70158f; return c * t * t * t - c * t * t; },
            Ease.OutBack     => { const float c = 1.70158f; return 1f + (c + 1f) * MathF.Pow(t - 1f, 3) + c * MathF.Pow(t - 1f, 2); },
            Ease.InElastic   => t == 0f ? 0f : t == 1f ? 1f : -MathF.Pow(2f, 10f * t - 10f) * MathF.Sin((t * 10f - 10.75f) * (2f * MathF.PI / 3f)),
            Ease.OutElastic  => t == 0f ? 0f : t == 1f ? 1f : MathF.Pow(2f, -10f * t) * MathF.Sin((t * 10f - 0.75f) * (2f * MathF.PI / 3f)) + 1f,
            Ease.OutBounce   => OutBounce(t),
            Ease.InBounce    => 1f - OutBounce(1f - t),
            Ease.InOutBounce => t < 0.5f ? (1f - OutBounce(1f - 2f * t)) * 0.5f : (1f + OutBounce(2f * t - 1f)) * 0.5f,
            _                => t
        };
    }

    private static float OutBounce(float t)
    {
        const float n1 = 7.5625f, d1 = 2.75f;
        if (t < 1f / d1)      return n1 * t * t;
        if (t < 2f / d1)     { t -= 1.5f   / d1; return n1 * t * t + 0.75f; }
        if (t < 2.5f / d1)   { t -= 2.25f  / d1; return n1 * t * t + 0.9375f; }
        else                  { t -= 2.625f / d1; return n1 * t * t + 0.984375f; }
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  TWEEN  (single animated value)
// ═══════════════════════════════════════════════════════════════════════
public class Tween
{
    internal float  Duration;
    internal float  Elapsed;
    internal float  Delay;
    internal int    Loops;        // -1 = infinite
    internal int    LoopsDone;
    internal bool   PingPong;
    internal bool   IsPaused;
    internal bool   IsComplete;
    internal Ease   EaseType = Ease.Linear;

    internal Action<float>? Setter;      // receives 0–1 progress
    internal Action?        OnComplete;
    internal Action?        OnUpdate;

    public Tween SetEase(Ease e)      { EaseType = e;  return this; }
    public Tween SetLoops(int n, bool pingPong = false) { Loops = n; PingPong = pingPong; return this; }
    public Tween SetDelay(float d)    { Delay = d;     return this; }
    public Tween OnComplete(Action a) { OnComplete += a; return this; }
    public Tween OnUpdate(Action a)   { OnUpdate   += a; return this; }

    public void Kill()    => IsComplete = true;
    public void Pause()   => IsPaused   = true;
    public void Resume()  => IsPaused   = false;

    internal void Tick(float dt)
    {
        if (IsComplete || IsPaused) return;

        if (Delay > 0f) { Delay -= dt; return; }

        Elapsed += dt;
        float t  = Math.Clamp(Elapsed / Duration, 0f, 1f);
        float et = EaseFunc.Evaluate(PingPong && LoopsDone % 2 == 1 ? 1f - t : t, EaseType);

        Setter?.Invoke(et);
        OnUpdate?.Invoke();

        if (Elapsed >= Duration)
        {
            LoopsDone++;
            if (Loops < 0 || LoopsDone < Loops)
            {
                Elapsed = 0f;
            }
            else
            {
                Setter?.Invoke(PingPong && LoopsDone % 2 == 1 ? 0f : 1f);
                IsComplete = true;
                OnComplete?.Invoke();
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  TWEEN SEQUENCE
// ═══════════════════════════════════════════════════════════════════════
public class TweenSequence
{
    private readonly List<(float at, Tween tween)> _tweens = new();
    private float _cursor;
    private float _elapsed;
    private bool  _complete;

    public event Action? OnComplete;

    public TweenSequence Append(Tween t)
    {
        _tweens.Add((_cursor, t));
        _cursor += t.Duration + t.Delay;
        return this;
    }

    public TweenSequence Insert(float at, Tween t)
    {
        _tweens.Add((at, t));
        _cursor = MathF.Max(_cursor, at + t.Duration);
        return this;
    }

    public TweenSequence AppendInterval(float seconds)
    {
        _cursor += seconds;
        return this;
    }

    internal void Tick(float dt)
    {
        if (_complete) return;
        _elapsed += dt;

        bool allDone = true;
        foreach (var (at, tween) in _tweens)
        {
            if (_elapsed >= at && !tween.IsComplete)
                tween.Tick(dt);
            if (!tween.IsComplete) allDone = false;
        }

        if (allDone && _elapsed >= _cursor)
        {
            _complete = true;
            OnComplete?.Invoke();
        }
    }

    public bool IsComplete => _complete;
}

// ═══════════════════════════════════════════════════════════════════════
//  DOT (static tween factory — DOTween-style API)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Static tween factory. Engine calls DOT.Tick(dt) each frame.
/// NEEDED BY: Subway Surfers (lane slide), UI animations, camera zooms,
///            Zuma ball movement, Limbo silhouette fade, GTA camera cuts.
/// </summary>
public static class DOT
{
    private static readonly List<Tween>         _tweens    = new();
    private static readonly List<TweenSequence> _sequences = new();

    // ── Float ─────────────────────────────────────────────────────
    public static Tween To(Func<float> getter, Action<float> setter, float target, float duration)
    {
        float start = getter();
        var t = new Tween
        {
            Duration = duration,
            Setter   = p => setter(start + (target - start) * p)
        };
        _tweens.Add(t);
        return t;
    }

    // ── Vector3 ───────────────────────────────────────────────────
    public static Tween Move(Transform transform, Vector3 target, float duration)
    {
        var start = transform.Position;
        var t = new Tween
        {
            Duration = duration,
            Setter   = p => transform.Position = Vector3.Lerp(start, target, p)
        };
        _tweens.Add(t);
        return t;
    }

    public static Tween Scale(Transform transform, Vector3 target, float duration)
    {
        var start = transform.LocalScale;
        var t = new Tween
        {
            Duration = duration,
            Setter   = p => transform.LocalScale = Vector3.Lerp(start, target, p)
        };
        _tweens.Add(t);
        return t;
    }

    // ── Color ─────────────────────────────────────────────────────
    public static Tween Fade(Action<float> alphaSetter, float target, float duration)
    {
        float start = 1f;
        var t = new Tween
        {
            Duration = duration,
            Setter   = p => alphaSetter(start + (target - start) * p)
        };
        _tweens.Add(t);
        return t;
    }

    // ── Sequence ──────────────────────────────────────────────────
    public static TweenSequence Sequence()
    {
        var s = new TweenSequence();
        _sequences.Add(s);
        return s;
    }

    // ── Kill ──────────────────────────────────────────────────────
    public static void KillAll() { _tweens.Clear(); _sequences.Clear(); }

    // ── Engine tick ───────────────────────────────────────────────
    public static void Tick(float dt)
    {
        for (int i = _tweens.Count - 1; i >= 0; i--)
        {
            _tweens[i].Tick(dt);
            if (_tweens[i].IsComplete) _tweens.RemoveAt(i);
        }
        for (int i = _sequences.Count - 1; i >= 0; i--)
        {
            _sequences[i].Tick(dt);
            if (_sequences[i].IsComplete) _sequences.RemoveAt(i);
        }
    }

    public static int ActiveTweenCount    => _tweens.Count;
    public static int ActiveSequenceCount => _sequences.Count;
}
