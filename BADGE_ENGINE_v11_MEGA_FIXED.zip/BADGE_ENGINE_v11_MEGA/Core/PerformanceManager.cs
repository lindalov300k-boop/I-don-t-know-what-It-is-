using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;

namespace BADGE.Core
{
    /// <summary>
    /// Tracks frame timing, CPU/RAM metrics, and applies real optimisations
    /// when performance degrades — not just log messages.
    ///
    /// The engine calls FeedFrame(dt) every iteration after EndFrame().
    /// </summary>
    public sealed class PerformanceManager
    {
        // ── Singleton ─────────────────────────────────────────────────────
        private static readonly Lazy<PerformanceManager> _lazy =
            new(() => new PerformanceManager());
        public static PerformanceManager Instance => _lazy.Value;

        // ── Metrics ───────────────────────────────────────────────────────
        public float CurrentFPS    { get; private set; }
        public float AverageFPS    { get; private set; }
        public float CPUUsage      { get; private set; }
        public long  MemoryMB      { get; private set; }
        public int   DrawCalls     { get; private set; }
        public int   TriangleCount { get; private set; }

        // ── Targets ───────────────────────────────────────────────────────
        public float TargetFPS    { get; set; } = 60f;
        public float MaxCPUPct    { get; set; } = 80f;
        public long  MaxMemoryMB  { get; set; } = 512;

        // ── Settings ──────────────────────────────────────────────────────
        public bool AutoOptimize     { get; set; } = true;
        public bool DynamicLOD       { get; set; } = true;
        public bool AggressivePooling{ get; set; } = true;

        // ── Render quality knobs (read by Renderer) ───────────────────────
        public int    ShadowQuality     { get; private set; } = 2;  // 0-4
        public float  DrawDistance      { get; private set; } = 500f;
        public int    MaxParticles      { get; private set; } = 2000;
        public bool   PostProcessing    { get; private set; } = true;
        public float  TextureQuality    { get; private set; } = 1f;  // 0.25-1
        public bool   ShadowsEnabled    { get; private set; } = true;

        // ── Internal ──────────────────────────────────────────────────────
        private readonly Queue<float>  _samples      = new(120);
        private readonly Stopwatch     _cpuWatch     = Stopwatch.StartNew();
        private readonly Process       _proc         = Process.GetCurrentProcess();
        private          TimeSpan      _lastCpuTime;
        private          DateTime      _lastCpuCheck = DateTime.UtcNow;
        private          OptimizationLevel _currentOpt = OptimizationLevel.None;
        private          int           _gcWarningCount;

        private PerformanceManager()
        {
            _lastCpuTime = _proc.TotalProcessorTime;
        }

        // ── Called by Engine each frame ───────────────────────────────────
        public void FeedFrame(float dt)
        {
            // FPS
            CurrentFPS = dt > 0f ? 1f / dt : 0f;
            _samples.Enqueue(dt);
            if (_samples.Count > 120) _samples.Dequeue();
            float sum = 0f;
            foreach (float s in _samples) sum += s;
            AverageFPS = _samples.Count / sum;

            // CPU / RAM (sampled every 500 ms to avoid OS overhead)
            if (_cpuWatch.Elapsed.TotalMilliseconds > 500)
            {
                _cpuWatch.Restart();
                try
                {
                    _proc.Refresh();
                    var now     = DateTime.UtcNow;
                    var cpu     = _proc.TotalProcessorTime;
                    double span = (now - _lastCpuCheck).TotalSeconds;
                    if (span > 0)
                        CPUUsage = (float)((cpu - _lastCpuTime).TotalSeconds /
                                            (span * Environment.ProcessorCount) * 100f);
                    _lastCpuTime  = cpu;
                    _lastCpuCheck = now;
                    MemoryMB = _proc.WorkingSet64 / (1024 * 1024);
                }
                catch { /* process may have closed */ }
            }

            if (AutoOptimize) CheckAndOptimize();
        }

        // ── Legacy StartFrame/EndFrame shim (for old call sites) ──────────
        public void StartFrame() { }
        public void EndFrame()   { }

        // ── Auto-optimise ─────────────────────────────────────────────────
        private void CheckAndOptimize()
        {
            // Improve quality if we have headroom
            if (AverageFPS >= TargetFPS * 1.1f && CPUUsage < MaxCPUPct * 0.5f)
            {
                IncreaseQuality();
                return;
            }

            // Degrade quality progressively when starved
            if (AverageFPS < TargetFPS * 0.5f || CPUUsage > MaxCPUPct)
            {
                ApplyOptimizations(OptimizationLevel.Aggressive);
            }
            else if (AverageFPS < TargetFPS * 0.75f)
            {
                ApplyOptimizations(OptimizationLevel.Moderate);
            }
            else if (AverageFPS < TargetFPS * 0.9f)
            {
                ApplyOptimizations(OptimizationLevel.Light);
            }

            // Memory pressure → GC
            if (MemoryMB > MaxMemoryMB)
            {
                _gcWarningCount++;
                if (_gcWarningCount % 10 == 1)
                {
                    Console.WriteLine($"⚠️ Memory {MemoryMB}MB/{MaxMemoryMB}MB — collecting.");
                    GC.Collect(1, GCCollectionMode.Optimized, blocking: false);
                }
            }
        }

        private void ApplyOptimizations(OptimizationLevel level)
        {
            if (level <= _currentOpt) return;  // already at this level or worse
            _currentOpt = level;
            Console.WriteLine($"[Perf] Applying {level} optimisations (avg {AverageFPS:F0} fps)");

            switch (level)
            {
                case OptimizationLevel.Light:
                    ShadowQuality   = Math.Max(0, ShadowQuality - 1);
                    MaxParticles    = (int)(MaxParticles * 0.75f);
                    PostProcessing  = false;
                    break;

                case OptimizationLevel.Moderate:
                    ShadowQuality   = Math.Max(0, ShadowQuality - 2);
                    DrawDistance    = Math.Max(50f, DrawDistance * 0.6f);
                    MaxParticles    = (int)(MaxParticles * 0.4f);
                    TextureQuality  = Math.Max(0.5f, TextureQuality - 0.25f);
                    PostProcessing  = false;
                    // Tell throttle to reduce AI tick rate
                    break;

                case OptimizationLevel.Aggressive:
                    ShadowsEnabled  = false;
                    ShadowQuality   = 0;
                    DrawDistance    = Math.Max(50f, DrawDistance * 0.4f);
                    MaxParticles    = Math.Max(50, (int)(MaxParticles * 0.15f));
                    TextureQuality  = 0.25f;
                    PostProcessing  = false;
                    GC.Collect(2, GCCollectionMode.Forced, blocking: false);
                    break;
            }
        }

        private void IncreaseQuality()
        {
            if (_currentOpt == OptimizationLevel.None) return;
            _currentOpt = (OptimizationLevel)Math.Max(0, (int)_currentOpt - 1);

            ShadowQuality   = Math.Clamp(ShadowQuality + 1, 0, 4);
            DrawDistance    = Math.Min(500f, DrawDistance * 1.2f);
            MaxParticles    = Math.Min(2000, (int)(MaxParticles * 1.5f));
            TextureQuality  = Math.Min(1f, TextureQuality + 0.25f);
            if (_currentOpt == OptimizationLevel.None)
            {
                ShadowsEnabled = true;
                PostProcessing = true;
            }
        }

        // ── Render stats ──────────────────────────────────────────────────
        public void UpdateRenderStats(int drawCalls, int triangles)
        {
            DrawCalls     = drawCalls;
            TriangleCount = triangles;
        }

        // ── Report ────────────────────────────────────────────────────────
        public PerformanceReport GetReport() => new()
        {
            FPS        = CurrentFPS,
            AverageFPS = AverageFPS,
            CPUUsage   = CPUUsage,
            MemoryMB   = MemoryMB,
            DrawCalls  = DrawCalls,
            Triangles  = TriangleCount,
            Status     = GetStatus(),
            ThrottleInfo = EngineThrottle.Instance.ToString()
        };

        private PerformanceStatus GetStatus()
        {
            if (AverageFPS >= TargetFPS * 0.9f && CPUUsage < MaxCPUPct * 0.7f)
                return PerformanceStatus.Excellent;
            if (AverageFPS >= TargetFPS * 0.7f && CPUUsage < MaxCPUPct * 0.9f)
                return PerformanceStatus.Good;
            if (AverageFPS >= TargetFPS * 0.5f)
                return PerformanceStatus.Moderate;
            return PerformanceStatus.Poor;
        }
    }

    // ── Enums ─────────────────────────────────────────────────────────────
    public enum OptimizationLevel { None, Light, Moderate, Aggressive }
    public enum PerformanceStatus  { Excellent, Good, Moderate, Poor }

    // ── Report DTO ────────────────────────────────────────────────────────
    public class PerformanceReport
    {
        public float           FPS          { get; set; }
        public float           AverageFPS   { get; set; }
        public float           CPUUsage     { get; set; }
        public long            MemoryMB     { get; set; }
        public int             DrawCalls    { get; set; }
        public int             Triangles    { get; set; }
        public PerformanceStatus Status     { get; set; }
        public string          ThrottleInfo { get; set; } = "";

        public void Print()
        {
            Console.WriteLine("\n=== Performance Report ===");
            Console.WriteLine($"  FPS    : {FPS:F1} (avg {AverageFPS:F1})");
            Console.WriteLine($"  CPU    : {CPUUsage:F1}%");
            Console.WriteLine($"  RAM    : {MemoryMB} MB");
            Console.WriteLine($"  Draws  : {DrawCalls}   Tris: {Triangles:N0}");
            Console.WriteLine($"  Status : {Status}");
            Console.WriteLine($"  {ThrottleInfo}");
            Console.WriteLine("==========================\n");
        }
    }

    // ── CrashRecovery ─────────────────────────────────────────────────────
    public static class CrashRecovery
    {
        private static Timer?               _timer;
        private static readonly Queue<SceneSnapshot> _snapshots = new(10);
        private const  int MAX_SNAPSHOTS   = 10;
        private const  int INTERVAL_SECS   = 300;  // 5 min

        public static void Initialize()
        {
            _timer = new Timer(
                _ => { try { CreateSnapshot(); } catch { } },
                null,
                TimeSpan.FromSeconds(INTERVAL_SECS),
                TimeSpan.FromSeconds(INTERVAL_SECS));
            Console.WriteLine($"  - Crash recovery: auto-save every {INTERVAL_SECS}s");
        }

        public static void CreateSnapshot()
        {
            var scene = Engine.Instance.GetCurrentScene();
            if (scene == null) return;

            while (_snapshots.Count >= MAX_SNAPSHOTS) _snapshots.Dequeue();
            _snapshots.Enqueue(new SceneSnapshot
            {
                Timestamp   = DateTime.Now,
                SceneName   = scene.Name,
                EntityCount = scene.Entities.Count
            });
            Console.WriteLine($"[AutoSave] {scene.Name} ({scene.Entities.Count} entities)");
        }

        public static void Shutdown()
        {
            _timer?.Dispose();
            CreateSnapshot();
        }
    }

    public class SceneSnapshot
    {
        public DateTime Timestamp   { get; set; }
        public string   SceneName   { get; set; } = "";
        public int      EntityCount { get; set; }
    }

    // ── Object pool ───────────────────────────────────────────────────────
    public class OptimizedObjectPool<T> where T : class, new()
    {
        private readonly Stack<T> _pool;
        private readonly int      _capacity;
        private int _allocated, _reused;

        public OptimizedObjectPool(int capacity = 100)
        {
            _pool     = new Stack<T>(capacity);
            _capacity = capacity;
        }

        public T Get()
        {
            if (_pool.Count > 0) { _reused++; return _pool.Pop(); }
            _allocated++;
            return new T();
        }

        public void Return(T obj)
        {
            if (_pool.Count < _capacity) _pool.Push(obj);
        }

        public void Clear() => _pool.Clear();

        public PoolStatistics GetStatistics() => new()
        {
            Capacity = _capacity, Available = _pool.Count,
            Allocated = _allocated, Reused = _reused,
            ReuseRate = _allocated > 0 ? _reused * 100f / _allocated : 0
        };
    }

    public class PoolStatistics
    {
        public int   Capacity  { get; set; }
        public int   Available { get; set; }
        public int   Allocated { get; set; }
        public int   Reused    { get; set; }
        public float ReuseRate { get; set; }

        public void Print(string name) =>
            Console.WriteLine($"{name}: cap={Capacity} avail={Available} " +
                              $"alloc={Allocated} reuse={ReuseRate:F1}%");
    }

    // ── LOD ───────────────────────────────────────────────────────────────
    public class LODSystem
    {
        private readonly Dictionary<G3DP.Mesh, LODGroup> _groups = new();

        public void Register(G3DP.Mesh mesh, LODLevel[] levels)
            => _groups[mesh] = new LODGroup { OriginalMesh = mesh, Levels = levels };

        public G3DP.Mesh GetLOD(G3DP.Mesh original, float distance)
        {
            if (!_groups.TryGetValue(original, out var g)) return original;
            foreach (var lvl in g.Levels)
                if (distance >= lvl.Distance) return lvl.Mesh;
            return original;
        }
    }

    public class LODGroup  { public G3DP.Mesh OriginalMesh = null!; public LODLevel[] Levels = Array.Empty<LODLevel>(); }
    public class LODLevel  { public float Distance; public G3DP.Mesh Mesh = null!; }
}
