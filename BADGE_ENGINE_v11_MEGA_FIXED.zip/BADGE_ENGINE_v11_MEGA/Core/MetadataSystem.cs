using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace BADGE.Core
{
    /// <summary>
    /// Metadata system: tracks asset, file, project, performance, and user metadata.
    /// All metadata is persisted to JSON in the project's Config/ directory.
    /// </summary>
    public static class MetadataSystem
    {
        private static readonly string MetaDir = "Config/Metadata";
        private static readonly Dictionary<string, AssetMetadata>   _assets   = new();
        private static readonly Dictionary<string, FileMetadata>     _files    = new();
        private static ProjectMetadata _project = new();

        static MetadataSystem()
        {
            Directory.CreateDirectory(MetaDir);
            Load();
        }

        // ── Asset metadata ────────────────────────────────────────────────
        public static AssetMetadata GetAsset(string assetPath)
        {
            if (!_assets.TryGetValue(assetPath, out var meta))
            {
                meta = new AssetMetadata
                {
                    Path        = assetPath,
                    CreatedAt   = DateTime.UtcNow,
                    ModifiedAt  = DateTime.UtcNow,
                    Author      = Environment.UserName,
                };
                _assets[assetPath] = meta;
                Save();
            }
            return meta;
        }

        public static void UpdateAsset(string assetPath, Action<AssetMetadata> update)
        {
            var meta = GetAsset(assetPath);
            update(meta);
            meta.ModifiedAt = DateTime.UtcNow;
            Save();
        }

        // ── File metadata ─────────────────────────────────────────────────
        public static FileMetadata GetFile(string filePath)
        {
            var info = new FileInfo(filePath);
            if (!_files.TryGetValue(filePath, out var meta))
            {
                meta = new FileMetadata
                {
                    Path        = filePath,
                    Size        = info.Exists ? info.Length : 0,
                    Extension   = info.Extension,
                    CreatedAt   = info.Exists ? info.CreationTimeUtc : DateTime.UtcNow,
                    ModifiedAt  = info.Exists ? info.LastWriteTimeUtc : DateTime.UtcNow,
                };
                _files[filePath] = meta;
                Save();
            }
            else if (info.Exists)
            {
                meta.Size      = info.Length;
                meta.ModifiedAt = info.LastWriteTimeUtc;
            }
            return meta;
        }

        // ── Project metadata ──────────────────────────────────────────────
        public static ProjectMetadata GetProject() => _project;

        public static void SetProjectVersion(string version)
        {
            _project.Version    = version;
            _project.ModifiedAt = DateTime.UtcNow;
            Save();
        }

        // ── Performance snapshot ──────────────────────────────────────────
        public static void RecordPerformance(float fps, int drawCalls, int triangles)
        {
            _project.LastFPS         = fps;
            _project.LastDrawCalls   = drawCalls;
            _project.LastTriangles   = triangles;
            _project.LastSessionTime = DateTime.UtcNow;
            Save();
        }

        // ── Tag / search ──────────────────────────────────────────────────
        public static void TagAsset(string path, string tag)
        {
            var meta = GetAsset(path);
            if (!meta.Tags.Contains(tag)) meta.Tags.Add(tag);
            Save();
        }

        public static IEnumerable<string> FindByTag(string tag)
        {
            foreach (var (path, meta) in _assets)
                if (meta.Tags.Contains(tag)) yield return path;
        }

        // ── Persistence ───────────────────────────────────────────────────
        private static void Save()
        {
            var data = new MetadataStore { Assets = _assets, Files = _files, Project = _project };
            File.WriteAllText(Path.Combine(MetaDir, "metadata.json"),
                              JsonConvert.SerializeObject(data, Formatting.Indented));
        }

        private static void Load()
        {
            string path = Path.Combine(MetaDir, "metadata.json");
            if (!File.Exists(path)) return;
            try
            {
                var data = JsonConvert.DeserializeObject<MetadataStore>(File.ReadAllText(path));
                if (data == null) return;
                foreach (var kv in data.Assets) _assets[kv.Key] = kv.Value;
                foreach (var kv in data.Files)  _files[kv.Key]  = kv.Value;
                _project = data.Project ?? new ProjectMetadata();
            }
            catch { /* ignore corrupt metadata file */ }
        }

        private class MetadataStore
        {
            public Dictionary<string, AssetMetadata> Assets  { get; set; } = new();
            public Dictionary<string, FileMetadata>  Files   { get; set; } = new();
            public ProjectMetadata                    Project { get; set; } = new();
        }
    }

    public class AssetMetadata
    {
        public string       Path        { get; set; } = "";
        public string       Author      { get; set; } = "";
        public string       Description { get; set; } = "";
        public List<string> Tags        { get; set; } = new();
        public DateTime     CreatedAt   { get; set; }
        public DateTime     ModifiedAt  { get; set; }
        public Dictionary<string, string> Custom { get; set; } = new();
    }

    public class FileMetadata
    {
        public string   Path       { get; set; } = "";
        public long     Size       { get; set; }
        public string   Extension  { get; set; } = "";
        public DateTime CreatedAt  { get; set; }
        public DateTime ModifiedAt { get; set; }
    }

    public class ProjectMetadata
    {
        public string   Name          { get; set; } = "Untitled";
        public string   Version       { get; set; } = "0.1.0";
        public string   TargetPlatform{ get; set; } = "Windows";
        public DateTime CreatedAt     { get; set; } = DateTime.UtcNow;
        public DateTime ModifiedAt    { get; set; } = DateTime.UtcNow;
        public DateTime LastSessionTime{ get; set; }
        public float    LastFPS       { get; set; }
        public int      LastDrawCalls { get; set; }
        public int      LastTriangles { get; set; }
    }
}
