using System;
using System.Collections.Generic;

namespace BADGE.Core.ECS
{
    /// <summary>
    /// Object pooling system to reduce garbage collection pressure
    /// Critical for low-end hardware performance
    /// </summary>
    public class ObjectPool
    {
        private Dictionary<Type, Queue<object>> _pools;
        private int _maxPoolSize = 100;

        public ObjectPool()
        {
            _pools = new Dictionary<Type, Queue<object>>();
        }

        public T Get<T>() where T : class, new()
        {
            Type type = typeof(T);
            
            if (!_pools.ContainsKey(type))
            {
                _pools[type] = new Queue<object>();
            }

            if (_pools[type].Count > 0)
            {
                return _pools[type].Dequeue() as T;
            }
            
            return new T();
        }

        public void Return<T>(T obj) where T : class
        {
            Type type = typeof(T);
            
            if (!_pools.ContainsKey(type))
            {
                _pools[type] = new Queue<object>();
            }

            // Don't exceed max pool size
            if (_pools[type].Count < _maxPoolSize)
            {
                _pools[type].Enqueue(obj);
            }
        }

        public void Clear()
        {
            _pools.Clear();
        }

        public int GetPoolSize<T>()
        {
            Type type = typeof(T);
            return _pools.ContainsKey(type) ? _pools[type].Count : 0;
        }
    }
}
