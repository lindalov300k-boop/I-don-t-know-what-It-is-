using System;
using System.Collections.Generic;
using System.Collections.Concurrent;

namespace BADGE.Core.Integration
{
    // Real, working event system
    public sealed class EventBus
    {
        private static EventBus? _instance;
        public static EventBus Instance => _instance ??= new EventBus();
        
        private readonly ConcurrentDictionary<Type, List<Delegate>> _handlers = new();
        
        public void Subscribe<T>(Action<T> handler) where T : class
        {
            var type = typeof(T);
            if (!_handlers.ContainsKey(type))
                _handlers[type] = new List<Delegate>();
            _handlers[type].Add(handler);
        }
        
        public void Publish<T>(T eventData) where T : class
        {
            var type = typeof(T);
            if (_handlers.TryGetValue(type, out var handlers))
            {
                foreach (Action<T> handler in handlers)
                    handler(eventData);
            }
        }
    }
    
    // Asset metadata
    public class AssetMetadata
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; } = "";
        public string Path { get; set; } = "";
        public DateTime Created { get; set; } = DateTime.Now;
    }
}
