using System;

namespace BADGE.Core;

/// <summary>
/// Static time class — Unity-API-compatible.
/// Engine feeds values in via internal setters each frame.
///
/// NEW: Was completely absent; manual dt parameters were everywhere,
///      but nothing centralised them, and Time.DeltaTime was missing.
/// </summary>
public static class Time
{
    // ── Read-only public API ──────────────────────────────────────
    /// <summary>Seconds since last frame, scaled by TimeScale.</summary>
    public static float DeltaTime { get; private set; }

    /// <summary>Unscaled real seconds since last frame.</summary>
    public static float UnscaledDeltaTime { get; private set; }

    /// <summary>Total elapsed seconds since game start, scaled.</summary>
    public static float ElapsedTime { get; private set; }

    /// <summary>Total real seconds since game start.</summary>
    public static float RealTimeSinceStartup { get; private set; }

    /// <summary>Fixed timestep (default 0.02 = 50 Hz physics).</summary>
    public static float FixedDeltaTime { get; set; } = 0.02f;

    /// <summary>Total frames rendered.</summary>
    public static int FrameCount { get; private set; }

    /// <summary>Current frames-per-second.</summary>
    public static float FrameRate { get; private set; }

    /// <summary>Multiplier applied to DeltaTime. Set to 0 to pause.</summary>
    public static float TimeScale { get; set; } = 1f;

    // ── Smoothing ─────────────────────────────────────────────────
    private static float _smoothFps;
    private const  float SMOOTH_FACTOR = 0.95f;

    // ── Internal: Engine feeds these ─────────────────────────────
    internal static void Advance(float rawDt)
    {
        UnscaledDeltaTime = rawDt;
        DeltaTime         = rawDt * TimeScale;
        ElapsedTime      += DeltaTime;
        RealTimeSinceStartup += rawDt;
        FrameCount++;

        // Smooth FPS calculation
        float instantFps = rawDt > 0f ? 1f / rawDt : 0f;
        _smoothFps = _smoothFps * SMOOTH_FACTOR + instantFps * (1f - SMOOTH_FACTOR);
        FrameRate  = _smoothFps;
    }

    // ── Utility ───────────────────────────────────────────────────
    /// <summary>Returns a string suitable for HUD display: "60 FPS".</summary>
    public static string GetFPSString() => $"{FrameRate:0} FPS";

    /// <summary>Converts seconds to the number of frames at current rate.</summary>
    public static int SecondsToFrames(float seconds)
        => (int)MathF.Ceiling(seconds / FixedDeltaTime);
}
