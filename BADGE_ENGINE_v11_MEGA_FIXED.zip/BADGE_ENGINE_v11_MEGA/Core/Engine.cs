using System;
using System.Diagnostics;
using System.Threading;
using BADGE.Security;
using BADGE.Hardware;
using BADGE.Analytics;
using BADGE.Modding;
using BADGE.Physics;
using BADGE.Rendering;
using BADGE.Audio;
using BADGE.Procedural;
using BADGE.VFX;

namespace BADGE.Core
{
    /// <summary>
    /// Main engine class — coordinates all systems and enforces idle-safe operation.
    ///
    /// IDLE / FREEZE PREVENTION
    /// ─────────────────────────
    /// The old Run() loop had no frame-cap and would peg the CPU at 100%.
    /// All frame pacing is now delegated to EngineThrottle which:
    ///   • Caps to TargetFPS via Thread.Sleep + precision spin
    ///   • Drops to 15 fps when the window loses focus
    ///   • Drops to  5 fps after 30 s of no user activity
    ///   • Drops to  1 fps when minimised
    ///   • Exposes PhysicsActive / AIActive / AudioActive flags so
    ///     subsystems self-throttle without scattered _isIdle booleans.
    /// </summary>
    public sealed class Engine
    {
        // ── Singleton ──────────────────────────────────────────────────────
        private static Engine? _instance;
        public  static Engine   Instance => _instance ??= new Engine();

        // ── State ──────────────────────────────────────────────────────────
        public bool  IsRunning  { get; private set; }
        public bool  IsPlayMode { get; private set; }
        public float DeltaTime  => EngineThrottle.Instance.ActualDelta;

        // ── Sub-systems ────────────────────────────────────────────────────
        private WindowManager       _windowManager = null!;
        private EngineThrottle      _throttle      = EngineThrottle.Instance;
        private PerformanceManager  _perf          = PerformanceManager.Instance;

        // ── Scene helpers ──────────────────────────────────────────────────
        public Scene?          GetCurrentScene()     => SceneManager.Instance.CurrentScene;
        public SceneManager    GetSceneManager()     => SceneManager.Instance;
        public PerformanceManager GetPerformanceManager() => _perf;

        // ── Constructor ────────────────────────────────────────────────────
        private Engine() { }

        // ── Boot ───────────────────────────────────────────────────────────
        public void Initialize()
        {
            Console.WriteLine("=== BADGE Engine v10.0 Initialization ===");
            Console.WriteLine("Basic Atlas Dimensional Game Engine");
            Console.WriteLine("By ATLAS NETWORK CLUB — All Input Devices Supported");
            Console.WriteLine("========================================\n");

            Console.WriteLine("[1/9] Core systems…");
            _windowManager = new WindowManager();
            _windowManager.OnFocusChanged = focused =>
            {
                if (focused) OnWindowFocusGained(); else OnWindowFocusLost();
            };
            _windowManager.Create();  // Opens OS window + OpenGL context
            ECS.EntityManager.Initialize();

            Console.WriteLine("[2/9] Security & permissions…");
            // PermissionSystem is already initialized by Program.cs.
            // Verify the current principal has engine-start permission.
            PermissionGate.Require(Permissions.EngineModeSwitch);
            Console.WriteLine($"  Security layer active. Principal: {PermissionSystem.Instance.CurrentPrincipal}");

            Console.WriteLine("[3/9] Hardware interface…");
            // Hardware.Initialize() called by Program.cs before this point.
            // Wire GPU info once OpenGL context is ready (deferred).
            var hw = HardwareInterface.Instance;
            if (hw.IsLowEndDevice)
            {
                Console.WriteLine("  Low-end device detected — reducing default quality settings.");
                _throttle.ActiveFPS = 30;  // cap to 30fps on low-end
            }

            Console.WriteLine("[4/9] Editor tabs…");
            // Editor tabs initialised in Editor namespace on first access

            Console.WriteLine("[5/9] Runtime systems…");
            Rendering.Renderer2D.Initialize();
            Physics.Physics2D.Initialize();
            BepuPhysicsWorld.Initialize(-9.81f);        // 3D rigid body physics
            MaterialSystem.Initialize();                // PBR material registry
            Modding.ModLoader.Initialize();            // mod system
            Core.ECS.SystemManager.Initialize();       // ECS system registry
            GarbageCollector.SetCollectionInterval(300); // GC every 300 frames

            Console.WriteLine("[6/9] Idle throttle…");
            // EngineThrottle is lazy-singleton, already constructed above.
            // Configure targets here if needed.
            _throttle.ActiveFPS        = 60;
            _throttle.UnfocusedFPS     = 15;
            _throttle.IdleFPS          = 5;
            _throttle.BackgroundFPS    = 1;
            _throttle.IdleTimeoutSecs  = 30f;

            // Legacy compatibility: pulse the old SetIdle helpers so they
            // stop doing their own work and defer to EngineThrottle instead.
            EnforceIdleState();

            Console.WriteLine("[7/9] Default scene…");
            SceneManager.Instance.LoadScene("DefaultScene");

            Console.WriteLine("[8/9] Crash recovery…");
            CrashRecovery.Initialize();

            Console.WriteLine("[9/9] Engine ready — editor mode, idle-safe active.\n");
            IsRunning = true;
        }

        // ── Main loop ──────────────────────────────────────────────────────
        /// <summary>
        /// Blocking game loop.  Frame rate is enforced by EngineThrottle.EndFrame()
        /// which sleeps the thread for the remainder of the frame budget —
        /// the CPU sits near 0% when the engine is idle.
        /// </summary>
        public void Run()
        {
            var reportTimer = Stopwatch.StartNew();

            _windowManager.RunLoop(
                () => IsRunning,
                dt =>
                {
                    _throttle.BeginFrame();
                    if (_throttle.RenderingActive)
                    {
                        Update(dt);
                        Render();
                    }
                    var actualDt = _throttle.EndFrame();
                    _perf.FeedFrame(actualDt);
                });
            return;
            while (IsRunning) // legacy - unreachable after RunLoop
            {
                _throttle.BeginFrame();

                // Skip heavy work when background / fully idle
                if (_throttle.RenderingActive)
                {
                    Update(_throttle.ActualDelta);
                    Render();
                }

                float dt = _throttle.EndFrame();
                _perf.FeedFrame(dt);

                // Periodic perf report (every 5 s, only if degraded)
                if (reportTimer.Elapsed.TotalSeconds > 5.0)
                {
                    var report = _perf.GetReport();
                    if (report.Status != PerformanceStatus.Excellent)
                        report.Print();
                    reportTimer.Restart();
                }
            }
        }

        // ── Update ─────────────────────────────────────────────────────────
        private void Update(float rawDt)
        {
            float dt = Math.Clamp(rawDt, 0f, 0.1f);  // cap spike frames at 100 ms

            Time.Advance(dt);
            Input.BeginFrame();
            GamepadInput.UpdateAll();   // poll all connected controllers
            DOT.Tick(dt);               // advance all active tweens

            SceneManager.Instance.FlushPendingLoad();
            var scene = SceneManager.Instance.CurrentScene;

            if (IsPlayMode && scene != null)
            {
                ECS.EntityManager.Update(dt);

                if (_throttle.PhysicsActive)
                {
                    Physics.Physics2D.Update(dt);
                    BepuPhysicsWorld.Step(dt);          // 3D rigid body step
                }

                CollisionWorld.Tick(scene);
                CoroutineRunner.Tick(dt);
                GarbageCollector.Update();
                ShaderCompiler.PollHotReload();         // live shader editing
                scene.Update(dt);
                scene.LateUpdate(dt);
            }
            else
            {
                Editor.SceneTab.Update(dt);
            }
        }

        // ── Render ─────────────────────────────────────────────────────────
        private void Render()
        {
            Rendering.Renderer2D.BeginFrame();

            var scene = SceneManager.Instance.CurrentScene;
            Rendering.Renderer2D.RenderScene(scene);

            if (!IsPlayMode)
                Editor.SceneTab.RenderGizmos();

            // Debug gizmos (world-space lines, boxes — no-op if nothing queued)
            // DebugDraw.Flush(view, proj) — caller supplies matrices from active camera

            // Scene fade/transition overlay (always on top, under ImGui)
            SceneTransitionManager.Render(
                _windowManager.Width, _windowManager.Height);

            Rendering.Renderer2D.EndFrame();
        }

        // ── Play mode ──────────────────────────────────────────────────────
        public void EnterPlayMode()
        {
            Console.WriteLine("\n=== Entering Play Mode ===");
            IsPlayMode = true;
            Physics.Physics2D.Activate();
            Editor.SceneTab.SetActive(false);
            _throttle.NotifyActivity();   // exit idle immediately on play
        }

        public void ExitPlayMode()
        {
            Console.WriteLine("\n=== Exiting Play Mode ===");
            IsPlayMode = false;
            Editor.SceneTab.SetActive(true);
            EnforceIdleState();
        }

        // ── Shutdown ───────────────────────────────────────────────────────
        public void Shutdown()
        {
            Console.WriteLine("\n=== BADGE Engine Shutdown ===");
            IsRunning = false;

            CrashRecovery.Shutdown();
            BepuPhysicsWorld.Shutdown();
            MaterialSystem.Cleanup();
            SceneManager.Instance.UnloadAll();
            _windowManager.Close();

            _perf.GetReport().Print();
            Console.WriteLine("Engine shutdown complete.");
        }

        // ── Window focus hooks (call from window event handlers) ───────────
        public void OnWindowFocusGained()  => _throttle.NotifyFocusGained();
        public void OnWindowFocusLost()    => _throttle.NotifyFocusLost();
        public void OnWindowMinimised()    => _throttle.NotifyMinimised();
        public void OnWindowRestored()     => _throttle.NotifyRestored();

        /// <summary>Call from input handler on every keypress/mouse event.</summary>
        public void OnUserActivity()       => _throttle.NotifyActivity();

        // ── Idle helpers ───────────────────────────────────────────────────
        private void EnforceIdleState()
        {
            // Legacy modules that still have SetIdle stubs — keep them
            // in sync with EngineThrottle so they don't spin on their own.
            Procedural.ProceduralManager.SetIdle(true);
            G3DP.MeshFilterStack.SetIdle(true);
            Audio.AudioMixer.SetIdle(true);
            AI.ScriptGenerator.SetIdle(true);
            AI.FreeAIService.SetIdle(true);
        }
    }
}
