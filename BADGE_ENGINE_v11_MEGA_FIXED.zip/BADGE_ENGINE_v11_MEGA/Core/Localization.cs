using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using BADGE.Core;

namespace BADGE.Core
{
    /// <summary>
    /// JSON-based localization / i18n system.
    ///
    /// Usage:
    ///   Loc.Load("en");           // loads Locales/en.json
    ///   Loc.Load("fr");
    ///   Loc.Set("en");            // switch active language
    ///   string s = Loc.T("ui.start_button");          // "Start Game"
    ///   string s = Loc.T("enemy.killed", count);      // plural: "1 enemy" / "3 enemies"
    ///   string s = Loc.Tf("player.score", score);     // "Score: 4200"
    ///
    /// JSON format (Locales/en.json):
    ///   {
    ///     "ui.start_button": "Start Game",
    ///     "enemy.killed":    ["1 enemy killed", "{0} enemies killed"],
    ///     "player.score":    "Score: {0}"
    ///   }
    ///
    /// Falls back to the key name if a translation is missing.
    /// Raises Loc.OnLanguageChanged event when switching languages.
    /// </summary>
    public static class Loc
    {
        // ── Config ────────────────────────────────────────────────────────
        public static string LocalesDir    { get; set; } = "Locales";
        public static string FallbackLang  { get; set; } = "en";

        // ── State ─────────────────────────────────────────────────────────
        public static string CurrentLanguage { get; private set; } = "en";

        private static readonly Dictionary<string, Dictionary<string, JsonElement>> _tables = new();
        private static Dictionary<string, JsonElement> _active = new();
        private static Dictionary<string, JsonElement> _fallback = new();

        // ── Events ────────────────────────────────────────────────────────
        public static event Action<string>? OnLanguageChanged;

        // ── Load / set ────────────────────────────────────────────────────

        /// <summary>Load a language file. Pass lang="en" to load Locales/en.json.</summary>
        public static bool Load(string lang)
        {
            string path = Path.Combine(LocalesDir, $"{lang}.json");
            if (!File.Exists(path))
            {
                Console.WriteLine($"[Loc] Missing locale file: {path}");
                return false;
            }

            try
            {
                var json = File.ReadAllText(path);
                var doc  = JsonDocument.Parse(json);
                var dict = new Dictionary<string, JsonElement>(StringComparer.OrdinalIgnoreCase);

                foreach (var prop in doc.RootElement.EnumerateObject())
                    dict[prop.Name] = prop.Value.Clone();

                _tables[lang] = dict;
                Console.WriteLine($"[Loc] Loaded '{lang}' ({dict.Count} keys)");

                if (lang == FallbackLang)  _fallback = dict;
                if (lang == CurrentLanguage) _active  = dict;

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Loc] Failed to parse '{path}': {ex.Message}");
                return false;
            }
        }

        /// <summary>Switch the active language. Loads it if not already cached.</summary>
        public static bool Set(string lang)
        {
            if (!_tables.ContainsKey(lang))
                if (!Load(lang)) return false;

            CurrentLanguage = lang;
            _active = _tables[lang];
            OnLanguageChanged?.Invoke(lang);
            return true;
        }

        /// <summary>Returns all loaded language codes.</summary>
        public static IEnumerable<string> LoadedLanguages => _tables.Keys;

        // ── Translation ───────────────────────────────────────────────────

        /// <summary>Get translation for key. Returns key if not found.</summary>
        public static string T(string key)
        {
            if (TryGet(key, out var el))
                return ElementToString(el, 1);
            return key;
        }

        /// <summary>Plural form. count=1 uses first element, count>1 uses second.</summary>
        public static string T(string key, int count)
        {
            if (TryGet(key, out var el))
                return ElementToString(el, count);
            return key;
        }

        /// <summary>String.Format — Tf("player.score", 4200) → "Score: 4200".</summary>
        public static string Tf(string key, params object[] args)
        {
            string raw = T(key);
            try { return string.Format(raw, args); }
            catch { return raw; }
        }

        /// <summary>Check if key exists in current language.</summary>
        public static bool Has(string key) => TryGet(key, out _);

        // ── Internal ──────────────────────────────────────────────────────
        private static bool TryGet(string key, out JsonElement el)
        {
            if (_active.TryGetValue(key, out el)) return true;
            if (_fallback.TryGetValue(key, out el)) return true;
            el = default;
            return false;
        }

        private static string ElementToString(JsonElement el, int count)
        {
            if (el.ValueKind == JsonValueKind.String)
                return el.GetString() ?? "";

            if (el.ValueKind == JsonValueKind.Array)
            {
                // [singular, plural] — index 0 for 1, index 1 for everything else
                int idx = count == 1 ? 0 : 1;
                int len = el.GetArrayLength();
                if (idx < len) return el[idx].GetString() ?? "";
                if (len > 0)   return el[0].GetString() ?? "";
                return "";
            }

            return el.ToString();
        }

        // ── Locale file generator (dev helper) ───────────────────────────
        /// <summary>
        /// Scans source for Loc.T("key") calls and generates a skeleton JSON.
        /// Run from editor: Loc.GenerateSkeleton("en");
        /// </summary>
        public static void GenerateSkeleton(string lang, IEnumerable<string>? keys = null)
        {
            Directory.CreateDirectory(LocalesDir);
            string path = Path.Combine(LocalesDir, $"{lang}.json");

            var existing = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (File.Exists(path))
            {
                var doc = JsonDocument.Parse(File.ReadAllText(path));
                foreach (var p in doc.RootElement.EnumerateObject())
                    if (p.Value.ValueKind == JsonValueKind.String)
                        existing[p.Name] = p.Value.GetString() ?? p.Name;
            }

            if (keys != null)
                foreach (var k in keys)
                    if (!existing.ContainsKey(k)) existing[k] = k;

            var opts = new JsonSerializerOptions { WriteIndented = true };
            File.WriteAllText(path, JsonSerializer.Serialize(existing, opts));
            Console.WriteLine($"[Loc] Skeleton written to {path}");
        }
    }
}
