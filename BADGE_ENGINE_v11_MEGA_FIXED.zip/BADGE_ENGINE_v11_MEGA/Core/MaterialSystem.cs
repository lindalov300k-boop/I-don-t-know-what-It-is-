using OpenTK.Mathematics;
using OpenTK.Graphics.OpenGL4;
using System.Collections.Generic;

namespace BADGE.Core;

/// <summary>
/// Material class for rendering with shaders
/// </summary>
public class Material
{
    public string Name { get; set; } = "Default Material";
    public Shader? Shader { get; set; }
    public Color4 Color { get; set; } = Color4.White;
    public Texture? MainTexture { get; set; }
    
    private Dictionary<string, object> _properties = new();
    
    // Keyword flags (emission, alpha clip, etc.)
    private readonly Dictionary<string, bool> _keywords = new();

    public Material()
    {
        Shader = ShaderLibrary.GetDefaultShader();
    }

    public Material(Shader shader)
    {
        Shader = shader;
    }

    /// <summary>
    /// Create a material by shader name — mirrors Unity's new Material(Shader.Find("Standard")).
    /// NEW: Was absent; LUMINOUS used new Material("Standard") everywhere.
    /// </summary>
    public Material(string shaderName)
    {
        Name   = shaderName + " Material";
        Shader = ShaderLibrary.GetShader(shaderName) ?? ShaderLibrary.GetDefaultShader();
    }

    // ── Keyword API ───────────────────────────────────────────────
    /// <summary>Enable or disable a shader keyword (e.g. "_EMISSION").</summary>
    public void SetKeyword(string keyword, bool enabled) => _keywords[keyword] = enabled;
    public void EnableKeyword(string keyword)            => _keywords[keyword] = true;
    public void DisableKeyword(string keyword)           => _keywords[keyword] = false;
    public bool IsKeywordEnabled(string keyword)         => _keywords.TryGetValue(keyword, out var v) && v;

    // ── Getter overloads ──────────────────────────────────────────
    public Color4  GetColor(string name)   => _properties.TryGetValue(name, out var v) && v is Color4  c ? c : Color4.Black;
    public float   GetFloat(string name)   => _properties.TryGetValue(name, out var v) && v is float   f ? f : 0f;
    public int     GetInt(string name)     => _properties.TryGetValue(name, out var v) && v is int     i ? i : 0;
    public Vector3 GetVector(string name)  => _properties.TryGetValue(name, out var v) && v is Vector3 w ? w : Vector3.Zero;
    
    public void SetFloat(string name, float value)
    {
        _properties[name] = value;
    }
    
    public void SetInt(string name, int value)
    {
        _properties[name] = value;
    }
    
    public void SetVector(string name, Vector3 value)
    {
        _properties[name] = value;
    }
    
    public void SetColor(string name, Color4 value)
    {
        _properties[name] = value;
    }
    
    public void SetTexture(string name, Texture value)
    {
        _properties[name] = value;
    }
    
    public void Apply()
    {
        if (Shader == null) return;
        
        Shader.Use();
        Shader.SetColor("_Color", Color);
        
        if (MainTexture != null)
        {
            GL.ActiveTexture(TextureUnit.Texture0);
            GL.BindTexture(TextureTarget.Texture2D, MainTexture.Handle);
            Shader.SetInt("_MainTex", 0);
        }
        
        // Apply custom properties
        foreach (var prop in _properties)
        {
            switch (prop.Value)
            {
                case float f:
                    Shader.SetFloat(prop.Key, f);
                    break;
                case int i:
                    Shader.SetInt(prop.Key, i);
                    break;
                case Vector3 v:
                    Shader.SetVector3(prop.Key, v);
                    break;
                case Color4 c:
                    Shader.SetColor(prop.Key, c);
                    break;
            }
        }
    }
}

/// <summary>
/// Shader program wrapper
/// </summary>
public class Shader
{
    public int Handle { get; private set; }
    public string Name { get; set; }
    
    private Dictionary<string, int> _uniformLocations = new();
    
    public Shader(string name, string vertexSource, string fragmentSource)
    {
        Name = name;
        
        int vertexShader = GL.CreateShader(ShaderType.VertexShader);
        GL.ShaderSource(vertexShader, vertexSource);
        GL.CompileShader(vertexShader);
        CheckShaderCompilation(vertexShader, "VERTEX");
        
        int fragmentShader = GL.CreateShader(ShaderType.FragmentShader);
        GL.ShaderSource(fragmentShader, fragmentSource);
        GL.CompileShader(fragmentShader);
        CheckShaderCompilation(fragmentShader, "FRAGMENT");
        
        Handle = GL.CreateProgram();
        GL.AttachShader(Handle, vertexShader);
        GL.AttachShader(Handle, fragmentShader);
        GL.LinkProgram(Handle);
        CheckProgramLinking(Handle);
        
        GL.DetachShader(Handle, vertexShader);
        GL.DetachShader(Handle, fragmentShader);
        GL.DeleteShader(vertexShader);
        GL.DeleteShader(fragmentShader);
    }
    
    private void CheckShaderCompilation(int shader, string type)
    {
        GL.GetShader(shader, ShaderParameter.CompileStatus, out int success);
        if (success == 0)
        {
            string infoLog = GL.GetShaderInfoLog(shader);
            Console.WriteLine($"ERROR::SHADER::{type}::COMPILATION_FAILED\n{infoLog}");
        }
    }
    
    private void CheckProgramLinking(int program)
    {
        GL.GetProgram(program, GetProgramParameterName.LinkStatus, out int success);
        if (success == 0)
        {
            string infoLog = GL.GetProgramInfoLog(program);
            Console.WriteLine($"ERROR::SHADER::PROGRAM::LINKING_FAILED\n{infoLog}");
        }
    }
    
    public void Use()
    {
        GL.UseProgram(Handle);
    }

    public void Unuse()
    {
        GL.UseProgram(0);
    }

    private int GetUniformLocation(string name)
    {
        if (!_uniformLocations.ContainsKey(name))
        {
            _uniformLocations[name] = GL.GetUniformLocation(Handle, name);
        }
        return _uniformLocations[name];
    }

    public void SetInt(string name, int value)
    {
        GL.Uniform1(GetUniformLocation(name), value);
    }

    public void SetFloat(string name, float value)
    {
        GL.Uniform1(GetUniformLocation(name), value);
    }

    public void SetVector3(string name, Vector3 value)
    {
        GL.Uniform3(GetUniformLocation(name), value);
    }

    public void SetVector4(string name, Vector4 value)
    {
        GL.Uniform4(GetUniformLocation(name), value);
    }

    public void SetColor(string name, Color4 value)
    {
        GL.Uniform4(GetUniformLocation(name), value);
    }

    public void SetMatrix4(string name, Matrix4 value)
    {
        GL.UniformMatrix4(GetUniformLocation(name), false, ref value);
    }

    public void SetMatrix4(string name, ref Matrix4 value)
    {
        GL.UniformMatrix4(GetUniformLocation(name), false, ref value);
    }
    
    public void Dispose()
    {
        GL.DeleteProgram(Handle);
    }
}

/// <summary>
/// Texture wrapper
/// </summary>
public class Texture
{
    public int Handle    { get; private set; }
    public int GlHandle  => Handle;   // alias used by renderers
    public int Width     { get; private set; }
    public int Height    { get; private set; }
    
    public Texture(int width, int height)
    {
        Width = width;
        Height = height;
        
        Handle = GL.GenTexture();
        GL.BindTexture(TextureTarget.Texture2D, Handle);
        
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMinFilter, (int)TextureMinFilter.Linear);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureMagFilter, (int)TextureMagFilter.Linear);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapS, (int)TextureWrapMode.Repeat);
        GL.TexParameter(TextureTarget.Texture2D, TextureParameterName.TextureWrapT, (int)TextureWrapMode.Repeat);
    }
    
    public void SetData(byte[] data)
    {
        GL.BindTexture(TextureTarget.Texture2D, Handle);
        GL.TexImage2D(TextureTarget.Texture2D, 0, PixelInternalFormat.Rgba, Width, Height, 0,
            PixelFormat.Rgba, PixelType.UnsignedByte, data);
        GL.GenerateMipmap(GenerateMipmapTarget.Texture2D);
    }
    
    public void Dispose()
    {
        GL.DeleteTexture(Handle);
    }
}

/// <summary>
/// Shader library for managing built-in shaders
/// </summary>
public static class ShaderLibrary
{
    private static Dictionary<string, Shader> _shaders = new();
    private static Shader? _defaultShader;
    
    public static void Initialize()
    {
        // Create default lit shader
        _defaultShader = CreateDefaultShader();
        _shaders["Standard"] = _defaultShader;
        
        // Create unlit shader
        _shaders["Unlit"] = CreateUnlitShader();

        // Gizmo shader (solid colour lines / wireframe)
        _shaders["Gizmo"] = CreateGizmoShader();

        // Sprite2D shader (orthographic quad rendering)
        _shaders["Sprite2D"] = CreateSprite2DShader();
    }
    
    public static Shader GetShader(string name)
    {
        return _shaders.GetValueOrDefault(name, _defaultShader!);
    }
    
    public static Shader GetDefaultShader()
    {
        return _defaultShader ?? CreateDefaultShader();
    }
    
    private static Shader CreateDefaultShader()
    {
        string vertexSource = @"
            #version 330 core
            layout (location = 0) in vec3 aPosition;
            layout (location = 1) in vec3 aNormal;
            layout (location = 2) in vec2 aTexCoord;
            
            out vec3 FragPos;
            out vec3 Normal;
            out vec2 TexCoord;
            
            uniform mat4 model;
            uniform mat4 view;
            uniform mat4 projection;
            
            void main()
            {
                FragPos = vec3(model * vec4(aPosition, 1.0));
                Normal = mat3(transpose(inverse(model))) * aNormal;
                TexCoord = aTexCoord;
                gl_Position = projection * view * vec4(FragPos, 1.0);
            }
        ";
        
        string fragmentSource = @"
            #version 330 core
            out vec4 FragColor;
            
            in vec3 FragPos;
            in vec3 Normal;
            in vec2 TexCoord;
            
            uniform vec4 _Color;
            uniform sampler2D _MainTex;
            uniform vec3 _LightDir;
            uniform vec3 _LightColor;
            
            void main()
            {
                vec3 norm = normalize(Normal);
                float diff = max(dot(norm, _LightDir), 0.0);
                vec3 diffuse = diff * _LightColor;
                
                vec3 ambient = vec3(0.3, 0.3, 0.3);
                vec3 result = (ambient + diffuse) * _Color.rgb;
                
                FragColor = vec4(result, _Color.a);
            }
        ";
        
        return new Shader("Standard", vertexSource, fragmentSource);
    }
    
    private static Shader CreateUnlitShader()
    {
        string vertexSource = @"
            #version 330 core
            layout (location = 0) in vec3 aPosition;
            layout (location = 2) in vec2 aTexCoord;
            
            out vec2 TexCoord;
            
            uniform mat4 model;
            uniform mat4 view;
            uniform mat4 projection;
            
            void main()
            {
                TexCoord = aTexCoord;
                gl_Position = projection * view * model * vec4(aPosition, 1.0);
            }
        ";
        
        string fragmentSource = @"
            #version 330 core
            out vec4 FragColor;
            
            in vec2 TexCoord;
            
            uniform vec4 _Color;
            uniform sampler2D _MainTex;
            
            void main()
            {
                FragColor = _Color;
            }
        ";
        
        return new Shader("Unlit", vertexSource, fragmentSource);
    }
    
    private static Shader CreateGizmoShader()
    {
        string vert = @"
            #version 330 core
            layout (location = 0) in vec3 aPosition;
            uniform mat4 model;
            uniform mat4 view;
            uniform mat4 projection;
            void main() {
                gl_Position = projection * view * model * vec4(aPosition, 1.0);
            }
        ";
        string frag = @"
            #version 330 core
            out vec4 FragColor;
            uniform vec4 _Color;
            void main() { FragColor = _Color; }
        ";
        return new Shader("Gizmo", vert, frag);
    }

    private static Shader CreateSprite2DShader()
    {
        string vert = @"
            #version 330 core
            layout (location = 0) in vec2 aPosition;
            layout (location = 1) in vec2 aUV;
            out vec2 TexCoord;
            uniform mat4 model;
            uniform mat4 projection;
            void main() {
                TexCoord    = aUV;
                gl_Position = projection * model * vec4(aPosition, 0.0, 1.0);
            }
        ";
        string frag = @"
            #version 330 core
            in vec2 TexCoord;
            out vec4 FragColor;
            uniform sampler2D _MainTex;
            uniform vec4 _Color;
            void main() {
                FragColor = texture(_MainTex, TexCoord) * _Color;
            }
        ";
        return new Shader("Sprite2D", vert, frag);
    }

    public static void Cleanup()
    {
        foreach (var shader in _shaders.Values)
        {
            shader.Dispose();
        }
        _shaders.Clear();
    }
}
