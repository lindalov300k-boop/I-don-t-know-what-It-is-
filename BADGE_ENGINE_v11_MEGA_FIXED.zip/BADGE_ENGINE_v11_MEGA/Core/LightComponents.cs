using OpenTK.Mathematics;

namespace BADGE.Core;

// ═══════════════════════════════════════════════════════════════════════
//  LIGHT COMPONENT BASE
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Base class for all light components.
///
/// NEW: The engine had no LightComponent type — FindAllComponents<LightComponent>()
///      was impossible, and LUMINOUS's glow light had no proper type.
/// </summary>
public abstract class LightComponent : Component
{
    public Color4 Color     { get; set; } = Color4.White;
    public float  Intensity { get; set; } = 1f;
    public bool   CastShadows { get; set; } = false;

    public abstract LightType LightType { get; }
}

public enum LightType { Point, Directional, Spot, Area }

// ═══════════════════════════════════════════════════════════════════════
//  POINT LIGHT
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Omnidirectional point light with attenuation range.
///
/// NEW: LUMINOUS's glow system needed this — engine only had the old
///      MonoBehaviour-level Camera-attached Light stub.
/// </summary>
public class PointLight : LightComponent
{
    public override LightType LightType => LightType.Point;

    /// <summary>World-space radius beyond which light has zero effect.</summary>
    public float Range { get; set; } = 10f;

    /// <summary>Attenuation curve: 1 = physical inverse-square, 0 = linear falloff.</summary>
    public float AttenuationExponent { get; set; } = 2f;

    /// <summary>
    /// Computes the 0–1 attenuation factor for a given distance from the light.
    /// </summary>
    public float GetAttenuation(float distance)
    {
        if (distance >= Range) return 0f;
        float normalized = 1f - distance / Range;
        return MathF.Pow(normalized, AttenuationExponent);
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  DIRECTIONAL LIGHT
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Infinite-distance directional light (like the sun).
/// Direction is taken from the component's transform forward vector.
/// </summary>
public class DirectionalLight : LightComponent
{
    public override LightType LightType => LightType.Directional;

    /// <summary>
    /// World-space direction toward the light source.
    /// Derived from Transform.Forward when not overridden.
    /// </summary>
    public Vector3? DirectionOverride { get; set; } = null;

    public Vector3 Direction =>
        DirectionOverride ?? (Transform != null ? -Transform.Forward : -Vector3.UnitY);
}

// ═══════════════════════════════════════════════════════════════════════
//  SPOT LIGHT
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Cone-shaped spot light with inner/outer angle falloff.
/// </summary>
public class SpotLight : LightComponent
{
    public override LightType LightType => LightType.Spot;

    public float Range      { get; set; } = 20f;

    /// <summary>Inner cone angle in degrees — full intensity within this.</summary>
    public float InnerAngle { get; set; } = 15f;

    /// <summary>Outer cone angle in degrees — zero intensity beyond this.</summary>
    public float OuterAngle { get; set; } = 30f;

    /// <summary>
    /// Computes 0–1 attenuation for a direction and distance from the spot.
    /// </summary>
    public float GetAttenuation(Vector3 toFragment, float distance)
    {
        if (distance >= Range) return 0f;

        var dir   = Transform?.Forward ?? -Vector3.UnitY;
        float dot = Vector3.Dot(dir, Vector3.Normalize(toFragment));
        float deg = MathHelper.RadiansToDegrees(MathF.Acos(Math.Clamp(dot, -1f, 1f)));

        float half = OuterAngle * 0.5f;
        if (deg > half) return 0f;

        float innerHalf = InnerAngle * 0.5f;
        float coneAtten = 1f - Math.Clamp((deg - innerHalf) / (half - innerHalf), 0f, 1f);
        float distAtten = 1f - distance / Range;

        return coneAtten * distAtten;
    }
}
