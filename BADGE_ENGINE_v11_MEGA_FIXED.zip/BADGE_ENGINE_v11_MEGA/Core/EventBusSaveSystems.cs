// BADGE ENGINE v8 — Core/EventBusSaveSystems.cs
// EventBus, SaveSystem, and CrashRecovery convenience entry-points.
// Full implementations live in Core/GameSystems/EventBus.cs and
// Core/GameSystems/SaveSystem.cs — these aliases keep old using
// directives working without duplicating code.

using BADGE.Core.GameSystems;

namespace BADGE.Core
{
    // CrashRecovery lives in PerformanceManager.cs (BADGE.Core namespace, complete implementation)
}
