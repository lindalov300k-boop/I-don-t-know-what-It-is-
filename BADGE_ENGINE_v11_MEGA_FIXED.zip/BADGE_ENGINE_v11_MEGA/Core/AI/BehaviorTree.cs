using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Core.AI;

// ═══════════════════════════════════════════════════════════════════════
//  BEHAVIOR TREE
//  GTA SA: CivNPC patrol → chase → flee → call police → fight
//  Subnautica: leviathan patrol → stalk → attack
//  Terraria: slime idle → hop → player spotted → aggro hop
// ═══════════════════════════════════════════════════════════════════════

public enum NodeStatus { Running, Success, Failure }

public abstract class BehaviorNode
{
    public string Name { get; set; } = "";
    public abstract NodeStatus Tick(float dt, Blackboard bb);
    public virtual void Reset() { }
}

// ── Composite nodes ───────────────────────────────────────────────────
/// <summary>Runs children left-to-right. Returns Success when all succeed.</summary>
public class Sequence : BehaviorNode
{
    private readonly List<BehaviorNode> _children;
    private int _index = 0;

    public Sequence(params BehaviorNode[] children) { _children = new(children); }

    public override NodeStatus Tick(float dt, Blackboard bb)
    {
        while (_index < _children.Count)
        {
            var status = _children[_index].Tick(dt, bb);
            if (status == NodeStatus.Failure) { Reset(); return NodeStatus.Failure; }
            if (status == NodeStatus.Running)  return NodeStatus.Running;
            _index++;
        }
        Reset();
        return NodeStatus.Success;
    }
    public override void Reset() { _index = 0; foreach (var c in _children) c.Reset(); }
}

/// <summary>Runs children until one succeeds.</summary>
public class Selector : BehaviorNode
{
    private readonly List<BehaviorNode> _children;
    private int _index = 0;

    public Selector(params BehaviorNode[] children) { _children = new(children); }

    public override NodeStatus Tick(float dt, Blackboard bb)
    {
        while (_index < _children.Count)
        {
            var status = _children[_index].Tick(dt, bb);
            if (status == NodeStatus.Success) { Reset(); return NodeStatus.Success; }
            if (status == NodeStatus.Running)  return NodeStatus.Running;
            _index++;
        }
        Reset();
        return NodeStatus.Failure;
    }
    public override void Reset() { _index = 0; foreach (var c in _children) c.Reset(); }
}

/// <summary>Runs all children every tick regardless of result.</summary>
public class Parallel : BehaviorNode
{
    private readonly List<BehaviorNode> _children;
    private readonly int _successThreshold;

    public Parallel(int successThreshold, params BehaviorNode[] children)
    { _children = new(children); _successThreshold = successThreshold; }

    public override NodeStatus Tick(float dt, Blackboard bb)
    {
        int successes = 0, failures = 0;
        foreach (var c in _children)
        {
            var s = c.Tick(dt, bb);
            if (s == NodeStatus.Success) successes++;
            if (s == NodeStatus.Failure) failures++;
        }
        if (successes >= _successThreshold) { Reset(); return NodeStatus.Success; }
        if (failures > _children.Count - _successThreshold) { Reset(); return NodeStatus.Failure; }
        return NodeStatus.Running;
    }
    public override void Reset() { foreach (var c in _children) c.Reset(); }
}

// ── Decorator nodes ───────────────────────────────────────────────────
public class Inverter : BehaviorNode
{
    private readonly BehaviorNode _child;
    public Inverter(BehaviorNode child) { _child = child; }
    public override NodeStatus Tick(float dt, Blackboard bb)
    {
        var s = _child.Tick(dt, bb);
        return s == NodeStatus.Success ? NodeStatus.Failure
             : s == NodeStatus.Failure ? NodeStatus.Success : NodeStatus.Running;
    }
}

public class Repeater : BehaviorNode
{
    private readonly BehaviorNode _child;
    private readonly int _times;    // -1 = forever
    private int _count = 0;
    public Repeater(BehaviorNode child, int times = -1) { _child = child; _times = times; }
    public override NodeStatus Tick(float dt, Blackboard bb)
    {
        if (_times > 0 && _count >= _times) { Reset(); return NodeStatus.Success; }
        var s = _child.Tick(dt, bb);
        if (s != NodeStatus.Running) { _child.Reset(); _count++; }
        return _times > 0 && _count >= _times ? NodeStatus.Success : NodeStatus.Running;
    }
    public override void Reset() { _count = 0; _child.Reset(); }
}

public class Cooldown : BehaviorNode
{
    private readonly BehaviorNode _child;
    private readonly float _cooldownSec;
    private float _elapsed = float.MaxValue;
    public Cooldown(BehaviorNode child, float cooldownSeconds) { _child = child; _cooldownSec = cooldownSeconds; }
    public override NodeStatus Tick(float dt, Blackboard bb)
    {
        _elapsed += dt;
        if (_elapsed < _cooldownSec) return NodeStatus.Failure;
        var s = _child.Tick(dt, bb);
        if (s == NodeStatus.Success) _elapsed = 0f;
        return s;
    }
}

// ── Leaf nodes ────────────────────────────────────────────────────────
/// <summary>Action node — wraps a delegate.</summary>
public class ActionNode : BehaviorNode
{
    private readonly Func<float, Blackboard, NodeStatus> _action;
    public ActionNode(string name, Func<float, Blackboard, NodeStatus> action)
    { Name = name; _action = action; }
    public override NodeStatus Tick(float dt, Blackboard bb) => _action(dt, bb);
}

/// <summary>Condition node — returns Success/Failure from a bool predicate.</summary>
public class ConditionNode : BehaviorNode
{
    private readonly Func<Blackboard, bool> _predicate;
    public ConditionNode(string name, Func<Blackboard, bool> pred)
    { Name = name; _predicate = pred; }
    public override NodeStatus Tick(float dt, Blackboard bb)
        => _predicate(bb) ? NodeStatus.Success : NodeStatus.Failure;
}

/// <summary>Wait node — running for a fixed duration then succeeds.</summary>
public class Wait : BehaviorNode
{
    private readonly float _duration;
    private float _elapsed;
    public Wait(float seconds) { _duration = seconds; }
    public override NodeStatus Tick(float dt, Blackboard bb)
    {
        _elapsed += dt;
        if (_elapsed >= _duration) { _elapsed = 0f; return NodeStatus.Success; }
        return NodeStatus.Running;
    }
    public override void Reset() { _elapsed = 0f; }
}

// ── Blackboard ────────────────────────────────────────────────────────
/// <summary>Shared data dictionary for all behavior tree nodes.</summary>
public class Blackboard
{
    private readonly Dictionary<string, object?> _data = new();

    public void   Set<T>(string key, T value) => _data[key] = value;
    public T?     Get<T>(string key)           => _data.TryGetValue(key, out var v) && v is T t ? t : default;
    public bool   Has(string key)              => _data.ContainsKey(key);
    public void   Unset(string key)            => _data.Remove(key);

    // Typed shorthand
    public Vector3 GetVector3(string key, Vector3 def = default) => Get<Vector3?>(key) ?? def;
    public float   GetFloat  (string key, float   def = 0f)      => Get<float?>(key)   ?? def;
    public bool    GetBool   (string key, bool    def = false)    => Get<bool?>(key)    ?? def;
    public int     GetInt    (string key, int     def = 0)        => Get<int?>(key)     ?? def;
    public string  GetString (string key, string  def = "")       => Get<string>(key)   ?? def;
}

// ── BehaviorTree Runner component ─────────────────────────────────────
public class BehaviorTreeRunner : Component
{
    public BehaviorNode? Root      { get; set; }
    public Blackboard    Board     { get; } = new();
    public float         TickRate  { get; set; } = 0.05f; // 20 times/sec
    private float        _timer    = 0f;

    public override void Update(float dt)
    {
        _timer += dt;
        if (_timer >= TickRate)
        {
            _timer = 0f;
            Root?.Tick(dt, Board);
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  A* PATHFINDING
//  GTA: pedestrians navigate city grid
//  Terraria: enemies path around terrain
//  Subnautica: sea creatures navigate 3D space
// ═══════════════════════════════════════════════════════════════════════
public static class Pathfinding
{
    // ── Grid pathfinding ──────────────────────────────────────────
    public static List<Vector2Int> FindPath2D(bool[,] walkable, Vector2Int start, Vector2Int goal,
        bool diagonals = true)
    {
        int w = walkable.GetLength(0), h = walkable.GetLength(1);
        var open   = new SortedSet<ANode2D>(Comparer<ANode2D>.Create((a, b) => a.F != b.F ? a.F.CompareTo(b.F) : a.Pos.GetHashCode().CompareTo(b.Pos.GetHashCode())));
        var closed = new HashSet<Vector2Int>();
        var dict   = new Dictionary<Vector2Int, ANode2D>();

        var startNode = new ANode2D(start, null, 0, Heuristic2D(start, goal));
        open.Add(startNode);
        dict[start] = startNode;

        int[] dx = diagonals ? new[]{0,0,1,-1,1,1,-1,-1} : new[]{0,0,1,-1};
        int[] dy = diagonals ? new[]{1,-1,0,0,1,-1,1,-1} : new[]{1,-1,0,0};

        while (open.Count > 0)
        {
            var current = open.Min!;
            open.Remove(current);
            closed.Add(current.Pos);

            if (current.Pos == goal) return ReconstructPath2D(current);

            for (int d = 0; d < dx.Length; d++)
            {
                var np = new Vector2Int(current.Pos.X + dx[d], current.Pos.Y + dy[d]);
                if (np.X < 0 || np.Y < 0 || np.X >= w || np.Y >= h) continue;
                if (!walkable[np.X, np.Y] || closed.Contains(np)) continue;

                float cost = d < 4 ? 1f : 1.414f;
                float g    = current.G + cost;
                float h    = Heuristic2D(np, goal);

                if (dict.TryGetValue(np, out var existing) && existing.G <= g) continue;

                var node = new ANode2D(np, current, g, h);
                if (existing != null) open.Remove(existing);
                open.Add(node);
                dict[np] = node;
            }
        }
        return new List<Vector2Int>(); // no path
    }

    private static float Heuristic2D(Vector2Int a, Vector2Int b)
        => MathF.Sqrt((a.X - b.X) * (a.X - b.X) + (a.Y - b.Y) * (a.Y - b.Y));

    private static List<Vector2Int> ReconstructPath2D(ANode2D node)
    {
        var path = new List<Vector2Int>();
        for (var n = node; n != null; n = n.Parent) path.Add(n.Pos);
        path.Reverse();
        return path;
    }

    // ── Steering behaviours ───────────────────────────────────────
    public static Vector3 Seek(Vector3 pos, Vector3 target, float maxSpeed)
        => Vector3.Normalize(target - pos) * maxSpeed;

    public static Vector3 Flee(Vector3 pos, Vector3 threat, float maxSpeed)
        => Vector3.Normalize(pos - threat) * maxSpeed;

    public static Vector3 Arrive(Vector3 pos, Vector3 target, float maxSpeed, float slowRadius = 3f)
    {
        var dir = target - pos;
        float dist = dir.Length;
        if (dist < 0.01f) return Vector3.Zero;
        float speed = dist < slowRadius ? maxSpeed * (dist / slowRadius) : maxSpeed;
        return dir.Normalized() * speed;
    }

    public static Vector3 Wander(ref float wanderAngle, float speed, float jitter = 0.5f, Random? rng = null)
    {
        rng ??= new Random();
        wanderAngle += ((float)rng.NextDouble() * 2 - 1) * jitter;
        return new Vector3(MathF.Cos(wanderAngle), 0f, MathF.Sin(wanderAngle)) * speed;
    }

    private class ANode2D { public Vector2Int Pos; public ANode2D? Parent; public float G, H; public float F => G + H; public ANode2D(Vector2Int p, ANode2D? par, float g, float h) { Pos=p; Parent=par; G=g; H=h; } }
}

public struct Vector2Int : IEquatable<Vector2Int>
{
    public int X, Y;
    public Vector2Int(int x, int y) { X = x; Y = y; }
    public bool Equals(Vector2Int o) => X == o.X && Y == o.Y;
    public override bool Equals(object? o) => o is Vector2Int v && Equals(v);
    public override int GetHashCode() => HashCode.Combine(X, Y);
    public static bool operator ==(Vector2Int a, Vector2Int b) => a.Equals(b);
    public static bool operator !=(Vector2Int a, Vector2Int b) => !a.Equals(b);
    public Vector2 ToVector2() => new Vector2(X, Y);
}
