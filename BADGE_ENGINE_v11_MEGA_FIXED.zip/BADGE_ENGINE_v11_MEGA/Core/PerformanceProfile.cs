using System;
using System.Runtime;
using System.Runtime.InteropServices;

namespace BADGE.Core
{
    // ══════════════════════════════════════════════════════════════════════════
    //  BADGE ENGINE v8 — PERFORMANCE PROFILE
    //  Basic Atlas Dimensional Game Engine
    //
    //  Target minimum hardware:
    //    CPU  : Intel Pentium / AMD equivalent (dual-core)
    //    RAM  : 4 GB  ← Design target. This is the floor, not the ceiling.
    //    GPU  : OpenGL 3.3 integrated or discrete
    //
    //  BADGE is engineered to run smoothly on this hardware.
    //  Every system has a low-end path. No feature silently hogs memory.
    //  The idle throttle system (EngineThrottle) ensures CPU sits at
    //  near-zero when the editor is not actively being used.
    //
    //  This class detects hardware tier at startup and applies the right
    //  default quality settings automatically.
    // ══════════════════════════════════════════════════════════════════════════

    public enum HardwareTier
    {
        Minimum   = 0,   // Pentium, 4 GB RAM, integrated GPU
        Low       = 1,   // Dual-core i3/Ryzen 3, 8 GB, entry discrete
        Mid       = 2,   // Quad-core i5/Ryzen 5, 16 GB, mid-range GPU
        High      = 3,   // i7/Ryzen 7+, 32 GB+, high-end GPU
    }

    public sealed class PerformanceProfile
    {
        public static PerformanceProfile Instance { get; } = new();

        // ── Detected tier ─────────────────────────────────────────────────
        public HardwareTier Tier         { get; private set; } = HardwareTier.Mid;
        public long         TotalRamMB   { get; private set; }
        public int          LogicalCores { get; private set; }
        public bool         IsMinimumSpec=> Tier == HardwareTier.Minimum;
        public bool         IsLowSpec    => Tier <= HardwareTier.Low;

        // ── Quality settings (auto-set by tier) ──────────────────────────
        public int   MaxTextureSize      { get; set; }
        public int   ShadowMapResolution { get; set; }
        public int   TargetFPS           { get; set; }
        public bool  EnablePostProcess   { get; set; }
        public bool  EnableBloom         { get; set; }
        public bool  EnableSSAO          { get; set; }
        public bool  EnableRaycast       { get; set; }
        public int   MaxParticles        { get; set; }
        public int   AudioBufferSize     { get; set; }
        public int   MaxActiveSounds     { get; set; }
        public int   PhysicsStepsPerSec  { get; set; }
        public bool  EnableDynamicLOD    { get; set; }
        public float LODBias             { get; set; }
        public bool  GCServerMode        { get; set; }
        public int   JobWorkerThreads    { get; set; }
        public bool  TextureStreaming    { get; set; }
        public bool  AsyncAssetLoading   { get; set; }
        public int   MaxCacheMemoryMB    { get; set; }

        private PerformanceProfile() { }

        // ── Detect & apply ────────────────────────────────────────────────
        public void DetectAndApply()
        {
            TotalRamMB   = GetTotalRamMB();
            LogicalCores = Environment.ProcessorCount;
            Tier         = ClassifyTier(TotalRamMB, LogicalCores);

            ApplyProfile(Tier);
            ApplyGCSettings();

            Console.WriteLine($"[PerformanceProfile] Detected: {Tier} tier");
            Console.WriteLine($"  RAM: {TotalRamMB} MB  |  Cores: {LogicalCores}  |  OS: {RuntimeInformation.OSDescription}");
            Console.WriteLine($"  Target FPS: {TargetFPS}  |  Max particles: {MaxParticles}  |  Audio buffer: {AudioBufferSize}");

            if (IsMinimumSpec)
            {
                Console.WriteLine("  [PerformanceProfile] Minimum spec detected (4 GB Pentium target).");
                Console.WriteLine("  Low-memory paths active. Dynamic LOD enabled. Post-process disabled.");
                Console.WriteLine("  BADGE is built for this hardware — expect smooth performance.");
            }
        }

        private static HardwareTier ClassifyTier(long ramMB, int cores)
        {
            if (ramMB < 6000 || cores <= 2)  return HardwareTier.Minimum;
            if (ramMB < 12000 || cores <= 4) return HardwareTier.Low;
            if (ramMB < 24000 || cores <= 8) return HardwareTier.Mid;
            return HardwareTier.High;
        }

        private void ApplyProfile(HardwareTier tier)
        {
            switch (tier)
            {
                case HardwareTier.Minimum:
                    // Pentium, 4 GB RAM — every byte and cycle matters
                    MaxTextureSize      = 1024;
                    ShadowMapResolution = 512;
                    TargetFPS           = 30;
                    EnablePostProcess   = false;
                    EnableBloom         = false;
                    EnableSSAO          = false;
                    EnableRaycast       = false;
                    MaxParticles        = 500;
                    AudioBufferSize     = 1024;
                    MaxActiveSounds     = 8;
                    PhysicsStepsPerSec  = 30;
                    EnableDynamicLOD    = true;
                    LODBias             = 0.6f;
                    GCServerMode        = false;
                    JobWorkerThreads    = 1;
                    TextureStreaming    = true;
                    AsyncAssetLoading  = true;
                    MaxCacheMemoryMB    = 256;
                    break;

                case HardwareTier.Low:
                    MaxTextureSize      = 2048;
                    ShadowMapResolution = 1024;
                    TargetFPS           = 60;
                    EnablePostProcess   = true;
                    EnableBloom         = false;
                    EnableSSAO          = false;
                    EnableRaycast       = true;
                    MaxParticles        = 2000;
                    AudioBufferSize     = 512;
                    MaxActiveSounds     = 16;
                    PhysicsStepsPerSec  = 60;
                    EnableDynamicLOD    = true;
                    LODBias             = 0.8f;
                    GCServerMode        = false;
                    JobWorkerThreads    = 2;
                    TextureStreaming    = true;
                    AsyncAssetLoading  = true;
                    MaxCacheMemoryMB    = 512;
                    break;

                case HardwareTier.Mid:
                    MaxTextureSize      = 4096;
                    ShadowMapResolution = 2048;
                    TargetFPS           = 60;
                    EnablePostProcess   = true;
                    EnableBloom         = true;
                    EnableSSAO          = true;
                    EnableRaycast       = true;
                    MaxParticles        = 8000;
                    AudioBufferSize     = 256;
                    MaxActiveSounds     = 32;
                    PhysicsStepsPerSec  = 60;
                    EnableDynamicLOD    = true;
                    LODBias             = 1.0f;
                    GCServerMode        = true;
                    JobWorkerThreads    = 4;
                    TextureStreaming    = false;
                    AsyncAssetLoading  = true;
                    MaxCacheMemoryMB    = 1024;
                    break;

                case HardwareTier.High:
                    MaxTextureSize      = 8192;
                    ShadowMapResolution = 4096;
                    TargetFPS           = 120;
                    EnablePostProcess   = true;
                    EnableBloom         = true;
                    EnableSSAO          = true;
                    EnableRaycast       = true;
                    MaxParticles        = 50000;
                    AudioBufferSize     = 128;
                    MaxActiveSounds     = 64;
                    PhysicsStepsPerSec  = 120;
                    EnableDynamicLOD    = false;
                    LODBias             = 1.2f;
                    GCServerMode        = true;
                    JobWorkerThreads    = Math.Max(4, Environment.ProcessorCount - 2);
                    TextureStreaming    = false;
                    AsyncAssetLoading  = true;
                    MaxCacheMemoryMB    = 4096;
                    break;
            }
        }

        private void ApplyGCSettings()
        {
            if (GCServerMode)
                GCSettings.LatencyMode = GCLatencyMode.SustainedLowLatency;
            else
                GCSettings.LatencyMode = GCLatencyMode.Interactive;
        }

        // ── Override ──────────────────────────────────────────────────────
        public void ForceTier(HardwareTier tier)
        {
            Tier = tier;
            ApplyProfile(tier);
            ApplyGCSettings();
            Console.WriteLine($"[PerformanceProfile] Tier overridden to: {tier}");
        }

        public void SetTargetFPS(int fps)
        {
            TargetFPS = fps;
            EngineThrottle.Instance.ActiveFPS = fps;
        }

        // ── Memory pressure ───────────────────────────────────────────────
        public void OnLowMemory()
        {
            Console.WriteLine("[PerformanceProfile] Low memory detected — flushing caches.");
            MaxCacheMemoryMB = Math.Max(64, MaxCacheMemoryMB / 2);
            GC.Collect(2, GCCollectionMode.Aggressive, blocking: false, compacting: true);
        }

        // ── Diagnostics ───────────────────────────────────────────────────
        public string GetDiagnosticString()
        {
            return $"BADGE Engine v8 | Tier: {Tier} | RAM: {TotalRamMB}MB | " +
                   $"Cores: {LogicalCores} | FPS target: {TargetFPS} | " +
                   $"Particles: {MaxParticles} | Post-FX: {EnablePostProcess}";
        }

        // ── Platform RAM detection ─────────────────────────────────────────
        private static long GetTotalRamMB()
        {
            try
            {
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                    return GetWindowsRamMB();
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                    return GetLinuxRamMB();
                if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
                    return GetMacRamMB();
            }
            catch { }
            return 4096; // Safe default — assume minimum spec
        }

        private static long GetWindowsRamMB()
        {
            var info = new MEMORYSTATUSEX { dwLength = (uint)Marshal.SizeOf<MEMORYSTATUSEX>() };
            return GlobalMemoryStatusEx(ref info) ? (long)(info.ullTotalPhys / 1048576) : 4096;
        }

        private static long GetLinuxRamMB()
        {
            foreach (var line in System.IO.File.ReadLines("/proc/meminfo"))
                if (line.StartsWith("MemTotal:"))
                {
                    var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length >= 2 && long.TryParse(parts[1], out long kB))
                        return kB / 1024;
                }
            return 4096;
        }

        private static long GetMacRamMB()
        {
            var p = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            { FileName = "sysctl", Arguments = "-n hw.memsize", RedirectStandardOutput = true, UseShellExecute = false });
            p?.WaitForExit();
            if (long.TryParse(p?.StandardOutput.ReadToEnd().Trim(), out long bytes))
                return bytes / 1048576;
            return 4096;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MEMORYSTATUSEX
        {
            public uint  dwLength;
            public uint  dwMemoryLoad;
            public ulong ullTotalPhys;
            public ulong ullAvailPhys;
            public ulong ullTotalPageFile;
            public ulong ullAvailPageFile;
            public ulong ullTotalVirtual;
            public ulong ullAvailVirtual;
            public ulong ullAvailExtendedVirtual;
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX lpBuffer);
    }
}
