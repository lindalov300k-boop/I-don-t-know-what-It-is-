using System;
using System.Collections.Generic;
using System.Linq;
using OpenTK.Mathematics;
using BADGE.Core;

namespace BADGE.GameFeatures
{
    // ==================== PIANO TILES / RHYTHM GAME SYSTEM ====================

    /// <summary>
    /// Rhythm game mechanics system (Piano Tiles, Guitar Hero, etc.)
    /// </summary>
    public class RhythmGameSystem
    {
        public class Note
        {
            public float Time { get; set; }
            public int Lane { get; set; }
            public float Duration { get; set; }
            public bool IsHit { get; set; }
            public float HitAccuracy { get; set; }
        }

        public class Track
        {
            public List<Note> Notes { get; set; } = new List<Note>();
            public float BPM { get; set; } = 120f;
            public float Speed { get; set; } = 1.0f;
        }

        private Track _currentTrack;
        private float _currentTime;
        private int _score;
        private int _combo;
        private int _maxCombo;
        private const float HIT_WINDOW_PERFECT = 0.05f;
        private const float HIT_WINDOW_GOOD = 0.1f;
        private const float HIT_WINDOW_OK = 0.15f;

        public int Score => _score;
        public int Combo => _combo;
        public int MaxCombo => _maxCombo;

        public void LoadTrack(Track track)
        {
            _currentTrack = track;
            _currentTime = 0;
            _score = 0;
            _combo = 0;
            _maxCombo = 0;
        }

        public void Update(float deltaTime)
        {
            if (_currentTrack == null) return;
            _currentTime += deltaTime * _currentTrack.Speed;

            // Auto-fail missed notes
            foreach (var note in _currentTrack.Notes.Where(n => !n.IsHit))
            {
                if (_currentTime - note.Time > HIT_WINDOW_OK)
                {
                    MissNote(note);
                }
            }
        }

        public HitResult TryHitNote(int lane)
        {
            var activeNotes = _currentTrack.Notes
                .Where(n => n.Lane == lane && !n.IsHit && Math.Abs(_currentTime - n.Time) <= HIT_WINDOW_OK)
                .OrderBy(n => Math.Abs(_currentTime - n.Time))
                .ToList();

            if (activeNotes.Count == 0)
                return new HitResult { Success = false, Timing = HitTiming.Miss };

            var closestNote = activeNotes.First();
            float timeDiff = Math.Abs(_currentTime - closestNote.Time);

            HitTiming timing;
            int points;

            if (timeDiff <= HIT_WINDOW_PERFECT)
            {
                timing = HitTiming.Perfect;
                points = 300;
            }
            else if (timeDiff <= HIT_WINDOW_GOOD)
            {
                timing = HitTiming.Good;
                points = 200;
            }
            else
            {
                timing = HitTiming.OK;
                points = 100;
            }

            closestNote.IsHit = true;
            closestNote.HitAccuracy = timeDiff;
            _combo++;
            _maxCombo = Math.Max(_maxCombo, _combo);
            _score += points * Math.Max(1, _combo / 10);

            return new HitResult { Success = true, Timing = timing, Points = points };
        }

        private void MissNote(Note note)
        {
            note.IsHit = true;
            _combo = 0;
        }

        public enum HitTiming { Perfect, Good, OK, Miss }

        public class HitResult
        {
            public bool Success { get; set; }
            public HitTiming Timing { get; set; }
            public int Points { get; set; }
        }
    }

    // ==================== HILL CLIMBER / VEHICLE PHYSICS SYSTEM ====================

    /// <summary>
    /// Advanced 2D vehicle physics system (Hill Climber, Trials, etc.)
    /// </summary>
    public class Vehicle2DPhysics
    {
        public class Wheel
        {
            public Vector2 Position { get; set; }
            public float Radius { get; set; }
            public float SuspensionStiffness { get; set; } = 200f;
            public float SuspensionDamping { get; set; } = 20f;
            public float Grip { get; set; } = 1.0f;
            public float AngularVelocity { get; set; }
            public bool IsGrounded { get; set; }
        }

        public Vector2 Position { get; set; }
        public Vector2 Velocity { get; set; }
        public float Rotation { get; set; }
        public float AngularVelocity { get; set; }
        public float Mass { get; set; } = 100f;
        public float EnginePower { get; set; } = 500f;
        public float BrakePower { get; set; } = 300f;
        public List<Wheel> Wheels { get; set; } = new List<Wheel>();

        private float _throttle;
        private float _brake;
        private Vector2 _centerOfMass;

        public void SetThrottle(float value) => _throttle = Math.Clamp(value, -1f, 1f);
        public void SetBrake(float value) => _brake = Math.Clamp(value, 0f, 1f);

        public void Update(float deltaTime)
        {
            // Apply gravity
            Velocity += new Vector2(0, -9.81f) * deltaTime;

            // Update each wheel
            foreach (var wheel in Wheels)
            {
                UpdateWheel(wheel, deltaTime);
            }

            // Apply engine forces
            ApplyEngineTorque(_throttle);
            ApplyBrakes(_brake);

            // Update position and rotation
            Position += Velocity * deltaTime;
            Rotation += AngularVelocity * deltaTime;

            // Apply air resistance
            Velocity *= Math.Max(0, 1.0f - 0.1f * deltaTime);
            AngularVelocity *= Math.Max(0, 1.0f - 0.1f * deltaTime);
        }

        private void UpdateWheel(Wheel wheel, float deltaTime)
        {
            // Simple ground detection (in real implementation, use raycasting)
            wheel.IsGrounded = Position.Y <= 0;

            if (wheel.IsGrounded)
            {
                // Apply suspension forces
                float compression = -Position.Y;
                float suspensionForce = compression * wheel.SuspensionStiffness;
                Velocity += new Vector2(0, suspensionForce / Mass) * deltaTime;

                // Apply grip
                float lateralVelocity = Velocity.X;
                float gripForce = -lateralVelocity * wheel.Grip;
                Velocity += new Vector2(gripForce, 0) * deltaTime;
            }
        }

        private void ApplyEngineTorque(float throttle)
        {
            if (Math.Abs(throttle) < 0.01f) return;

            foreach (var wheel in Wheels.Where(w => w.IsGrounded))
            {
                float torque = throttle * EnginePower;
                wheel.AngularVelocity += torque;
                
                // Transfer to linear velocity
                float wheelVelocity = wheel.AngularVelocity * wheel.Radius;
                Velocity += new Vector2(wheelVelocity, 0) * 0.1f;
            }
        }

        private void ApplyBrakes(float brake)
        {
            if (brake < 0.01f) return;

            foreach (var wheel in Wheels.Where(w => w.IsGrounded))
            {
                wheel.AngularVelocity *= (1.0f - brake * 0.5f);
            }

            Velocity *= (1.0f - brake * 0.3f);
        }

        public void AddWheel(Vector2 localPosition, float radius)
        {
            Wheels.Add(new Wheel
            {
                Position = localPosition,
                Radius = radius
            });
        }
    }

    // ==================== MONOPOLY / BOARD GAME SYSTEM ====================

    /// <summary>
    /// Turn-based board game system (Monopoly, board games)
    /// </summary>
    public class BoardGameSystem
    {
        public class BoardSpace
        {
            public int Index { get; set; }
            public string Name { get; set; }
            public SpaceType Type { get; set; }
            public int Price { get; set; }
            public string Owner { get; set; }
            public int Rent { get; set; }
            public Dictionary<string, object> Properties { get; set; } = new Dictionary<string, object>();
        }

        public enum SpaceType
        {
            Property,
            Chance,
            CommunityChest,
            Tax,
            Jail,
            FreeParking,
            Go,
            Railroad,
            Utility
        }

        public class Player
        {
            public string Id { get; set; }
            public string Name { get; set; }
            public int Money { get; set; } = 1500;
            public int Position { get; set; }
            public List<BoardSpace> Properties { get; set; } = new List<BoardSpace>();
            public bool InJail { get; set; }
            public int JailTurns { get; set; }
            public Dictionary<string, int> Inventory { get; set; } = new Dictionary<string, int>();
        }

        private List<BoardSpace> _board;
        private List<Player> _players;
        private int _currentPlayerIndex;
        private Random _random;

        public Player CurrentPlayer => _players[_currentPlayerIndex];
        public List<Player> Players => _players;

        public BoardGameSystem()
        {
            _board = new List<BoardSpace>();
            _players = new List<Player>();
            _random = new Random();
        }

        public void CreateBoard(int spaces)
        {
            _board.Clear();
            for (int i = 0; i < spaces; i++)
            {
                _board.Add(new BoardSpace
                {
                    Index = i,
                    Name = $"Space {i}",
                    Type = SpaceType.Property
                });
            }
        }

        public void AddPlayer(string name)
        {
            _players.Add(new Player
            {
                Id = Guid.NewGuid().ToString(),
                Name = name,
                Position = 0
            });
        }

        public (int, int) RollDice()
        {
            int die1 = _random.Next(1, 7);
            int die2 = _random.Next(1, 7);
            return (die1, die2);
        }

        public void MovePlayer(Player player, int spaces)
        {
            int oldPosition = player.Position;
            player.Position = (player.Position + spaces) % _board.Count;

            // Check if passed GO
            if (player.Position < oldPosition)
            {
                player.Money += 200; // Collect GO money
                Console.WriteLine($"{player.Name} passed GO and collected $200!");
            }

            ProcessLanding(player);
        }

        private void ProcessLanding(Player player)
        {
            var space = _board[player.Position];
            Console.WriteLine($"{player.Name} landed on {space.Name}");

            switch (space.Type)
            {
                case SpaceType.Property:
                    if (string.IsNullOrEmpty(space.Owner))
                    {
                        // Property available for purchase
                    }
                    else if (space.Owner != player.Id)
                    {
                        // Pay rent
                        PayRent(player, space);
                    }
                    break;

                case SpaceType.Chance:
                case SpaceType.CommunityChest:
                    DrawCard(player, space.Type);
                    break;

                case SpaceType.Tax:
                    player.Money -= space.Price;
                    break;

                case SpaceType.Jail:
                    SendToJail(player);
                    break;
            }
        }

        private void PayRent(Player player, BoardSpace space)
        {
            var owner = _players.FirstOrDefault(p => p.Id == space.Owner);
            if (owner != null)
            {
                int rent = space.Rent;
                player.Money -= rent;
                owner.Money += rent;
                Console.WriteLine($"{player.Name} paid ${rent} rent to {owner.Name}");
            }
        }

        private void DrawCard(Player player, SpaceType type)
        {
            // Implement card drawing logic
        }

        private void SendToJail(Player player)
        {
            player.InJail = true;
            player.Position = 10; // Jail position
            player.JailTurns = 0;
        }

        public void NextTurn()
        {
            _currentPlayerIndex = (_currentPlayerIndex + 1) % _players.Count;
        }

        public bool BuyProperty(Player player, BoardSpace space)
        {
            if (player.Money >= space.Price && string.IsNullOrEmpty(space.Owner))
            {
                player.Money -= space.Price;
                space.Owner = player.Id;
                player.Properties.Add(space);
                return true;
            }
            return false;
        }
    }

    // ==================== POKEMON / RPG BATTLE SYSTEM ====================

    /// <summary>
    /// Turn-based RPG battle system (Pokemon-style)
    /// </summary>
    public class RPGBattleSystem
    {
        public class Creature
        {
            public string Name { get; set; }
            public int Level { get; set; }
            public int HP { get; set; }
            public int MaxHP { get; set; }
            public int Attack { get; set; }
            public int Defense { get; set; }
            public int Speed { get; set; }
            public List<Move> Moves { get; set; } = new List<Move>();
            public CreatureType Type { get; set; }
            public Dictionary<string, int> Stats { get; set; } = new Dictionary<string, int>();
            public List<StatusEffect> StatusEffects { get; set; } = new List<StatusEffect>();
        }

        public enum CreatureType { Normal, Fire, Water, Grass, Electric, Ice, Fighting, Poison, Ground, Flying, Psychic, Bug, Rock, Ghost, Dragon, Dark, Steel, Fairy }

        public class Move
        {
            public string Name { get; set; }
            public CreatureType Type { get; set; }
            public int Power { get; set; }
            public int Accuracy { get; set; }
            public int PP { get; set; }
            public int MaxPP { get; set; }
            public MoveCategory Category { get; set; }
            public Action<Creature, Creature> Effect { get; set; }
        }

        public enum MoveCategory { Physical, Special, Status }

        public class StatusEffect
        {
            public string Name { get; set; }
            public int Duration { get; set; }
            public Action<Creature> OnTurn { get; set; }
        }

        private Creature _player;
        private Creature _enemy;
        private Random _random = new Random();

        public void StartBattle(Creature player, Creature enemy)
        {
            _player = player;
            _enemy = enemy;
            Console.WriteLine($"{_player.Name} encountered {_enemy.Name}!");
        }

        public BattleResult ExecuteMove(Move move, bool playerFirst)
        {
            Creature attacker = playerFirst ? _player : _enemy;
            Creature defender = playerFirst ? _enemy : _player;

            // Check if move hits
            if (_random.Next(100) >= move.Accuracy)
            {
                return new BattleResult { Hit = false, Message = $"{attacker.Name}'s attack missed!" };
            }

            // Calculate damage
            float effectiveness = GetTypeEffectiveness(move.Type, defender.Type);
            int baseDamage = move.Power;
            int attackStat = move.Category == MoveCategory.Physical ? attacker.Attack : attacker.Attack;
            int defenseStat = move.Category == MoveCategory.Physical ? defender.Defense : defender.Defense;

            int damage = (int)(((2 * attacker.Level / 5.0f + 2) * baseDamage * attackStat / defenseStat) / 50 + 2);
            damage = (int)(damage * effectiveness);

            // Apply random modifier (85-100%)
            damage = (int)(damage * (0.85f + _random.NextSingle() * 0.15f));

            defender.HP = Math.Max(0, defender.HP - damage);

            string effectivenessText = effectiveness > 1.0f ? "It's super effective!" :
                                      effectiveness < 1.0f ? "It's not very effective..." : "";

            return new BattleResult
            {
                Hit = true,
                Damage = damage,
                Critical = false,
                Message = $"{attacker.Name} used {move.Name}! {effectivenessText}",
                BattleOver = defender.HP <= 0
            };
        }

        private float GetTypeEffectiveness(CreatureType attack, CreatureType defense)
        {
            // Simplified type chart
            var effectiveness = new Dictionary<(CreatureType, CreatureType), float>
            {
                { (CreatureType.Fire, CreatureType.Grass), 2.0f },
                { (CreatureType.Water, CreatureType.Fire), 2.0f },
                { (CreatureType.Grass, CreatureType.Water), 2.0f },
                { (CreatureType.Electric, CreatureType.Water), 2.0f },
                { (CreatureType.Fire, CreatureType.Water), 0.5f },
                { (CreatureType.Water, CreatureType.Grass), 0.5f },
                { (CreatureType.Grass, CreatureType.Fire), 0.5f }
            };

            return effectiveness.TryGetValue((attack, defense), out float value) ? value : 1.0f;
        }

        public class BattleResult
        {
            public bool Hit { get; set; }
            public int Damage { get; set; }
            public bool Critical { get; set; }
            public string Message { get; set; }
            public bool BattleOver { get; set; }
        }
    }

    // ==================== AMONG US / SOCIAL DEDUCTION SYSTEM ====================

    /// <summary>
    /// Social deduction / multiplayer task system (Among Us-style)
    /// </summary>
    public class SocialDeductionSystem
    {
        public enum PlayerRole { Crewmate, Impostor }

        public class GamePlayer
        {
            public string Id { get; set; }
            public string Name { get; set; }
            public PlayerRole Role { get; set; }
            public bool IsAlive { get; set; } = true;
            public Vector2 Position { get; set; }
            public List<string> CompletedTasks { get; set; } = new List<string>();
            public bool InVent { get; set; }
        }

        public class Task
        {
            public string Id { get; set; }
            public string Name { get; set; }
            public Vector2 Location { get; set; }
            public TaskType Type { get; set; }
            public int StepCount { get; set; }
            public int CurrentStep { get; set; }
            public bool IsCompleted { get; set; }
        }

        public enum TaskType { Short, Long, Common }

        private List<GamePlayer> _players;
        private List<Task> _tasks;
        private float _taskCompletionPercentage;

        public float TaskCompletion => _taskCompletionPercentage;

        public SocialDeductionSystem()
        {
            _players = new List<GamePlayer>();
            _tasks = new List<Task>();
        }

        public void AssignRoles(int impostorCount)
        {
            var random = new Random();
            var indices = Enumerable.Range(0, _players.Count).OrderBy(x => random.Next()).ToList();

            for (int i = 0; i < _players.Count; i++)
            {
                _players[i].Role = i < impostorCount ? PlayerRole.Impostor : PlayerRole.Crewmate;
            }
        }

        public void CreateTasks(int taskCount)
        {
            for (int i = 0; i < taskCount; i++)
            {
                _tasks.Add(new Task
                {
                    Id = Guid.NewGuid().ToString(),
                    Name = $"Task {i + 1}",
                    Location = new Vector2(),
                    Type = TaskType.Short
                });
            }
        }

        public bool CompleteTask(GamePlayer player, string taskId)
        {
            if (player.Role == PlayerRole.Impostor) return false;

            var task = _tasks.FirstOrDefault(t => t.Id == taskId);
            if (task != null && !task.IsCompleted)
            {
                task.CurrentStep++;
                if (task.CurrentStep >= task.StepCount)
                {
                    task.IsCompleted = true;
                    player.CompletedTasks.Add(taskId);
                    UpdateTaskCompletion();
                    return true;
                }
            }
            return false;
        }

        private void UpdateTaskCompletion()
        {
            int totalTasks = _tasks.Count;
            int completedTasks = _tasks.Count(t => t.IsCompleted);
            _taskCompletionPercentage = (float)completedTasks / totalTasks;
        }

        public void CallEmergencyMeeting()
        {
            Console.WriteLine("Emergency Meeting Called!");
            // Implement voting system
        }

        public void ReportBody(GamePlayer reporter, GamePlayer victim)
        {
            Console.WriteLine($"{reporter.Name} reported {victim.Name}'s body!");
            // Trigger meeting
        }

        public void EliminatePlayer(GamePlayer player)
        {
            player.IsAlive = false;
            Console.WriteLine($"{player.Name} has been eliminated!");
        }
    }

    // ==================== ESCAPE ROOM / PUZZLE SYSTEM ====================

    /// <summary>
    /// Puzzle and escape room mechanics
    /// </summary>
    public class PuzzleSystem
    {
        public abstract class Puzzle
        {
            public string Id { get; set; }
            public string Name { get; set; }
            public bool IsSolved { get; set; }
            public List<string> RequiredItems { get; set; } = new List<string>();
            public List<string> UnlockedItems { get; set; } = new List<string>();
            public int Difficulty { get; set; }

            public abstract bool AttemptSolve(params object[] inputs);
        }

        public class CodePuzzle : Puzzle
        {
            public string CorrectCode { get; set; }
            
            public override bool AttemptSolve(params object[] inputs)
            {
                if (inputs.Length > 0 && inputs[0] is string code)
                {
                    IsSolved = code == CorrectCode;
                    return IsSolved;
                }
                return false;
            }
        }

        public class PatternPuzzle : Puzzle
        {
            public List<int> CorrectPattern { get; set; }

            public override bool AttemptSolve(params object[] inputs)
            {
                if (inputs.Length > 0 && inputs[0] is List<int> pattern)
                {
                    IsSolved = pattern.SequenceEqual(CorrectPattern);
                    return IsSolved;
                }
                return false;
            }
        }

        public class InventoryPuzzle : Puzzle
        {
            public Dictionary<string, int> RequiredCombination { get; set; }

            public override bool AttemptSolve(params object[] inputs)
            {
                // Check if player has correct items in inventory
                return false; // Implement with actual inventory check
            }
        }

        private List<Puzzle> _puzzles;
        private Dictionary<string, object> _inventory;

        public PuzzleSystem()
        {
            _puzzles = new List<Puzzle>();
            _inventory = new Dictionary<string, object>();
        }

        public void AddPuzzle(Puzzle puzzle) => _puzzles.Add(puzzle);
        public void AddToInventory(string item, object value) => _inventory[item] = value;
        public bool HasItem(string item) => _inventory.ContainsKey(item);
        
        public float GetCompletionPercentage()
        {
            int solved = _puzzles.Count(p => p.IsSolved);
            return (float)solved / _puzzles.Count;
        }
    }

    // ==================== PLATFORMER MECHANICS (G Switch, etc.) ====================

    /// <summary>
    /// Advanced platformer movement and gravity switching
    /// </summary>
    public class PlatformerController
    {
        public Vector2 Position { get; set; }
        public Vector2 Velocity { get; set; }
        public float GravityDirection { get; set; } = -1f; // -1 = down, 1 = up
        public float MoveSpeed { get; set; } = 5f;
        public float JumpForce { get; set; } = 10f;
        public bool IsGrounded { get; set; }
        public bool CanDoubleJump { get; set; }
        public bool HasDoubleJumped { get; set; }
        public float WallSlideSpeed { get; set; } = 2f;
        public bool IsWallSliding { get; set; }
        public int WallDirection { get; set; } // -1 = left, 1 = right

        public void Update(float deltaTime)
        {
            // Apply gravity
            Velocity += new Vector2(0, -9.81f * GravityDirection) * deltaTime;

            // Wall slide
            if (IsWallSliding)
            {
                Velocity = new Vector2(Velocity.X, Math.Max(Velocity.Y, -WallSlideSpeed));
            }

            // Update position
            Position += Velocity * deltaTime;

            // Reset double jump when grounded
            if (IsGrounded)
            {
                HasDoubleJumped = false;
            }
        }

        public void Move(float direction)
        {
            Velocity = new Vector2(direction * MoveSpeed, Velocity.Y);
        }

        public void Jump()
        {
            if (IsGrounded || IsWallSliding)
            {
                Velocity = new Vector2(Velocity.X, JumpForce * GravityDirection);
                IsGrounded = false;
                
                // Wall jump
                if (IsWallSliding)
                {
                    Velocity = new Vector2(-WallDirection * MoveSpeed, JumpForce * GravityDirection);
                    IsWallSliding = false;
                }
            }
            else if (CanDoubleJump && !HasDoubleJumped)
            {
                Velocity = new Vector2(Velocity.X, JumpForce * GravityDirection);
                HasDoubleJumped = true;
            }
        }

        public void FlipGravity()
        {
            GravityDirection *= -1;
            Velocity = new Vector2(Velocity.X, -Velocity.Y * 0.5f);
        }

        public void Dash(float direction)
        {
            Velocity = new Vector2(direction * MoveSpeed * 2f, Velocity.Y);
        }
    }
}
