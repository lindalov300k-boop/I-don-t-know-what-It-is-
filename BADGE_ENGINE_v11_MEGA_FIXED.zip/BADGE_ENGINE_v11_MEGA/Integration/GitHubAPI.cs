using System;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace BADGE.Integration
{
    public class GitHubAPI
    {
        private static readonly HttpClient _client = new HttpClient();
        private const string BaseUrl = "https://api.github.com";
        
        static GitHubAPI() { _client.DefaultRequestHeaders.Add("User-Agent", "BADGE-Engine"); }
        
        public static async Task<List<Repository>> SearchRepositories(string query)
        {
            try
            {
                var url = $"{BaseUrl}/search/repositories?q={Uri.EscapeDataString(query)}";
                var response = await _client.GetStringAsync(url);
                var result = JsonDocument.Parse(response);
                var repos = new List<Repository>();
                foreach (var item in result.RootElement.GetProperty("items").EnumerateArray())
                {
                    repos.Add(new Repository
                    {
                        Name = item.GetProperty("name").GetString(),
                        Stars = item.GetProperty("stargazers_count").GetInt32(),
                        CloneUrl = item.GetProperty("clone_url").GetString()
                    });
                }
                return repos;
            }
            catch { return new List<Repository>(); }
        }
        
        public static async Task<string> GetFileContent(string owner, string repo, string path)
        {
            try
            {
                var url = $"{BaseUrl}/repos/{owner}/{repo}/contents/{path}";
                var response = await _client.GetStringAsync(url);
                var result = JsonDocument.Parse(response);
                var content = result.RootElement.GetProperty("content").GetString();
                return System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(content));
            }
            catch { return null; }
        }
    }
    
    public class Repository { public string Name { get; set; } public int Stars { get; set; } public string CloneUrl { get; set; } }
}
