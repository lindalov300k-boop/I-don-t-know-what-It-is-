using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Gameplay;

// ═══════════════════════════════════════════════════════════════════════
//  VEHICLE DEFINITION
// ═══════════════════════════════════════════════════════════════════════
public enum VehicleType { Car, Truck, Motorcycle, Boat, Helicopter, Plane }

public class VehicleDef
{
    public string      Name         { get; init; } = "Vehicle";
    public VehicleType Type         { get; init; } = VehicleType.Car;
    public float       Mass         { get; init; } = 1400f;      // kg
    public float       MaxSpeed     { get; init; } = 60f;        // m/s
    public float       Acceleration { get; init; } = 12f;        // m/s²
    public float       Braking      { get; init; } = 18f;
    public float       TurnSpeed    { get; init; } = 120f;       // degrees/s at max steer
    public float       TractionFront{ get; init; } = 0.85f;      // 0–1
    public float       TractionRear { get; init; } = 0.78f;
    public float       SuspensionK  { get; init; } = 40000f;     // spring constant
    public float       SuspensionD  { get; init; } = 3000f;      // damping
    public float       WheelRadius  { get; init; } = 0.35f;
    public int         SeatCount    { get; init; } = 4;
    public float       Health       { get; init; } = 1000f;
    public float       FuelCapacity { get; init; } = 60f;        // litres
    public float       FuelConsumption { get; init; } = 0.05f;   // L/s at full throttle
}

// ═══════════════════════════════════════════════════════════════════════
//  WHEEL
// ═══════════════════════════════════════════════════════════════════════
public class Wheel
{
    public Vector3 LocalOffset { get; set; }
    public bool    IsGrounded  { get; set; }
    public float   Compression { get; set; }
    public float   SpinAngle   { get; set; }
    public float   SteerAngle  { get; set; }
    public bool    CanSteer    { get; set; } = false;
    public bool    IsDriven    { get; set; } = true;

    public Wheel(Vector3 offset, bool canSteer, bool driven)
    {
        LocalOffset = offset;
        CanSteer    = canSteer;
        IsDriven    = driven;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  VEHICLE CONTROLLER
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Arcade-style vehicle physics controller.
/// NEEDED BY: GTA SA, Payback (top-down variant), simulators.
/// Handles throttle, braking, steering, fuel, health, enter/exit.
/// </summary>
public class VehicleController : BADGE.Core.Component
{
    public VehicleDef Def         { get; }
    public float      CurrentSpeed{ get; private set; }
    public float      SteerAngle  { get; private set; }
    public float      Throttle    { get; set; }    // -1 to 1
    public float      Brake       { get; set; }    // 0 to 1
    public bool       Handbrake   { get; set; }
    public float      Health      { get; private set; }
    public float      Fuel        { get; private set; }
    public bool       IsOccupied  => _occupants.Count > 0;
    public bool       EngineOn    { get; private set; }
    public bool       IsDestroyed => Health <= 0f;

    private Vector3   _velocity   = Vector3.Zero;
    private float     _yawVelocity;
    private readonly List<BADGE.Core.Component> _occupants = new();
    public readonly  List<Wheel>                Wheels     = new();

    public event Action<BADGE.Core.Component>? OnEntered;
    public event Action<BADGE.Core.Component>? OnExited;
    public event Action?                        OnDestroyed;

    public VehicleController(VehicleDef def)
    {
        Def    = def;
        Health = def.Health;
        Fuel   = def.FuelCapacity;

        // Default 4-wheel layout
        float lx = 0.85f, lz = 1.4f;
        Wheels.Add(new Wheel(new Vector3( lx, -0.45f,  lz), canSteer:true,  driven:false));  // FL
        Wheels.Add(new Wheel(new Vector3(-lx, -0.45f,  lz), canSteer:true,  driven:false));  // FR
        Wheels.Add(new Wheel(new Vector3( lx, -0.45f, -lz), canSteer:false, driven:true));   // RL
        Wheels.Add(new Wheel(new Vector3(-lx, -0.45f, -lz), canSteer:false, driven:true));   // RR
    }

    public override void Update(float dt)
    {
        if (IsDestroyed || Transform == null) return;
        if (!EngineOn) return;

        SimulatePhysics(dt);
        SpinWheels(dt);
        ConsumeFuel(dt);
    }

    private void SimulatePhysics(float dt)
    {
        // Heading
        var forward = Transform.Forward;
        float steerInput  = SteerAngle;  // set externally (-1 to 1)
        float speedFactor = Math.Clamp(CurrentSpeed / Def.MaxSpeed, 0f, 1f);

        // Steering — reduce at high speed (stability)
        float maxSteer    = Def.TurnSpeed * (1f - speedFactor * 0.6f);
        float targetYaw   = steerInput * maxSteer;
        _yawVelocity      = MathHelper.Lerp(_yawVelocity, targetYaw, 10f * dt);

        // Rotate
        Transform.LocalEulerAngles += new Vector3(0f, _yawVelocity * dt, 0f);

        // Recalculate forward after rotation
        forward = Transform.Forward;

        // Throttle / brake
        float thrustForce  = Throttle * Def.Acceleration;
        float brakeForce   = Brake * Def.Braking;
        if (Handbrake) brakeForce = Def.Braking * 2.5f;

        // Integrate velocity
        var accel = forward * thrustForce;
        _velocity += accel * dt;
        // Friction
        float friction = brakeForce + 4f;  // rolling resistance
        _velocity -= _velocity * Math.Min(friction * dt, 1f);

        // Clamp to max speed
        if (_velocity.Length > Def.MaxSpeed)
            _velocity = _velocity.Normalized() * Def.MaxSpeed;

        CurrentSpeed = _velocity.Length;

        // Move
        Transform.Position += _velocity * dt;
    }

    private void SpinWheels(float dt)
    {
        foreach (var w in Wheels)
        {
            w.SpinAngle += CurrentSpeed / Def.WheelRadius * dt * (Throttle >= 0f ? 1f : -1f);
            if (w.CanSteer) w.SteerAngle = SteerAngle * 30f; // max steer degrees
        }
    }

    private void ConsumeFuel(float dt)
    {
        if (MathF.Abs(Throttle) > 0.01f)
            Fuel = Math.Max(0f, Fuel - Def.FuelConsumption * MathF.Abs(Throttle) * dt);
        if (Fuel <= 0f) EngineOn = false;
    }

    // ── Entry / Exit ──────────────────────────────────────────────
    public bool TryEnter(BADGE.Core.Component driver)
    {
        if (_occupants.Count >= Def.SeatCount) return false;
        if (!_occupants.Contains(driver)) _occupants.Add(driver);
        if (!EngineOn && Fuel > 0f) EngineOn = true;
        OnEntered?.Invoke(driver);
        return true;
    }

    public void Exit(BADGE.Core.Component occupant)
    {
        _occupants.Remove(occupant);
        if (_occupants.Count == 0) EngineOn = false;
        OnExited?.Invoke(occupant);
    }

    // ── Damage ────────────────────────────────────────────────────
    public void ApplyDamage(float damage)
    {
        if (IsDestroyed) return;
        Health = Math.Max(0f, Health - damage);
        if (Health <= 0f) OnDestroyed?.Invoke();
    }

    // ── Utility ───────────────────────────────────────────────────
    public float GetSpeedKmh() => CurrentSpeed * 3.6f;
    public Vector3 GetVelocity() => _velocity;
}

// ═══════════════════════════════════════════════════════════════════════
//  WANTED SYSTEM  (GTA-style)
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Tracks wanted level and dispatches pursuit AI.
/// NEEDED BY: GTA SA, Payback.
/// </summary>
public class WantedSystem : BADGE.Core.Component
{
    public int   WantedLevel    { get; private set; }   // 0–5
    public float EvasionTimer   { get; private set; }   // how long since last spotted
    public float EvasionRequired { get; set; } = 5f;   // seconds out of sight to lower level
    public bool  IsWanted       => WantedLevel > 0;

    private static readonly float[] _dispatchThresholds = { 0f, 1f, 2f, 3f, 4f, 5f };
    private static readonly int[]   _copsPerLevel       = { 0, 1, 2, 4, 6, 10 };

    public event Action<int, int>? OnWantedLevelChanged;
    public event Action<int>?      OnCopsDispatched;

    public void AddWanted(int amount = 1)
    {
        int prev = WantedLevel;
        WantedLevel = Math.Clamp(WantedLevel + amount, 0, 5);
        if (WantedLevel != prev)
        {
            OnWantedLevelChanged?.Invoke(prev, WantedLevel);
            EventBus.Publish(new WantedLevelChanged(prev, WantedLevel));
            if (WantedLevel > prev)
                OnCopsDispatched?.Invoke(_copsPerLevel[WantedLevel]);
        }
        EvasionTimer = 0f;
    }

    public void ClearWanted()
    {
        int prev = WantedLevel;
        WantedLevel = 0;
        if (prev != 0) OnWantedLevelChanged?.Invoke(prev, 0);
    }

    public override void Update(float dt)
    {
        if (!IsWanted) return;

        // Check if player is evading (set EvasionTimer to 0 when spotted)
        EvasionTimer += dt;
        if (EvasionTimer >= EvasionRequired)
        {
            AddWanted(-1);
            EvasionTimer = 0f;
        }
    }

    public void NotifySpotted() => EvasionTimer = 0f;

    public string GetStarDisplay()
    {
        var sb = new System.Text.StringBuilder();
        for (int i = 0; i < 5; i++)
            sb.Append(i < WantedLevel ? "★" : "☆");
        return sb.ToString();
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  ENDLESS RUNNER  (Subway Surfers, temple run style)
// ═══════════════════════════════════════════════════════════════════════
public class EndlessRunner : BADGE.Core.Component
{
    public int   LaneCount    { get; set; } = 3;
    public float LaneWidth    { get; set; } = 2.5f;
    public float RunSpeed     { get; set; } = 8f;
    public float SpeedIncrease{ get; set; } = 0.02f;   // per second
    public float Distance     { get; private set; }

    private int _currentLane; // 0=left, 1=center, 2=right
    private int _targetLane;
    private bool _isSwapping;
    private float _swapT;
    private float _swapFrom, _swapTo;

    public int CurrentLane => _currentLane;
    public bool IsJumping  { get; private set; }
    public bool IsSliding  { get; private set; }

    private float _jumpVelocity;
    private float _jumpHeight;
    private const float GRAVITY = -28f;

    public event Action<float>? OnObstacleHit;
    public event Action<float>? OnCoinCollected;

    public override void Update(float dt)
    {
        if (Transform == null) return;

        RunSpeed = Math.Min(RunSpeed + SpeedIncrease * dt, 30f);
        Distance += RunSpeed * dt;

        UpdateLaneSwap(dt);
        UpdateJump(dt);
    }

    private void UpdateLaneSwap(float dt)
    {
        if (!_isSwapping)
        {
            // Snap to lane
            float targetX = (_targetLane - LaneCount / 2) * LaneWidth;
            var pos = Transform.Position;
            pos.X = MathHelper.Lerp(pos.X, targetX, 20f * dt);
            Transform.Position = pos;
            return;
        }

        _swapT += dt * 8f;
        float x = MathHelper.Lerp(_swapFrom, _swapTo, Math.Clamp(_swapT, 0f, 1f));
        var p   = Transform.Position;
        p.X     = x;
        Transform.Position = p;

        if (_swapT >= 1f)
        {
            _isSwapping = false;
            _currentLane = _targetLane;
        }
    }

    private void UpdateJump(float dt)
    {
        if (!IsJumping) return;
        _jumpVelocity += GRAVITY * dt;
        _jumpHeight   += _jumpVelocity * dt;

        var pos = Transform.Position;
        pos.Y   = Math.Max(0f, _jumpHeight);
        Transform.Position = pos;

        if (pos.Y <= 0f)
        {
            IsJumping      = false;
            _jumpHeight    = 0f;
            _jumpVelocity  = 0f;
        }
    }

    public void SwapLane(int delta)
    {
        int next = Math.Clamp(_targetLane + delta, 0, LaneCount - 1);
        if (next == _targetLane) return;
        _swapFrom    = (_targetLane - LaneCount / 2) * LaneWidth;
        _swapTo      = (next       - LaneCount / 2) * LaneWidth;
        _targetLane  = next;
        _swapT       = 0f;
        _isSwapping  = true;
    }

    public void Jump(float power = 10f)
    {
        if (IsJumping || IsSliding) return;
        IsJumping     = true;
        _jumpVelocity = power;
    }

    public void Slide() { if (!IsJumping) IsSliding = true; }
    public void EndSlide() => IsSliding = false;
}
