using System;
using System.Collections.Generic;

namespace BADGE.Gameplay;

// ═══════════════════════════════════════════════════════════════════════
//  STATE INTERFACE
// ═══════════════════════════════════════════════════════════════════════
public interface IGameplayState
{
    string Name { get; }
    void OnEnter(IGameplayState? previous);
    void OnUpdate(float dt);
    void OnExit(IGameplayState? next);
    void OnSubStateChanged(IGameplayState? oldSub, IGameplayState? newSub) { }
}

// ═══════════════════════════════════════════════════════════════════════
//  BASE STATE  (convenience base class)
// ═══════════════════════════════════════════════════════════════════════
public abstract class State : IGameplayState
{
    public virtual string Name => GetType().Name;
    public virtual void OnEnter(IGameplayState? previous)  { }
    public virtual void OnUpdate(float dt)          { }
    public virtual void OnExit(IGameplayState? next)        { }
}

// ═══════════════════════════════════════════════════════════════════════
//  TRANSITION
// ═══════════════════════════════════════════════════════════════════════
public class Transition
{
    public string     ToState   { get; }
    public Func<bool> Condition { get; }
    public float      MinTime   { get; }   // minimum time in current state before firing

    public Transition(string toState, Func<bool> condition, float minTime = 0f)
    {
        ToState   = toState;
        Condition = condition;
        MinTime   = minTime;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  STATE MACHINE
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Generic hierarchical finite state machine.
///
/// NEEDED BY: Enemy AI (Idle→Chase→Attack), game flow (Menu→Playing→Paused→Dead),
///            cutscene sequencing, vehicle states, GTA wanted level, Ludo turn system.
///
/// Supports: Named transitions with conditions, sub-states (nested FSM),
///           any-state transitions, OnEnter/OnUpdate/OnExit callbacks.
/// </summary>
public class GameplayStateMachine
{
    private readonly Dictionary<string, IGameplayState>         _states      = new();
    private readonly Dictionary<string, List<Transition>> _transitions = new();
    private readonly List<Transition>                    _anyState    = new();

    public IGameplayState? Current     { get; private set; }
    public IGameplayState? Previous    { get; private set; }
    public float   TimeInState { get; private set; }

    public string CurrentName => Current?.Name ?? "None";

    public event Action<IGameplayState?, IGameplayState?>? OnTransition;

    // ── State registration ────────────────────────────────────────
    public StateMachine Add(IGameplayState state)
    {
        _states[state.Name] = state;
        return this;
    }

    public StateMachine Add(string name, Action? enter = null, Action<float>? update = null, Action? exit = null)
    {
        Add(new LambdaState(name, enter, update, exit));
        return this;
    }

    public StateMachine AddTransition(string from, string to, Func<bool> condition, float minTime = 0f)
    {
        if (!_transitions.ContainsKey(from)) _transitions[from] = new();
        _transitions[from].Add(new Transition(to, condition, minTime));
        return this;
    }

    public StateMachine AddAnyTransition(string to, Func<bool> condition, float minTime = 0f)
    {
        _anyState.Add(new Transition(to, condition, minTime));
        return this;
    }

    // ── Start ─────────────────────────────────────────────────────
    public void Start(string stateName)
    {
        if (!_states.TryGetValue(stateName, out var state))
            throw new InvalidOperationException($"State '{stateName}' not registered.");
        Current = state;
        Current.OnEnter(null);
        TimeInState = 0f;
    }

    // ── Update ────────────────────────────────────────────────────
    public void Update(float dt)
    {
        if (Current == null) return;

        TimeInState += dt;
        Current.OnUpdate(dt);
        CheckTransitions();
    }

    private void CheckTransitions()
    {
        if (Current == null) return;

        // Check any-state transitions first
        foreach (var t in _anyState)
        {
            if (TimeInState >= t.MinTime && t.Condition())
            {
                if (t.ToState != Current.Name) TransitionTo(t.ToState);
                return;
            }
        }

        // Check current-state transitions
        if (_transitions.TryGetValue(Current.Name, out var transitions))
        {
            foreach (var t in transitions)
            {
                if (TimeInState >= t.MinTime && t.Condition())
                {
                    TransitionTo(t.ToState);
                    return;
                }
            }
        }
    }

    public void TransitionTo(string stateName)
    {
        if (!_states.TryGetValue(stateName, out var next)) return;
        if (next == Current) return;

        Previous = Current;
        Current?.OnExit(next);
        OnTransition?.Invoke(Previous, next);
        Current     = next;
        TimeInState = 0f;
        Current.OnEnter(Previous);
    }

    public bool IsIn(string stateName) => Current?.Name == stateName;

    // ── Lambda state helper ───────────────────────────────────────
    private class LambdaState : IGameplayState
    {
        public string Name { get; }
        private readonly Action?       _enter;
        private readonly Action<float>? _update;
        private readonly Action?       _exit;

        public LambdaState(string name, Action? enter, Action<float>? update, Action? exit)
        {
            Name    = name;
            _enter  = enter;
            _update = update;
            _exit   = exit;
        }

        public void OnEnter(IGameplayState? prev)  => _enter?.Invoke();
        public void OnUpdate(float dt)     => _update?.Invoke(dt);
        public void OnExit(IGameplayState? next)   => _exit?.Invoke();
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  TURN MANAGER  (Ludo, board games, tactical RPGs)
// ═══════════════════════════════════════════════════════════════════════
public class TurnManager
{
    private readonly List<string> _players = new();
    private int _currentIndex;
    private int _roundNumber;

    public string CurrentPlayer => _players.Count > 0 ? _players[_currentIndex] : "None";
    public int    Round         => _roundNumber;

    public event Action<string, string>? OnTurnChanged;   // (prev, next)
    public event Action<int>?            OnNewRound;

    public void AddPlayer(string name) => _players.Add(name);

    public void Start()
    {
        _currentIndex = 0;
        _roundNumber  = 1;
    }

    public void NextTurn()
    {
        if (_players.Count == 0) return;
        var prev = CurrentPlayer;
        _currentIndex++;
        if (_currentIndex >= _players.Count)
        {
            _currentIndex = 0;
            _roundNumber++;
            OnNewRound?.Invoke(_roundNumber);
        }
        OnTurnChanged?.Invoke(prev, CurrentPlayer);
    }

    public bool IsPlayerTurn(string name) => CurrentPlayer == name;

    // ── Dice ──────────────────────────────────────────────────────
    private static readonly Random _rng = new();

    public static int RollDie(int faces = 6)          => _rng.Next(1, faces + 1);
    public static int[] RollDice(int count, int faces) { var r = new int[count]; for(int i=0;i<count;i++) r[i]=RollDie(faces); return r; }
}

// ═══════════════════════════════════════════════════════════════════════
//  BOARD PATH FOLLOWER  (Ludo tokens moving along defined path nodes)
// ═══════════════════════════════════════════════════════════════════════
public class BoardPathFollower : BADGE.Core.Component
{
    public List<BADGE.Core.Vector3Serializable> PathNodes { get; } = new();
    public int    CurrentNode  { get; private set; }
    public float  MoveSpeed    { get; set; } = 5f;
    public bool   IsMoving     { get; private set; }

    private int   _targetNode;
    private int   _stepsLeft;

    public event Action? OnMoveComplete;

    public void MoveSteps(int steps)
    {
        _stepsLeft = steps;
        _targetNode = Math.Min(CurrentNode + 1, PathNodes.Count - 1);
        IsMoving    = true;
    }

    public override void Update(float dt)
    {
        if (!IsMoving || PathNodes.Count == 0 || Transform == null) return;

        var target = new OpenTK.Mathematics.Vector3(
            PathNodes[_targetNode].X,
            PathNodes[_targetNode].Y,
            PathNodes[_targetNode].Z);
        var current = Transform.Position;
        var dir = target - current;

        if (dir.Length < 0.05f)
        {
            Transform.Position = target;
            CurrentNode = _targetNode;
            _stepsLeft--;

            if (_stepsLeft <= 0)
            {
                IsMoving = false;
                OnMoveComplete?.Invoke();
            }
            else
            {
                _targetNode = Math.Min(CurrentNode + 1, PathNodes.Count - 1);
            }
        }
        else
        {
            Transform.Position += dir.Normalized() * MoveSpeed * dt;
        }
    }
}

// ── Shim for serialisable vector3 ────────────────────────────────────
public struct Vector3Serializable { public float X, Y, Z; }
