using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.Gameplay;

// ═══════════════════════════════════════════════════════════════════════
//  ITEM DEFINITION
// ═══════════════════════════════════════════════════════════════════════
public enum ItemCategory { None, Weapon, Armor, Consumable, Material, Tool, Block, Ammo, Misc }
public enum EquipSlot    { None, Head, Chest, Legs, Feet, Hands, Weapon, OffHand, Accessory1, Accessory2 }
public enum ToolType     { None, Pickaxe, Axe, Shovel, Sword, Bow, Wand }
public enum Rarity       { Common, Uncommon, Rare, Epic, Legendary }

public class ItemDef
{
    public ushort   Id           { get; init; }
    public string   Name         { get; init; } = "Unknown Item";
    public string   Description  { get; init; } = "";
    public ItemCategory Category { get; init; } = ItemCategory.Misc;
    public EquipSlot EquipSlot   { get; init; } = EquipSlot.None;
    public ToolType  ToolType    { get; init; } = ToolType.None;
    public Rarity    Rarity      { get; init; } = Rarity.Common;
    public int       MaxStack    { get; init; } = 99;
    public float     Weight      { get; init; } = 0.1f;
    public int       SellValue   { get; init; } = 1;
    public int       TextureX    { get; init; }
    public int       TextureY    { get; init; }
    // Combat stats
    public float     Damage      { get; init; }
    public float     Defence     { get; init; }
    public float     ToolPower   { get; init; }   // mining/axe power
    public float     UseSpeed    { get; init; } = 1f;
    // Consumable effect
    public string    UseEffect   { get; init; } = "";
    public bool IsEquippable => EquipSlot != EquipSlot.None;
}

// ═══════════════════════════════════════════════════════════════════════
//  ITEM REGISTRY
// ═══════════════════════════════════════════════════════════════════════
public static class ItemRegistry
{
    private static readonly Dictionary<ushort, ItemDef> _defs = new();

    public static void Register(ItemDef def)     => _defs[def.Id] = def;
    public static ItemDef? Get(ushort id)        => _defs.TryGetValue(id, out var d) ? d : null;
    public static IEnumerable<ItemDef> All       => _defs.Values;

    public static void RegisterDefaults()
    {
        Register(new ItemDef { Id=1,  Name="Dirt Block",    Category=ItemCategory.Block,    MaxStack=999, SellValue=0 });
        Register(new ItemDef { Id=2,  Name="Stone Block",   Category=ItemCategory.Block,    MaxStack=999, SellValue=1 });
        Register(new ItemDef { Id=10, Name="Wooden Sword",  Category=ItemCategory.Weapon,   EquipSlot=EquipSlot.Weapon,  Damage=8,  UseSpeed=1.5f });
        Register(new ItemDef { Id=11, Name="Iron Sword",    Category=ItemCategory.Weapon,   EquipSlot=EquipSlot.Weapon,  Damage=18, UseSpeed=1.3f, Rarity=Rarity.Uncommon });
        Register(new ItemDef { Id=20, Name="Wooden Pickaxe",Category=ItemCategory.Tool,     ToolType=ToolType.Pickaxe,   ToolPower=35, MaxStack=1, UseSpeed=1.2f });
        Register(new ItemDef { Id=21, Name="Iron Pickaxe",  Category=ItemCategory.Tool,     ToolType=ToolType.Pickaxe,   ToolPower=55, MaxStack=1, Rarity=Rarity.Uncommon });
        Register(new ItemDef { Id=30, Name="Health Potion", Category=ItemCategory.Consumable, UseEffect="heal:50", SellValue=5 });
        Register(new ItemDef { Id=31, Name="Mana Potion",   Category=ItemCategory.Consumable, UseEffect="mana:50",  SellValue=5 });
        Register(new ItemDef { Id=40, Name="Iron Helmet",   Category=ItemCategory.Armor,    EquipSlot=EquipSlot.Head,    Defence=4, Rarity=Rarity.Uncommon });
        Register(new ItemDef { Id=41, Name="Iron Chestplate",Category=ItemCategory.Armor,   EquipSlot=EquipSlot.Chest,   Defence=8, Rarity=Rarity.Uncommon });
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  ITEM STACK  (slot contents)
// ═══════════════════════════════════════════════════════════════════════
public class ItemStack
{
    public ushort ItemId   { get; set; }
    public int    Quantity { get; set; }
    public Dictionary<string, float> Enchantments { get; } = new();

    public bool IsEmpty => ItemId == 0 || Quantity <= 0;
    public ItemDef? Def => ItemRegistry.Get(ItemId);

    public ItemStack() { }
    public ItemStack(ushort id, int qty) { ItemId = id; Quantity = qty; }

    public static ItemStack Empty => new() { ItemId = 0, Quantity = 0 };
}

// ═══════════════════════════════════════════════════════════════════════
//  INVENTORY
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Grid-based inventory with equipment slots, hotbar, and stacking.
/// Needed by: Terraria, Subnautica, GTA, No Man's Sky.
/// </summary>
public class Inventory : BADGE.Core.Component
{
    public int Width  { get; }
    public int Height { get; }
    public int HotbarSize { get; }

    private readonly ItemStack[,] _grid;
    private readonly ItemStack[]  _hotbar;
    private readonly Dictionary<EquipSlot, ItemStack> _equipped = new();

    public int SelectedHotbarSlot { get; set; } = 0;
    public ItemStack? ActiveItem   => _hotbar[SelectedHotbarSlot].IsEmpty ? null : _hotbar[SelectedHotbarSlot];

    public event Action? OnChanged;

    public Inventory(int width = 10, int height = 4, int hotbarSize = 10)
    {
        Width       = width;
        Height      = height;
        HotbarSize  = hotbarSize;
        _grid       = new ItemStack[width, height];
        _hotbar     = new ItemStack[hotbarSize];

        for (int x = 0; x < width;  x++)
        for (int y = 0; y < height; y++)
            _grid[x, y] = ItemStack.Empty;
        for (int i = 0; i < hotbarSize; i++)
            _hotbar[i] = ItemStack.Empty;
        foreach (EquipSlot s in Enum.GetValues<EquipSlot>())
            if (s != EquipSlot.None) _equipped[s] = ItemStack.Empty;
    }

    // ── Add / Remove ──────────────────────────────────────────────
    /// <summary>Add items to inventory. Returns leftovers that didn't fit.</summary>
    public int Add(ushort itemId, int quantity)
    {
        var def = ItemRegistry.Get(itemId);
        if (def == null) return quantity;

        // Try to stack on existing stacks in hotbar first
        quantity = StackInto(_hotbar, itemId, quantity, def.MaxStack);
        if (quantity <= 0) { OnChanged?.Invoke(); return 0; }

        // Then grid
        for (int x = 0; x < Width && quantity > 0; x++)
        for (int y = 0; y < Height && quantity > 0; y++)
        {
            var slot = _grid[x, y];
            if (!slot.IsEmpty && slot.ItemId == itemId && slot.Quantity < def.MaxStack)
            {
                int add = Math.Min(quantity, def.MaxStack - slot.Quantity);
                slot.Quantity += add;
                quantity -= add;
            }
        }

        // Empty slots
        for (int i = 0; i < HotbarSize && quantity > 0; i++)
        {
            if (_hotbar[i].IsEmpty)
            {
                int add = Math.Min(quantity, def.MaxStack);
                _hotbar[i] = new ItemStack(itemId, add);
                quantity -= add;
            }
        }
        for (int x = 0; x < Width && quantity > 0; x++)
        for (int y = 0; y < Height && quantity > 0; y++)
        {
            if (_grid[x, y].IsEmpty)
            {
                int add = Math.Min(quantity, def.MaxStack);
                _grid[x, y] = new ItemStack(itemId, add);
                quantity -= add;
            }
        }

        OnChanged?.Invoke();
        return quantity;
    }

    private static int StackInto(ItemStack[] slots, ushort id, int qty, int maxStack)
    {
        foreach (var slot in slots)
        {
            if (!slot.IsEmpty && slot.ItemId == id && slot.Quantity < maxStack)
            {
                int add = Math.Min(qty, maxStack - slot.Quantity);
                slot.Quantity += add;
                qty -= add;
                if (qty <= 0) return 0;
            }
        }
        return qty;
    }

    public bool Remove(ushort itemId, int quantity)
    {
        if (!Has(itemId, quantity)) return false;
        RemoveFrom(_hotbar, itemId, ref quantity);
        if (quantity > 0)
            for (int x = 0; x < Width; x++)
            for (int y = 0; y < Height; y++)
                RemoveFrom(ref _grid[x, y], itemId, ref quantity);
        OnChanged?.Invoke();
        return true;
    }

    private static void RemoveFrom(ItemStack[] slots, ushort id, ref int qty)
    {
        foreach (var slot in slots)
        {
            if (!slot.IsEmpty && slot.ItemId == id)
            {
                int take = Math.Min(qty, slot.Quantity);
                slot.Quantity -= take;
                qty -= take;
                if (slot.Quantity <= 0) { slot.ItemId = 0; }
                if (qty <= 0) return;
            }
        }
    }

    private static void RemoveFrom(ref ItemStack slot, ushort id, ref int qty)
    {
        if (!slot.IsEmpty && slot.ItemId == id)
        {
            int take = Math.Min(qty, slot.Quantity);
            slot.Quantity -= take;
            qty -= take;
            if (slot.Quantity <= 0) slot = ItemStack.Empty;
        }
    }

    public bool Has(ushort itemId, int quantity = 1) => Count(itemId) >= quantity;

    public int Count(ushort itemId)
    {
        int total = 0;
        foreach (var s in _hotbar) if (!s.IsEmpty && s.ItemId == itemId) total += s.Quantity;
        for (int x = 0; x < Width; x++)
        for (int y = 0; y < Height; y++)
        {
            var s = _grid[x, y];
            if (!s.IsEmpty && s.ItemId == itemId) total += s.Quantity;
        }
        return total;
    }

    // ── Hotbar ────────────────────────────────────────────────────
    public ItemStack GetHotbar(int slot)  => _hotbar[slot];
    public void SetHotbar(int slot, ItemStack stack) { _hotbar[slot] = stack; OnChanged?.Invoke(); }

    // ── Grid ──────────────────────────────────────────────────────
    public ItemStack GetGrid(int x, int y)             => _grid[x, y];
    public void SetGrid(int x, int y, ItemStack stack) { _grid[x, y] = stack; OnChanged?.Invoke(); }

    // ── Equipment ─────────────────────────────────────────────────
    public bool Equip(ItemStack stack)
    {
        var def = stack.Def;
        if (def == null || !def.IsEquippable) return false;
        if (!_equipped[def.EquipSlot].IsEmpty) Unequip(def.EquipSlot);
        _equipped[def.EquipSlot] = stack;
        OnChanged?.Invoke();
        return true;
    }

    public ItemStack Unequip(EquipSlot slot)
    {
        var was = _equipped[slot];
        _equipped[slot] = ItemStack.Empty;
        OnChanged?.Invoke();
        return was;
    }

    public ItemStack GetEquipped(EquipSlot slot) => _equipped[slot];

    // ── Aggregate stats ───────────────────────────────────────────
    public float GetTotalDefence()
    {
        float total = 0f;
        foreach (var s in _equipped.Values)
            if (!s.IsEmpty && s.Def != null) total += s.Def.Defence;
        return total;
    }

    public float GetActiveDamage()
        => ActiveItem?.Def?.Damage ?? 0f;

    public float GetToolPower()
        => ActiveItem?.Def?.ToolPower ?? 0f;

    public ToolType GetActiveTool()
        => ActiveItem?.Def?.ToolType ?? ToolType.None;
}

// ═══════════════════════════════════════════════════════════════════════
//  CRAFTING SYSTEM
// ═══════════════════════════════════════════════════════════════════════
public class CraftingRecipe
{
    public string Name { get; init; } = "";
    public (ushort Id, int Qty)[] Inputs  { get; init; } = Array.Empty<(ushort, int)>();
    public (ushort Id, int Qty)  Output   { get; init; }
    public string  StationRequired { get; init; } = "";  // "" = anywhere
}

public static class CraftingSystem
{
    private static readonly List<CraftingRecipe> _recipes = new();

    public static void AddRecipe(CraftingRecipe r) => _recipes.Add(r);

    public static IEnumerable<CraftingRecipe> GetAvailable(Inventory inv, string station = "")
    {
        foreach (var r in _recipes)
        {
            if (r.StationRequired != "" && r.StationRequired != station) continue;
            bool ok = true;
            foreach (var (id, qty) in r.Inputs)
                if (!inv.Has(id, qty)) { ok = false; break; }
            if (ok) yield return r;
        }
    }

    public static bool Craft(CraftingRecipe recipe, Inventory inv)
    {
        foreach (var (id, qty) in recipe.Inputs)
            if (!inv.Has(id, qty)) return false;
        foreach (var (id, qty) in recipe.Inputs)
            inv.Remove(id, qty);
        inv.Add(recipe.Output.Id, recipe.Output.Qty);
        return true;
    }

    public static void RegisterDefaults()
    {
        AddRecipe(new CraftingRecipe
        {
            Name   = "Wooden Sword",
            Inputs = new[] { ((ushort)3, 10) },
            Output = (10, 1)
        });
        AddRecipe(new CraftingRecipe
        {
            Name   = "Wooden Pickaxe",
            Inputs = new[] { ((ushort)3, 12) },
            Output = (20, 1)
        });
    }
}
