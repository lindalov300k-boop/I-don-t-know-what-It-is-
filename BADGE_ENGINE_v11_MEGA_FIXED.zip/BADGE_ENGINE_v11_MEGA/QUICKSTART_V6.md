# BADGE Engine v6.0 - Quick Start Guide

## 🚀 Welcome to BADGE Engine v6.0!

**Congratulations!** You now have a production-ready game engine with NO stub implementations.

---

## 📦 What's Included

### Core Systems
- ✅ Complete Plugin/Addon Architecture
- ✅ Drag & Drop File Management  
- ✅ Advanced Scene Management
- ✅ Camera & Lighting Systems
- ✅ UI Management System

### Game Feature Modules
- ✅ Rhythm Game System (Piano Tiles style)
- ✅ Vehicle Physics (Hill Climber style)
- ✅ Board Game System (Monopoly style)
- ✅ RPG Battle System (Pokemon style)
- ✅ Social Deduction (Among Us style)
- ✅ Puzzle System (Escape Room)
- ✅ Platformer Mechanics (G Switch style)

### Design Tools
- ✅ Sprite Designer (Pixel Art Editor)
- ✅ Procedural Texture Generator
- ✅ Material Designer
- ✅ Platform Designer
- ✅ Effect Designer

---

## ⚡ 5-Minute Quickstart

### 1. Build the Engine

```bash
cd BADGE_Engine_v2_Unity_Style
dotnet restore
dotnet build
dotnet run
```

### 2. Your First Scene with New Features

```csharp
using BADGE.Editor;
using BADGE.Plugins;
using BADGE.GameFeatures;

// Initialize systems
PluginManager.Instance.Initialize();
var sceneManager = AdvancedSceneManager.Instance;

// Create a scene
var scene = sceneManager.CreateScene("MyGame", SceneTemplate.Basic3D);
sceneManager.LoadScene("MyGame");

// Add a camera
var camera = CameraManager.Instance.CreateCamera("Main", CameraType.Perspective);

// Add lighting
var sun = LightingManager.Instance.CreateLight("Sun", LightType.Directional);
```

### 3. Use a Built-in Plugin

```csharp
// Get the rhythm game plugin
var rhythmPlugin = PluginManager.Instance.GetPlugin<TileGamePlugin>();

// Create a rhythm game
var rhythm = new RhythmGameSystem();
var track = new RhythmGameSystem.Track { BPM = 120 };

// Add notes
track.Notes.Add(new RhythmGameSystem.Note 
{ 
    Time = 1.0f, 
    Lane = 0 
});

rhythm.LoadTrack(track);
```

### 4. Design a Sprite

```csharp
var studio = new DesignStudio();
studio.SpriteDesigner.CreateCanvas(64, 64);

// Draw something
studio.SpriteDesigner.ActiveLayer.DrawCircle(32, 32, 20, Color.Red);
studio.SpriteDesigner.ActiveLayer.FloodFill(32, 32, Color.Blue);

// Export
byte[] png = studio.SpriteDesigner.ActiveLayer.ExportToPNG();
```

---

## 📚 Common Tasks

### Create a New Plugin

```csharp
public class MyPlugin : BasePlugin
{
    public override string Name => "My Plugin";
    public override string Version => "1.0.0";
    public override PluginType Type => PluginType.Gameplay;

    public override void Initialize()
    {
        base.Initialize();
        Console.WriteLine("My plugin initialized!");
    }
}
```

### Generate Procedural Textures

```csharp
var texDesigner = new TextureDesigner();
var settings = new TextureDesigner.TextureSettings
{
    Width = 512,
    Height = 512,
    PrimaryColor = Color.Green,
    SecondaryColor = Color.Brown,
    Scale = 1.5f
};

byte[] woodTexture = texDesigner.GenerateTexture(TextureType.Wood, settings);
```

### Create a Follow Camera

```csharp
var player = scene.FindGameObjectByName("Player");
var rig = CameraManager.Instance.CreateFollowRig(
    "ThirdPerson",
    player,
    offset: new Vector3(0, 2, -5)
);
rig.SmoothFollow = true;
```

### Add UI at Runtime

```csharp
var button = UIManager.Instance.CreateButton(
    "Start Game",
    new Vector2(100, 100),
    new Vector2(200, 50)
);

var text = UIManager.Instance.CreateText(
    "Score: 0",
    new Vector2(10, 10),
    fontSize: 24
);
```

---

## 🎮 Example Projects

### Piano Tiles Clone

```csharp
var rhythm = new RhythmGameSystem();
var track = new RhythmGameSystem.Track { BPM = 120, Speed = 2.0f };

for (int i = 0; i < 100; i++)
{
    track.Notes.Add(new RhythmGameSystem.Note
    {
        Time = i * 0.5f,
        Lane = Random.Next(0, 4)
    });
}

rhythm.LoadTrack(track);

// In update loop
rhythm.Update(deltaTime);

// When lane is clicked
if (Input.GetMouseButtonDown(0))
{
    int lane = GetLaneFromMousePosition();
    var result = rhythm.TryHitNote(lane);
    if (result.Success)
        score += result.Points;
}
```

### Hill Climber Clone

```csharp
var vehicle = new Vehicle2DPhysics
{
    Mass = 100f,
    EnginePower = 500f
};

vehicle.AddWheel(new Vector2(-1, -0.5f), 0.3f);  // Front wheel
vehicle.AddWheel(new Vector2(1, -0.5f), 0.3f);   // Back wheel

// In update loop
if (Input.GetKey(Keys.Right))
    vehicle.SetThrottle(1.0f);
else if (Input.GetKey(Keys.Left))
    vehicle.SetThrottle(-1.0f);
else
    vehicle.SetThrottle(0f);

vehicle.Update(deltaTime);
```

---

## 🛠️ Development Workflow

### 1. Use Editor
- Open editor
- Create GameObjects with right-click
- Add components
- Test in Play mode

### 2. Write Scripts
- Right-click in Project → C# Script
- Auto-opens in VSCode
- Implement MonoBehaviour methods

### 3. Design Assets
- Use Sprite Designer for pixel art
- Generate textures procedurally
- Create materials with Material Designer

### 4. Build Game
- File → Build Settings
- Select platform
- Build executable

---

## 🔌 Plugin Development

### Creating a Plugin

1. Create a new class:
```csharp
public class MyGamePlugin : BasePlugin
{
    public override string Name => "My Game Plugin";
    public override string Version => "1.0.0";
    public override PluginType Type => PluginType.Gameplay;

    public override void Initialize()
    {
        base.Initialize();
        // Setup
    }

    public override void Update(float deltaTime)
    {
        // Per-frame logic
    }
}
```

2. Register it:
```csharp
// In PluginManager.LoadBuiltInPlugins()
builtInPlugins.Add(new MyGamePlugin());
```

### Distributing Plugins

1. **Compiled DLL**: Build as library, place in `Plugins/User/`
2. **With Manifest**: Create `plugin.json` alongside DLL

```json
{
  "name": "My Plugin",
  "version": "1.0.0",
  "author": "Your Name",
  "type": "Gameplay",
  "entryPoint": "MyPlugin.dll"
}
```

---

## 📖 Full Documentation

- **COMPLETE_FEATURES_V6.md** - Complete feature list
- **DEVELOPER_GUIDE.md** - Advanced topics
- **API Reference** - Full API documentation

---

## 🎯 Next Steps

1. ✅ Build the engine
2. ✅ Explore example scenes
3. ✅ Try the Design Studio
4. ✅ Create your first plugin
5. ✅ Build your game!

---

## 💡 Tips

- **Use Templates**: Scene templates save time
- **Plugin Composition**: Combine multiple plugins
- **Design First**: Use Design Studio before coding
- **Iterate Fast**: Use hot-reload for scripts
- **Performance**: Use Performance Profiler plugin

---

## 🆘 Troubleshooting

**Plugin not loading?**
- Check plugin manifest format
- Ensure dependencies are met
- Look for errors in console

**Drag & drop not working?**
- Initialize DragDropManager
- Register drop targets
- Check file types

**Design tools not appearing?**
- Initialize DesignStudio
- Check editor tab visibility

---

## 🎉 You're Ready!

BADGE Engine v6.0 has everything you need to create:
- Rhythm games
- Racing games  
- Board games
- RPGs
- Social deduction games
- Puzzle games
- Platformers
- And anything else you imagine!

**Start building amazing games today!**

---

*BADGE Engine v6.0 - By ATLAS NETWORK CLUB*
*March 2026*
