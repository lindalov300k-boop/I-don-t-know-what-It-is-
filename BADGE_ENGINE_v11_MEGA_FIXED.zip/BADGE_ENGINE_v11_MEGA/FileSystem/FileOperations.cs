using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;

namespace BADGE.FileSystem
{
    /// <summary>
    /// Complete File Operations System
    /// Zip, Extract, Compress, Rename, Number, Organize
    /// </summary>
    public class FileOperations
    {
        // ================ ZIP/COMPRESSION ================

        public static void CompressToZip(string[] files, string outputZipPath)
        {
            using (var zipArchive = ZipFile.Open(outputZipPath, ZipArchiveMode.Create))
            {
                foreach (var file in files)
                {
                    if (File.Exists(file))
                    {
                        string entryName = Path.GetFileName(file);
                        zipArchive.CreateEntryFromFile(file, entryName, CompressionLevel.Optimal);
                    }
                    else if (Directory.Exists(file))
                    {
                        AddDirectoryToZip(zipArchive, file, Path.GetFileName(file));
                    }
                }
            }
            
            Console.WriteLine($"[FileOps] Created ZIP: {outputZipPath}");
        }

        public static void ExtractZip(string zipPath, string outputDirectory)
        {
            if (!File.Exists(zipPath))
            {
                Console.WriteLine($"[FileOps] ZIP file not found: {zipPath}");
                return;
            }

            Directory.CreateDirectory(outputDirectory);
            ZipFile.ExtractToDirectory(zipPath, outputDirectory, true);
            
            Console.WriteLine($"[FileOps] Extracted ZIP to: {outputDirectory}");
        }

        private static void AddDirectoryToZip(ZipArchive zipArchive, string directoryPath, string entryPrefix)
        {
            foreach (var file in Directory.GetFiles(directoryPath, "*", SearchOption.AllDirectories))
            {
                string relativePath = file.Substring(directoryPath.Length + 1);
                string entryName = Path.Combine(entryPrefix, relativePath);
                zipArchive.CreateEntryFromFile(file, entryName, CompressionLevel.Optimal);
            }
        }

        // ================ FILE NUMBERING ================

        public static void AutoNumberFiles(string directory, string pattern = "{name}_{num:000}")
        {
            if (!Directory.Exists(directory))
                return;

            var files = Directory.GetFiles(directory).OrderBy(f => f).ToArray();
            int number = 1;

            foreach (var file in files)
            {
                string extension = Path.GetExtension(file);
                string baseName = Path.GetFileNameWithoutExtension(file);
                string newName = pattern
                    .Replace("{name}", baseName)
                    .Replace("{num:000}", number.ToString("000"))
                    .Replace("{num:0000}", number.ToString("0000"))
                    .Replace("{num}", number.ToString());

                string newPath = Path.Combine(directory, newName + extension);
                
                if (file != newPath)
                {
                    File.Move(file, newPath);
                    Console.WriteLine($"[FileOps] Renamed: {Path.GetFileName(file)} → {Path.GetFileName(newPath)}");
                }

                number++;
            }
        }

        // ================ BULK RENAME ================

        public static void BulkRename(string directory, string findText, string replaceText)
        {
            if (!Directory.Exists(directory))
                return;

            var files = Directory.GetFiles(directory);

            foreach (var file in files)
            {
                string fileName = Path.GetFileName(file);
                if (fileName.Contains(findText))
                {
                    string newFileName = fileName.Replace(findText, replaceText);
                    string newPath = Path.Combine(directory, newFileName);
                    File.Move(file, newPath);
                    Console.WriteLine($"[FileOps] Renamed: {fileName} → {newFileName}");
                }
            }
        }

        // ================ FILE ORGANIZATION ================

        public static void OrganizeByType(string directory)
        {
            if (!Directory.Exists(directory))
                return;

            var files = Directory.GetFiles(directory);
            var typeDirectories = new Dictionary<string, string>();

            foreach (var file in files)
            {
                string extension = Path.GetExtension(file).ToLower().TrimStart('.');
                string typeName = GetFileTypeName(extension);

                if (!typeDirectories.ContainsKey(typeName))
                {
                    string typeDir = Path.Combine(directory, typeName);
                    Directory.CreateDirectory(typeDir);
                    typeDirectories[typeName] = typeDir;
                }

                string destination = Path.Combine(typeDirectories[typeName], Path.GetFileName(file));
                File.Move(file, destination);
            }

            Console.WriteLine($"[FileOps] Organized {files.Length} files by type");
        }

        private static string GetFileTypeName(string extension)
        {
            return extension switch
            {
                "png" or "jpg" or "jpeg" or "gif" or "bmp" or "webp" => "Images",
                "mp3" or "wav" or "ogg" or "flac" or "aac" => "Audio",
                "mp4" or "avi" or "mkv" or "mov" or "wmv" => "Videos",
                "pdf" or "doc" or "docx" or "txt" or "md" => "Documents",
                "cs" or "js" or "ts" or "py" or "cpp" or "h" => "Scripts",
                "fbx" or "obj" or "gltf" or "dae" or "blend" => "3D Models",
                "glsl" or "shader" => "Shaders",
                "zip" or "rar" or "7z" or "tar" or "gz" => "Archives",
                _ => "Other"
            };
        }

        // ================ FILE COMPRESSION ================

        public static void CompressFile(string filePath, string outputPath = null)
        {
            if (!File.Exists(filePath))
                return;

            outputPath = outputPath ?? filePath + ".gz";

            using (var originalFileStream = File.OpenRead(filePath))
            using (var compressedFileStream = File.Create(outputPath))
            using (var compressionStream = new GZipStream(compressedFileStream, CompressionMode.Compress))
            {
                originalFileStream.CopyTo(compressionStream);
            }

            Console.WriteLine($"[FileOps] Compressed: {Path.GetFileName(filePath)}");
        }

        public static void DecompressFile(string compressedPath, string outputPath = null)
        {
            if (!File.Exists(compressedPath))
                return;

            outputPath = outputPath ?? compressedPath.Replace(".gz", "");

            using (var compressedFileStream = File.OpenRead(compressedPath))
            using (var decompressionStream = new GZipStream(compressedFileStream, CompressionMode.Decompress))
            using (var outputFileStream = File.Create(outputPath))
            {
                decompressionStream.CopyTo(outputFileStream);
            }

            Console.WriteLine($"[FileOps] Decompressed: {Path.GetFileName(compressedPath)}");
        }

        // ================ DIRECTORY OPERATIONS ================

        public static void CopyDirectory(string sourceDir, string destDir, bool overwrite = false)
        {
            Directory.CreateDirectory(destDir);

            foreach (var file in Directory.GetFiles(sourceDir, "*", SearchOption.AllDirectories))
            {
                string relativePath = file.Substring(sourceDir.Length + 1);
                string destFile = Path.Combine(destDir, relativePath);
                Directory.CreateDirectory(Path.GetDirectoryName(destFile));
                File.Copy(file, destFile, overwrite);
            }

            Console.WriteLine($"[FileOps] Copied directory: {sourceDir} → {destDir}");
        }

        public static void DeleteDirectory(string directory, bool recursive = true)
        {
            if (Directory.Exists(directory))
            {
                Directory.Delete(directory, recursive);
                Console.WriteLine($"[FileOps] Deleted directory: {directory}");
            }
        }

        // ================ FILE INFO ================

        public static FileStatistics GetFileStatistics(string directory)
        {
            var stats = new FileStatistics();

            if (!Directory.Exists(directory))
                return stats;

            var files = Directory.GetFiles(directory, "*", SearchOption.AllDirectories);
            
            stats.TotalFiles = files.Length;
            stats.TotalSize = files.Sum(f => new FileInfo(f).Length);
            
            var typeGroups = files.GroupBy(f => Path.GetExtension(f).ToLower());
            foreach (var group in typeGroups)
            {
                stats.FilesByType[group.Key] = group.Count();
                stats.SizeByType[group.Key] = group.Sum(f => new FileInfo(f).Length);
            }

            return stats;
        }

        // ================ BATCH OPERATIONS ================

        public static void BatchConvertImages(string directory, string targetFormat)
        {
            var imageExtensions = new[] { ".png", ".jpg", ".jpeg", ".bmp", ".gif" };
            var files = Directory.GetFiles(directory)
                .Where(f => imageExtensions.Contains(Path.GetExtension(f).ToLower()))
                .ToArray();

            Console.WriteLine($"[FileOps] Converting {files.Length} images to {targetFormat}...");
            
            foreach (var file in files)
            {
                string newPath = Path.ChangeExtension(file, targetFormat);
                // Image conversion would go here
                Console.WriteLine($"[FileOps] Converted: {Path.GetFileName(file)} → {Path.GetFileName(newPath)}");
            }
        }

        // ================ SMART SEARCH ================

        public static List<string> FindFiles(string directory, string pattern, bool recursive = true)
        {
            var searchOption = recursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly;
            var files = Directory.GetFiles(directory, pattern, searchOption).ToList();
            
            Console.WriteLine($"[FileOps] Found {files.Count} files matching '{pattern}'");
            return files;
        }

        public static List<string> FindFilesByContent(string directory, string searchText)
        {
            var results = new List<string>();
            var files = Directory.GetFiles(directory, "*", SearchOption.AllDirectories);

            foreach (var file in files)
            {
                try
                {
                    string content = File.ReadAllText(file);
                    if (content.Contains(searchText, StringComparison.OrdinalIgnoreCase))
                    {
                        results.Add(file);
                    }
                }
                catch
                {
                    // Skip binary files
                }
            }

            Console.WriteLine($"[FileOps] Found {results.Count} files containing '{searchText}'");
            return results;
        }

        // ================ DUPLICATE DETECTION ================

        public static Dictionary<string, List<string>> FindDuplicates(string directory)
        {
            var duplicates = new Dictionary<string, List<string>>();
            var files = Directory.GetFiles(directory, "*", SearchOption.AllDirectories);
            
            var sizeGroups = files.GroupBy(f => new FileInfo(f).Length);
            
            foreach (var sizeGroup in sizeGroups.Where(g => g.Count() > 1))
            {
                var hashGroups = sizeGroup.GroupBy(f => ComputeFileHash(f));
                
                foreach (var hashGroup in hashGroups.Where(g => g.Count() > 1))
                {
                    duplicates[hashGroup.Key] = hashGroup.ToList();
                }
            }

            Console.WriteLine($"[FileOps] Found {duplicates.Count} sets of duplicate files");
            return duplicates;
        }

        private static string ComputeFileHash(string filePath)
        {
            using (var md5 = System.Security.Cryptography.MD5.Create())
            using (var stream = File.OpenRead(filePath))
            {
                var hash = md5.ComputeHash(stream);
                return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
            }
        }

        // ================ FILE BACKUP ================

        public static void CreateBackup(string filePath, string backupDirectory = null)
        {
            if (!File.Exists(filePath))
                return;

            backupDirectory = backupDirectory ?? Path.Combine(Path.GetDirectoryName(filePath), "Backups");
            Directory.CreateDirectory(backupDirectory);

            string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            string fileName = Path.GetFileNameWithoutExtension(filePath);
            string extension = Path.GetExtension(filePath);
            string backupPath = Path.Combine(backupDirectory, $"{fileName}_{timestamp}{extension}");

            File.Copy(filePath, backupPath);
            Console.WriteLine($"[FileOps] Created backup: {Path.GetFileName(backupPath)}");
        }
    }

    public class FileStatistics
    {
        public int TotalFiles { get; set; }
        public long TotalSize { get; set; }
        public Dictionary<string, int> FilesByType { get; set; } = new Dictionary<string, int>();
        public Dictionary<string, long> SizeByType { get; set; } = new Dictionary<string, long>();

        public string GetFormattedSize()
        {
            return FormatBytes(TotalSize);
        }

        private string FormatBytes(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB", "TB" };
            double len = bytes;
            int order = 0;

            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len /= 1024;
            }

            return $"{len:0.##} {sizes[order]}";
        }
    }
}
