using System;
using System.IO;
using System.IO.Compression;
namespace BADGE.FileSystem
{
    public static class Exporter
    {
        public static void ExportToZip(string projectName, string outputPath)
        {
            Console.WriteLine($"Exporting {projectName} to {outputPath}");
            string zipPath = Path.Combine(outputPath, $"{projectName}_Build.zip");
            using (var archive = ZipFile.Open(zipPath, ZipArchiveMode.Create))
            {
                archive.CreateEntry("Game.exe");
                archive.CreateEntry("Assets/");
                archive.CreateEntry("Config/");
                archive.CreateEntry("Data/");
                var readme = archive.CreateEntry("ReadMe.txt");
                using (var writer = new StreamWriter(readme.Open()))
                {
                    writer.WriteLine($"BADGE Game Build - {projectName}");
                    writer.WriteLine("By ATLAS NETWORK CLUB");
                    writer.WriteLine("Creator Alias: Fake");
                }
            }
            Console.WriteLine($"Build complete: {zipPath}");
        }
    }
}
