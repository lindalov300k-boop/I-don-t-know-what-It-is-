using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BADGE.FileSystem
{
    /// <summary>
    /// Comprehensive asset importing system
    /// Supports 2D sprites, 3D models, audio, and more
    /// </summary>
    public static class AssetImporter
    {
        private static Dictionary<string, AssetImportSettings> _importCache;
        private static string _assetDirectory = "Assets/";

        static AssetImporter()
        {
            _importCache = new Dictionary<string, AssetImportSettings>();
            EnsureDirectories();
        }

        private static void EnsureDirectories()
        {
            string[] dirs = {
                "Assets/Sprites",
                "Assets/Textures",
                "Assets/Models",
                "Assets/Audio",
                "Assets/Scripts",
                "Assets/Materials",
                "Assets/Scenes",
                "Assets/Prefabs",
                "Assets/Generated",
                "Assets/Fonts",
                "Assets/Shaders"
            };

            foreach (var dir in dirs)
            {
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);
            }

            Console.WriteLine("  - Asset directories initialized");
        }

        // ==================== 2D ASSET IMPORTING ====================

        /// <summary>
        /// Import 2D sprite image (PNG, JPG, BMP)
        /// </summary>
        public static Sprite ImportSprite(string filepath, SpriteImportSettings settings = null)
        {
            if (!File.Exists(filepath))
            {
                Console.WriteLine($"ERROR: File not found: {filepath}");
                return null;
            }

            settings = settings ?? SpriteImportSettings.Default;

            Console.WriteLine($"Importing sprite: {Path.GetFileName(filepath)}");

            // Read image data (simplified - would use actual image library)
            byte[] imageData = File.ReadAllBytes(filepath);

            // Create sprite
            Sprite sprite = new Sprite
            {
                Name = Path.GetFileNameWithoutExtension(filepath),
                Width = settings.TargetWidth,
                Height = settings.TargetHeight,
                Data = ProcessImageData(imageData, settings),
                PixelsPerUnit = settings.PixelsPerUnit,
                FilterMode = settings.FilterMode
            };

            // Save to assets folder
            string assetPath = Path.Combine("Assets/Sprites", Path.GetFileName(filepath));
            File.Copy(filepath, assetPath, overwrite: true);

            // Cache import settings
            _importCache[assetPath] = settings;

            Console.WriteLine($"  ✓ Imported: {sprite.Name} ({sprite.Width}x{sprite.Height})");
            return sprite;
        }

        /// <summary>
        /// Import spritesheet and slice into individual sprites
        /// </summary>
        public static List<Sprite> ImportSpritesheet(string filepath, SpritesheetSettings settings)
        {
            Console.WriteLine($"Importing spritesheet: {Path.GetFileName(filepath)}");

            List<Sprite> sprites = new List<Sprite>();

            // Read base image
            byte[] imageData = File.ReadAllBytes(filepath);

            // Calculate slice positions
            int cols = settings.Columns;
            int rows = settings.Rows;
            int cellWidth = settings.Width / cols;
            int cellHeight = settings.Height / rows;

            // Extract each sprite
            for (int row = 0; row < rows; row++)
            {
                for (int col = 0; col < cols; col++)
                {
                    Sprite sprite = new Sprite
                    {
                        Name = $"{settings.BaseName}_{row}_{col}",
                        Width = cellWidth,
                        Height = cellHeight,
                        Data = ExtractSprite(imageData, col * cellWidth, row * cellHeight, cellWidth, cellHeight),
                        PixelsPerUnit = settings.PixelsPerUnit,
                        FilterMode = FilterMode.Point
                    };

                    sprites.Add(sprite);
                }
            }

            Console.WriteLine($"  ✓ Sliced into {sprites.Count} sprites");
            return sprites;
        }

        // ==================== 3D ASSET IMPORTING ====================

        /// <summary>
        /// Import 3D model (OBJ, FBX format support)
        /// </summary>
        public static G3DP.Mesh ImportMesh(string filepath, MeshImportSettings settings = null)
        {
            if (!File.Exists(filepath))
            {
                Console.WriteLine($"ERROR: File not found: {filepath}");
                return null;
            }

            settings = settings ?? MeshImportSettings.Default;

            Console.WriteLine($"Importing 3D model: {Path.GetFileName(filepath)}");

            string extension = Path.GetExtension(filepath).ToLower();
            G3DP.Mesh mesh = null;

            switch (extension)
            {
                case ".obj":
                    mesh = ImportOBJ(filepath, settings);
                    break;
                case ".fbx":
                    mesh = ImportFBX(filepath, settings);
                    break;
                default:
                    Console.WriteLine($"ERROR: Unsupported format: {extension}");
                    return null;
            }

            if (mesh != null)
            {
                // Apply import settings
                if (settings.OptimizeForLowEnd)
                {
                    mesh = OptimizeMesh(mesh, settings.TargetTriangleCount);
                }

                if (settings.GenerateNormals)
                {
                    mesh.RecalculateNormals();
                }

                // Save to assets
                string assetPath = Path.Combine("Assets/Models", Path.GetFileName(filepath));
                File.Copy(filepath, assetPath, overwrite: true);

                Console.WriteLine($"  ✓ Imported: {mesh.Vertices.Count} vertices, {mesh.TriangleCount} triangles");
            }

            return mesh;
        }

        private static G3DP.Mesh ImportOBJ(string filepath, MeshImportSettings settings)
        {
            G3DP.Mesh mesh = new G3DP.Mesh();

            // Simple OBJ parser
            string[] lines = File.ReadAllLines(filepath);

            foreach (string line in lines)
            {
                string[] tokens = line.Split(' ');

                if (tokens[0] == "v") // Vertex
                {
                    float x = float.Parse(tokens[1]) * settings.Scale;
                    float y = float.Parse(tokens[2]) * settings.Scale;
                    float z = float.Parse(tokens[3]) * settings.Scale;
                    mesh.Vertices.Add(new Core.Vector3(x, y, z));
                }
                else if (tokens[0] == "f") // Face
                {
                    // Parse face indices (simplified - handles only triangles)
                    int v1 = int.Parse(tokens[1].Split('/')[0]) - 1;
                    int v2 = int.Parse(tokens[2].Split('/')[0]) - 1;
                    int v3 = int.Parse(tokens[3].Split('/')[0]) - 1;

                    mesh.Triangles.Add(v1);
                    mesh.Triangles.Add(v2);
                    mesh.Triangles.Add(v3);
                }
            }

            return mesh;
        }

        private static G3DP.Mesh ImportFBX(string filepath, MeshImportSettings settings)
        {
            // FBX import requires an external library (e.g. Assimp via AssimpNet NuGet).
            // Without it, return an empty mesh and log guidance.
            Console.WriteLine("  [AssetImporter] FBX: install AssimpNet and hook ImportFBX for full support.");
            return new G3DP.Mesh();
        }

        private static G3DP.Mesh OptimizeMesh(G3DP.Mesh mesh, int targetTriangleCount)
        {
            if (mesh.TriangleCount <= targetTriangleCount)
                return mesh;

            Console.WriteLine($"  Optimizing mesh: {mesh.TriangleCount} → {targetTriangleCount} triangles");

            // Simplified mesh optimization (would use proper decimation algorithm)
            // For now, just warn
            if (mesh.TriangleCount > 50000)
            {
                Console.WriteLine($"  ⚠️ WARNING: High triangle count ({mesh.TriangleCount})");
                Console.WriteLine("     Consider using LOD or mesh simplification");
            }

            return mesh;
        }

        // ==================== AUDIO IMPORTING ====================

        /// <summary>
        /// Import audio file (WAV, MP3, OGG)
        /// </summary>
        public static Audio.AudioClip ImportAudio(string filepath, AudioImportSettings settings = null)
        {
            if (!File.Exists(filepath))
            {
                Console.WriteLine($"ERROR: File not found: {filepath}");
                return null;
            }

            settings = settings ?? AudioImportSettings.Default;

            Console.WriteLine($"Importing audio: {Path.GetFileName(filepath)}");

            string extension = Path.GetExtension(filepath).ToLower();

            Audio.AudioClip clip = new Audio.AudioClip
            {
                Name = Path.GetFileNameWithoutExtension(filepath)
            };

            switch (extension)
            {
                case ".wav":
                    clip.Samples = ImportWAV(filepath, settings);
                    break;
                case ".mp3":
                    clip.Samples = ImportMP3(filepath, settings);
                    break;
                case ".ogg":
                    clip.Samples = ImportOGG(filepath, settings);
                    break;
                default:
                    Console.WriteLine($"ERROR: Unsupported audio format: {extension}");
                    return null;
            }

            // Save to assets
            string assetPath = Path.Combine("Assets/Audio", Path.GetFileName(filepath));
            File.Copy(filepath, assetPath, overwrite: true);

            Console.WriteLine($"  ✓ Imported: {clip.Samples.Length} samples @ {settings.SampleRate}Hz");
            return clip;
        }

        private static float[] ImportWAV(string filepath, AudioImportSettings settings)
        {
            // Simplified WAV import (would use proper audio library)
            byte[] data = File.ReadAllBytes(filepath);
            int sampleCount = data.Length / 2; // 16-bit samples
            float[] samples = new float[sampleCount];

            // Convert bytes to float samples
            for (int i = 0; i < sampleCount; i++)
            {
                short sample = BitConverter.ToInt16(data, i * 2);
                samples[i] = sample / 32768.0f;
            }

            return samples;
        }

        private static float[] ImportMP3(string filepath, AudioImportSettings settings)
        {
            // MP3 import requires external library (NAudio, etc.)
            Console.WriteLine("  MP3 import requires NAudio library");
            return new float[44100]; // 1 second silence placeholder
        }

        private static float[] ImportOGG(string filepath, AudioImportSettings settings)
        {
            // OGG import requires external library (NVorbis, etc.)
            Console.WriteLine("  OGG import requires NVorbis library");
            return new float[44100]; // 1 second silence placeholder
        }

        // ==================== TEXTURE IMPORTING ====================

        /// <summary>
        /// Import texture for 3D materials
        /// </summary>
        public static Rendering.Texture ImportTexture(string filepath, TextureImportSettings settings = null)
        {
            if (!File.Exists(filepath))
            {
                Console.WriteLine($"ERROR: File not found: {filepath}");
                return null;
            }

            settings = settings ?? TextureImportSettings.Default;

            Console.WriteLine($"Importing texture: {Path.GetFileName(filepath)}");

            byte[] imageData = File.ReadAllBytes(filepath);

            Rendering.Texture texture = new Rendering.Texture(settings.Width, settings.Height)
            {
                Data = ProcessImageData(imageData, settings)
            };

            // Save to assets
            string assetPath = Path.Combine("Assets/Textures", Path.GetFileName(filepath));
            File.Copy(filepath, assetPath, overwrite: true);

            Console.WriteLine($"  ✓ Imported: {texture.Width}x{texture.Height}");
            return texture;
        }

        // ==================== UTILITY METHODS ====================

        private static byte[] ProcessImageData(byte[] data, AssetImportSettings settings)
        {
            // Image processing (resize, compress, optimize)
            // Simplified - would use actual image library

            if (settings.OptimizeForLowEnd)
            {
                // Compress and optimize
                Console.WriteLine("  Optimizing for low-end hardware...");
            }

            return data;
        }

        private static byte[] ExtractSprite(byte[] sheetData, int x, int y, int width, int height)
        {
            // Extract sub-rectangle from an RGBA spritesheet.
            // sheetData layout: row-major RGBA, stride = sheetWidth * 4.
            // We don't know sheetWidth here, so derive it from total size.
            int totalPixels = sheetData.Length / 4;
            int sheetWidth  = (int)Math.Sqrt(totalPixels);  // assume square sheet

            var sprite = new byte[width * height * 4];
            for (int row = 0; row < height; row++)
            {
                int srcOffset = ((y + row) * sheetWidth + x) * 4;
                int dstOffset = row * width * 4;
                int copyLen   = width * 4;
                if (srcOffset + copyLen > sheetData.Length) break;
                Array.Copy(sheetData, srcOffset, sprite, dstOffset, copyLen);
            }
            return sprite;
        }

        /// <summary>
        /// Get list of all importable files in directory
        /// </summary>
        public static List<string> ScanImportableAssets(string directory)
        {
            List<string> assets = new List<string>();

            string[] supportedExtensions = {
                // Images
                ".png", ".jpg", ".jpeg", ".bmp", ".gif",
                // 3D Models
                ".obj", ".fbx", ".dae",
                // Audio
                ".wav", ".mp3", ".ogg",
                // Scripts
                ".cs"
            };

            if (Directory.Exists(directory))
            {
                foreach (string ext in supportedExtensions)
                {
                    assets.AddRange(Directory.GetFiles(directory, $"*{ext}", SearchOption.AllDirectories));
                }
            }

            return assets;
        }

        /// <summary>
        /// Batch import all assets in directory
        /// </summary>
        public static void BatchImport(string directory)
        {
            Console.WriteLine($"\n=== Batch Import from: {directory} ===");

            var files = ScanImportableAssets(directory);

            foreach (var file in files)
            {
                string ext = Path.GetExtension(file).ToLower();

                try
                {
                    if (ext == ".png" || ext == ".jpg" || ext == ".bmp")
                    {
                        ImportSprite(file);
                    }
                    else if (ext == ".obj" || ext == ".fbx")
                    {
                        ImportMesh(file);
                    }
                    else if (ext == ".wav" || ext == ".mp3" || ext == ".ogg")
                    {
                        ImportAudio(file);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"  ✗ Failed to import {Path.GetFileName(file)}: {ex.Message}");
                }
            }

            Console.WriteLine($"=== Batch import complete: {files.Count} files processed ===\n");
        }
    }

    // ==================== IMPORT SETTINGS CLASSES ====================

    public class AssetImportSettings
    {
        public bool OptimizeForLowEnd { get; set; } = true;
        public bool GenerateThumbnail { get; set; } = true;
    }

    public class SpriteImportSettings : AssetImportSettings
    {
        public static SpriteImportSettings Default => new SpriteImportSettings();

        public int TargetWidth { get; set; } = 512;
        public int TargetHeight { get; set; } = 512;
        public int PixelsPerUnit { get; set; } = 100;
        public FilterMode FilterMode { get; set; } = FilterMode.Point;
        public bool PixelPerfect { get; set; } = true;
        public CompressionQuality Compression { get; set; } = CompressionQuality.Medium;
    }

    public class SpritesheetSettings : SpriteImportSettings
    {
        public string BaseName { get; set; } = "sprite";
        public int Width { get; set; } = 512;
        public int Height { get; set; } = 512;
        public int Columns { get; set; } = 4;
        public int Rows { get; set; } = 4;
    }

    public class MeshImportSettings : AssetImportSettings
    {
        public static MeshImportSettings Default => new MeshImportSettings();

        public float Scale { get; set; } = 1.0f;
        public bool GenerateNormals { get; set; } = true;
        public bool GenerateUVs { get; set; } = false;
        public int TargetTriangleCount { get; set; } = 10000;
        public bool ImportMaterials { get; set; } = true;
        public bool ImportAnimations { get; set; } = false;
    }

    public class AudioImportSettings : AssetImportSettings
    {
        public static AudioImportSettings Default => new AudioImportSettings();

        public int SampleRate { get; set; } = 44100;
        public bool ConvertToMono { get; set; } = false;
        public bool Normalize { get; set; } = true;
        public CompressionQuality Compression { get; set; } = CompressionQuality.Medium;
    }

    public class TextureImportSettings : AssetImportSettings
    {
        public static TextureImportSettings Default => new TextureImportSettings();

        public int Width { get; set; } = 1024;
        public int Height { get; set; } = 1024;
        public bool GenerateMipmaps { get; set; } = true;
        public FilterMode FilterMode { get; set; } = FilterMode.Bilinear;
        public CompressionQuality Compression { get; set; } = CompressionQuality.Medium;
    }

    // ==================== ENUMS ====================

    public enum FilterMode
    {
        Point,      // Pixel-perfect, no filtering
        Bilinear,   // Smooth interpolation
        Trilinear   // Smooth with mipmaps
    }

    public enum CompressionQuality
    {
        None,
        Low,
        Medium,
        High
    }

    // ==================== SPRITE CLASS ====================

    public class Sprite
    {
        public string Name { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public byte[] Data { get; set; }
        public int PixelsPerUnit { get; set; } = 100;
        public FilterMode FilterMode { get; set; } = FilterMode.Point;
    }
}
