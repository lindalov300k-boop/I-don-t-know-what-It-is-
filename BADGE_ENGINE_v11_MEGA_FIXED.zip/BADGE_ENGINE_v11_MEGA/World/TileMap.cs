using System;
using System.Collections.Generic;
using OpenTK.Mathematics;

namespace BADGE.World;

// ═══════════════════════════════════════════════════════════════════════
//  TILE DEFINITION
// ═══════════════════════════════════════════════════════════════════════
public enum TileLayer { Background, Midground, Foreground, Liquid }

[Flags]
public enum TileFlags
{
    None         = 0,
    Solid        = 1 << 0,
    Platform     = 1 << 1,    // pass-through from below
    Liquid       = 1 << 2,
    Climbable    = 1 << 3,
    Destructible = 1 << 4,
    Luminous     = 1 << 5,    // emits tile-based light
}

public struct TileDef
{
    public ushort Id;
    public string Name;
    public TileFlags Flags;
    public int      TextureX, TextureY;   // atlas coords
    public float    Hardness;             // hits to break (0 = indestructible)
    public byte     LightEmission;        // 0-15
    public byte     LightAbsorption;      // 0-15 — how much light this tile blocks
    public string   BreakSound;
    public string   PlaceSound;
    public ushort   DropItemId;           // item spawned on break

    public bool HasFlag(TileFlags f) => (Flags & f) != 0;
}

// ═══════════════════════════════════════════════════════════════════════
//  TILE CELL  (16 bytes, cache-friendly)
// ═══════════════════════════════════════════════════════════════════════
public struct TileCell
{
    public ushort FgId;      // foreground tile ID (0 = empty)
    public ushort BgId;      // background wall ID
    public byte   LiquidAmt; // 0–255: fill level for water/lava
    public byte   LiquidType;// 0=none, 1=water, 2=lava, 3=honey
    public byte   Light;     // computed light level 0–15
    public byte   Damage;    // accumulated damage hits
}

// ═══════════════════════════════════════════════════════════════════════
//  TILE CHUNK  (16×16 cells per chunk)
// ═══════════════════════════════════════════════════════════════════════
public class TileChunk
{
    public const int SIZE = 16;

    public int ChunkX { get; }
    public int ChunkY { get; }
    public bool IsDirty { get; set; }   // mesh needs rebuild

    private readonly TileCell[,] _cells = new TileCell[SIZE, SIZE];

    public TileChunk(int cx, int cy) { ChunkX = cx; ChunkY = cy; }

    public ref TileCell GetCell(int lx, int ly) => ref _cells[lx, ly];

    public void SetFg(int lx, int ly, ushort id)
    {
        _cells[lx, ly].FgId = id;
        IsDirty = true;
    }

    public void SetBg(int lx, int ly, ushort id)
    {
        _cells[lx, ly].BgId = id;
        IsDirty = true;
    }

    public bool IsEmpty()
    {
        for (int x = 0; x < SIZE; x++)
        for (int y = 0; y < SIZE; y++)
            if (_cells[x, y].FgId != 0 || _cells[x, y].BgId != 0) return false;
        return true;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  TILE REGISTRY
// ═══════════════════════════════════════════════════════════════════════
public static class TileRegistry
{
    private static readonly Dictionary<ushort, TileDef> _defs = new();

    public static void Register(TileDef def) => _defs[def.Id] = def;

    public static ref TileDef Get(ushort id)
    {
        if (_defs.TryGetValue(id, out _)) return ref System.Runtime.InteropServices.CollectionsMarshal.GetValueRefOrNullRef(_defs, id);
        return ref System.Runtime.InteropServices.CollectionsMarshal.GetValueRefOrAddDefault(_defs, 0, out _);
    }

    public static bool TryGet(ushort id, out TileDef def) => _defs.TryGetValue(id, out def);

    public static void RegisterDefaults()
    {
        Register(new TileDef { Id=1, Name="Dirt",   Flags=TileFlags.Solid|TileFlags.Destructible, Hardness=2, TextureX=0, TextureY=0, LightAbsorption=15 });
        Register(new TileDef { Id=2, Name="Stone",  Flags=TileFlags.Solid|TileFlags.Destructible, Hardness=5, TextureX=1, TextureY=0, LightAbsorption=15 });
        Register(new TileDef { Id=3, Name="Wood",   Flags=TileFlags.Solid|TileFlags.Destructible, Hardness=3, TextureX=2, TextureY=0 });
        Register(new TileDef { Id=4, Name="Grass",  Flags=TileFlags.Solid|TileFlags.Destructible, Hardness=2, TextureX=3, TextureY=0 });
        Register(new TileDef { Id=5, Name="Water",  Flags=TileFlags.Liquid, LightAbsorption=4 });
        Register(new TileDef { Id=6, Name="Lava",   Flags=TileFlags.Liquid|TileFlags.Luminous, LightEmission=12, LightAbsorption=6 });
        Register(new TileDef { Id=7, Name="Torch",  Flags=TileFlags.Luminous, LightEmission=14, Hardness=1 });
        Register(new TileDef { Id=8, Name="Platform",Flags=TileFlags.Platform|TileFlags.Destructible, Hardness=1 });
        Register(new TileDef { Id=9, Name="Bedrock",Flags=TileFlags.Solid, Hardness=0 });
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  TILEMAP COMPONENT
// ═══════════════════════════════════════════════════════════════════════
/// <summary>
/// Main 2D tile world. Handles chunk management, tile manipulation,
/// liquid simulation, and flood-fill lighting.
/// Needed by: Terraria, Limbo, Ludo boards, simulator grids.
/// </summary>
public class TileMap : BADGE.Core.Component
{
    public float TileSize   { get; set; } = 1f;   // world units per tile
    public int   WorldWidth { get; set; } = 4096;  // tiles
    public int   WorldDepth { get; set; } = 1024;

    private readonly Dictionary<(int, int), TileChunk> _chunks = new();

    // ── Chunk access ──────────────────────────────────────────────
    public TileChunk GetOrCreateChunk(int cx, int cy)
    {
        var key = (cx, cy);
        if (!_chunks.TryGetValue(key, out var chunk))
        {
            chunk = new TileChunk(cx, cy);
            _chunks[key] = chunk;
        }
        return chunk;
    }

    public TileChunk? GetChunk(int cx, int cy)
        => _chunks.TryGetValue((cx, cy), out var c) ? c : null;

    private void WorldToChunk(int wx, int wy, out int cx, out int cy, out int lx, out int ly)
    {
        cx = wx >= 0 ? wx / TileChunk.SIZE : (wx - TileChunk.SIZE + 1) / TileChunk.SIZE;
        cy = wy >= 0 ? wy / TileChunk.SIZE : (wy - TileChunk.SIZE + 1) / TileChunk.SIZE;
        lx = ((wx % TileChunk.SIZE) + TileChunk.SIZE) % TileChunk.SIZE;
        ly = ((wy % TileChunk.SIZE) + TileChunk.SIZE) % TileChunk.SIZE;
    }

    // ── Tile read/write ───────────────────────────────────────────
    public ushort GetFg(int wx, int wy)
    {
        WorldToChunk(wx, wy, out var cx, out var cy, out var lx, out var ly);
        return GetChunk(cx, cy)?.GetCell(lx, ly).FgId ?? 0;
    }

    public ushort GetBg(int wx, int wy)
    {
        WorldToChunk(wx, wy, out var cx, out var cy, out var lx, out var ly);
        return GetChunk(cx, cy)?.GetCell(lx, ly).BgId ?? 0;
    }

    public void SetFg(int wx, int wy, ushort id)
    {
        WorldToChunk(wx, wy, out var cx, out var cy, out var lx, out var ly);
        GetOrCreateChunk(cx, cy).SetFg(lx, ly, id);
        MarkNeighboursDirty(cx, cy);
    }

    public void SetBg(int wx, int wy, ushort id)
    {
        WorldToChunk(wx, wy, out var cx, out var cy, out var lx, out var ly);
        GetOrCreateChunk(cx, cy).SetBg(lx, ly, id);
    }

    private void MarkNeighboursDirty(int cx, int cy)
    {
        for (int dx = -1; dx <= 1; dx++)
        for (int dy = -1; dy <= 1; dy++)
            if (GetChunk(cx + dx, cy + dy) is { } c) c.IsDirty = true;
    }

    // ── Tile query helpers ────────────────────────────────────────
    public bool IsSolid(int wx, int wy)
    {
        var id = GetFg(wx, wy);
        return id != 0 && TileRegistry.TryGet(id, out var def) && def.HasFlag(TileFlags.Solid);
    }

    public bool IsPlatform(int wx, int wy)
    {
        var id = GetFg(wx, wy);
        return id != 0 && TileRegistry.TryGet(id, out var def) && def.HasFlag(TileFlags.Platform);
    }

    public bool IsEmpty(int wx, int wy) => GetFg(wx, wy) == 0;

    // ── World-space helpers ───────────────────────────────────────
    public Vector2 TileToWorld(int wx, int wy) => new Vector2(wx * TileSize, wy * TileSize);

    public (int, int) WorldToTile(Vector2 worldPos)
        => ((int)MathF.Floor(worldPos.X / TileSize), (int)MathF.Floor(worldPos.Y / TileSize));

    // ── Damage / destruction ──────────────────────────────────────
    /// <summary>Apply damage to a tile. Returns true if it broke.</summary>
    public bool DamageTile(int wx, int wy, byte dmg)
    {
        WorldToChunk(wx, wy, out var cx, out var cy, out var lx, out var ly);
        var chunk = GetChunk(cx, cy);
        if (chunk == null) return false;

        ref var cell = ref chunk.GetCell(lx, ly);
        if (cell.FgId == 0) return false;
        if (!TileRegistry.TryGet(cell.FgId, out var def)) return false;
        if (def.Hardness <= 0) return false;   // indestructible

        cell.Damage += dmg;
        if (cell.Damage >= def.Hardness * 10)
        {
            // Drop item
            if (def.DropItemId != 0)
                ItemDropped?.Invoke(wx, wy, def.DropItemId);
            cell.FgId   = 0;
            cell.Damage = 0;
            chunk.IsDirty = true;
            MarkNeighboursDirty(cx, cy);
            PropagateLighting(wx, wy);
            return true;
        }
        chunk.IsDirty = true;
        return false;
    }

    public event Action<int, int, ushort>? ItemDropped;

    // ── Flood-fill lighting ───────────────────────────────────────
    public void PropagateLighting(int originX, int originY, int radius = 20)
    {
        var queue   = new Queue<(int, int, byte)>();
        var visited = new HashSet<(int, int)>();

        queue.Enqueue((originX, originY, 15));

        while (queue.Count > 0)
        {
            var (x, y, light) = queue.Dequeue();
            if (!visited.Add((x, y))) continue;

            WorldToChunk(x, y, out var cx, out var cy, out var lx, out var ly);
            var chunk = GetChunk(cx, cy);
            if (chunk == null) continue;

            ref var cell = ref chunk.GetCell(lx, ly);
            if (cell.Light >= light) continue;
            cell.Light    = light;
            chunk.IsDirty = true;

            if (light <= 1) continue;

            byte absorbed = TileRegistry.TryGet(cell.FgId, out var def) ? def.LightAbsorption : (byte)0;
            byte next = (byte)Math.Max(0, light - 1 - absorbed);

            if (MathF.Abs(x - originX) < radius && MathF.Abs(y - originY) < radius)
            {
                queue.Enqueue((x+1, y, next));
                queue.Enqueue((x-1, y, next));
                queue.Enqueue((x, y+1, next));
                queue.Enqueue((x, y-1, next));
            }
        }
    }

    // ── Liquid simulation (cellular automaton) ────────────────────
    private int _liquidTick;
    public void UpdateLiquids()
    {
        if (++_liquidTick % 3 != 0) return;  // run every 3rd frame

        foreach (var chunk in _chunks.Values)
        {
            for (int lx = 0; lx < TileChunk.SIZE; lx++)
            for (int ly = 0; ly < TileChunk.SIZE; ly++)
            {
                ref var cell = ref chunk.GetCell(lx, ly);
                if (cell.LiquidAmt == 0) continue;

                int wx = chunk.ChunkX * TileChunk.SIZE + lx;
                int wy = chunk.ChunkY * TileChunk.SIZE + ly;

                // Flow down
                if (!IsSolid(wx, wy - 1))
                {
                    int transfer = Math.Min(cell.LiquidAmt, 50);
                    WorldToChunk(wx, wy-1, out var cx2, out var cy2, out var lx2, out var ly2);
                    ref var below = ref GetOrCreateChunk(cx2, cy2).GetCell(lx2, ly2);
                    if (below.LiquidType == 0) below.LiquidType = cell.LiquidType;
                    int space = 255 - below.LiquidAmt;
                    transfer  = Math.Min(transfer, space);
                    below.LiquidAmt   += (byte)transfer;
                    cell.LiquidAmt    -= (byte)transfer;
                }

                // Flow sideways
                if (cell.LiquidAmt > 1)
                {
                    int spread = cell.LiquidAmt / 4;
                    foreach (int dx in new[] { -1, 1 })
                    {
                        if (!IsSolid(wx + dx, wy))
                        {
                            WorldToChunk(wx+dx, wy, out var cx2, out var cy2, out var lx2, out var ly2);
                            ref var side = ref GetOrCreateChunk(cx2, cy2).GetCell(lx2, ly2);
                            if (side.LiquidAmt < cell.LiquidAmt - 1)
                            {
                                int t = Math.Min(spread, cell.LiquidAmt - side.LiquidAmt) / 2;
                                side.LiquidAmt += (byte)t;
                                cell.LiquidAmt -= (byte)t;
                            }
                        }
                    }
                }
            }
        }
    }

    // ── Raycasting ────────────────────────────────────────────────
    /// <summary>2D tile raycast. Returns true if a solid tile was hit.</summary>
    public bool Raycast(Vector2 origin, Vector2 dir, float maxDist, out Vector2 hitPos, out (int,int) hitTile)
    {
        hitPos  = origin;
        hitTile = (0, 0);

        dir = dir.Normalized;
        float dist = 0f;
        float step = TileSize * 0.5f;

        while (dist < maxDist)
        {
            var pos = origin + dir * dist;
            var (tx, ty) = WorldToTile(pos);
            if (IsSolid(tx, ty))
            {
                hitPos  = pos;
                hitTile = (tx, ty);
                return true;
            }
            dist += step;
        }
        return false;
    }

    // ── Chunk lifecycle ───────────────────────────────────────────
    public IEnumerable<TileChunk> GetLoadedChunks() => _chunks.Values;

    public void UnloadChunk(int cx, int cy) => _chunks.Remove((cx, cy));

    public int LoadedChunkCount => _chunks.Count;
}
