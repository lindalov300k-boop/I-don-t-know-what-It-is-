# BADGE Studio v4.0 — Release Notes

## Bug Fixes Applied (v3 → v4)

| # | File | Bug | Fix |
|---|------|-----|-----|
| 1 | `Utilities/Math.cs` | Missing `Vector3.Angle()` static method | Added method returning degrees |
| 2 | `AI/AISystem.cs` | `Vector2.Normalized()` called as method (it's a property) | Removed `()` on all 10 occurrences |
| 3 | `Utilities/Math.cs` | `Vector2.Length()` method missing | Added `Length()` alias for `Magnitude` |
| 4 | `Animation/AnimationSystem.cs` | `AnimationClip.Evaluate()` doesn't exist | Changed to `clip.AnimClip.Sample(local, go)` |
| 5 | `SDK/SDKAPI.cs` | `Config` has `private set` but assigned externally | Added `SetConfig()` public method |
| 6 | `BADGE.Engine.csproj` | `Nullable` set to `warnings` instead of `enable` | Fixed to `<Nullable>enable</Nullable>` |
| 7 | `BADGE.Engine.csproj` | `OutputType=Exe` with no entry point | Changed to `<OutputType>Library</OutputType>` |
| 8 | `InputSystem/InputSystem.cs` | Unsafe `Enum.Parse<KeyCode>()` on string bindings | Changed to `Enum.TryParse` with fallback |
| 9 | `Audio/AudioEngine.cs` | Wrong `ArgumentNullException` parameter name | Changed to `ArgumentException` with correct message |
| 10 | `Security/Security.cs` | `Checksums` class declared twice without `partial` | Added `partial` keyword to first declaration |
| 11 | `Animation/AnimationSystem.cs` | Missing closing `}` brace (depth=1 at EOF) | Appended closing brace |
| 12 | `NodeSystems/NodeSystem.cs` | Missing closing `}` brace (depth=1 at EOF) | Appended closing brace |
| 13 | `Editor/AnimationEditor/AnimationEditorSystem.cs` | Extra `}` brace (depth=-1 at EOF) | Removed trailing extra brace |

## New Features

### AI/GameDevAssistant.cs
- In-engine AI coding assistant with live web context
- Searches GitHub Search API (free, 10 req/min) and Stack Exchange API (free, ~300/day)
- Calls Anthropic Claude API for BADGE-specific code generation
- `GameDevAssistantPanel` implements `IEditorExtension` for editor integration
- Configure via env vars: `ANTHROPIC_API_KEY`, `GITHUB_TOKEN`

## Project Structure

```
BADGE.Engine.csproj     ← OutputType=Library, net8.0, Nullable=enable
AI/
  AISystem.cs           ← NavMesh, BehaviorTree, SteeringAgent, CrowdManager
  GameDevAssistant.cs   ← NEW: AI coding assistant + asset search
Animation/
  AnimationSystem.cs    ← AnimatorController, BlendTree, IK, Timeline, MoCap
Audio/
  AudioEngine.cs        ← DSP chain (7 effects), spatial audio, mixer buses
Components/
  ComponentSystem.cs    ← GameObject, Transform, Camera, Rigidbody, Colliders
Engine/
  Engine.cs             ← Top-level singleton, lifecycle management
  EngineKernel.cs       ← High-level facade for game code
  Kernel.cs             ← Low-level kernel, hardware boot
InputSystem/
  InputSystem.cs        ← Keyboard, mouse, gamepad, touch
Physics/
  PhysicsWorld.cs       ← BVH broadphase, SAT narrowphase, constraints
Runtime/
  Time.cs               ← Static time facade
  GameLoop.cs           ← Fixed + variable timestep loop
SceneSystem/
  SceneSystem.cs        ← Scene, SceneManager, Prefab, Object, LayerMask
SDK/
  SDKAPI.cs             ← GameApplication, IEnginePlugin, IEditorExtension
Security/
  Security.cs           ← Encryption, checksums (partial classes fixed)
Utilities/
  Math.cs               ← Vector2/3/4, Quaternion, Matrix4, Color, Bounds, Ray
```

## Usage

```csharp
// Reference BADGE.Engine.dll from your game project
public class MyGame : GameApplication
{
    protected override void OnInitialize()
    {
        var scene = new Scene("Main");
        Kernel.SceneManager.RegisterScene("Main", scene);
        Kernel.SceneManager.LoadScene("Main");
    }
}

new MyGame().Run(new EngineConfig { TargetFPS = 60 });
```

## AI Assistant Usage

```csharp
// Set env var: ANTHROPIC_API_KEY=your_key
var ai = new GameDevAssistant();
var reply = await ai.AskAsync("How do I make an enemy patrol AI?");
Console.WriteLine(reply.Answer);
```
