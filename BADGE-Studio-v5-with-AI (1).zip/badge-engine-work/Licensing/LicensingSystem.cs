// ============================================================
//  BADGE Engine – Licensing/LicensingSystem.cs
//  License validation, activation codes, feature entitlements,
//  and offline/online license checks.
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace BADGE.Licensing
{
    public enum LicenseTier { Free, Indie, Studio, Enterprise }
    public enum LicenseStatus { Valid, Expired, Invalid, NotActivated, Revoked }

    // ── License record ────────────────────────────────────────
    public sealed class LicenseRecord
    {
        public string       LicenseKey   { get; set; } = string.Empty;
        public string       HolderName   { get; set; } = string.Empty;
        public string       HolderEmail  { get; set; } = string.Empty;
        public LicenseTier  Tier         { get; set; } = LicenseTier.Free;
        public DateTime     IssuedAt     { get; set; } = DateTime.UtcNow;
        public DateTime     ExpiresAt    { get; set; } = DateTime.MaxValue;
        public bool         IsPerpetual  { get; set; } = false;
        public string       MachineId    { get; set; } = string.Empty;
        public string       Signature    { get; set; } = string.Empty;
    }

    // ── Entitlement flags ─────────────────────────────────────
    public sealed class FeatureEntitlements
    {
        public bool CanExportAndroid   { get; init; }
        public bool CanExportIOS       { get; init; }
        public bool CanExportConsole   { get; init; }
        public bool CanUseNetworking   { get; init; }
        public bool CanRemoveWatermark { get; init; }
        public bool CanUsePrioritySupport { get; init; }
        public int  MaxTeamMembers     { get; init; } = 1;
        public long MaxRevenueUSD      { get; init; } = 0; // 0 = unlimited

        public static FeatureEntitlements For(LicenseTier tier) => tier switch
        {
            LicenseTier.Free       => new() { MaxTeamMembers = 1,  MaxRevenueUSD = 100_000 },
            LicenseTier.Indie      => new() { CanExportAndroid=true, CanExportIOS=true, CanUseNetworking=true, CanRemoveWatermark=true, MaxTeamMembers=3,  MaxRevenueUSD=500_000 },
            LicenseTier.Studio     => new() { CanExportAndroid=true, CanExportIOS=true, CanExportConsole=true, CanUseNetworking=true, CanRemoveWatermark=true, MaxTeamMembers=25 },
            LicenseTier.Enterprise => new() { CanExportAndroid=true, CanExportIOS=true, CanExportConsole=true, CanUseNetworking=true, CanRemoveWatermark=true, CanUsePrioritySupport=true, MaxTeamMembers=int.MaxValue },
            _                      => new()
        };
    }

    // ── Main system ───────────────────────────────────────────
    public sealed class LicensingSystem
    {
        // ── Singleton ─────────────────────────────────────────
        private static LicensingSystem? _instance;
        public  static LicensingSystem   Instance => _instance ??= new();

        // ── State ─────────────────────────────────────────────
        public LicenseRecord?      Active       { get; private set; }
        public LicenseStatus       Status       { get; private set; } = LicenseStatus.NotActivated;
        public FeatureEntitlements Entitlements { get; private set; } = FeatureEntitlements.For(LicenseTier.Free);

        private const string LICENSE_FILE = "badge.license";
        // In production this would be an RSA public key; here we use HMAC for simplicity.
        private const string SECRET_SEED  = "BADGE-STUDIO-LICENSE-SEED-v1";

        // ── Activation ────────────────────────────────────────

        public LicenseStatus Activate(string licenseKey, string holderName, string email, LicenseTier tier)
        {
            var record = new LicenseRecord
            {
                LicenseKey  = licenseKey,
                HolderName  = holderName,
                HolderEmail = email,
                Tier        = tier,
                IssuedAt    = DateTime.UtcNow,
                ExpiresAt   = tier == LicenseTier.Free ? DateTime.MaxValue : DateTime.UtcNow.AddYears(1),
                IsPerpetual = tier == LicenseTier.Enterprise,
                MachineId   = GetMachineId(),
                Signature   = Sign(licenseKey + holderName + tier)
            };

            Save(record);
            Apply(record);
            Console.WriteLine($"[Licensing] Activated {tier} for {holderName} ({email})");
            return Status;
        }

        // ── Load from disk ────────────────────────────────────

        public LicenseStatus Load()
        {
            if (!File.Exists(LICENSE_FILE))
            { Status = LicenseStatus.NotActivated; return Status; }

            try
            {
                var json   = File.ReadAllText(LICENSE_FILE);
                var record = JsonSerializer.Deserialize<LicenseRecord>(json);
                if (record == null) { Status = LicenseStatus.Invalid; return Status; }
                Apply(record);
            }
            catch
            {
                Status = LicenseStatus.Invalid;
            }
            return Status;
        }

        // ── Validation ────────────────────────────────────────

        private void Apply(LicenseRecord record)
        {
            Active = record;

            if (record.ExpiresAt < DateTime.UtcNow && !record.IsPerpetual)
            { Status = LicenseStatus.Expired; Entitlements = FeatureEntitlements.For(LicenseTier.Free); return; }

            string expected = Sign(record.LicenseKey + record.HolderName + record.Tier);
            if (expected != record.Signature)
            { Status = LicenseStatus.Invalid; Entitlements = FeatureEntitlements.For(LicenseTier.Free); return; }

            Status       = LicenseStatus.Valid;
            Entitlements = FeatureEntitlements.For(record.Tier);
        }

        public bool IsFeatureAllowed(string featureName) => featureName switch
        {
            "export.android"     => Entitlements.CanExportAndroid,
            "export.ios"         => Entitlements.CanExportIOS,
            "export.console"     => Entitlements.CanExportConsole,
            "networking"         => Entitlements.CanUseNetworking,
            "no_watermark"       => Entitlements.CanRemoveWatermark,
            "priority_support"   => Entitlements.CanUsePrioritySupport,
            _                    => true  // unknown features are allowed by default
        };

        // ── Helpers ───────────────────────────────────────────

        private static string Sign(string data)
        {
            var key  = Encoding.UTF8.GetBytes(SECRET_SEED);
            var msg  = Encoding.UTF8.GetBytes(data);
            using var hmac = new HMACSHA256(key);
            return Convert.ToHexString(hmac.ComputeHash(msg))[..16];
        }

        private static string GetMachineId()
        {
            // Stable per-machine hash from OS+CPU combo
            string raw = Environment.MachineName + Environment.OSVersion + Environment.ProcessorCount;
            using var sha = SHA256.Create();
            return Convert.ToHexString(sha.ComputeHash(Encoding.UTF8.GetBytes(raw)))[..12];
        }

        private static void Save(LicenseRecord record)
        {
            var json = JsonSerializer.Serialize(record, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(LICENSE_FILE, json);
        }

        // ── Trial helpers ─────────────────────────────────────

        public bool IsTrialExpired() => Status == LicenseStatus.Expired;
        public bool IsActivated()    => Status == LicenseStatus.Valid;

        public TimeSpan? TimeRemaining()
        {
            if (Active == null || Active.IsPerpetual) return null;
            var remaining = Active.ExpiresAt - DateTime.UtcNow;
            return remaining < TimeSpan.Zero ? TimeSpan.Zero : remaining;
        }

        public void PrintStatus()
        {
            Console.WriteLine($"[Licensing] Status: {Status}");
            if (Active != null)
                Console.WriteLine($"[Licensing] {Active.Tier} — {Active.HolderName} — expires {(Active.IsPerpetual ? "never" : Active.ExpiresAt.ToString("yyyy-MM-dd"))}");
        }
    }
}
