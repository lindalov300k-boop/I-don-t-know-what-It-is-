# Libraries
Place Libraries assets here.
BADGE Studio will auto-discover files in this directory.
