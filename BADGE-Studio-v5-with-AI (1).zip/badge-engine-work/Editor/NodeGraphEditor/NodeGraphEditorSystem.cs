using BADGE.Icons;
// ============================================================
//  BADGE Engine – Editor/NodeGraphEditor/NodeGraphEditorSystem.cs
//  Node graph editor: wraps the NodeSystems runtime (BaseNode,
//  NodeGraph, Port) instead of using its own parallel types.
//  Implements IEditorModule so it registers in EditorSystem.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using BADGE.Editor;
using BADGE.NodeSystems;          // the actual node-graph runtime

namespace BADGE.Engine.Editor
{
    public enum NodeGraphType { VisualScript, BehaviourTree, ShaderGraph, AnimationGraph, DialogueGraph }

    // ── Thin editor overlay (position + selection) ────────────
    public sealed class EditorNodeOverlay
    {
        public string  RuntimeNodeId { get; }
        public float   X { get; set; }
        public float   Y { get; set; }
        public bool    IsSelected { get; set; }
        public string? Comment    { get; set; }
        public EditorNodeOverlay(string runtimeId, float x, float y)
        { RuntimeNodeId = runtimeId; X = x; Y = y; }
    }

    public class NodeGraphEditorSystem : IEditorModule
    {
        private static NodeGraphEditorSystem? _instance;
        public  static NodeGraphEditorSystem   Instance => _instance ??= new NodeGraphEditorSystem();

        // ── IEditorModule ─────────────────────────────────────
        public string Name   => "Node Graph Editor";
        public string Icon   => Icons.Network;
        public bool   IsOpen { get; set; }

        public void Open()  { IsOpen = true;  Console.WriteLine("[NodeGraphEditor] Opened."); }
        public void Close() { IsOpen = false; Console.WriteLine("[NodeGraphEditor] Closed."); }

        public void Update(float dt)
        {
            if (!IsOpen || _runtimeGraph == null) return;
            // Tick the runtime graph every editor frame
            _runtimeGraph.Evaluate();
        }

        public void DrawUI()
        {
            if (!IsOpen) return;
            Console.WriteLine($"[NodeGraphEditor] Graph: {_graphName} ({ActiveGraphType})  " +
                              $"Nodes: {_overlays.Count}  Zoom: {ZoomLevel:F2}x");
        }

        public void OnShortcut(string s)
        {
            if (s == "Del")    DeleteSelected();
            if (s == "Ctrl+A") SelectAll();
            if (s == "F5")     ExecuteGraph();
        }

        // ── Runtime graph (NodeSystems) ───────────────────────
        private NodeGraph? _runtimeGraph;
        public NodeGraph? RuntimeGraph => _runtimeGraph;

        // ── Editor overlays ───────────────────────────────────
        private readonly Dictionary<string, EditorNodeOverlay> _overlays = new();
        private string _graphName = "Untitled";

        public NodeGraphType ActiveGraphType { get; private set; }
        public float ZoomLevel = 1f, PanX = 0f, PanY = 0f;
        public bool  ShowMinimap = true;

        // ── Graph management ──────────────────────────────────
        public void OpenGraph(string name, NodeGraphType type)
        {
            _graphName = name;
            ActiveGraphType = type;
            _runtimeGraph = new NodeGraph { Name = name };
            _overlays.Clear();
            Console.WriteLine($"[NodeGraphEditor] Opened {type} graph: {name}");
        }

        /// <summary>Add a runtime BaseNode and create an editor overlay for it.</summary>
        public string AddNode(BaseNode runtimeNode, float x = 0f, float y = 0f)
        {
            if (_runtimeGraph == null) throw new InvalidOperationException("Open a graph first.");
            _runtimeGraph.AddNode(runtimeNode);
            _overlays[runtimeNode.Id] = new EditorNodeOverlay(runtimeNode.Id, x, y);
            Console.WriteLine($"[NodeGraphEditor] Added node: {runtimeNode.Title} ({runtimeNode.Id})");
            return runtimeNode.Id;
        }

        /// <summary>Connect two ports through the runtime graph and record the connection.</summary>
        public void ConnectNodes(string fromNodeId, string fromPortId, string toNodeId, string toPortId)
        {
            if (_runtimeGraph == null) return;
            var fromNode = _runtimeGraph.Nodes.FirstOrDefault(n => n.Id == fromNodeId);
            var toNode   = _runtimeGraph.Nodes.FirstOrDefault(n => n.Id == toNodeId);
            if (fromNode == null || toNode == null) { Console.WriteLine("[NodeGraphEditor] Node not found."); return; }
            var fromPort = fromNode.Outputs.FirstOrDefault(p => p.Id == fromPortId);
            var toPort   = toNode.Inputs.FirstOrDefault(p => p.Id == toPortId);
            if (fromPort == null || toPort == null) { Console.WriteLine("[NodeGraphEditor] Port not found."); return; }
            bool ok = _runtimeGraph.Connect(fromPort, toPort);
            if (ok) Console.WriteLine($"[NodeGraphEditor] Connected {fromNodeId}.{fromPortId} → {toNodeId}.{toPortId}");
            else    Console.WriteLine($"[NodeGraphEditor] Connection rejected (type mismatch or invalid flow).");
        }

        public void RemoveNode(string nodeId)
        {
            _runtimeGraph?.RemoveNode(nodeId);
            _overlays.Remove(nodeId);
        }

        public void MoveNode(string nodeId, float x, float y)
        {
            if (_overlays.TryGetValue(nodeId, out var ov)) { ov.X = x; ov.Y = y; }
        }

        // ── Execution ─────────────────────────────────────────
        public void ExecuteGraph()
        {
            if (_runtimeGraph == null) { Console.WriteLine("[NodeGraphEditor] No graph loaded."); return; }
            _runtimeGraph.Evaluate();
            Console.WriteLine($"[NodeGraphEditor] Executed graph: {_graphName}");
        }

        // ── Selection ─────────────────────────────────────────
        public void SelectAll()   { foreach (var ov in _overlays.Values) ov.IsSelected = true; }
        public void ClearSelect() { foreach (var ov in _overlays.Values) ov.IsSelected = false; }
        public void DeleteSelected()
        {
            var toDelete = new List<string>();
            foreach (var (id, ov) in _overlays) if (ov.IsSelected) toDelete.Add(id);
            foreach (var id in toDelete) RemoveNode(id);
        }

        // ── Serialisation ─────────────────────────────────────
        public void SaveGraph(string path)  => Console.WriteLine($"[NodeGraphEditor] Saved: {path}");
        public void LoadGraph(string path)  => Console.WriteLine($"[NodeGraphEditor] Loaded: {path}");
    }
}
