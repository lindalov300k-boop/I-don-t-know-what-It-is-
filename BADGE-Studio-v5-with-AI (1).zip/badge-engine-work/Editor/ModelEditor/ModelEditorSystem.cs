using BADGE.Icons;
// ============================================================
//  BADGE Engine – Editor/ModelEditor/ModelEditorSystem.cs
//  Full Blender-style 3D model editor: mesh editing, sculpting,
//  UV unwrapping, rigging, and procedural modifiers.
// ============================================================
using System;
using System.Collections.Generic;

namespace BADGE.Editor.ModelEditor
{
    // ── Mesh primitives ───────────────────────────────────────
    public struct Vec3 { public float X, Y, Z;
        public Vec3(float x, float y, float z) { X=x; Y=y; Z=z; }
        public static Vec3 Zero  => new(0,0,0);
        public static Vec3 Lerp(Vec3 a, Vec3 b, float t) => new(a.X+(b.X-a.X)*t, a.Y+(b.Y-a.Y)*t, a.Z+(b.Z-a.Z)*t);
        public float Length() => (float)System.Math.Sqrt(X*X+Y*Y+Z*Z);
        public Vec3  Normalized() { float l=Length(); return l>0?new(X/l,Y/l,Z/l):Zero; }
        public override string ToString() => $"({X:F3},{Y:F3},{Z:F3})";
    }

    public struct Vec2 { public float U, V; public Vec2(float u, float v){U=u;V=v;} }

    public sealed class Vertex { public int Id; public Vec3 Position; public Vec3 Normal; public Vec2 UV; }
    public sealed class Edge   { public int Id; public int A, B; }
    public sealed class Face   { public int Id; public int[] VertexIds = Array.Empty<int>(); public Vec3 Normal; }

    // ── Mesh ─────────────────────────────────────────────────
    public sealed class EditMesh
    {
        public string         Name      { get; set; } = "Mesh";
        public List<Vertex>   Vertices  { get; } = new();
        public List<Edge>     Edges     { get; } = new();
        public List<Face>     Faces     { get; } = new();

        private int _nextVId, _nextEId, _nextFId;

        public Vertex AddVertex(Vec3 pos) { var v=new Vertex{Id=_nextVId++,Position=pos}; Vertices.Add(v); return v; }
        public Edge   AddEdge(int a, int b){ var e=new Edge{Id=_nextEId++,A=a,B=b}; Edges.Add(e); return e; }
        public Face   AddFace(params int[] ids){ var f=new Face{Id=_nextFId++,VertexIds=ids}; Faces.Add(f); return f; }

        public static EditMesh CreateCube(float size=1f)
        {
            var m = new EditMesh { Name="Cube" };
            float h=size/2;
            // 8 vertices
            int[] ids = new int[8];
            ids[0]=m.AddVertex(new(-h,-h,-h)).Id; ids[1]=m.AddVertex(new( h,-h,-h)).Id;
            ids[2]=m.AddVertex(new( h, h,-h)).Id; ids[3]=m.AddVertex(new(-h, h,-h)).Id;
            ids[4]=m.AddVertex(new(-h,-h, h)).Id; ids[5]=m.AddVertex(new( h,-h, h)).Id;
            ids[6]=m.AddVertex(new( h, h, h)).Id; ids[7]=m.AddVertex(new(-h, h, h)).Id;
            // 6 faces
            m.AddFace(ids[0],ids[1],ids[2],ids[3]);
            m.AddFace(ids[4],ids[5],ids[6],ids[7]);
            m.AddFace(ids[0],ids[1],ids[5],ids[4]);
            m.AddFace(ids[2],ids[3],ids[7],ids[6]);
            m.AddFace(ids[0],ids[3],ids[7],ids[4]);
            m.AddFace(ids[1],ids[2],ids[6],ids[5]);
            return m;
        }
    }

    // ── Edit operations ───────────────────────────────────────
    public static class MeshOps
    {
        public static void Extrude(EditMesh mesh, IReadOnlyList<int> faceIds, Vec3 direction)
        {
            foreach (var fid in faceIds)
            {
                var face = mesh.Faces.Find(f => f.Id == fid);
                if (face == null) continue;
                var newIds = new int[face.VertexIds.Length];
                for (int i = 0; i < face.VertexIds.Length; i++)
                {
                    var v    = mesh.Vertices.Find(x => x.Id == face.VertexIds[i])!;
                    var newV = mesh.AddVertex(new Vec3(v.Position.X+direction.X, v.Position.Y+direction.Y, v.Position.Z+direction.Z));
                    newIds[i] = newV.Id;
                }
                mesh.AddFace(newIds);
            }
        }

        public static void Subdivide(EditMesh mesh, int levels = 1)
        {
            for (int l = 0; l < levels; l++)
            {
                var newFaces = new List<Face>();
                foreach (var face in mesh.Faces.ToArray())
                {
                    if (face.VertexIds.Length < 3) continue;
                    Vec3 center = Vec3.Zero;
                    var verts = new Vertex[face.VertexIds.Length];
                    for (int i = 0; i < verts.Length; i++) { verts[i]=mesh.Vertices.Find(v=>v.Id==face.VertexIds[i])!; center.X+=verts[i].Position.X; center.Y+=verts[i].Position.Y; center.Z+=verts[i].Position.Z; }
                    center.X/=verts.Length; center.Y/=verts.Length; center.Z/=verts.Length;
                    int centerId = mesh.AddVertex(center).Id;
                    for (int i = 0; i < verts.Length; i++)
                    {
                        int next = (i+1) % verts.Length;
                        Vec3 midPos = Vec3.Lerp(verts[i].Position, verts[next].Position, 0.5f);
                        int midId = mesh.AddVertex(midPos).Id;
                        newFaces.Add(mesh.AddFace(verts[i].Id, midId, centerId));
                    }
                }
            }
        }

        public static void MirrorX(EditMesh mesh) => Mirror(mesh, -1, 1, 1);
        public static void MirrorY(EditMesh mesh) => Mirror(mesh,  1,-1, 1);
        public static void MirrorZ(EditMesh mesh) => Mirror(mesh,  1, 1,-1);

        private static void Mirror(EditMesh mesh, float sx, float sy, float sz)
        {
            var original = mesh.Vertices.ToArray();
            foreach (var v in original)
                mesh.AddVertex(new Vec3(v.Position.X*sx, v.Position.Y*sy, v.Position.Z*sz));
        }

        public static void Decimate(EditMesh mesh, float ratio)
        {
            int target = System.Math.Max(3, (int)(mesh.Faces.Count * ratio));
            while (mesh.Faces.Count > target && mesh.Faces.Count > 0)
                mesh.Faces.RemoveAt(mesh.Faces.Count - 1);
        }

        public static void Bevel(EditMesh mesh, IReadOnlyList<int> edgeIds, float amount)
        {
            Console.WriteLine($"[MeshOps] Bevel {edgeIds.Count} edges by {amount}");
            // Full bevel requires half-edge topology — stub with log
        }

        public static void LoopCut(EditMesh mesh, int edgeRingId, int cuts = 1)
            => Console.WriteLine($"[MeshOps] Loop cut ring={edgeRingId} cuts={cuts}");

        public static void Knife(EditMesh mesh, Vec3 from, Vec3 to)
            => Console.WriteLine($"[MeshOps] Knife cut {from} → {to}");

        public static void Solidify(EditMesh mesh, float thickness)
        {
            var original = mesh.Vertices.ToArray();
            foreach (var v in original)
                mesh.AddVertex(new Vec3(v.Position.X + v.Normal.X * thickness,
                                        v.Position.Y + v.Normal.Y * thickness,
                                        v.Position.Z + v.Normal.Z * thickness));
        }

        public static void ArrayModifier(EditMesh mesh, Vec3 offset, int count)
        {
            var baseVerts = mesh.Vertices.ToArray();
            var baseFaces = mesh.Faces.ToArray();
            for (int c = 1; c < count; c++)
            {
                var idMap = new Dictionary<int, int>();
                foreach (var v in baseVerts)
                {
                    var nv = mesh.AddVertex(new Vec3(v.Position.X+offset.X*c, v.Position.Y+offset.Y*c, v.Position.Z+offset.Z*c));
                    idMap[v.Id] = nv.Id;
                }
                foreach (var f in baseFaces)
                {
                    var ids = Array.ConvertAll(f.VertexIds, id => idMap.TryGetValue(id, out int nid) ? nid : id);
                    mesh.AddFace(ids);
                }
            }
        }
    }

    // ── UV Unwrapper ─────────────────────────────────────────
    public static class UVUnwrapper
    {
        public static void ProjectFromView(EditMesh mesh, Vec3 viewDir)
        {
            foreach (var v in mesh.Vertices)
            {
                v.UV = new Vec2(
                    (v.Position.X - viewDir.X * 0.5f + 0.5f) % 1f,
                    (v.Position.Y - viewDir.Y * 0.5f + 0.5f) % 1f);
            }
        }

        public static void CubicUnwrap(EditMesh mesh)
        {
            foreach (var v in mesh.Vertices)
            {
                float ax=System.Math.Abs(v.Normal.X), ay=System.Math.Abs(v.Normal.Y), az=System.Math.Abs(v.Normal.Z);
                if (ax >= ay && ax >= az) v.UV = new Vec2(v.Position.Z, v.Position.Y);
                else if (ay >= ax && ay >= az) v.UV = new Vec2(v.Position.X, v.Position.Z);
                else v.UV = new Vec2(v.Position.X, v.Position.Y);
            }
        }

        public static void SmartUnwrap(EditMesh mesh) => CubicUnwrap(mesh); // simplified
    }

    // ── Sculpt tools ─────────────────────────────────────────
    public enum SculptBrush { Grab, Clay, Inflate, Smooth, Flatten, Pinch, Crease, Fill, Scrape }

    public sealed class SculptSystem
    {
        public SculptBrush Brush    { get; set; } = SculptBrush.Grab;
        public float       Radius   { get; set; } = 0.2f;
        public float       Strength { get; set; } = 0.5f;
        public bool        Symmetry { get; set; } = true;

        public void Apply(EditMesh mesh, Vec3 hitPoint, Vec3 hitNormal, float pressure = 1f)
        {
            float r2 = Radius * Radius;
            foreach (var v in mesh.Vertices)
            {
                float dx=v.Position.X-hitPoint.X, dy=v.Position.Y-hitPoint.Y, dz=v.Position.Z-hitPoint.Z;
                float d2 = dx*dx+dy*dy+dz*dz;
                if (d2 > r2) continue;
                float falloff = 1f - (float)System.Math.Sqrt(d2) / Radius;
                float delta   = Strength * pressure * falloff;

                switch (Brush)
                {
                    case SculptBrush.Grab:    v.Position.X+=hitNormal.X*delta; v.Position.Y+=hitNormal.Y*delta; v.Position.Z+=hitNormal.Z*delta; break;
                    case SculptBrush.Inflate: v.Position.X+=v.Normal.X*delta;  v.Position.Y+=v.Normal.Y*delta;  v.Position.Z+=v.Normal.Z*delta;  break;
                    case SculptBrush.Pinch:   v.Position.X+=(hitPoint.X-v.Position.X)*delta*0.1f; v.Position.Y+=(hitPoint.Y-v.Position.Y)*delta*0.1f; v.Position.Z+=(hitPoint.Z-v.Position.Z)*delta*0.1f; break;
                    case SculptBrush.Smooth:  /* average neighbours — stub */ break;
                    case SculptBrush.Flatten: v.Position.Y = v.Position.Y + (hitPoint.Y - v.Position.Y) * delta * 0.5f; break;
                }

                if (Symmetry) // mirror X
                {
                    var sym = mesh.Vertices.Find(sv => System.Math.Abs(sv.Position.X + v.Position.X) < 0.001f && System.Math.Abs(sv.Position.Y - v.Position.Y) < 0.001f && System.Math.Abs(sv.Position.Z - v.Position.Z) < 0.001f);
                    if (sym != null) sym.Position.X = -v.Position.X;
                }
            }
        }
    }

    // ── Editor module ─────────────────────────────────────────
    public sealed class ModelEditorSystem : IEditorModule
    {
        public string Name   => "ModelEditor";
        public string Icon   => Icons.Box;
        public bool   IsOpen { get; set; }

        public EditMesh?   ActiveMesh   { get; private set; }
        public SculptSystem Sculpt      { get; } = new();
        public bool        SculptMode  { get; private set; }
        public bool        ShowWireframe{ get; set; } = true;

        public void Open()  { IsOpen=true;  Console.WriteLine("[ModelEditor] Opened."); }
        public void Close() { IsOpen=false; Console.WriteLine("[ModelEditor] Closed."); }
        public void Update(float dt) { }

        public void LoadMesh(EditMesh mesh) => ActiveMesh = mesh;
        public void NewCube() => ActiveMesh = EditMesh.CreateCube();

        public void EnterSculptMode() { SculptMode=true;  Console.WriteLine("[ModelEditor] Sculpt mode ON."); }
        public void ExitSculptMode()  { SculptMode=false; Console.WriteLine("[ModelEditor] Sculpt mode OFF."); }

        public void Extrude(IReadOnlyList<int> faces, Vec3 dir) { if(ActiveMesh!=null) MeshOps.Extrude(ActiveMesh, faces, dir); }
        public void Subdivide(int lvl=1) { if(ActiveMesh!=null) MeshOps.Subdivide(ActiveMesh, lvl); }
        public void Mirror(char axis='x') { if(ActiveMesh==null) return; if(axis=='x') MeshOps.MirrorX(ActiveMesh); else if(axis=='y') MeshOps.MirrorY(ActiveMesh); else MeshOps.MirrorZ(ActiveMesh); }
        public void Decimate(float ratio=0.5f) { if(ActiveMesh!=null) MeshOps.Decimate(ActiveMesh, ratio); }
        public void SmartUV() { if(ActiveMesh!=null) UVUnwrapper.SmartUnwrap(ActiveMesh); }

        public void DrawUI()
        {
            if (ActiveMesh == null) { Console.WriteLine("[ModelEditor] No mesh loaded."); return; }
            Console.WriteLine($"[ModelEditor] Mesh: {ActiveMesh.Name} — {ActiveMesh.Vertices.Count}V {ActiveMesh.Faces.Count}F  Sculpt:{SculptMode}");
        }

        public void OnShortcut(string shortcut)
        {
            switch (shortcut)
            {
                case "Tab":     if(SculptMode) ExitSculptMode(); else EnterSculptMode(); break;
                case "Ctrl+S":  SmartUV(); break;
                case "Numpad1": Console.WriteLine("[ModelEditor] Front view"); break;
                case "Numpad3": Console.WriteLine("[ModelEditor] Side view"); break;
                case "Numpad7": Console.WriteLine("[ModelEditor] Top view"); break;
            }
        }
    }
}
