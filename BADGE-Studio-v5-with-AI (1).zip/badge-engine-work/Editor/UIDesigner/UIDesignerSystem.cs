using BADGE.Icons;
// ============================================================
//  BADGE Engine – Editor/UIDesigner/UIDesignerSystem.cs
//  UILayoutEditor, WidgetSystem, UIRenderer, FontSystem
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using BADGE.Editor;

namespace BADGE.Engine.Editor.UIDesigner
{
    public enum WidgetType
    {
        Panel, Button, Label, Text, TMPText, TextInput, InputField, Image,
        Slider, Checkbox, Dropdown, ScrollView, ProgressBar, Toggle,
        RadioGroup, TabView, Modal, Tooltip, Navbar, Sidebar, Grid,
        Canvas, Video, Icon, Divider, Spacer
    }

    public enum Anchor { TopLeft, TopCenter, TopRight, MiddleLeft, Center,
                         MiddleRight, BottomLeft, BottomCenter, BottomRight, Stretch }

    public sealed class UIWidget
    {
        public string     ID        { get; } = Guid.NewGuid().ToString("N")[..8];
        public WidgetType Type      { get; set; }
        public string     Name      { get; set; } = "Widget";
        public string     Text      { get; set; } = "";
        public float      X         { get; set; }
        public float      Y         { get; set; }
        public float      Width     { get; set; } = 100f;
        public float      Height    { get; set; } = 30f;
        public Anchor     Anchor    { get; set; } = Anchor.TopLeft;
        public bool       Visible   { get; set; } = true;
        public bool       Enabled   { get; set; } = true;
        public bool       Selected  { get; set; }
        public float      Opacity   { get; set; } = 1f;
        public float      Rotation  { get; set; }
        public (float R,float G,float B,float A) BackgroundColor { get; set; } = (1,1,1,1);
        public (float R,float G,float B,float A) ForegroundColor { get; set; } = (0,0,0,1);
        public (float R,float G,float B,float A) BorderColor     { get; set; } = (0.5f,0.5f,0.5f,1);
        public float      BorderWidth  { get; set; }
        public float      CornerRadius { get; set; }
        public string     FontName     { get; set; } = "Default";
        public float      FontSize     { get; set; } = 14f;
        public bool       Bold         { get; set; }
        public bool       Italic       { get; set; }
        public string?    ImagePath    { get; set; }
        public string?    Tooltip      { get; set; }
        public string?    OnClick      { get; set; }   // event binding
        public string?    DataBinding  { get; set; }   // property path
        public Dictionary<string,string> Styles { get; } = new();
        public List<UIWidget> Children { get; } = new();
        public UIWidget? Parent { get; set; }

        public void AddChild(UIWidget w) { w.Parent=this; Children.Add(w); }
        public void RemoveChild(UIWidget w) { Children.Remove(w); w.Parent=null; }

        public (float AX, float AY, float AW, float AH) GetAbsoluteRect()
        {
            float px=0,py=0,pw=0,ph=0;
            if(Parent!=null){var pr=Parent.GetAbsoluteRect();px=pr.AX;py=pr.AY;pw=pr.AW;ph=pr.AH;}
            return Anchor switch
            {
                Anchor.TopLeft     => (px+X,   py+Y,   Width, Height),
                Anchor.TopCenter   => (px+pw/2-Width/2+X, py+Y, Width, Height),
                Anchor.TopRight    => (px+pw-Width+X, py+Y, Width, Height),
                Anchor.Center      => (px+pw/2-Width/2+X, py+ph/2-Height/2+Y, Width, Height),
                Anchor.Stretch     => (px, py, pw, ph),
                _                  => (px+X, py+Y, Width, Height)
            };
        }

        public UIWidget? HitTest(float sx, float sy)
        {
            if(!Visible) return null;
            var (ax,ay,aw,ah)=GetAbsoluteRect();
            if(sx<ax||sx>ax+aw||sy<ay||sy>ay+ah) return null;
            foreach(var c in Children)
            {
                var hit=c.HitTest(sx,sy);
                if(hit!=null) return hit;
            }
            return this;
        }
    }

    public sealed class WidgetFactory
    {
        public static UIWidget Panel(float x,float y,float w,float h,string name="Panel")=>new(){Type=WidgetType.Panel,Name=name,X=x,Y=y,Width=w,Height=h};
        public static UIWidget Button(float x,float y,float w,float h,string text="Button")=>new(){Type=WidgetType.Button,Text=text,X=x,Y=y,Width=w,Height=h,Name="Button"};
        public static UIWidget Label(float x,float y,string text,float fontSize=14)=>new(){Type=WidgetType.Label,Text=text,X=x,Y=y,Width=200,Height=24,FontSize=fontSize,Name="Label"};
        public static UIWidget Text(float x,float y,string text,float fontSize=14)=>new(){Type=WidgetType.Text,Text=text,X=x,Y=y,Width=200,Height=24,FontSize=fontSize,Name="Text"};
        public static UIWidget TMPText(float x,float y,string text,float fontSize=14,bool richText=true)=>new(){Type=WidgetType.TMPText,Text=richText?$"<size={fontSize}>{text}</size>":text,X=x,Y=y,Width=200,Height=24,FontSize=fontSize,Name="TMPText"};
        public static UIWidget TextInput(float x,float y,float w,float h,string placeholder="")=>new(){Type=WidgetType.TextInput,Text=placeholder,X=x,Y=y,Width=w,Height=h,Name="Input"};
        public static UIWidget InputField(float x,float y,float w,float h,string placeholder="")=>new(){Type=WidgetType.InputField,Text=placeholder,X=x,Y=y,Width=w,Height=h,Name="InputField"};
        public static UIWidget Slider(float x,float y,float w=200)=>new(){Type=WidgetType.Slider,X=x,Y=y,Width=w,Height=20,Name="Slider"};
        public static UIWidget Checkbox(float x,float y,string label)=>new(){Type=WidgetType.Checkbox,Text=label,X=x,Y=y,Width=150,Height=20,Name="Checkbox"};
        public static UIWidget Image(float x,float y,float w,float h,string path="")=>new(){Type=WidgetType.Image,ImagePath=path,X=x,Y=y,Width=w,Height=h,Name="Image"};
        public static UIWidget ProgressBar(float x,float y,float w=200)=>new(){Type=WidgetType.ProgressBar,X=x,Y=y,Width=w,Height=16,Name="ProgressBar"};
        public static UIWidget Dropdown(float x,float y,float w=180)=>new(){Type=WidgetType.Dropdown,X=x,Y=y,Width=w,Height=30,Name="Dropdown"};
        public static UIWidget ScrollView(float x,float y,float w,float h)=>new(){Type=WidgetType.ScrollView,X=x,Y=y,Width=w,Height=h,Name="ScrollView"};
        public static UIWidget TabView(float x,float y,float w,float h)=>new(){Type=WidgetType.TabView,X=x,Y=y,Width=w,Height=h,Name="TabView"};
        public static UIWidget Modal(float w=400,float h=300,string title="Dialog")=>new(){Type=WidgetType.Modal,Text=title,Width=w,Height=h,Anchor=Anchor.Center,Name="Modal"};
    }

    public sealed class UIScreen
    {
        public string      Name     { get; set; } = "Screen";
        public List<UIWidget> Widgets { get; } = new();
        public float       Width    { get; set; } = 1920f;
        public float       Height   { get; set; } = 1080f;
        public (float,float,float,float) Background { get; set; } = (0.1f,0.1f,0.1f,1f);
        public bool        Visible  { get; set; } = true;

        public void Add(UIWidget w) => Widgets.Add(w);
        public void Remove(UIWidget w) => Widgets.Remove(w);

        public UIWidget? HitTest(float x, float y) =>
            Widgets.AsEnumerable().Reverse().Select(w=>w.HitTest(x,y)).FirstOrDefault(h=>h!=null);

        public IEnumerable<UIWidget> All => Widgets.SelectMany(AllDescendants);
        private static IEnumerable<UIWidget> AllDescendants(UIWidget w)
        { yield return w; foreach(var c in w.Children) foreach(var d in AllDescendants(c)) yield return d; }

        public UIWidget? FindById(string id) => All.FirstOrDefault(w=>w.ID==id);
        public UIWidget? FindByName(string name) => All.FirstOrDefault(w=>w.Name==name);
    }

    public sealed class UILayoutEditor : IEditorModule
    {
        public string Name    => "UIDesigner";
        public string Icon    => Icons.Ruler;
        public bool   IsOpen  { get; private set; }
        public void   Open()  => IsOpen = true;
        public void   Close() => IsOpen = false;
        public void   Update(float dt) {}
        public void   DrawUI() {}
        public void   OnShortcut(string shortcut)
        {
            if (shortcut == "Ctrl+Z") Undo();
            else if (shortcut == "Ctrl+Y") Redo();
        }

        public UIScreen?    ActiveScreen { get; private set; }
        public UIWidget?    Selected     { get; private set; }
        public List<UIScreen> Screens   { get; } = new();
        public float         Zoom       { get; set; } = 1f;
        public bool          ShowGrid   { get; set; } = true;
        public int           GridSize   { get; set; } = 8;
        public bool          SnapToGrid { get; set; } = true;

        private readonly Stack<UIScreen> _undoStack = new();

        public UIScreen NewScreen(string name="Screen",float w=1920,float h=1080)
        {
            var s=new UIScreen{Name=name,Width=w,Height=h};
            Screens.Add(s); ActiveScreen=s; return s;
        }

        public void SetActiveScreen(UIScreen s) { ActiveScreen=s; Selected=null; }

        public void Select(UIWidget? w) { if(Selected!=null) Selected.Selected=false; Selected=w; if(w!=null) w.Selected=true; }

        public void AddWidget(UIWidget w) { ActiveScreen?.Add(w); Select(w); }
        public void DeleteSelected()      { if(Selected==null||ActiveScreen==null) return; ActiveScreen.Remove(Selected); Selected=null; }

        public void MoveSelected(float dx, float dy)
        {
            if(Selected==null) return;
            Selected.X+=SnapToGrid?MathF.Round(dx/GridSize)*GridSize:dx;
            Selected.Y+=SnapToGrid?MathF.Round(dy/GridSize)*GridSize:dy;
        }

        public void ResizeSelected(float dw, float dh)
        {
            if(Selected==null) return;
            Selected.Width=System.Math.Max(4,Selected.Width+dw);
            Selected.Height=System.Math.Max(4,Selected.Height+dh);
        }

        public void DuplicateSelected()
        {
            if(Selected==null||ActiveScreen==null) return;
            // Shallow clone
            var clone=new UIWidget{Type=Selected.Type,Name=Selected.Name+" Copy",
                Text=Selected.Text,Width=Selected.Width,Height=Selected.Height,
                X=Selected.X+10,Y=Selected.Y+10,FontSize=Selected.FontSize};
            AddWidget(clone);
        }

        public void AlignLeft()    { if(Selected==null||ActiveScreen==null) return; Selected.X=0; }
        public void AlignCenter()  { if(Selected==null||ActiveScreen==null) return; Selected.X=(ActiveScreen.Width-Selected.Width)/2; }
        public void AlignRight()   { if(Selected==null||ActiveScreen==null) return; Selected.X=ActiveScreen.Width-Selected.Width; }
        public void AlignTop()     { if(Selected==null||ActiveScreen==null) return; Selected.Y=0; }
        public void AlignMiddle()  { if(Selected==null||ActiveScreen==null) return; Selected.Y=(ActiveScreen.Height-Selected.Height)/2; }
        public void AlignBottom()  { if(Selected==null||ActiveScreen==null) return; Selected.Y=ActiveScreen.Height-Selected.Height; }

        // Export screen to XML/JSON for runtime
        public string ExportXML()
        {
            if(ActiveScreen==null) return "<Screen/>";
            var sb=new System.Text.StringBuilder();
            sb.AppendLine($"<Screen name=\"{ActiveScreen.Name}\" width=\"{ActiveScreen.Width}\" height=\"{ActiveScreen.Height}\">");
            foreach(var w in ActiveScreen.Widgets) WriteWidget(sb,w,1);
            sb.AppendLine("</Screen>");
            return sb.ToString();
        }

        private static void WriteWidget(System.Text.StringBuilder sb, UIWidget w, int depth)
        {
            string indent=new string(' ',depth*2);
            sb.AppendLine($"{indent}<{w.Type} name=\"{w.Name}\" x=\"{w.X}\" y=\"{w.Y}\" w=\"{w.Width}\" h=\"{w.Height}\" text=\"{w.Text}\">");
            foreach(var c in w.Children) WriteWidget(sb,c,depth+1);
            sb.AppendLine($"{indent}</{w.Type}>");
        }
    }

    public sealed class FontSystem
    {
        private readonly Dictionary<string,FontInfo> _fonts = new();
        public IReadOnlyDictionary<string,FontInfo> Fonts => _fonts;

        public FontSystem()
        {
            // Register default fonts
            Register("Default",    new FontInfo("Default","sans-serif",false,false));
            Register("Monospace",  new FontInfo("Monospace","monospace",false,false));
            Register("Serif",      new FontInfo("Serif","serif",false,false));
            Register("Bold",       new FontInfo("Bold","sans-serif",true,false));
            Register("Italic",     new FontInfo("Italic","sans-serif",false,true));
        }

        public void Register(string name, FontInfo info) => _fonts[name]=info;
        public FontInfo? Get(string name) => _fonts.TryGetValue(name,out var f)?f:null;

        public float MeasureWidth(string text, string font, float size)
        {
            // Rough approximation: each char ~0.6 * size
            var info=Get(font);
            float charW=(info?.Bold??false)?size*0.65f:size*0.58f;
            return text.Length*charW;
        }

        public float MeasureHeight(string font, float size) => size*1.2f;
    }

    public sealed class FontInfo
    {
        public string  Name       { get; }
        public string  FamilyName { get; }
        public bool    Bold       { get; }
        public bool    Italic     { get; }
        public string? FilePath   { get; set; }
        public int     GPUHandle  { get; set; }

        public FontInfo(string name,string family,bool bold,bool italic)
        { Name=name; FamilyName=family; Bold=bold; Italic=italic; }
    }

    // ─── Widget System ────────────────────────────────────────
    /// <summary>
    /// Central registry and lifecycle manager for all runtime UI widgets.
    /// </summary>
    public sealed class WidgetSystem
    {
        private readonly Dictionary<string, UIWidget>  _widgetsById   = new();
        private readonly Dictionary<string, UIWidget>  _widgetsByName = new();
        private readonly List<UIWidget>                _updateQueue   = new();

        public IReadOnlyDictionary<string, UIWidget> WidgetsById   => _widgetsById;

        public void Register(UIWidget w)
        {
            _widgetsById[w.ID]     = w;
            _widgetsByName[w.Name] = w;
        }

        public void RegisterScreen(UIScreen screen)
        {
            foreach (var w in screen.All) Register(w);
        }

        public void Unregister(UIWidget w)
        {
            _widgetsById.Remove(w.ID);
            _widgetsByName.Remove(w.Name);
        }

        public UIWidget? GetByID  (string id)   => _widgetsById.TryGetValue(id, out var w)   ? w : null;
        public UIWidget? GetByName(string name) => _widgetsByName.TryGetValue(name, out var w) ? w : null;

        public void SetVisible(string widgetName, bool visible)
        {
            if (GetByName(widgetName) is { } w) w.Visible = visible;
        }

        public void SetText(string widgetName, string text)
        {
            if (GetByName(widgetName) is { } w) w.Text = text;
        }

        public void SetEnabled(string widgetName, bool enabled)
        {
            if (GetByName(widgetName) is { } w) w.Enabled = enabled;
        }

        public void BindData(string widgetName, object dataSource, string propertyPath)
        {
            if (GetByName(widgetName) is { } w) w.DataBinding = propertyPath;
            // In a full runtime, this would subscribe to INotifyPropertyChanged
        }

        public List<UIWidget> GetWidgetsOfType(WidgetType type) =>
            _widgetsById.Values.Where(w => w.Type == type).ToList();
    }

    // ─── UI Renderer ─────────────────────────────────────────
    public interface IUIRenderBackend
    {
        void DrawRect  (float x, float y, float w, float h, float r, float g, float b, float a);
        void DrawBorder(float x, float y, float w, float h, float bw, float r, float g, float b, float a, float cornerRadius);
        void DrawText  (string text, float x, float y, float size, bool bold, bool italic, float r, float g, float b, float a);
        void DrawImage (string path, float x, float y, float w, float h, float alpha);
        void PushClip  (float x, float y, float w, float h);
        void PopClip   ();
    }

    /// <summary>Traverses a UIScreen and issues draw calls to the backend.</summary>
    public sealed class UIRenderer
    {
        private readonly IUIRenderBackend _backend;
        public TMPTextRenderer TMP { get; } = new();

        public UIRenderer(IUIRenderBackend backend) { _backend = backend; }

        public void Render(UIScreen screen)
        {
            if (!screen.Visible) return;
            var (br,bg,bb,ba) = screen.Background;
            _backend.DrawRect(0, 0, screen.Width, screen.Height, br, bg, bb, ba);
            foreach (var widget in screen.Widgets)
                RenderWidget(widget);
        }

        private void RenderWidget(UIWidget w)
        {
            if (!w.Visible) return;
            var (ax, ay, aw, ah) = w.GetAbsoluteRect();
            var (bgR,bgG,bgB,bgA) = w.BackgroundColor;
            var (fgR,fgG,fgB,fgA) = w.ForegroundColor;
            var (bdR,bdG,bdB,bdA) = w.BorderColor;

            bgA *= w.Opacity;

            switch (w.Type)
            {
                case WidgetType.Panel:
                    _backend.DrawRect  (ax, ay, aw, ah, bgR,bgG,bgB,bgA);
                    if (w.BorderWidth > 0)
                        _backend.DrawBorder(ax,ay,aw,ah,w.BorderWidth,bdR,bdG,bdB,bdA,w.CornerRadius);
                    break;

                case WidgetType.Button:
                    _backend.DrawRect(ax, ay, aw, ah, bgR,bgG,bgB, w.Enabled ? bgA : bgA*0.5f);
                    _backend.DrawBorder(ax,ay,aw,ah,1,bdR,bdG,bdB,bdA,w.CornerRadius);
                    _backend.DrawText(w.Text, ax+aw/2-w.FontSize*w.Text.Length*0.3f, ay+(ah-w.FontSize)/2,
                        w.FontSize, w.Bold, w.Italic, fgR,fgG,fgB,fgA);
                    break;

                case WidgetType.Label:
                case WidgetType.Text:
                    _backend.DrawText(w.Text, ax, ay, w.FontSize, w.Bold, w.Italic, fgR,fgG,fgB,fgA);
                    break;

                case WidgetType.TMPText:
                    TMP.Render(w, ax, ay, _backend);
                    break;

                case WidgetType.TextInput:
                case WidgetType.InputField:
                    _backend.DrawRect  (ax, ay, aw, ah, bgR,bgG,bgB,bgA);
                    _backend.DrawBorder(ax, ay, aw, ah, 1, bdR,bdG,bdB,bdA, w.CornerRadius);
                    _backend.DrawText  (w.Text, ax+4, ay+(ah-w.FontSize)/2,
                        w.FontSize, w.Bold, w.Italic, fgR,fgG,fgB, w.Text.Length>0 ? fgA : 0.4f);
                    break;

                case WidgetType.Image:
                    if (w.ImagePath != null)
                        _backend.DrawImage(w.ImagePath, ax, ay, aw, ah, w.Opacity);
                    break;

                case WidgetType.Slider:
                    _backend.DrawRect(ax, ay+ah/2-2, aw, 4, 0.4f,0.4f,0.4f,bgA);
                    _backend.DrawRect(ax, ay, 12, ah, fgR,fgG,fgB,fgA); // thumb
                    break;

                case WidgetType.Checkbox:
                    _backend.DrawRect  (ax, ay+2, 16, 16, bgR,bgG,bgB,bgA);
                    _backend.DrawBorder(ax, ay+2, 16, 16, 1, bdR,bdG,bdB,bdA, 2);
                    _backend.DrawText  (w.Text, ax+22, ay, w.FontSize, w.Bold, w.Italic, fgR,fgG,fgB,fgA);
                    break;

                case WidgetType.Dropdown:
                    _backend.DrawRect  (ax, ay, aw, ah, bgR,bgG,bgB,bgA);
                    _backend.DrawBorder(ax, ay, aw, ah, 1, bdR,bdG,bdB,bdA, w.CornerRadius);
                    _backend.DrawText  (w.Text, ax+6, ay+(ah-w.FontSize)/2, w.FontSize, false, false, fgR,fgG,fgB,fgA);
                    break;

                default:
                    _backend.DrawRect(ax, ay, aw, ah, bgR,bgG,bgB,bgA);
                    break;
            }

            // Clip children to parent bounds
            _backend.PushClip(ax, ay, aw, ah);
            foreach (var child in w.Children) RenderWidget(child);
            _backend.PopClip();
        }
    }

    // ─── TMP Text Renderer ────────────────────────────────────
    public sealed class RichTextSpan
    {
        public string Text     { get; set; } = "";
        public float  Size     { get; set; } = 14f;
        public bool   Bold     { get; set; }
        public bool   Italic   { get; set; }
        public bool   Underline{ get; set; }
        public (float R,float G,float B,float A) Color { get; set; } = (0,0,0,1);
    }

    public sealed class TMPFontAtlas
    {
        public string Name     { get; set; } = "";
        public int    Width    { get; set; } = 1024;
        public int    Height   { get; set; } = 1024;
        public int    GPUHandle{ get; set; }
        public Dictionary<char, (float u, float v, float uw, float vh, float advance)> Glyphs { get; } = new();

        public bool HasGlyph(char c) => Glyphs.ContainsKey(c);
        public bool SupportsUnicode => true;  // All registered glyphs support Unicode
    }

    /// <summary>
    /// TextMeshPro-equivalent renderer: parses rich-text tags, resolves font
    /// atlases, and issues draw calls supporting Unicode.
    /// </summary>
    public sealed class TMPTextRenderer
    {
        private readonly Dictionary<string, TMPFontAtlas> _atlases = new();

        public TMPFontAtlas RegisterAtlas(string name, int w = 1024, int h = 1024)
        {
            var a = new TMPFontAtlas { Name = name, Width = w, Height = h };
            _atlases[name] = a;
            return a;
        }

        public TMPFontAtlas? GetAtlas(string name) =>
            _atlases.TryGetValue(name, out var a) ? a : null;

        /// <summary>Parse rich-text tags into a list of styled spans.</summary>
        public List<RichTextSpan> ParseRichText(string input, float baseSize = 14f,
            (float,float,float,float) baseColor = default)
        {
            var spans   = new List<RichTextSpan>();
            var stack   = new Stack<(string tag, string value)>();
            float size  = baseSize;
            var color   = baseColor == default ? (0f,0f,0f,1f) : baseColor;
            bool bold = false, italic = false;
            int i = 0;

            while (i < input.Length)
            {
                if (input[i] == '<')
                {
                    int end = input.IndexOf('>', i);
                    if (end < 0) { i++; continue; }
                    string tag = input[(i+1)..end];
                    i = end + 1;

                    if (tag.StartsWith('/'))
                    {
                        // closing tag
                        string t = tag[1..].ToLower();
                        switch (t)
                        {
                            case "b": bold   = false; break;
                            case "i": italic = false; break;
                            case "size":  if (stack.TryPop(out var sp)) size  = float.TryParse(sp.value, out float sv) ? sv : baseSize; break;
                            case "color": if (stack.TryPop(out var cp)) color = ParseColor(cp.value); break;
                        }
                    }
                    else
                    {
                        // opening tag
                        if (tag.ToLower() == "b")      { bold   = true; }
                        else if (tag.ToLower() == "i") { italic = true; }
                        else if (tag.StartsWith("size=",  StringComparison.OrdinalIgnoreCase))
                        { float.TryParse(tag[5..], out float ns); stack.Push(("size", tag[5..])); size = ns; }
                        else if (tag.StartsWith("color=", StringComparison.OrdinalIgnoreCase))
                        { stack.Push(("color", tag[6..])); color = ParseColor(tag[6..]); }
                    }
                }
                else
                {
                    // Collect plain-text run
                    int start = i;
                    while (i < input.Length && input[i] != '<') i++;
                    spans.Add(new RichTextSpan
                    {
                        Text   = input[start..i],
                        Size   = size,
                        Bold   = bold,
                        Italic = italic,
                        Color  = color
                    });
                }
            }
            return spans;
        }

        public void Render(UIWidget w, float ax, float ay, IUIRenderBackend backend)
        {
            var spans = ParseRichText(w.Text, w.FontSize, w.ForegroundColor);
            float cx = ax;
            foreach (var span in spans)
            {
                var (r,g,b,a) = span.Color;
                backend.DrawText(span.Text, cx, ay, span.Size, span.Bold, span.Italic, r, g, b, a*w.Opacity);
                cx += span.Text.Length * span.Size * 0.6f;
            }
        }

        private static (float R, float G, float B, float A) ParseColor(string s)
        {
            s = s.Trim().TrimStart('#');
            if (s.Length >= 6)
            {
                float r = Convert.ToInt32(s[0..2], 16) / 255f;
                float g = Convert.ToInt32(s[2..4], 16) / 255f;
                float b = Convert.ToInt32(s[4..6], 16) / 255f;
                float a = s.Length >= 8 ? Convert.ToInt32(s[6..8], 16) / 255f : 1f;
                return (r, g, b, a);
            }
            return (0, 0, 0, 1);
        }
    }
}
