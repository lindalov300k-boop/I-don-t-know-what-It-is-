using BADGE.Icons;
// ============================================================
//  BADGE Engine – Editor/PhysicsDebugger/PhysicsDebuggerSystem.cs
//  Physics debugger: live body tracking via PhysicsWorld hooks,
//  per-layer visualisation — implements IEditorModule.
// ============================================================
using System;
using System.Collections.Generic;
using BADGE.Editor;
using BADGE.Engine.Components;
using BADGE.Engine.Core;
using BADGE.Engine.Physics;

namespace BADGE.Engine.Editor
{
    public enum PhysicsDebugLayer { Colliders, Triggers, Rigidbodies, Joints, RaycastLines, ForceVectors }

    public class PhysicsDebugEntry
    {
        public string ObjectId     = string.Empty;
        public string ColliderType = string.Empty;
        public bool   IsKinematic, IsTrigger, IsSleeping;
        public float  Mass;
        public float[] Velocity        = new float[3];
        public float[] AngularVelocity = new float[3];
    }

    public class PhysicsDebuggerSystem : IEditorModule
    {
        private static PhysicsDebuggerSystem? _instance;
        public  static PhysicsDebuggerSystem   Instance => _instance ??= new PhysicsDebuggerSystem();

        public string Name   => "Physics Debugger";
        public string Icon   => Icons.Settings;
        public bool   IsOpen { get; set; }

        public void Open()
        {
            IsOpen = true;
            HookIntoPhysicsWorld();
            Console.WriteLine("[PhysicsDebugger] Opened — listening to PhysicsWorld.");
        }

        public void Close()
        {
            IsOpen = false;
            UnhookFromPhysicsWorld();
            Console.WriteLine("[PhysicsDebugger] Closed.");
        }

        public void Update(float dt)
        {
            if (!IsOpen) return;
            // Sync live entries from PhysicsWorld registrations
            _liveEntries.Clear();
            foreach (var (id, entry) in _trackedBodies)
                _liveEntries.Add(entry);
        }

        public void DrawUI()
        {
            if (!IsOpen) return;
            Console.WriteLine($"[PhysicsDebugger] Bodies: {_liveEntries.Count}  Collisions this frame: {_collisionCount}");
            if (_activeLayers.Contains(PhysicsDebugLayer.Rigidbodies))
                foreach (var e in _liveEntries)
                    Console.WriteLine($"  [{e.ObjectId}] vel=({e.Velocity[0]:F2},{e.Velocity[1]:F2},{e.Velocity[2]:F2}) sleeping={e.IsSleeping}");
        }

        public void OnShortcut(string s)
        {
            if (s == "P") TogglePause();
        }

        // ── Layer control ─────────────────────────────────────
        private readonly HashSet<PhysicsDebugLayer> _activeLayers = new()
            { PhysicsDebugLayer.Colliders, PhysicsDebugLayer.Rigidbodies };

        public void EnableLayer(PhysicsDebugLayer l)  => _activeLayers.Add(l);
        public void DisableLayer(PhysicsDebugLayer l) => _activeLayers.Remove(l);
        public bool IsLayerActive(PhysicsDebugLayer l)=> _activeLayers.Contains(l);

        // ── State ─────────────────────────────────────────────
        private readonly Dictionary<string, PhysicsDebugEntry> _trackedBodies = new();
        private readonly List<PhysicsDebugEntry> _liveEntries = new();
        private int  _collisionCount;
        private bool _paused;

        // ── PhysicsWorld hooks ────────────────────────────────
        private bool _hooked;

        private void HookIntoPhysicsWorld()
        {
            if (_hooked) return;
            try
            {
                var world = EngineKernel.Instance.Physics;
                world.OnCollision += OnCollision;
                _hooked = true;
                Console.WriteLine("[PhysicsDebugger] Hooked into PhysicsWorld.OnCollision.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[PhysicsDebugger] Hook failed: {ex.Message}");
            }
        }

        private void UnhookFromPhysicsWorld()
        {
            if (!_hooked) return;
            try { EngineKernel.Instance.Physics.OnCollision -= OnCollision; }
            catch { /* world may have been disposed */ }
            _hooked = false;
        }

        private void OnCollision(CollisionManifold m)
        {
            _collisionCount++;
            if (_activeLayers.Contains(PhysicsDebugLayer.Colliders))
                Console.WriteLine($"[PhysicsDebugger] Collision: {m.A.GameObject?.Name ?? "?"} ↔ {m.B.GameObject?.Name ?? "?"}  depth={m.Depth:F3}");
        }

        // ── Body tracking ─────────────────────────────────────
        public void TrackBody(string id, string colliderType, float mass)
        {
            _trackedBodies[id] = new PhysicsDebugEntry
                { ObjectId = id, ColliderType = colliderType, Mass = mass };
        }

        public void UpdateBody(string id, float[] vel, float[] angVel, bool sleeping)
        {
            if (!_trackedBodies.TryGetValue(id, out var e)) return;
            e.Velocity = vel; e.AngularVelocity = angVel; e.IsSleeping = sleeping;
        }

        public void UntrackBody(string id) => _trackedBodies.Remove(id);

        // ── Simulation control ────────────────────────────────
        public bool IsPaused => _paused;
        public void TogglePause()
        {
            _paused = !_paused;
            Console.WriteLine($"[PhysicsDebugger] Physics {(_paused?"PAUSED":"RESUMED")}.");
        }

        public void ResetCollisionCount() => _collisionCount = 0;
    }
}
