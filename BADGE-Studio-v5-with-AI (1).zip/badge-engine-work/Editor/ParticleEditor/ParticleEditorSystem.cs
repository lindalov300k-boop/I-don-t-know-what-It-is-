using BADGE.Icons;
// ============================================================
//  BADGE Engine – Editor/ParticleEditor/ParticleEditorSystem.cs
//  Full particle editor: curve editing, sub-emitters, burst
//  mode, and preview lifetime — implements IEditorModule.
// ============================================================
using System;
using System.Collections.Generic;
using BADGE.Editor;

namespace BADGE.Engine.Editor
{
    public sealed class CurveKey
    {
        public float Time, Value, InTangent, OutTangent;
    }

    public sealed class ParticleAnimationCurve
    {
        private readonly List<CurveKey> _keys = new();
        public IReadOnlyList<CurveKey> Keys => _keys;
        public void AddKey(float t, float v, float inT = 0f, float outT = 0f)
            => _keys.Add(new CurveKey { Time = t, Value = v, InTangent = inT, OutTangent = outT });
        public float Evaluate(float t)
        {
            if (_keys.Count == 0) return 0f;
            if (_keys.Count == 1) return _keys[0].Value;
            for (int i = 0; i < _keys.Count - 1; i++)
            {
                var a = _keys[i]; var b = _keys[i + 1];
                if (t >= a.Time && t <= b.Time)
                { float s = (t - a.Time)/(b.Time - a.Time); return a.Value + s*(b.Value - a.Value); }
            }
            return _keys[^1].Value;
        }
    }

    public sealed class BurstEntry
    {
        public float Time; public int Count; public int Cycles = 1; public float Interval = 0.05f;
    }

    public sealed class ParticleEmitterConfig
    {
        public string  Name = string.Empty;
        public float   EmitRate = 10f, LifetimeMin = 1f, LifetimeMax = 3f;
        public float   SpeedMin = 1f,  SpeedMax = 5f;
        public float   SizeStart = 1f, SizeEnd = 0f;
        public float[] ColorStart = {1,1,1,1}, ColorEnd = {1,1,1,0};
        public string  Texture = string.Empty, EmitterShape = "Point";
        public float   GravityMultiplier = 1f;
        public bool    Looping = true;
        public int     MaxParticles = 1000;
        public ParticleAnimationCurve SizeCurve  = new();
        public ParticleAnimationCurve AlphaCurve = new();
        public ParticleAnimationCurve SpeedCurve = new();
        public bool BurstEnabled;
        public List<BurstEntry> Bursts = new();
        public List<string> SubEmitterNames = new();
    }

    internal sealed class PreviewParticle
    {
        public float Age, Lifetime, Size, Alpha, Speed;
    }

    public class ParticleEditorSystem : IEditorModule
    {
        private static ParticleEditorSystem? _instance;
        public  static ParticleEditorSystem   Instance => _instance ??= new ParticleEditorSystem();

        public string Name   => "Particle Editor";
        public string Icon   => Icons.Sparkles;
        public bool   IsOpen { get; set; }
        public void Open()  { IsOpen = true; }
        public void Close() { IsOpen = false; StopPreview(); }

        public void Update(float dt)
        {
            if (!_previewing || _active == null) return;
            _previewTime += dt;
            for (int i = _live.Count - 1; i >= 0; i--)
            {
                var p = _live[i]; p.Age += dt;
                p.Size  = _active.SizeCurve.Evaluate(p.Age / p.Lifetime) * _active.SizeStart;
                p.Alpha = _active.AlphaCurve.Evaluate(p.Age / p.Lifetime);
                if (p.Age >= p.Lifetime) _live.RemoveAt(i);
            }
            if (!_active.BurstEnabled)
            {
                _emitAccum += dt * _active.EmitRate;
                while (_emitAccum >= 1f && _live.Count < _active.MaxParticles) { Spawn(); _emitAccum -= 1f; }
            }
            else foreach (var b in _active.Bursts)
                if (_previewTime >= b.Time && _previewTime < b.Time + b.Interval * b.Cycles)
                    for (int k = 0; k < b.Count && _live.Count < _active.MaxParticles; k++) Spawn();
        }

        public void DrawUI()
        {
            if (!IsOpen) return;
            Console.WriteLine($"[ParticleEditor] Live={_live.Count}  t={_previewTime:F1}s  PreviewLifetime={PreviewLifetime:F1}s");
        }

        public void OnShortcut(string s) { if (s == "Space") { if (_previewing) StopPreview(); else Preview(); } }

        private ParticleEmitterConfig? _active;
        private readonly List<ParticleEmitterConfig> _emitters = new();
        private readonly List<PreviewParticle> _live = new();
        private bool _previewing; private float _previewTime, _emitAccum;
        private static readonly Random _rng = new();

        public void NewEmitter(string name)
        {
            _active = new ParticleEmitterConfig { Name = name };
            _active.SizeCurve.AddKey(0f,1f); _active.SizeCurve.AddKey(1f,0f);
            _active.AlphaCurve.AddKey(0f,1f); _active.AlphaCurve.AddKey(1f,0f);
            _emitters.Add(_active);
            Console.WriteLine($"[ParticleEditor] New emitter: {name}");
        }
        public void AddSubEmitter(string child) { _active?.SubEmitterNames.Add(child); Console.WriteLine($"[ParticleEditor] Sub-emitter: {child}"); }
        public void AddBurst(float t, int c, int cycles=1, float interval=0.05f)
            { _active?.Bursts.Add(new BurstEntry{Time=t,Count=c,Cycles=cycles,Interval=interval}); if(_active!=null) _active.BurstEnabled=true; }
        public void SetEmitRate(float r)          { if(_active!=null) _active.EmitRate=r; }
        public void SetLifetime(float a, float b) { if(_active!=null){_active.LifetimeMin=a;_active.LifetimeMax=b;} }
        public void SetSpeed(float a, float b)    { if(_active!=null){_active.SpeedMin=a;_active.SpeedMax=b;} }
        public void SetShape(string s)            { if(_active!=null) _active.EmitterShape=s; }
        public void SetMaxParticles(int m)        { if(_active!=null) _active.MaxParticles=m; }
        public void EditSizeCurve(float t,float v) { _active?.SizeCurve.AddKey(t,v); }
        public void EditAlphaCurve(float t,float v){ _active?.AlphaCurve.AddKey(t,v); }
        public void EditSpeedCurve(float t,float v){ _active?.SpeedCurve.AddKey(t,v); }
        public float PreviewLifetime => _active!=null ? (_active.LifetimeMin+_active.LifetimeMax)*0.5f : 0f;
        public void Preview()
        {
            if(_active==null) return;
            _previewing=true; _previewTime=0f; _emitAccum=0f; _live.Clear();
            Console.WriteLine($"[ParticleEditor] Preview: {_active.Name}  avg lifetime {PreviewLifetime:F1}s");
        }
        public void StopPreview() { _previewing=false; _live.Clear(); Console.WriteLine("[ParticleEditor] Preview stopped."); }
        public void SaveEmitter()              => Console.WriteLine($"[ParticleEditor] Saved: {_active?.Name}");
        public void ImportEmitter(string path) => Console.WriteLine($"[ParticleEditor] Imported: {path}");
        public void ExportEmitter(string path) => Console.WriteLine($"[ParticleEditor] Exported: {path}");
        private void Spawn()
        {
            if(_active==null) return;
            float life=(float)(_rng.NextDouble()*(_active.LifetimeMax-_active.LifetimeMin)+_active.LifetimeMin);
            _live.Add(new PreviewParticle{Age=0f,Lifetime=life,Size=_active.SizeStart,Alpha=1f,
                Speed=(float)(_rng.NextDouble()*(_active.SpeedMax-_active.SpeedMin)+_active.SpeedMin)});
        }
    }
}
