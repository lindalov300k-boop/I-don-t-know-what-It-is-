using BADGE.Icons;
// ============================================================
//  BADGE Engine – Editor/VoxelEditor/VoxelEditorSystem.cs
//  Voxel editor: paint, flood-fill, extrude, palette, mesh
//  export — implements IEditorModule.
// ============================================================
using System;
using System.Collections.Generic;
using System.Text;
using BADGE.Editor;

namespace BADGE.Engine.Editor
{
    public struct VoxelCoord { public int X, Y, Z; }

    public class Voxel
    {
        public byte R=255,G=255,B=255,A=255, MaterialId; public bool IsSolid=true;
    }

    public sealed class VoxelPalette
    {
        private readonly List<Voxel> _entries = new();
        public int ActiveIndex { get; set; }
        public Voxel Active => _entries.Count > 0 ? _entries[ActiveIndex % _entries.Count] : new Voxel();
        public void Add(Voxel v) => _entries.Add(v);
        public void Remove(int i) { if(i>=0&&i<_entries.Count) _entries.RemoveAt(i); }
        public IReadOnlyList<Voxel> Entries => _entries;
    }

    public class VoxelEditorSystem : IEditorModule
    {
        private static VoxelEditorSystem? _instance;
        public  static VoxelEditorSystem   Instance => _instance ??= new VoxelEditorSystem();

        public string Name   => "Voxel Editor";
        public string Icon   => Icons.Grid;
        public bool   IsOpen { get; set; }
        public void Open()  { IsOpen = true; }
        public void Close() { IsOpen = false; }
        public void Update(float dt) { }
        public void DrawUI()
        {
            if (!IsOpen) return;
            Console.WriteLine($"[VoxelEditor] Grid {GridSizeX}×{GridSizeY}×{GridSizeZ}  Voxels:{_voxels.Count}  Palette:{Palette.Entries.Count}");
        }
        public void OnShortcut(string s) { }

        private readonly Dictionary<(int,int,int), Voxel> _voxels = new();
        public int GridSizeX=32, GridSizeY=32, GridSizeZ=32;
        public VoxelPalette Palette { get; } = new();

        // ── Basic ops ─────────────────────────────────────────
        public void PlaceVoxel(int x,int y,int z,Voxel v) => _voxels[(x,y,z)] = v;
        public void RemoveVoxel(int x,int y,int z)        => _voxels.Remove((x,y,z));
        public Voxel? GetVoxel(int x,int y,int z)         => _voxels.TryGetValue((x,y,z),out var v)?v:null;

        // ── Paint tool ────────────────────────────────────────
        public void Paint(int x, int y, int z)
        {
            var src = Palette.Active;
            _voxels[(x,y,z)] = new Voxel { R=src.R, G=src.G, B=src.B, A=src.A, MaterialId=src.MaterialId, IsSolid=true };
        }

        // ── Flood-fill (6-connected) ──────────────────────────
        public void FloodFill(int sx, int sy, int sz)
        {
            var target = GetVoxel(sx,sy,sz);
            byte tr=target?.R??0, tg=target?.G??0, tb=target?.B??0;
            var fill = Palette.Active;
            var queue = new Queue<(int,int,int)>();
            var visited = new HashSet<(int,int,int)>();
            queue.Enqueue((sx,sy,sz));
            int[] dx={1,-1,0,0,0,0}, dy={0,0,1,-1,0,0}, dz={0,0,0,0,1,-1};
            while (queue.Count > 0)
            {
                var (x,y,z) = queue.Dequeue();
                if (!visited.Add((x,y,z))) continue;
                if (x<0||y<0||z<0||x>=GridSizeX||y>=GridSizeY||z>=GridSizeZ) continue;
                var v = GetVoxel(x,y,z);
                if (v!=null && (v.R!=tr||v.G!=tg||v.B!=tb)) continue;
                Paint(x,y,z);
                for (int d=0;d<6;d++) queue.Enqueue((x+dx[d],y+dy[d],z+dz[d]));
            }
            Console.WriteLine($"[VoxelEditor] Flood-fill from ({sx},{sy},{sz})");
        }

        // ── Extrude face ──────────────────────────────────────
        public void Extrude(int x, int y, int z, int axis, int dir = 1)
        {
            // Copy slice along axis in direction dir
            var src = GetVoxel(x,y,z);
            if (src == null) return;
            int nx=x+(axis==0?dir:0), ny=y+(axis==1?dir:0), nz=z+(axis==2?dir:0);
            PlaceVoxel(nx,ny,nz, new Voxel{R=src.R,G=src.G,B=src.B,A=src.A,MaterialId=src.MaterialId});
            Console.WriteLine($"[VoxelEditor] Extruded ({x},{y},{z}) → ({nx},{ny},{nz})");
        }

        // ── Fill box ─────────────────────────────────────────
        public void FillBox(int x0,int y0,int z0,int x1,int y1,int z1,Voxel v)
        {
            for(int x=x0;x<=x1;x++) for(int y=y0;y<=y1;y++) for(int z=z0;z<=z1;z++) PlaceVoxel(x,y,z,v);
        }

        // ── Mesh export (OBJ) ─────────────────────────────────
        public string ExportToObj()
        {
            var sb = new StringBuilder();
            sb.AppendLine("# BADGE Voxel Export"); sb.AppendLine("o VoxelMesh");
            int vi = 1;
            foreach (var ((x,y,z), v) in _voxels)
            {
                if (!v.IsSolid) continue;
                // Simple cube — 8 verts per voxel
                float[] xs={x,x+1}; float[] ys={y,y+1}; float[] zs={z,z+1};
                foreach (float vy in ys) foreach (float vz in zs) foreach (float vx in xs)
                    sb.AppendLine($"v {vx:F3} {vy:F3} {vz:F3}");
                int b = vi;
                // 6 faces (quads → 2 tris each)
                sb.AppendLine($"f {b} {b+1} {b+3} {b+2}"); // bottom
                sb.AppendLine($"f {b+4} {b+5} {b+7} {b+6}"); // top
                sb.AppendLine($"f {b} {b+1} {b+5} {b+4}"); // front
                sb.AppendLine($"f {b+2} {b+3} {b+7} {b+6}"); // back
                sb.AppendLine($"f {b} {b+2} {b+6} {b+4}"); // left
                sb.AppendLine($"f {b+1} {b+3} {b+7} {b+5}"); // right
                vi += 8;
            }
            Console.WriteLine($"[VoxelEditor] OBJ export: {_voxels.Count} voxels");
            return sb.ToString();
        }

        public void ExportMesh(string path)
        {
            var obj = ExportToObj();
            System.IO.File.WriteAllText(path, obj);
            Console.WriteLine($"[VoxelEditor] Mesh exported to: {path}");
        }

        public void Clear()   { _voxels.Clear(); }
        public void SaveGrid(string p)  => Console.WriteLine($"[VoxelEditor] Saved: {p}");
        public void LoadGrid(string p)  => Console.WriteLine($"[VoxelEditor] Loaded: {p}");
    }
}
