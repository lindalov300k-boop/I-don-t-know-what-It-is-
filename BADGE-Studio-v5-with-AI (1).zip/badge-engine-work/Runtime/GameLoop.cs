// ============================================================
//  BADGE Engine – Runtime/GameLoop.cs
//  Manages the runtime game loop independently of the editor.
//  Supports fixed timestep physics, variable render timestep,
//  frame-rate limiting, pause/resume, and slow-motion.
// ============================================================
using System;
using System.Diagnostics;

namespace BADGE.Runtime
{
    public enum LoopState { Stopped, Running, Paused }

    /// <summary>
    /// Standalone game loop for runtime builds.
    /// Separate from EngineLoop so the editor can drive its
    /// own refresh rate without coupling to game physics.
    /// </summary>
    public sealed class GameLoop
    {
        // ── Singleton ─────────────────────────────────────────
        private static GameLoop? _instance;
        public  static GameLoop   Instance => _instance ??= new GameLoop();

        // ── Configuration ─────────────────────────────────────
        public int   TargetFPS       { get; set; } = 60;
        public float FixedTimestep   { get; set; } = 1f / 50f;   // 50 Hz physics
        public float MaxDeltaTime    { get; set; } = 0.1f;        // spiral-of-death guard
        public float TimeScale       { get; set; } = 1.0f;        // slow-motion support

        // ── State ─────────────────────────────────────────────
        public LoopState State      { get; private set; } = LoopState.Stopped;
        public float     DeltaTime  { get; private set; }
        public float     TotalTime  { get; private set; }
        public long      FrameCount { get; private set; }
        public float     FPS        { get; private set; }

        // ── Events ────────────────────────────────────────────
        public event Action<float>? OnUpdate;         // variable dt (scaled)
        public event Action<float>? OnFixedUpdate;    // fixed dt (always FixedTimestep)
        public event Action?        OnRender;
        public event Action?        OnLateUpdate;
        public event Action?        OnPause;
        public event Action?        OnResume;
        public event Action?        OnStop;

        // ── Internals ─────────────────────────────────────────
        private float   _fixedAccumulator;
        private bool    _shouldStop;
        private float   _fpsAccum;
        private int     _fpsFrames;

        // ── Lifecycle ─────────────────────────────────────────

        public void Run()
        {
            if (State == LoopState.Running) return;
            State        = LoopState.Running;
            _shouldStop  = false;

            var  sw           = Stopwatch.StartNew();
            long lastTicks    = sw.ElapsedTicks;
            double freq       = Stopwatch.Frequency;
            double targetSecs = 1.0 / TargetFPS;

            while (!_shouldStop)
            {
                long   now     = sw.ElapsedTicks;
                double elapsed = (now - lastTicks) / freq;
                lastTicks = now;

                if (State == LoopState.Paused)
                {
                    System.Threading.Thread.Sleep(16);
                    continue;
                }

                // Clamp + scale delta time
                float rawDt = (float)System.Math.Min(elapsed, MaxDeltaTime);
                DeltaTime   = rawDt * TimeScale;
                TotalTime  += rawDt;
                FrameCount++;

                // FPS counter (rolling 1-second window)
                _fpsAccum  += rawDt;
                _fpsFrames++;
                if (_fpsAccum >= 1f)
                {
                    FPS        = _fpsFrames / _fpsAccum;
                    _fpsAccum  = 0;
                    _fpsFrames = 0;
                }

                // Fixed-timestep physics
                _fixedAccumulator += DeltaTime;
                while (_fixedAccumulator >= FixedTimestep)
                {
                    OnFixedUpdate?.Invoke(FixedTimestep);
                    _fixedAccumulator -= FixedTimestep;
                }

                OnUpdate?.Invoke(DeltaTime);
                OnLateUpdate?.Invoke();
                OnRender?.Invoke();

                // Frame-rate cap
                double frameTime = (sw.ElapsedTicks - now) / freq;
                double sleep     = targetSecs - frameTime;
                if (sleep > 0.001)
                    System.Threading.Thread.Sleep((int)(sleep * 1000));
            }

            State = LoopState.Stopped;
            OnStop?.Invoke();
        }

        public void Pause()
        {
            if (State != LoopState.Running) return;
            State = LoopState.Paused;
            OnPause?.Invoke();
        }

        public void Resume()
        {
            if (State != LoopState.Paused) return;
            State = LoopState.Running;
            OnResume?.Invoke();
        }

        public void Stop() => _shouldStop = true;

        /// <summary>Toggle between Paused and Running.</summary>
        public void TogglePause()
        {
            if (State == LoopState.Running) Pause();
            else if (State == LoopState.Paused) Resume();
        }

        /// <summary>Step exactly one fixed frame (useful in editor play-step mode).</summary>
        public void StepFrame()
        {
            OnFixedUpdate?.Invoke(FixedTimestep);
            OnUpdate?.Invoke(FixedTimestep);
            OnLateUpdate?.Invoke();
            OnRender?.Invoke();
            FrameCount++;
        }

        public override string ToString()
            => $"GameLoop [{State}] Frame={FrameCount} FPS={FPS:F1} Time={TotalTime:F2}s";
    }
}
