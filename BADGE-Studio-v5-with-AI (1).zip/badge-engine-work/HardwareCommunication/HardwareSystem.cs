// ============================================================
//  BADGE Engine – HardwareCommunication/HardwareSystem.cs
//  CPU detection, GPU detection, RAM detection, Disk scanning,
//  Peripheral scanning. Used to optimize performance.
// ============================================================
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace BADGE.Engine.Hardware
{
    // ═══════════════════════════════════════════════════════
    //  Hardware Manager  (entry point)
    // ═══════════════════════════════════════════════════════
    public sealed class HardwareManager
    {
        public CPUInfo        CPU         { get; private set; } = new();
        public GPUInfo        GPU         { get; private set; } = new();
        public RAMInfo        RAM         { get; private set; } = new();
        public DiskInfo       Disk        { get; private set; } = new();
        public PeripheralInfo Peripherals { get; private set; } = new();

        public bool IsInitialized { get; private set; }

        public HardwareManager() { }

        // Full synchronous detection pass
        public void Initialize()
        {
            Console.WriteLine("[Hardware] Detecting system hardware…");
            CPU         = CPUDetector.Detect();
            GPU         = GPUDetector.Detect();
            RAM         = RAMDetector.Detect();
            Disk        = DiskDetector.Detect();
            Peripherals = PeripheralDetector.Detect();
            IsInitialized = true;
            PrintSummary();
        }

        public async Task InitializeAsync()
        {
            await Task.Run(Initialize);
        }

        // ── Auto-optimization hints ───────────────────────
        public PerformanceProfile RecommendProfile()
        {
            if (!IsInitialized) Initialize();

            // Score system 0–100
            int score = 0;
            score += System.Math.Min(40, CPU.PhysicalCores * 5);
            score += System.Math.Min(20, (int)(RAM.TotalGB / 2));
            if (GPU.HasDedicatedGPU) score += 25;
            if (GPU.VRAM_GB >= 4)    score += 10;
            if (GPU.VRAM_GB >= 8)    score += 5;

            return score switch
            {
                >= 80 => PerformanceProfile.Ultra,
                >= 60 => PerformanceProfile.High,
                >= 40 => PerformanceProfile.Medium,
                >= 20 => PerformanceProfile.Low,
                _     => PerformanceProfile.Minimal
            };
        }

        public QualitySettings GetRecommendedQuality()
        {
            var profile = RecommendProfile();
            return new QualitySettings
            {
                Profile          = profile,
                TargetFPS        = profile >= PerformanceProfile.High ? 120 : 60,
                ShadowQuality    = (int)profile,
                TextureQuality   = (int)profile,
                AntiAliasing     = profile >= PerformanceProfile.Medium ? 2 : 0,
                DrawDistance     = profile switch
                {
                    PerformanceProfile.Ultra  => 2000f,
                    PerformanceProfile.High   => 1200f,
                    PerformanceProfile.Medium => 800f,
                    PerformanceProfile.Low    => 400f,
                    _                         => 200f
                },
                EnableHDR        = GPU.HasDedicatedGPU && GPU.VRAM_GB >= 4,
                EnableRaytracing = GPU.SupportsRaytracing,
                EnableVRS        = GPU.SupportsVRS,
                WorkerThreads    = System.Math.Max(1, CPU.LogicalCores - 2)
            };
        }

        private void PrintSummary()
        {
            Console.WriteLine($"  CPU:  {CPU.Name}  ({CPU.PhysicalCores}C/{CPU.LogicalCores}T @ {CPU.BaseClockGHz:F1}GHz)");
            Console.WriteLine($"  GPU:  {GPU.Name}  ({GPU.VRAM_GB:F1} GB VRAM)  API:{GPU.PreferredAPI}");
            Console.WriteLine($"  RAM:  {RAM.TotalGB:F1} GB  ({RAM.FreeGB:F1} GB free)  {RAM.SpeedMHz} MHz");
            Console.WriteLine($"  Disk: {Disk.Drives.Count} drive(s)  OS:{Disk.OSDrive?.Name ?? "?"}  {Disk.OSDrive?.FreeGB:F0} GB free");
            Console.WriteLine($"  OS:   {CPU.OS}  |  Platform: {CPU.Platform}");
            Console.WriteLine($"  Profile recommendation: {RecommendProfile()}");
        }
    }

    // ═══════════════════════════════════════════════════════
    //  CPU Detection
    // ═══════════════════════════════════════════════════════
    public sealed class CPUInfo
    {
        public string     Name           { get; set; } = "Unknown CPU";
        public string     Vendor         { get; set; } = "";           // Intel, AMD, Apple, ARM
        public string     Architecture   { get; set; } = "";           // x64, ARM64, x86
        public int        PhysicalCores  { get; set; }
        public int        LogicalCores   { get; set; }
        public float      BaseClockGHz   { get; set; }
        public float      BoostClockGHz  { get; set; }
        public int        CacheL1_KB     { get; set; }
        public int        CacheL2_KB     { get; set; }
        public int        CacheL3_MB     { get; set; }
        public string     OS             { get; set; } = "";
        public OSPlatform Platform       { get; set; }

        // Feature flags
        public bool HasSSE4    { get; set; }
        public bool HasAVX     { get; set; }
        public bool HasAVX512  { get; set; }
        public bool HasFMA     { get; set; }
        public bool HasNEON    { get; set; }   // ARM
        public bool HasAMX     { get; set; }   // Apple M-series / Intel AI
        public bool HasRDTSCP  { get; set; }   // High-precision timer
        public bool IsHyperthreaded { get; set; }
        public bool IsARM      { get; set; }
        public bool IsAppleSilicon { get; set; }

        public float UtilizationPercent { get; internal set; }
        public float TemperatureCelsius { get; internal set; }
        public float CurrentClockGHz    { get; internal set; }
    }

    public static class CPUDetector
    {
        public static CPUInfo Detect()
        {
            var info = new CPUInfo
            {
                LogicalCores = Environment.ProcessorCount,
                OS           = RuntimeInformation.OSDescription,
                Architecture = RuntimeInformation.ProcessOSArchitecture.ToString()
            };

            // Physical cores + model name via OS-specific methods
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                info.Platform = OSPlatform.Windows;
                DetectWindows(info);
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                info.Platform = OSPlatform.Linux;
                DetectLinux(info);
            }
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))
            {
                info.Platform = OSPlatform.OSX;
                DetectMacOS(info);
            }

            // Fallback
            if (info.PhysicalCores == 0) info.PhysicalCores = System.Math.Max(1, info.LogicalCores / 2);
            if (info.Name == "Unknown CPU") info.Name = $"{info.Architecture} CPU ×{info.LogicalCores}";

            // Feature detection
            info.HasSSE4  = RuntimeInformation.ProcessArchitecture == Architecture.X64 ||
                            RuntimeInformation.ProcessArchitecture == Architecture.X86;
            info.HasAVX   = info.HasSSE4;
            info.HasNEON  = RuntimeInformation.ProcessArchitecture == Architecture.Arm64;
            info.IsARM    = info.HasNEON;
            info.IsAppleSilicon = info.IsARM && RuntimeInformation.IsOSPlatform(OSPlatform.OSX);
            info.IsHyperthreaded = info.LogicalCores > info.PhysicalCores;

            // Live metrics
            info.UtilizationPercent = GetCPUUsage();
            return info;
        }

        private static void DetectWindows(CPUInfo info)
        {
            try
            {
                var psi = new ProcessStartInfo("wmic", "cpu get Name,NumberOfCores,MaxClockSpeed /format:list")
                { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                using var proc = Process.Start(psi)!;
                var output = proc.StandardOutput.ReadToEnd();
                foreach (var line in output.Split('\n'))
                {
                    if (line.StartsWith("Name="))         info.Name = line[5..].Trim();
                    if (line.StartsWith("NumberOfCores=") && int.TryParse(line[14..].Trim(), out int c))
                        info.PhysicalCores = c;
                    if (line.StartsWith("MaxClockSpeed=") && float.TryParse(line[14..].Trim(), out float mhz))
                        info.BaseClockGHz = mhz / 1000f;
                }
                DetectVendor(info);
            }
            catch { }
        }

        private static void DetectLinux(CPUInfo info)
        {
            try
            {
                if (!File.Exists("/proc/cpuinfo")) return;
                var lines = File.ReadAllLines("/proc/cpuinfo");
                var physIds = new HashSet<string>();
                foreach (var line in lines)
                {
                    if (line.StartsWith("model name"))
                        info.Name = line.Split(':')[1].Trim();
                    if (line.StartsWith("cpu MHz") && float.TryParse(line.Split(':')[1].Trim(), out float mhz))
                        info.BaseClockGHz = System.Math.Max(info.BaseClockGHz, mhz / 1000f);
                    if (line.StartsWith("physical id"))
                        physIds.Add(line.Split(':')[1].Trim());
                    if (line.StartsWith("cache size") && line.Contains(':'))
                    {
                        var parts = line.Split(':')[1].Trim().Split(' ');
                        if (int.TryParse(parts[0], out int kb)) info.CacheL3_MB = kb / 1024;
                    }
                }
                if (physIds.Count == 0) physIds.Add("0");
                info.PhysicalCores = info.LogicalCores; // simplified; real: count unique physical+core combos
                DetectVendor(info);
            }
            catch { }
        }

        private static void DetectMacOS(CPUInfo info)
        {
            try
            {
                string Run(string cmd, string args)
                {
                    var psi = new ProcessStartInfo(cmd, args)
                    { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                    using var p = Process.Start(psi)!;
                    return p.StandardOutput.ReadToEnd().Trim();
                }
                info.Name           = Run("sysctl", "-n machdep.cpu.brand_string");
                var cores = Run("sysctl", "-n hw.physicalcpu");
                if (int.TryParse(cores, out int c)) info.PhysicalCores = c;
                var freq = Run("sysctl", "-n hw.cpufrequency");
                if (long.TryParse(freq, out long hz)) info.BaseClockGHz = hz / 1e9f;
                DetectVendor(info);
            }
            catch { }
        }

        private static void DetectVendor(CPUInfo info)
        {
            var name = info.Name.ToLower();
            if (name.Contains("intel"))  info.Vendor = "Intel";
            else if (name.Contains("amd")) info.Vendor = "AMD";
            else if (name.Contains("apple")) { info.Vendor = "Apple"; info.IsAppleSilicon = true; }
            else if (name.Contains("arm"))   info.Vendor = "ARM";
            else info.Vendor = "Unknown";
        }

        private static float GetCPUUsage()
        {
            try
            {
                if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux) && File.Exists("/proc/stat"))
                {
                    var line1 = File.ReadLines("/proc/stat").First();
                    Thread.Sleep(100);
                    var line2 = File.ReadLines("/proc/stat").First();
                    long Parse(string l) { var p = l.Split(' ', StringSplitOptions.RemoveEmptyEntries); return p.Skip(1).Take(4).Sum(long.Parse); }
                    long ParseIdle(string l) { var p = l.Split(' ', StringSplitOptions.RemoveEmptyEntries); return long.Parse(p[4]); }
                    long total1 = Parse(line1), idle1 = ParseIdle(line1);
                    long total2 = Parse(line2), idle2 = ParseIdle(line2);
                    long dt = total2 - total1, di = idle2 - idle1;
                    return dt > 0 ? 100f * (1f - (float)di / dt) : 0f;
                }
            }
            catch { }
            return -1f; // not available
        }
    }

    // ═══════════════════════════════════════════════════════
    //  GPU Detection
    // ═══════════════════════════════════════════════════════
    public sealed class GPUInfo
    {
        public string     Name             { get; set; } = "Unknown GPU";
        public string     Vendor           { get; set; } = "";       // NVIDIA, AMD, Intel, Apple
        public float      VRAM_GB          { get; set; }
        public bool       HasDedicatedGPU  { get; set; }
        public string     PreferredAPI     { get; set; } = "OpenGL"; // Vulkan, DirectX12, Metal, OpenGL
        public string     DriverVersion    { get; set; } = "";
        public List<GPUDevice> AllDevices  { get; set; } = new();

        // Feature support
        public bool   SupportsVulkan      { get; set; }
        public bool   SupportsDirectX12   { get; set; }
        public bool   SupportsMetal       { get; set; }
        public bool   SupportsRaytracing  { get; set; }
        public bool   SupportsVRS         { get; set; } // Variable Rate Shading
        public bool   SupportsMeshShaders { get; set; }
        public bool   SupportsComputeShaders { get; set; } = true;
        public int    MaxTextureSize      { get; set; } = 16384;
        public int    MaxMSAA             { get; set; } = 8;
        public float  UtilizationPercent  { get; internal set; }
        public float  TemperatureCelsius  { get; internal set; }
    }

    public sealed class GPUDevice
    {
        public string Name        { get; set; } = "";
        public float  VRAM_GB     { get; set; }
        public string Vendor      { get; set; } = "";
        public bool   IsDedicated { get; set; }
        public string DriverVer   { get; set; } = "";
    }

    public static class GPUDetector
    {
        public static GPUInfo Detect()
        {
            var info = new GPUInfo();

            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))   DetectWindows(info);
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux)) DetectLinux(info);
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))  DetectMacOS(info);

            // Determine preferred rendering API
            if (info.SupportsMetal)       info.PreferredAPI = "Metal";
            else if (info.SupportsDirectX12) info.PreferredAPI = "DirectX 12";
            else if (info.SupportsVulkan) info.PreferredAPI = "Vulkan";
            else                          info.PreferredAPI = "OpenGL";

            // Feature inference from vendor
            var vendor = info.Vendor.ToLower();
            if (vendor.Contains("nvidia"))
            {
                info.SupportsRaytracing  = info.VRAM_GB >= 6f;
                info.SupportsVRS         = true;
                info.SupportsMeshShaders = info.VRAM_GB >= 6f;
            }
            else if (vendor.Contains("amd"))
            {
                info.SupportsRaytracing  = info.VRAM_GB >= 8f;
                info.SupportsVRS         = true;
                info.SupportsMeshShaders = true;
            }
            else if (vendor.Contains("apple"))
            {
                info.SupportsRaytracing  = true;
                info.SupportsMetal       = true;
                info.SupportsMeshShaders = true;
            }

            if (info.Name == "Unknown GPU") info.Name = $"{info.PreferredAPI} GPU";
            return info;
        }

        private static void DetectWindows(GPUInfo info)
        {
            try
            {
                var psi = new ProcessStartInfo("wmic",
                    "path Win32_VideoController get Name,AdapterRAM,DriverVersion /format:list")
                { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                using var proc = Process.Start(psi)!;
                var output = proc.StandardOutput.ReadToEnd();
                long maxVram = 0;
                string curName = "", curDriver = "";
                long curVram = 0;

                foreach (var line in output.Split('\n'))
                {
                    if (line.StartsWith("Name="))        curName   = line[5..].Trim();
                    if (line.StartsWith("DriverVersion=")) curDriver = line[14..].Trim();
                    if (line.StartsWith("AdapterRAM=") && long.TryParse(line[11..].Trim(), out long v))
                        curVram = v;

                    // Flush on blank line
                    if (line.Trim() == "" && curName != "")
                    {
                        var dev = new GPUDevice { Name = curName, DriverVer = curDriver,
                            VRAM_GB = curVram / 1024f / 1024f / 1024f };
                        dev.Vendor = InferVendor(curName);
                        dev.IsDedicated = !curName.ToLower().Contains("intel");
                        info.AllDevices.Add(dev);
                        if (curVram > maxVram) { maxVram = curVram; info.Name = curName; info.DriverVersion = curDriver; }
                        curName = ""; curVram = 0; curDriver = "";
                    }
                }
                info.VRAM_GB        = maxVram / 1024f / 1024f / 1024f;
                info.Vendor         = InferVendor(info.Name);
                info.HasDedicatedGPU= info.AllDevices.Any(d => d.IsDedicated);
                info.SupportsDirectX12 = true;   // Win10+ guarantees DX12
                info.SupportsVulkan    = true;    // driver-dependent but likely
            }
            catch { }
        }

        private static void DetectLinux(GPUInfo info)
        {
            try
            {
                // Try lspci
                var psi = new ProcessStartInfo("lspci", "-v")
                { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                using var proc = Process.Start(psi)!;
                var output = proc.StandardOutput.ReadToEnd();
                foreach (var line in output.Split('\n'))
                {
                    if (!line.ToLower().Contains("vga") && !line.ToLower().Contains("3d")) continue;
                    info.Name   = line.Split(':').LastOrDefault()?.Trim() ?? info.Name;
                    info.Vendor = InferVendor(info.Name);
                    break;
                }
                info.SupportsVulkan = true;
            }
            catch { }

            // Try /sys/class/drm for VRAM
            try
            {
                var vramPath = "/sys/class/drm/card0/device/mem_info_vram_total";
                if (File.Exists(vramPath) && long.TryParse(File.ReadAllText(vramPath).Trim(), out long bytes))
                    info.VRAM_GB = bytes / 1024f / 1024f / 1024f;
            }
            catch { }
        }

        private static void DetectMacOS(GPUInfo info)
        {
            try
            {
                var psi = new ProcessStartInfo("system_profiler", "SPDisplaysDataType")
                { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                using var proc = Process.Start(psi)!;
                var output = proc.StandardOutput.ReadToEnd();
                foreach (var line in output.Split('\n'))
                {
                    if (line.TrimStart().StartsWith("Chipset Model:"))
                        info.Name = line.Split(':')[1].Trim();
                    if (line.TrimStart().StartsWith("VRAM") && line.Contains("MB"))
                    {
                        var num = line.Split(':').Last().Trim().Split(' ')[0];
                        if (float.TryParse(num, out float mb)) info.VRAM_GB = mb / 1024f;
                    }
                }
                info.Vendor      = InferVendor(info.Name);
                info.SupportsMetal = true;
                info.SupportsVulkan = false;
                info.HasDedicatedGPU = info.Name.ToLower().Contains("apple");
                info.VRAM_GB = info.VRAM_GB <= 0 ? 8f : info.VRAM_GB; // Apple Silicon UMA estimate
            }
            catch { }
        }

        private static string InferVendor(string name)
        {
            var n = name.ToLower();
            if (n.Contains("nvidia") || n.Contains("geforce") || n.Contains("rtx") || n.Contains("gtx")) return "NVIDIA";
            if (n.Contains("amd") || n.Contains("radeon") || n.Contains("rx ")) return "AMD";
            if (n.Contains("intel") || n.Contains("iris") || n.Contains("uhd")) return "Intel";
            if (n.Contains("apple") || n.Contains("m1") || n.Contains("m2") || n.Contains("m3")) return "Apple";
            return "Unknown";
        }
    }

    // ═══════════════════════════════════════════════════════
    //  RAM Detection
    // ═══════════════════════════════════════════════════════
    public sealed class RAMInfo
    {
        public float  TotalGB      { get; set; }
        public float  FreeGB       { get; set; }
        public float  UsedGB       => TotalGB - FreeGB;
        public float  UsagePercent => TotalGB > 0 ? 100f * UsedGB / TotalGB : 0f;
        public int    SpeedMHz     { get; set; }
        public string Type         { get; set; } = "";    // DDR4, DDR5, LPDDR5
        public int    Channels     { get; set; } = 1;     // single / dual / quad
        public long   TotalBytes   { get; set; }
        public long   FreeBytes    { get; set; }
    }

    public static class RAMDetector
    {
        public static RAMInfo Detect()
        {
            var info = new RAMInfo();
            if      (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) DetectWindows(info);
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))   DetectLinux(info);
            else if (RuntimeInformation.IsOSPlatform(OSPlatform.OSX))     DetectMacOS(info);
            return info;
        }

        private static void DetectWindows(RAMInfo info)
        {
            try
            {
                // Total via GlobalMemoryStatusEx — use wmic as fallback
                var psi = new ProcessStartInfo("wmic",
                    "MemoryChip get Capacity,Speed,MemoryType /format:list")
                { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                using var proc = Process.Start(psi)!;
                var output = proc.StandardOutput.ReadToEnd();
                long total = 0; int maxSpeed = 0; int stickCount = 0;
                foreach (var line in output.Split('\n'))
                {
                    if (line.StartsWith("Capacity=") && long.TryParse(line[9..].Trim(), out long cap)) total += cap;
                    if (line.StartsWith("Speed=") && int.TryParse(line[6..].Trim(), out int spd) && spd > maxSpeed) maxSpeed = spd;
                    if (line.StartsWith("Capacity=") && long.TryParse(line[9..].Trim(), out long _)) stickCount++;
                }
                info.TotalBytes = total;
                info.TotalGB    = total / 1024f / 1024f / 1024f;
                info.SpeedMHz   = maxSpeed;
                info.Channels   = stickCount >= 4 ? 4 : stickCount >= 2 ? 2 : 1;
                info.Type       = maxSpeed >= 5000 ? "DDR5" : maxSpeed >= 3200 ? "DDR4" : "DDR4";

                // Free RAM
                var psi2 = new ProcessStartInfo("wmic", "OS get FreePhysicalMemory /format:value")
                { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                using var p2 = Process.Start(psi2)!;
                var out2 = p2.StandardOutput.ReadToEnd();
                foreach (var l in out2.Split('\n'))
                    if (l.StartsWith("FreePhysicalMemory=") && long.TryParse(l[19..].Trim(), out long freeKB))
                    { info.FreeBytes = freeKB * 1024; info.FreeGB = freeKB / 1024f / 1024f; }
            }
            catch { FallbackToGC(info); }
        }

        private static void DetectLinux(RAMInfo info)
        {
            try
            {
                if (!File.Exists("/proc/meminfo")) { FallbackToGC(info); return; }
                foreach (var line in File.ReadAllLines("/proc/meminfo"))
                {
                    if (line.StartsWith("MemTotal:") && long.TryParse(line.Split(':')[1].Trim().Split(' ')[0], out long total))
                    { info.TotalBytes = total * 1024; info.TotalGB = total / 1024f / 1024f; }
                    if (line.StartsWith("MemAvailable:") && long.TryParse(line.Split(':')[1].Trim().Split(' ')[0], out long avail))
                    { info.FreeBytes  = avail * 1024; info.FreeGB  = avail / 1024f / 1024f; }
                }
                // Speed via dmidecode (requires root)
                DetectRAMSpeedDmidecode(info);
            }
            catch { FallbackToGC(info); }
        }

        private static void DetectMacOS(RAMInfo info)
        {
            try
            {
                string Run(string cmd, string args)
                {
                    var psi = new ProcessStartInfo(cmd, args)
                    { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                    using var p = Process.Start(psi)!;
                    return p.StandardOutput.ReadToEnd().Trim();
                }
                var memSize = Run("sysctl", "-n hw.memsize");
                if (long.TryParse(memSize, out long bytes))
                { info.TotalBytes = bytes; info.TotalGB = bytes / 1024f / 1024f / 1024f; }

                // vm_stat for free pages
                var vmStat = Run("vm_stat", "");
                var lines  = vmStat.Split('\n');
                long freePages = 0, pageSize = 4096;
                foreach (var l in lines)
                {
                    if (l.Contains("page size of") && long.TryParse(
                        new string(l.Where(char.IsDigit).ToArray()), out long ps)) pageSize = ps;
                    if (l.StartsWith("Pages free:") && long.TryParse(
                        l.Split(':')[1].Trim().TrimEnd('.'), out long fp)) freePages += fp;
                    if (l.StartsWith("Pages inactive:") && long.TryParse(
                        l.Split(':')[1].Trim().TrimEnd('.'), out long ip)) freePages += ip;
                }
                info.FreeBytes = freePages * pageSize;
                info.FreeGB    = info.FreeBytes / 1024f / 1024f / 1024f;
                info.Type      = info.TotalGB >= 32 ? "LPDDR5" : "LPDDR4X"; // Apple Silicon
            }
            catch { FallbackToGC(info); }
        }

        private static void DetectRAMSpeedDmidecode(RAMInfo info)
        {
            try
            {
                var psi = new ProcessStartInfo("dmidecode", "-t memory")
                { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                using var proc = Process.Start(psi)!;
                foreach (var l in proc.StandardOutput.ReadToEnd().Split('\n'))
                {
                    if (l.TrimStart().StartsWith("Speed:") && l.Contains("MT/s"))
                    {
                        var parts = l.Split(':')[1].Trim().Split(' ');
                        if (int.TryParse(parts[0], out int mhz) && mhz > info.SpeedMHz)
                            info.SpeedMHz = mhz;
                    }
                    if (l.TrimStart().StartsWith("Type:") && l.Contains("DDR"))
                        info.Type = l.Split(':')[1].Trim();
                }
            }
            catch { }
        }

        private static void FallbackToGC(RAMInfo info)
        {
            var gcInfo = GC.GetGCMemoryInfo();
            info.TotalBytes = gcInfo.TotalAvailableMemoryBytes;
            info.TotalGB    = info.TotalBytes / 1024f / 1024f / 1024f;
            info.FreeBytes  = gcInfo.TotalAvailableMemoryBytes - GC.GetTotalMemory(false);
            info.FreeGB     = info.FreeBytes / 1024f / 1024f / 1024f;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Disk Detection
    // ═══════════════════════════════════════════════════════
    public sealed class DiskInfo
    {
        public List<DriveDetails> Drives   { get; set; } = new();
        public DriveDetails?      OSDrive  { get; set; }
        public long TotalStorageBytes      => Drives.Sum(d => d.TotalBytes);
        public float TotalStorageGB        => TotalStorageBytes / 1024f / 1024f / 1024f;
    }

    public sealed class DriveDetails
    {
        public string     Name          { get; set; } = "";
        public string     Label         { get; set; } = "";
        public DriveType  Type          { get; set; }
        public string     FileSystem    { get; set; } = "";
        public long       TotalBytes    { get; set; }
        public long       FreeBytes     { get; set; }
        public float      TotalGB       => TotalBytes / 1024f / 1024f / 1024f;
        public float      FreeGB        => FreeBytes  / 1024f / 1024f / 1024f;
        public float      UsedGB        => TotalGB - FreeGB;
        public float      UsagePercent  => TotalGB > 0 ? 100f * UsedGB / TotalGB : 0f;
        public bool       IsReady       { get; set; }
        public bool       IsNVMe        { get; set; }
        public bool       IsSSD         { get; set; }
        public long       ReadSpeedMBps { get; set; }    // benchmark or estimate
        public long       WriteSpeedMBps{ get; set; }
    }

    public static class DiskDetector
    {
        public static DiskInfo Detect()
        {
            var info = new DiskInfo();
            foreach (var drive in DriveInfo.GetDrives())
            {
                if (!drive.IsReady) continue;
                var d = new DriveDetails
                {
                    Name       = drive.Name,
                    Label      = drive.VolumeLabel,
                    Type       = drive.DriveType,
                    FileSystem = drive.DriveFormat,
                    TotalBytes = drive.TotalSize,
                    FreeBytes  = drive.AvailableFreeSpace,
                    IsReady    = true
                };
                DetectDriveType(d);
                info.Drives.Add(d);
            }

            // Identify OS drive
            string osPath = RuntimeInformation.IsOSPlatform(OSPlatform.Windows)
                ? Path.GetPathRoot(Environment.SystemDirectory) ?? "C:\\"
                : "/";
            info.OSDrive = info.Drives.FirstOrDefault(d =>
                d.Name.Equals(osPath, StringComparison.OrdinalIgnoreCase))
                ?? info.Drives.FirstOrDefault();

            return info;
        }

        private static void DetectDriveType(DriveDetails d)
        {
            // Heuristic: drives > 500 GB with fast systems are likely NVMe/SSD
            d.IsSSD  = d.TotalBytes > 0;  // simplified; real: WMI or /sys/block/*/queue/rotational
            d.IsNVMe = d.Name.Contains("nvme", StringComparison.OrdinalIgnoreCase);

            // Speed estimate
            if (d.IsNVMe)  { d.ReadSpeedMBps = 3500; d.WriteSpeedMBps = 3000; }
            else if (d.IsSSD){ d.ReadSpeedMBps = 550;  d.WriteSpeedMBps = 500;  }
            else             { d.ReadSpeedMBps = 150;  d.WriteSpeedMBps = 120;  }

            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    // /sys/block/<dev>/queue/rotational: 0 = SSD, 1 = HDD
                    string devName = d.Name.TrimStart('/').Replace('/', '-');
                    var rotPath = $"/sys/block/{devName}/queue/rotational";
                    if (File.Exists(rotPath))
                        d.IsSSD = File.ReadAllText(rotPath).Trim() == "0";
                }
                catch { }
            }
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Peripheral Detection
    // ═══════════════════════════════════════════════════════
    public sealed class PeripheralInfo
    {
        public List<DisplayDevice> Displays     { get; set; } = new();
        public List<AudioDevice>   AudioDevices { get; set; } = new();
        public List<GamepadDevice> Gamepads     { get; set; } = new();
        public List<USBDevice>     USBDevices   { get; set; } = new();
        public bool                HasKeyboard  { get; set; } = true;
        public bool                HasMouse     { get; set; } = true;
        public bool                HasTouchscreen{ get; set; }
        public bool                HasWebcam    { get; set; }
        public bool                HasMicrophone{ get; set; }
        public bool                HasVRHeadset { get; set; }
        public bool                HasGamepad   => Gamepads.Count > 0;
    }

    public sealed class DisplayDevice
    {
        public string Name         { get; set; } = "";
        public int    Width        { get; set; }
        public int    Height       { get; set; }
        public float  RefreshHz    { get; set; }
        public bool   IsPrimary    { get; set; }
        public float  DPI          { get; set; }
        public bool   IsHDR        { get; set; }
        public int    BitDepth     { get; set; } = 24;
        public string Connection   { get; set; } = "";  // HDMI, DisplayPort, eDP
    }

    public sealed class AudioDevice
    {
        public string Name        { get; set; } = "";
        public bool   IsInput     { get; set; }
        public bool   IsOutput    { get; set; }
        public bool   IsDefault   { get; set; }
        public int    Channels    { get; set; }
        public int    SampleRate  { get; set; }
        public string DeviceId    { get; set; } = "";
    }

    public sealed class GamepadDevice
    {
        public string Name        { get; set; } = "";
        public int    Index       { get; set; }
        public bool   IsConnected { get; set; }
        public string VendorId    { get; set; } = "";
        public string ProductId   { get; set; } = "";
        public bool   HasRumble   { get; set; }
        public bool   IsXInput    { get; set; }
        public float  BatteryLevel{ get; set; } = 1f;
    }

    public sealed class USBDevice
    {
        public string Name      { get; set; } = "";
        public string VendorId  { get; set; } = "";
        public string ProductId { get; set; } = "";
        public string Class     { get; set; } = "";  // HID, Audio, Storage, etc.
        public string Port      { get; set; } = "";
    }

    public static class PeripheralDetector
    {
        public static PeripheralInfo Detect()
        {
            var info = new PeripheralInfo();
            DetectDisplays(info);
            DetectAudio(info);
            DetectGamepads(info);
            DetectUSB(info);
            DetectVR(info);
            return info;
        }

        private static void DetectDisplays(PeripheralInfo info)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                try
                {
                    var psi = new ProcessStartInfo("wmic",
                        "DesktopMonitor get Name,ScreenWidth,ScreenHeight /format:list")
                    { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                    using var proc = Process.Start(psi)!;
                    var output = proc.StandardOutput.ReadToEnd();
                    var d = new DisplayDevice { IsPrimary = info.Displays.Count == 0 };
                    foreach (var line in output.Split('\n'))
                    {
                        if (line.StartsWith("Name="))        d.Name   = line[5..].Trim();
                        if (line.StartsWith("ScreenWidth=")  && int.TryParse(line[12..].Trim(), out int w)) d.Width  = w;
                        if (line.StartsWith("ScreenHeight=") && int.TryParse(line[13..].Trim(), out int h)) d.Height = h;
                    }
                    if (d.Width > 0) info.Displays.Add(d);
                }
                catch { }
            }
            // Fallback / Linux / macOS: use environment
            if (info.Displays.Count == 0)
                info.Displays.Add(new DisplayDevice
                {
                    Name = "Primary Display", Width = 1920, Height = 1080,
                    RefreshHz = 60, IsPrimary = true, DPI = 96
                });
        }

        private static void DetectAudio(PeripheralInfo info)
        {
            // Default output
            info.AudioDevices.Add(new AudioDevice
            { Name="Default Output", IsOutput=true, IsDefault=true, Channels=2, SampleRate=44100 });
            info.HasMicrophone = true;  // assume present; real: enumerate via CoreAudio/WASAPI/PulseAudio

            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    var psi = new ProcessStartInfo("pactl", "list sinks short")
                    { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                    using var proc = Process.Start(psi)!;
                    foreach (var l in proc.StandardOutput.ReadToEnd().Split('\n'))
                        if (!string.IsNullOrWhiteSpace(l))
                            info.AudioDevices.Add(new AudioDevice { Name = l.Split('\t').ElementAtOrDefault(1) ?? l, IsOutput = true });
                }
                catch { }
            }
        }

        private static void DetectGamepads(PeripheralInfo info)
        {
            // Real: enumerate via SDL2, XInput (Windows), evdev (Linux), GameController (iOS/macOS)
            // Check for common gamepad paths on Linux
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                for (int i = 0; i < 4; i++)
                {
                    var path = $"/dev/input/js{i}";
                    if (File.Exists(path))
                        info.Gamepads.Add(new GamepadDevice
                        { Name = $"Gamepad {i}", Index = i, IsConnected = true });
                }
            }
        }

        private static void DetectUSB(PeripheralInfo info)
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    var psi = new ProcessStartInfo("lsusb")
                    { RedirectStandardOutput = true, UseShellExecute = false, CreateNoWindow = true };
                    using var proc = Process.Start(psi)!;
                    foreach (var line in proc.StandardOutput.ReadToEnd().Split('\n'))
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;
                        var parts = line.Split(' ', 7);
                        info.USBDevices.Add(new USBDevice
                        {
                            Port      = parts.ElementAtOrDefault(1) ?? "",
                            VendorId  = parts.ElementAtOrDefault(5)?.Split(':').FirstOrDefault() ?? "",
                            ProductId = parts.ElementAtOrDefault(5)?.Split(':').LastOrDefault()  ?? "",
                            Name      = parts.ElementAtOrDefault(6) ?? ""
                        });
                    }
                }
                catch { }
            }
        }

        private static void DetectVR(PeripheralInfo info)
        {
            var vrRuntime = Environment.GetEnvironmentVariable("VR_RUNTIME") ??
                            Environment.GetEnvironmentVariable("XR_RUNTIME_JSON");
            info.HasVRHeadset = !string.IsNullOrEmpty(vrRuntime);
            if (info.HasVRHeadset) Console.WriteLine($"[Hardware] VR runtime detected: {vrRuntime}");
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Performance Profiling & Live Metrics
    // ═══════════════════════════════════════════════════════
    public enum PerformanceProfile { Minimal, Low, Medium, High, Ultra }

    public sealed class QualitySettings
    {
        public PerformanceProfile Profile        { get; set; }
        public int   TargetFPS       { get; set; }
        public int   ShadowQuality   { get; set; }  // 0–4
        public int   TextureQuality  { get; set; }  // 0–4
        public int   AntiAliasing    { get; set; }  // 0/2/4/8
        public float DrawDistance    { get; set; }
        public bool  EnableHDR       { get; set; }
        public bool  EnableRaytracing{ get; set; }
        public bool  EnableVRS       { get; set; }
        public int   WorkerThreads   { get; set; }
    }

    public sealed class LiveMetrics
    {
        private readonly HardwareManager _hw;
        private readonly Process _self = Process.GetCurrentProcess();

        public float CPUUsagePercent   { get; private set; }
        public float GPUUsagePercent   { get; private set; }
        public float RAMUsedGB         { get; private set; }
        public float RAMUsagePercent   { get; private set; }
        public float ProcessMemoryMB   { get; private set; }
        public float FrameTimesMs      { get; private set; }
        public int   FPS               { get; private set; }
        private int  _frameCount;
        private float _fpsTimer;

        public LiveMetrics(HardwareManager hw) { _hw = hw; }

        public void Update(float dt)
        {
            _fpsTimer  += dt;
            _frameCount++;
            if (_fpsTimer >= 1f)
            {
                FPS        = _frameCount;
                _frameCount = 0;
                _fpsTimer  -= 1f;
                SampleMetrics();
            }
            FrameTimesMs = dt * 1000f;
        }

        private void SampleMetrics()
        {
            try
            {
                _self.Refresh();
                ProcessMemoryMB = _self.WorkingSet64 / 1024f / 1024f;
                RAMUsedGB       = _hw.RAM.UsedGB;
                RAMUsagePercent = _hw.RAM.UsagePercent;
            }
            catch { }
        }

        public string FormatHUD() =>
            $"FPS:{FPS,4}  CPU:{CPUUsagePercent,5:F1}%  RAM:{RAMUsedGB:F1}GB({RAMUsagePercent:F0}%)  VRAM:{_hw.GPU.VRAM_GB:F1}GB  Proc:{ProcessMemoryMB:F0}MB";
    }

    // ═══════════════════════════════════════════════════════
    //  Hardware Event System
    // ═══════════════════════════════════════════════════════
    public sealed class HardwareEventMonitor
    {
        public event Action<PeripheralChangeEvent>? OnPeripheralChanged;
        public event Action<ThermalEvent>?          OnThermalWarning;
        public event Action<MemoryPressureEvent>?   OnMemoryPressure;

        private CancellationTokenSource? _cts;

        public void Start()
        {
            _cts = new CancellationTokenSource();
            Task.Run(() => MonitorLoop(_cts.Token));
        }

        public void Stop() => _cts?.Cancel();

        private async Task MonitorLoop(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested)
            {
                await Task.Delay(2000, ct).ConfigureAwait(false);
                // Real: poll device change notifications (WM_DEVICECHANGE on Windows, udev on Linux)
                CheckMemoryPressure();
            }
        }

        private void CheckMemoryPressure()
        {
            var info = GC.GetGCMemoryInfo();
            float frag = 1f - (float)info.HeapSizeBytes / System.Math.Max(1, info.TotalAvailableMemoryBytes);
            if (frag > 0.85f)
                OnMemoryPressure?.Invoke(new MemoryPressureEvent
                { UsagePercent = frag * 100f, AvailableGB = info.TotalAvailableMemoryBytes / 1024f / 1024f / 1024f });
        }
    }

    public sealed class PeripheralChangeEvent
    {
        public string DeviceName { get; set; } = "";
        public bool   Connected  { get; set; }
        public string DeviceType { get; set; } = "";
    }

    public sealed class ThermalEvent
    {
        public string Component { get; set; } = "";
        public float  Temperature { get; set; }
        public bool   IsCritical  { get; set; }
    }

    public sealed class MemoryPressureEvent
    {
        public float UsagePercent  { get; set; }
        public float AvailableGB   { get; set; }
    }
}
