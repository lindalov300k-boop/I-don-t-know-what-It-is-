// ============================================================
//  BADGE Engine – MemoryManagement/MemorySystem.cs
//  Object Pooling, Asset Streaming, Resource Caching,
//  Garbage Optimization, Memory Budget tracking.
// ============================================================
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace BADGE.Engine.Memory
{
    // ═══════════════════════════════════════════════════════
    //  Memory Manager  (central coordinator)
    // ═══════════════════════════════════════════════════════
    public sealed class MemoryManager
    {
        public static MemoryManager Instance { get; } = new();

        public PoolRegistry    Pools    { get; } = new();
        public ResourceCache   Cache    { get; } = new();
        public GCOptimizer     GC       { get; } = new();
        public MemoryBudget    Budget   { get; } = new();

        public event Action<MemoryPressureLevel>? OnPressureChanged;
        private MemoryPressureLevel _lastPressure = MemoryPressureLevel.Normal;

        private MemoryManager() { }

        public void Initialize(long budgetBytes = 512 * 1024 * 1024)
        {
            Budget.TotalBudget = budgetBytes;
            GC.Initialize();
            Console.WriteLine($"[Memory] Manager initialized. Budget: {FormatBytes(budgetBytes)}");
        }

        public void Update(float dt)
        {
            Budget.Update();
            var pressure = Budget.PressureLevel;
            if (pressure != _lastPressure)
            {
                _lastPressure = pressure;
                OnPressureChanged?.Invoke(pressure);
                HandlePressure(pressure);
            }
        }

        private void HandlePressure(MemoryPressureLevel level)
        {
            Console.WriteLine($"[Memory] Pressure: {level}");
            switch (level)
            {
                case MemoryPressureLevel.High:
                    Cache.TrimToPercent(0.5f);
                    Pools.TrimAll(0.5f);
                    break;
                case MemoryPressureLevel.Critical:
                    Cache.Clear();
                    Pools.ClearAll();
                    System.GC.Collect(2, GCCollectionMode.Forced, blocking: true);
                    System.GC.WaitForPendingFinalizers();
                    break;
            }
        }

        public void PrintReport()
        {
            Console.WriteLine("\n[Memory] ─── Report ──────────────────────────────");
            Console.WriteLine($"  Managed heap:  {FormatBytes(System.GC.GetTotalMemory(false))}");
            Console.WriteLine($"  Budget used:   {FormatBytes(Budget.UsedBytes)} / {FormatBytes(Budget.TotalBudget)}  ({Budget.UsagePercent:F0}%)");
            Console.WriteLine($"  Pressure:      {Budget.PressureLevel}");
            Console.WriteLine($"  Cache entries: {Cache.EntryCount}  ({FormatBytes(Cache.UsedBytes)})");
            Console.WriteLine($"  Pool types:    {Pools.PoolCount}");
            Console.WriteLine($"  GC gen0:{System.GC.CollectionCount(0)}  gen1:{System.GC.CollectionCount(1)}  gen2:{System.GC.CollectionCount(2)}");
            Console.WriteLine();
        }

        private static string FormatBytes(long b) =>
            b < 1024 ? $"{b}B" : b < 1_048_576 ? $"{b/1024}KB" :
            b < 1_073_741_824L ? $"{b/1_048_576}MB" : $"{b/1_073_741_824.0:F1}GB";
    }

    public enum MemoryPressureLevel { Normal, Moderate, High, Critical }

    // ═══════════════════════════════════════════════════════
    //  Memory Budget Tracker
    // ═══════════════════════════════════════════════════════
    public sealed class MemoryBudget
    {
        public long  TotalBudget    { get; set; } = 512 * 1024 * 1024;
        public long  UsedBytes      { get; private set; }
        public float UsagePercent   => TotalBudget > 0 ? 100f * UsedBytes / TotalBudget : 0f;
        public long  AvailableBytes => System.Math.Max(0, TotalBudget - UsedBytes);

        private readonly Dictionary<string, long> _categories = new();

        public MemoryPressureLevel PressureLevel => UsagePercent switch
        {
            >= 95f => MemoryPressureLevel.Critical,
            >= 80f => MemoryPressureLevel.High,
            >= 65f => MemoryPressureLevel.Moderate,
            _      => MemoryPressureLevel.Normal
        };

        public void Allocate  (string cat, long bytes) { _categories.TryGetValue(cat, out var cur); _categories[cat] = cur + bytes; Recalc(); }
        public void Deallocate(string cat, long bytes) { if(_categories.TryGetValue(cat,out var cur)) _categories[cat]=System.Math.Max(0,cur-bytes); Recalc(); }
        public void SetCategory(string cat, long bytes) { _categories[cat]=bytes; Recalc(); }
        public void ClearCategory(string cat) { _categories.Remove(cat); Recalc(); }

        public void Update() { UsedBytes = System.Math.Max(0, System.GC.GetTotalMemory(false)); }

        private void Recalc() => UsedBytes = _categories.Values.Sum();

        public IReadOnlyDictionary<string, long> Categories => _categories;
    }

    // ═══════════════════════════════════════════════════════
    //  Object Pool — Generic
    // ═══════════════════════════════════════════════════════
    public sealed class ObjectPool<T> where T : class
    {
        private readonly ConcurrentBag<T> _bag        = new();
        private readonly Func<T>          _factory;
        private readonly Action<T>?       _onGet;
        private readonly Action<T>?       _onReturn;
        private readonly Action<T>?       _onDestroy;
        private int _created, _totalGet, _totalReturn;

        public string Name        { get; }
        public int    Available   => _bag.Count;
        public int    Created     => _created;
        public int    TotalGets   => _totalGet;
        public float  HitRate     => _totalGet > 0 ? (float)(_totalGet - _created) / _totalGet : 0f;
        public int    MaxSize     { get; set; } = -1;  // -1 = unlimited

        public ObjectPool(string name, Func<T> factory,
            Action<T>? onGet = null, Action<T>? onReturn = null, Action<T>? onDestroy = null)
        {
            Name       = name;
            _factory   = factory;
            _onGet     = onGet;
            _onReturn  = onReturn;
            _onDestroy = onDestroy;
        }

        public T Get()
        {
            Interlocked.Increment(ref _totalGet);
            if (_bag.TryTake(out var obj))
            {
                _onGet?.Invoke(obj);
                return obj;
            }
            Interlocked.Increment(ref _created);
            var fresh = _factory();
            _onGet?.Invoke(fresh);
            return fresh;
        }

        public void Return(T obj)
        {
            Interlocked.Increment(ref _totalReturn);
            if (MaxSize >= 0 && _bag.Count >= MaxSize) { _onDestroy?.Invoke(obj); return; }
            _onReturn?.Invoke(obj);
            _bag.Add(obj);
        }

        /// <summary>Use in a using block — auto-returns on dispose.</summary>
        public PoolLease<T> Lease() => new(Get(), this);

        public void Prewarm(int count)
        {
            for (int i = 0; i < count; i++) { var o = _factory(); Interlocked.Increment(ref _created); _bag.Add(o); }
        }

        public void Trim(float keepFraction = 0.5f)
        {
            int target = (int)(_bag.Count * keepFraction);
            while (_bag.Count > target && _bag.TryTake(out var obj)) _onDestroy?.Invoke(obj);
        }

        public void Clear()
        {
            while (_bag.TryTake(out var obj)) _onDestroy?.Invoke(obj);
        }

        public PoolStats GetStats() => new()
        {
            Name = Name, Available = Available, Created = _created,
            TotalGets = _totalGet, TotalReturns = _totalReturn, HitRate = HitRate
        };
    }

    public readonly struct PoolLease<T> : IDisposable where T : class
    {
        public  T           Value { get; }
        private readonly ObjectPool<T> _pool;
        public PoolLease(T v, ObjectPool<T> p) { Value = v; _pool = p; }
        public void Dispose() => _pool.Return(Value);
    }

    public sealed class PoolStats
    {
        public string Name        { get; init; } = "";
        public int    Available   { get; init; }
        public int    Created     { get; init; }
        public int    TotalGets   { get; init; }
        public int    TotalReturns{ get; init; }
        public float  HitRate     { get; init; }
    }

    // ═══════════════════════════════════════════════════════
    //  Pool Registry  (manages all pools)
    // ═══════════════════════════════════════════════════════
    public sealed class PoolRegistry
    {
        private readonly Dictionary<string, object> _pools = new();

        public int PoolCount => _pools.Count;

        public ObjectPool<T> Create<T>(string name, Func<T> factory,
            Action<T>? onGet = null, Action<T>? onReturn = null, Action<T>? onDestroy = null,
            int prewarm = 0, int maxSize = -1) where T : class
        {
            var pool = new ObjectPool<T>(name, factory, onGet, onReturn, onDestroy) { MaxSize = maxSize };
            if (prewarm > 0) pool.Prewarm(prewarm);
            _pools[name] = pool;
            Console.WriteLine($"[Pool] Created '{name}'  prewarm:{prewarm}  max:{(maxSize < 0 ? "∞" : maxSize.ToString())}");
            return pool;
        }

        public ObjectPool<T>? Get<T>(string name) where T : class =>
            _pools.TryGetValue(name, out var p) ? p as ObjectPool<T> : null;

        public void Remove(string name) => _pools.Remove(name);

        public void TrimAll(float keepFraction = 0.5f)
        {
            foreach (var p in _pools.Values)
            {
                var trimMethod = p.GetType().GetMethod("Trim");
                trimMethod?.Invoke(p, new object[] { keepFraction });
            }
        }

        public void ClearAll()
        {
            foreach (var p in _pools.Values)
                p.GetType().GetMethod("Clear")?.Invoke(p, null);
        }

        public List<PoolStats> GetAllStats()
        {
            var stats = new List<PoolStats>();
            foreach (var p in _pools.Values)
            {
                var statsMethod = p.GetType().GetMethod("GetStats");
                if (statsMethod?.Invoke(p, null) is PoolStats s) stats.Add(s);
            }
            return stats;
        }

        public void PrintStats()
        {
            Console.WriteLine("\n[Pool] ─── Registry Stats ────────────────────────");
            foreach (var s in GetAllStats().OrderByDescending(x => x.TotalGets))
                Console.WriteLine($"  {s.Name,-28} avail:{s.Available,4}  created:{s.Created,4}  gets:{s.TotalGets,6}  hit:{s.HitRate:P0}");
            Console.WriteLine();
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Typed Pool  — convenient wrappers for common types
    // ═══════════════════════════════════════════════════════
    public sealed class GameObjectPool
    {
        private readonly ObjectPool<PooledObject> _pool;

        public GameObjectPool(string name, int prewarm = 32, int maxSize = 256)
        {
            _pool = new ObjectPool<PooledObject>(name,
                factory:  () => new PooledObject { Name = name },
                onGet:    o  => { o.Active = true;  o.ResetAge(); },
                onReturn: o  => { o.Active = false; },
                onDestroy: _ => { });
            if (prewarm > 0) _pool.Prewarm(prewarm);
        }

        public PooledObject  Spawn(float x = 0, float y = 0, float z = 0)
        {
            var o = _pool.Get();
            o.X = x; o.Y = y; o.Z = z;
            return o;
        }

        public void Despawn(PooledObject o) => _pool.Return(o);
        public int  Available => _pool.Available;
        public void Prewarm(int n) => _pool.Prewarm(n);
    }

    public sealed class PooledObject
    {
        public string Name    { get; set; } = "";
        public bool   Active  { get; set; }
        public float  X, Y, Z;
        public float  Age     { get; private set; }
        public object? Data   { get; set; }   // user payload
        public void ResetAge() => Age = 0f;
        public void Update(float dt) => Age += dt;
    }

    // ═══════════════════════════════════════════════════════
    //  Resource Cache  (LRU, TTL, type-keyed)
    // ═══════════════════════════════════════════════════════
    public sealed class ResourceCache
    {
        private readonly Dictionary<string, CacheEntry> _entries = new();
        private long   _usedBytes;
        private long   _maxBytes = 256 * 1024 * 1024; // 256 MB default

        public long MaxBytes    { get => _maxBytes; set { _maxBytes = value; Evict(0); } }
        public long UsedBytes   => _usedBytes;
        public int  EntryCount  => _entries.Count;
        public float UsagePercent => _maxBytes > 0 ? 100f * _usedBytes / _maxBytes : 0f;

        public int  TotalHits   { get; private set; }
        public int  TotalMisses { get; private set; }
        public float HitRate    => (TotalHits + TotalMisses) > 0
            ? (float)TotalHits / (TotalHits + TotalMisses) : 0f;

        // ── Store & Retrieve ─────────────────────────────
        public void Store(string key, object value, long sizeBytes = 0,
            float ttlSeconds = -1f, CachePriority priority = CachePriority.Normal)
        {
            if (_entries.TryGetValue(key, out var existing)) { _usedBytes -= existing.SizeBytes; }
            Evict(sizeBytes);
            _entries[key] = new CacheEntry
            {
                Key         = key,
                Value       = value,
                SizeBytes   = sizeBytes,
                LastAccess  = DateTime.UtcNow,
                Expiry      = ttlSeconds > 0 ? DateTime.UtcNow.AddSeconds(ttlSeconds) : DateTime.MaxValue,
                Priority    = priority
            };
            _usedBytes += sizeBytes;
        }

        public bool TryGet<T>(string key, out T? value)
        {
            if (_entries.TryGetValue(key, out var e) && !e.IsExpired)
            {
                e.LastAccess = DateTime.UtcNow;
                e.Hits++;
                value = (T?)e.Value;
                TotalHits++;
                return true;
            }
            if (_entries.ContainsKey(key)) _entries.Remove(key);
            TotalMisses++;
            value = default;
            return false;
        }

        public T GetOrCreate<T>(string key, Func<T> factory,
            long sizeBytes = 0, float ttlSeconds = -1f) where T : class
        {
            if (TryGet<T>(key, out var v) && v != null) return v;
            var created = factory();
            Store(key, created, sizeBytes, ttlSeconds);
            return created;
        }

        public bool Invalidate(string key)
        {
            if (!_entries.TryGetValue(key, out var e)) return false;
            _usedBytes -= e.SizeBytes;
            _entries.Remove(key);
            return true;
        }

        public int InvalidateByPrefix(string prefix)
        {
            var keys = _entries.Keys.Where(k => k.StartsWith(prefix)).ToList();
            foreach (var k in keys) Invalidate(k);
            return keys.Count;
        }

        public int InvalidateByTag(string tag)
        {
            var keys = _entries.Values.Where(e => e.Tags.Contains(tag)).Select(e => e.Key).ToList();
            foreach (var k in keys) Invalidate(k);
            return keys.Count;
        }

        public void AddTag(string key, string tag)
        {
            if (_entries.TryGetValue(key, out var e)) e.Tags.Add(tag);
        }

        public void Clear() { _entries.Clear(); _usedBytes = 0; }

        public void TrimToPercent(float keepFraction)
        {
            long target = (long)(_maxBytes * keepFraction);
            Evict(_maxBytes - target);
        }

        public void PurgeExpired()
        {
            var expired = _entries.Values.Where(e => e.IsExpired).Select(e => e.Key).ToList();
            foreach (var k in expired) Invalidate(k);
        }

        // LRU eviction — respects priority
        private void Evict(long needed)
        {
            PurgeExpired();
            var candidates = _entries.Values
                .Where(e => e.Priority < CachePriority.Pinned)
                .OrderBy(e => (int)e.Priority)
                .ThenBy(e => e.LastAccess)
                .ToList();

            foreach (var e in candidates)
            {
                if (_usedBytes + needed <= _maxBytes) break;
                Invalidate(e.Key);
            }
        }

        public void PrintStats()
        {
            Console.WriteLine($"\n[Cache] Entries:{EntryCount}  Used:{FormatBytes(_usedBytes)}/{FormatBytes(_maxBytes)}  Hit:{HitRate:P0}");
            var top = _entries.Values.OrderByDescending(e => e.Hits).Take(10);
            foreach (var e in top)
                Console.WriteLine($"  {e.Key,-36} {FormatBytes(e.SizeBytes),8}  hits:{e.Hits}  prio:{e.Priority}");
        }

        private static string FormatBytes(long b) =>
            b < 1024 ? $"{b}B" : b < 1_048_576 ? $"{b/1024}KB" : $"{b/1_048_576}MB";

        private sealed class CacheEntry
        {
            public string          Key        { get; set; } = "";
            public object?         Value      { get; set; }
            public long            SizeBytes  { get; set; }
            public DateTime        LastAccess { get; set; }
            public DateTime        Expiry     { get; set; }
            public CachePriority   Priority   { get; set; }
            public int             Hits       { get; set; }
            public HashSet<string> Tags       { get; } = new();
            public bool            IsExpired  => DateTime.UtcNow > Expiry;
        }
    }

    public enum CachePriority { Low, Normal, High, Pinned }

    // ═══════════════════════════════════════════════════════
    //  GC Optimizer  (controls GC mode per workload)
    // ═══════════════════════════════════════════════════════
    public sealed class GCOptimizer
    {
        private GCMode _currentMode = GCMode.Balanced;

        public GCMode CurrentMode => _currentMode;

        public void Initialize()
        {
            // Configure GC for game workloads by default
            SetMode(GCMode.LowLatency);
            System.GC.RegisterForFullGCNotification(50, 50);
            Console.WriteLine($"[GC] Optimizer initialized. Mode: {_currentMode}");
        }

        public void SetMode(GCMode mode)
        {
            _currentMode = mode;
            switch (mode)
            {
                case GCMode.LowLatency:
                    // Reduces GC pauses during gameplay
                    System.Runtime.GCSettings.LatencyMode = GCLatencyMode.SustainedLowLatency;
                    break;
                case GCMode.Throughput:
                    System.Runtime.GCSettings.LatencyMode = GCLatencyMode.Batch;
                    break;
                case GCMode.Interactive:
                    System.Runtime.GCSettings.LatencyMode = GCLatencyMode.Interactive;
                    break;
                case GCMode.Balanced:
                    System.Runtime.GCSettings.LatencyMode = GCLatencyMode.Interactive;
                    break;
            }
            Console.WriteLine($"[GC] Mode → {mode}  (LatencyMode:{System.Runtime.GCSettings.LatencyMode})");
        }

        /// <summary>Call at the start of a gameplay frame to suppress GC.</summary>
        public void BeginGameplayFrame()
        {
            if (_currentMode == GCMode.LowLatency)
                System.GC.TryStartNoGCRegion(32 * 1024 * 1024, true); // 32 MB no-GC region
        }

        /// <summary>Call at end of frame to allow GC again.</summary>
        public void EndGameplayFrame()
        {
            try { System.GC.EndNoGCRegion(); }
            catch { /* already ended */ }
        }

        /// <summary>Gentle background collect — good for loading screens.</summary>
        public void SoftCollect()
        {
            System.GC.Collect(0, GCCollectionMode.Optimized, blocking: false);
        }

        /// <summary>Full blocking collect — use during scene transitions.</summary>
        public void FullCollect()
        {
            System.GC.Collect(2, GCCollectionMode.Forced, blocking: true);
            System.GC.WaitForPendingFinalizers();
            System.GC.Collect(2, GCCollectionMode.Forced, blocking: true);
            Console.WriteLine($"[GC] Full collect. Managed heap: {System.GC.GetTotalMemory(false)/1024}KB");
        }

        /// <summary>Compact LOH to reduce fragmentation.</summary>
        public void CompactLargeObjectHeap()
        {
            System.Runtime.GCSettings.LargeObjectHeapCompactionMode =
                GCLargeObjectHeapCompactionMode.CompactOnce;
            System.GC.Collect(2, GCCollectionMode.Forced, blocking: true);
            Console.WriteLine("[GC] LOH compacted.");
        }

        public GCMemoryInfo GetMemoryInfo() => System.GC.GetGCMemoryInfo();

        public void PrintGCReport()
        {
            var info = GetMemoryInfo();
            Console.WriteLine($"\n[GC] ─── GC Report ──────────────────────────────");
            Console.WriteLine($"  Heap size:      {info.HeapSizeBytes/1024/1024}MB");
            Console.WriteLine($"  Total available:{info.TotalAvailableMemoryBytes/1024/1024}MB");
            Console.WriteLine($"  Fragmented:     {info.FragmentedBytes/1024/1024}MB");
            Console.WriteLine($"  Gen0:{System.GC.CollectionCount(0)}  Gen1:{System.GC.CollectionCount(1)}  Gen2:{System.GC.CollectionCount(2)}");
            Console.WriteLine($"  Mode:           {_currentMode}  ({System.Runtime.GCSettings.LatencyMode})");
            Console.WriteLine();
        }
    }

    public enum GCMode { LowLatency, Throughput, Interactive, Balanced }

    // ═══════════════════════════════════════════════════════
    //  Native Memory  (unmanaged buffer management)
    // ═══════════════════════════════════════════════════════
    public sealed unsafe class NativeBuffer : IDisposable
    {
        private void*  _ptr;
        private bool   _disposed;

        public int    SizeBytes { get; }
        public bool   IsValid   => _ptr != null && !_disposed;
        public IntPtr Pointer   => IsValid ? (IntPtr)_ptr : IntPtr.Zero;

        public NativeBuffer(int sizeBytes)
        {
            SizeBytes = sizeBytes;
            _ptr = System.Runtime.InteropServices.NativeMemory.Alloc((nuint)sizeBytes);
            System.Runtime.InteropServices.NativeMemory.Clear(_ptr, (nuint)sizeBytes);
        }

        public Span<byte> AsSpan()
        {
            if (!IsValid) throw new ObjectDisposedException(nameof(NativeBuffer));
            return new Span<byte>(_ptr, SizeBytes);
        }

        public Span<T> AsSpan<T>() where T : unmanaged
        {
            if (!IsValid) throw new ObjectDisposedException(nameof(NativeBuffer));
            return new Span<T>(_ptr, SizeBytes / Unsafe.SizeOf<T>());
        }

        public void Dispose()
        {
            if (_disposed) return;
            System.Runtime.InteropServices.NativeMemory.Free(_ptr);
            _ptr = null;
            _disposed = true;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Ring Buffer  (lock-free fixed-capacity queue)
    // ═══════════════════════════════════════════════════════
    public sealed class RingBuffer<T>
    {
        private readonly T[]  _data;
        private int           _head, _tail, _count;
        private readonly object _lock = new();

        public int  Capacity  => _data.Length;
        public int  Count     { get { lock(_lock) return _count; } }
        public bool IsFull    { get { lock(_lock) return _count == _data.Length; } }
        public bool IsEmpty   { get { lock(_lock) return _count == 0; } }

        public RingBuffer(int capacity) { _data = new T[capacity]; }

        public bool TryEnqueue(T item)
        {
            lock (_lock)
            {
                if (_count == _data.Length) return false;
                _data[_tail] = item;
                _tail = (_tail + 1) % _data.Length;
                _count++;
                return true;
            }
        }

        /// <summary>Enqueue, overwriting oldest if full.</summary>
        public void Enqueue(T item)
        {
            lock (_lock)
            {
                if (_count == _data.Length) _head = (_head + 1) % _data.Length;
                else _count++;
                _data[_tail] = item;
                _tail = (_tail + 1) % _data.Length;
            }
        }

        public bool TryDequeue(out T item)
        {
            lock (_lock)
            {
                if (_count == 0) { item = default!; return false; }
                item  = _data[_head];
                _head = (_head + 1) % _data.Length;
                _count--;
                return true;
            }
        }

        public bool TryPeek(out T item)
        {
            lock (_lock)
            {
                if (_count == 0) { item = default!; return false; }
                item = _data[_head];
                return true;
            }
        }

        public void Clear() { lock (_lock) { _head = _tail = _count = 0; } }
    }

    // ═══════════════════════════════════════════════════════
    //  Frame Allocator  (bump allocator, reset each frame)
    // ═══════════════════════════════════════════════════════
    public sealed class FrameAllocator
    {
        private readonly byte[] _buffer;
        private int _offset;
        private readonly object _lock = new();

        public int Capacity    => _buffer.Length;
        public int Used        => _offset;
        public int Available   => _buffer.Length - _offset;
        public float UsagePercent => _buffer.Length > 0 ? 100f * _offset / _buffer.Length : 0f;

        public FrameAllocator(int sizeBytes = 4 * 1024 * 1024) // 4 MB default
        {
            _buffer = new byte[sizeBytes];
        }

        public Memory<byte> Allocate(int bytes)
        {
            lock (_lock)
            {
                // Align to 16 bytes
                int aligned = (bytes + 15) & ~15;
                if (_offset + aligned > _buffer.Length)
                    throw new OutOfMemoryException($"FrameAllocator exhausted ({_buffer.Length} bytes). Need {aligned}.");
                var mem = new Memory<byte>(_buffer, _offset, bytes);
                _offset += aligned;
                return mem;
            }
        }

        public Span<T> AllocateSpan<T>(int count) where T : unmanaged
        {
            var mem = Allocate(count * Unsafe.SizeOf<T>());
            return System.Runtime.InteropServices.MemoryMarshal.Cast<byte, T>(mem.Span);
        }

        /// <summary>Call at start of each frame to reset.</summary>
        public void Reset() { lock (_lock) _offset = 0; }

        public void PrintUsage() =>
            Console.WriteLine($"[FrameAlloc] {Used/1024}KB / {Capacity/1024}KB  ({UsagePercent:F0}%)");
    }

    // ═══════════════════════════════════════════════════════
    //  Weak Reference Cache  (objects can be GC'd)
    // ═══════════════════════════════════════════════════════
    public sealed class WeakCache<TKey, TValue> where TValue : class where TKey : notnull
    {
        private readonly Dictionary<TKey, WeakReference<TValue>> _refs = new();

        public bool TryGet(TKey key, out TValue? value)
        {
            if (_refs.TryGetValue(key, out var wr) && wr.TryGetTarget(out value))
                return true;
            _refs.Remove(key);
            value = null;
            return false;
        }

        public void Store(TKey key, TValue value) =>
            _refs[key] = new WeakReference<TValue>(value);

        public void Compact()
        {
            var dead = _refs.Where(kv => !kv.Value.TryGetTarget(out _)).Select(kv => kv.Key).ToList();
            foreach (var k in dead) _refs.Remove(k);
        }

        public int Count  => _refs.Count;
        public int Alive  => _refs.Count(kv => kv.Value.TryGetTarget(out _));
    }
}
