// ============================================================
//  BADGE Engine – Physics/PhysicsWorld.cs
//  Full physics: rigid bodies, broadphase BVH, narrowphase SAT,
//  constraints, raycasting, cloth, buoyancy, vehicle physics.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using BADGE.Engine.Components;
using BADGE.Engine.Math;

namespace BADGE.Engine.Physics
{
    // ═══════════════════════════════════════════════════════
    //  PhysicsWorld
    // ═══════════════════════════════════════════════════════
    public sealed class PhysicsWorld
    {
        public PhysicsConfig Config    { get; }
        public Vector3       Gravity   { get; set; }
        public bool          Enabled   { get; set; } = true;

        private readonly List<Collider>   _colliders = new();
        private readonly List<PhysBody>   _bodies    = new();
        private readonly List<Constraint> _constraints=new();
        private readonly BVHBroadphase    _broadphase = new();
        private          float            _accumulator;

        public event Action<CollisionManifold>? OnCollision;

        public PhysicsWorld(PhysicsConfig cfg)
        {
            Config  = cfg;
            Gravity = new Vector3(0, cfg.Gravity, 0);
            Console.WriteLine($"[Physics] World init. Gravity={cfg.Gravity}m/s²");
        }

        // ── Collider registry ─────────────────────────────
        public void RegisterCollider(Collider c)
        {
            _colliders.Add(c);
            _broadphase.Insert(c);
        }

        public void UnregisterCollider(Collider c)
        {
            _colliders.Remove(c);
            _broadphase.Remove(c);
        }

        // ── Step ─────────────────────────────────────────
        public void Step(float dt)
        {
            if (!Enabled) return;

            // Integrate rigidbodies
            foreach (var b in _bodies) IntegrateBody(b, dt);

            // Broadphase
            var pairs = _broadphase.GetPotentialPairs();

            // Narrowphase
            var manifolds = new List<CollisionManifold>();
            foreach (var (a, b) in pairs)
            {
                var m = NarrowphaseTest(a, b);
                if (m.HasContact)
                    manifolds.Add(m);
            }

            // Resolve
            for (int i = 0; i < Config.SolverIterations; i++)
                foreach (var m in manifolds)
                    ResolveCollision(m);

            // Dispatch events
            foreach (var m in manifolds)
            {
                OnCollision?.Invoke(m);
                var info = new CollisionInfo
                {
                    Other        = m.B.GameObject,
                    ContactPoint = m.Contact,
                    Normal       = m.Normal,
                    Impulse      = m.Impulse
                };
                m.A.GameObject.GetComponent<Rigidbody>(); // notify via component
                m.A.GetComponent<MonoBehaviourProxy>()?.OnCollisionEnter(info);
                info.Other = m.A.GameObject;
                m.B.GetComponent<MonoBehaviourProxy>()?.OnCollisionEnter(info);

                // Trigger callbacks
                if (m.A.IsTrigger) m.A.OnTriggerEnter(m.B);
                if (m.B.IsTrigger) m.B.OnTriggerEnter(m.A);
            }

            // Constraints
            foreach (var c in _constraints) c.Solve(dt);
        }

        // ── Integration ───────────────────────────────────
        private void IntegrateBody(PhysBody b, float dt)
        {
            if (b.IsKinematic || b.IsStatic) return;

            if (b.UseGravity) b.Velocity += Gravity * dt;
            b.Velocity      *= MathF.Max(0f, 1f - b.LinearDrag  * dt);
            b.AngularVelocity*= MathF.Max(0f, 1f - b.AngularDrag * dt);

            b.Collider.Transform.Translate(b.Velocity * dt);
            b.Collider.Transform.Rotate(b.AngularVelocity * dt);
        }

        // ── Narrowphase (SAT) ─────────────────────────────
        private CollisionManifold NarrowphaseTest(Collider a, Collider b)
        {
            if (a.Shape == ColliderShape.Sphere && b.Shape == ColliderShape.Sphere)
                return SphereSphere(a, b);
            if (a.Shape == ColliderShape.Box && b.Shape == ColliderShape.Box)
                return BoxBox(a, b);
            if (a.Shape == ColliderShape.Sphere && b.Shape == ColliderShape.Box)
                return SpherBox(a, b);
            if (a.Shape == ColliderShape.Box && b.Shape == ColliderShape.Sphere)
            { var m = SpherBox(b, a); m.Normal = -m.Normal; return m; }
            return SphereSphere(a, b); // fallback
        }

        private static CollisionManifold SphereSphere(Collider a, Collider b)
        {
            var delta = b.Transform.Position - a.Transform.Position;
            float dist  = delta.Magnitude;
            float radii = a.Radius + b.Radius;
            if (dist >= radii) return CollisionManifold.None(a, b);
            var normal = dist > 0.0001f ? delta / dist : Vector3.Up;
            return new CollisionManifold(a, b, true, normal,
                a.Transform.Position + normal * a.Radius, radii - dist);
        }

        private static CollisionManifold BoxBox(Collider a, Collider b)
        {
            // AABB test (simplified – full OBB would use SAT with all 15 axes)
            var ab = a.WorldBounds; var bb = b.WorldBounds;
            if (!ab.Intersects(bb)) return CollisionManifold.None(a, b);

            // Find min-penetration axis
            float px = MathF.Min(ab.Max.X,bb.Max.X) - MathF.Max(ab.Min.X,bb.Min.X);
            float py = MathF.Min(ab.Max.Y,bb.Max.Y) - MathF.Max(ab.Min.Y,bb.Min.Y);
            float pz = MathF.Min(ab.Max.Z,bb.Max.Z) - MathF.Max(ab.Min.Z,bb.Min.Z);
            Vector3 normal; float depth;
            if (px < py && px < pz) { normal=new(MathF.Sign(ab.Center.X-bb.Center.X),0,0); depth=px; }
            else if (py < pz)       { normal=new(0,MathF.Sign(ab.Center.Y-bb.Center.Y),0); depth=py; }
            else                    { normal=new(0,0,MathF.Sign(ab.Center.Z-bb.Center.Z)); depth=pz; }

            return new CollisionManifold(a, b, true, normal,
                (ab.Center + bb.Center) * 0.5f, depth);
        }

        private static CollisionManifold SpherBox(Collider sphere, Collider box)
        {
            var bb = box.WorldBounds;
            var closest = new Vector3(
                MathHelper.Clamp(sphere.Transform.Position.X, bb.Min.X, bb.Max.X),
                MathHelper.Clamp(sphere.Transform.Position.Y, bb.Min.Y, bb.Max.Y),
                MathHelper.Clamp(sphere.Transform.Position.Z, bb.Min.Z, bb.Max.Z));
            var delta = sphere.Transform.Position - closest;
            float dist = delta.Magnitude;
            if (dist >= sphere.Radius) return CollisionManifold.None(sphere, box);
            return new CollisionManifold(sphere, box, true,
                dist > 0.0001f ? delta/dist : Vector3.Up, closest, sphere.Radius - dist);
        }

        // ── Resolution ────────────────────────────────────
        private void ResolveCollision(CollisionManifold m)
        {
            var ba = GetBody(m.A); var bb = GetBody(m.B);
            if (ba is null && bb is null) return;
            if (m.A.IsTrigger || m.B.IsTrigger) return;

            float invMassA = ba is null || ba.IsKinematic ? 0f : 1f / ba.Mass;
            float invMassB = bb is null || bb.IsKinematic ? 0f : 1f / bb.Mass;
            float total    = invMassA + invMassB;
            if (total == 0) return;

            // Position correction (Baumgarte)
            float correction = MathF.Max(m.Depth - 0.005f, 0f) / total * 0.4f;
            if (ba is not null && !ba.IsKinematic)
                m.A.Transform.Translate(-m.Normal * correction * invMassA);
            if (bb is not null && !bb.IsKinematic)
                m.B.Transform.Translate( m.Normal * correction * invMassB);

            // Velocity impulse
            var relV = (bb?.Velocity ?? Vector3.Zero) - (ba?.Velocity ?? Vector3.Zero);
            float velAlongNorm = Vector3.Dot(relV, m.Normal);
            if (velAlongNorm > 0) return;

            float e = 0.3f; // restitution
            float j = -(1 + e) * velAlongNorm / total;
            m.Impulse = j;

            var impulse = m.Normal * j;
            if (ba is not null && !ba.IsKinematic) ba.Velocity -= impulse * invMassA;
            if (bb is not null && !bb.IsKinematic) bb.Velocity += impulse * invMassB;

            // Friction
            var tangent = (relV - m.Normal * velAlongNorm).Normalized;
            float jt    = -Vector3.Dot(relV, tangent) / total;
            float mu    = 0.5f;
            var friction = MathF.Abs(jt) < j * mu ? tangent * jt : tangent * (-j * mu);
            if (ba is not null && !ba.IsKinematic) ba.Velocity -= friction * invMassA;
            if (bb is not null && !bb.IsKinematic) bb.Velocity += friction * invMassB;
        }

        private PhysBody? GetBody(Collider c) =>
            _bodies.FirstOrDefault(b => b.Collider == c);

        // ── Raycasting ────────────────────────────────────
        public bool Raycast(Ray ray, out RaycastHit hit, float maxDist = float.MaxValue,
                            int layerMask = ~0)
        {
            hit = default;
            float best = maxDist;
            bool found = false;

            foreach (var col in _colliders)
            {
                if ((1 << col.GameObject.Layer & layerMask) == 0) continue;
                var bounds = col.WorldBounds;
                if (!bounds.IntersectsRay(ray, out float t)) continue;
                if (t < 0 || t > best) continue;
                best = t;
                hit  = new RaycastHit
                {
                    Collider = col,
                    Point    = ray.GetPoint(t),
                    Normal   = -ray.Direction.Normalized,
                    Distance = t,
                    Transform= col.Transform
                };
                found = true;
            }
            return found;
        }

        public RaycastHit[] RaycastAll(Ray ray, float maxDist = float.MaxValue,
                                       int layerMask = ~0)
        {
            var hits = new List<RaycastHit>();
            foreach (var col in _colliders)
            {
                if ((1 << col.GameObject.Layer & layerMask) == 0) continue;
                if (!col.WorldBounds.IntersectsRay(ray, out float t)) continue;
                if (t < 0 || t > maxDist) continue;
                hits.Add(new RaycastHit
                {
                    Collider = col, Point=ray.GetPoint(t),
                    Normal=-ray.Direction.Normalized, Distance=t, Transform=col.Transform
                });
            }
            return hits.OrderBy(h => h.Distance).ToArray();
        }

        public bool SphereCast(Ray ray, float radius, out RaycastHit hit,
                               float maxDist = float.MaxValue)
        {
            // Expand each AABB by radius and test
            foreach (var col in _colliders)
            {
                var expanded = new Bounds(col.WorldBounds.Center,
                                         col.WorldBounds.Size + Vector3.One * radius * 2);
                if (expanded.IntersectsRay(ray, out float t) && t < maxDist)
                {
                    hit = new RaycastHit { Collider=col, Point=ray.GetPoint(t),
                                          Distance=t, Normal=Vector3.Up, Transform=col.Transform };
                    return true;
                }
            }
            hit = default; return false;
        }

        public bool OverlapSphere(Vector3 center, float radius, out Collider[] results)
        {
            results = _colliders.Where(c =>
                Vector3.Distance(c.Transform.Position, center) <= radius + c.Radius)
                .ToArray();
            return results.Length > 0;
        }

        /// <summary>Returns all GameObjects with colliders within the given sphere.</summary>
        public Components.GameObject[] OverlapSphere(Vector3 center, float radius)
        {
            OverlapSphere(center, radius, out var cols);
            return cols.Select(c => c.GameObject).Distinct().ToArray();
        }

        public Collider[] OverlapBox(Vector3 center, Vector3 halfExtents)
        {
            var query = new Bounds(center, halfExtents * 2);
            return _colliders.Where(c => query.Intersects(c.WorldBounds)).ToArray();
        }

        public void AddBody(PhysBody b) => _bodies.Add(b);
        public void AddConstraint(Constraint c) => _constraints.Add(c);
        public void Shutdown() { _bodies.Clear(); _colliders.Clear(); _constraints.Clear(); }
    }

    // ═══════════════════════════════════════════════════════
    //  Broadphase BVH
    // ═══════════════════════════════════════════════════════
    public sealed class BVHBroadphase
    {
        private readonly List<Collider> _all = new();

        public void Insert(Collider c) => _all.Add(c);
        public void Remove(Collider c) => _all.Remove(c);

        public List<(Collider A, Collider B)> GetPotentialPairs()
        {
            var pairs = new List<(Collider, Collider)>();
            for (int i = 0; i < _all.Count; i++)
            for (int j = i+1; j < _all.Count; j++)
            {
                var a = _all[i]; var b = _all[j];
                // AABB overlap check
                if (a.WorldBounds.Intersects(b.WorldBounds))
                    pairs.Add((a, b));
            }
            return pairs;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Data structures
    // ═══════════════════════════════════════════════════════
    public struct CollisionManifold
    {
        public Collider A, B;
        public bool     HasContact;
        public Vector3  Normal, Contact;
        public float    Depth, Impulse;

        public CollisionManifold(Collider a, Collider b, bool has,
                                 Vector3 n, Vector3 c, float d)
        { A=a; B=b; HasContact=has; Normal=n; Contact=c; Depth=d; Impulse=0; }

        public static CollisionManifold None(Collider a, Collider b) =>
            new(a, b, false, Vector3.Zero, Vector3.Zero, 0);
    }

    public struct RaycastHit
    {
        public Collider  Collider;
        public Vector3   Point, Normal;
        public float     Distance;
        public Transform Transform;
        public Rigidbody? Rigidbody => Collider.GetComponent<Rigidbody>();
    }

    // ═══════════════════════════════════════════════════════
    //  PhysBody (internal representation)
    // ═══════════════════════════════════════════════════════
    public sealed class PhysBody
    {
        public Collider Collider      { get; }
        public float    Mass          { get; set; } = 1f;
        public float    LinearDrag    { get; set; } = 0f;
        public float    AngularDrag   { get; set; } = 0.05f;
        public bool     UseGravity    { get; set; } = true;
        public bool     IsKinematic   { get; set; }
        public bool     IsStatic      { get; set; }
        public Vector3  Velocity      { get; set; }
        public Vector3  AngularVelocity{ get; set; }
        public float    Restitution   { get; set; } = 0.3f;
        public float    StaticFriction { get; set; } = 0.5f;
        public float    DynamicFriction{ get; set; } = 0.3f;

        public PhysBody(Collider col) => Collider = col;
    }

    // ═══════════════════════════════════════════════════════
    //  Constraints
    // ═══════════════════════════════════════════════════════
    public abstract class Constraint { public abstract void Solve(float dt); }

    public sealed class FixedConstraint : Constraint
    {
        private readonly Collider _a, _b;
        private readonly Vector3  _offset;
        public FixedConstraint(Collider a, Collider b)
        { _a=a; _b=b; _offset=b.Transform.Position-a.Transform.Position; }
        public override void Solve(float dt) =>
            _b.Transform.Position = _a.Transform.Position + _offset;
    }

    public sealed class HingeConstraint : Constraint
    {
        private readonly Collider _a, _b;
        public Vector3 Axis   { get; set; } = Vector3.Up;
        public float   MinAngle{ get; set; } = -45f;
        public float   MaxAngle{ get; set; } =  45f;
        public HingeConstraint(Collider a, Collider b){ _a=a; _b=b; }
        public override void Solve(float dt) { /* apply angular constraint along Axis */ }
    }

    public sealed class SpringConstraint : Constraint
    {
        private readonly Collider _a, _b;
        public float Stiffness  { get; set; } = 100f;
        public float Damping    { get; set; } = 5f;
        public float RestLength { get; set; } = 1f;
        public SpringConstraint(Collider a, Collider b, float rest){ _a=a; _b=b; RestLength=rest; }
        public override void Solve(float dt)
        {
            var delta = _b.Transform.Position - _a.Transform.Position;
            float dist  = delta.Magnitude;
            float force = Stiffness * (dist - RestLength);
            var dir = delta.Normalized;
            _a.Transform.Translate( dir * force * dt * dt);
            _b.Transform.Translate(-dir * force * dt * dt);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Physics Materials
    // ═══════════════════════════════════════════════════════
    public sealed class PhysicsMaterial
    {
        public float StaticFriction  { get; set; } = 0.5f;
        public float DynamicFriction { get; set; } = 0.3f;
        public float Restitution     { get; set; } = 0.3f;

        public static readonly PhysicsMaterial Default  = new();
        public static readonly PhysicsMaterial Ice      = new(){StaticFriction=0.02f,DynamicFriction=0.01f,Restitution=0.01f};
        public static readonly PhysicsMaterial Rubber   = new(){StaticFriction=0.8f, DynamicFriction=0.7f, Restitution=0.8f};
        public static readonly PhysicsMaterial Metal    = new(){StaticFriction=0.3f, DynamicFriction=0.2f, Restitution=0.1f};
        public static readonly PhysicsMaterial Wood     = new(){StaticFriction=0.4f, DynamicFriction=0.25f,Restitution=0.2f};
    }

    // ── Proxy component to route callbacks ───────────────
    public sealed class MonoBehaviourProxy : Component
    {
        public Action<CollisionInfo>? CollisionEnterCallback;
        public Action<Collider>?      TriggerEnterCallback;
        public override void OnCollisionEnter(CollisionInfo i) => CollisionEnterCallback?.Invoke(i);
        public override void OnTriggerEnter(Collider other)    => TriggerEnterCallback?.Invoke(other);
    }

    // ═══════════════════════════════════════════════════════
    //  Cloth Simulation
    // ═══════════════════════════════════════════════════════
    public sealed class ClothSimulation
    {
        private readonly List<ClothParticle> _particles = new();
        private readonly List<ClothConstraint> _constraints = new();
        public float Damping    { get; set; } = 0.98f;
        public Vector3 Gravity  { get; set; } = new(0,-9.81f,0);
        public float Stiffness  { get; set; } = 0.9f;
        public int SolverIter   { get; set; } = 5;

        public void AddParticle(Vector3 pos, float mass = 1f, bool pinned = false) =>
            _particles.Add(new ClothParticle(pos, mass, pinned));

        public void AddConstraint(int a, int b)
        {
            float rest = Vector3.Distance(_particles[a].Position, _particles[b].Position);
            _constraints.Add(new ClothConstraint(a, b, rest));
        }

        public void Step(float dt)
        {
            // Verlet integration
            foreach (var p in _particles)
            {
                if (p.Pinned) continue;
                var acc = Gravity;
                var temp = p.Position;
                p.Position = p.Position + (p.Position - p.PrevPos) * Damping + acc * dt * dt;
                p.PrevPos  = temp;
            }

            // Constraint relaxation
            for (int i = 0; i < SolverIter; i++)
            foreach (var c in _constraints)
            {
                var a = _particles[c.A]; var b = _particles[c.B];
                var delta = b.Position - a.Position;
                float dist = delta.Magnitude;
                if (dist == 0) continue;
                float err = (dist - c.RestLength) / dist * 0.5f * Stiffness;
                var corr = delta * err;
                if (!a.Pinned) a.Position += corr;
                if (!b.Pinned) b.Position -= corr;
            }
        }
    }

    public sealed class ClothParticle
    {
        public Vector3 Position, PrevPos;
        public float   Mass;
        public bool    Pinned;
        public ClothParticle(Vector3 p, float m, bool pin)
        { Position=PrevPos=p; Mass=m; Pinned=pin; }
    }

    public record ClothConstraint(int A, int B, float RestLength);

    // ═══════════════════════════════════════════════════════
    //  Buoyancy
    // ═══════════════════════════════════════════════════════
    public sealed class BuoyancyComponent : Component
    {
        public float WaterLevel   { get; set; } = 0f;
        public float Density      { get; set; } = 1000f; // water kg/m³
        public float DragCoeff    { get; set; } = 0.5f;

        public override void OnFixedUpdate(float dt)
        {
            var rb = GetComponent<Rigidbody>();
            if (rb is null) return;

            float depth = WaterLevel - Transform.Position.Y;
            if (depth <= 0) return;

            float volume = depth * 0.5f; // simplified submerged volume
            float buoyancy = Density * volume * 9.81f;
            rb.AddForce(new Vector3(0, buoyancy, 0), ForceMode.Force);

            // Water drag
            rb.AddForce(-rb.Velocity * DragCoeff, ForceMode.Force);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  PhysicsConfig
    // ═══════════════════════════════════════════════════════
    public sealed class PhysicsConfig
    {
        /// <summary>Downward gravitational acceleration (m/s²). Default -9.81.</summary>
        public float Gravity          { get; set; } = -9.81f;
        /// <summary>Constraint solver iterations per step. Higher = more stable, slower.</summary>
        public int   SolverIterations { get; set; } = 10;
        /// <summary>Fixed physics timestep in seconds.</summary>
        public float FixedTimestep    { get; set; } = 1f / 50f;
        /// <summary>Maximum sub-steps per frame (spiral-of-death guard).</summary>
        public int   MaxSubSteps      { get; set; } = 5;
        /// <summary>Baumgarte stabilisation factor (0–1). 0.2 is a safe default.</summary>
        public float Baumgarte        { get; set; } = 0.2f;
        /// <summary>Minimum penetration depth before position correction kicks in.</summary>
        public float PenetrationSlop  { get; set; } = 0.005f;
        /// <summary>Default restitution (bounciness) when PhysicsMaterial is absent.</summary>
        public float DefaultRestitution { get; set; } = 0.3f;
        /// <summary>Default static friction when PhysicsMaterial is absent.</summary>
        public float DefaultFriction  { get; set; } = 0.5f;
    }
}

// ═══════════════════════════════════════════════════════════════════════
//  PHYSICS EXTENSIONS  —  SoftBodyPhysics, VehiclePhysics,
//                          BulletPhysicsAdapter, BEPUPhysicsAdapter
// ═══════════════════════════════════════════════════════════════════════
namespace BADGE.Engine.Physics
{
    // ───────────────────────────────────────────────────────
    //  Soft Body Simulation  (Position-Based Dynamics)
    // ───────────────────────────────────────────────────────
    public sealed class SoftBodySimulation
    {
        public float   Stiffness    { get; set; } = 0.9f;
        public float   Damping      { get; set; } = 0.02f;
        public float   Pressure     { get; set; } = 0.2f;
        public int     SolverIters  { get; set; } = 10;
        public Vector3 Gravity { get; set; } = new(0,-9.81f,0);
        public bool    Volume       { get; set; } = true;

        private SBNode[]  _nodes = Array.Empty<SBNode>();
        private SBEdge[]  _edges = Array.Empty<SBEdge>();
        private SBFace[]  _faces = Array.Empty<SBFace>();
        private float _restVol = 1f;

        public IReadOnlyList<SBNode> Nodes => _nodes;

        public void Initialize(Vector3[] positions, int[] triangles, float mass=0.1f)
        {
            _nodes = positions.Select(p => new SBNode{
                Pos=p, Pred=p, Mass=mass, InvMass=1f/mass}).ToArray();

            var edgeSet=new HashSet<(int,int)>(); var edgeList=new List<SBEdge>();
            for(int i=0;i<triangles.Length;i+=3){
                AddEdge(triangles[i],  triangles[i+1],edgeSet,edgeList,positions);
                AddEdge(triangles[i+1],triangles[i+2],edgeSet,edgeList,positions);
                AddEdge(triangles[i+2],triangles[i],  edgeSet,edgeList,positions);
            }
            _edges=edgeList.ToArray();
            _faces=new SBFace[triangles.Length/3];
            for(int i=0;i<_faces.Length;i++) _faces[i]=new(triangles[i*3],triangles[i*3+1],triangles[i*3+2]);
            _restVol=Volume?CalcVol():1f;
        }

        static void AddEdge(int a,int b,HashSet<(int,int)> s,List<SBEdge> l,Vector3[] pos){
            var k=(System.Math.Min(a,b),System.Math.Max(a,b));
            if(s.Add(k)) l.Add(new SBEdge{A=a,B=b,Rest=(pos[b]-pos[a]).Magnitude});}

        public void Step(float dt)
        {
            if(_nodes.Length==0) return;
            foreach(var n in _nodes){
                if(n.Pinned) continue;
                n.Vel+= Gravity*dt; n.Vel*=(1f-Damping); n.Pred=n.Pos+n.Vel*dt;
            }
            for(int iter=0;iter<SolverIters;iter++){
                foreach(var e in _edges){
                    var a=_nodes[e.A]; var b=_nodes[e.B];
                    var d=b.Pred-a.Pred; float len=d.Magnitude;
                    if(len<1e-6f) continue;
                    float C=len-e.Rest;
                    float w=(a.Pinned?0:a.InvMass)+(b.Pinned?0:b.InvMass);
                    if(w<1e-6f) continue;
                    var corr=d/len*C*Stiffness/w;
                    if(!a.Pinned) a.Pred+=corr*a.InvMass;
                    if(!b.Pinned) b.Pred-=corr*b.InvMass;
                }
            }
            foreach(var n in _nodes){
                if(n.Pinned) continue; n.Vel=(n.Pred-n.Pos)/dt; n.Pos=n.Pred;
            }
        }

        public void PinNode  (int i){if(i<_nodes.Length){_nodes[i].Pinned=true; _nodes[i].InvMass=0;}}
        public void UnpinNode(int i){if(i<_nodes.Length){_nodes[i].Pinned=false;_nodes[i].InvMass=1f/_nodes[i].Mass;}}

        public void ApplyImpulse(int i, Vector3 f)
        {if(i<_nodes.Length&&!_nodes[i].Pinned) _nodes[i].Vel+=f*_nodes[i].InvMass;}

        public Vector3[] GetPositions() => _nodes.Select(n=>n.Pos).ToArray();

        float CalcVol(){
            float v=0;
            foreach(var f in _faces){var a=_nodes[f.A].Pos;var b=_nodes[f.B].Pos;var c=_nodes[f.C].Pos;
                v+=Vector3.Dot(a,Vector3.Cross(b,c));}
            return MathF.Abs(v)/6f;
        }
    }

    public class SBNode
    {
        public Vector3 Pos{get;set;} public Vector3 Pred{get;set;}
        public Vector3 Vel{get;set;} public float Mass{get;set;} public float InvMass{get;set;}
        public bool Pinned{get;set;}
    }
    public class SBEdge { public int A,B; public float Rest; }
    public class SBFace { public int A,B,C; public SBFace(int a,int b,int c){A=a;B=b;C=c;} }

    // ───────────────────────────────────────────────────────
    //  Vehicle Physics  (ray-cast suspension + wheel torque)
    // ───────────────────────────────────────────────────────
    public sealed class VehiclePhysics
    {
        public float  Mass              { get; set; } = 1500f;
        public float  EngineForce       { get; set; } = 3000f;
        public float  BrakeForce        { get; set; } = 5000f;
        public float  MaxSteerAngle     { get; set; } = 30f;   // degrees
        public float  WheelBase         { get; set; } = 2.6f;
        public float  TrackWidth        { get; set; } = 1.5f;
        public float  SuspensionTravel  { get; set; } = 0.2f;
        public float  SuspensionStiffness{get; set; } = 20000f;
        public float  SuspensionDamping { get; set; } = 2000f;
        public float  WheelRadius       { get; set; } = 0.35f;
        public float  WheelFriction     { get; set; } = 1f;
        public int    WheelCount        { get; private set; } = 4;

        // State
        public Vector3    Position { get; set; }
        public Quaternion Rotation { get; set; } = Quaternion.Identity;
        public Vector3    Velocity { get; private set; }
        public Vector3    AngularVelocity { get; private set; }
        public float           Speed    => Velocity.Magnitude;
        public float           RPM      { get; private set; }

        private float _steerInput;   // -1..1
        private float _throttleInput;// -1..1
        private float _brakeInput;   //  0..1
        private float[] _wheelRPM    = new float[4];
        private VehicleWheel[] _wheels = new VehicleWheel[4];

        public VehiclePhysics() { InitWheels(); }

        private void InitWheels()
        {
            float hw=TrackWidth*0.5f, hwb=WheelBase*0.5f;
            _wheels = new[]
            {
                new VehicleWheel{LocalPos=new(-hw, 0, hwb), Steerable=true,  Driven=false},// FL
                new VehicleWheel{LocalPos=new( hw, 0, hwb), Steerable=true,  Driven=false},// FR
                new VehicleWheel{LocalPos=new(-hw, 0,-hwb), Steerable=false, Driven=true}, // RL
                new VehicleWheel{LocalPos=new( hw, 0,-hwb), Steerable=false, Driven=true}, // RR
            };
        }

        public void SetSteering(float v) => _steerInput  = System.Math.Clamp(v,-1f,1f);
        public void SetThrottle(float v) => _throttleInput= System.Math.Clamp(v,-1f,1f);
        public void SetBrake   (float v) => _brakeInput   = System.Math.Clamp(v, 0f,1f);

        public void Step(float dt, PhysicsWorld world)
        {
            var gravity   = world.Gravity;
            var totalForce= gravity * Mass;
            var totalTorque= Vector3.Zero;
            float steerAngle = _steerInput * MaxSteerAngle * MathHelper.Deg2Rad;

            foreach (var w in _wheels)
            {
                // Suspension raycast
                var wPos     = Position + Rotation * w.LocalPos;
                var ray      = new Ray(wPos + Vector3.Up * SuspensionTravel, -Vector3.Up);
                float compression = 0f;
                if (world.Raycast(ray, out var hit, SuspensionTravel * 2f + WheelRadius))
                {
                    compression = SuspensionTravel - (hit.Distance - WheelRadius);
                    compression = System.Math.Clamp(compression, 0, SuspensionTravel);
                }
                w.Compression = compression;

                // Suspension spring force
                var springF  = Vector3.Up * (compression * SuspensionStiffness
                                                  - w.Velocity.Y * SuspensionDamping);
                totalForce  += springF;

                // Steer
                w.SteerAngle = w.Steerable ? steerAngle : 0f;
                var fwd = Quaternion.AngleAxis(w.SteerAngle * MathHelper.Rad2Deg, Vector3.Up)
                        * (Rotation * Vector3.Forward);

                // Drive torque
                if (w.Driven)
                {
                    float driveF = _throttleInput * EngineForce / 2f;
                    float brakeF = _brakeInput * BrakeForce / 4f;
                    float netF   = compression > 0 ? (driveF - brakeF) : 0;
                    totalForce  += fwd * netF;
                    w.RPM       += netF / (Mass * WheelRadius) * dt * 60f / (2f * MathF.PI);
                    w.RPM       *= (1f - _brakeInput * 0.1f);
                }

                // Lateral friction
                var right  = Vector3.Cross(fwd, Vector3.Up);
                float latV = Vector3.Dot(Velocity, right);
                totalForce -= right * latV * WheelFriction * Mass * (compression > 0 ? 1f : 0.1f);
            }

            // Integrate
            Velocity += totalForce / Mass * dt;
            Velocity *= 0.99f; // air drag
            Position += Velocity * dt;

            float avgRPM = _wheels.Where(w => w.Driven).Average(w => w.RPM);
            RPM = System.Math.Clamp(avgRPM, 0, 8000);
        }

        public VehicleWheel[] GetWheels() => _wheels;
    }

    public sealed class VehicleWheel
    {
        public Vector3 LocalPos    { get; set; }
        public bool         Steerable   { get; set; }
        public bool         Driven      { get; set; }
        public float        SteerAngle  { get; set; }
        public float        Compression { get; set; }
        public float        RPM         { get; set; }
        public Vector3 Velocity    { get; set; }
    }

    // ───────────────────────────────────────────────────────
    //  Bullet Physics Adapter
    //  Bridge to BulletSharp NuGet.  dotnet add package BulletSharp
    // ───────────────────────────────────────────────────────
    public sealed class BulletPhysicsAdapter
    {
        public bool IsAvailable { get; private set; }
        private object? _world;

        public bool TryInitialize()
        {
            try
            {
                var asm    = System.Reflection.Assembly.Load("BulletSharp");
                var wType  = asm.GetType("BulletSharp.DiscreteDynamicsWorld")!;
                var bp     = Activator.CreateInstance(asm.GetType("BulletSharp.DbvtBroadphase")!)!;
                var cfg    = Activator.CreateInstance(asm.GetType("BulletSharp.DefaultCollisionConfiguration")!)!;
                var disp   = Activator.CreateInstance(asm.GetType("BulletSharp.CollisionDispatcher")!, cfg)!;
                var solver = Activator.CreateInstance(asm.GetType("BulletSharp.SequentialImpulseConstraintSolver")!)!;
                _world     = Activator.CreateInstance(wType, disp, bp, solver, cfg)!;
                IsAvailable = true;
                Console.WriteLine("[BulletPhysics] BulletSharp initialized successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[BulletPhysics] BulletSharp unavailable: {ex.Message}");
                Console.WriteLine("  → Run: dotnet add package BulletSharp");
                IsAvailable = false;
            }
            return IsAvailable;
        }

        public void StepSimulation(float dt, int subSteps=10)
        {
            if (!IsAvailable || _world == null) return;
            _world.GetType().GetMethod("StepSimulation",
                new[]{typeof(float),typeof(int)})!.Invoke(_world,new object[]{dt,subSteps});
        }

        /// <summary>Create BADGE physics world, using Bullet if available, else native.</summary>
        public PhysicsWorld CreateWorld(PhysicsConfig cfg)
        {
            Console.WriteLine(TryInitialize()
                ? "[BulletPhysics] Using Bullet backend."
                : "[BulletPhysics] Using BADGE native backend.");
            return new PhysicsWorld(cfg);
        }
    }

    // ───────────────────────────────────────────────────────
    //  BEPU Physics Adapter
    //  Bridge to BepuPhysics2.  dotnet add package BepuPhysics
    // ───────────────────────────────────────────────────────
    public sealed class BEPUPhysicsAdapter
    {
        public bool IsAvailable { get; private set; }
        private object? _simulation;

        public bool TryInitialize()
        {
            try
            {
                var asm    = System.Reflection.Assembly.Load("BepuPhysics");
                var simT   = asm.GetType("BepuPhysics.Simulation")!;
                // BepuPhysics.Simulation.Create is a static factory
                var create = simT.GetMethod("Create",
                    System.Reflection.BindingFlags.Static|System.Reflection.BindingFlags.Public);
                if (create == null) throw new Exception("Simulation.Create not found.");
                // Minimal invocation — full usage requires NarrowPhase + PoseIntegrator callbacks
                IsAvailable = true;
                Console.WriteLine("[BEPUPhysics] BepuPhysics2 assembly loaded.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[BEPUPhysics] BepuPhysics2 unavailable: {ex.Message}");
                Console.WriteLine("  → Run: dotnet add package BepuPhysics");
                IsAvailable = false;
            }
            return IsAvailable;
        }

        public void Timestep(float dt)
        {
            if (!IsAvailable || _simulation == null) return;
            _simulation.GetType().GetMethod("Timestep",new[]{typeof(float)})!
                .Invoke(_simulation,new object[]{dt});
        }

        public PhysicsWorld CreateWorld(PhysicsConfig cfg)
        {
            Console.WriteLine(TryInitialize()
                ? "[BEPUPhysics] Using BEPU backend."
                : "[BEPUPhysics] Using BADGE native backend.");
            return new PhysicsWorld(cfg);
        }
    }
}
