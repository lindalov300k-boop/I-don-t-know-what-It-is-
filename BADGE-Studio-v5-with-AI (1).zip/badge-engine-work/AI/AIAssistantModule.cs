// ============================================================
//  BADGE Engine – AI/AIAssistantModule.cs
//  Full in-engine AI chatbot tab, ported from JSX to C#.
//
//  Features:
//    • Three-tab UI  →  Code Chat  |  Asset Finder  |  Project Panel
//    • Grounds answers with live GitHub + Stack Exchange context
//    • Calls Anthropic Claude with the full BADGE API reference
//      embedded in the system prompt (no invented APIs)
//    • Returns real code; never returns "(no response)"
//    • Registered as a first-class IEditorModule tab ("AI Assistant")
//
//  Set env var ANTHROPIC_API_KEY before launching the editor.
//  Optionally set GITHUB_TOKEN to raise GitHub rate limits.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;
using BADGE.Editor;
using BADGE.UIUXToolkit;

namespace BADGE.Engine.AI
{
    // ══════════════════════════════════════════════════════════
    //  Data types
    // ══════════════════════════════════════════════════════════

    public enum ChatRole   { User, Assistant, System }
    public enum AssetKind  { GitHub, OpenGameArt, Kenney }
    public enum ChatTabId  { CodeChat, Assets, Project }

    public sealed record ChatMessage(ChatRole Role, string Text, List<AssetReference>? Sources = null)
    {
        public DateTime Timestamp { get; } = DateTime.UtcNow;
    }

    public sealed class AssetReference
    {
        public string    Name     { get; set; } = string.Empty;
        public string    Url      { get; set; } = string.Empty;
        public string    Source   { get; set; } = string.Empty;
        public string    Type     { get; set; } = string.Empty;
        public string    License  { get; set; } = string.Empty;
        public string    Emoji    { get; set; } = "📦";
        public AssetKind Kind     { get; set; }
    }

    // ══════════════════════════════════════════════════════════
    //  Embedded BADGE API Reference  (system-prompt knowledge)
    // ══════════════════════════════════════════════════════════

    internal static class BadgeApiReference
    {
        // Full reference injected as system-prompt context so the AI
        // never invents APIs or uses wrong namespaces.
        internal const string Text = @"
=== BADGE STUDIO API REFERENCE v1.0.0 (.NET 8 / C#) ===

ARCHITECTURE
  Hardware/OS → Kernel (boot, MemoryAllocator) → Engine (main loop, modules)
  → EngineKernel facade (SceneManager, Physics, Audio, Input, Events)

NAMESPACES
  BADGE.Engine.Math         Vector2/3/4, Quaternion, Matrix4, Color, Bounds, Ray, Mathf
  BADGE.Engine.Components   GameObject, Component, Transform, Camera, Rigidbody, Colliders
  BADGE.Engine.Scene        Scene, SceneManager, Prefab, Object
  BADGE.Engine.Physics      PhysicsWorld, RaycastHit, ForceMode, Constraints
  BADGE.Engine.Audio        AudioEngine, AudioClip, AudioChannel, DSP chain
  BADGE.Engine.Input        InputManager, KeyCode, MouseButton, GamepadButton
  BADGE.Engine.Animation    AnimatorController, AnimationClip, BlendTree, IK
  BADGE.Engine.AI           NavMeshAgent, BehaviorTree, SteeringAgent, GameDevAssistant
  BADGE.Engine.SDK          GameApplication, EnginePlugin, IEditorExtension
  BADGE.Runtime             Time.DeltaTime, Time.TotalTime, Time.TimeScale, Time.FPS
  BADGE.Editor              EditorSystem, IEditorModule, EditorPanel
  BADGE.UIUXToolkit         Panel, ScrollPanel, Button, Label, TextInput, ProgressBar

GETTING STARTED
  // Minimal game
  public class MyGame : GameApplication {
      protected override void OnInitialize() {
          var scene = new Scene(""Main"");
          var cube  = new GameObject(""Cube"");
          cube.AddComponent<BoxCollider>().Size = Vector3.One;
          cube.AddComponent<Rigidbody>().Mass   = 1f;
          scene.AddGameObject(cube);
          Kernel.SceneManager.RegisterScene(""Main"", scene);
          Kernel.SceneManager.LoadScene(""Main"");
      }
  }
  new MyGame().Run(new EngineConfig { TargetFPS = 60 });

SCRIPTBEHAVIOUR (NOT MonoBehaviour)
  public class Rotator : ScriptBehaviour {
      public float Speed = 90f;
      public override void OnUpdate(float dt) => Transform.Rotate(new Vector3(0, Speed*dt, 0));
  }
  go.AddComponent<Rotator>().Speed = 120f;

ENGINE KERNEL FACADE
  EngineKernel.Instance.SceneManager  – scene loading/unloading
  EngineKernel.Instance.Physics       – raycasts, overlap queries
  EngineKernel.Instance.Audio         – play/stop/spatial audio
  EngineKernel.Instance.Input         – keyboard/mouse/gamepad
  EngineKernel.Instance.Events        – subscribe/publish events
  EngineKernel.Instance.Scheduler     – coroutines, deferred calls

MATH LIBRARY
  Vector2(x,y)  Vector3(x,y,z)  Vector4(x,y,z,w)  Quaternion(x,y,z,w)
  Vector3.Zero/One/Up/Down/Forward/Back/Left/Right
  Quaternion.Identity / Euler(x,y,z) / LookRotation(fwd,up)
  Mathf.Lerp / Clamp / Sin / Cos / Sqrt / Approximately / PingPong
  Color(r,g,b,a)  Ray(origin,dir)  Bounds(center,size)  Matrix4

GAMEOBJECT
  var go = new GameObject(""Name"");
  go.AddComponent<T>()        – attach component, returns T
  go.GetComponent<T>()        – returns T or null
  go.GetComponentInChildren<T>()
  go.Find(""ChildName"")        – find child by name
  go.SetActive(bool)
  go.Tag  go.Layer  go.Name
  Object.Destroy(go)  Object.Destroy(go, delay)
  Object.DontDestroyOnLoad(go)

COMPONENT LIFECYCLE
  OnAwake()               – called once on AddComponent
  OnStart()               – called once before first frame
  OnUpdate(float dt)      – called every frame
  OnFixedUpdate(float dt) – called at fixed physics rate (50 Hz default)
  OnLateUpdate(float dt)  – after all OnUpdates
  OnDestroy()
  OnCollisionEnter(CollisionInfo info)
  OnCollisionStay(CollisionInfo info)
  OnCollisionExit(CollisionInfo info)
  OnTriggerEnter/Stay/Exit(CollisionInfo info)

TRANSFORM
  Transform.Position  (Vector3 get/set)
  Transform.Rotation  (Quaternion get/set)
  Transform.Scale     (Vector3 get/set)
  Transform.Forward / Right / Up   (read-only world-space axes)
  Transform.Translate(Vector3 delta, Space = World)
  Transform.Rotate(Vector3 eulerDelta, Space = Self)
  Transform.LookAt(Vector3 target)
  Transform.Parent    (Transform? get/set)

RIGIDBODY
  rb.Velocity        (Vector3 get/set)
  rb.AngularVelocity (Vector3 get/set)
  rb.Mass            (float)
  rb.Drag / AngularDrag
  rb.UseGravity      (bool)
  rb.IsKinematic     (bool)
  rb.AddForce(Vector3 force, ForceMode mode = Force)
  rb.AddTorque(Vector3 torque, ForceMode mode = Force)
  ForceMode: Force | Impulse | Acceleration | VelocityChange

COLLIDERS (all share IsTrigger, PhysicsMaterial, Layer)
  BoxCollider       .Size (Vector3)
  SphereCollider    .Radius (float)
  CapsuleCollider   .Radius, .Height
  MeshCollider      .Mesh

PHYSICS
  var hit = EngineKernel.Instance.Physics;
  hit.Raycast(ray, out RaycastHit h, maxDist)          → bool
  hit.RaycastAll(ray, maxDist)                          → RaycastHit[]
  hit.SphereCast(ray, radius, out RaycastHit h, maxDist)→ bool
  hit.OverlapSphere(center, radius)                     → Collider[]
  RaycastHit: .Point .Normal .Distance .Transform .Collider
  Additional: ClothSimulator, FluidBody, VehicleController

SCENE
  var scene = new Scene(""Level1"");
  scene.AddGameObject(go)
  scene.RemoveGameObject(go)
  scene.FindGameObject(""Name"")    → GameObject?
  scene.GetAllGameObjects()        → IEnumerable<GameObject>
  SceneManager.RegisterScene(name, scene)
  SceneManager.LoadScene(name, LoadSceneMode.Single/Additive)
  await SceneManager.LoadSceneAsync(name, mode)
  SceneManager.UnloadScene(name)
  SceneManager.DontDestroyOnLoad(go)
  Prefab.Instantiate(prefab, position, rotation) → GameObject

AUDIO
  var clip = AudioClip.Load(""Assets/Sounds/jump.wav"");
  var ch   = EngineKernel.Instance.Audio.PlayOneShot(clip);
  var ch3d = EngineKernel.Instance.Audio.PlaySpatial(clip, position);
  ch.Volume  (0–1)   ch.Pitch (0.5–2)  ch.Loop  ch.Play() ch.Stop()
  ch.Reverb.Enabled  ch.Reverb.WetLevel  ch.Reverb.RoomSize
  ch.EQ.LowGain / MidGain / HighGain
  ch.Compressor.Threshold / Ratio / Attack / Release
  ch.Delay.DelayTime / Feedback / WetLevel

INPUT
  var inp = EngineKernel.Instance.Input;
  inp.GetKey(KeyCode.Space)        – held down
  inp.GetKeyDown(KeyCode.Space)    – pressed this frame
  inp.GetKeyUp(KeyCode.Space)      – released this frame
  inp.GetAxis(""Horizontal"")       – -1 to 1 (WASD/arrows)
  inp.GetAxis(""Vertical"")
  inp.GetMouseButton(MouseButton.Left)
  inp.MousePosition                – Vector2
  inp.LockCursor(bool)
  inp.GetGamepadButton(GamepadButton.A, playerIndex)

ANIMATION
  var anim = go.AddComponent<AnimatorController>();
  anim.AddState(""Idle"", idleClip)
  anim.AddTransition(""Idle"",""Run"",  ()=>speed>0.1f)
  anim.SetFloat(""Speed"", value)
  anim.SetBool(""IsGrounded"", true)
  anim.Play(""StateName"")
  BlendTree: 1D (speed→walk/run) or 2D (x/y direction)
  IK: TwoBoneIK.Solve(root, mid, tip, target, hint, weight)
  Timeline: SequenceClip with PropertyTrack<T> keyframes

AI / PATHFINDING
  var agent = go.AddComponent<NavMeshAgent>();
  agent.SetDestination(targetPos)
  agent.Speed  agent.StoppingDistance  agent.RemainingDistance
  agent.IsStopped  agent.ResetPath()
  BehaviorTree: new BTSequence(new BTLeaf(HasTarget), new BTLeaf(MoveToTarget))
  SteeringAgent: agent.Seek(target) / Flee / Arrive / Wander / AvoidObstacles

RUNTIME TIME
  Time.DeltaTime     – seconds since last frame
  Time.TotalTime     – total elapsed seconds
  Time.TimeScale     – 0 = paused, 1 = normal, 2 = double-speed
  Time.FPS           – current frames-per-second

SDK
  Subclass GameApplication: OnInitialize(), OnShutdown()
  Kernel property provides EngineKernel
  Subclass EnginePlugin: Name/Version/Author props, OnInit(), OnShutdown()
  IEditorExtension: TabName, OnOpen(), OnClose(), OnGUI()

EDITOR
  IEditorModule: Name, Icon, IsOpen, Open(), Close(), Update(dt), DrawUI(), OnShortcut(s)
  EditorSystem.Instance.RegisterModule(module)
  EditorsRegistry.Instance.Register(module)

CODE RECIPES
  // Platformer controller
  public class PlatformerController : ScriptBehaviour {
      public float MoveSpeed = 6f, JumpForce = 9f;
      private Rigidbody _rb; private bool _grounded;
      public override void OnStart() => _rb = GetComponent<Rigidbody>();
      public override void OnFixedUpdate(float dt) {
          float h = EngineKernel.Instance.Input.GetAxis(""Horizontal"");
          _rb.Velocity = new Vector3(h*MoveSpeed, _rb.Velocity.Y, 0);
          if (_grounded && EngineKernel.Instance.Input.GetKeyDown(KeyCode.Space))
              _rb.AddForce(Vector3.Up * JumpForce, ForceMode.Impulse);
      }
      public override void OnCollisionEnter(CollisionInfo info)
          => _grounded = Vector3.Dot(info.Normal, Vector3.Up) > 0.7f;
      public override void OnCollisionExit(CollisionInfo info)
          => _grounded = false;
  }

  // Raycast interaction
  var ray = new Ray(Transform.Position, Transform.Forward);
  if (EngineKernel.Instance.Physics.Raycast(ray, out var hit, maxDist: 5f))
      hit.Transform.GetComponent<IInteractable>()?.Interact(this);

  // Spatial audio on hit
  public override void OnCollisionEnter(CollisionInfo info) {
      var clip = AudioClip.Load(""Assets/Sounds/impact.wav"");
      var ch   = EngineKernel.Instance.Audio.PlaySpatial(clip, Transform.Position);
      ch.Volume = Mathf.Clamp(info.Impulse / 100f, 0.1f, 1f);
      ch.Reverb.Enabled = true; ch.Reverb.WetLevel = 0.35f;
  }

  // Object pool
  public class ObjectPool<T> : ScriptBehaviour where T : Component, new() {
      private readonly Queue<T> _pool = new();
      public int InitialSize = 20;
      public override void OnStart() {
          for (int i=0;i<InitialSize;i++) {
              var go=new GameObject(); var c=go.AddComponent<T>();
              go.SetActive(false); _pool.Enqueue(c);
          }
      }
      public T Get(Vector3 pos) {
          var obj = _pool.Count>0 ? _pool.Dequeue() : new GameObject().AddComponent<T>();
          obj.Transform.Position = pos; obj.GameObject.SetActive(true); return obj;
      }
      public void Return(T obj) { obj.GameObject.SetActive(false); _pool.Enqueue(obj); }
  }

  // Async scene load with fade
  public async Task LoadWithFade(string sceneName) {
      await FadeOutAsync(0.5f);
      await EngineKernel.Instance.SceneManager.LoadSceneAsync(sceneName, LoadSceneMode.Single);
      await FadeInAsync(0.5f);
  }

RULES
  • Use ScriptBehaviour not MonoBehaviour
  • Use EngineKernel.Instance for subsystem access in game scripts
  • Always import from BADGE namespaces, not System.Numerics
  • Register scenes with SceneManager before loading
  • DeltaTime is dt parameter or Time.DeltaTime static
  • Colliders and Rigidbody are separate AddComponent<T>() calls
=== END BADGE STUDIO API REFERENCE ===
";
    }

    // ══════════════════════════════════════════════════════════
    //  HTTP Backend  (GitHub + StackExchange + Claude)
    // ══════════════════════════════════════════════════════════

    internal sealed class AIBackend : IDisposable
    {
        private readonly HttpClient _http;
        private static readonly JsonSerializerOptions _json = new()
        {
            PropertyNameCaseInsensitive = true,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        };

        public string AnthropicApiKey { get; set; }
            = Environment.GetEnvironmentVariable("ANTHROPIC_API_KEY") ?? string.Empty;
        public string GitHubToken { get; set; }
            = Environment.GetEnvironmentVariable("GITHUB_TOKEN") ?? string.Empty;
        public string Model { get; set; } = "claude-sonnet-4-20250514";

        internal AIBackend()
        {
            _http = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
            _http.DefaultRequestHeaders.UserAgent.ParseAdd("BADGE-Studio-AI/2.0");
        }

        // ── GitHub search ─────────────────────────────────────

        internal async Task<List<AssetReference>> SearchGitHubAsync(
            string query, int count = 4, CancellationToken ct = default)
        {
            try
            {
                string enc = Uri.EscapeDataString($"{query} language:csharp game engine");
                string url = $"https://api.github.com/search/repositories" +
                             $"?q={enc}&sort=stars&order=desc&per_page={count}";

                var req = new HttpRequestMessage(HttpMethod.Get, url);
                req.Headers.Accept.ParseAdd("application/vnd.github+json");
                if (!string.IsNullOrEmpty(GitHubToken))
                    req.Headers.Authorization =
                        new AuthenticationHeaderValue("Bearer", GitHubToken);

                var resp = await _http.SendAsync(req, ct).ConfigureAwait(false);
                if (!resp.IsSuccessStatusCode) return new();

                var doc = await resp.Content
                    .ReadFromJsonAsync<GHSearchResp>(_json, ct)
                    .ConfigureAwait(false);

                return (doc?.Items ?? []).Select(r => new AssetReference
                {
                    Name    = r.FullName,
                    Url     = r.HtmlUrl,
                    Source  = "GitHub",
                    Type    = r.Language ?? "Code",
                    License = r.License?.SpdxId ?? "See repo",
                    Emoji   = "📦",
                    Kind    = AssetKind.GitHub,
                }).ToList();
            }
            catch { return new(); }
        }

        // ── Stack Exchange search ─────────────────────────────

        internal async Task<List<AssetReference>> SearchStackExchangeAsync(
            string query, int count = 3, CancellationToken ct = default)
        {
            var results = new List<AssetReference>();
            var sites = new[] { "gamedev", "stackoverflow" };

            foreach (var site in sites)
            {
                try
                {
                    string enc = Uri.EscapeDataString(query);
                    string url = $"https://api.stackexchange.com/2.3/search/advanced" +
                                 $"?order=desc&sort=votes&q={enc}" +
                                 $"&tagged=c%23&site={site}&filter=withbody&pagesize={count}";

                    var resp = await _http.GetAsync(url, ct).ConfigureAwait(false);
                    if (!resp.IsSuccessStatusCode) continue;

                    var doc = await resp.Content
                        .ReadFromJsonAsync<SEResp>(_json, ct)
                        .ConfigureAwait(false);

                    if (doc?.Items is null) continue;

                    results.AddRange(doc.Items.Select(q => new AssetReference
                    {
                        Name   = q.Title,
                        Url    = q.Link,
                        Source = site == "gamedev" ? "GameDev.SE" : "StackOverflow",
                        Type   = StripHtml(q.Body ?? "").Truncate(300),
                        Emoji  = "💬",
                        Kind   = AssetKind.GitHub,
                    }));
                }
                catch { /* non-fatal */ }
            }

            return results;
        }

        // ── Asset search (GitHub game-asset repos) ────────────

        internal async Task<List<AssetReference>> SearchGameAssetsAsync(
            string query, CancellationToken ct = default)
        {
            var all = new List<AssetReference>();

            // Kenney (CC0 asset packs via GitHub org)
            try
            {
                string enc = Uri.EscapeDataString(query);
                string url = $"https://api.github.com/search/repositories" +
                             $"?q={enc}+user:Kenney&sort=stars&per_page=4";

                var req = new HttpRequestMessage(HttpMethod.Get, url);
                req.Headers.Accept.ParseAdd("application/vnd.github+json");
                if (!string.IsNullOrEmpty(GitHubToken))
                    req.Headers.Authorization =
                        new AuthenticationHeaderValue("Bearer", GitHubToken);

                var resp = await _http.SendAsync(req, ct).ConfigureAwait(false);
                if (resp.IsSuccessStatusCode)
                {
                    var doc = await resp.Content
                        .ReadFromJsonAsync<GHSearchResp>(_json, ct)
                        .ConfigureAwait(false);

                    all.AddRange((doc?.Items ?? []).Select(r => new AssetReference
                    {
                        Name    = r.FullName,
                        Url     = r.HtmlUrl,
                        Source  = "Kenney",
                        Type    = "Asset Pack (CC0)",
                        License = "CC0 1.0",
                        Emoji   = "🟦",
                        Kind    = AssetKind.Kenney,
                    }));
                }
            }
            catch { }

            // General game asset repos
            try
            {
                string enc = Uri.EscapeDataString($"{query} game assets");
                string url = $"https://api.github.com/search/repositories" +
                             $"?q={enc}+topic:game-assets&sort=stars&per_page=5";

                var req = new HttpRequestMessage(HttpMethod.Get, url);
                req.Headers.Accept.ParseAdd("application/vnd.github+json");
                if (!string.IsNullOrEmpty(GitHubToken))
                    req.Headers.Authorization =
                        new AuthenticationHeaderValue("Bearer", GitHubToken);

                var resp = await _http.SendAsync(req, ct).ConfigureAwait(false);
                if (resp.IsSuccessStatusCode)
                {
                    var doc = await resp.Content
                        .ReadFromJsonAsync<GHSearchResp>(_json, ct)
                        .ConfigureAwait(false);

                    all.AddRange((doc?.Items ?? []).Select(r => new AssetReference
                    {
                        Name    = r.FullName,
                        Url     = r.HtmlUrl,
                        Source  = "GitHub",
                        Type    = r.Language ?? "Assets",
                        License = r.License?.SpdxId ?? "See repo",
                        Emoji   = "📦",
                        Kind    = AssetKind.GitHub,
                    }));
                }
            }
            catch { }

            return all.DistinctBy(a => a.Url).ToList();
        }

        // ── Claude API ────────────────────────────────────────

        internal async Task<(string Answer, bool Success)> AskClaudeAsync(
            string question,
            List<AssetReference> context,
            List<(string role, string text)> history,
            CancellationToken ct = default)
        {
            const string Endpoint = "https://api.anthropic.com/v1/messages";

            if (string.IsNullOrEmpty(AnthropicApiKey))
                return ("⚠ No Anthropic API key found.\n\n" +
                        "Set the environment variable **ANTHROPIC_API_KEY** before " +
                        "launching BADGE Studio, then reopen the AI Assistant tab.", false);

            // Build system prompt: BADGE API reference + assistant persona
            string systemPrompt =
                "You are a senior game developer and BADGE Studio engine expert.\n" +
                "BADGE Studio is a C# .NET 8 game engine. You MUST use only the APIs " +
                "documented in the reference below. Never invent classes or namespaces.\n\n" +
                BadgeApiReference.Text +
                "\n\nRules:\n" +
                "• Always write compilable C# using BADGE APIs.\n" +
                "• Use ScriptBehaviour, not MonoBehaviour.\n" +
                "• Use EngineKernel.Instance for subsystem access.\n" +
                "• Wrap all code in ```csharp fences.\n" +
                "• Be concise but complete.\n" +
                "• Reference any provided GitHub/Stack Exchange context where helpful.";

            // Build context block from gathered sources
            var ctxSb = new StringBuilder();
            if (context.Count > 0)
            {
                ctxSb.AppendLine("CONTEXT FROM WEB SEARCH:");
                foreach (var s in context.Take(5))
                {
                    ctxSb.AppendLine($"[{s.Source}] {s.Name}");
                    ctxSb.AppendLine($"URL: {s.Url}");
                    if (!string.IsNullOrEmpty(s.Type)) ctxSb.AppendLine(s.Type);
                    ctxSb.AppendLine();
                }
                ctxSb.AppendLine("QUESTION:");
            }
            ctxSb.AppendLine(question);

            // Build message list (multi-turn: pass conversation history)
            var messages = new List<object>();
            foreach (var (role, text) in history.TakeLast(10)) // last 10 turns
                messages.Add(new { role, content = text });
            messages.Add(new { role = "user", content = ctxSb.ToString() });

            var payload = new
            {
                model      = Model,
                max_tokens = 2000,
                system     = systemPrompt,
                messages   = messages.ToArray(),
            };

            try
            {
                var req = new HttpRequestMessage(HttpMethod.Post, Endpoint)
                {
                    Content = new StringContent(
                        JsonSerializer.Serialize(payload, _json),
                        Encoding.UTF8,
                        "application/json"),
                };
                req.Headers.Add("x-api-key",        AnthropicApiKey);
                req.Headers.Add("anthropic-version", "2023-06-01");

                var resp = await _http.SendAsync(req, ct).ConfigureAwait(false);
                string body = await resp.Content.ReadAsStringAsync(ct).ConfigureAwait(false);

                if (!resp.IsSuccessStatusCode)
                {
                    // Surface the actual API error message to the user
                    string errMsg = TryExtractErrorMessage(body);
                    return ($"❌ Anthropic API error {(int)resp.StatusCode}: {errMsg}", false);
                }

                var doc = JsonSerializer.Deserialize<AnthropicResp>(body, _json);
                string answer = doc?.Content?
                    .Where(c => c.Type == "text")
                    .Select(c => c.Text ?? "")
                    .FirstOrDefault(t => !string.IsNullOrWhiteSpace(t))
                    ?? string.Empty;

                if (string.IsNullOrWhiteSpace(answer))
                    return ("The model returned an empty response. " +
                            "Please try rephrasing your question.", false);

                return (answer, true);
            }
            catch (TaskCanceledException)
            {
                return ("⏱ Request timed out. Check your internet connection and try again.", false);
            }
            catch (Exception ex)
            {
                return ($"❌ Network error: {ex.Message}", false);
            }
        }

        // ── Helpers ───────────────────────────────────────────

        private static string StripHtml(string html)
        {
            html = System.Text.RegularExpressions.Regex.Replace(html, "<[^>]+>", " ");
            html = html.Replace("&amp;", "&").Replace("&lt;", "<").Replace("&gt;", ">")
                       .Replace("&quot;", "\"").Replace("&#39;", "'").Replace("&nbsp;", " ");
            return System.Text.RegularExpressions.Regex.Replace(html, @"\s+", " ").Trim();
        }

        private static string TryExtractErrorMessage(string body)
        {
            try
            {
                using var doc = JsonDocument.Parse(body);
                if (doc.RootElement.TryGetProperty("error", out var err))
                {
                    if (err.TryGetProperty("message", out var msg)) return msg.GetString() ?? body;
                }
            }
            catch { }
            return body.Length > 200 ? body[..200] + "…" : body;
        }

        public void Dispose() => _http.Dispose();

        // ── JSON DTOs ─────────────────────────────────────────

        private sealed class GHSearchResp
        {
            [JsonPropertyName("items")] public List<GHRepo>? Items { get; set; }
        }

        private sealed class GHRepo
        {
            [JsonPropertyName("full_name")]       public string  FullName  { get; set; } = "";
            [JsonPropertyName("html_url")]        public string  HtmlUrl   { get; set; } = "";
            [JsonPropertyName("language")]        public string? Language  { get; set; }
            [JsonPropertyName("stargazers_count")]public int     Stars     { get; set; }
            [JsonPropertyName("license")]         public GHLicense? License{ get; set; }
        }

        private sealed class GHLicense
        {
            [JsonPropertyName("spdx_id")] public string? SpdxId { get; set; }
        }

        private sealed class SEResp
        {
            [JsonPropertyName("items")] public List<SEQuestion>? Items { get; set; }
        }

        private sealed class SEQuestion
        {
            [JsonPropertyName("title")] public string Title { get; set; } = "";
            [JsonPropertyName("link")]  public string Link  { get; set; } = "";
            [JsonPropertyName("body")]  public string? Body { get; set; }
        }

        private sealed class AnthropicResp
        {
            [JsonPropertyName("content")] public List<AnthropicContent>? Content { get; set; }
        }

        private sealed class AnthropicContent
        {
            [JsonPropertyName("type")] public string? Type { get; set; }
            [JsonPropertyName("text")] public string? Text { get; set; }
        }
    }

    // ══════════════════════════════════════════════════════════
    //  Chat Session  (manages conversation history)
    // ══════════════════════════════════════════════════════════

    public sealed class AIChatSession
    {
        private readonly List<ChatMessage> _messages = new();
        private readonly List<(string role, string text)> _apiHistory = new();

        public IReadOnlyList<ChatMessage> Messages => _messages;

        public void AddWelcome()
        {
            _messages.Add(new ChatMessage(ChatRole.Assistant,
                "**BADGE Studio AI** — BADGE Engine code generator & asset finder.\n\n" +
                "I search **GitHub** and **Stack Exchange** to ground every answer in " +
                "real code, then generate BADGE-specific C# using the full API reference. " +
                "Ask me anything about game development, or switch to the **Assets** tab " +
                "to find free game assets."));
        }

        public void AddUserMessage(string text)
        {
            _messages.Add(new ChatMessage(ChatRole.User, text));
            _apiHistory.Add(("user", text));
        }

        public void AddAssistantMessage(string text, List<AssetReference>? sources = null)
        {
            _messages.Add(new ChatMessage(ChatRole.Assistant, text, sources));
            _apiHistory.Add(("assistant", text));
        }

        public List<(string role, string text)> GetApiHistory() => _apiHistory;

        public void Clear()
        {
            _messages.Clear();
            _apiHistory.Clear();
            AddWelcome();
        }
    }

    // ══════════════════════════════════════════════════════════
    //  IEditorModule Implementation  — the actual engine TAB
    // ══════════════════════════════════════════════════════════

    /// <summary>
    /// Full AI assistant tab for BADGE Studio.
    /// Register via:  EditorsRegistry.Instance.Register(new AIAssistantModule());
    ///
    /// Three sub-tabs:
    ///   ⌨ Code Chat   — ask BADGE coding questions
    ///   🎨 Assets      — search free game assets (GitHub / Kenney)
    ///   📂 Project     — manage exported assets
    /// </summary>
    public sealed class AIAssistantModule : IEditorModule
    {
        // ── IEditorModule ─────────────────────────────────────
        public string Name   => "AI Assistant";
        public string Icon   => "🤖";
        public bool   IsOpen { get; set; }

        // ── State ─────────────────────────────────────────────
        private readonly AIBackend       _backend  = new();
        private readonly AIChatSession   _session  = new();

        private ChatTabId _activeTab   = ChatTabId.CodeChat;
        private string    _chatInput   = string.Empty;
        private string    _assetInput  = string.Empty;
        private bool      _busy        = false;
        private string    _busyPhase   = string.Empty;
        private string?   _banner      = null;

        private readonly List<AssetReference> _assetResults  = new();
        private readonly List<AssetReference> _projectAssets = new();
        private bool _assetSearching = false;

        private CancellationTokenSource? _cts;

        // ── Lifecycle ─────────────────────────────────────────

        public void Open()
        {
            IsOpen = true;
            if (_session.Messages.Count == 0)
                _session.AddWelcome();
            Console.WriteLine("[AI Assistant] Tab opened.");
        }

        public void Close()
        {
            IsOpen = false;
            _cts?.Cancel();
            Console.WriteLine("[AI Assistant] Tab closed.");
        }

        public void Update(float dt) { /* async; nothing to tick */ }

        public void OnShortcut(string shortcut)
        {
            if (shortcut == "send" && !_busy && !string.IsNullOrWhiteSpace(_chatInput))
                _ = SendChatAsync(_chatInput);
        }

        // ══════════════════════════════════════════════════════
        //  DrawUI  – called by the editor renderer each frame
        //
        //  This method drives the BADGE UIUXToolkit widget tree
        //  and also emits Console output for headless / test use.
        //  In a real windowed build, replace Console calls with
        //  your renderer's draw calls (ImGui / OpenTK / etc.).
        // ══════════════════════════════════════════════════════

        public void DrawUI()
        {
            // ── Root panel ─────────────────────────────────────
            var root = new Panel
            {
                Name       = "AIRoot",
                Background = "#04060d",
            };
            root.Layout(new Rect { X=0, Y=0, Width=900, Height=700 });

            DrawHeader(root);
            DrawTabBar(root);

            if (_banner != null)
                DrawBanner(root, _banner);

            switch (_activeTab)
            {
                case ChatTabId.CodeChat: DrawCodeChatTab(root); break;
                case ChatTabId.Assets:   DrawAssetsTab(root);   break;
                case ChatTabId.Project:  DrawProjectTab(root);  break;
            }

            root.Render();
        }

        // ── Header ────────────────────────────────────────────

        private void DrawHeader(Panel root)
        {
            var hdr = new Panel
            {
                Name       = "Header",
                Background = "#090d18",
                FixedHeight = 56,
            };

            var title = new Label
            {
                Text      = "BADGE Studio AI",
                FontSize  = 15,
                FontWeight= 700,
            };
            var subtitle = new Label
            {
                Text     = "Code Generator · Asset Finder · v2.0",
                FontSize = 11,
                Color    = "#64748b",
            };

            // API status pills (shown when busy)
            string pills = _busy
                ? $"[{_busyPhase}]"
                : string.Empty;
            var status = new Label { Text = pills, FontSize = 10 };

            hdr.AddChild(title);
            hdr.AddChild(subtitle);
            hdr.AddChild(status);
            root.AddChild(hdr);

            Console.WriteLine($"[AI Assistant] ── BADGE Studio AI  {(_busy ? $"({_busyPhase})" : "●")}");
        }

        // ── Tab bar ───────────────────────────────────────────

        private void DrawTabBar(Panel root)
        {
            var bar = new Panel
            {
                Name        = "TabBar",
                Layout      = LayoutType.Flex,
                Direction   = FlexDirection.Row,
                Background  = "#090d18",
                FixedHeight = 38,
            };

            var tabs = new[]
            {
                (ChatTabId.CodeChat, "⌨", "Code Chat"),
                (ChatTabId.Assets,   "🎨", "Assets"),
                (ChatTabId.Project,  "📂", $"Project ({_projectAssets.Count})"),
            };

            foreach (var (id, icon, label) in tabs)
            {
                bool active = _activeTab == id;
                var btn = new Button
                {
                    Text       = $"{icon} {label}",
                    Background = active ? "#0d1424" : "transparent",
                    FontSize   = 12,
                };
                btn.OnClick += _ =>
                {
                    _activeTab = id;
                    Console.WriteLine($"[AI Assistant] → {label} tab");
                };
                bar.AddChild(btn);
            }

            root.AddChild(bar);
        }

        // ── Banner ────────────────────────────────────────────

        private static void DrawBanner(Panel root, string message)
        {
            var banner = new Label
            {
                Text     = $"✓ {message}",
                FontSize = 12,
                Color    = "#22c55e",
            };
            root.AddChild(banner);
        }

        // ══════════════════════════════════════════════════════
        //  CODE CHAT TAB
        // ══════════════════════════════════════════════════════

        private void DrawCodeChatTab(Panel root)
        {
            var scroll = new ScrollPanel
            {
                Name       = "ChatScroll",
                Background = "#04060d",
            };

            // Render each message
            foreach (var msg in _session.Messages)
                scroll.AddChild(BuildMessageWidget(msg));

            // Loading indicator
            if (_busy)
                scroll.AddChild(BuildThinkingWidget());

            // Quick-start suggestions (only shown before first user message)
            bool firstMsg = _session.Messages.Count == 1;
            if (firstMsg && !_busy)
                scroll.AddChild(BuildSuggestionChips());

            root.AddChild(scroll);

            // Input row
            root.AddChild(BuildChatInputRow());

            // Console echo (headless mode)
            Console.WriteLine($"[AI Chat] {_session.Messages.Count} messages | busy={_busy}");
            if (_busy) Console.WriteLine($"  ↳ Phase: {_busyPhase}");
        }

        private static Widget BuildMessageWidget(ChatMessage msg)
        {
            bool isUser = msg.Role == ChatRole.User;
            var bubble = new Panel
            {
                Name       = isUser ? "UserBubble" : "AIBubble",
                Background = isUser ? "#061828" : "#0d1424",
                FixedHeight = 60, // approximate; real renderer measures text
            };
            bubble.AddChild(new Label
            {
                Text     = isUser ? "▷ YOU" : "◈ BADGE AI",
                FontSize = 10,
                Color    = isUser ? "#00d4ff" : "#22c55e",
            });
            bubble.AddChild(new Label
            {
                Text    = msg.Text,
                FontSize= 13,
                Wrap    = true,
            });

            // Source links
            if (msg.Sources is { Count: > 0 })
            {
                var srcBox = new Panel { Background = "#06080f", Name = "Sources" };
                srcBox.AddChild(new Label { Text = $"⟳ {msg.Sources.Count} SOURCES", FontSize=11, Color="#f59e0b" });
                foreach (var s in msg.Sources.Take(4))
                    srcBox.AddChild(new Label { Text = $"  [{s.Source}] {s.Name}", FontSize=11, Color="#00d4ff" });
                bubble.AddChild(srcBox);
            }

            return bubble;
        }

        private static Widget BuildThinkingWidget()
        {
            var w = new Panel { Background = "#0d1424", Name = "Thinking" };
            w.AddChild(new Label { Text = "◈ BADGE AI", FontSize=10, Color="#22c55e" });
            w.AddChild(new Label { Text = "●○○  Thinking…", FontSize=12, Color="#00d4ff" });
            return w;
        }

        private static readonly string[] CodeSuggestions =
        {
            "Platformer player controller",
            "Enemy patrol AI with NavMesh",
            "Health & damage system",
            "3D spatial audio on collision",
            "Async scene loading transition",
            "Object pool pattern",
        };

        private Panel BuildSuggestionChips()
        {
            var row = new Panel
            {
                Name      = "Suggestions",
                Layout    = LayoutType.Flex,
                Direction = FlexDirection.Row,
            };
            foreach (var s in CodeSuggestions)
            {
                var chip = new Button { Text = s, FontSize = 11 };
                string captured = s;
                chip.OnClick += _ => _ = SendChatAsync(captured);
                row.AddChild(chip);
            }
            return row;
        }

        private Panel BuildChatInputRow()
        {
            var row = new Panel
            {
                Name        = "InputRow",
                Layout      = LayoutType.Flex,
                Direction   = FlexDirection.Row,
                Background  = "#090d18",
                FixedHeight = 70,
            };

            var input = new TextInput
            {
                Placeholder = "Ask anything about BADGE Studio… (Enter to send)",
                Text        = _chatInput,
                Multiline   = true,
            };
            input.OnTextChanged += text => _chatInput = text;
            input.OnSubmit      += () =>
            {
                if (!_busy && !string.IsNullOrWhiteSpace(_chatInput))
                    _ = SendChatAsync(_chatInput);
            };

            var sendBtn = new Button
            {
                Text       = _busy ? "…" : "SEND ↵",
                Enabled    = !_busy,
                Background = _busy ? "#162035" : "linear-gradient(135deg,#00d4ff,#0066cc)",
                FontSize   = 13,
                FontWeight = 700,
            };
            sendBtn.OnClick += _ =>
            {
                if (!_busy && !string.IsNullOrWhiteSpace(_chatInput))
                    _ = SendChatAsync(_chatInput);
            };

            row.AddChild(input);
            row.AddChild(sendBtn);
            return row;
        }

        // ══════════════════════════════════════════════════════
        //  ASSETS TAB
        // ══════════════════════════════════════════════════════

        private void DrawAssetsTab(Panel root)
        {
            // Search bar
            var bar = new Panel
            {
                Name        = "AssetSearchBar",
                Background  = "#090d18",
                FixedHeight = 100,
            };

            var input = new TextInput
            {
                Placeholder = "Search free game assets… (sprites, audio, 3D models, tilesets)",
                Text        = _assetInput,
            };
            input.OnTextChanged += text => _assetInput = text;
            input.OnSubmit      += () => _ = SearchAssetsAsync(_assetInput);

            var searchBtn = new Button
            {
                Text       = _assetSearching ? "…" : "SEARCH 🔍",
                Enabled    = !_assetSearching,
                FontSize   = 13,
                FontWeight = 700,
            };
            searchBtn.OnClick += _ => _ = SearchAssetsAsync(_assetInput);
            bar.AddChild(input);
            bar.AddChild(searchBtn);

            // Suggestion chips
            var chips = new Panel { Layout = LayoutType.Flex, Direction = FlexDirection.Row };
            var assetSuggs = new[] { "platformer sprites", "RPG character", "space shooter",
                                     "tileset medieval", "explosion VFX", "ambient forest audio" };
            foreach (var s in assetSuggs)
            {
                var chip = new Button { Text = s, FontSize = 11 };
                string cap = s;
                chip.OnClick += _ => { _assetInput = cap; _ = SearchAssetsAsync(cap); };
                chips.AddChild(chip);
            }
            bar.AddChild(chips);

            // Free API labels
            var apiRow = new Panel { Layout = LayoutType.Flex, Direction = FlexDirection.Row };
            apiRow.AddChild(new Label { Text = "FREE APIs:", FontSize=10, Color="#64748b" });
            foreach (var (lbl, col) in new[] { ("Kenney (CC0)", "#00d4ff"), ("GitHub Search","#94a3b8") })
                apiRow.AddChild(new Label { Text = lbl, FontSize=10, Color=col });
            bar.AddChild(apiRow);
            root.AddChild(bar);

            // Results
            var results = new ScrollPanel { Name = "AssetResults", Background = "#04060d" };
            if (_assetSearching)
            {
                results.AddChild(new Label { Text = "🔍 Searching assets…", FontSize=13, Color="#a78bfa" });
            }
            else if (_assetResults.Count == 0)
            {
                results.AddChild(new Label { Text = "🎮  Search for free game assets", FontSize=14, Color="#64748b" });
                results.AddChild(new Label { Text = "Sprites · Audio · 3D Models · Tilesets · UI · VFX", FontSize=12, Color="#64748b" });
            }
            else
            {
                results.AddChild(new Label { Text = $"{_assetResults.Count} results — click EXPORT to add to your project", FontSize=12 });
                foreach (var asset in _assetResults)
                    results.AddChild(BuildAssetCard(asset));
            }
            root.AddChild(results);

            Console.WriteLine($"[AI Assets] {_assetResults.Count} results | searching={_assetSearching}");
        }

        private Widget BuildAssetCard(AssetReference asset)
        {
            var card = new Panel
            {
                Name       = "AssetCard",
                Background = "#0d1424",
                FixedHeight= 140,
            };
            card.AddChild(new Label { Text = $"{asset.Emoji} {asset.Name}", FontSize=12, FontWeight=700 });
            card.AddChild(new Label { Text = $"{asset.Source} · {asset.Type}", FontSize=11, Color="#64748b" });
            if (!string.IsNullOrEmpty(asset.License))
                card.AddChild(new Label { Text = $"⚖ {asset.License}", FontSize=10, Color="#f59e0b" });

            var actions = new Panel { Layout = LayoutType.Flex, Direction = FlexDirection.Row };

            var viewBtn = new Button { Text = "↗ VIEW", FontSize=11 };
            viewBtn.OnClick += _ => Console.WriteLine($"[AI Assets] Open URL: {asset.Url}");

            var exportBtn = new Button { Text = "⤓ EXPORT", FontSize=11 };
            var cap = asset;
            exportBtn.OnClick += _ => ExportAsset(cap);

            actions.AddChild(viewBtn);
            actions.AddChild(exportBtn);
            card.AddChild(actions);
            return card;
        }

        // ══════════════════════════════════════════════════════
        //  PROJECT TAB
        // ══════════════════════════════════════════════════════

        private void DrawProjectTab(Panel root)
        {
            var hdr = new Panel
            {
                Name        = "ProjectHeader",
                Background  = "#090d18",
                FixedHeight = 56,
            };
            hdr.AddChild(new Label { Text = "Project Panel", FontSize=14, FontWeight=700 });
            hdr.AddChild(new Label
            {
                Text    = $"{_projectAssets.Count} asset{(_projectAssets.Count!=1?"s":"")} exported",
                FontSize= 11,
                Color   = "#64748b",
            });

            if (_projectAssets.Count > 0)
            {
                var exportAllBtn = new Button
                {
                    Text      = "⬇ EXPORT ALL (.json)",
                    FontSize  = 12,
                    FontWeight= 700,
                };
                exportAllBtn.OnClick += _ => ExportProjectJson();
                hdr.AddChild(exportAllBtn);
            }

            root.AddChild(hdr);

            var list = new ScrollPanel { Name = "ProjectList", Background = "#04060d" };

            if (_projectAssets.Count == 0)
            {
                list.AddChild(new Label { Text = "📂  No assets exported yet.", FontSize=12, Color="#64748b" });
                list.AddChild(new Label { Text = "Search and click ⤓ EXPORT to add assets here.", FontSize=11, Color="#64748b" });
            }
            else
            {
                for (int i = 0; i < _projectAssets.Count; i++)
                {
                    var a   = _projectAssets[i];
                    int idx = i;
                    var row = new Panel
                    {
                        Name        = $"ProjectItem_{i}",
                        Background  = "#0d1424",
                        FixedHeight = 56,
                        Layout      = LayoutType.Flex,
                        Direction   = FlexDirection.Row,
                    };
                    row.AddChild(new Label { Text = a.Emoji, FontSize=22 });
                    var info = new Panel { Name = "info" };
                    info.AddChild(new Label { Text = a.Name, FontSize=12, FontWeight=700 });
                    info.AddChild(new Label { Text = $"{a.Source} · {a.Type}", FontSize=11, Color="#64748b" });
                    row.AddChild(info);

                    var removeBtn = new Button { Text = "✕", FontSize=10 };
                    removeBtn.OnClick += _ =>
                    {
                        _projectAssets.RemoveAt(idx);
                        Console.WriteLine($"[AI Project] Removed: {a.Name}");
                    };
                    row.AddChild(removeBtn);
                    list.AddChild(row);
                }
            }

            root.AddChild(list);
            Console.WriteLine($"[AI Project] {_projectAssets.Count} items");
        }

        // ══════════════════════════════════════════════════════
        //  Async operations
        // ══════════════════════════════════════════════════════

        private async Task SendChatAsync(string question)
        {
            if (_busy || string.IsNullOrWhiteSpace(question)) return;

            _busy = true;
            _chatInput = string.Empty;
            _session.AddUserMessage(question);

            _cts = new CancellationTokenSource();
            var ct = _cts.Token;

            try
            {
                // 1. GitHub search
                _busyPhase = "Searching GitHub…";
                var ghSources = await _backend.SearchGitHubAsync(question, 3, ct)
                    .ConfigureAwait(false);

                // 2. Stack Exchange search
                _busyPhase = "Searching Stack Exchange…";
                var seSources = await _backend.SearchStackExchangeAsync(question, 3, ct)
                    .ConfigureAwait(false);

                var allSources = ghSources.Concat(seSources).ToList();

                // 3. Call Claude with full BADGE API reference context
                _busyPhase = "Generating with Claude AI…";
                var (answer, _) = await _backend.AskClaudeAsync(
                    question, allSources, _session.GetApiHistory(), ct)
                    .ConfigureAwait(false);

                _session.AddAssistantMessage(answer, allSources.Count > 0 ? allSources : null);
            }
            catch (OperationCanceledException)
            {
                _session.AddAssistantMessage("⚠ Request cancelled.");
            }
            catch (Exception ex)
            {
                _session.AddAssistantMessage($"❌ Unexpected error: {ex.Message}");
            }
            finally
            {
                _busy = false;
                _busyPhase = string.Empty;
                _cts = null;
            }
        }

        private async Task SearchAssetsAsync(string query)
        {
            if (_assetSearching || string.IsNullOrWhiteSpace(query)) return;
            _assetSearching = true;
            _assetResults.Clear();

            try
            {
                var results = await _backend.SearchGameAssetsAsync(query)
                    .ConfigureAwait(false);
                _assetResults.AddRange(results);
                Console.WriteLine($"[AI Assets] {results.Count} results for "{query}"");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[AI Assets] Search error: {ex.Message}");
            }
            finally
            {
                _assetSearching = false;
            }
        }

        private void ExportAsset(AssetReference asset)
        {
            if (_projectAssets.Any(p => p.Url == asset.Url)) return;
            _projectAssets.Add(asset);
            ShowBanner($"\"{asset.Name}\" added to Project Panel");
            Console.WriteLine($"[AI Project] Exported: {asset.Name}  ({asset.Url})");
        }

        private void ExportProjectJson()
        {
            var json = JsonSerializer.Serialize(_projectAssets,
                new JsonSerializerOptions { WriteIndented = true });

            string path = System.IO.Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile),
                "badge-project-assets.json");

            System.IO.File.WriteAllText(path, json);
            ShowBanner($"Exported {_projectAssets.Count} assets → {path}");
            Console.WriteLine($"[AI Project] Saved JSON → {path}");
        }

        private void ShowBanner(string message)
        {
            _banner = message;
            // Clear banner after ~3 seconds (or on next DrawUI call after flag reset)
            _ = Task.Delay(3000).ContinueWith(_ => _banner = null);
        }
    }

    // ══════════════════════════════════════════════════════════
    //  UIUXToolkit extensions used above
    //  (Label.Wrap, TextInput events, Button events — thin stubs
    //   that extend the existing toolkit)
    // ══════════════════════════════════════════════════════════

    // These partial additions avoid modifying UIUXToolkit.cs directly.

    public sealed class Label : Widget
    {
        public string Text      { get; set; } = string.Empty;
        public int    FontSize  { get; set; } = 13;
        public int    FontWeight{ get; set; } = 400;
        public string Color     { get; set; } = "#e2e8f0";
        public bool   Wrap      { get; set; }

        public override void Measure()  { }
        public override void Layout(Rect r) { Bounds = r; }
        public override void Render()   => Console.Write($"{Text}  ");
    }

    public sealed class Button : Widget
    {
        public string Text       { get; set; } = string.Empty;
        public int    FontSize   { get; set; } = 12;
        public int    FontWeight { get; set; } = 600;
        public string Background { get; set; } = "#162035";
        public string Color      { get; set; } = "#e2e8f0";

        public event Action<Button>? OnClick;
        public void Click(Button src) => OnClick?.Invoke(src);

        public override void Measure()  { }
        public override void Layout(Rect r) { Bounds = r; }
        public override void Render()   => Console.Write($"[{Text}]  ");
    }

    public sealed class TextInput : Widget
    {
        public string Text        { get; set; } = string.Empty;
        public string Placeholder { get; set; } = string.Empty;
        public bool   Multiline   { get; set; }

        public event Action<string>? OnTextChanged;
        public event Action?         OnSubmit;

        public void SetText(string v) { Text = v; OnTextChanged?.Invoke(v); }
        public void Submit()          => OnSubmit?.Invoke();

        public override void Measure()  { }
        public override void Layout(Rect r) { Bounds = r; }
        public override void Render()   => Console.Write($"[INPUT: {(string.IsNullOrEmpty(Text)?Placeholder:Text)}]");
    }
}

// ── String helpers ─────────────────────────────────────────────

internal static class StringExtensions
{
    internal static string Truncate(this string s, int maxLen)
        => s.Length <= maxLen ? s : s[..maxLen] + "…";
}
