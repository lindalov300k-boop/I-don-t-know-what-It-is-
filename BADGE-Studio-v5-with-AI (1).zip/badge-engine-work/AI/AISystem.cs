// ============================================================
//  BADGE Engine – AI/AISystem.cs
//  Pathfinding (A*), NavMesh, Behavior Trees, Decision Trees,
//  Steering Behaviors, Crowd Simulation.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using BADGE.Engine.Math;

namespace BADGE.Engine.AI
{
    // ═══════════════════════════════════════════════════════
    //  AI Manager  (central entry point)
    // ═══════════════════════════════════════════════════════
    public sealed class AIManager
    {
        public NavMesh           NavMesh  { get; } = new();
        public CrowdSimulator    Crowd    { get; } = new();

        private readonly List<BehaviorTreeAgent> _btAgents = new();
        private readonly List<DecisionTreeAgent> _dtAgents = new();

        public void RegisterAgent(BehaviorTreeAgent agent) => _btAgents.Add(agent);
        public void RegisterAgent(DecisionTreeAgent agent) => _dtAgents.Add(agent);
        public void UnregisterAgent(BehaviorTreeAgent agent) => _btAgents.Remove(agent);
        public void UnregisterAgent(DecisionTreeAgent agent) => _dtAgents.Remove(agent);

        public void Update(float dt)
        {
            foreach (var a in _btAgents) a.Tick(dt);
            foreach (var a in _dtAgents) a.Evaluate();
            Crowd.Update(dt);
        }

        public List<Vector2> FindPath(Vector2 start, Vector2 goal) =>
            AStar.FindPath(NavMesh, start, goal);
    }

    // ═══════════════════════════════════════════════════════
    //  A* Pathfinding
    // ═══════════════════════════════════════════════════════
    public static class AStar
    {
        public static List<Vector2> FindPath(NavMesh mesh, Vector2 start, Vector2 goal)
        {
            var startNode = mesh.GetNearestNode(start);
            var goalNode  = mesh.GetNearestNode(goal);
            if (startNode == null || goalNode == null) return new List<Vector2>();
            if (startNode == goalNode) return new List<Vector2> { goal };

            var openSet   = new PriorityQueue<NavNode, float>();
            var cameFrom  = new Dictionary<NavNode, NavNode>();
            var gScore    = new Dictionary<NavNode, float>();
            var fScore    = new Dictionary<NavNode, float>();

            foreach (var n in mesh.Nodes) { gScore[n] = float.MaxValue; fScore[n] = float.MaxValue; }
            gScore[startNode] = 0f;
            fScore[startNode] = Heuristic(startNode.Position, goalNode.Position);
            openSet.Enqueue(startNode, fScore[startNode]);

            while (openSet.Count > 0)
            {
                var current = openSet.Dequeue();
                if (current == goalNode)
                    return ReconstructPath(cameFrom, current, start, goal);

                foreach (var edge in current.Edges)
                {
                    var neighbour = edge.To;
                    if (!neighbour.Walkable) continue;
                    float tentative = gScore[current] + edge.Cost;
                    if (tentative < gScore[neighbour])
                    {
                        cameFrom[neighbour] = current;
                        gScore[neighbour]   = tentative;
                        fScore[neighbour]   = tentative + Heuristic(neighbour.Position, goalNode.Position);
                        openSet.Enqueue(neighbour, fScore[neighbour]);
                    }
                }
            }
            return new List<Vector2>(); // No path found
        }

        private static float Heuristic(Vector2 a, Vector2 b) => Vector2.Distance(a, b);

        private static List<Vector2> ReconstructPath(Dictionary<NavNode, NavNode> cameFrom,
            NavNode current, Vector2 start, Vector2 goal)
        {
            var path = new List<Vector2> { goal };
            while (cameFrom.ContainsKey(current))
            {
                path.Add(current.Position);
                current = cameFrom[current];
            }
            path.Add(start);
            path.Reverse();
            return path;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  NavMesh — polygon-based navigation graph
    // ═══════════════════════════════════════════════════════
    public sealed class NavMesh
    {
        public List<NavNode>     Nodes    { get; } = new();
        public List<NavPolygon>  Polygons { get; } = new();
        public bool              Built    { get; private set; }

        // ── Grid-based NavMesh generation ────────────────
        public void BuildFromGrid(bool[,] walkable, float cellSize = 1f)
        {
            Nodes.Clear();
            int w = walkable.GetLength(0), h = walkable.GetLength(1);
            var grid = new NavNode?[w, h];

            // Create nodes
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                if (!walkable[x, y]) continue;
                var node = new NavNode(new Vector2(x * cellSize, y * cellSize)) { Walkable = true };
                grid[x, y] = node;
                Nodes.Add(node);
            }

            // Connect edges (8-directional)
            int[][] dirs = { new[]{1,0}, new[]{-1,0}, new[]{0,1}, new[]{0,-1},
                             new[]{1,1}, new[]{-1,1}, new[]{1,-1}, new[]{-1,-1} };
            for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                var node = grid[x, y];
                if (node == null) continue;
                foreach (var d in dirs)
                {
                    int nx = x + d[0], ny = y + d[1];
                    if (nx < 0 || nx >= w || ny < 0 || ny >= h) continue;
                    var nb = grid[nx, ny];
                    if (nb == null) continue;
                    float cost = (d[0] != 0 && d[1] != 0) ? cellSize * 1.414f : cellSize;
                    node.Edges.Add(new NavEdge(node, nb, cost));
                }
            }
            Built = true;
            Console.WriteLine($"[NavMesh] Built from {w}×{h} grid → {Nodes.Count} nodes.");
        }

        // ── Geometry-based NavMesh generation ────────────
        public void BuildFromPolygons(IEnumerable<NavPolygon> polys)
        {
            Polygons.Clear();
            Polygons.AddRange(polys);
            Nodes.Clear();
            // One node per polygon centroid
            foreach (var poly in Polygons)
            {
                poly.Node = new NavNode(poly.Centroid) { Walkable = true };
                Nodes.Add(poly.Node);
            }
            // Connect adjacent polygons (share an edge)
            for (int i = 0; i < Polygons.Count; i++)
            for (int j = i + 1; j < Polygons.Count; j++)
            {
                if (!Polygons[i].IsAdjacentTo(Polygons[j])) continue;
                float cost = Vector2.Distance(Polygons[i].Node!.Position, Polygons[j].Node!.Position);
                Polygons[i].Node!.Edges.Add(new NavEdge(Polygons[i].Node, Polygons[j].Node!, cost));
                Polygons[j].Node!.Edges.Add(new NavEdge(Polygons[j].Node, Polygons[i].Node!, cost));
            }
            Built = true;
            Console.WriteLine($"[NavMesh] Built from {Polygons.Count} polygons → {Nodes.Count} nodes.");
        }

        public NavNode? GetNearestNode(Vector2 pos) =>
            Nodes.Count == 0 ? null :
            Nodes.MinBy(n => Vector2.Distance(n.Position, pos));

        public void AddObstacle(Vector2 center, float radius)
        {
            foreach (var n in Nodes)
                if (Vector2.Distance(n.Position, center) <= radius)
                    n.Walkable = false;
        }

        public void RemoveObstacle(Vector2 center, float radius)
        {
            foreach (var n in Nodes)
                if (Vector2.Distance(n.Position, center) <= radius)
                    n.Walkable = true;
        }
    }

    public sealed class NavNode
    {
        public Vector2         Position { get; }
        public bool            Walkable { get; set; } = true;
        public float           Weight   { get; set; } = 1f;
        public List<NavEdge>   Edges    { get; } = new();
        public NavNode(Vector2 pos) { Position = pos; }
    }

    public sealed class NavEdge
    {
        public NavNode From { get; }
        public NavNode To   { get; }
        public float   Cost { get; set; }
        public NavEdge(NavNode from, NavNode to, float cost) { From = from; To = to; Cost = cost; }
    }

    public sealed class NavPolygon
    {
        public List<Vector2> Vertices { get; } = new();
        public NavNode?      Node     { get; internal set; }
        public Vector2       Centroid => Vertices.Count == 0 ? Vector2.Zero
            : new Vector2(Vertices.Average(v => v.X), Vertices.Average(v => v.Y));

        public bool IsAdjacentTo(NavPolygon other)
        {
            int shared = 0;
            foreach (var v in Vertices)
                if (other.Vertices.Any(u => Vector2.Distance(u, v) < 0.01f))
                    shared++;
            return shared >= 2;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Behavior Trees
    // ═══════════════════════════════════════════════════════
    public enum BTStatus { Success, Failure, Running }

    public abstract class BTNode
    {
        public string Name { get; set; } = "";
        public abstract BTStatus Tick(BTContext ctx);
        public virtual  void     Reset() { }
    }

    // ── Composite nodes ──────────────────────────────────
    /// <summary>Runs children in order; succeeds if ALL succeed.</summary>
    public sealed class Sequence : BTNode
    {
        private readonly List<BTNode> _children;
        private int _current;
        public Sequence(string name, params BTNode[] children)
        { Name = name; _children = children.ToList(); }

        public override BTStatus Tick(BTContext ctx)
        {
            while (_current < _children.Count)
            {
                var s = _children[_current].Tick(ctx);
                if (s == BTStatus.Failure) { Reset(); return BTStatus.Failure; }
                if (s == BTStatus.Running)  return BTStatus.Running;
                _current++;
            }
            Reset();
            return BTStatus.Success;
        }
        public override void Reset() { _current = 0; foreach (var c in _children) c.Reset(); }
    }

    /// <summary>Runs children in order; succeeds if ANY succeeds.</summary>
    public sealed class Selector : BTNode
    {
        private readonly List<BTNode> _children;
        private int _current;
        public Selector(string name, params BTNode[] children)
        { Name = name; _children = children.ToList(); }

        public override BTStatus Tick(BTContext ctx)
        {
            while (_current < _children.Count)
            {
                var s = _children[_current].Tick(ctx);
                if (s == BTStatus.Success) { Reset(); return BTStatus.Success; }
                if (s == BTStatus.Running)  return BTStatus.Running;
                _current++;
            }
            Reset();
            return BTStatus.Failure;
        }
        public override void Reset() { _current = 0; foreach (var c in _children) c.Reset(); }
    }

    /// <summary>Runs all children in parallel; configurable success/failure policy.</summary>
    public sealed class Parallel : BTNode
    {
        private readonly List<BTNode> _children;
        private readonly int _successThreshold;
        public Parallel(string name, int successThreshold, params BTNode[] children)
        { Name = name; _successThreshold = successThreshold; _children = children.ToList(); }

        public override BTStatus Tick(BTContext ctx)
        {
            int successes = 0, failures = 0;
            foreach (var c in _children)
            {
                var s = c.Tick(ctx);
                if (s == BTStatus.Success) successes++;
                if (s == BTStatus.Failure) failures++;
            }
            if (successes >= _successThreshold) return BTStatus.Success;
            if (failures  > _children.Count - _successThreshold) return BTStatus.Failure;
            return BTStatus.Running;
        }
    }

    // ── Decorator nodes ──────────────────────────────────
    public sealed class Inverter : BTNode
    {
        private readonly BTNode _child;
        public Inverter(BTNode child) { Name = "Inverter"; _child = child; }
        public override BTStatus Tick(BTContext ctx) => _child.Tick(ctx) switch
        {
            BTStatus.Success => BTStatus.Failure,
            BTStatus.Failure => BTStatus.Success,
            _ => BTStatus.Running
        };
    }

    public sealed class Repeater : BTNode
    {
        private readonly BTNode _child;
        private readonly int    _times;   // -1 = infinite
        private int _count;
        public Repeater(BTNode child, int times = -1) { Name = $"Repeat×{times}"; _child = child; _times = times; }
        public override BTStatus Tick(BTContext ctx)
        {
            if (_times >= 0 && _count >= _times) { Reset(); return BTStatus.Success; }
            var s = _child.Tick(ctx);
            if (s != BTStatus.Running) { _child.Reset(); _count++; }
            return (_times >= 0 && _count >= _times) ? BTStatus.Success : BTStatus.Running;
        }
        public override void Reset() { _count = 0; _child.Reset(); }
    }

    public sealed class Cooldown : BTNode
    {
        private readonly BTNode _child;
        private readonly float  _seconds;
        private float           _elapsed;
        public Cooldown(BTNode child, float seconds) { Name = $"Cooldown({seconds}s)"; _child = child; _seconds = seconds; _elapsed = seconds; }
        public override BTStatus Tick(BTContext ctx)
        {
            _elapsed += ctx.DeltaTime;
            if (_elapsed < _seconds) return BTStatus.Failure;
            var s = _child.Tick(ctx);
            if (s == BTStatus.Success) _elapsed = 0f;
            return s;
        }
    }

    // ── Leaf nodes ───────────────────────────────────────
    public sealed class ActionNode : BTNode
    {
        private readonly Func<BTContext, BTStatus> _action;
        public ActionNode(string name, Func<BTContext, BTStatus> action) { Name = name; _action = action; }
        public override BTStatus Tick(BTContext ctx) => _action(ctx);
    }

    public sealed class ConditionNode : BTNode
    {
        private readonly Func<BTContext, bool> _condition;
        public ConditionNode(string name, Func<BTContext, bool> condition) { Name = name; _condition = condition; }
        public override BTStatus Tick(BTContext ctx) =>
            _condition(ctx) ? BTStatus.Success : BTStatus.Failure;
    }

    // ── Context + Agent ──────────────────────────────────
    public sealed class BTContext
    {
        public float DeltaTime  { get; set; }
        public object? Agent    { get; set; }
        private readonly Dictionary<string, object?> _bb = new();
        public void   Set(string key, object? val) => _bb[key] = val;
        public T?     Get<T>(string key)           => _bb.TryGetValue(key, out var v) ? (T?)v : default;
        public bool   Has(string key)              => _bb.ContainsKey(key);
    }

    public sealed class BehaviorTreeAgent
    {
        public BTNode    Root    { get; set; }
        public BTContext Context { get; } = new();
        public BehaviorTreeAgent(BTNode root) { Root = root; }
        public void Tick(float dt) { Context.DeltaTime = dt; Root.Tick(Context); }
    }

    // ═══════════════════════════════════════════════════════
    //  Decision Trees
    // ═══════════════════════════════════════════════════════
    public abstract class DTNode
    {
        public abstract object? Evaluate(DTContext ctx);
    }

    public sealed class DTDecision : DTNode
    {
        private readonly Func<DTContext, bool> _test;
        private readonly DTNode _trueBranch, _falseBranch;
        public string Question { get; set; } = "";

        public DTDecision(string question, Func<DTContext, bool> test, DTNode trueBranch, DTNode falseBranch)
        { Question = question; _test = test; _trueBranch = trueBranch; _falseBranch = falseBranch; }

        public override object? Evaluate(DTContext ctx) =>
            _test(ctx) ? _trueBranch.Evaluate(ctx) : _falseBranch.Evaluate(ctx);
    }

    public sealed class DTAction : DTNode
    {
        private readonly object _result;
        public string Label { get; set; }
        public DTAction(string label, object result) { Label = label; _result = result; }
        public override object? Evaluate(DTContext ctx) { ctx.LastAction = Label; return _result; }
    }

    public sealed class DTContext
    {
        private readonly Dictionary<string, object?> _facts = new();
        public string? LastAction { get; internal set; }
        public void   Set(string key, object? val) => _facts[key] = val;
        public T?     Get<T>(string key)           => _facts.TryGetValue(key, out var v) ? (T?)v : default;
    }

    public sealed class DecisionTreeAgent
    {
        public DTNode    Root    { get; set; }
        public DTContext Context { get; } = new();
        public DecisionTreeAgent(DTNode root) { Root = root; }
        public object? Evaluate() => Root.Evaluate(Context);
    }

    // ═══════════════════════════════════════════════════════
    //  Steering Behaviors
    // ═══════════════════════════════════════════════════════
    public sealed class SteeringAgent
    {
        public Vector2 Position  { get; set; }
        public Vector2 Velocity  { get; set; }
        public float   MaxSpeed  { get; set; } = 5f;
        public float   MaxForce  { get; set; } = 10f;
        public float   Mass      { get; set; } = 1f;
        public float   Radius    { get; set; } = 0.5f;

        /// <summary>Apply a combined steering force and integrate.</summary>
        public void Steer(Vector2 force, float dt)
        {
            force = Truncate(force, MaxForce);
            var accel = force * (1f / Mass);
            Velocity  = Truncate(Velocity + accel * dt, MaxSpeed);
            Position += Velocity * dt;
        }

        private static Vector2 Truncate(Vector2 v, float max)
        {
            float len = v.Length();
            return len > max && len > 0f ? v * (max / len) : v;
        }
    }

    public static class Steering
    {
        // ── Basic behaviors ──────────────────────────────
        public static Vector2 Seek(SteeringAgent agent, Vector2 target)
        {
            var desired = (target - agent.Position).Normalized * agent.MaxSpeed;
            return desired - agent.Velocity;
        }

        public static Vector2 Flee(SteeringAgent agent, Vector2 target)
            => -Seek(agent, target);

        public static Vector2 Arrive(SteeringAgent agent, Vector2 target, float slowRadius = 3f)
        {
            var diff    = target - agent.Position;
            float dist  = diff.Length();
            if (dist < 0.01f) return -agent.Velocity;
            float speed = dist < slowRadius ? agent.MaxSpeed * (dist / slowRadius) : agent.MaxSpeed;
            var desired = diff.Normalized * speed;
            return desired - agent.Velocity;
        }

        public static Vector2 Pursue(SteeringAgent agent, SteeringAgent target)
        {
            float ahead = Vector2.Distance(agent.Position, target.Position) / agent.MaxSpeed;
            return Seek(agent, target.Position + target.Velocity * ahead);
        }

        public static Vector2 Evade(SteeringAgent agent, SteeringAgent threat)
        {
            float ahead = Vector2.Distance(agent.Position, threat.Position) / agent.MaxSpeed;
            return Flee(agent, threat.Position + threat.Velocity * ahead);
        }

        public static Vector2 Wander(SteeringAgent agent, ref float wanderAngle, float jitter = 0.5f,
            float circleRadius = 2f, float circleDistance = 4f)
        {
            var rng = new Random();
            wanderAngle += ((float)rng.NextDouble() * 2f - 1f) * jitter;
            var circleCenter = agent.Velocity.Length() > 0.01f
                ? agent.Velocity.Normalized * circleDistance
                : new Vector2(circleDistance, 0);
            var displacement = new Vector2(
                MathF.Cos(wanderAngle) * circleRadius,
                MathF.Sin(wanderAngle) * circleRadius);
            return Seek(agent, agent.Position + circleCenter + displacement);
        }

        // ── Group behaviors ──────────────────────────────
        public static Vector2 Separation(SteeringAgent agent, IEnumerable<SteeringAgent> neighbors,
            float desiredDist = 2f)
        {
            var force = Vector2.Zero;
            int count = 0;
            foreach (var nb in neighbors)
            {
                if (nb == agent) continue;
                float d = Vector2.Distance(agent.Position, nb.Position);
                if (d > 0 && d < desiredDist)
                {
                    force += (agent.Position - nb.Position).Normalized * (1f / d);
                    count++;
                }
            }
            return count > 0 ? (force * (1f / count)).Normalized * agent.MaxSpeed - agent.Velocity : Vector2.Zero;
        }

        public static Vector2 Cohesion(SteeringAgent agent, IEnumerable<SteeringAgent> neighbors)
        {
            var center = Vector2.Zero;
            int count  = 0;
            foreach (var nb in neighbors)
            {
                if (nb == agent) continue;
                center += nb.Position;
                count++;
            }
            return count > 0 ? Seek(agent, center * (1f / count)) : Vector2.Zero;
        }

        public static Vector2 Alignment(SteeringAgent agent, IEnumerable<SteeringAgent> neighbors)
        {
            var avg   = Vector2.Zero;
            int count = 0;
            foreach (var nb in neighbors)
            {
                if (nb == agent) continue;
                avg += nb.Velocity;
                count++;
            }
            return count > 0 ? avg.Normalized * agent.MaxSpeed - agent.Velocity : Vector2.Zero;
        }

        public static Vector2 Flock(SteeringAgent agent, IEnumerable<SteeringAgent> neighbors,
            float wSep = 1.5f, float wCoh = 1f, float wAlign = 1f)
        {
            var list = neighbors.ToList();
            return Separation(agent, list) * wSep
                 + Cohesion(agent,   list) * wCoh
                 + Alignment(agent,  list) * wAlign;
        }

        // ── Obstacle avoidance ───────────────────────────
        public static Vector2 ObstacleAvoidance(SteeringAgent agent, IEnumerable<Vector2> obstaclePositions,
            float avoidRadius = 2f, float lookAhead = 3f)
        {
            var ahead = agent.Position + agent.Velocity.Normalized * lookAhead;
            Vector2 best = Vector2.Zero;
            float closest = float.MaxValue;
            foreach (var obs in obstaclePositions)
            {
                float d = Vector2.Distance(ahead, obs);
                if (d < avoidRadius && d < closest)
                {
                    closest = d;
                    best = ahead - obs;
                }
            }
            return best.Length() > 0 ? best.Normalized * agent.MaxForce : Vector2.Zero;
        }

        // ── Path following ───────────────────────────────
        public static Vector2 FollowPath(SteeringAgent agent, List<Vector2> path, ref int pathIndex,
            float waypointRadius = 0.5f)
        {
            if (pathIndex >= path.Count) return Vector2.Zero;
            if (Vector2.Distance(agent.Position, path[pathIndex]) < waypointRadius)
                pathIndex = System.Math.Min(pathIndex + 1, path.Count - 1);
            return Arrive(agent, path[pathIndex]);
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Crowd Simulation
    // ═══════════════════════════════════════════════════════
    public sealed class CrowdAgent
    {
        public int           Id         { get; }
        public SteeringAgent Steering   { get; } = new();
        public List<Vector2> Path       { get; set; } = new();
        public int           PathIndex  { get; set; }
        public Vector2       Goal       { get; set; }
        public CrowdAgentState State    { get; set; } = CrowdAgentState.Idle;
        public string        Group      { get; set; } = "default";
        public float         WanderAngle { get; set; }

        private static int _nextId;
        public CrowdAgent() { Id = System.Threading.Interlocked.Increment(ref _nextId); }
    }

    public enum CrowdAgentState { Idle, Moving, Avoiding, Arrived }

    public sealed class CrowdSimulator
    {
        public List<CrowdAgent>  Agents    { get; } = new();
        public NavMesh?          NavMesh   { get; set; }
        public float             NeighborRadius { get; set; } = 3f;
        public bool              UseRVO   { get; set; } = true;  // Reciprocal Velocity Obstacles

        private readonly Dictionary<string, List<CrowdAgent>> _groups = new();

        public CrowdAgent AddAgent(Vector2 position, string group = "default")
        {
            var agent = new CrowdAgent { Group = group };
            agent.Steering.Position = position;
            Agents.Add(agent);
            if (!_groups.ContainsKey(group)) _groups[group] = new();
            _groups[group].Add(agent);
            Console.WriteLine($"[Crowd] Agent#{agent.Id} added at {position}.");
            return agent;
        }

        public void RemoveAgent(CrowdAgent agent)
        {
            Agents.Remove(agent);
            _groups.GetValueOrDefault(agent.Group)?.Remove(agent);
        }

        public void SetGoal(CrowdAgent agent, Vector2 goal)
        {
            agent.Goal = goal;
            if (NavMesh?.Built == true)
                agent.Path = AStar.FindPath(NavMesh, agent.Steering.Position, goal);
            else
                agent.Path = new List<Vector2> { goal };
            agent.PathIndex = 0;
            agent.State = CrowdAgentState.Moving;
        }

        public void Update(float dt)
        {
            foreach (var agent in Agents)
            {
                if (agent.State != CrowdAgentState.Moving) continue;
                if (agent.Path.Count == 0)               { agent.State = CrowdAgentState.Arrived; continue; }

                var neighbors = Agents.Where(a => a != agent &&
                    Vector2.Distance(a.Steering.Position, agent.Steering.Position) < NeighborRadius).ToList();

                var steer = Vector2.Zero;
                // Path following
                steer += Steering.FollowPath(agent.Steering, agent.Path, ref agent.PathIndex) * 1.5f;
                // Separation from crowd
                steer += Steering.Separation(agent.Steering,
                    neighbors.Select(n => n.Steering), agent.Steering.Radius * 2f) * 2f;
                // Optional RVO
                if (UseRVO && neighbors.Count > 0)
                    steer += RVO(agent, neighbors) * 1.2f;

                if (agent.PathIndex >= agent.Path.Count &&
                    Vector2.Distance(agent.Steering.Position, agent.Goal) < 0.5f)
                {
                    agent.State = CrowdAgentState.Arrived;
                    agent.Steering.Velocity = Vector2.Zero;
                    continue;
                }

                agent.Steering.Steer(steer, dt);
            }
        }

        /// <summary>Simplified Reciprocal Velocity Obstacles.</summary>
        private static Vector2 RVO(CrowdAgent agent, List<CrowdAgent> neighbors)
        {
            var avoid = Vector2.Zero;
            foreach (var nb in neighbors)
            {
                var relPos  = nb.Steering.Position - agent.Steering.Position;
                var relVel  = agent.Steering.Velocity - nb.Steering.Velocity;
                float dist  = relPos.Length();
                float combinedRadius = agent.Steering.Radius + nb.Steering.Radius + 0.3f;
                if (dist < combinedRadius * 2f)
                {
                    // Compute avoidance velocity perturbation
                    var perp = new Vector2(-relPos.Y, relPos.X).Normalized;
                    float dot = Vector2.Dot(relVel, relPos.Normalized);
                    if (dot > 0)
                        avoid += perp * (combinedRadius / dist);
                }
            }
            return avoid;
        }

        public IEnumerable<CrowdAgent> GetGroup(string group) =>
            _groups.TryGetValue(group, out var list) ? list : Enumerable.Empty<CrowdAgent>();
    }
}
