// BADGE Engine – SDK/SDKAPI.cs
// Plugin API, Editor Extension API, Game Framework base classes
using System;
using System.Collections.Generic;
using BADGE.Engine.Core;

namespace BADGE.Engine.SDK
{
    // ── Plugin API ─────────────────────────────────────────
    public interface IEnginePlugin
    {
        string Name    { get; }
        string Version { get; }
        string Author  { get; }
        void Initialize(EngineKernel kernel);
        void Shutdown();
    }

    public abstract class EnginePlugin : IEnginePlugin
    {
        public abstract string Name    { get; }
        public abstract string Version { get; }
        public abstract string Author  { get; }
        protected EngineKernel Kernel  { get; private set; } = null!;
        public void Initialize(EngineKernel k) { Kernel=k; OnInit(); }
        public void Shutdown() { OnShutdown(); }
        protected virtual void OnInit()     {}
        protected virtual void OnShutdown() {}
    }

    // PluginManager lives in Engine/PluginManager/PluginManager.cs (BADGE.Engine.Core).
    // SDK consumers should use BADGE.Engine.Core.PluginManager.Instance directly.

    // ── Editor Extension API ───────────────────────────────
    public interface IEditorExtension
    {
        string TabName { get; }
        void OnGUI();
        void OnOpen();
        void OnClose();
    }

    // ── Game Framework ─────────────────────────────────────
    public abstract class GameApplication
    {
        protected EngineKernel Kernel => EngineKernel.Instance;

        public void Run(EngineConfig? cfg = null)
        {
            if (cfg is not null)
                Engine.Instance.Config.SetConfig(cfg);
            Engine.Instance.Initialize(showBootScreen: true);
            OnInitialize();
            Engine.Instance.Run();
            OnShutdown();
        }

        protected abstract void OnInitialize();
        protected virtual  void OnShutdown() {}
    }

    // ── Script Templates ───────────────────────────────────
    public static class ScriptTemplates
    {
        public const string PlayerController = @"
using BADGE.Engine;
using BADGE.Engine.Components;
using BADGE.Engine.Input;
using BADGE.Engine.Math;

public class PlayerController : ScriptBehaviour
{
    public float MoveSpeed = 5f;
    public float JumpForce = 7f;
    private Rigidbody rb;

    public override void OnStart()
    {
        rb = GetComponent<Rigidbody>();
    }

    public override void OnUpdate(float dt)
    {
        float h = EngineKernel.Instance.Input.GetAxis(""Horizontal"");
        float v = EngineKernel.Instance.Input.GetAxis(""Vertical"");
        var move = new Vector3(h, 0, v).Normalized * MoveSpeed;
        rb?.AddForce(new Vector3(move.X, 0, move.Z), ForceMode.VelocityChange);

        if(EngineKernel.Instance.Input.GetKeyDown(KeyCode.Space))
            rb?.AddForce(new Vector3(0, JumpForce, 0), ForceMode.Impulse);
    }
}";

        public const string EnemyAI = @"
using BADGE.Engine;
using BADGE.Engine.Components;
using BADGE.Engine.AI;

public class EnemyAI : ScriptBehaviour
{
    public float DetectRange = 10f;
    public float AttackRange = 2f;
    private NavMeshAgent agent;

    public override void OnStart()
    {
        agent = GetComponent<NavMeshAgent>();
    }

    public override void OnUpdate(float dt)
    {
        var player = Scene.Scene.FindObjectOfType<PlayerController>();
        if(player == null) return;
        float dist = Vector3.Distance(Transform.Position, player.Transform.Position);
        if(dist < DetectRange)
            agent?.SetDestination(player.Transform.Position);
    }
}";

        public const string GameManager = @"
using BADGE.Engine;
using BADGE.Engine.Components;

public class GameManager : ScriptBehaviour
{
    public static GameManager Instance { get; private set; }
    public int Score { get; private set; }
    public int Lives { get; private set; } = 3;

    public override void OnStart()
    {
        if(Instance != null) { GameObject.Destroy(GameObject); return; }
        Instance = this;
        Object.DontDestroyOnLoad(GameObject);
    }

    public void AddScore(int pts) { Score += pts; }
    public void LoseLife() { Lives--; if(Lives<=0) GameOver(); }
    private void GameOver() { EngineKernel.Instance.SceneManager.LoadScene(""GameOver""); }
}";
    }
}
