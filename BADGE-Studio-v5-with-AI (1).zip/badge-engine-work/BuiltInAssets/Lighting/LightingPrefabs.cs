// ============================================================
//  BADGE Engine – BuiltInAssets/Lighting/LightingPrefabs.cs
//  Competition-ready light fixture game-object factories.
// ============================================================
using System;
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Lighting
{
    public static class LightingPrefabs
    {
        // ── Torch ────────────────────────────────────────────
        /// <summary>
        /// Wall or floor torch with flickering point light,
        /// fire particle emitter and looping crackle audio.
        /// Flicker uses noise-based intensity variation.
        /// </summary>
        public static GameObject Torch()
        {
            var root = new GameObject("Light_Torch");

            // Bracket / sconce mesh
            var bracket = new GameObject("Bracket");
            bracket.Parent = root;
            var bMr = bracket.AddComponent<MeshRenderer>();
            bMr.Mesh     = "builtin:mesh/torch_bracket";
            bMr.Material = Materials.TorchIron;
            bracket.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Bowl with embers mesh
            var bowl = new GameObject("Bowl");
            bowl.Parent = root;
            bowl.Transform.LocalPosition = new Vector3(0f, 0.3f, 0f);
            var bowlMr = bowl.AddComponent<MeshRenderer>();
            bowlMr.Mesh     = "builtin:mesh/torch_bowl";
            bowlMr.Material = Materials.TorchBowl;

            // Flame particles
            var flame = new GameObject("Flame");
            flame.Parent = root;
            flame.Transform.LocalPosition = new Vector3(0f, 0.45f, 0f);
            var pe = flame.AddComponent<ParticleEmitter>();
            pe.Rate        = 20f;
            pe.LifetimeMin = 0.3f; pe.LifetimeMax = 0.6f;
            pe.SpeedMin    = 0.4f; pe.SpeedMax    = 1f;
            pe.SizeMin     = 0.06f; pe.SizeMax    = 0.18f;
            pe.ColorStart  = new Color(1f, 0.6f, 0.05f);
            pe.ColorEnd    = new Color(1f, 0.1f, 0f, 0f);
            pe.Shape       = EmissionShapeType.Point;
            pe.Gravity     = -0.5f;

            // Ember particles (drift up)
            var embers = new GameObject("Embers");
            embers.Parent = root;
            embers.Transform.LocalPosition = new Vector3(0f, 0.4f, 0f);
            var ep = embers.AddComponent<ParticleEmitter>();
            ep.Rate = 4f; ep.LifetimeMin = 1f; ep.LifetimeMax = 2.5f;
            ep.SpeedMin = 0.2f; ep.SpeedMax = 0.8f;
            ep.SizeMin = 0.01f; ep.SizeMax = 0.04f;
            ep.ColorStart = new Color(1f, 0.55f, 0.1f, 0.9f);
            ep.ColorEnd   = new Color(0.3f, 0.1f, 0f, 0f);
            ep.Gravity    = -1f;

            // Flickering point light
            var lightObj = new GameObject("FlameLight");
            lightObj.Parent = root;
            lightObj.Transform.LocalPosition = new Vector3(0f, 0.5f, 0f);
            var light = lightObj.AddComponent<Light>();
            light.Type      = LightType.Point;
            light.Color     = new Color(1f, 0.65f, 0.2f);
            light.Intensity = 2.5f;
            light.Range     = 8f;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/fire_crackle"; audio.Loop = true; audio.PlayOnAwake = true;
            audio.Volume = 0.4f; audio.SpatialBlend = 1f; audio.MaxDistance = 12f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "FlickerLight";
            script.SetField("BaseIntensity",    2.5f);
            script.SetField("FlickerAmount",    0.6f);
            script.SetField("FlickerSpeed",     8f);
            script.SetField("FlickerNoiseScale",2.5f);
            script.SetField("FlameLight",       light);
            script.SetField("Audio",            audio);

            return root;
        }

        // ── Street Lamp ──────────────────────────────────────
        /// <summary>
        /// Urban lamp post with warm overhead light, a configurable
        /// flicker probability and a glass bloom sprite.
        /// </summary>
        public static GameObject StreetLamp()
        {
            var root = new GameObject("Light_StreetLamp");

            // Pole mesh
            var pole = new GameObject("Pole");
            pole.Parent = root;
            var pMr = pole.AddComponent<MeshRenderer>();
            pMr.Mesh     = Mesh.CreateCylinder(0.06f, 5f);
            pMr.Material = Materials.MetalPole;
            pole.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Arm (horizontal extension)
            var arm = new GameObject("Arm");
            arm.Parent = root;
            arm.Transform.LocalPosition = new Vector3(0.5f, 5f, 0f);
            var aMr = arm.AddComponent<MeshRenderer>();
            aMr.Mesh     = Mesh.CreateCylinder(0.04f, 1.0f);
            aMr.Material = Materials.MetalPole;

            // Lantern housing
            var lantern = new GameObject("Lantern");
            lantern.Parent = root;
            lantern.Transform.LocalPosition = new Vector3(1f, 5f, 0f);
            var lMr = lantern.AddComponent<MeshRenderer>();
            lMr.Mesh     = Mesh.CreateCube(new Vector3(0.35f, 0.4f, 0.35f));
            lMr.Material = Materials.LanternGlass;

            // Glass bloom sprite child
            var bloom = new GameObject("GlassBloom");
            bloom.Parent = lantern;
            var bloomSr = bloom.AddComponent<SpriteRenderer>();
            bloomSr.Sprite = "builtin:sprites/light_bloom";
            bloomSr.Color  = new Color(1f, 0.9f, 0.5f, 0.5f);

            // Point light child
            var lightObj = new GameObject("LampLight");
            lightObj.Parent = lantern;
            lightObj.Transform.LocalPosition = new Vector3(0f, -0.2f, 0f);
            var light = lightObj.AddComponent<Light>();
            light.Type      = LightType.Point;
            light.Color     = new Color(1f, 0.88f, 0.55f);
            light.Intensity = 3f;
            light.Range     = 14f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "StreetLampController";
            script.SetField("FlickerProbability", 0.002f);  // Per frame
            script.SetField("FlickerDuration",    0.08f);
            script.SetField("NightOnlyMode",      false);
            script.SetField("LampLight",          light);
            script.SetField("BloomSprite",        bloom);

            return root;
        }

        // ── Spotlight Rig ────────────────────────────────────
        /// <summary>
        /// Two-spotlight stage rig for arenas, concerts and
        /// interrogation rooms.  Supports colour cycling and
        /// sweep animation modes.
        /// </summary>
        public static GameObject SpotlightRig()
        {
            var root = new GameObject("Light_SpotlightRig");

            // Truss bar mesh
            var truss = new GameObject("Truss");
            truss.Parent = root;
            var tMr = truss.AddComponent<MeshRenderer>();
            tMr.Mesh     = Mesh.CreateCylinder(0.05f, 4f);
            tMr.Material = Materials.MetalPole;
            truss.Transform.LocalEulerAngles = new Vector3(0f, 0f, 90f);

            // Two spot heads
            foreach (var (xOff, name, hue) in new[] {
                (-1.5f, "SpotL", new Color(1f, 0.3f, 0.3f)),
                ( 1.5f, "SpotR", new Color(0.3f, 0.5f, 1f)) })
            {
                var head = new GameObject(name);
                head.Parent = root;
                head.Transform.LocalPosition = new Vector3(xOff, 0f, 0f);

                var hMr = head.AddComponent<MeshRenderer>();
                hMr.Mesh     = Mesh.CreateCylinder(0.15f, 0.35f);
                hMr.Material = Materials.SpotlightCan;

                var sl = head.AddComponent<Light>();
                sl.Type       = LightType.Spot;
                sl.Color      = hue;
                sl.Intensity  = 20f;
                sl.Range      = 25f;
                sl.SpotAngle  = 22f;
            }

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "SpotlightRigController";
            script.SetField("Mode",          "Sweep");    // Static | Sweep | ColorCycle
            script.SetField("SweepAngle",    45f);
            script.SetField("SweepSpeed",    30f);
            script.SetField("ColorCycleRate",0.5f);

            return root;
        }

        // ── Lava Glow ────────────────────────────────────────
        /// <summary>
        /// Area light with pulsing intensity simulating molten rock.
        /// Pairs well with LavaFloor trap prefab.
        /// </summary>
        public static GameObject LavaGlow()
        {
            var root = new GameObject("Light_LavaGlow");

            var lightObj = new GameObject("LavaLight");
            lightObj.Parent = root;
            var light = lightObj.AddComponent<Light>();
            light.Type      = LightType.Point;
            light.Color     = new Color(1f, 0.3f, 0.04f);
            light.Intensity = 4f;
            light.Range     = 10f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "FlickerLight";
            script.SetField("BaseIntensity",    4f);
            script.SetField("FlickerAmount",    1f);
            script.SetField("FlickerSpeed",     2f);
            script.SetField("FlickerNoiseScale",1f);
            script.SetField("FlameLight",       light);

            return root;
        }
    }
}
