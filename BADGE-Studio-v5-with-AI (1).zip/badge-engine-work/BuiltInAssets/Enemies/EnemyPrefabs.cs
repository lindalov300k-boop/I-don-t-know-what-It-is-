// ============================================================
//  BADGE Engine – BuiltInAssets/Enemies/EnemyPrefabs.cs
//  Competition-ready AI enemy game-object factories.
// ============================================================
using System;
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Enemies
{
    public static class EnemyPrefabs
    {
        // ─── shared helper ────────────────────────────────────
        private static void AddNavAgent(GameObject go,
            float speed, float accel, float stopDist, float turnSpeed)
        {
            var nav = go.AddComponent<NavMeshAgent>();
            nav.Speed            = speed;
            nav.Acceleration     = accel;
            nav.StoppingDistance = stopDist;
            nav.AngularSpeed     = turnSpeed;
        }

        // ── Grunt ─────────────────────────────────────────────
        /// <summary>
        /// Basic melee patrol enemy.
        /// States: Idle → Patrol → Alert → Chase → Attack → Dead.
        /// Uses NavMesh pathfinding, field-of-view cone perception,
        /// melee strike animation and a death ragdoll impulse.
        /// </summary>
        public static GameObject Grunt()
        {
            var root = new GameObject("Enemy_Grunt");
            root.Tag   = "Enemy";
            root.Layer = Layers.Enemy;

            var col = root.AddComponent<Collider>();
            col.Shape  = ColliderShape.Capsule;
            col.Radius = 0.4f;
            col.Size   = new Vector3(0.8f, 1.8f, 0.8f);

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass        = 80f;
            rb.Drag        = 5f;
            rb.UseGravity  = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            AddNavAgent(root, speed: 3.5f, accel: 10f, stopDist: 1.2f, turnSpeed: 180f);

            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth     = 80f;
            hp.CurrentHealth = 80f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/grunt";

            var perc = root.AddComponent<AIPerception>();
            perc.SightRange    = 14f;
            perc.SightFOV      = 110f;
            perc.HearingRadius = 8f;

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCapsule(0.4f, 1.8f);
            mr.Material = Materials.EnemyGrunt;

            // Hit sound
            var audio = root.AddComponent<AudioSource>();
            audio.Clip         = "builtin:audio/grunt_hurt";
            audio.SpatialBlend = 1f;
            audio.MaxDistance  = 25f;

            // Attack hit-box child (enabled only during attack anim)
            var hitbox = new GameObject("MeleeHitbox");
            hitbox.Parent = root;
            hitbox.Transform.LocalPosition = new Vector3(0f, 1f, 0.9f);
            var hbCol = hitbox.AddComponent<Collider>();
            hbCol.Shape  = ColliderShape.Box;
            hbCol.Size   = new Vector3(1.0f, 0.8f, 0.7f);
            hbCol.IsTrigger = true;
            hitbox.SetActive(false);

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "GruntAI";
            script.SetField("PatrolRadius",    8f);
            script.SetField("AttackDamage",    20f);
            script.SetField("AttackRange",     1.3f);
            script.SetField("AttackCooldown",  1.4f);
            script.SetField("AlertSpeed",      5.5f);
            script.SetField("Animator",        anim);
            script.SetField("Perception",      perc);
            script.SetField("MeleeHitbox",     hitbox);
            script.SetField("Audio",           audio);

            return root;
        }

        // ── Archer ────────────────────────────────────────────
        /// <summary>
        /// Ranged bow enemy.
        /// Leads moving targets, retreats when player gets close,
        /// takes cover behind obstacles when health drops below 30 %.
        /// </summary>
        public static GameObject Archer()
        {
            var root = new GameObject("Enemy_Archer");
            root.Tag   = "Enemy";
            root.Layer = Layers.Enemy;

            var col = root.AddComponent<Collider>();
            col.Shape  = ColliderShape.Capsule;
            col.Radius = 0.38f;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 65f; rb.Drag = 5f; rb.UseGravity = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            AddNavAgent(root, speed: 3.0f, accel: 8f, stopDist: 6f, turnSpeed: 200f);

            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth = hp.CurrentHealth = 55f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/archer";

            var perc = root.AddComponent<AIPerception>();
            perc.SightRange = 22f;
            perc.SightFOV   = 90f;
            perc.HearingRadius = 6f;

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCapsule(0.38f, 1.75f);
            mr.Material = Materials.EnemyArcher;

            // Arrow spawn point child
            var bowSocket = new GameObject("BowSocket");
            bowSocket.Parent = root;
            bowSocket.Transform.LocalPosition = new Vector3(0.3f, 1.4f, 0.5f);

            var audio = root.AddComponent<AudioSource>();
            audio.Clip         = "builtin:audio/bow_shoot";
            audio.SpatialBlend = 1f;
            audio.MaxDistance  = 35f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ArcherAI";
            script.SetField("AttackDamage",     15f);
            script.SetField("ArrowSpeed",       28f);
            script.SetField("ArrowDrop",        9.8f);
            script.SetField("ShotLeadFactor",   0.6f);
            script.SetField("AttackCooldown",   2.0f);
            script.SetField("RetreatRange",     4f);
            script.SetField("PreferredRange",   12f);
            script.SetField("CoverThreshold",   0.3f);  // 30 % HP
            script.SetField("Animator",         anim);
            script.SetField("Perception",       perc);
            script.SetField("BowSocket",        bowSocket);
            script.SetField("Audio",            audio);

            return root;
        }

        // ── Flying Drone ─────────────────────────────────────
        /// <summary>
        /// Aerial burst-fire drone.
        /// Strafe-circles the player at a fixed altitude, fires
        /// 3-round bursts, banks visually during turns.
        /// </summary>
        public static GameObject FlyingDrone()
        {
            var root = new GameObject("Enemy_FlyingDrone");
            root.Tag   = "Enemy";
            root.Layer = Layers.Enemy;

            // No gravity – fully scripted flight
            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 15f; rb.Drag = 3f; rb.UseGravity = false;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            var col = root.AddComponent<Collider>();
            col.Shape  = ColliderShape.Sphere;
            col.Radius = 0.55f;

            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth = hp.CurrentHealth = 40f;

            var perc = root.AddComponent<AIPerception>();
            perc.SightRange = 30f;
            perc.SightFOV   = 200f;   // Drone has wide sensors

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateSphere(0.55f, 12, 16);
            mr.Material = Materials.EnemyDrone;
            mr.CastShadows = false;

            // Engine glow light child
            var glow = new GameObject("EngineFire");
            glow.Parent = root;
            glow.Transform.LocalPosition = new Vector3(0f, -0.4f, 0f);
            var light = glow.AddComponent<Light>();
            light.Type      = LightType.Point;
            light.Color     = new Color(0.2f, 0.6f, 1f);
            light.Intensity = 2.5f;
            light.Range     = 4f;

            // Muzzle flash child
            var muzzle = new GameObject("Muzzle");
            muzzle.Parent = root;
            muzzle.Transform.LocalPosition = new Vector3(0f, 0f, 0.6f);

            var audio = root.AddComponent<AudioSource>();
            audio.Clip         = "builtin:audio/drone_shoot";
            audio.SpatialBlend = 1f;
            audio.MaxDistance  = 40f;

            var engineAudio = root.AddComponent<AudioSource>();
            engineAudio.Clip       = "builtin:audio/drone_hum";
            engineAudio.Loop       = true;
            engineAudio.Volume     = 0.4f;
            engineAudio.PlayOnAwake = true;
            engineAudio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "FlyingDroneAI";
            script.SetField("PatrolAltitude",   5f);
            script.SetField("CircleRadius",     7f);
            script.SetField("CircleSpeed",      4.5f);
            script.SetField("BurstCount",       3);
            script.SetField("BurstRate",        0.12f);
            script.SetField("BurstCooldown",    2.5f);
            script.SetField("BulletDamage",     8f);
            script.SetField("BulletSpeed",      40f);
            script.SetField("BankAngleMax",     35f);
            script.SetField("Perception",       perc);
            script.SetField("MuzzleSocket",     muzzle);
            script.SetField("EngineLight",      light);
            script.SetField("Audio",            audio);

            return root;
        }

        // ── Boss Knight ───────────────────────────────────────
        /// <summary>
        /// Multi-phase arena boss.
        /// Phase 1 (100-50 % HP): ground pound + sword sweep.
        /// Phase 2 (50-0 % HP):   enrages, gains shield, adds
        ///     homing projectile volley and charge attack.
        /// Phase transition: screen flash, VFX burst, audio sting.
        /// </summary>
        public static GameObject BossKnight()
        {
            var root = new GameObject("Enemy_BossKnight");
            root.Tag   = "Boss";
            root.Layer = Layers.Enemy;

            var col = root.AddComponent<Collider>();
            col.Shape  = ColliderShape.Capsule;
            col.Radius = 0.7f;
            col.Size   = new Vector3(1.4f, 3f, 1.4f);

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 400f; rb.Drag = 10f; rb.UseGravity = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            AddNavAgent(root, speed: 4f, accel: 6f, stopDist: 1.8f, turnSpeed: 120f);

            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth = hp.CurrentHealth = 800f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/boss_knight";

            var perc = root.AddComponent<AIPerception>();
            perc.SightRange    = 40f;
            perc.SightFOV      = 180f;
            perc.HearingRadius = 40f;   // Boss is always aware

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCapsule(0.7f, 3f);
            mr.Material = Materials.BossKnight;

            // Ground pound shockwave child (disabled until attack)
            var shockwave = new GameObject("Shockwave");
            shockwave.Parent = root;
            var swCol = shockwave.AddComponent<Collider>();
            swCol.Shape     = ColliderShape.Sphere;
            swCol.Radius    = 0f;   // Radius set by script at runtime
            swCol.IsTrigger = true;
            shockwave.SetActive(false);

            // Phase-2 shield FX child
            var shield = new GameObject("BossShield");
            shield.Parent = root;
            var shieldSr = shield.AddComponent<MeshRenderer>();
            shieldSr.Mesh     = Mesh.CreateSphere(1.2f);
            shieldSr.Material = Materials.BossShield;
            shield.SetActive(false);

            // Sword socket child
            var sword = new GameObject("SwordSocket");
            sword.Parent = root;
            sword.Transform.LocalPosition = new Vector3(0.9f, 1.5f, 0.5f);

            // Audio sources
            var audioRoar  = root.AddComponent<AudioSource>();
            audioRoar.Clip = "builtin:audio/boss_roar";
            audioRoar.Volume = 1f; audioRoar.SpatialBlend = 1f; audioRoar.MaxDistance = 80f;

            var audioHit = root.AddComponent<AudioSource>();
            audioHit.Clip  = "builtin:audio/boss_swordswing";
            audioHit.Volume = 0.9f; audioHit.SpatialBlend = 1f; audioHit.MaxDistance = 50f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "BossKnightAI";
            script.SetField("Phase1AttackDamage",   50f);
            script.SetField("Phase2AttackDamage",   70f);
            script.SetField("SweepRange",           4.5f);
            script.SetField("SweepArc",             120f);
            script.SetField("GroundPoundRadius",    5f);
            script.SetField("GroundPoundDamage",    60f);
            script.SetField("ChargeSpeed",          14f);
            script.SetField("ChargeDistance",       12f);
            script.SetField("ProjectileCount",      8);
            script.SetField("ProjectileDamage",     25f);
            script.SetField("PhaseThreshold",       0.5f);
            script.SetField("ShieldHP",             150f);
            script.SetField("Animator",             anim);
            script.SetField("Perception",           perc);
            script.SetField("ShockwaveObj",         shockwave);
            script.SetField("ShieldObj",            shield);
            script.SetField("SwordSocket",          sword);
            script.SetField("AudioRoar",            audioRoar);
            script.SetField("AudioAttack",          audioHit);

            return root;
        }

        // ── Crawler ───────────────────────────────────────────
        /// <summary>
        /// Fast low-profile enemy.  Uses off-mesh links to scale
        /// walls and ceilings.  Leaps at the player when in range.
        /// </summary>
        public static GameObject Crawler()
        {
            var root = new GameObject("Enemy_Crawler");
            root.Tag   = "Enemy";
            root.Layer = Layers.Enemy;

            var col = root.AddComponent<Collider>();
            col.Shape  = ColliderShape.Box;
            col.Size   = new Vector3(0.9f, 0.45f, 0.7f);

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 30f; rb.Drag = 4f; rb.UseGravity = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            AddNavAgent(root, speed: 6f, accel: 20f, stopDist: 0.5f, turnSpeed: 360f);

            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth = hp.CurrentHealth = 30f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/crawler";

            var perc = root.AddComponent<AIPerception>();
            perc.SightRange    = 16f;
            perc.SightFOV      = 150f;
            perc.HearingRadius = 10f;

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCube(0.8f);
            mr.Material = Materials.EnemyCrawler;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/crawler_skitter";
            audio.Loop = true; audio.PlayOnAwake = true;
            audio.Volume = 0.3f; audio.SpatialBlend = 1f; audio.MaxDistance = 20f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "CrawlerAI";
            script.SetField("LeapRange",        3.5f);
            script.SetField("LeapForce",        12f);
            script.SetField("LeapCooldown",     3f);
            script.SetField("AttackDamage",     12f);
            script.SetField("ClimbSpeed",       5f);
            script.SetField("UseWallClimb",     true);
            script.SetField("Animator",         anim);
            script.SetField("Perception",       perc);
            script.SetField("Audio",            audio);

            return root;
        }
    }
}
