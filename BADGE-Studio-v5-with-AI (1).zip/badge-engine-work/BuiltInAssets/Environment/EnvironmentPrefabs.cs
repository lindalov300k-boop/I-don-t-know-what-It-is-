// ============================================================
//  BADGE Engine – BuiltInAssets/Environment/EnvironmentPrefabs.cs
//  Competition-ready environmental prop factories.
// ============================================================
using System;
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Environment
{
    public static class EnvironmentPrefabs
    {
        // ── Wooden Crate ──────────────────────────────────────
        /// <summary>
        /// Destructible wooden crate with 3 health stages (intact,
        /// cracked, destroyed), splinter VFX and a configurable
        /// weighted loot table.
        /// </summary>
        public static GameObject WoodenCrate()
        {
            var root = new GameObject("Env_WoodenCrate");
            root.Tag   = "Destructible";
            root.Layer = Layers.Default;

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCube(1f);
            mr.Material = Materials.WoodCrate;
            mr.CastShadows    = true;
            mr.ReceiveShadows = true;

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Box;
            col.Size  = Vector3.One;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 25f; rb.Drag = 0.5f; rb.UseGravity = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = false;   // Can tip over

            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth = hp.CurrentHealth = 60f;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/wood_impact"; audio.SpatialBlend = 1f; audio.MaxDistance = 20f;

            // Cracked mesh child (shown at 33 % HP)
            var cracked = new GameObject("CratedMesh_Cracked");
            cracked.Parent = root;
            var crackedMr = cracked.AddComponent<MeshRenderer>();
            crackedMr.Mesh     = "builtin:mesh/crate_cracked";
            crackedMr.Material = Materials.WoodCrateDamaged;
            cracked.SetActive(false);

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "DestructibleProp";
            script.SetField("Stage1Threshold",  0.66f);
            script.SetField("Stage2Threshold",  0.33f);
            script.SetField("DestroyVFX",       "builtin:vfx/crate_splinter");
            script.SetField("LootTable",        "builtin:loot/crate_common");
            script.SetField("ImpactAudio",      audio);
            script.SetField("CrackedMesh",      cracked);
            script.SetField("PhysicsDebris",    true);

            return root;
        }

        // ── Explosive Barrel ──────────────────────────────────
        /// <summary>
        /// Red steel barrel that detonates at 0 HP or when caught
        /// in another explosion's radius (chain reaction).
        /// </summary>
        public static GameObject ExplosiveBarrel()
        {
            var root = new GameObject("Env_ExplosiveBarrel");
            root.Tag   = "Explosive";
            root.Layer = Layers.Default;

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCylinder(0.35f, 0.9f);
            mr.Material = Materials.ExplosiveBarrel;

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Capsule;
            col.Radius = 0.35f; col.Size = new Vector3(0.7f, 0.9f, 0.7f);

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 40f; rb.Drag = 0.3f; rb.UseGravity = true;

            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth = hp.CurrentHealth = 40f;

            // Danger warning light (blinks when HP < 50 %)
            var warnLight = new GameObject("WarningLight");
            warnLight.Parent = root;
            warnLight.Transform.LocalPosition = new Vector3(0f, 0.5f, 0f);
            var light = warnLight.AddComponent<Light>();
            light.Type = LightType.Point; light.Color = new Color(1f, 0.1f, 0.05f);
            light.Intensity = 0f; light.Range = 3f;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/barrel_beep"; audio.SpatialBlend = 1f;

            // Explosion trigger zone (enabled at detonate)
            var blastZone = new GameObject("BlastZone");
            blastZone.Parent = root;
            var bCol = blastZone.AddComponent<Collider>();
            bCol.Shape = ColliderShape.Sphere; bCol.Radius = 5f; bCol.IsTrigger = true;
            blastZone.SetActive(false);

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ExplosiveProp";
            script.SetField("ExplosionRadius",  5f);
            script.SetField("ExplosionDamage",  80f);
            script.SetField("KnockbackForce",   18f);
            script.SetField("ChainDelay",       0.08f);
            script.SetField("WarnThreshold",    0.5f);
            script.SetField("WarningBlink",     4f);
            script.SetField("WarningLight",     light);
            script.SetField("BlastZone",        blastZone);
            script.SetField("Audio",            audio);

            return root;
        }

        // ── Oak Tree ──────────────────────────────────────────
        /// <summary>
        /// LOD oak tree with procedural wind in foliage via
        /// ClothPhysics on the leaves layer. Casts and receives shadows.
        /// </summary>
        public static GameObject OakTree()
        {
            var root = new GameObject("Env_OakTree");
            root.Tag   = "Environment";

            // Trunk mesh
            var trunk = new GameObject("Trunk");
            trunk.Parent = root;
            var trunkMr = trunk.AddComponent<MeshRenderer>();
            trunkMr.Mesh     = Mesh.CreateCylinder(0.3f, 3.5f);
            trunkMr.Material = Materials.TreeBark;
            trunkMr.CastShadows = true; trunkMr.ReceiveShadows = true;

            var trunkCol = trunk.AddComponent<Collider>();
            trunkCol.Shape  = ColliderShape.Capsule;
            trunkCol.Radius = 0.3f;

            // Foliage mesh child
            var foliage = new GameObject("Foliage");
            foliage.Parent = root;
            foliage.Transform.LocalPosition = new Vector3(0f, 3.5f, 0f);
            var foliageMr = foliage.AddComponent<MeshRenderer>();
            foliageMr.Mesh     = Mesh.CreateSphere(2.2f, 8, 10);
            foliageMr.Material = Materials.TreeLeaves;
            foliageMr.CastShadows = true;

            // Cloth wind on foliage
            var cloth = foliage.AddComponent<ClothPhysics>();
            cloth.WindInfluence    = 0.35f;
            cloth.Gravity          = 0f;
            cloth.Stiffness        = 0.8f;

            return root;
        }

        // ── Large Rock ───────────────────────────────────────
        /// <summary>
        /// Navigation-obstacle rock cluster with mesh collider.
        /// </summary>
        public static GameObject LargeRock()
        {
            var root = new GameObject("Env_LargeRock");
            root.Tag   = "Environment";

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = "builtin:mesh/rock_large";
            mr.Material = Materials.Rock;
            mr.CastShadows = true; mr.ReceiveShadows = true;

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Mesh;   // Exact rock silhouette

            return root;
        }

        // ── Moving Platform ───────────────────────────────────
        /// <summary>
        /// Waypoint-based kinematic platform.  Carries passengers
        /// by re-parenting them on contact.  Supports ping-pong
        /// and looped waypoint lists.
        /// </summary>
        public static GameObject MovingPlatform()
        {
            var root = new GameObject("Env_MovingPlatform");
            root.Tag   = "MovingPlatform";

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCube(new Vector3(4f, 0.3f, 2f));
            mr.Material = Materials.PlatformMetal;
            mr.CastShadows = true; mr.ReceiveShadows = true;

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Box;
            col.Size  = new Vector3(4f, 0.3f, 2f);

            var rb = root.AddComponent<Rigidbody>();
            rb.IsKinematic = true;

            // Passenger detection trigger (slightly larger than platform surface)
            var passengerTrigger = new GameObject("PassengerTrigger");
            passengerTrigger.Parent = root;
            passengerTrigger.Transform.LocalPosition = new Vector3(0f, 0.25f, 0f);
            var ptCol = passengerTrigger.AddComponent<Collider>();
            ptCol.Shape     = ColliderShape.Box;
            ptCol.Size      = new Vector3(4f, 0.15f, 2f);
            ptCol.IsTrigger = true;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/platform_hum"; audio.Loop = true; audio.Volume = 0.25f;
            audio.PlayOnAwake = true; audio.SpatialBlend = 1f; audio.MaxDistance = 15f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "MovingPlatformController";
            script.SetField("Speed",             4f);
            script.SetField("WaitTime",          1.2f);
            script.SetField("Mode",              "PingPong");   // PingPong | Loop
            script.SetField("CarryPassengers",   true);
            script.SetField("PassengerTrigger",  passengerTrigger);
            script.SetField("Audio",             audio);
            // Waypoints are set in-editor via transform handles

            return root;
        }

        // ── Sliding Door ─────────────────────────────────────
        /// <summary>
        /// Proximity or keycard triggered sliding door.
        /// Two leaf halves slide apart.  Supports locked state
        /// (requires matching Key pickup) and auto-close timer.
        /// </summary>
        public static GameObject SlidingDoor()
        {
            var root = new GameObject("Env_SlidingDoor");
            root.Tag = "Door";

            // Frame mesh
            var frame = new GameObject("DoorFrame");
            frame.Parent = root;
            var frameMr = frame.AddComponent<MeshRenderer>();
            frameMr.Mesh     = "builtin:mesh/door_frame";
            frameMr.Material = Materials.DoorMetal;

            // Left leaf child
            var left = new GameObject("LeafLeft");
            left.Parent = root;
            left.Transform.LocalPosition = new Vector3(-1f, 0f, 0f);
            var leftMr = left.AddComponent<MeshRenderer>();
            leftMr.Mesh     = "builtin:mesh/door_leaf";
            leftMr.Material = Materials.DoorMetal;
            left.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Right leaf child
            var right = new GameObject("LeafRight");
            right.Parent = root;
            right.Transform.LocalPosition = new Vector3(1f, 0f, 0f);
            var rightMr = right.AddComponent<MeshRenderer>();
            rightMr.Mesh     = "builtin:mesh/door_leaf";
            rightMr.Material = Materials.DoorMetal;
            right.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Keypad glow child
            var keypad = new GameObject("Keypad");
            keypad.Parent = root;
            keypad.Transform.LocalPosition = new Vector3(1.3f, 1.2f, 0.1f);
            var kLight = keypad.AddComponent<Light>();
            kLight.Type = LightType.Point; kLight.Color = new Color(1f, 0.15f, 0.1f);  // Red = locked
            kLight.Intensity = 1.2f; kLight.Range = 0.8f;

            // Trigger zone child
            var trigger = new GameObject("ProximityTrigger");
            trigger.Parent = root;
            var tCol = trigger.AddComponent<Collider>();
            tCol.Shape = ColliderShape.Box; tCol.Size = new Vector3(4f, 3f, 3f); tCol.IsTrigger = true;

            var openAudio  = root.AddComponent<AudioSource>();
            openAudio.Clip  = "builtin:audio/door_slide_open"; openAudio.Volume = 0.8f; openAudio.SpatialBlend = 1f;
            var closeAudio = root.AddComponent<AudioSource>();
            closeAudio.Clip = "builtin:audio/door_slide_close"; closeAudio.Volume = 0.7f; closeAudio.SpatialBlend = 1f;
            var lockedAudio = root.AddComponent<AudioSource>();
            lockedAudio.Clip = "builtin:audio/door_locked_buzz"; lockedAudio.Volume = 0.6f; lockedAudio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "SlidingDoorController";
            script.SetField("SlideDist",      1.8f);
            script.SetField("SlideSpeed",     3.5f);
            script.SetField("AutoClose",      true);
            script.SetField("AutoCloseDelay", 3f);
            script.SetField("IsLocked",       false);
            script.SetField("RequiredKeyID",  "Gold");
            script.SetField("LeafLeft",       left);
            script.SetField("LeafRight",      right);
            script.SetField("KeypadLight",    kLight);
            script.SetField("ProxTrigger",    trigger);
            script.SetField("OpenAudio",      openAudio);
            script.SetField("CloseAudio",     closeAudio);
            script.SetField("LockedAudio",    lockedAudio);

            return root;
        }

        // ── Treasure Chest ────────────────────────────────────
        /// <summary>
        /// Lootable treasure chest.  Lid animates open, loot
        /// items spawn with a golden shimmer burst.  Rarity
        /// (Common/Rare/Epic/Legendary) drives particle colour.
        /// </summary>
        public static GameObject TreasureChest()
        {
            var root = new GameObject("Env_TreasureChest");
            root.Tag = "Interactable";

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = "builtin:mesh/chest_body";
            mr.Material = Materials.ChestWood;

            // Lid child (rotates around hinge)
            var lid = new GameObject("Lid");
            lid.Parent = root;
            lid.Transform.LocalPosition = new Vector3(0f, 0.5f, -0.32f);
            var lidMr = lid.AddComponent<MeshRenderer>();
            lidMr.Mesh     = "builtin:mesh/chest_lid";
            lidMr.Material = Materials.ChestWood;

            // Loot spawn point child
            var lootSpawn = new GameObject("LootSpawn");
            lootSpawn.Parent = root;
            lootSpawn.Transform.LocalPosition = new Vector3(0f, 0.7f, 0f);

            // Shimmer glow child
            var shimmer = new GameObject("Shimmer");
            shimmer.Parent = root;
            var sLight = shimmer.AddComponent<Light>();
            sLight.Type = LightType.Point; sLight.Color = new Color(1f, 0.85f, 0.1f);
            sLight.Intensity = 0f; sLight.Range = 4f;
            shimmer.SetActive(false);

            // Trigger zone
            var trigger = new GameObject("OpenTrigger");
            trigger.Parent = root;
            var tCol = trigger.AddComponent<Collider>();
            tCol.Shape = ColliderShape.Box; tCol.Size = new Vector3(2.5f, 2f, 2.5f); tCol.IsTrigger = true;

            var openAudio = root.AddComponent<AudioSource>();
            openAudio.Clip = "builtin:audio/chest_open"; openAudio.Volume = 0.9f; openAudio.SpatialBlend = 1f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/chest_open";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "TreasureChestController";
            script.SetField("Rarity",       "Common");   // Common/Rare/Epic/Legendary
            script.SetField("LootTable",    "builtin:loot/chest_common");
            script.SetField("LootCount",    3);
            script.SetField("LidObj",       lid);
            script.SetField("LootSpawn",    lootSpawn);
            script.SetField("ShimmerObj",   shimmer);
            script.SetField("OpenTrigger",  trigger);
            script.SetField("OpenAudio",    openAudio);
            script.SetField("Animator",     anim);

            return root;
        }

        // ── Rope Bridge ───────────────────────────────────────
        /// <summary>
        /// Segmented rope bridge with ClothPhysics sway.
        /// Player weight increases sway intensity.
        /// Supports destructible planks (step-through on enough damage).
        /// </summary>
        public static GameObject RopeBridge()
        {
            var root = new GameObject("Env_RopeBridge");
            root.Tag = "Environment";

            const int segments = 12;
            const float segLength = 1.0f;

            GameObject? prev = null;
            for (int i = 0; i < segments; i++)
            {
                var plank = new GameObject($"Plank_{i:D2}");
                plank.Parent = root;
                plank.Transform.LocalPosition = new Vector3(i * segLength - segments * segLength * 0.5f, 0f, 0f);

                var mr = plank.AddComponent<MeshRenderer>();
                mr.Mesh     = Mesh.CreateCube(new Vector3(segLength * 0.95f, 0.1f, 1.2f));
                mr.Material = Materials.WoodPlank;

                var col = plank.AddComponent<Collider>();
                col.Shape = ColliderShape.Box;
                col.Size  = new Vector3(segLength * 0.95f, 0.1f, 1.2f);

                var rb = plank.AddComponent<Rigidbody>();
                rb.Mass = 8f; rb.Drag = 2f; rb.UseGravity = true;
                rb.FreezeRotationY = rb.FreezePositionX = true;

                var hp = plank.AddComponent<HealthComponent>();
                hp.MaxHealth = hp.CurrentHealth = 25f;

                prev = plank;
            }

            // Left/right rope lines
            foreach (var side in new[] { -0.6f, 0.6f })
            {
                var rope = new GameObject($"Rope_{(side < 0 ? "L" : "R")}");
                rope.Parent = root;
                var lr = rope.AddComponent<LineRenderer>();
                lr.Width    = 0.04f;
                lr.Color    = new Color(0.45f, 0.3f, 0.1f);
                lr.Material = Materials.Rope;
            }

            var step = root.AddComponent<AudioSource>();
            step.Clip = "builtin:audio/wood_creak"; step.Volume = 0.5f; step.SpatialBlend = 1f; step.MaxDistance = 20f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "RopeBridgeController";
            script.SetField("SwayAmplitude",   0.08f);
            script.SetField("SwayFrequency",   1.2f);
            script.SetField("PlayerWeightMul", 3f);
            script.SetField("PlankHP",         25f);
            script.SetField("StepAudio",       step);

            return root;
        }

        // ── Water Surface ─────────────────────────────────────
        /// <summary>
        /// Animated tiling wave surface.  Buoyancy trigger adds
        /// upward force to rigidbodies.  Splash VFX and ripple
        /// decals on entry.
        /// </summary>
        public static GameObject WaterSurface()
        {
            var root = new GameObject("Env_WaterSurface");
            root.Tag = "Water";

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreatePlane(50f, 50f, 32, 32);
            mr.Material = Materials.Water;
            mr.CastShadows = false; mr.ReceiveShadows = true;

            // Buoyancy trigger (thin box under the surface)
            var buoyancy = new GameObject("BuoyancyTrigger");
            buoyancy.Parent = root;
            buoyancy.Transform.LocalPosition = new Vector3(0f, -1f, 0f);
            var bCol = buoyancy.AddComponent<Collider>();
            bCol.Shape     = ColliderShape.Box;
            bCol.Size      = new Vector3(50f, 2f, 50f);
            bCol.IsTrigger = true;

            var splashAudio = root.AddComponent<AudioSource>();
            splashAudio.Clip = "builtin:audio/water_splash"; splashAudio.Volume = 0.7f; splashAudio.SpatialBlend = 1f;

            var ambientAudio = root.AddComponent<AudioSource>();
            ambientAudio.Clip = "builtin:audio/water_ambient"; ambientAudio.Loop = true;
            ambientAudio.Volume = 0.3f; ambientAudio.PlayOnAwake = true; ambientAudio.SpatialBlend = 0f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "WaterSurface";
            script.SetField("WaveSpeed",       0.5f);
            script.SetField("WaveHeight",      0.3f);
            script.SetField("WaveFrequency",   0.8f);
            script.SetField("BuoyancyForce",   12f);
            script.SetField("WaterDrag",       4f);
            script.SetField("AngularDrag",     3f);
            script.SetField("SplashThreshold", 3f);   // Entry speed
            script.SetField("BuoyancyTrigger", buoyancy);
            script.SetField("SplashAudio",     splashAudio);

            return root;
        }
    }
}
