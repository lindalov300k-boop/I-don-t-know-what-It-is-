// ============================================================
//  BADGE Engine – BuiltInAssets/Weapons/WeaponPrefabs.cs
//  Competition-ready weapon game-object factories.
//  All weapons attach to a WeaponSocket child of the player.
// ============================================================
using System;
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Weapons
{
    public static class WeaponPrefabs
    {
        // ── Pistol ────────────────────────────────────────────
        /// <summary>
        /// Semi-automatic pistol.
        /// Muzzle flash (point light + sprite), brass shell eject,
        /// recoil animation, dry-fire click, reload animation with
        /// bullet-in-chamber tracking.
        /// </summary>
        public static GameObject Pistol()
        {
            var root = new GameObject("Weapon_Pistol");
            root.Tag = "Weapon";

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = "builtin:mesh/pistol";
            mr.Material = Materials.WeaponMetal;
            mr.CastShadows = false;

            // Muzzle socket child
            var muzzle = new GameObject("MuzzleFlash");
            muzzle.Parent = root;
            muzzle.Transform.LocalPosition = new Vector3(0f, 0f, 0.42f);

            var muzzleLight = muzzle.AddComponent<Light>();
            muzzleLight.Type      = LightType.Point;
            muzzleLight.Color     = new Color(1f, 0.85f, 0.3f);
            muzzleLight.Intensity = 6f;
            muzzleLight.Range     = 4f;
            muzzle.SetActive(false);   // Enabled for 1 frame per shot

            var muzzleSr = muzzle.AddComponent<SpriteRenderer>();
            muzzleSr.Sprite = "builtin:sprites/muzzle_flash";

            // Shell eject socket child
            var eject = new GameObject("ShellEject");
            eject.Parent = root;
            eject.Transform.LocalPosition = new Vector3(0.06f, 0.04f, 0.22f);

            // Audio
            var shoot = root.AddComponent<AudioSource>();
            shoot.Clip         = "builtin:audio/pistol_shot";
            shoot.Volume       = 0.9f;
            shoot.SpatialBlend = 0f;
            shoot.Pitch        = 1f;

            var reload = root.AddComponent<AudioSource>();
            reload.Clip   = "builtin:audio/pistol_reload";
            reload.Volume = 0.7f;
            reload.SpatialBlend = 0f;

            var dryFire = root.AddComponent<AudioSource>();
            dryFire.Clip   = "builtin:audio/pistol_dryfire";
            dryFire.Volume = 0.5f;
            dryFire.SpatialBlend = 0f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/pistol";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PistolController";
            script.SetField("Damage",            30f);
            script.SetField("Range",             60f);
            script.SetField("FireRate",          0.35f);
            script.SetField("MagazineSize",      15);
            script.SetField("ReserveAmmo",       60);
            script.SetField("ReloadTime",        1.4f);
            script.SetField("RecoilUp",          1.2f);
            script.SetField("RecoilSide",        0.3f);
            script.SetField("RecoilRecoverSpeed",8f);
            script.SetField("MuzzleFlash",       muzzle);
            script.SetField("ShellEject",        eject);
            script.SetField("ShootAudio",        shoot);
            script.SetField("ReloadAudio",       reload);
            script.SetField("DryFireAudio",      dryFire);
            script.SetField("Animator",          anim);

            return root;
        }

        // ── Shotgun ───────────────────────────────────────────
        /// <summary>
        /// Pump-action shotgun.
        /// 8-pellet spread, camera shake per shot, shell pump sound,
        /// knockback impulse on target.
        /// </summary>
        public static GameObject Shotgun()
        {
            var root = new GameObject("Weapon_Shotgun");
            root.Tag = "Weapon";

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = "builtin:mesh/shotgun";
            mr.Material = Materials.WeaponWood;
            mr.CastShadows = false;

            var muzzle = new GameObject("MuzzleFlash");
            muzzle.Parent = root;
            muzzle.Transform.LocalPosition = new Vector3(0f, 0f, 0.72f);
            var muzzleLight = muzzle.AddComponent<Light>();
            muzzleLight.Type      = LightType.Point;
            muzzleLight.Color     = new Color(1f, 0.75f, 0.2f);
            muzzleLight.Intensity = 12f;
            muzzleLight.Range     = 5f;
            muzzle.SetActive(false);

            var muzzleSr = muzzle.AddComponent<SpriteRenderer>();
            muzzleSr.Sprite = "builtin:sprites/muzzle_flash_shotgun";

            var eject = new GameObject("ShellEject");
            eject.Parent = root;
            eject.Transform.LocalPosition = new Vector3(0.04f, 0.05f, 0.4f);

            var shoot = root.AddComponent<AudioSource>();
            shoot.Clip = "builtin:audio/shotgun_shot"; shoot.Volume = 1f; shoot.SpatialBlend = 0f;

            var pump = root.AddComponent<AudioSource>();
            pump.Clip  = "builtin:audio/shotgun_pump"; pump.Volume = 0.8f; pump.SpatialBlend = 0f;

            var reload = root.AddComponent<AudioSource>();
            reload.Clip = "builtin:audio/shotgun_reload_shell"; reload.Volume = 0.7f; reload.SpatialBlend = 0f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/shotgun";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ShotgunController";
            script.SetField("DamagePerPellet",   14f);
            script.SetField("PelletCount",       8);
            script.SetField("SpreadAngle",       8f);
            script.SetField("Range",             30f);
            script.SetField("FireRate",          0.9f);
            script.SetField("TubeMagazine",      6);
            script.SetField("ReserveAmmo",       24);
            script.SetField("ReloadTimePerShell",0.55f);
            script.SetField("KnockbackForce",    12f);
            script.SetField("CameraShake",       0.4f);
            script.SetField("CameraShakeDuration",0.15f);
            script.SetField("MuzzleFlash",       muzzle);
            script.SetField("ShellEject",        eject);
            script.SetField("ShootAudio",        shoot);
            script.SetField("PumpAudio",         pump);
            script.SetField("ReloadAudio",       reload);
            script.SetField("Animator",          anim);

            return root;
        }

        // ── Assault Rifle ─────────────────────────────────────
        /// <summary>
        /// Full-auto assault rifle.
        /// Recoil pattern (random walk within cone), heat buildup
        /// → overheating jam state, scope ADS zoom.
        /// </summary>
        public static GameObject AssaultRifle()
        {
            var root = new GameObject("Weapon_AssaultRifle");
            root.Tag = "Weapon";

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = "builtin:mesh/assault_rifle";
            mr.Material = Materials.WeaponMetal;
            mr.CastShadows = false;

            var muzzle = new GameObject("MuzzleFlash");
            muzzle.Parent = root;
            muzzle.Transform.LocalPosition = new Vector3(0f, 0.01f, 0.56f);
            var muzzleLight = muzzle.AddComponent<Light>();
            muzzleLight.Type = LightType.Point; muzzleLight.Color = new Color(1f, 0.9f, 0.4f);
            muzzleLight.Intensity = 5f; muzzleLight.Range = 3f;
            muzzle.SetActive(false);

            var eject = new GameObject("ShellEject");
            eject.Parent = root;
            eject.Transform.LocalPosition = new Vector3(0.07f, 0.04f, 0.28f);

            // Scope child (visible only in ADS)
            var scope = new GameObject("ScopeOverlay");
            scope.Parent = root;
            scope.SetActive(false);

            var shoot  = root.AddComponent<AudioSource>();
            shoot.Clip  = "builtin:audio/ar_shot"; shoot.Volume = 0.85f; shoot.SpatialBlend = 0f;
            var reload  = root.AddComponent<AudioSource>();
            reload.Clip = "builtin:audio/ar_reload"; reload.Volume = 0.7f; reload.SpatialBlend = 0f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/assault_rifle";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "AssaultRifleController";
            script.SetField("Damage",           22f);
            script.SetField("Range",            120f);
            script.SetField("FireRate",         0.09f);   // Full-auto
            script.SetField("MagazineSize",     30);
            script.SetField("ReserveAmmo",      120);
            script.SetField("ReloadTime",       2.1f);
            script.SetField("RecoilUp",         0.5f);
            script.SetField("RecoilSide",       0.15f);
            script.SetField("RecoilRecoverSpeed",10f);
            script.SetField("HeatPerShot",      3f);
            script.SetField("CooldownRate",     15f);
            script.SetField("OverheatThreshold",100f);
            script.SetField("JamClearTime",     2.5f);
            script.SetField("ADSFOVDelta",      -20f);
            script.SetField("ADSSpeed",         10f);
            script.SetField("MuzzleFlash",      muzzle);
            script.SetField("ShellEject",       eject);
            script.SetField("ScopeObj",         scope);
            script.SetField("ShootAudio",       shoot);
            script.SetField("ReloadAudio",      reload);
            script.SetField("Animator",         anim);

            return root;
        }

        // ── Sword ─────────────────────────────────────────────
        /// <summary>
        /// Melee sword with 3-hit combo chain.
        /// Swing trail VFX (LineRenderer arc), stagger on heavy,
        /// block parry window (25 ms), metal clash sound on parry.
        /// </summary>
        public static GameObject Sword()
        {
            var root = new GameObject("Weapon_Sword");
            root.Tag = "Weapon";

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = "builtin:mesh/sword";
            mr.Material = Materials.WeaponSword;
            mr.CastShadows = false;

            // Blade hit-box child
            var blade = new GameObject("BladeHitbox");
            blade.Parent = root;
            blade.Transform.LocalPosition = new Vector3(0f, 0.5f, 0f);
            var bladeCol = blade.AddComponent<Collider>();
            bladeCol.Shape     = ColliderShape.Box;
            bladeCol.Size      = new Vector3(0.1f, 1.0f, 0.05f);
            bladeCol.IsTrigger = true;
            blade.SetActive(false);

            // Swing trail VFX
            var trail = root.AddComponent<LineRenderer>();
            trail.Width = 0.06f;
            trail.Color = new Color(0.8f, 0.9f, 1f, 0.7f);
            trail.Material = Materials.SwordTrail;

            // Audio
            var swing  = root.AddComponent<AudioSource>();
            swing.Clip  = "builtin:audio/sword_swing"; swing.Volume = 0.7f; swing.SpatialBlend = 0f;
            var clash   = root.AddComponent<AudioSource>();
            clash.Clip  = "builtin:audio/sword_clash"; clash.Volume = 0.9f; clash.SpatialBlend = 0f;
            var hit     = root.AddComponent<AudioSource>();
            hit.Clip    = "builtin:audio/sword_hit_flesh"; hit.Volume = 0.8f; hit.SpatialBlend = 0f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/sword";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "SwordController";
            script.SetField("Combo1Damage",      35f);
            script.SetField("Combo2Damage",      35f);
            script.SetField("Combo3Damage",      60f);
            script.SetField("ComboWindowTime",   0.5f);
            script.SetField("AttackCooldown",    0.3f);
            script.SetField("HeavyAttackDamage", 90f);
            script.SetField("HeavyChargeTime",   0.6f);
            script.SetField("ParryWindowTime",   0.25f);
            script.SetField("StaggerDuration",   0.4f);
            script.SetField("BladeHitbox",       blade);
            script.SetField("SwingTrail",        trail);
            script.SetField("SwingAudio",        swing);
            script.SetField("ClashAudio",        clash);
            script.SetField("HitAudio",          hit);
            script.SetField("Animator",          anim);

            return root;
        }

        // ── Bow ────────────────────────────────────────────────
        /// <summary>
        /// Charge-to-power bow.
        /// Arrow physics with drop, quiver system (max 20 arrows),
        /// arrow recovery on hit surfaces, screen-edge arrow counter.
        /// </summary>
        public static GameObject Bow()
        {
            var root = new GameObject("Weapon_Bow");
            root.Tag = "Weapon";

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = "builtin:mesh/bow";
            mr.Material = Materials.WeaponWood;
            mr.CastShadows = false;

            // Arrow nock point child
            var nock = new GameObject("NockPoint");
            nock.Parent = root;
            nock.Transform.LocalPosition = new Vector3(0f, 0f, 0.08f);

            var drawSound = root.AddComponent<AudioSource>();
            drawSound.Clip  = "builtin:audio/bow_draw"; drawSound.Volume = 0.5f; drawSound.SpatialBlend = 0f;
            var releaseSound = root.AddComponent<AudioSource>();
            releaseSound.Clip = "builtin:audio/bow_release"; releaseSound.Volume = 0.8f; releaseSound.SpatialBlend = 0f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/bow";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "BowController";
            script.SetField("MinDamage",       20f);
            script.SetField("MaxDamage",       70f);
            script.SetField("MinSpeed",        18f);
            script.SetField("MaxSpeed",        50f);
            script.SetField("FullChargeTime",  0.8f);
            script.SetField("ArrowDrop",       9.8f);
            script.SetField("Quiver",          20);
            script.SetField("RecoveryChance",  0.7f);
            script.SetField("NockPoint",       nock);
            script.SetField("DrawAudio",       drawSound);
            script.SetField("ReleaseAudio",    releaseSound);
            script.SetField("Animator",        anim);

            return root;
        }

        // ── Grenade ───────────────────────────────────────────
        /// <summary>
        /// Cookable frag grenade.
        /// Physical bounce with audio, cook timer HUD indicator,
        /// explosion radius gizmo, chain-reaction with barrels.
        /// </summary>
        public static GameObject Grenade()
        {
            var root = new GameObject("Weapon_Grenade");
            root.Tag = "Weapon";

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateSphere(0.065f, 8, 8);
            mr.Material = Materials.WeaponMetal;
            mr.CastShadows = false;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass      = 0.4f;
            rb.Drag      = 0.05f;
            rb.UseGravity = true;

            var col = root.AddComponent<Collider>();
            col.Shape  = ColliderShape.Sphere;
            col.Radius = 0.065f;
            col.PhysicsMaterial = PhysicsMaterials.Bouncy;

            // Explosion trigger child
            var blastZone = new GameObject("BlastZone");
            blastZone.Parent = root;
            var blastCol = blastZone.AddComponent<Collider>();
            blastCol.Shape     = ColliderShape.Sphere;
            blastCol.Radius    = 0f;  // Set to ExplosionRadius at detonate
            blastCol.IsTrigger = true;
            blastZone.SetActive(false);

            var bounceSound = root.AddComponent<AudioSource>();
            bounceSound.Clip  = "builtin:audio/grenade_bounce"; bounceSound.Volume = 0.6f; bounceSound.SpatialBlend = 1f;
            var tickSound = root.AddComponent<AudioSource>();
            tickSound.Clip    = "builtin:audio/grenade_tick"; tickSound.Volume = 0.4f; tickSound.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "GrenadeController";
            script.SetField("CookTime",        4f);
            script.SetField("MinCookThrow",    0.3f);   // Must be held at least 0.3 s
            script.SetField("ExplosionRadius", 6f);
            script.SetField("ExplosionDamage", 110f);
            script.SetField("KnockbackForce",  20f);
            script.SetField("CameraShake",     0.8f);
            script.SetField("TickRate",        0.5f);
            script.SetField("BlastZone",       blastZone);
            script.SetField("BounceAudio",     bounceSound);
            script.SetField("TickAudio",       tickSound);

            return root;
        }
    }
}
