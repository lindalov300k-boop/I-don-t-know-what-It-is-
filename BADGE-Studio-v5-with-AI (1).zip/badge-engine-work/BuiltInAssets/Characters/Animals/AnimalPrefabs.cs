// ============================================================
//  BADGE Engine – BuiltInAssets/Characters/Animals/AnimalPrefabs.cs
//  Low-poly animal game-object factories.
//  Animals use bone rigs built from primitive meshes,
//  idle/walk/run/react animations and ambient audio.
// ============================================================
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Characters.Animals
{
    public static class AnimalPrefabs
    {
        // ── Dog ──────────────────────────────────────────────
        /// <summary>
        /// Friendly low-poly dog. Follows player when near,
        /// pants at idle, barks on interaction, wags tail
        /// (bone-animated cylinder).
        /// </summary>
        public static GameObject Dog()
        {
            var root = new GameObject("Animal_Dog");
            root.Tag   = "Animal";
            root.Layer = Layers.NPC;

            // Body
            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(0.45f, 0.3f, 0.65f));
            bMr.Material = AnimalMaterials.FurGolden;

            // Head
            var head = new GameObject("Head");
            head.Parent = root;
            head.Transform.LocalPosition = new Vector3(0f, 0.22f, 0.38f);
            var hMr = head.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateCube(new Vector3(0.3f, 0.28f, 0.32f));
            hMr.Material = AnimalMaterials.FurGolden;

            // Snout
            var snout = new GameObject("Snout");
            snout.Parent = head;
            snout.Transform.LocalPosition = new Vector3(0f, -0.05f, 0.17f);
            var snMr = snout.AddComponent<MeshRenderer>();
            snMr.Mesh     = Mesh.CreateCube(new Vector3(0.18f, 0.12f, 0.15f));
            snMr.Material = AnimalMaterials.FurLight;

            // Ears (two flat quads)
            foreach (var (x, name) in new[] { (-0.13f, "EarL"), (0.13f, "EarR") })
            {
                var ear = new GameObject(name);
                ear.Parent = head;
                ear.Transform.LocalPosition = new Vector3(x, 0.17f, -0.05f);
                ear.Transform.LocalEulerAngles = new Vector3(0f, 0f, x < 0 ? 20f : -20f);
                var eMr = ear.AddComponent<MeshRenderer>();
                eMr.Mesh     = Mesh.CreateCube(new Vector3(0.08f, 0.12f, 0.03f));
                eMr.Material = AnimalMaterials.FurGolden;
            }

            // Tail (wags)
            var tail = new GameObject("Tail");
            tail.Parent = root;
            tail.Transform.LocalPosition = new Vector3(0f, 0.2f, -0.35f);
            tail.Transform.LocalEulerAngles = new Vector3(-30f, 0f, 0f);
            var tMr = tail.AddComponent<MeshRenderer>();
            tMr.Mesh     = Mesh.CreateCylinder(0.05f, 0.25f, 6);
            tMr.Material = AnimalMaterials.FurGolden;

            // Legs (four)
            float[] lx = { -0.14f, 0.14f, -0.14f, 0.14f };
            float[] lz = { 0.24f, 0.24f, -0.24f, -0.24f };
            string[] ln = { "LegFL", "LegFR", "LegBL", "LegBR" };
            for (int i = 0; i < 4; i++)
            {
                var leg = new GameObject(ln[i]);
                leg.Parent = root;
                leg.Transform.LocalPosition = new Vector3(lx[i], -0.1f, lz[i]);
                var lMr = leg.AddComponent<MeshRenderer>();
                lMr.Mesh     = Mesh.CreateCylinder(0.05f, 0.22f, 6);
                lMr.Material = AnimalMaterials.FurGolden;
            }

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Capsule; col.Radius = 0.25f;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 25f; rb.Drag = 6f; rb.UseGravity = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/dog_idle_walk_run";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/dog_bark"; audio.SpatialBlend = 1f; audio.MaxDistance = 20f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PetAnimalAI";
            script.SetField("FollowRange",    6f);
            script.SetField("FollowSpeed",    3f);
            script.SetField("WanderRadius",   8f);
            script.SetField("BarkOnPet",      true);
            script.SetField("TailWagSpeed",   180f);
            script.SetField("TailObj",        tail);
            script.SetField("Animator",       anim);
            script.SetField("Audio",          audio);

            return root;
        }

        // ── Cat ───────────────────────────────────────────────
        /// <summary>
        /// Aloof low-poly cat. Sits, stretches, walks slowly.
        /// Purrs when petted, hisses when startled.
        /// </summary>
        public static GameObject Cat()
        {
            var root = new GameObject("Animal_Cat");
            root.Tag   = "Animal";
            root.Layer = Layers.NPC;

            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(0.22f, 0.2f, 0.38f));
            bMr.Material = AnimalMaterials.FurOrange;

            var head = new GameObject("Head");
            head.Parent = root;
            head.Transform.LocalPosition = new Vector3(0f, 0.18f, 0.22f);
            var hMr = head.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateSphere(0.14f, 5, 6);
            hMr.Material = AnimalMaterials.FurOrange;

            // Triangular ears
            foreach (var (x, name) in new[] { (-0.07f, "EarL"), (0.07f, "EarR") })
            {
                var ear = new GameObject(name);
                ear.Parent = head;
                ear.Transform.LocalPosition = new Vector3(x, 0.1f, 0f);
                var eMr = ear.AddComponent<MeshRenderer>();
                eMr.Mesh     = Mesh.CreateCone(0.045f, 0.09f, 3);
                eMr.Material = AnimalMaterials.FurOrange;
            }

            // Curved tail
            var tail = new GameObject("Tail");
            tail.Parent = root;
            tail.Transform.LocalPosition = new Vector3(0f, 0.12f, -0.22f);
            tail.Transform.LocalEulerAngles = new Vector3(-60f, 0f, 0f);
            var tMr = tail.AddComponent<MeshRenderer>();
            tMr.Mesh     = Mesh.CreateCylinder(0.03f, 0.35f, 5);
            tMr.Material = AnimalMaterials.FurDarkStripe;

            float[] lx2 = { -0.08f, 0.08f, -0.08f, 0.08f };
            float[] lz2 = { 0.15f, 0.15f, -0.15f, -0.15f };
            string[] ln2 = { "LegFL", "LegFR", "LegBL", "LegBR" };
            for (int i = 0; i < 4; i++)
            {
                var leg = new GameObject(ln2[i]);
                leg.Parent = root;
                leg.Transform.LocalPosition = new Vector3(lx2[i], -0.08f, lz2[i]);
                var lMr = leg.AddComponent<MeshRenderer>();
                lMr.Mesh     = Mesh.CreateCylinder(0.03f, 0.16f, 5);
                lMr.Material = AnimalMaterials.FurOrange;
            }

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Capsule; col.Radius = 0.14f;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 4f; rb.Drag = 8f; rb.UseGravity = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/cat_idle_walk_sit";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/cat_purr"; audio.Loop = true; audio.Volume = 0.2f;
            audio.SpatialBlend = 1f; audio.MaxDistance = 6f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PetAnimalAI";
            script.SetField("WanderRadius",  4f);
            script.SetField("WalkSpeed",     1.2f);
            script.SetField("SitChance",     0.5f);
            script.SetField("CanClimbProps", true);
            script.SetField("Animator",      anim);
            script.SetField("Audio",         audio);

            return root;
        }

        // ── Horse ─────────────────────────────────────────────
        /// <summary>
        /// Rideable low-poly horse. Mount point on saddle.
        /// Walk/trot/canter/gallop animations, whinny audio,
        /// mane and tail cloth-sim.
        /// </summary>
        public static GameObject Horse()
        {
            var root = new GameObject("Animal_Horse");
            root.Tag   = "Animal";
            root.Layer = Layers.NPC;

            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(0.7f, 0.85f, 2.1f));
            bMr.Material = AnimalMaterials.FurChestnut;

            // Neck
            var neck = new GameObject("Neck");
            neck.Parent = root;
            neck.Transform.LocalPosition = new Vector3(0f, 0.65f, 0.9f);
            neck.Transform.LocalEulerAngles = new Vector3(-30f, 0f, 0f);
            var nMr = neck.AddComponent<MeshRenderer>();
            nMr.Mesh     = Mesh.CreateCylinder(0.18f, 0.65f, 7);
            nMr.Material = AnimalMaterials.FurChestnut;

            // Head
            var head = new GameObject("Head");
            head.Parent = neck;
            head.Transform.LocalPosition = new Vector3(0f, 0.4f, 0f);
            var hMr = head.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateCube(new Vector3(0.22f, 0.25f, 0.45f));
            hMr.Material = AnimalMaterials.FurChestnut;

            // Mane cloth
            var mane = new GameObject("Mane");
            mane.Parent = neck;
            mane.Transform.LocalPosition = new Vector3(0f, 0.1f, -0.12f);
            var maneMr = mane.AddComponent<MeshRenderer>();
            maneMr.Mesh     = Mesh.CreatePlane(0.15f, 0.6f);
            maneMr.Material = AnimalMaterials.ManeDark;
            mane.AddComponent<ClothPhysics>().WindInfluence = 0.35f;

            // Tail cloth
            var tail = new GameObject("Tail");
            tail.Parent = root;
            tail.Transform.LocalPosition = new Vector3(0f, 0.5f, -1.1f);
            var tailMr = tail.AddComponent<MeshRenderer>();
            tailMr.Mesh     = Mesh.CreatePlane(0.2f, 0.7f);
            tailMr.Material = AnimalMaterials.ManeDark;
            tail.AddComponent<ClothPhysics>().WindInfluence = 0.5f;

            // Saddle
            var saddle = new GameObject("Saddle");
            saddle.Parent = root;
            saddle.Transform.LocalPosition = new Vector3(0f, 0.52f, 0.2f);
            var sMr = saddle.AddComponent<MeshRenderer>();
            sMr.Mesh     = Mesh.CreateCube(new Vector3(0.4f, 0.1f, 0.5f));
            sMr.Material = AnimalMaterials.SaddleLeather;

            // Mount point child
            var mountPoint = new GameObject("MountPoint");
            mountPoint.Parent = saddle;
            mountPoint.Transform.LocalPosition = new Vector3(0f, 0.12f, 0f);

            // Legs (four)
            float[] lxH = { -0.28f, 0.28f, -0.28f, 0.28f };
            float[] lzH = { 0.7f, 0.7f, -0.7f, -0.7f };
            string[] lnH = { "LegFL", "LegFR", "LegBL", "LegBR" };
            for (int i = 0; i < 4; i++)
            {
                var leg = new GameObject(lnH[i]);
                leg.Parent = root;
                leg.Transform.LocalPosition = new Vector3(lxH[i], -0.5f, lzH[i]);
                var lMr = leg.AddComponent<MeshRenderer>();
                lMr.Mesh     = Mesh.CreateCylinder(0.1f, 0.8f, 6);
                lMr.Material = AnimalMaterials.FurChestnut;
            }

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Box; col.Size = new Vector3(0.7f, 1.7f, 2.1f);

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 500f; rb.Drag = 3f; rb.UseGravity = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/horse_walk_trot_gallop";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/horse_whinny"; audio.SpatialBlend = 1f; audio.MaxDistance = 40f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "HorseAI";
            script.SetField("WalkSpeed",     3f);
            script.SetField("TrotSpeed",     6f);
            script.SetField("GallopSpeed",   14f);
            script.SetField("IsRideable",    true);
            script.SetField("MountPoint",    mountPoint);
            script.SetField("Animator",      anim);
            script.SetField("Audio",         audio);

            return root;
        }

        // ── Chicken ───────────────────────────────────────────
        /// <summary>
        /// Pecking low-poly chicken. Wanders, lays an egg prop
        /// periodically, flaps wings when startled.
        /// </summary>
        public static GameObject Chicken()
        {
            var root = new GameObject("Animal_Chicken");
            root.Tag   = "Animal";
            root.Layer = Layers.NPC;

            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateSphere(0.18f, 5, 6);
            bMr.Material = AnimalMaterials.FeatherWhite;

            var head = new GameObject("Head");
            head.Parent = root;
            head.Transform.LocalPosition = new Vector3(0f, 0.22f, 0.15f);
            var hMr = head.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateSphere(0.1f, 4, 5);
            hMr.Material = AnimalMaterials.FeatherWhite;

            // Beak
            var beak = new GameObject("Beak");
            beak.Parent = head;
            beak.Transform.LocalPosition = new Vector3(0f, -0.02f, 0.08f);
            var beakMr = beak.AddComponent<MeshRenderer>();
            beakMr.Mesh     = Mesh.CreateCone(0.025f, 0.06f, 3);
            beakMr.Material = AnimalMaterials.BeakYellow;

            // Comb / wattle
            var comb = new GameObject("Comb");
            comb.Parent = head;
            comb.Transform.LocalPosition = new Vector3(0f, 0.09f, 0f);
            var combMr = comb.AddComponent<MeshRenderer>();
            combMr.Mesh     = Mesh.CreateCube(new Vector3(0.03f, 0.07f, 0.05f));
            combMr.Material = AnimalMaterials.WattleRed;

            // Wings
            foreach (var (x, name) in new[] { (-0.2f, "WingL"), (0.2f, "WingR") })
            {
                var wing = new GameObject(name);
                wing.Parent = root;
                wing.Transform.LocalPosition = new Vector3(x, 0.04f, 0f);
                var wMr = wing.AddComponent<MeshRenderer>();
                wMr.Mesh     = Mesh.CreateCube(new Vector3(0.08f, 0.06f, 0.2f));
                wMr.Material = AnimalMaterials.FeatherWhite;
            }

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Sphere; col.Radius = 0.2f;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 2f; rb.Drag = 8f; rb.UseGravity = true;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/chicken_idle_peck_walk";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/chicken_cluck"; audio.SpatialBlend = 1f; audio.MaxDistance = 15f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ChickenAI";
            script.SetField("WanderRadius",    5f);
            script.SetField("PeckInterval",    2.5f);
            script.SetField("EggLayInterval",  60f);
            script.SetField("EggPrefab",       "builtin:prefab/egg");
            script.SetField("FlightOnScare",   true);
            script.SetField("Animator",        anim);
            script.SetField("Audio",           audio);

            return root;
        }

        // ── Cow ───────────────────────────────────────────────
        /// <summary>
        /// Large dairy cow with udder. Grazes, moos, can be
        /// interacted with for milk resource.
        /// </summary>
        public static GameObject Cow()
        {
            var root = new GameObject("Animal_Cow");
            root.Tag   = "Animal";
            root.Layer = Layers.NPC;

            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(1f, 1.1f, 1.8f));
            bMr.Material = AnimalMaterials.FurCowBlackWhite;

            var neck = new GameObject("Neck");
            neck.Parent = root;
            neck.Transform.LocalPosition = new Vector3(0f, 0.6f, 0.85f);
            var nMr = neck.AddComponent<MeshRenderer>();
            nMr.Mesh     = Mesh.CreateCylinder(0.2f, 0.45f, 6);
            nMr.Material = AnimalMaterials.FurCowBlackWhite;

            var head = new GameObject("Head");
            head.Parent = neck;
            head.Transform.LocalPosition = new Vector3(0f, 0.28f, 0f);
            var hMr = head.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateCube(new Vector3(0.35f, 0.32f, 0.5f));
            hMr.Material = AnimalMaterials.FurCowBlackWhite;

            // Udder
            var udder = new GameObject("Udder");
            udder.Parent = root;
            udder.Transform.LocalPosition = new Vector3(0f, -0.4f, -0.35f);
            var uMr = udder.AddComponent<MeshRenderer>();
            uMr.Mesh     = Mesh.CreateSphere(0.18f, 5, 6);
            uMr.Material = AnimalMaterials.UdderPink;

            // Horns
            foreach (var (x, name) in new[] { (-0.16f, "HornL"), (0.16f, "HornR") })
            {
                var horn = new GameObject(name);
                horn.Parent = head;
                horn.Transform.LocalPosition = new Vector3(x, 0.18f, -0.1f);
                horn.Transform.LocalEulerAngles = new Vector3(0f, 0f, x < 0 ? -25f : 25f);
                var hornMr = horn.AddComponent<MeshRenderer>();
                hornMr.Mesh     = Mesh.CreateCone(0.04f, 0.2f, 4);
                hornMr.Material = AnimalMaterials.HornBeige;
            }

            float[] lxC = { -0.38f, 0.38f, -0.38f, 0.38f };
            float[] lzC = { 0.65f, 0.65f, -0.65f, -0.65f };
            string[] lnC = { "LegFL", "LegFR", "LegBL", "LegBR" };
            for (int i = 0; i < 4; i++)
            {
                var leg = new GameObject(lnC[i]);
                leg.Parent = root;
                leg.Transform.LocalPosition = new Vector3(lxC[i], -0.65f, lzC[i]);
                var lMr = leg.AddComponent<MeshRenderer>();
                lMr.Mesh     = Mesh.CreateCylinder(0.1f, 0.65f, 6);
                lMr.Material = AnimalMaterials.FurCowBlackWhite;
            }

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Box; col.Size = new Vector3(1f, 2.2f, 1.8f);

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 600f; rb.Drag = 5f; rb.UseGravity = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/cow_idle_graze_walk";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/cow_moo"; audio.SpatialBlend = 1f; audio.MaxDistance = 30f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "GrazerAI";
            script.SetField("WanderRadius",   10f);
            script.SetField("GrazeInterval",  8f);
            script.SetField("MilkYield",      3);
            script.SetField("MilkRechargeTime",120f);
            script.SetField("Animator",       anim);
            script.SetField("Audio",          audio);

            return root;
        }

        // ── Wolf ──────────────────────────────────────────────
        /// <summary>
        /// Wild predator wolf. Hunts in packs (spawns with pack
        /// radius), howls at night, can be tamed by feeding.
        /// </summary>
        public static GameObject Wolf()
        {
            var root = new GameObject("Animal_Wolf");
            root.Tag   = "Animal";
            root.Layer = Layers.NPC;

            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(0.55f, 0.45f, 0.9f));
            bMr.Material = AnimalMaterials.FurGrey;

            var head = new GameObject("Head");
            head.Parent = root;
            head.Transform.LocalPosition = new Vector3(0f, 0.32f, 0.48f);
            var hMr = head.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateCube(new Vector3(0.32f, 0.28f, 0.36f));
            hMr.Material = AnimalMaterials.FurGrey;

            var snout = new GameObject("Snout");
            snout.Parent = head;
            snout.Transform.LocalPosition = new Vector3(0f, -0.05f, 0.2f);
            var snMr = snout.AddComponent<MeshRenderer>();
            snMr.Mesh     = Mesh.CreateCube(new Vector3(0.18f, 0.14f, 0.18f));
            snMr.Material = AnimalMaterials.FurLight;

            var tail = new GameObject("Tail");
            tail.Parent = root;
            tail.Transform.LocalPosition = new Vector3(0f, 0.28f, -0.5f);
            tail.Transform.LocalEulerAngles = new Vector3(-40f, 0f, 0f);
            var tMr = tail.AddComponent<MeshRenderer>();
            tMr.Mesh     = Mesh.CreateCylinder(0.06f, 0.4f, 6);
            tMr.Material = AnimalMaterials.FurDark;

            float[] lxW = { -0.2f, 0.2f, -0.2f, 0.2f };
            float[] lzW = { 0.32f, 0.32f, -0.32f, -0.32f };
            string[] lnW = { "LegFL", "LegFR", "LegBL", "LegBR" };
            for (int i = 0; i < 4; i++)
            {
                var leg = new GameObject(lnW[i]);
                leg.Parent = root;
                leg.Transform.LocalPosition = new Vector3(lxW[i], -0.22f, lzW[i]);
                var lMr = leg.AddComponent<MeshRenderer>();
                lMr.Mesh     = Mesh.CreateCylinder(0.06f, 0.3f, 5);
                lMr.Material = AnimalMaterials.FurGrey;
            }

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Capsule; col.Radius = 0.3f;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 45f; rb.Drag = 5f; rb.UseGravity = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            root.AddComponent<HealthComponent>().MaxHealth = 60f;

            var nav = root.AddComponent<NavMeshAgent>();
            nav.Speed = 7f; nav.StoppingDistance = 1f;

            var perc = root.AddComponent<AIPerception>();
            perc.SightRange = 20f; perc.SightFOV = 120f; perc.HearingRadius = 15f;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/wolf_idle_walk_run_howl";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/wolf_howl"; audio.SpatialBlend = 1f; audio.MaxDistance = 60f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "WolfAI";
            script.SetField("PackRadius",    12f);
            script.SetField("AttackDamage",  18f);
            script.SetField("TameFood",      "builtin:item/raw_meat");
            script.SetField("TameChance",    0.3f);
            script.SetField("HowlAtNight",   true);
            script.SetField("Animator",      anim);
            script.SetField("Audio",         audio);

            return root;
        }

        // ── Rabbit ────────────────────────────────────────────
        /// <summary>
        /// Small timid rabbit. Hops, sniffs ground, bolts
        /// into a burrow hole when frightened.
        /// </summary>
        public static GameObject Rabbit()
        {
            var root = new GameObject("Animal_Rabbit");
            root.Tag   = "Animal";
            root.Layer = Layers.NPC;

            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateSphere(0.14f, 5, 6);
            bMr.Material = AnimalMaterials.FurCream;

            var head = new GameObject("Head");
            head.Parent = root;
            head.Transform.LocalPosition = new Vector3(0f, 0.16f, 0.1f);
            var hMr = head.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateSphere(0.09f, 4, 5);
            hMr.Material = AnimalMaterials.FurCream;

            // Long ears
            foreach (var (x, name) in new[] { (-0.05f, "EarL"), (0.05f, "EarR") })
            {
                var ear = new GameObject(name);
                ear.Parent = head;
                ear.Transform.LocalPosition = new Vector3(x, 0.14f, -0.01f);
                var eMr = ear.AddComponent<MeshRenderer>();
                eMr.Mesh     = Mesh.CreateCube(new Vector3(0.03f, 0.15f, 0.025f));
                eMr.Material = AnimalMaterials.EarPink;
            }

            // Puff tail
            var tail = new GameObject("Tail");
            tail.Parent = root;
            tail.Transform.LocalPosition = new Vector3(0f, 0.04f, -0.13f);
            var tMr = tail.AddComponent<MeshRenderer>();
            tMr.Mesh     = Mesh.CreateSphere(0.04f, 4, 4);
            tMr.Material = AnimalMaterials.FurCream;

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Sphere; col.Radius = 0.15f;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 1.5f; rb.Drag = 8f; rb.UseGravity = true;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/rabbit_idle_hop_bolt";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/rabbit_squeak"; audio.SpatialBlend = 1f; audio.MaxDistance = 8f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "RabbitAI";
            script.SetField("HopInterval",    1.5f);
            script.SetField("HopForce",       4f);
            script.SetField("FleeRadius",     6f);
            script.SetField("FleeSpeed",      7f);
            script.SetField("BurrowTag",      "Burrow");
            script.SetField("Animator",       anim);
            script.SetField("Audio",          audio);

            return root;
        }

        // ── Bird ──────────────────────────────────────────────
        /// <summary>
        /// Small perching/flying bird. Lands on branches and
        /// rooftops, takes flight when player approaches.
        /// </summary>
        public static GameObject Bird()
        {
            var root = new GameObject("Animal_Bird");
            root.Tag   = "Animal";
            root.Layer = Layers.NPC;

            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateSphere(0.08f, 4, 5);
            bMr.Material = AnimalMaterials.FeatherRed;

            var head = new GameObject("Head");
            head.Parent = root;
            head.Transform.LocalPosition = new Vector3(0f, 0.09f, 0.06f);
            var hMr = head.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateSphere(0.055f, 4, 4);
            hMr.Material = AnimalMaterials.FeatherRed;

            var beak = new GameObject("Beak");
            beak.Parent = head;
            beak.Transform.LocalPosition = new Vector3(0f, -0.01f, 0.05f);
            var beakMr = beak.AddComponent<MeshRenderer>();
            beakMr.Mesh     = Mesh.CreateCone(0.015f, 0.04f, 3);
            beakMr.Material = AnimalMaterials.BeakYellow;

            foreach (var (x, name) in new[] { (-0.1f, "WingL"), (0.1f, "WingR") })
            {
                var wing = new GameObject(name);
                wing.Parent = root;
                wing.Transform.LocalPosition = new Vector3(x, 0f, 0f);
                var wMr = wing.AddComponent<MeshRenderer>();
                wMr.Mesh     = Mesh.CreateCube(new Vector3(0.09f, 0.025f, 0.13f));
                wMr.Material = AnimalMaterials.FeatherRed;
            }

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Sphere; col.Radius = 0.09f;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 0.2f; rb.Drag = 2f; rb.UseGravity = false;  // Flight

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/bird_perch_fly";

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/bird_chirp"; audio.SpatialBlend = 1f; audio.MaxDistance = 15f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "BirdAI";
            script.SetField("PerchTime",      5f);
            script.SetField("FleeRadius",     4f);
            script.SetField("FlightSpeed",    8f);
            script.SetField("FlightAltMin",   3f);
            script.SetField("FlightAltMax",   10f);
            script.SetField("TweetInterval",  4f);
            script.SetField("Animator",       anim);
            script.SetField("Audio",          audio);

            return root;
        }

        // ── Fish ─────────────────────────────────────────────
        /// <summary>
        /// Schooling low-poly fish. Uses flocking (boids) to
        /// swim in groups. Lives inside WaterSurface trigger volume.
        /// </summary>
        public static GameObject Fish()
        {
            var root = new GameObject("Animal_Fish");
            root.Tag   = "Animal";
            root.Layer = Layers.NPC;

            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = "builtin:mesh/fish_body";
            bMr.Material = AnimalMaterials.ScaleTropicalBlue;

            var tailFin = new GameObject("TailFin");
            tailFin.Parent = root;
            tailFin.Transform.LocalPosition = new Vector3(0f, 0f, -0.14f);
            var tfMr = tailFin.AddComponent<MeshRenderer>();
            tfMr.Mesh     = Mesh.CreateCube(new Vector3(0.1f, 0.08f, 0.06f));
            tfMr.Material = AnimalMaterials.ScaleTropicalBlue;

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Capsule; col.Radius = 0.05f;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 0.3f; rb.Drag = 3f; rb.UseGravity = false;
            rb.FreezeRotationX = rb.FreezeRotationZ = false;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/fish_swim";

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "FishBoidAI";
            script.SetField("SwimSpeed",       2f);
            script.SetField("FlockRadius",     3f);
            script.SetField("SeparationDist",  0.3f);
            script.SetField("TailWagSpeed",    6f);
            script.SetField("Animator",        anim);

            return root;
        }
    }
}
