// ============================================================
//  BADGE Engine – BuiltInAssets/Characters/People/MorePeoplePrefabs.cs
//  Extended low-poly human character set — modern, fantasy
//  and occupation themed.
// ============================================================
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Characters.People
{
    public static class MorePeoplePrefabs
    {
        // ── Biped builder (reused from PeoplePrefabs) ─────────
        private static GameObject MakeBiped(string name, float h,
            Material bodyMat, Material skinMat)
        {
            var root = new GameObject(name);
            root.Tag = "Character"; root.Layer = Layers.NPC;

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Capsule; col.Radius = h * 0.14f;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass = 70f; rb.Drag = 6f; rb.UseGravity = true;
            rb.FreezeRotationX = rb.FreezeRotationZ = true;

            var hips = new GameObject("Hips");
            hips.Parent = root;
            hips.Transform.LocalPosition = new Vector3(0f, h * 0.5f, 0f);

            var torso = new GameObject("Torso");
            torso.Parent = hips;
            torso.Transform.LocalPosition = new Vector3(0f, h * 0.18f, 0f);
            torso.AddComponent<MeshRenderer>().Mesh  = Mesh.CreateCube(new Vector3(h*0.32f, h*0.38f, h*0.2f));
            torso.GetComponent<MeshRenderer>().Material = bodyMat;

            var head = new GameObject("Head");
            head.Parent = hips;
            head.Transform.LocalPosition = new Vector3(0f, h * 0.42f, 0f);
            head.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(h * 0.12f, 5, 6);
            head.GetComponent<MeshRenderer>().Material = skinMat;

            void MkLimb(string nm, Vector3 lp, Vector3 sz) {
                var go = new GameObject(nm); go.Parent = hips;
                go.Transform.LocalPosition = lp;
                go.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(sz.X, sz.Y);
                go.GetComponent<MeshRenderer>().Material = bodyMat;
            }
            MkLimb("ArmL",  new Vector3(-(h*0.22f), h*0.28f, 0f), new Vector3(h*0.06f, h*0.32f));
            MkLimb("ArmR",  new Vector3(  h*0.22f,  h*0.28f, 0f), new Vector3(h*0.06f, h*0.32f));
            MkLimb("LegL",  new Vector3(-(h*0.10f),-(h*0.28f),0f), new Vector3(h*0.07f, h*0.38f));
            MkLimb("LegR",  new Vector3(  h*0.10f, -(h*0.28f),0f), new Vector3(h*0.07f, h*0.38f));

            root.AddComponent<HealthComponent>().MaxHealth = 100f;
            return root;
        }

        private static void Anim(GameObject root, string ctrl) =>
            root.AddComponent<Animator>().Controller = ctrl;

        // ── Police Officer ────────────────────────────────────
        public static GameObject PoliceOfficer()
        {
            var root = MakeBiped("Char_PoliceOfficer", 1.80f,
                CharMaterials.UniformBlue, CharMaterials.SkinMedium);

            // Cap
            var cap = new GameObject("PoliceCap"); cap.Parent = root.FindChild("Hips").FindChild("Head");
            cap.Transform.LocalPosition = new Vector3(0f, 0.12f, 0f);
            cap.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.13f, 0.06f, 8);
            cap.GetComponent<MeshRenderer>().Material = CharMaterials.CapBlue;

            // Badge on chest
            var badge = new GameObject("Badge"); badge.Parent = root.FindChild("Hips").FindChild("Torso");
            badge.Transform.LocalPosition = new Vector3(0.07f, 0.08f, 0.11f);
            badge.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.04f,0.04f,0.01f));
            badge.GetComponent<MeshRenderer>().Material = CharMaterials.BrassShiny;

            // Utility belt with baton
            var baton = new GameObject("Baton"); baton.Parent = root;
            baton.Transform.LocalPosition = new Vector3(-0.28f, 0.88f, 0.1f);
            baton.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.02f, 0.5f);
            baton.GetComponent<MeshRenderer>().Material = CharMaterials.IronDark;

            Anim(root, "builtin:anim/humanoid_idle_walk_run");
            var nav = root.AddComponent<NavMeshAgent>(); nav.Speed = 3f;
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "GuardAI";
            script.SetField("PatrolRadius", 15f);
            script.SetField("AlertSoundLine", "Stop! Police!");
            script.SetField("Animator", root.GetComponent<Animator>());
            return root;
        }

        // ── Doctor / Nurse ────────────────────────────────────
        public static GameObject Doctor()
        {
            var root = MakeBiped("Char_Doctor", 1.75f,
                CharMaterials.LabCoatWhite, CharMaterials.SkinLight);

            // Stethoscope
            var steth = new GameObject("Stethoscope"); steth.Parent = root;
            steth.Transform.LocalPosition = new Vector3(0f, 1.1f, 0.12f);
            steth.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.015f, 0.35f);
            steth.GetComponent<MeshRenderer>().Material = CharMaterials.IronDark;

            // Clipboard
            var clip = new GameObject("Clipboard"); clip.Parent = root;
            clip.Transform.LocalPosition = new Vector3(0.22f, 0.88f, 0.1f);
            clip.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.14f, 0.18f, 0.02f));
            clip.GetComponent<MeshRenderer>().Material = CharMaterials.WoodLight;

            Anim(root, "builtin:anim/humanoid_idle_walk_run");
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "MerchantNPC";
            script.SetField("ShopInventory", "builtin:shop/medical_supplies");
            script.SetField("GreetLine", "How are you feeling today?");
            script.SetField("Animator", root.GetComponent<Animator>());
            return root;
        }

        // ── Chef ─────────────────────────────────────────────
        public static GameObject Chef()
        {
            var root = MakeBiped("Char_Chef", 1.73f,
                CharMaterials.ChefWhite, CharMaterials.SkinMedium);

            // Tall chef hat
            var hat = new GameObject("ChefHat"); hat.Parent = root.FindChild("Hips").FindChild("Head");
            hat.Transform.LocalPosition = new Vector3(0f, 0.18f, 0f);
            hat.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.11f, 0.28f, 8);
            hat.GetComponent<MeshRenderer>().Material = CharMaterials.CapChef;

            // Ladle in right hand
            var ladle = new GameObject("Ladle"); ladle.Parent = root;
            ladle.Transform.LocalPosition = new Vector3(0.28f, 0.88f, 0.1f);
            ladle.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.02f, 0.55f);
            ladle.GetComponent<MeshRenderer>().Material = CharMaterials.IronDark;

            Anim(root, "builtin:anim/humanoid_idle_walk_run");
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NPCWander";
            script.SetField("WanderRadius", 5f); script.SetField("WalkSpeed", 1.5f);
            script.SetField("DialogueLine", "Taste this! My finest dish!");
            script.SetField("Animator", root.GetComponent<Animator>());
            return root;
        }

        // ── Construction Worker ───────────────────────────────
        public static GameObject ConstructionWorker()
        {
            var root = MakeBiped("Char_ConstructionWorker", 1.78f,
                CharMaterials.HiVisYellow, CharMaterials.SkinMedium);

            // Hard hat
            var hat = new GameObject("HardHat"); hat.Parent = root.FindChild("Hips").FindChild("Head");
            hat.Transform.LocalPosition = new Vector3(0f, 0.11f, 0f);
            hat.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.14f, 5, 6);
            hat.GetComponent<MeshRenderer>().Material = CharMaterials.HelmetHardHat;

            // Drill / hammer
            var drill = new GameObject("Drill"); drill.Parent = root;
            drill.Transform.LocalPosition = new Vector3(0.3f, 0.82f, 0.12f);
            drill.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.1f,0.1f,0.22f));
            drill.GetComponent<MeshRenderer>().Material = CharMaterials.IronDark;

            Anim(root, "builtin:anim/humanoid_idle_walk_run");
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NPCWander";
            script.SetField("WanderRadius", 4f); script.SetField("WalkSpeed", 1.4f);
            script.SetField("DialogueLine", "Mind the works!");
            script.SetField("Animator", root.GetComponent<Animator>());
            return root;
        }

        // ── Sailor ───────────────────────────────────────────
        public static GameObject Sailor()
        {
            var root = MakeBiped("Char_Sailor", 1.76f,
                CharMaterials.SailorWhite, CharMaterials.SkinTanned);

            // Sailor cap
            var cap = new GameObject("SailorCap"); cap.Parent = root.FindChild("Hips").FindChild("Head");
            cap.Transform.LocalPosition = new Vector3(0f, 0.12f, 0f);
            cap.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.13f, 0.05f, 10);
            cap.GetComponent<MeshRenderer>().Material = CharMaterials.HelmetSailor;

            // Spyglass
            var glass = new GameObject("Spyglass"); glass.Parent = root;
            glass.Transform.LocalPosition = new Vector3(0.3f, 1.05f, 0.15f);
            glass.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.025f, 0.4f);
            glass.GetComponent<MeshRenderer>().Material = CharMaterials.BrassShiny;

            Anim(root, "builtin:anim/humanoid_idle_walk_run");
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NPCWander";
            script.SetField("WanderRadius", 10f); script.SetField("WalkSpeed", 2f);
            script.SetField("DialogueLine", "Land ho!");
            script.SetField("Animator", root.GetComponent<Animator>());
            return root;
        }

        // ── Pirate ───────────────────────────────────────────
        public static GameObject Pirate()
        {
            var root = MakeBiped("Char_Pirate", 1.78f,
                CharMaterials.PirateShirt, CharMaterials.SkinTanned);

            // Bandana
            var bandana = new GameObject("Bandana"); bandana.Parent = root.FindChild("Hips").FindChild("Head");
            bandana.Transform.LocalPosition = new Vector3(0f, 0.05f, 0.06f);
            bandana.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.22f,0.06f,0.22f));
            bandana.GetComponent<MeshRenderer>().Material = CharMaterials.BandanaRed;

            // Eye patch
            var patch = new GameObject("EyePatch"); patch.Parent = root.FindChild("Hips").FindChild("Head");
            patch.Transform.LocalPosition = new Vector3(-0.06f, 0.02f, 0.11f);
            patch.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.06f,0.04f,0.01f));
            patch.GetComponent<MeshRenderer>().Material = CharMaterials.HatBlack;

            // Cutlass
            var cutlass = new GameObject("Cutlass"); cutlass.Parent = root;
            cutlass.Transform.LocalPosition = new Vector3(0.25f, 0.85f, 0.12f);
            cutlass.Transform.LocalEulerAngles = new Vector3(0f, 0f, 35f);
            cutlass.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.04f, 0.5f, 0.02f));
            cutlass.GetComponent<MeshRenderer>().Material = CharMaterials.SwordBlade;

            Anim(root, "builtin:anim/humanoid_combat");
            root.AddComponent<HealthComponent>().MaxHealth = 80f;
            var nav = root.AddComponent<NavMeshAgent>(); nav.Speed = 3.5f;
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "GruntAI"; script.SetField("AttackDamage", 18f);
            script.SetField("Animator", root.GetComponent<Animator>());
            return root;
        }

        // ── Witch ─────────────────────────────────────────────
        public static GameObject Witch()
        {
            var root = MakeBiped("Char_Witch", 1.68f,
                CharMaterials.WitchBlack, CharMaterials.SkinLight);

            // Cone hat
            var hat = new GameObject("WitchHat"); hat.Parent = root.FindChild("Hips").FindChild("Head");
            hat.Transform.LocalPosition = new Vector3(0f, 0.2f, 0f);
            hat.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCone(0.14f, 0.50f, 8);
            hat.GetComponent<MeshRenderer>().Material = CharMaterials.HatBlack;

            // Broom
            var broom = new GameObject("Broom"); broom.Parent = root;
            broom.Transform.LocalPosition = new Vector3(0.3f, 0.5f, 0f);
            broom.Transform.LocalEulerAngles = new Vector3(15f, 0f, 20f);
            broom.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.025f, 1.4f);
            broom.GetComponent<MeshRenderer>().Material = CharMaterials.WoodDark;

            // Cauldron smoke VFX
            var smoke = new GameObject("BroomSmoke"); smoke.Parent = broom;
            smoke.Transform.LocalPosition = new Vector3(0f, 0.7f, 0f);
            var pe = smoke.AddComponent<ParticleEmitter>();
            pe.Rate=4f; pe.LifetimeMin=0.5f; pe.LifetimeMax=1.2f;
            pe.SpeedMin=0.2f; pe.SpeedMax=0.6f;
            pe.SizeMin=0.04f; pe.SizeMax=0.15f;
            pe.ColorStart=new Color(0.4f,0.1f,0.6f,0.6f); pe.ColorEnd=new Color(0.2f,0.05f,0.3f,0f);

            Anim(root, "builtin:anim/humanoid_idle_walk_run");
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NPCWander";
            script.SetField("WanderRadius", 6f);
            script.SetField("DialogueLine", "Double, double toil and trouble...");
            script.SetField("Animator", root.GetComponent<Animator>());
            return root;
        }

        // ── Ninja ─────────────────────────────────────────────
        public static GameObject Ninja()
        {
            var root = MakeBiped("Char_Ninja", 1.72f,
                CharMaterials.NinjaBlack, CharMaterials.SkinMedium);

            // Face wrap
            var wrap = new GameObject("FaceWrap"); wrap.Parent = root.FindChild("Hips").FindChild("Head");
            wrap.Transform.LocalPosition = new Vector3(0f, -0.04f, 0.05f);
            wrap.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.20f, 0.08f, 0.12f));
            wrap.GetComponent<MeshRenderer>().Material = CharMaterials.NinjaBlack;

            // Katana on back
            var katana = new GameObject("Katana"); katana.Parent = root;
            katana.Transform.LocalPosition = new Vector3(0.05f, 1.1f, -0.15f);
            katana.Transform.LocalEulerAngles = new Vector3(0f, 0f, 45f);
            katana.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.025f, 0.7f, 0.01f));
            katana.GetComponent<MeshRenderer>().Material = CharMaterials.SwordBlade;

            Anim(root, "builtin:anim/humanoid_combat");
            root.AddComponent<HealthComponent>().MaxHealth = 70f;
            var nav = root.AddComponent<NavMeshAgent>(); nav.Speed = 5.5f;
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "GruntAI"; script.SetField("AttackDamage", 25f); script.SetField("PatrolRadius", 12f);
            script.SetField("Animator", root.GetComponent<Animator>());
            return root;
        }

        // ── Dancer ────────────────────────────────────────────
        public static GameObject Dancer()
        {
            var root = MakeBiped("Char_Dancer", 1.68f,
                CharMaterials.DressPink, CharMaterials.SkinMedium);

            // Tutu skirt
            var tutu = new GameObject("Tutu"); tutu.Parent = root.FindChild("Hips");
            tutu.Transform.LocalPosition = new Vector3(0f, 0.05f, 0f);
            tutu.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.32f, 0.18f, 10);
            tutu.GetComponent<MeshRenderer>().Material = CharMaterials.DressPink;
            tutu.AddComponent<ClothPhysics>().WindInfluence = 0.15f;

            // Bun hair
            var hair = new GameObject("HairBun"); hair.Parent = root.FindChild("Hips").FindChild("Head");
            hair.Transform.LocalPosition = new Vector3(0f, 0.14f, -0.02f);
            hair.AddComponent<MeshRenderer>().Mesh = Mesh.CreateSphere(0.08f, 5, 5);
            hair.GetComponent<MeshRenderer>().Material = CharMaterials.HairDarkBrown;

            Anim(root, "builtin:anim/humanoid_dance");
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NPCWander";
            script.SetField("WanderRadius", 3f); script.SetField("WalkSpeed", 1.8f);
            script.SetField("DialogueLine", "Every step tells a story.");
            script.SetField("Animator", root.GetComponent<Animator>());
            return root;
        }

        // ── Priest / Monk ─────────────────────────────────────
        public static GameObject Priest()
        {
            var root = MakeBiped("Char_Priest", 1.75f,
                CharMaterials.RobeWhite, CharMaterials.SkinLight);

            // Long robe overlay
            var robe = new GameObject("Robe"); robe.Parent = root.FindChild("Hips");
            robe.Transform.LocalPosition = new Vector3(0f, 0f, 0f);
            robe.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCylinder(0.26f, 0.90f, 8);
            robe.GetComponent<MeshRenderer>().Material = CharMaterials.RobeWhite;
            robe.AddComponent<ClothPhysics>().WindInfluence = 0.15f;

            // Gold cross necklace
            var cross = new GameObject("Cross"); cross.Parent = root;
            cross.Transform.LocalPosition = new Vector3(0f, 1.2f, 0.12f);
            cross.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.02f, 0.06f, 0.01f));
            cross.GetComponent<MeshRenderer>().Material = CharMaterials.BrassShiny;

            Anim(root, "builtin:anim/humanoid_idle_walk_run");
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NPCWander";
            script.SetField("WanderRadius", 8f); script.SetField("WalkSpeed", 1.2f);
            script.SetField("DialogueLine", "May the light guide you.");
            script.SetField("CanHeal", true);
            script.SetField("Animator", root.GetComponent<Animator>());
            return root;
        }

        // ── Business Person ────────────────────────────────────
        public static GameObject BusinessPerson()
        {
            var root = MakeBiped("Char_BusinessPerson", 1.78f,
                CharMaterials.JacketBlack, CharMaterials.SkinMedium);

            // Tie
            var tie = new GameObject("Tie"); tie.Parent = root.FindChild("Hips").FindChild("Torso");
            tie.Transform.LocalPosition = new Vector3(0f, 0.08f, 0.11f);
            tie.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.035f, 0.22f, 0.01f));
            tie.GetComponent<MeshRenderer>().Material = CharMaterials.CapBlue;

            // Briefcase
            var briefcase = new GameObject("Briefcase"); briefcase.Parent = root;
            briefcase.Transform.LocalPosition = new Vector3(0.32f, 0.72f, 0.05f);
            briefcase.AddComponent<MeshRenderer>().Mesh = Mesh.CreateCube(new Vector3(0.22f,0.16f,0.06f));
            briefcase.GetComponent<MeshRenderer>().Material = CharMaterials.LeatherBrown;

            Anim(root, "builtin:anim/humanoid_idle_walk_run");
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NPCWander";
            script.SetField("WanderRadius", 20f); script.SetField("WalkSpeed", 2.2f);
            script.SetField("DialogueLine", "I'm late for a meeting.");
            script.SetField("Animator", root.GetComponent<Animator>());
            return root;
        }
    }
}
