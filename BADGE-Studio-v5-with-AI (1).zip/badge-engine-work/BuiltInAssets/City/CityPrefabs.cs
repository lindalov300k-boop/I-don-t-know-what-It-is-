// ============================================================
//  BADGE Engine – BuiltInAssets/City/CityPrefabs.cs
//  Low-poly city / urban environment game-object factories.
//  All objects cast and receive shadows, have LOD-appropriate
//  colliders and optional interactive scripts.
// ============================================================
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.City
{
    public static class CityPrefabs
    {
        // ── Street Light ─────────────────────────────────────
        /// <summary>
        /// Classic cast-iron street lamp with warm sodium point
        /// light. Flickers on a probability schedule.
        /// See also LightingPrefabs.StreetLamp for a minimal version.
        /// This version includes a full post, arm and globe glass.
        /// </summary>
        public static GameObject StreetLight()
        {
            var root = new GameObject("City_StreetLight");
            root.Tag = "CityProp";

            // Post
            var post = new GameObject("Post");
            post.Parent = root;
            var pMr = post.AddComponent<MeshRenderer>();
            pMr.Mesh     = Mesh.CreateCylinder(0.06f, 5.2f);
            pMr.Material = CityMaterials.IronBlack;
            post.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Curved arm (lean)
            var arm = new GameObject("Arm");
            arm.Parent = root;
            arm.Transform.LocalPosition = new Vector3(0.35f, 5.0f, 0f);
            arm.Transform.LocalEulerAngles = new Vector3(0f, 0f, -20f);
            var aMr = arm.AddComponent<MeshRenderer>();
            aMr.Mesh     = Mesh.CreateCylinder(0.04f, 0.9f);
            aMr.Material = CityMaterials.IronBlack;

            // Globe head
            var globe = new GameObject("Globe");
            globe.Parent = root;
            globe.Transform.LocalPosition = new Vector3(0.6f, 5.1f, 0f);
            var gMr = globe.AddComponent<MeshRenderer>();
            gMr.Mesh     = Mesh.CreateSphere(0.18f, 6, 8);
            gMr.Material = CityMaterials.GlobeGlass;

            // Point light inside globe
            var lightObj = new GameObject("GlobeLight");
            lightObj.Parent = globe;
            var light = lightObj.AddComponent<Light>();
            light.Type = LightType.Point; light.Color = new Color(1f, 0.85f, 0.45f);
            light.Intensity = 3.5f; light.Range = 18f;

            // Base cap
            var cap = new GameObject("BaseCap");
            cap.Parent = root;
            cap.Transform.LocalPosition = new Vector3(0f, 0.12f, 0f);
            var capMr = cap.AddComponent<MeshRenderer>();
            capMr.Mesh     = Mesh.CreateCylinder(0.15f, 0.24f, 8);
            capMr.Material = CityMaterials.IronBlack;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "StreetLampController";
            script.SetField("FlickerProbability", 0.001f);
            script.SetField("FlickerDuration",    0.07f);
            script.SetField("NightOnlyMode",      true);
            script.SetField("LampLight",          light);

            return root;
        }

        // ── Post Box ──────────────────────────────────────────
        /// <summary>
        /// Iconic red cylindrical post box. Collectable letters
        /// can be deposited or retrieved (quest hook).
        /// Lid pops open on interact.
        /// </summary>
        public static GameObject PostBox()
        {
            var root = new GameObject("City_PostBox");
            root.Tag = "CityProp";

            // Body cylinder
            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCylinder(0.25f, 1.2f, 12);
            bMr.Material = CityMaterials.PostBoxRed;
            bMr.CastShadows = true;
            body.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Dome top
            var dome = new GameObject("Dome");
            dome.Parent = root;
            dome.Transform.LocalPosition = new Vector3(0f, 0.66f, 0f);
            var dMr = dome.AddComponent<MeshRenderer>();
            dMr.Mesh     = Mesh.CreateSphere(0.26f, 6, 8);
            dMr.Material = CityMaterials.PostBoxRed;

            // Letter slot
            var slot = new GameObject("LetterSlot");
            slot.Parent = root;
            slot.Transform.LocalPosition = new Vector3(0f, 0.3f, 0.25f);
            var sMr = slot.AddComponent<MeshRenderer>();
            sMr.Mesh     = Mesh.CreateCube(new Vector3(0.14f, 0.025f, 0.01f));
            sMr.Material = CityMaterials.SlotMetal;

            // Royal cypher decal
            var cypher = new GameObject("Cypher");
            cypher.Parent = root;
            cypher.Transform.LocalPosition = new Vector3(0f, 0.55f, 0.25f);
            var cyMr = cypher.AddComponent<MeshRenderer>();
            cyMr.Mesh     = Mesh.CreateQuad();
            cyMr.Material = CityMaterials.CypherDecal;

            // Interaction trigger
            var trigger = new GameObject("PostTrigger");
            trigger.Parent = root;
            var tCol = trigger.AddComponent<Collider>();
            tCol.Shape = ColliderShape.Sphere; tCol.Radius = 1.5f; tCol.IsTrigger = true;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/letter_drop"; audio.Volume = 0.6f; audio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PostBoxInteraction";
            script.SetField("AcceptsLetters",  true);
            script.SetField("QuestMailID",     "quest_mail_01");
            script.SetField("Audio",           audio);

            return root;
        }

        // ── Park Bench ────────────────────────────────────────
        /// <summary>
        /// Wooden slatted park bench with cast-iron legs.
        /// Sittable (2 seats), NPCs wander to and sit on it.
        /// </summary>
        public static GameObject ParkBench()
        {
            var root = new GameObject("City_ParkBench");
            root.Tag = "CityProp";

            // Seat slats (5)
            for (int i = 0; i < 5; i++)
            {
                var slat = new GameObject($"SeatSlat_{i}");
                slat.Parent = root;
                slat.Transform.LocalPosition = new Vector3(0f, 0.45f, -0.16f + i * 0.08f);
                var sMr = slat.AddComponent<MeshRenderer>();
                sMr.Mesh     = Mesh.CreateCube(new Vector3(1.6f, 0.04f, 0.07f));
                sMr.Material = CityMaterials.BenchWood;
                sMr.CastShadows = true;
            }

            // Back slats (4)
            for (int i = 0; i < 4; i++)
            {
                var slat = new GameObject($"BackSlat_{i}");
                slat.Parent = root;
                slat.Transform.LocalPosition = new Vector3(0f, 0.6f + i * 0.1f, -0.2f);
                var sMr = slat.AddComponent<MeshRenderer>();
                sMr.Mesh     = Mesh.CreateCube(new Vector3(1.6f, 0.04f, 0.07f));
                sMr.Material = CityMaterials.BenchWood;
            }

            // Cast iron legs (2)
            foreach (var (x, name) in new[] { (-0.72f, "LegL"), (0.72f, "LegR") })
            {
                var leg = new GameObject(name);
                leg.Parent = root;
                leg.Transform.LocalPosition = new Vector3(x, 0.22f, 0f);
                var lMr = leg.AddComponent<MeshRenderer>();
                lMr.Mesh     = "builtin:mesh/bench_leg";
                lMr.Material = CityMaterials.IronBlack;
            }

            var col = root.AddComponent<Collider>();
            col.Shape = ColliderShape.Box; col.Size = new Vector3(1.6f, 0.9f, 0.5f);

            var sitTrigger = new GameObject("SitTrigger");
            sitTrigger.Parent = root;
            var stCol = sitTrigger.AddComponent<Collider>();
            stCol.Shape = ColliderShape.Box; stCol.Size = new Vector3(1.5f, 0.5f, 0.4f); stCol.IsTrigger = true;
            sitTrigger.Transform.LocalPosition = new Vector3(0f, 0.55f, 0f);

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "SittableFurniture";
            script.SetField("SeatCount",  2);
            script.SetField("SitHeight",  0.45f);

            return root;
        }

        // ── Litter Bin ────────────────────────────────────────
        /// <summary>
        /// Metal cylindrical litter bin on a post.
        /// Lid lifts on interact, throwable items can be binned.
        /// </summary>
        public static GameObject LitterBin()
        {
            var root = new GameObject("City_LitterBin");
            root.Tag = "CityProp";

            // Support post
            var post = new GameObject("Post");
            post.Parent = root;
            var pMr = post.AddComponent<MeshRenderer>();
            pMr.Mesh     = Mesh.CreateCylinder(0.04f, 0.75f);
            pMr.Material = CityMaterials.IronBlack;

            // Bin body
            var bin = new GameObject("BinBody");
            bin.Parent = root;
            bin.Transform.LocalPosition = new Vector3(0f, 0.85f, 0f);
            var bMr = bin.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCylinder(0.22f, 0.6f, 10);
            bMr.Material = CityMaterials.BinGreen;
            bin.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Lid
            var lid = new GameObject("Lid");
            lid.Parent = root;
            lid.Transform.LocalPosition = new Vector3(0f, 1.18f, 0f);
            var lidMr = lid.AddComponent<MeshRenderer>();
            lidMr.Mesh     = Mesh.CreateCylinder(0.23f, 0.06f, 10);
            lidMr.Material = CityMaterials.BinGreen;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/bin_lid"; audio.Volume = 0.5f; audio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "LitterBinInteraction";
            script.SetField("LidObj",  lid);
            script.SetField("Audio",   audio);

            return root;
        }

        // ── Bus Stop ──────────────────────────────────────────
        /// <summary>
        /// Covered bus stop shelter with a timetable poster.
        /// NPCs wait at the bench inside. Bus route hook.
        /// </summary>
        public static GameObject BusStop()
        {
            var root = new GameObject("City_BusStop");
            root.Tag = "CityProp";

            // Back panel (glass/perspex)
            var backPanel = new GameObject("BackPanel");
            backPanel.Parent = root;
            backPanel.Transform.LocalPosition = new Vector3(0f, 1.1f, -0.3f);
            var bpMr = backPanel.AddComponent<MeshRenderer>();
            bpMr.Mesh     = Mesh.CreateCube(new Vector3(2.4f, 2.2f, 0.05f));
            bpMr.Material = CityMaterials.ShelterGlass;
            backPanel.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Roof
            var roof = new GameObject("Roof");
            roof.Parent = root;
            roof.Transform.LocalPosition = new Vector3(0f, 2.25f, 0f);
            var rMr = roof.AddComponent<MeshRenderer>();
            rMr.Mesh     = Mesh.CreateCube(new Vector3(2.5f, 0.06f, 1.0f));
            rMr.Material = CityMaterials.ShelterMetal;

            // Side posts (2)
            foreach (var (x, name) in new[] { (-1.18f, "PostL"), (1.18f, "PostR") })
            {
                var sPost = new GameObject(name);
                sPost.Parent = root;
                sPost.Transform.LocalPosition = new Vector3(x, 1.05f, 0f);
                var spMr = sPost.AddComponent<MeshRenderer>();
                spMr.Mesh     = Mesh.CreateCylinder(0.05f, 2.1f);
                spMr.Material = CityMaterials.ShelterMetal;
            }

            // Bench inside
            var bench = new GameObject("BusBench");
            bench.Parent = root;
            bench.Transform.LocalPosition = new Vector3(0f, 0.38f, -0.22f);
            var benMr = bench.AddComponent<MeshRenderer>();
            benMr.Mesh     = Mesh.CreateCube(new Vector3(2f, 0.06f, 0.35f));
            benMr.Material = CityMaterials.BenchWood;

            // Timetable poster
            var poster = new GameObject("Timetable");
            poster.Parent = root;
            poster.Transform.LocalPosition = new Vector3(0.7f, 1.4f, -0.27f);
            var poMr = poster.AddComponent<MeshRenderer>();
            poMr.Mesh     = Mesh.CreateQuad();
            poMr.Material = CityMaterials.BusTimePoster;

            // Route sign on top
            var routeSign = new GameObject("RouteSign");
            routeSign.Parent = root;
            routeSign.Transform.LocalPosition = new Vector3(0f, 2.5f, -0.1f);
            var rsMr = routeSign.AddComponent<MeshRenderer>();
            rsMr.Mesh     = Mesh.CreateCube(new Vector3(1.0f, 0.35f, 0.08f));
            rsMr.Material = CityMaterials.SignYellow;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "BusStopController";
            script.SetField("RouteNumber",    42);
            script.SetField("BusIntervalSec", 120f);
            script.SetField("WaitTagTarget",  "NPC");

            return root;
        }

        // ── Phone Box ─────────────────────────────────────────
        /// <summary>
        /// Classic red telephone box. Door opens on approach.
        /// Inside has a payphone prop; can trigger a quest call cutscene.
        /// </summary>
        public static GameObject PhoneBox()
        {
            var root = new GameObject("City_PhoneBox");
            root.Tag = "CityProp";

            // Main body
            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(1.0f, 2.7f, 1.0f));
            bMr.Material = CityMaterials.PhoneBoxRed;
            body.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Glass panes (4 sides)
            Material glassMat = CityMaterials.ShelterGlass;
            float[] gpz = { 0.46f, -0.46f, 0f, 0f };
            float[] gpx = { 0f, 0f, 0.46f, -0.46f };
            bool[] isWide = { true, true, false, false };
            for (int i = 0; i < 4; i++)
            {
                var pane = new GameObject($"Pane_{i}");
                pane.Parent = root;
                pane.Transform.LocalPosition = new Vector3(gpx[i], 0.9f, gpz[i]);
                var pMr = pane.AddComponent<MeshRenderer>();
                pMr.Mesh     = Mesh.CreateCube(isWide[i]
                    ? new Vector3(0.95f, 1.5f, 0.04f)
                    : new Vector3(0.04f, 1.5f, 0.95f));
                pMr.Material = glassMat;
            }

            // Roof dome
            var roof = new GameObject("Roof");
            roof.Parent = root;
            roof.Transform.LocalPosition = new Vector3(0f, 1.52f, 0f);
            var rMr = roof.AddComponent<MeshRenderer>();
            rMr.Mesh     = Mesh.CreateSphere(0.55f, 4, 6);
            rMr.Material = CityMaterials.PhoneBoxRed;

            // Payphone inside
            var phone = new GameObject("Payphone");
            phone.Parent = root;
            phone.Transform.LocalPosition = new Vector3(0f, 0.65f, -0.3f);
            var phMr = phone.AddComponent<MeshRenderer>();
            phMr.Mesh     = "builtin:mesh/payphone";
            phMr.Material = CityMaterials.PhoneBlack;

            // Interior light
            var intLight = new GameObject("IntLight");
            intLight.Parent = root;
            var l = intLight.AddComponent<Light>();
            l.Type = LightType.Point; l.Color = new Color(1f, 0.95f, 0.7f);
            l.Intensity = 1.5f; l.Range = 2f;

            var ringAudio = root.AddComponent<AudioSource>();
            ringAudio.Clip = "builtin:audio/phone_ring"; ringAudio.Volume = 0.7f; ringAudio.SpatialBlend = 1f; ringAudio.MaxDistance = 15f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PhoneBoxInteraction";
            script.SetField("QuestCallID",  "quest_call_01");
            script.SetField("RingInterval", 30f);
            script.SetField("RingAudio",    ringAudio);
            script.SetField("IntLight",     l);

            return root;
        }

        // ── Traffic Light ─────────────────────────────────────
        /// <summary>
        /// 3-state traffic light (red/amber/green cycle).
        /// Paired with a pedestrian crossing trigger that halts
        /// NPC / vehicle traffic.
        /// </summary>
        public static GameObject TrafficLight()
        {
            var root = new GameObject("City_TrafficLight");
            root.Tag = "CityProp";

            // Post
            var post = new GameObject("Post");
            post.Parent = root;
            var pMr = post.AddComponent<MeshRenderer>();
            pMr.Mesh     = Mesh.CreateCylinder(0.06f, 4.0f);
            pMr.Material = CityMaterials.IronBlack;
            post.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Housing box
            var housing = new GameObject("Housing");
            housing.Parent = root;
            housing.Transform.LocalPosition = new Vector3(0f, 3.2f, 0f);
            var hMr = housing.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateCube(new Vector3(0.3f, 0.85f, 0.25f));
            hMr.Material = CityMaterials.IronBlack;

            // Light lenses (red, amber, green)
            Color[] lensColors = {
                new Color(1f, 0.1f, 0.1f),
                new Color(1f, 0.65f, 0.1f),
                new Color(0.1f, 0.9f, 0.1f)
            };
            Light[] lights = new Light[3];
            for (int i = 0; i < 3; i++)
            {
                var lens = new GameObject(new[] { "LensRed", "LensAmber", "LensGreen" }[i]);
                lens.Parent = housing;
                lens.Transform.LocalPosition = new Vector3(0f, 0.3f - i * 0.28f, 0.13f);
                var lMr = lens.AddComponent<MeshRenderer>();
                lMr.Mesh     = Mesh.CreateSphere(0.08f, 5, 6);
                lMr.Material = Make(lensColors[i]);
                var l = lens.AddComponent<Light>();
                l.Type = LightType.Point; l.Color = lensColors[i];
                l.Intensity = 0f; l.Range = 8f;
                lights[i] = l;
            }

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/traffic_beep"; audio.Volume = 0.5f; audio.SpatialBlend = 1f; audio.MaxDistance = 15f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "TrafficLightController";
            script.SetField("RedDuration",    12f);
            script.SetField("AmberDuration",  2.5f);
            script.SetField("GreenDuration",  10f);
            script.SetField("LightRed",       lights[0]);
            script.SetField("LightAmber",     lights[1]);
            script.SetField("LightGreen",     lights[2]);
            script.SetField("Audio",          audio);

            return root;
        }

        // ── Fire Hydrant ──────────────────────────────────────
        /// <summary>
        /// Red fire hydrant. Can be struck to emit a water geyser
        /// VFX that pushes back nearby characters and vehicles.
        /// </summary>
        public static GameObject FireHydrant()
        {
            var root = new GameObject("City_FireHydrant");
            root.Tag = "CityProp";

            // Body
            var body = new GameObject("HydrantBody");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCylinder(0.15f, 0.5f, 8);
            bMr.Material = CityMaterials.HydrantRed;
            body.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Dome top
            var dome = new GameObject("HydrantDome");
            dome.Parent = root;
            dome.Transform.LocalPosition = new Vector3(0f, 0.3f, 0f);
            var dMr = dome.AddComponent<MeshRenderer>();
            dMr.Mesh     = Mesh.CreateSphere(0.13f, 5, 6);
            dMr.Material = CityMaterials.HydrantRed;

            // Side nozzles (2)
            foreach (var (x, name) in new[] { (-0.16f, "NozzleL"), (0.16f, "NozzleR") })
            {
                var nozzle = new GameObject(name);
                nozzle.Parent = root;
                nozzle.Transform.LocalPosition = new Vector3(x, 0.18f, 0f);
                var nMr = nozzle.AddComponent<MeshRenderer>();
                nMr.Mesh     = Mesh.CreateCylinder(0.04f, 0.12f);
                nMr.Material = CityMaterials.SlotMetal;
            }

            // Water geyser VFX (off by default)
            var geyser = new GameObject("WaterGeyser");
            geyser.Parent = root;
            geyser.Transform.LocalPosition = new Vector3(0f, 0.35f, 0f);
            var pe = geyser.AddComponent<ParticleEmitter>();
            pe.Rate = 60f; pe.LifetimeMin = 0.5f; pe.LifetimeMax = 1.5f;
            pe.SpeedMin = 4f; pe.SpeedMax = 9f;
            pe.SizeMin = 0.04f; pe.SizeMax = 0.2f;
            pe.ColorStart = new Color(0.7f, 0.85f, 1f, 0.9f); pe.ColorEnd = new Color(0.9f, 1f, 1f, 0f);
            pe.Shape = EmissionShapeType.Cone;
            geyser.SetActive(false);

            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth = hp.CurrentHealth = 50f;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/water_geyser"; audio.Loop = true; audio.Volume = 0.7f; audio.SpatialBlend = 1f; audio.MaxDistance = 20f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "FireHydrantProp";
            script.SetField("GeyserPushForce", 12f);
            script.SetField("GeyserRadius",    4f);
            script.SetField("GeyserObj",       geyser);
            script.SetField("Audio",           audio);

            return root;
        }

        // ── Manhole Cover ─────────────────────────────────────
        /// <summary>
        /// Flush cast-iron manhole cover. Player can lift and
        /// enter a tunnel/sewer sub-level trigger beneath.
        /// </summary>
        public static GameObject ManholeCover()
        {
            var root = new GameObject("City_ManholeCover");
            root.Tag = "CityProp";

            var cover = new GameObject("Cover");
            cover.Parent = root;
            var cMr = cover.AddComponent<MeshRenderer>();
            cMr.Mesh     = Mesh.CreateCylinder(0.55f, 0.06f, 16);
            cMr.Material = CityMaterials.IronBlack;
            cover.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Sewer descent trigger underneath
            var tunnel = new GameObject("TunnelEntrance");
            tunnel.Parent = root;
            tunnel.Transform.LocalPosition = new Vector3(0f, -0.15f, 0f);
            var tCol = tunnel.AddComponent<Collider>();
            tCol.Shape = ColliderShape.Cylinder; tCol.Radius = 0.45f; tCol.IsTrigger = true;
            tunnel.SetActive(false);

            var liftAudio = root.AddComponent<AudioSource>();
            liftAudio.Clip = "builtin:audio/manhole_scrape"; liftAudio.Volume = 0.7f; liftAudio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ManholeCoverInteraction";
            script.SetField("TargetScene",    "");  // Set to sub-level scene name
            script.SetField("LiftTime",       1.2f);
            script.SetField("CoverObj",       cover);
            script.SetField("TunnelTrigger",  tunnel);
            script.SetField("LiftAudio",      liftAudio);

            return root;
        }

        // ── Newspaper Stand ───────────────────────────────────
        /// <summary>
        /// Wire newspaper dispenser box. Interact to collect a
        /// newspaper item (reveals a quest clue or lore snippet).
        /// </summary>
        public static GameObject NewspaperStand()
        {
            var root = new GameObject("City_NewspaperStand");
            root.Tag = "CityProp";

            // Metal box
            var box = new GameObject("StandBox");
            box.Parent = root;
            var bMr = box.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(0.45f, 0.55f, 0.3f));
            bMr.Material = CityMaterials.IronBlack;
            box.AddComponent<Collider>().Shape = ColliderShape.Box;
            box.Transform.LocalPosition = new Vector3(0f, 0.28f, 0f);

            // Headline poster on front
            var poster = new GameObject("Headline");
            poster.Parent = root;
            poster.Transform.LocalPosition = new Vector3(0f, 0.3f, 0.155f);
            var poMr = poster.AddComponent<MeshRenderer>();
            poMr.Mesh     = Mesh.CreateQuad();
            poMr.Material = CityMaterials.NewspaperPaper;
            poster.Transform.LocalScale = new Vector3(0.38f, 0.42f, 1f);

            // Coin slot
            var coinSlot = new GameObject("CoinSlot");
            coinSlot.Parent = root;
            coinSlot.Transform.LocalPosition = new Vector3(0.15f, 0.35f, 0.16f);
            var csMr = coinSlot.AddComponent<MeshRenderer>();
            csMr.Mesh     = Mesh.CreateCube(new Vector3(0.04f, 0.025f, 0.01f));
            csMr.Material = CityMaterials.SlotMetal;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/coin_insert"; audio.Volume = 0.5f; audio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "NewspaperStandInteraction";
            script.SetField("CostCoins",   1);
            script.SetField("LorePage",    "lore_page_01");
            script.SetField("Audio",       audio);

            return root;
        }

        // ── Vending Machine ───────────────────────────────────
        /// <summary>
        /// Glowing vending machine. Sells food/ammo/powerup items.
        /// Can be shot/destroyed to spill loot. Hums and flickers
        /// when low on stock.
        /// </summary>
        public static GameObject VendingMachine()
        {
            var root = new GameObject("City_VendingMachine");
            root.Tag = "CityProp";

            // Body
            var body = new GameObject("VendBody");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(0.9f, 1.8f, 0.6f));
            bMr.Material = CityMaterials.VendingBodyBlue;
            bMr.CastShadows = true;
            body.AddComponent<Collider>().Shape = ColliderShape.Box;
            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth = hp.CurrentHealth = 80f;

            // Screen / display
            var screen = new GameObject("Screen");
            screen.Parent = root;
            screen.Transform.LocalPosition = new Vector3(0f, 0.55f, 0.31f);
            var scMr = screen.AddComponent<MeshRenderer>();
            scMr.Mesh     = Mesh.CreateCube(new Vector3(0.7f, 0.55f, 0.02f));
            scMr.Material = CityMaterials.VendScreen;

            // Screen glow light
            var screenGlow = screen.AddComponent<Light>();
            screenGlow.Type = LightType.Point; screenGlow.Color = new Color(0.3f, 0.7f, 1f);
            screenGlow.Intensity = 1.2f; screenGlow.Range = 2.5f;

            // Coin slot
            var coinSlot = new GameObject("CoinSlot");
            coinSlot.Parent = root;
            coinSlot.Transform.LocalPosition = new Vector3(0.3f, 0.15f, 0.31f);
            var csMr = coinSlot.AddComponent<MeshRenderer>();
            csMr.Mesh     = Mesh.CreateCube(new Vector3(0.06f, 0.035f, 0.01f));
            csMr.Material = CityMaterials.SlotMetal;

            // Retrieval slot at bottom
            var retSlot = new GameObject("RetrievalSlot");
            retSlot.Parent = root;
            retSlot.Transform.LocalPosition = new Vector3(0f, -0.7f, 0.31f);
            var rsMr = retSlot.AddComponent<MeshRenderer>();
            rsMr.Mesh     = Mesh.CreateCube(new Vector3(0.4f, 0.15f, 0.01f));
            rsMr.Material = CityMaterials.IronBlack;

            var humAudio = root.AddComponent<AudioSource>();
            humAudio.Clip = "builtin:audio/vending_hum"; humAudio.Loop = true; humAudio.PlayOnAwake = true;
            humAudio.Volume = 0.15f; humAudio.SpatialBlend = 1f; humAudio.MaxDistance = 6f;

            var dispenseAudio = root.AddComponent<AudioSource>();
            dispenseAudio.Clip = "builtin:audio/vending_dispense"; dispenseAudio.Volume = 0.7f; dispenseAudio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "VendingMachineInteraction";
            script.SetField("Inventory",      "builtin:shop/vending_machine");
            script.SetField("Stock",          20);
            script.SetField("ScreenGlow",     screenGlow);
            script.SetField("HumAudio",       humAudio);
            script.SetField("DispenseAudio",  dispenseAudio);
            script.SetField("LootOnDestroy",  "builtin:loot/vending_spill");

            return root;
        }

        // ── ATM ──────────────────────────────────────────────
        /// <summary>
        /// Wall-mounted ATM. Deposit or withdraw in-game currency.
        /// Screen glows, number pad interaction, card skimmer 
        /// tamper event for thief gameplay hooks.
        /// </summary>
        public static GameObject ATM()
        {
            var root = new GameObject("City_ATM");
            root.Tag = "CityProp";

            // Housing
            var housing = new GameObject("Housing");
            housing.Parent = root;
            var hMr = housing.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateCube(new Vector3(0.65f, 1.6f, 0.4f));
            hMr.Material = CityMaterials.ATMBodyGrey;
            housing.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Screen
            var screen = new GameObject("ATMScreen");
            screen.Parent = root;
            screen.Transform.LocalPosition = new Vector3(0f, 0.45f, 0.205f);
            var scMr = screen.AddComponent<MeshRenderer>();
            scMr.Mesh     = Mesh.CreateCube(new Vector3(0.45f, 0.35f, 0.02f));
            scMr.Material = CityMaterials.VendScreen;
            var sLight = screen.AddComponent<Light>();
            sLight.Type = LightType.Point; sLight.Color = new Color(0.4f, 0.8f, 1f);
            sLight.Intensity = 1f; sLight.Range = 1.5f;

            // Card slot
            var cardSlot = new GameObject("CardSlot");
            cardSlot.Parent = root;
            cardSlot.Transform.LocalPosition = new Vector3(0.18f, 0.7f, 0.205f);
            var csMr = cardSlot.AddComponent<MeshRenderer>();
            csMr.Mesh     = Mesh.CreateCube(new Vector3(0.1f, 0.025f, 0.01f));
            csMr.Material = CityMaterials.SlotMetal;

            // Cash slot
            var cashSlot = new GameObject("CashSlot");
            cashSlot.Parent = root;
            cashSlot.Transform.LocalPosition = new Vector3(0f, -0.3f, 0.205f);
            var cashMr = cashSlot.AddComponent<MeshRenderer>();
            cashMr.Mesh     = Mesh.CreateCube(new Vector3(0.2f, 0.03f, 0.01f));
            cashMr.Material = CityMaterials.SlotMetal;

            var beepAudio = root.AddComponent<AudioSource>();
            beepAudio.Clip = "builtin:audio/atm_beep"; beepAudio.Volume = 0.5f; beepAudio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ATMInteraction";
            script.SetField("WithdrawLimit",    500);
            script.SetField("TransactionFee",   5);
            script.SetField("SkimmerHackable",  true);
            script.SetField("ScreenLight",      sLight);
            script.SetField("BeepAudio",        beepAudio);

            return root;
        }

        // ── Shared material helper ────────────────────────────
        private static Material Make(Color c) =>
            new Material { Albedo = c, Metallic = 0.5f, Roughness = 0.4f, EmissionColor = c, EmissionStrength = 1.5f };
    }
}
