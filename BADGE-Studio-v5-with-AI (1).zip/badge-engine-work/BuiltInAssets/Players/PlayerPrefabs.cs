// ============================================================
//  BADGE Engine – BuiltInAssets/Players/PlayerPrefabs.cs
//  Competition-ready player game-object factories.
//  Each factory returns a fully configured GameObject with
//  all components, child objects and tuned default values.
// ============================================================
using System;
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Players
{
    public static class PlayerPrefabs
    {
        // ── FPS Player ───────────────────────────────────────
        /// <summary>
        /// Full first-person shooter rig.
        /// Hierarchy: Player → CameraRig → FPSCamera
        ///                               → WeaponSocket
        ///            Player → Body (mesh, collider, CC)
        /// Features: sprint, crouch, camera bob, footstep audio,
        ///           landing squash, stamina drain, step detection.
        /// </summary>
        public static GameObject FPSPlayer()
        {
            var root = new GameObject("FPS_Player");
            root.Tag   = "Player";
            root.Layer = Layers.Player;

            // ── CharacterController (physics body) ───────────
            var cc = root.AddComponent<CharacterController>();
            cc.Height      = 1.8f;
            cc.Radius      = 0.4f;
            cc.SlopeLimit  = 55f;
            cc.StepOffset  = 0.35f;

            // ── Rigidbody (kinematic – CC drives movement) ───
            var rb = root.AddComponent<Rigidbody>();
            rb.IsKinematic = true;
            rb.UseGravity  = false;

            // ── Audio: footsteps, land, jump ─────────────────
            var footAudio = root.AddComponent<AudioSource>();
            footAudio.Clip       = "builtin:audio/footstep_concrete";
            footAudio.Volume     = 0.6f;
            footAudio.SpatialBlend = 0f;   // 2-D in-head audio

            var landAudio = root.AddComponent<AudioSource>();
            landAudio.Clip       = "builtin:audio/land_thud";
            landAudio.Volume     = 0.8f;
            landAudio.SpatialBlend = 0f;

            // ── Health ────────────────────────────────────────
            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth     = 100f;
            hp.CurrentHealth = 100f;

            // ── Inventory ─────────────────────────────────────
            root.AddComponent<InventoryComponent>();

            // ── Camera rig child ──────────────────────────────
            var camRig = new GameObject("CameraRig");
            camRig.Parent = root;
            camRig.Transform.LocalPosition = new Vector3(0f, 1.65f, 0f);

            var cam = camRig.AddComponent<Camera>();
            cam.Mode        = CameraMode.FirstPerson;
            cam.FieldOfView = 90f;
            cam.NearClip    = 0.05f;
            cam.FarClip     = 500f;
            cam.SetAsMain();

            camRig.AddComponent<AudioListener>();

            // ── Weapon socket child ───────────────────────────
            var weaponSocket = new GameObject("WeaponSocket");
            weaponSocket.Parent = camRig;
            weaponSocket.Transform.LocalPosition = new Vector3(0.25f, -0.25f, 0.5f);

            // ── Body mesh (capsule stand-in) ──────────────────
            var body = new GameObject("Body");
            body.Parent = root;
            var mr = body.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCapsule(0.4f, 1.8f);
            mr.Material = Materials.PlayerBody;
            mr.CastShadows = true;

            // ── Ground check child ────────────────────────────
            var groundCheck = new GameObject("GroundCheck");
            groundCheck.Parent = root;
            groundCheck.Transform.LocalPosition = new Vector3(0f, -0.95f, 0f);

            // ── Script: FPSController ────────────────────────
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "FPSController";
            script.SetField("MoveSpeed",     6f);
            script.SetField("SprintSpeed",   10f);
            script.SetField("CrouchSpeed",   3f);
            script.SetField("JumpForce",     5.5f);
            script.SetField("Gravity",       -18f);
            script.SetField("MouseSensitivity", 2.5f);
            script.SetField("CrouchHeight",  1.1f);
            script.SetField("StaminaMax",    100f);
            script.SetField("StaminaDrain",  20f);
            script.SetField("StaminaRegen",  12f);
            script.SetField("BobFrequency",  12f);
            script.SetField("BobAmplitude",  0.05f);
            script.SetField("CameraRig",     camRig);
            script.SetField("WeaponSocket",  weaponSocket);
            script.SetField("FootAudio",     footAudio);
            script.SetField("LandAudio",     landAudio);
            script.SetField("GroundCheck",   groundCheck);

            return root;
        }

        // ── Platformer Hero ──────────────────────────────────
        /// <summary>
        /// 2-D side-scroller platformer character.
        /// Features: coyote time, jump buffering, wall slide,
        ///           wall jump, double jump, dash, sprite flip.
        /// </summary>
        public static GameObject PlatformerHero()
        {
            var root = new GameObject("Platformer_Hero");
            root.Tag   = "Player";
            root.Layer = Layers.Player;

            // ── Physics ───────────────────────────────────────
            var rb = root.AddComponent<Rigidbody>();
            rb.Mass             = 60f;
            rb.Drag             = 0f;
            rb.AngularDrag      = 0f;
            rb.UseGravity       = true;
            rb.FreezeRotationX  = true;
            rb.FreezeRotationY  = true;
            rb.FreezeRotationZ  = true;
            rb.FreezePositionZ  = true;   // Lock to 2-D plane

            var col = root.AddComponent<Collider>();
            col.Shape  = ColliderShape.Capsule;
            col.Size   = new Vector3(0.5f, 1.7f, 0.5f);
            col.PhysicsMaterial = PhysicsMaterials.ZeroFriction;

            // ── Sprite ────────────────────────────────────────
            var sr = root.AddComponent<SpriteRenderer>();
            sr.Sprite = "builtin:sprites/hero_idle";
            sr.Color  = Color.White;

            // ── Animator ─────────────────────────────────────
            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/platformer_hero";

            // ── Audio ─────────────────────────────────────────
            var audio = root.AddComponent<AudioSource>();
            audio.SpatialBlend = 0f;
            audio.Volume       = 0.7f;

            // ── Health ────────────────────────────────────────
            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth     = 3f;    // Hearts
            hp.CurrentHealth = 3f;
            hp.Invincible    = false;
            hp.InvincibilityDuration = 1.5f;

            // ── Camera (side-scroller) ─────────────────────
            var cam = root.AddComponent<Camera>();
            cam.Mode        = CameraMode.SideScroller;
            cam.Projection  = ProjectionMode.Orthographic;
            cam.OrthoSize   = 7f;
            cam.SetAsMain();
            root.AddComponent<AudioListener>();

            // ── Script ────────────────────────────────────────
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PlatformerController";
            script.SetField("MoveSpeed",        8f);
            script.SetField("JumpForce",        16f);
            script.SetField("DoubleJumpForce",  14f);
            script.SetField("DashSpeed",        22f);
            script.SetField("DashDuration",     0.15f);
            script.SetField("DashCooldown",     0.8f);
            script.SetField("CoyoteTime",       0.12f);
            script.SetField("JumpBufferTime",   0.1f);
            script.SetField("WallSlideGravity", -3f);
            script.SetField("WallJumpForce",    new Vector2(10f, 15f));
            script.SetField("MaxFallSpeed",    -30f);
            script.SetField("Animator",         anim);
            script.SetField("AudioSource",      audio);

            return root;
        }

        // ── Top-Down Hero ────────────────────────────────────
        /// <summary>
        /// Twin-stick / RPG top-down character.
        /// Features: 8-directional movement, dodge roll with
        ///           i-frames, animated shadow blob, auto-aim
        ///           assist, isometric camera option.
        /// </summary>
        public static GameObject TopDownHero()
        {
            var root = new GameObject("TopDown_Hero");
            root.Tag   = "Player";
            root.Layer = Layers.Player;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass            = 70f;
            rb.Drag            = 8f;
            rb.UseGravity      = false;
            rb.FreezePositionY = true;
            rb.FreezeRotationX = true;
            rb.FreezeRotationZ = true;

            var col = root.AddComponent<Collider>();
            col.Shape  = ColliderShape.Capsule;
            col.Radius = 0.35f;

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateCapsule(0.35f, 1.7f);
            mr.Material = Materials.PlayerBody;

            var anim = root.AddComponent<Animator>();
            anim.Controller = "builtin:anim/topdown_hero";

            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth     = 100f;
            hp.CurrentHealth = 100f;
            hp.InvincibilityDuration = 0.6f;

            root.AddComponent<InventoryComponent>();

            // Shadow blob decal child
            var shadow = new GameObject("BlobShadow");
            shadow.Parent = root;
            shadow.Transform.LocalPosition = new Vector3(0f, 0.02f, 0f);
            var shadowSr = shadow.AddComponent<SpriteRenderer>();
            shadowSr.Sprite = "builtin:sprites/blob_shadow";
            shadowSr.Color  = new Color(0f, 0f, 0f, 0.35f);

            // Top-down camera
            var camGo = new GameObject("TopDownCamera");
            camGo.Parent = root;
            camGo.Transform.LocalPosition = new Vector3(0f, 12f, -5f);
            camGo.Transform.LocalEulerAngles = new Vector3(60f, 0f, 0f);
            var cam = camGo.AddComponent<Camera>();
            cam.Mode        = CameraMode.TopDown;
            cam.FieldOfView = 60f;
            cam.SetAsMain();
            camGo.AddComponent<AudioListener>();

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "TopDownController";
            script.SetField("MoveSpeed",         7f);
            script.SetField("DodgeForce",        18f);
            script.SetField("DodgeDuration",     0.22f);
            script.SetField("DodgeCooldown",     1.0f);
            script.SetField("DodgeInvincible",   true);
            script.SetField("AimAssistRadius",   3.5f);
            script.SetField("AimAssistStrength", 0.4f);
            script.SetField("Animator",          anim);

            return root;
        }

        // ── Vehicle Driver ────────────────────────────────────
        /// <summary>
        /// Racing / combat player that drives an ArcadeCar prefab.
        /// Spawns behind the wheel with a chase camera, nitro HUD
        /// and crash rumble on collision.
        /// </summary>
        public static GameObject VehicleDriver()
        {
            var root = new GameObject("Vehicle_Driver");
            root.Tag   = "Player";
            root.Layer = Layers.Player;

            var hp = root.AddComponent<HealthComponent>();
            hp.MaxHealth     = 200f;
            hp.CurrentHealth = 200f;

            // Chase camera child
            var camGo = new GameObject("ChaseCamera");
            camGo.Parent = root;
            camGo.Transform.LocalPosition = new Vector3(0f, 3.5f, -8f);
            var cam = camGo.AddComponent<Camera>();
            cam.Mode        = CameraMode.ThirdPerson;
            cam.FieldOfView = 75f;
            cam.SetAsMain();
            camGo.AddComponent<AudioListener>();

            // Script wires the driver to a VehicleController at runtime
            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "VehicleDriverController";
            script.SetField("CameraLagSpeed",   6f);
            script.SetField("CameraFOVBoost",   10f);
            script.SetField("CrashShakeForce",  0.5f);
            script.SetField("CrashShakeDuration",0.4f);
            script.SetField("Camera",           camGo);

            return root;
        }
    }
}
