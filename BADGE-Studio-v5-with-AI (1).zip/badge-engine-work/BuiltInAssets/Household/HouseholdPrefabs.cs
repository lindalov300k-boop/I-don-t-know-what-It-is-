// ============================================================
//  BADGE Engine – BuiltInAssets/Household/HouseholdPrefabs.cs
//  Low-poly household furniture & chattel game-object factories.
//  All props cast and receive shadows, have accurate colliders
//  and optional interactive scripts.
// ============================================================
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Household
{
    public static class HouseholdPrefabs
    {
        // ── Sofa ──────────────────────────────────────────────
        /// <summary>
        /// 3-seat sofa with cushions. Player can sit when
        /// SitTrigger is entered. Cloth-physics cushions.
        /// </summary>
        public static GameObject Sofa()
        {
            var root = new GameObject("Household_Sofa");
            root.Tag = "Furniture";

            // Base frame
            var frame = new GameObject("Frame");
            frame.Parent = root;
            var fMr = frame.AddComponent<MeshRenderer>();
            fMr.Mesh     = Mesh.CreateCube(new Vector3(2.1f, 0.55f, 0.85f));
            fMr.Material = HouseMaterials.SofaFabricGrey;
            fMr.CastShadows = true; fMr.ReceiveShadows = true;
            frame.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Back rest
            var back = new GameObject("BackRest");
            back.Parent = root;
            back.Transform.LocalPosition = new Vector3(0f, 0.55f, -0.3f);
            var bMr = back.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(2.1f, 0.7f, 0.3f));
            bMr.Material = HouseMaterials.SofaFabricGrey;

            // Armrests
            foreach (var (x, name) in new[] { (-1.05f, "ArmL"), (1.05f, "ArmR") })
            {
                var arm = new GameObject(name);
                arm.Parent = root;
                arm.Transform.LocalPosition = new Vector3(x, 0.45f, 0f);
                var aMr = arm.AddComponent<MeshRenderer>();
                aMr.Mesh     = Mesh.CreateCube(new Vector3(0.25f, 0.45f, 0.85f));
                aMr.Material = HouseMaterials.SofaFabricGrey;
            }

            // Cushions (3)
            for (int i = 0; i < 3; i++)
            {
                var cushion = new GameObject($"Cushion_{i}");
                cushion.Parent = root;
                cushion.Transform.LocalPosition = new Vector3(-0.65f + i * 0.65f, 0.58f, 0.1f);
                var cMr = cushion.AddComponent<MeshRenderer>();
                cMr.Mesh     = Mesh.CreateCube(new Vector3(0.58f, 0.15f, 0.6f));
                cMr.Material = HouseMaterials.CushionBlue;
                cushion.AddComponent<ClothPhysics>().Stiffness = 0.9f;
            }

            // Sit trigger
            var sitTrigger = new GameObject("SitTrigger");
            sitTrigger.Parent = root;
            sitTrigger.Transform.LocalPosition = new Vector3(0f, 0.7f, 0.2f);
            var stCol = sitTrigger.AddComponent<Collider>();
            stCol.Shape = ColliderShape.Box; stCol.Size = new Vector3(2f, 0.6f, 0.5f); stCol.IsTrigger = true;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "SittableFurniture";
            script.SetField("SeatCount",  3);
            script.SetField("SitHeight",  0.52f);
            script.SetField("SitDepth",   0.25f);

            return root;
        }

        // ── Dining Table ──────────────────────────────────────
        /// <summary>
        /// Wooden dining table with four legs.
        /// </summary>
        public static GameObject DiningTable()
        {
            var root = new GameObject("Household_DiningTable");
            root.Tag = "Furniture";

            // Table top
            var top = new GameObject("TableTop");
            top.Parent = root;
            var tMr = top.AddComponent<MeshRenderer>();
            tMr.Mesh     = Mesh.CreateCube(new Vector3(2f, 0.08f, 1f));
            tMr.Material = HouseMaterials.WoodOak;
            tMr.CastShadows = true; tMr.ReceiveShadows = true;
            top.AddComponent<Collider>().Shape = ColliderShape.Box;
            top.Transform.LocalPosition = new Vector3(0f, 0.78f, 0f);

            // Legs (4)
            float[] lx = { -0.9f, 0.9f, -0.9f, 0.9f };
            float[] lz = { -0.42f, -0.42f, 0.42f, 0.42f };
            for (int i = 0; i < 4; i++)
            {
                var leg = new GameObject($"Leg_{i}");
                leg.Parent = root;
                leg.Transform.LocalPosition = new Vector3(lx[i], 0.37f, lz[i]);
                var lMr = leg.AddComponent<MeshRenderer>();
                lMr.Mesh     = Mesh.CreateCylinder(0.05f, 0.74f);
                lMr.Material = HouseMaterials.WoodOak;
            }

            root.AddComponent<Collider>().Shape = ColliderShape.Box;
            return root;
        }

        // ── Chair ─────────────────────────────────────────────
        /// <summary>
        /// Wooden chair, sittable via trigger.
        /// </summary>
        public static GameObject Chair()
        {
            var root = new GameObject("Household_Chair");
            root.Tag = "Furniture";

            // Seat
            var seat = new GameObject("Seat");
            seat.Parent = root;
            seat.Transform.LocalPosition = new Vector3(0f, 0.45f, 0f);
            var sMr = seat.AddComponent<MeshRenderer>();
            sMr.Mesh     = Mesh.CreateCube(new Vector3(0.5f, 0.06f, 0.5f));
            sMr.Material = HouseMaterials.WoodOak;
            seat.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Back
            var back = new GameObject("BackRest");
            back.Parent = root;
            back.Transform.LocalPosition = new Vector3(0f, 0.75f, -0.22f);
            var bMr = back.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(0.5f, 0.55f, 0.05f));
            bMr.Material = HouseMaterials.WoodOak;

            // Legs (4)
            float[] cx = { -0.2f, 0.2f, -0.2f, 0.2f };
            float[] cz = { -0.2f, -0.2f, 0.2f, 0.2f };
            for (int i = 0; i < 4; i++)
            {
                var leg = new GameObject($"Leg_{i}");
                leg.Parent = root;
                leg.Transform.LocalPosition = new Vector3(cx[i], 0.21f, cz[i]);
                var lMr = leg.AddComponent<MeshRenderer>();
                lMr.Mesh     = Mesh.CreateCylinder(0.025f, 0.42f);
                lMr.Material = HouseMaterials.WoodOak;
            }

            var sitTrigger = new GameObject("SitTrigger");
            sitTrigger.Parent = root;
            sitTrigger.Transform.LocalPosition = new Vector3(0f, 0.55f, 0.1f);
            var stCol = sitTrigger.AddComponent<Collider>();
            stCol.Shape = ColliderShape.Box; stCol.Size = new Vector3(0.5f, 0.4f, 0.5f); stCol.IsTrigger = true;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "SittableFurniture";
            script.SetField("SeatCount",  1);
            script.SetField("SitHeight",  0.45f);

            return root;
        }

        // ── Bed ───────────────────────────────────────────────
        /// <summary>
        /// Single bed with pillow and duvet cloth-sim.
        /// Player can sleep to fast-forward time and restore HP.
        /// </summary>
        public static GameObject Bed()
        {
            var root = new GameObject("Household_Bed");
            root.Tag = "Furniture";

            // Frame
            var frame = new GameObject("BedFrame");
            frame.Parent = root;
            var fMr = frame.AddComponent<MeshRenderer>();
            fMr.Mesh     = Mesh.CreateCube(new Vector3(1.1f, 0.35f, 2.1f));
            fMr.Material = HouseMaterials.WoodDark;
            fMr.CastShadows = true; fMr.ReceiveShadows = true;
            frame.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Headboard
            var headboard = new GameObject("Headboard");
            headboard.Parent = root;
            headboard.Transform.LocalPosition = new Vector3(0f, 0.55f, -0.98f);
            var hMr = headboard.AddComponent<MeshRenderer>();
            hMr.Mesh     = Mesh.CreateCube(new Vector3(1.1f, 0.65f, 0.1f));
            hMr.Material = HouseMaterials.WoodDark;

            // Mattress
            var mattress = new GameObject("Mattress");
            mattress.Parent = root;
            mattress.Transform.LocalPosition = new Vector3(0f, 0.42f, 0f);
            var mMr = mattress.AddComponent<MeshRenderer>();
            mMr.Mesh     = Mesh.CreateCube(new Vector3(1.0f, 0.2f, 1.95f));
            mMr.Material = HouseMaterials.BedsheetWhite;

            // Duvet (cloth-sim)
            var duvet = new GameObject("Duvet");
            duvet.Parent = root;
            duvet.Transform.LocalPosition = new Vector3(0f, 0.54f, 0.2f);
            var dMr = duvet.AddComponent<MeshRenderer>();
            dMr.Mesh     = Mesh.CreateCube(new Vector3(1.0f, 0.12f, 1.6f));
            dMr.Material = HouseMaterials.DuvetBlue;
            duvet.AddComponent<ClothPhysics>().Stiffness = 0.85f;

            // Pillows
            for (int i = 0; i < 2; i++)
            {
                var pillow = new GameObject($"Pillow_{i}");
                pillow.Parent = root;
                pillow.Transform.LocalPosition = new Vector3(-0.22f + i * 0.44f, 0.54f, -0.78f);
                var pMr = pillow.AddComponent<MeshRenderer>();
                pMr.Mesh     = Mesh.CreateCube(new Vector3(0.4f, 0.1f, 0.28f));
                pMr.Material = HouseMaterials.PillowCream;
            }

            // Sleep trigger
            var sleepTrigger = new GameObject("SleepTrigger");
            sleepTrigger.Parent = root;
            var sCol = sleepTrigger.AddComponent<Collider>();
            sCol.Shape = ColliderShape.Box; sCol.Size = new Vector3(1.1f, 0.8f, 2.1f); sCol.IsTrigger = true;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "BedInteraction";
            script.SetField("SleepHoursSkip",  8f);
            script.SetField("HPRestoreOnSleep", 100f);

            return root;
        }

        // ── Bookshelf ─────────────────────────────────────────
        /// <summary>
        /// Tall bookshelf with procedurally coloured book spines.
        /// Individual books can be pulled as pickups.
        /// </summary>
        public static GameObject Bookshelf()
        {
            var root = new GameObject("Household_Bookshelf");
            root.Tag = "Furniture";

            // Main carcass
            var carcass = new GameObject("Carcass");
            carcass.Parent = root;
            var cMr = carcass.AddComponent<MeshRenderer>();
            cMr.Mesh     = Mesh.CreateCube(new Vector3(1.0f, 2.2f, 0.3f));
            cMr.Material = HouseMaterials.WoodOak;
            carcass.AddComponent<Collider>().Shape = ColliderShape.Box;

            // 4 shelves of books
            Color[] spineColors = {
                new Color(0.7f, 0.15f, 0.15f), new Color(0.15f, 0.35f, 0.7f),
                new Color(0.2f, 0.6f, 0.25f),  new Color(0.6f, 0.55f, 0.15f),
                new Color(0.5f, 0.2f, 0.6f),   new Color(0.7f, 0.35f, 0.1f),
            };

            for (int shelf = 0; shelf < 4; shelf++)
            {
                float y = 0.28f + shelf * 0.5f;
                int booksOnShelf = 6;
                for (int b = 0; b < booksOnShelf; b++)
                {
                    var book = new GameObject($"Book_S{shelf}_B{b}");
                    book.Parent = root;
                    book.Transform.LocalPosition = new Vector3(-0.4f + b * 0.14f, y, 0f);
                    var bookMr = book.AddComponent<MeshRenderer>();
                    bookMr.Mesh     = Mesh.CreateCube(new Vector3(0.12f, 0.28f + (b % 3) * 0.04f, 0.15f));
                    bookMr.Material = Make(spineColors[b % spineColors.Length]);
                }
            }

            return root;
        }

        // ── Fireplace ─────────────────────────────────────────
        /// <summary>
        /// Stone fireplace with crackling fire VFX, warm light
        /// glow and ambient heat audio. Damages on direct contact.
        /// </summary>
        public static GameObject Fireplace()
        {
            var root = new GameObject("Household_Fireplace");
            root.Tag = "Furniture";

            // Stone surround
            var surround = new GameObject("Surround");
            surround.Parent = root;
            var sMr = surround.AddComponent<MeshRenderer>();
            sMr.Mesh     = "builtin:mesh/fireplace_surround";
            sMr.Material = HouseMaterials.Stone;
            surround.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Fire particles
            var fire = new GameObject("Fire");
            fire.Parent = root;
            fire.Transform.LocalPosition = new Vector3(0f, 0.25f, 0f);
            var pe = fire.AddComponent<ParticleEmitter>();
            pe.Rate = 25f; pe.LifetimeMin = 0.4f; pe.LifetimeMax = 0.9f;
            pe.SpeedMin = 0.3f; pe.SpeedMax = 1.2f;
            pe.SizeMin = 0.1f; pe.SizeMax = 0.3f;
            pe.ColorStart = new Color(1f, 0.55f, 0.05f); pe.ColorEnd = new Color(0.9f, 0.05f, 0f, 0f);
            pe.Shape = EmissionShapeType.Box; pe.EmissionBox = new Vector3(0.4f, 0.05f, 0.25f);

            // Embers
            var embers = new GameObject("Embers");
            embers.Parent = root;
            embers.Transform.LocalPosition = new Vector3(0f, 0.2f, 0f);
            var ep = embers.AddComponent<ParticleEmitter>();
            ep.Rate = 5f; ep.LifetimeMin = 1f; ep.LifetimeMax = 2.5f;
            ep.SpeedMin = 0.2f; ep.SpeedMax = 0.6f;
            ep.SizeMin = 0.01f; ep.SizeMax = 0.04f;
            ep.ColorStart = new Color(1f, 0.5f, 0.1f, 0.9f); ep.ColorEnd = new Color(0.3f, 0.1f, 0f, 0f);

            // Warm light (flickers)
            var glow = new GameObject("FireGlow");
            glow.Parent = root;
            glow.Transform.LocalPosition = new Vector3(0f, 0.4f, 0.2f);
            var light = glow.AddComponent<Light>();
            light.Type = LightType.Point; light.Color = new Color(1f, 0.6f, 0.2f);
            light.Intensity = 3f; light.Range = 8f;

            // Damage trigger (touching fire hurts)
            var burnZone = new GameObject("BurnZone");
            burnZone.Parent = root;
            burnZone.Transform.LocalPosition = new Vector3(0f, 0.3f, 0f);
            var bCol = burnZone.AddComponent<Collider>();
            bCol.Shape = ColliderShape.Box; bCol.Size = new Vector3(0.45f, 0.4f, 0.3f); bCol.IsTrigger = true;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/fire_crackle"; audio.Loop = true; audio.PlayOnAwake = true;
            audio.Volume = 0.45f; audio.SpatialBlend = 1f; audio.MaxDistance = 10f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "FlickerLight";
            script.SetField("BaseIntensity",    3f);
            script.SetField("FlickerAmount",    0.7f);
            script.SetField("FlickerSpeed",     5f);
            script.SetField("FlameLight",       light);
            script.SetField("BurnDamagePerSec", 10f);
            script.SetField("BurnZone",         burnZone);

            return root;
        }

        // ── Floor Lamp ────────────────────────────────────────
        /// <summary>
        /// Standing floor lamp with fabric shade and warm point light.
        /// Clickable toggle switch on the base.
        /// </summary>
        public static GameObject FloorLamp()
        {
            var root = new GameObject("Household_FloorLamp");
            root.Tag = "Furniture";

            // Pole
            var pole = new GameObject("Pole");
            pole.Parent = root;
            var pMr = pole.AddComponent<MeshRenderer>();
            pMr.Mesh     = Mesh.CreateCylinder(0.025f, 1.4f);
            pMr.Material = HouseMaterials.MetalBrass;
            pole.AddComponent<Collider>().Shape = ColliderShape.Capsule;

            // Shade
            var shade = new GameObject("Shade");
            shade.Parent = root;
            shade.Transform.LocalPosition = new Vector3(0f, 1.5f, 0f);
            var shMr = shade.AddComponent<MeshRenderer>();
            shMr.Mesh     = Mesh.CreateCone(0.25f, 0.35f, 10);
            shMr.Material = HouseMaterials.LampShadeCream;

            // Base
            var baseObj = new GameObject("Base");
            baseObj.Parent = root;
            baseObj.Transform.LocalPosition = new Vector3(0f, 0.06f, 0f);
            var baseMr = baseObj.AddComponent<MeshRenderer>();
            baseMr.Mesh     = Mesh.CreateCylinder(0.15f, 0.12f, 10);
            baseMr.Material = HouseMaterials.MetalBrass;

            // Light source
            var lightObj = new GameObject("LampLight");
            lightObj.Parent = root;
            lightObj.Transform.LocalPosition = new Vector3(0f, 1.38f, 0f);
            var light = lightObj.AddComponent<Light>();
            light.Type = LightType.Point; light.Color = new Color(1f, 0.85f, 0.55f);
            light.Intensity = 2.5f; light.Range = 8f;

            // Interaction trigger
            var trigger = new GameObject("SwitchTrigger");
            trigger.Parent = root;
            var tCol = trigger.AddComponent<Collider>();
            tCol.Shape = ColliderShape.Sphere; tCol.Radius = 1.5f; tCol.IsTrigger = true;

            var audio = root.AddComponent<AudioSource>();
            audio.Clip = "builtin:audio/lamp_click"; audio.Volume = 0.5f; audio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "ToggleLamp";
            script.SetField("LampLight",  light);
            script.SetField("OnByDefault",true);
            script.SetField("Audio",      audio);

            return root;
        }

        // ── Refrigerator ──────────────────────────────────────
        /// <summary>
        /// Kitchen refrigerator. Door swings open, cold fog VFX
        /// spills out, contains food item loot table.
        /// </summary>
        public static GameObject Refrigerator()
        {
            var root = new GameObject("Household_Refrigerator");
            root.Tag = "Furniture";

            // Body
            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(0.75f, 1.8f, 0.7f));
            bMr.Material = HouseMaterials.ApplianceWhite;
            bMr.CastShadows = true;
            body.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Door (swings open around Y axis)
            var door = new GameObject("FridgeDoor");
            door.Parent = root;
            door.Transform.LocalPosition = new Vector3(0.375f, 0f, 0f);   // Hinged at right edge
            var dMr = door.AddComponent<MeshRenderer>();
            dMr.Mesh     = Mesh.CreateCube(new Vector3(0.06f, 1.8f, 0.7f));
            dMr.Material = HouseMaterials.ApplianceWhite;

            // Cold fog VFX (enabled on door open)
            var fog = new GameObject("ColdFog");
            fog.Parent = root;
            fog.Transform.LocalPosition = new Vector3(0f, 0.5f, 0.4f);
            var fogPe = fog.AddComponent<ParticleEmitter>();
            fogPe.Rate = 12f; fogPe.LifetimeMin = 0.5f; fogPe.LifetimeMax = 1.5f;
            fogPe.SpeedMin = 0.1f; fogPe.SpeedMax = 0.5f;
            fogPe.SizeMin = 0.1f; fogPe.SizeMax = 0.4f;
            fogPe.ColorStart = new Color(0.8f, 0.9f, 1f, 0.4f); fogPe.ColorEnd = new Color(0.9f, 1f, 1f, 0f);
            fog.SetActive(false);

            // Interior light (on when door open)
            var intLight = new GameObject("InteriorLight");
            intLight.Parent = root;
            intLight.Transform.LocalPosition = new Vector3(0f, 0.6f, 0f);
            var l = intLight.AddComponent<Light>();
            l.Type = LightType.Point; l.Color = new Color(0.8f, 0.95f, 1f);
            l.Intensity = 0f; l.Range = 1.5f;

            var openAudio = root.AddComponent<AudioSource>();
            openAudio.Clip = "builtin:audio/fridge_open"; openAudio.Volume = 0.6f; openAudio.SpatialBlend = 1f;
            var humAudio = root.AddComponent<AudioSource>();
            humAudio.Clip = "builtin:audio/fridge_hum"; humAudio.Loop = true; humAudio.PlayOnAwake = true;
            humAudio.Volume = 0.1f; humAudio.SpatialBlend = 1f; humAudio.MaxDistance = 5f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "FridgeInteraction";
            script.SetField("FoodLootTable",  "builtin:loot/kitchen_food");
            script.SetField("DoorObj",        door);
            script.SetField("ColdFog",        fog);
            script.SetField("IntLight",       l);
            script.SetField("OpenAudio",      openAudio);

            return root;
        }

        // ── Bathtub ───────────────────────────────────────────
        /// <summary>
        /// Clawfoot bathtub. Can be filled with water (particle
        /// fill effect), player stepping in restores HP over time.
        /// </summary>
        public static GameObject Bathtub()
        {
            var root = new GameObject("Household_Bathtub");
            root.Tag = "Furniture";

            // Tub body
            var tub = new GameObject("Tub");
            tub.Parent = root;
            var tMr = tub.AddComponent<MeshRenderer>();
            tMr.Mesh     = "builtin:mesh/bathtub";
            tMr.Material = HouseMaterials.Porcelain;
            tMr.CastShadows = true;
            tub.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Water fill (animated plane that rises)
            var waterFill = new GameObject("WaterFill");
            waterFill.Parent = root;
            waterFill.Transform.LocalPosition = new Vector3(0f, 0.3f, 0f);
            var wMr = waterFill.AddComponent<MeshRenderer>();
            wMr.Mesh     = Mesh.CreatePlane(0.65f, 1.5f);
            wMr.Material = HouseMaterials.BathWater;
            waterFill.SetActive(false);

            // Drain trigger
            var sitTrigger = new GameObject("BathTrigger");
            sitTrigger.Parent = root;
            var stCol = sitTrigger.AddComponent<Collider>();
            stCol.Shape = ColliderShape.Box; stCol.Size = new Vector3(0.7f, 0.5f, 1.55f); stCol.IsTrigger = true;

            var tapAudio = root.AddComponent<AudioSource>();
            tapAudio.Clip = "builtin:audio/bath_running"; tapAudio.SpatialBlend = 1f; tapAudio.MaxDistance = 6f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "BathInteraction";
            script.SetField("FillTime",       5f);
            script.SetField("HPRegenRate",    5f);
            script.SetField("WaterObj",       waterFill);
            script.SetField("TapAudio",       tapAudio);

            return root;
        }

        // ── Wardrobe ──────────────────────────────────────────
        /// <summary>
        /// Double-door wardrobe. Doors swing open, contains
        /// costume/outfit selection menu on interact.
        /// </summary>
        public static GameObject Wardrobe()
        {
            var root = new GameObject("Household_Wardrobe");
            root.Tag = "Furniture";

            // Carcass
            var body = new GameObject("Body");
            body.Parent = root;
            var bMr = body.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(1.4f, 2.0f, 0.6f));
            bMr.Material = HouseMaterials.WoodDark;
            bMr.CastShadows = true;
            body.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Left door
            var doorL = new GameObject("DoorL");
            doorL.Parent = root;
            doorL.Transform.LocalPosition = new Vector3(-0.35f, 0f, 0.31f);
            var dlMr = doorL.AddComponent<MeshRenderer>();
            dlMr.Mesh     = Mesh.CreateCube(new Vector3(0.68f, 1.95f, 0.04f));
            dlMr.Material = HouseMaterials.WoodDark;

            // Right door
            var doorR = new GameObject("DoorR");
            doorR.Parent = root;
            doorR.Transform.LocalPosition = new Vector3(0.35f, 0f, 0.31f);
            var drMr = doorR.AddComponent<MeshRenderer>();
            drMr.Mesh     = Mesh.CreateCube(new Vector3(0.68f, 1.95f, 0.04f));
            drMr.Material = HouseMaterials.WoodDark;

            // Handles
            foreach (var (x, name) in new[] { (-0.04f, "HandleL"), (0.04f, "HandleR") })
            {
                var handle = new GameObject(name);
                handle.Parent = root;
                handle.Transform.LocalPosition = new Vector3(x, 0f, 0.34f);
                var hMr = handle.AddComponent<MeshRenderer>();
                hMr.Mesh     = Mesh.CreateSphere(0.025f);
                hMr.Material = HouseMaterials.MetalBrass;
            }

            var openAudio = root.AddComponent<AudioSource>();
            openAudio.Clip = "builtin:audio/wardrobe_open"; openAudio.Volume = 0.5f; openAudio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "WardrobeInteraction";
            script.SetField("CostumeMenu",   "builtin:ui/costume_select");
            script.SetField("DoorL",         doorL);
            script.SetField("DoorR",         doorR);
            script.SetField("OpenAudio",     openAudio);

            return root;
        }

        // ── Shared material helper ────────────────────────────
        private static Material Make(Color color)
            => new Material { Albedo = color, Metallic = 0f, Roughness = 0.8f };
    }
}
