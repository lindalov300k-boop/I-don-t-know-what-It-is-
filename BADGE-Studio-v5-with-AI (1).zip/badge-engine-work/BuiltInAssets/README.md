# BADGE Studio – Built-In Assets

Competition-ready game objects auto-discovered and registered via `BuiltInCatalog`.

## Categories & Prefabs

| Category    | Prefabs |
|-------------|---------|
| **Players** | FPS Player, Platformer Hero, Top-Down Hero, Vehicle Driver |
| **Enemies** | Grunt, Archer, Flying Drone, Boss Knight, Crawler |
| **Weapons** | Pistol, Shotgun, Assault Rifle, Sword, Bow, Grenade |
| **Pickups** | Health Pack, Ammo Crate, Coin, Key, Speed Boost, Shield Orb, Checkpoint |
| **Environment** | Wooden Crate, Explosive Barrel, Oak Tree, Large Rock, Moving Platform, Sliding Door, Treasure Chest, Rope Bridge, Water Surface |
| **Traps** | Spike Trap, Pendulum Blade, Laser Grid, Rolling Boulder, Lava Floor |
| **Vehicles** | Arcade Car, Helicopter, Speed Boat, Tank |
| **VFX** | Explosion, Sparks, Smoke Loop, Magic Portal, Blood Hit, Level Up Burst |
| **Lighting** | Torch, Street Lamp, Spotlight Rig, Lava Glow |
| **UI** | World Health Bar, Damage Number, Quest Marker, Interaction Prompt |

**Total: 46 prefabs** across 10 categories.

## Usage

```csharp
// Instantiate by ID
var player = BuiltInCatalog.All()
    .First(p => p.Id == "player_fps")
    .Instantiate();

// Or use factory directly
var enemy = EnemyPrefabs.BossKnight();
scene.AddGameObject(enemy);

// Browse a category
foreach (var prefab in BuiltInCatalog.Category("Weapons"))
    Console.WriteLine($"{prefab.Name} – {prefab.Description}");
```

## Source Files

```
BuiltInAssets/
├── BuiltInAssets.cs          Master catalog & BuiltInPrefab descriptor
├── Shared.cs                 Layer indices, Materials, PhysicsMaterials
├── Players/PlayerPrefabs.cs
├── Enemies/EnemyPrefabs.cs
├── Weapons/WeaponPrefabs.cs
├── Pickups/PickupPrefabs.cs
├── Environment/EnvironmentPrefabs.cs
├── Traps/TrapPrefabs.cs
├── Vehicles/VehiclePrefabs.cs
├── VFX/VFXPrefabs.cs
├── Lighting/LightingPrefabs.cs
└── UI/UIPrefabs.cs
```
