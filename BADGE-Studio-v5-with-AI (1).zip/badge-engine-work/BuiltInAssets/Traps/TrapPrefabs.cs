// ============================================================
//  BADGE Engine – BuiltInAssets/Traps/TrapPrefabs.cs
//  Competition-ready hazard / trap game-object factories.
// ============================================================
using System;
using BADGE.Engine.Components;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;
using BADGE.Engine.Scripting;

namespace BADGE.BuiltInAssets.Traps
{
    public static class TrapPrefabs
    {
        // ── Spike Trap ────────────────────────────────────────
        /// <summary>
        /// Floor spike panel with retract/extend cycle.
        /// Audible click warning 0.5 s before extending.
        /// Damage zone is trigger enabled only while spikes are out.
        /// </summary>
        public static GameObject SpikeTrap()
        {
            var root = new GameObject("Trap_SpikeTrap");
            root.Tag = "Trap";

            // Base plate
            var basePlate = new GameObject("BasePlate");
            basePlate.Parent = root;
            var bMr = basePlate.AddComponent<MeshRenderer>();
            bMr.Mesh     = Mesh.CreateCube(new Vector3(2f, 0.1f, 2f));
            bMr.Material = Materials.TrapStone;
            basePlate.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Spikes mesh (translates up on extend)
            var spikes = new GameObject("Spikes");
            spikes.Parent = root;
            spikes.Transform.LocalPosition = new Vector3(0f, -0.1f, 0f);
            var sMr = spikes.AddComponent<MeshRenderer>();
            sMr.Mesh     = "builtin:mesh/spike_cluster";
            sMr.Material = Materials.TrapMetal;

            // Damage trigger child (active only while extended)
            var damageZone = new GameObject("DamageZone");
            damageZone.Parent = root;
            var dCol = damageZone.AddComponent<Collider>();
            dCol.Shape = ColliderShape.Box;
            dCol.Size  = new Vector3(2f, 0.7f, 2f);
            dCol.IsTrigger = true;
            damageZone.SetActive(false);

            // Warning light (flashes before extend)
            var warnLight = new GameObject("WarnLight");
            warnLight.Parent = root;
            var light = warnLight.AddComponent<Light>();
            light.Type = LightType.Point; light.Color = new Color(1f, 0.4f, 0f);
            light.Intensity = 0f; light.Range = 2f;

            var extendAudio = root.AddComponent<AudioSource>();
            extendAudio.Clip = "builtin:audio/spike_extend"; extendAudio.Volume = 0.8f; extendAudio.SpatialBlend = 1f;
            var retractAudio = root.AddComponent<AudioSource>();
            retractAudio.Clip = "builtin:audio/spike_retract"; retractAudio.Volume = 0.6f; retractAudio.SpatialBlend = 1f;
            var clickAudio = root.AddComponent<AudioSource>();
            clickAudio.Clip = "builtin:audio/trap_click"; clickAudio.Volume = 0.7f; clickAudio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "SpikeTrapController";
            script.SetField("Damage",         35f);
            script.SetField("ExtendedTime",   1.2f);
            script.SetField("RetractedTime",  2.0f);
            script.SetField("WarnTime",       0.5f);
            script.SetField("ExtendSpeed",    8f);
            script.SetField("ExtendHeight",   0.55f);
            script.SetField("SpikesObj",      spikes);
            script.SetField("DamageZone",     damageZone);
            script.SetField("WarnLight",      light);
            script.SetField("ExtendAudio",    extendAudio);
            script.SetField("RetractAudio",   retractAudio);
            script.SetField("ClickAudio",     clickAudio);

            return root;
        }

        // ── Pendulum Blade ────────────────────────────────────
        /// <summary>
        /// Swinging axe blade on a chain pivot.
        /// Physics-driven pendulum arc with decal-slice trail.
        /// Arc speed and angle are configurable.
        /// </summary>
        public static GameObject PendulumBlade()
        {
            var root = new GameObject("Trap_PendulumBlade");
            root.Tag = "Trap";

            // Ceiling anchor (static)
            var anchor = new GameObject("Anchor");
            anchor.Parent = root;
            var anchorMr = anchor.AddComponent<MeshRenderer>();
            anchorMr.Mesh     = Mesh.CreateCube(0.3f);
            anchorMr.Material = Materials.TrapMetal;
            anchor.AddComponent<Collider>().Shape = ColliderShape.Box;

            // Chain visual (LineRenderer)
            var chain = new GameObject("Chain");
            chain.Parent = root;
            var lr = chain.AddComponent<LineRenderer>();
            lr.Width    = 0.06f;
            lr.Color    = new Color(0.45f, 0.45f, 0.45f);
            lr.Material = Materials.TrapMetal;

            // Blade child (swings)
            var blade = new GameObject("Blade");
            blade.Parent = root;
            blade.Transform.LocalPosition = new Vector3(0f, -3f, 0f);
            var bladeMr = blade.AddComponent<MeshRenderer>();
            bladeMr.Mesh     = "builtin:mesh/axe_blade";
            bladeMr.Material = Materials.TrapMetal;

            var bladeCol = blade.AddComponent<Collider>();
            bladeCol.Shape     = ColliderShape.Box;
            bladeCol.Size      = new Vector3(1.2f, 0.8f, 0.15f);
            bladeCol.IsTrigger = true;

            // Swing trail
            var trail = blade.AddComponent<LineRenderer>();
            trail.Width    = 0.04f;
            trail.Color    = new Color(0.9f, 0.9f, 0.9f, 0.5f);
            trail.Material = Materials.SwordTrail;

            var swingAudio = root.AddComponent<AudioSource>();
            swingAudio.Clip = "builtin:audio/pendulum_whoosh"; swingAudio.Loop = true;
            swingAudio.Volume = 0.5f; swingAudio.SpatialBlend = 1f; swingAudio.MaxDistance = 25f;
            swingAudio.PlayOnAwake = true;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "PendulumBladeTrap";
            script.SetField("Damage",        60f);
            script.SetField("ArmLength",     3f);
            script.SetField("SwingAngle",    75f);
            script.SetField("SwingPeriod",   2.2f);
            script.SetField("ChainObj",      chain);
            script.SetField("BladeObj",      blade);
            script.SetField("SwingAudio",    swingAudio);

            return root;
        }

        // ── Laser Grid ────────────────────────────────────────
        /// <summary>
        /// Emitter/receiver laser beam pair.
        /// Timed blink pattern or tripwire mode (constant on,
        /// trigger alarm + damage when crossed).
        /// </summary>
        public static GameObject LaserGrid()
        {
            var root = new GameObject("Trap_LaserGrid");
            root.Tag = "Trap";

            // Emitter box
            var emitter = new GameObject("Emitter");
            emitter.Parent = root;
            emitter.Transform.LocalPosition = new Vector3(-3f, 0f, 0f);
            var eMr = emitter.AddComponent<MeshRenderer>();
            eMr.Mesh     = Mesh.CreateCube(0.2f);
            eMr.Material = Materials.LaserEmitter;

            var eLight = emitter.AddComponent<Light>();
            eLight.Type = LightType.Point; eLight.Color = new Color(1f, 0.1f, 0.1f);
            eLight.Intensity = 1.5f; eLight.Range = 1f;

            // Receiver box
            var receiver = new GameObject("Receiver");
            receiver.Parent = root;
            receiver.Transform.LocalPosition = new Vector3(3f, 0f, 0f);
            var rMr = receiver.AddComponent<MeshRenderer>();
            rMr.Mesh     = Mesh.CreateCube(0.2f);
            rMr.Material = Materials.LaserEmitter;

            // Laser beam (LineRenderer between emitter and receiver)
            var beam = new GameObject("LaserBeam");
            beam.Parent = root;
            var beamLr = beam.AddComponent<LineRenderer>();
            beamLr.Width    = 0.04f;
            beamLr.Color    = new Color(1f, 0.08f, 0.08f, 0.85f);
            beamLr.Material = Materials.LaserBeam;

            // Damage trigger (thin capsule along beam)
            var beamCol = beam.AddComponent<Collider>();
            beamCol.Shape     = ColliderShape.Capsule;
            beamCol.Radius    = 0.04f;
            beamCol.IsTrigger = true;

            var onAudio = root.AddComponent<AudioSource>();
            onAudio.Clip = "builtin:audio/laser_hum"; onAudio.Loop = true;
            onAudio.Volume = 0.3f; onAudio.SpatialBlend = 1f; onAudio.PlayOnAwake = true;

            var alarmAudio = root.AddComponent<AudioSource>();
            alarmAudio.Clip = "builtin:audio/laser_alarm"; alarmAudio.Volume = 0.9f; alarmAudio.SpatialBlend = 1f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "LaserGridController";
            script.SetField("Mode",           "Timed");   // Timed | Tripwire
            script.SetField("Damage",         20f);        // Damage per second
            script.SetField("OnTime",         1.5f);
            script.SetField("OffTime",        0.8f);
            script.SetField("AlarmDuration",  3f);
            script.SetField("EmitterObj",     emitter);
            script.SetField("ReceiverObj",    receiver);
            script.SetField("BeamObj",        beam);
            script.SetField("HumAudio",       onAudio);
            script.SetField("AlarmAudio",     alarmAudio);

            return root;
        }

        // ── Rolling Boulder ───────────────────────────────────
        /// <summary>
        /// Classic trigger-released rolling boulder.  Knocks back
        /// and damages anything in its path.  Camera shake on impact
        /// with walls.  Explodes into rubble debris on final stop.
        /// </summary>
        public static GameObject RollingBoulder()
        {
            var root = new GameObject("Trap_RollingBoulder");
            root.Tag = "Trap";

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreateSphere(0.9f, 12, 14);
            mr.Material = Materials.Rock;
            mr.CastShadows = true;

            var col = root.AddComponent<Collider>();
            col.Shape  = ColliderShape.Sphere;
            col.Radius = 0.9f;

            var rb = root.AddComponent<Rigidbody>();
            rb.Mass     = 500f;
            rb.Drag     = 0.05f;
            rb.UseGravity = true;

            // Damage trigger (same sphere, separate trigger layer)
            var damage = new GameObject("DamageTrigger");
            damage.Parent = root;
            var dCol = damage.AddComponent<Collider>();
            dCol.Shape = ColliderShape.Sphere; dCol.Radius = 0.9f; dCol.IsTrigger = true;

            var rollAudio = root.AddComponent<AudioSource>();
            rollAudio.Clip = "builtin:audio/boulder_roll"; rollAudio.Loop = true;
            rollAudio.Volume = 0f; rollAudio.SpatialBlend = 1f; rollAudio.MaxDistance = 50f;

            var impactAudio = root.AddComponent<AudioSource>();
            impactAudio.Clip = "builtin:audio/boulder_impact"; impactAudio.Volume = 1f; impactAudio.SpatialBlend = 1f; impactAudio.MaxDistance = 60f;

            // Release trigger child (at boulder starting position)
            var releaseTrigger = new GameObject("ReleaseTrigger");
            releaseTrigger.Parent = root;
            var rtCol = releaseTrigger.AddComponent<Collider>();
            rtCol.Shape = ColliderShape.Box; rtCol.Size = new Vector3(3f, 3f, 1f); rtCol.IsTrigger = true;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "RollingBoulderTrap";
            script.SetField("Damage",          80f);
            script.SetField("KnockbackForce",  30f);
            script.SetField("CameraShake",     0.9f);
            script.SetField("ShakeDuration",   0.5f);
            script.SetField("DebrisCount",     12);
            script.SetField("DamageTrigger",   damage);
            script.SetField("ReleaseTrigger",  releaseTrigger);
            script.SetField("RollAudio",       rollAudio);
            script.SetField("ImpactAudio",     impactAudio);

            return root;
        }

        // ── Lava Floor ────────────────────────────────────────
        /// <summary>
        /// Animated lava tile.  Heat distortion shader, pulsing
        /// orange point light, burn DoT (15 damage/sec).
        /// Lava bubbles VFX particle emitter.
        /// </summary>
        public static GameObject LavaFloor()
        {
            var root = new GameObject("Trap_LavaFloor");
            root.Tag = "Hazard";

            var mr = root.AddComponent<MeshRenderer>();
            mr.Mesh     = Mesh.CreatePlane(4f, 4f, 4, 4);
            mr.Material = Materials.Lava;
            mr.CastShadows = false;

            // Damage trigger
            var trigger = new GameObject("BurnTrigger");
            trigger.Parent = root;
            trigger.Transform.LocalPosition = new Vector3(0f, 0.15f, 0f);
            var tCol = trigger.AddComponent<Collider>();
            tCol.Shape     = ColliderShape.Box;
            tCol.Size      = new Vector3(4f, 0.3f, 4f);
            tCol.IsTrigger = true;

            // Pulsing heat glow
            var glow = new GameObject("HeatGlow");
            glow.Parent = root;
            var light = glow.AddComponent<Light>();
            light.Type      = LightType.Point;
            light.Color     = new Color(1f, 0.35f, 0.05f);
            light.Intensity = 3f;
            light.Range     = 6f;

            // Bubble particles
            var bubbles = new GameObject("LavaBubbles");
            bubbles.Parent = root;
            bubbles.Transform.LocalPosition = new Vector3(0f, 0.05f, 0f);
            var pe = bubbles.AddComponent<ParticleEmitter>();
            pe.Rate        = 8f;
            pe.LifetimeMin = 0.5f; pe.LifetimeMax = 1.2f;
            pe.SpeedMin    = 0.3f; pe.SpeedMax    = 1f;
            pe.SizeMin     = 0.05f; pe.SizeMax    = 0.2f;
            pe.ColorStart  = new Color(1f, 0.4f, 0.1f);
            pe.ColorEnd    = new Color(0.2f, 0.0f, 0.0f, 0f);
            pe.Shape       = EmissionShapeType.Box;
            pe.EmissionBox = new Vector3(4f, 0.01f, 4f);

            var ambientAudio = root.AddComponent<AudioSource>();
            ambientAudio.Clip = "builtin:audio/lava_bubble"; ambientAudio.Loop = true;
            ambientAudio.Volume = 0.5f; ambientAudio.PlayOnAwake = true; ambientAudio.SpatialBlend = 1f; ambientAudio.MaxDistance = 20f;

            var script = root.AddComponent<ScriptBehaviour>();
            script.ScriptName = "LavaFloorHazard";
            script.SetField("DamagePerSec",    15f);
            script.SetField("KnockupForce",    4f);
            script.SetField("PulseSpeed",      0.8f);
            script.SetField("PulseMin",        2f);
            script.SetField("PulseMax",        4f);
            script.SetField("BurnTrigger",     trigger);
            script.SetField("HeatLight",       light);
            script.SetField("Audio",           ambientAudio);

            return root;
        }
    }
}
