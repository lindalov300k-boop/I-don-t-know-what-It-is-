// ============================================================
//  BADGE Engine – IdleStateSystem/IdleSystem.cs
//  Dynamic module loading/unloading, feature suspension,
//  memory release on idle, resource throttling.
//  Example: Sprite editor closed → sprite systems unload.
//           Audio editor closed → audio systems unload.
// ============================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace BADGE.Engine.Idle
{
    // ═══════════════════════════════════════════════════════
    //  Idle State Enums
    // ═══════════════════════════════════════════════════════
    public enum ModuleState  { Active, Suspended, Unloaded, Loading, Suspending }
    public enum ThrottleLevel{ Full, Reduced, Minimal, Paused }

    // ═══════════════════════════════════════════════════════
    //  Idle Module Descriptor
    // ═══════════════════════════════════════════════════════
    public sealed class IdleModule
    {
        public string        Name          { get; }
        public ModuleState   State         { get; internal set; } = ModuleState.Active;
        public ThrottleLevel Throttle      { get; internal set; } = ThrottleLevel.Full;
        public bool          IsActive      => State == ModuleState.Active;
        public bool          IsSuspended   => State == ModuleState.Suspended;
        public float         SuspendDelay  { get; set; } = 0f;   // seconds before auto-suspend
        public bool          AutoSuspend   { get; set; } = true;
        public long          MemoryReleasedBytes { get; internal set; }
        public DateTime      LastActivity  { get; internal set; } = DateTime.UtcNow;
        public int           SuspendCount  { get; internal set; }
        public string        EditorTabName { get; set; } = "";    // associated editor tab

        private readonly Action            _onLoad;
        private readonly Action            _onSuspend;
        private readonly Action            _onResume;
        private readonly Action            _onUnload;
        private readonly Func<long>?       _memReleaseFn;   // returns bytes freed
        private readonly Func<bool>?       _loadFn;         // async-compatible load gate

        public IdleModule(string name,
            Action onLoad,
            Action onSuspend,
            Action onResume,
            Action onUnload,
            Func<long>? memReleaseFn = null,
            Func<bool>? loadFn       = null)
        {
            Name          = name;
            _onLoad       = onLoad;
            _onSuspend    = onSuspend;
            _onResume     = onResume;
            _onUnload     = onUnload;
            _memReleaseFn = memReleaseFn;
            _loadFn       = loadFn;
        }

        internal void DoLoad()
        {
            State = ModuleState.Loading;
            _onLoad();
            State = ModuleState.Active;
            LastActivity = DateTime.UtcNow;
            Console.WriteLine($"[Idle] ▶ Loaded:    {Name}");
        }

        internal void DoSuspend()
        {
            State = ModuleState.Suspending;
            _onSuspend();
            if (_memReleaseFn != null) MemoryReleasedBytes += _memReleaseFn();
            State = ModuleState.Suspended;
            SuspendCount++;
            Console.WriteLine($"[Idle] ⏸ Suspended: {Name}  (mem freed: {FormatBytes(MemoryReleasedBytes)})");
        }

        internal void DoResume()
        {
            _onResume();
            State        = ModuleState.Active;
            LastActivity = DateTime.UtcNow;
            Console.WriteLine($"[Idle] ▶ Resumed:   {Name}");
        }

        internal void DoUnload()
        {
            _onUnload();
            if (_memReleaseFn != null) MemoryReleasedBytes += _memReleaseFn();
            State = ModuleState.Unloaded;
            Console.WriteLine($"[Idle] ✕ Unloaded:  {Name}");
        }

        internal bool CanLoad() => _loadFn?.Invoke() ?? true;

        private static string FormatBytes(long b) =>
            b < 1024 ? $"{b}B" : b < 1_048_576 ? $"{b/1024}KB" : $"{b/1_048_576}MB";
    }

    // ═══════════════════════════════════════════════════════
    //  Resource Throttle Profile
    // ═══════════════════════════════════════════════════════
    public sealed class ThrottleProfile
    {
        public string       Name           { get; set; } = "";
        public int          MaxFPS         { get; set; } = 60;
        public int          AudioMixRate   { get; set; } = 44100;
        public int          PhysicsHz      { get; set; } = 60;
        public bool         DisableShadows { get; set; }
        public bool         DisableVFX     { get; set; }
        public bool         DisableAI      { get; set; }
        public float        LODBias        { get; set; } = 1f;
        public int          WorkerThreads  { get; set; } = 4;

        public static readonly ThrottleProfile Full    = new() { Name="Full",    MaxFPS=240, WorkerThreads=Environment.ProcessorCount };
        public static readonly ThrottleProfile Reduced = new() { Name="Reduced", MaxFPS=30,  WorkerThreads=2, DisableVFX=true, LODBias=2f };
        public static readonly ThrottleProfile Minimal = new() { Name="Minimal", MaxFPS=10,  WorkerThreads=1, DisableVFX=true, DisableShadows=true, DisableAI=true, LODBias=4f };
        public static readonly ThrottleProfile Paused  = new() { Name="Paused",  MaxFPS=1,   WorkerThreads=0, DisableVFX=true, DisableShadows=true, DisableAI=true };
    }

    // ═══════════════════════════════════════════════════════
    //  Idle State Manager  (main entry point)
    // ═══════════════════════════════════════════════════════
    public sealed class IdleStateManager
    {
        private readonly Dictionary<string, IdleModule> _modules       = new();
        private readonly Dictionary<string, DateTime>   _tabClosedAt   = new();
        private readonly List<IdleRule>                 _rules         = new();
        private ThrottleProfile _activeThrottle = ThrottleProfile.Full;
        private bool            _engineIdle;
        private float           _idleTimer;
        private CancellationTokenSource? _cts;

        // ── Config ────────────────────────────────────────
        public float  EngineIdleTimeoutSec  { get; set; } = 30f;
        public float  ModuleSuspendDelaySec { get; set; } = 2f;
        public bool   AutoThrottleEnabled   { get; set; } = true;

        public IReadOnlyDictionary<string, IdleModule> Modules => _modules;
        public ThrottleProfile ActiveThrottle => _activeThrottle;
        public bool            IsEngineIdle   => _engineIdle;

        public event Action<IdleModule>?     OnModuleSuspended;
        public event Action<IdleModule>?     OnModuleResumed;
        public event Action<ThrottleProfile>? OnThrottleChanged;

        // ═══════════════════════════════════════════════════
        //  Module Registration
        // ═══════════════════════════════════════════════════
        public void Register(IdleModule module)
        {
            _modules[module.Name] = module;
            Console.WriteLine($"[Idle] Registered: {module.Name}");
        }

        /// <summary>Convenience overload — supply lambda callbacks directly.</summary>
        public IdleModule Register(string name,
            Action?     onLoad       = null,
            Action?     onSuspend    = null,
            Action?     onResume     = null,
            Action?     onUnload     = null,
            Func<long>? memRelease   = null,
            string      editorTab    = "",
            float       suspendDelay = -1f)
        {
            var m = new IdleModule(name,
                onLoad     ?? (() => {}),
                onSuspend  ?? (() => {}),
                onResume   ?? (() => {}),
                onUnload   ?? (() => {}),
                memRelease)
            {
                EditorTabName = editorTab,
                SuspendDelay  = suspendDelay >= 0 ? suspendDelay : ModuleSuspendDelaySec
            };
            Register(m);
            return m;
        }

        public void Unregister(string name)
        {
            if (_modules.TryGetValue(name, out var m)) { m.DoUnload(); _modules.Remove(name); }
        }

        // ═══════════════════════════════════════════════════
        //  Manual Control
        // ═══════════════════════════════════════════════════
        public void Suspend(string name)
        {
            if (_modules.TryGetValue(name, out var m) && m.IsActive)
            { m.DoSuspend(); OnModuleSuspended?.Invoke(m); }
        }

        public void Resume(string name)
        {
            if (_modules.TryGetValue(name, out var m) && m.IsSuspended && m.CanLoad())
            { m.DoResume(); OnModuleResumed?.Invoke(m); }
        }

        public void Load(string name)
        {
            if (_modules.TryGetValue(name, out var m) && m.State == ModuleState.Unloaded && m.CanLoad())
                m.DoLoad();
        }

        public void Unload(string name)
        {
            if (_modules.TryGetValue(name, out var m) && m.State != ModuleState.Unloaded)
                m.DoUnload();
        }

        public void SuspendAll()
        {
            foreach (var m in _modules.Values.Where(x => x.IsActive))
            { m.DoSuspend(); OnModuleSuspended?.Invoke(m); }
        }

        public void ResumeAll()
        {
            foreach (var m in _modules.Values.Where(x => x.IsSuspended))
            { m.DoResume(); OnModuleResumed?.Invoke(m); }
        }

        // ═══════════════════════════════════════════════════
        //  Editor Tab Integration
        //  Sprite editor closed → sprite systems unload
        //  Audio editor closed → audio systems unload
        // ═══════════════════════════════════════════════════
        public void OnEditorTabOpened(string tabName)
        {
            _tabClosedAt.Remove(tabName);
            // Resume all modules associated with this tab
            foreach (var m in _modules.Values.Where(x => x.EditorTabName == tabName))
            {
                if (m.IsSuspended) { m.DoResume(); OnModuleResumed?.Invoke(m); }
                else if (m.State == ModuleState.Unloaded && m.CanLoad()) m.DoLoad();
            }
            // Evaluate rules
            foreach (var rule in _rules.Where(r => r.TriggerTab == tabName && r.OnOpen))
                ApplyRule(rule);
        }

        public void OnEditorTabClosed(string tabName)
        {
            _tabClosedAt[tabName] = DateTime.UtcNow;
            // Modules associated with this exact tab
            foreach (var m in _modules.Values.Where(x => x.EditorTabName == tabName && x.IsActive))
            {
                if (m.SuspendDelay <= 0)
                    { m.DoSuspend(); OnModuleSuspended?.Invoke(m); }
                else
                    ScheduleSuspend(m);
            }
            // Evaluate rules
            foreach (var rule in _rules.Where(r => r.TriggerTab == tabName && !r.OnOpen))
                ApplyRule(rule);
        }

        private void ScheduleSuspend(IdleModule module)
        {
            _ = Task.Run(async () =>
            {
                await Task.Delay((int)(module.SuspendDelay * 1000));
                if (module.IsActive)
                { module.DoSuspend(); OnModuleSuspended?.Invoke(module); }
            });
        }

        // ═══════════════════════════════════════════════════
        //  Rule System
        //  Declarative: "when X tab closes, suspend Y modules"
        // ═══════════════════════════════════════════════════
        public void AddRule(IdleRule rule) => _rules.Add(rule);

        /// <summary>Quick rule builder.</summary>
        public void WhenTabCloses(string tab, params string[] suspendModules) =>
            AddRule(new IdleRule { TriggerTab = tab, OnOpen = false,
                Action = IdleRuleAction.Suspend, TargetModules = suspendModules.ToList() });

        public void WhenTabOpens(string tab, params string[] resumeModules) =>
            AddRule(new IdleRule { TriggerTab = tab, OnOpen = true,
                Action = IdleRuleAction.Resume, TargetModules = resumeModules.ToList() });

        private void ApplyRule(IdleRule rule)
        {
            foreach (var target in rule.TargetModules)
            {
                switch (rule.Action)
                {
                    case IdleRuleAction.Suspend: Suspend(target); break;
                    case IdleRuleAction.Resume:  Resume(target);  break;
                    case IdleRuleAction.Unload:  Unload(target);  break;
                    case IdleRuleAction.Load:    Load(target);    break;
                }
            }
        }

        // ═══════════════════════════════════════════════════
        //  Resource Throttling
        // ═══════════════════════════════════════════════════
        public void SetThrottle(ThrottleProfile profile)
        {
            if (_activeThrottle.Name == profile.Name) return;
            _activeThrottle = profile;
            Console.WriteLine($"[Idle] Throttle → {profile.Name}  " +
                              $"(FPS:{profile.MaxFPS} phys:{profile.PhysicsHz}Hz threads:{profile.WorkerThreads})");
            OnThrottleChanged?.Invoke(profile);
            // Propagate to registered modules
            foreach (var m in _modules.Values)
                m.Throttle = profile.Name switch
                {
                    "Reduced" => ThrottleLevel.Reduced,
                    "Minimal" => ThrottleLevel.Minimal,
                    "Paused"  => ThrottleLevel.Paused,
                    _         => ThrottleLevel.Full
                };
        }

        // ═══════════════════════════════════════════════════
        //  Engine-level idle detection
        // ═══════════════════════════════════════════════════
        public void Update(float dt, bool hasUserInput = false)
        {
            if (hasUserInput) { _idleTimer = 0f; if (_engineIdle) ExitEngineIdle(); return; }
            _idleTimer += dt;
            if (!_engineIdle && _idleTimer >= EngineIdleTimeoutSec) EnterEngineIdle();
            // Auto-suspend modules whose associated tab has been closed too long
            if (AutoThrottleEnabled)
            {
                foreach (var (tab, closedAt) in _tabClosedAt)
                {
                    float elapsed = (float)(DateTime.UtcNow - closedAt).TotalSeconds;
                    if (elapsed > ModuleSuspendDelaySec * 3)
                        foreach (var m in _modules.Values.Where(x => x.EditorTabName == tab && x.IsActive))
                            { m.DoSuspend(); OnModuleSuspended?.Invoke(m); }
                }
            }
        }

        private void EnterEngineIdle()
        {
            _engineIdle = true;
            Console.WriteLine("[Idle] Engine entered idle state.");
            if (AutoThrottleEnabled) SetThrottle(ThrottleProfile.Minimal);
            foreach (var m in _modules.Values.Where(x => x.AutoSuspend && x.IsActive))
                { m.DoSuspend(); OnModuleSuspended?.Invoke(m); }
            GC.Collect(2, GCCollectionMode.Optimized, blocking: false);
        }

        private void ExitEngineIdle()
        {
            _engineIdle = false;
            _idleTimer  = 0f;
            Console.WriteLine("[Idle] Engine exited idle state.");
            if (AutoThrottleEnabled) SetThrottle(ThrottleProfile.Full);
        }

        // ═══════════════════════════════════════════════════
        //  Memory Release
        // ═══════════════════════════════════════════════════
        public long ReleaseMemory(bool aggressive = false)
        {
            long total = 0;
            foreach (var m in _modules.Values.Where(x => x.IsSuspended))
                total += m.MemoryReleasedBytes;
            if (aggressive)
            {
                GC.Collect(2, GCCollectionMode.Forced, blocking: true);
                GC.WaitForPendingFinalizers();
                GC.Collect();
            }
            else
            {
                GC.Collect(0, GCCollectionMode.Optimized, blocking: false);
            }
            Console.WriteLine($"[Idle] Memory release: {FormatBytes(total)} freed from suspended modules.");
            return total;
        }

        // ═══════════════════════════════════════════════════
        //  Built-in Editor Module Presets
        // ═══════════════════════════════════════════════════
        /// <summary>
        /// Registers the standard BADGE editor-tab → module bindings.
        /// Call once at engine startup.
        /// </summary>
        public void RegisterEditorDefaults(
            Action? spriteLoad   = null, Action? spriteSuspend   = null, Action? spriteResume   = null, Action? spriteUnload   = null,
            Action? audioLoad    = null, Action? audioSuspend    = null, Action? audioResume    = null, Action? audioUnload    = null,
            Action? particleLoad = null, Action? particleSuspend = null, Action? particleResume = null, Action? particleUnload = null,
            Action? voxelLoad    = null, Action? voxelSuspend    = null, Action? voxelResume    = null, Action? voxelUnload    = null,
            Action? shaderLoad   = null, Action? shaderSuspend   = null, Action? shaderResume   = null, Action? shaderUnload   = null)
        {
            Register("SpriteSystem",   spriteLoad,   spriteSuspend,   spriteResume,   spriteUnload,   editorTab: "SpriteEditor");
            Register("AudioSystem",    audioLoad,    audioSuspend,    audioResume,    audioUnload,    editorTab: "AudioEditor");
            Register("ParticleSystem", particleLoad, particleSuspend, particleResume, particleUnload, editorTab: "ParticleEditor");
            Register("VoxelSystem",    voxelLoad,    voxelSuspend,    voxelResume,    voxelUnload,    editorTab: "VoxelEditor");
            Register("ShaderSystem",   shaderLoad,   shaderSuspend,   shaderResume,   shaderUnload,   editorTab: "ShaderEditor");

            // Wire rules automatically
            WhenTabCloses("SpriteEditor",   "SpriteSystem");
            WhenTabOpens ("SpriteEditor",   "SpriteSystem");
            WhenTabCloses("AudioEditor",    "AudioSystem");
            WhenTabOpens ("AudioEditor",    "AudioSystem");
            WhenTabCloses("ParticleEditor", "ParticleSystem");
            WhenTabOpens ("ParticleEditor", "ParticleSystem");
            WhenTabCloses("VoxelEditor",    "VoxelSystem");
            WhenTabOpens ("VoxelEditor",    "VoxelSystem");
            WhenTabCloses("ShaderEditor",   "ShaderSystem");
            WhenTabOpens ("ShaderEditor",   "ShaderSystem");

            Console.WriteLine("[Idle] Default editor module bindings registered.");
        }

        // ═══════════════════════════════════════════════════
        //  Dynamic Module Loading
        // ═══════════════════════════════════════════════════
        public async Task<bool> LoadModuleAsync(string name)
        {
            if (!_modules.TryGetValue(name, out var m)) return false;
            if (m.IsActive) return true;
            return await Task.Run(() =>
            {
                if (!m.CanLoad()) return false;
                if (m.IsSuspended) m.DoResume();
                else if (m.State == ModuleState.Unloaded) m.DoLoad();
                OnModuleResumed?.Invoke(m);
                return true;
            });
        }

        public async Task<bool> UnloadModuleAsync(string name)
        {
            if (!_modules.TryGetValue(name, out var m)) return false;
            return await Task.Run(() =>
            {
                if (m.State == ModuleState.Unloaded) return true;
                m.DoUnload();
                OnModuleSuspended?.Invoke(m);
                return true;
            });
        }

        // ═══════════════════════════════════════════════════
        //  Diagnostics
        // ═══════════════════════════════════════════════════
        public void PrintStatus()
        {
            Console.WriteLine("\n[Idle] ─── Module Status ─────────────────────────");
            Console.WriteLine($"  Engine idle: {_engineIdle}  Throttle: {_activeThrottle.Name}");
            foreach (var m in _modules.Values.OrderBy(x => x.Name))
                Console.WriteLine($"  {m.Name,-24} {m.State,-12} throttle:{m.Throttle,-8} tab:{m.EditorTabName}");
            var totalFreed = _modules.Values.Sum(m => m.MemoryReleasedBytes);
            Console.WriteLine($"  Total memory freed: {FormatBytes(totalFreed)}");
            Console.WriteLine();
        }

        private static string FormatBytes(long b) =>
            b < 1024 ? $"{b}B" : b < 1_048_576 ? $"{b/1024}KB" : $"{b/1_048_576}MB";
    }

    // ═══════════════════════════════════════════════════════
    //  Rule Types
    // ═══════════════════════════════════════════════════════
    public sealed class IdleRule
    {
        public string           TriggerTab    { get; set; } = "";
        public bool             OnOpen        { get; set; }   // true=tab opened, false=tab closed
        public IdleRuleAction   Action        { get; set; }
        public List<string>     TargetModules { get; set; } = new();
        public string           Description   { get; set; } = "";
    }

    public enum IdleRuleAction { Suspend, Resume, Unload, Load }
}
