// ============================================================
//  BADGE Engine – NodeSystems/VisualScripting.cs
//  Visual scripting runtime: execution nodes (if/loop/branch),
//  variable nodes, event nodes, and the script compiler that
//  turns a NodeGraph into a callable delegate.
// ============================================================
using System;
using System.Collections.Generic;
using BADGE.NodeSystems;

namespace BADGE.NodeSystems.VisualScript
{
    // ── Execution context ─────────────────────────────────────
    public sealed class ScriptContext
    {
        private readonly Dictionary<string, object?> _vars = new();

        public void   Set(string name, object? value) => _vars[name] = value;
        public object? Get(string name) => _vars.TryGetValue(name, out var v) ? v : null;
        public T?     Get<T>(string name) => _vars.TryGetValue(name, out var v) && v is T t ? t : default;
        public bool   Has(string name)   => _vars.ContainsKey(name);
    }

    // ── Execution flow base ───────────────────────────────────
    public abstract class ExecNode : BaseNode
    {
        public ExecNode? Next     { get; set; }  // flow-out
        public ExecNode? NextElse { get; set; }  // alternate branch (if/else)

        protected ScriptContext? _ctx;
        public void SetContext(ScriptContext ctx) => _ctx = ctx;

        /// <summary>Returns the next node to execute, or null to stop.</summary>
        public abstract ExecNode? Run();
        public override void Execute() => Run();
    }

    // ── Event entry node ──────────────────────────────────────
    public sealed class OnStartNode : ExecNode
    {
        public OnStartNode() { Title = "On Start"; }
        public override ExecNode? Run() => Next;
    }

    public sealed class OnUpdateNode : ExecNode
    {
        private readonly Port _dt;
        public OnUpdateNode() { Title = "On Update"; _dt = AddOutput("DeltaTime", PortType.Float); }
        public override ExecNode? Run()
        {
            _dt.Value = _ctx?.Get<float>("deltaTime") ?? 0f;
            return Next;
        }
    }

    // ── Variable nodes ────────────────────────────────────────
    public sealed class SetVariableNode : ExecNode
    {
        public string VarName { get; set; } = "myVar";
        private readonly Port _value;
        public SetVariableNode() { Title = "Set Variable"; _value = AddInput("Value", PortType.Any); }
        public override ExecNode? Run()
        {
            _ctx?.Set(VarName, _value.Value);
            return Next;
        }
    }

    public sealed class GetVariableNode : BaseNode
    {
        public string VarName { get; set; } = "myVar";
        private readonly Port _out;
        private ScriptContext? _ctx;
        public GetVariableNode() { Title = "Get Variable"; _out = AddOutput("Value", PortType.Any); }
        public void SetContext(ScriptContext ctx) => _ctx = ctx;
        public override void Execute() => _out.Value = _ctx?.Get(VarName);
    }

    // ── Branch / if ───────────────────────────────────────────
    public sealed class BranchNode : ExecNode
    {
        private readonly Port _condition;
        public BranchNode() { Title = "Branch"; _condition = AddInput("Condition", PortType.Bool); }
        public override ExecNode? Run()
            => (_condition.Value is bool b && b) ? Next : NextElse;
    }

    // ── For loop ──────────────────────────────────────────────
    public sealed class ForLoopNode : ExecNode
    {
        private readonly Port _count;
        public ExecNode? LoopBody  { get; set; }
        public ForLoopNode() { Title = "For Loop"; _count = AddInput("Count", PortType.Int); AddOutput("Index", PortType.Int); }
        public override ExecNode? Run()
        {
            int count = _count.Value is int i ? i : 0;
            for (int idx = 0; idx < count; idx++)
            {
                Outputs[0].Value = idx;
                var step = LoopBody;
                while (step != null) step = step.Run();
            }
            return Next;
        }
    }

    // ── Print / debug ─────────────────────────────────────────
    public sealed class PrintNode : ExecNode
    {
        private readonly Port _msg;
        public PrintNode() { Title = "Print"; _msg = AddInput("Message", PortType.String); }
        public override ExecNode? Run()
        {
            Console.WriteLine($"[VisualScript] {_msg.Value}");
            return Next;
        }
    }

    // ── Script compiler / runner ──────────────────────────────

    public sealed class VisualScript
    {
        public string       Name    { get; set; } = "Script";
        public ScriptContext Context { get; }     = new();
        private ExecNode?   _entry;

        public void SetEntry(ExecNode entry)
        {
            _entry = entry;
            PropagateContext(entry);
        }

        private void PropagateContext(ExecNode? node)
        {
            if (node == null) return;
            node.SetContext(Context);
            PropagateContext(node.Next);
            PropagateContext(node.NextElse);
            if (node is ForLoopNode fl) PropagateContext(fl.LoopBody);
        }

        public void Run(string eventName = "start", float deltaTime = 0f)
        {
            if (_entry == null) return;
            Context.Set("deltaTime", deltaTime);
            Context.Set("event",     eventName);

            var current = _entry;
            int safetyLimit = 100_000;
            while (current != null && safetyLimit-- > 0)
                current = current.Run();
        }
    }

    // ── Manager ───────────────────────────────────────────────

    public sealed class VisualScriptingManager
    {
        private static VisualScriptingManager? _instance;
        public  static VisualScriptingManager   Instance => _instance ??= new();

        private readonly Dictionary<string, VisualScript> _scripts = new();

        public void Register(VisualScript script) => _scripts[script.Name] = script;

        public void BroadcastEvent(string eventName, float dt = 0f)
        {
            foreach (var s in _scripts.Values)
                s.Run(eventName, dt);
        }

        public void UpdateAll(float dt) => BroadcastEvent("update", dt);
    }
}
