# BADGE Studio — Complete Documentation
**Basic Atlas Dimensional Game Engine  v1.0.0**

---

## Table of Contents
1. [Architecture Overview](#architecture)
2. [Getting Started](#getting-started)
3. [Engine Core](#engine-core)
4. [Boot Sequence](#boot-sequence)
5. [Systems Reference](#systems-reference)
6. [Editor Modules](#editor-modules)
7. [SDK / Public API](#sdk)
8. [Build Targets](#build-targets)
9. [Licensing](#licensing)

---

## Architecture Overview <a name="architecture"></a>

BADGE Studio is organized into a layered architecture:

```
┌─────────────────────────────────────────────┐
│              BADGE Studio IDE               │
│  Editor · Editors Registry · UIUXToolkit    │
├─────────────────────────────────────────────┤
│              Game / Runtime Layer           │
│  SceneSystem · Components · Scripting       │
│  NodeSystems · Animation · Physics · AI     │
├─────────────────────────────────────────────┤
│             Platform Services               │
│  Rendering · Audio · VFX · Networking       │
│  InputSystem · OutputSystem · AssetPipeline │
├─────────────────────────────────────────────┤
│             Engine Core (Kernel)            │
│  Engine · Kernel · EngineLoop · ModuleSystem│
│  EventSystem · ThreadScheduler · PluginMgr  │
├─────────────────────────────────────────────┤
│              Boot & Hardware                │
│  BootScreen · StartupSequence · HWScanner   │
│  DeviceScanner · MemoryAllocator · Diag     │
└─────────────────────────────────────────────┘
```

---

## Getting Started <a name="getting-started"></a>

### Requirements
- .NET 8 SDK
- Windows 10+ / Linux (Ubuntu 20+) / macOS 12+

### Build
```bash
dotnet build BADGE.Engine.csproj
```

### Minimal Game Entry Point
```csharp
using BADGE.Engine.Core;

Boot.Run();          // Initialize + start main loop
// or
Engine.Instance.Initialize();
Engine.Instance.Run();
```

### With custom systems
```csharp
Engine.Instance.Initialize();
Engine.Instance.Modules.Register(new MyGameModule());
Engine.Instance.Run();
```

---

## Engine Core <a name="engine-core"></a>

| Class | Namespace | Description |
|-------|-----------|-------------|
| `Engine` | `BADGE.Engine.Core` | Top-level singleton. Owns all subsystems. |
| `Kernel` | `BADGE.Engine.Core` | Low-level bridge to hardware and boot. |
| `Boot`   | `BADGE.Engine.Core` | Static façade: `Boot.Run()` / `Boot.InitOnly()` |
| `EngineLoop` | `BADGE.Engine.Core` | Fixed + variable timestep main loop. |
| `ModuleSystem` | `BADGE.Engine.Core` | Register/query `IEngineModule` subsystems. |
| `EventSystem` | `BADGE.Engine.Core` | Queued + immediate event dispatch. |
| `ThreadScheduler` | `BADGE.Engine.Core` | Main-thread deferred calls + recurring jobs. |
| `PluginManager` | `BADGE.Engine.Core` | Load `IPlugin` assemblies from `/Plugins/`. |
| `ConfigurationSystem` | `BADGE.Engine.Core` | JSON config load/save (`engine.config.json`). |

---

## Boot Sequence <a name="boot-sequence"></a>

On `Engine.Initialize()` the following steps execute in order:

1. **ConfigurationSystem.Load** — reads `engine.config.json`
2. **BootScreen.Show** — displays ASCII BADGE banner
3. **HardwareScanner.Scan** — detects CPU / GPU / RAM
4. **DeviceScanner.Scan** — enumerates input & audio devices
5. **MemoryAllocator.Initialize** — pre-allocates memory pools
6. **DiagnosticsLoader.Load** — opens log file, sets up profiler
7. **Render/Audio/Script** — deferred to respective modules
8. **ModuleSystem.InitializeAll** — initialises all registered modules
9. **PluginManager.LoadFromDirectory** — loads plugin DLLs

---

## Systems Reference <a name="systems-reference"></a>

### Runtime
```csharp
GameLoop.Instance.Run();              // start
GameLoop.Instance.Pause();            // pause
GameLoop.Instance.StepFrame();        // single step
GameLoop.Instance.TimeScale = 0.5f;  // slow motion
```

### NodeSystems
```csharp
var graph = NodeGraphFactory.CreateShaderGraph();
graph.AddNode(new TimeNode());
graph.AddNode(new SineNode());
graph.Connect(timeNode.GetOutput("Time"), sineNode.GetInput("Angle"));
graph.Evaluate();
```

### Networking
```csharp
NetworkManager.Instance.StartServer(7777);
NetworkManager.Instance.Broadcast(packet);
NetworkManager.Instance.RPC.Register("SetHealth", OnSetHealth);
```

### Compression
```csharp
var result = CompressionSystem.Instance.Compress(data, CompressionAlgorithm.Brotli);
Console.WriteLine(result.Summary); // "Brotli 4096→312 bytes (8%)"
CompressionSystem.Instance.CompressFile("asset.wav", "asset.bdgc");
```

### Tools
```csharp
// Color conversions
var (h,s,v) = ColorTools.RGBtoHSV(0.5f, 0.3f, 0.8f);
string hex  = ColorTools.RGBtoHex(1f, 0.5f, 0f); // "#FF8000"

// Event bus
EventBus.Instance.Subscribe<PlayerDied>(e => Console.WriteLine($"{e.Name} died"));
EventBus.Instance.Publish(new PlayerDied { Name = "Hero" });

// Command bus (with undo)
CommandBus.Instance.Execute(new MoveEntityCommand(entity, newPos));
CommandBus.Instance.Undo();
```

### Licensing
```csharp
LicensingSystem.Instance.Load();           // load from disk
LicensingSystem.Instance.Activate(key, name, email, LicenseTier.Studio);
bool ok = LicensingSystem.Instance.IsFeatureAllowed("export.android");
```

### UIUXToolkit
```csharp
var toolkit = UIUXToolkit.Instance;
toolkit.ApplyTheme(UITheme.Dark);
var root   = toolkit.CreateRoot(0, 0, 1280, 720);
var button = new Button { Text = "Play" };
button.OnClick += _ => GameLoop.Instance.Run();
root.AddChild(button);
toolkit.RenderAll();
```

---

## Editor Modules <a name="editor-modules"></a>

| Module | Icon | Description |
|--------|------|-------------|
| ModelEditor | 🧊 | Blender-style 3D modeling, sculpt, UV |
| SpriteEditor | 🖼 | Photoshop-style 2D pixel/raster editor |
| AnimationEditor | 🎞 | Timeline, curves, blend trees |
| AudioEditor | 🎵 | Waveform editor, mixer, DSP effects |
| MaterialEditor | 🎨 | PBR material authoring |
| NodeGraphEditor | 🔗 | Visual node graph viewer |
| ShaderEditor | ✨ | GLSL/HLSL shader IDE |
| ParticleEditor | 💫 | VFX particle system designer |
| TerrainEditor | 🏔 | Height map terrain sculpting |
| VoxelEditor | 🟫 | Minecraft-style voxel sculpting |
| UIDesigner | 📐 | Drag-and-drop UI layout |
| PhysicsDebugger | ⚙ | Runtime physics visualizer |
| Notes | 📝 | Markdown notes + to-do tracker |
| Terminal | 💻 | In-engine REPL console (50+ commands) |

### Opening editors
```csharp
EditorSystem.Instance.Initialize();
EditorsRegistry.Instance.RegisterAll();
EditorSystem.Instance.OpenModule("ModelEditor");
EditorSystem.Instance.SetTheme(EditorTheme.Midnight);
```

---

## SDK / Public API <a name="sdk"></a>

The `SDK/SDKAPI.cs` file exposes the full public surface area for game code.

```csharp
using BADGE.SDK;

// Scene
var scene = BSDK.Scene.CreateScene("Level1");
var obj   = BSDK.Scene.Spawn("Player");

// Physics
BSDK.Physics.SetGravity(0, -9.81f, 0);

// Audio
BSDK.Audio.PlaySFX("explosion.wav");

// Input
if (BSDK.Input.IsKeyDown("Space")) player.Jump();
```

---

## Build Targets <a name="build-targets"></a>

| Platform | Output | Notes |
|----------|--------|-------|
| Windows  | `.exe` + assets | Direct3D 12 / Vulkan |
| Linux    | Shell + assets  | Vulkan / OpenGL |
| macOS    | `.app` bundle   | Metal |
| WebGL    | HTML5 canvas    | WebAssembly |
| Android  | APK             | Vulkan / OpenGL ES |
| iOS      | Xcode project   | Metal |
| PS5      | Manifest stub   | Requires Sony SDK |
| Xbox     | Manifest stub   | Requires Microsoft GDK |
| Switch   | Manifest stub   | Requires Nintendo SDK |

---

## Licensing <a name="licensing"></a>

| Tier | Price | Team | Revenue Cap | Console Export |
|------|-------|------|-------------|----------------|
| Free | $0 | 1 | $100K/yr | ✗ |
| Indie | $99/yr | 3 | $500K/yr | ✗ |
| Studio | $499/yr | 25 | Unlimited | ✓ |
| Enterprise | Custom | Unlimited | Unlimited | ✓ |

See `Licensing/LICENSE.txt` for full terms.

---

*BADGE Studio — Basic Atlas Dimensional Game Engine  
Copyright © BADGE Studio Contributors. MIT License.*
