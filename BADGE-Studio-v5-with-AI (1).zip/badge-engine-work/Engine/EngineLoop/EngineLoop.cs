using System;
using System.Diagnostics;

namespace BADGE.Engine.Core
{
    public class EngineLoop
    {
        private static EngineLoop? _instance;
        public static EngineLoop Instance => _instance ??= new EngineLoop();

        private bool _running;
        private int _targetFPS = 60;
        private long _frameCount;
        private double _totalTime;

        public long FrameCount => _frameCount;
        public double TotalTime => _totalTime;
        public float DeltaTime { get; private set; }
        public float TimeScale { get; set; } = 1.0f;

        public event Action<float> OnUpdate;
        public event Action<float> OnFixedUpdate;
        public event Action OnRender;
        public event Action OnStart;
        public event Action OnStop;

        private const float FIXED_TIMESTEP = 1.0f / 50.0f;
        private float _fixedAccumulator;

        public void SetTargetFPS(int fps) => _targetFPS = fps;

        public void Run()
        {
            _running = true;
            OnStart?.Invoke();

            var stopwatch = Stopwatch.StartNew();
            long lastTicks = stopwatch.ElapsedTicks;
            double ticksPerSecond = Stopwatch.Frequency;
            double targetFrameTicks = ticksPerSecond / _targetFPS;

            while (_running)
            {
                long now = stopwatch.ElapsedTicks;
                double elapsed = (now - lastTicks) / ticksPerSecond;
                lastTicks = now;

                DeltaTime = (float)(elapsed * TimeScale);
                _totalTime += elapsed;
                _frameCount++;

                _fixedAccumulator += DeltaTime;
                while (_fixedAccumulator >= FIXED_TIMESTEP)
                {
                    OnFixedUpdate?.Invoke(FIXED_TIMESTEP);
                    _fixedAccumulator -= FIXED_TIMESTEP;
                }

                EventSystem.Instance.ProcessQueue();
                OnUpdate?.Invoke(DeltaTime);
                OnRender?.Invoke();

                double frameTime = (stopwatch.ElapsedTicks - now) / ticksPerSecond;
                double sleepTime = (targetFrameTicks / ticksPerSecond) - frameTime;
                if (sleepTime > 0.001)
                    System.Threading.Thread.Sleep((int)(sleepTime * 1000));
            }

            OnStop?.Invoke();
        }

        public void Stop() => _running = false;
    }
}
