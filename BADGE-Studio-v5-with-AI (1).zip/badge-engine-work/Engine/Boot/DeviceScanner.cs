// ============================================================
//  BADGE Engine – Boot/DeviceScanner.cs
//  Enumerates connected input devices: keyboard, mouse,
//  gamepads/joysticks, touch screens, and audio I/O.
// ============================================================
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace BADGE.Engine.Boot
{
    /// <summary>Describes a single detected input or audio device.</summary>
    public sealed class DeviceEntry
    {
        public string Category { get; init; } = string.Empty;   // "Keyboard", "Gamepad", …
        public string Name     { get; init; } = string.Empty;
        public bool   Available{ get; init; } = true;

        public override string ToString() => $"[{Category}] {Name}";
    }

    /// <summary>
    /// Scans the host for all connected input and audio
    /// devices and populates <see cref="Devices"/>.
    /// </summary>
    public sealed class DeviceScanner
    {
        /// <summary>All detected devices after <see cref="Scan"/>.</summary>
        public IReadOnlyList<DeviceEntry> Devices => _devices;
        private readonly List<DeviceEntry> _devices = new();

        // ── Public API ────────────────────────────────────────

        public void Scan()
        {
            _devices.Clear();

            AddAlwaysPresent();
            ScanGamepads();
            ScanAudioDevices();

            Console.WriteLine($"[DeviceScanner] {_devices.Count} device(s) detected:");
            foreach (var d in _devices)
                Console.WriteLine($"  • {d}");
        }

        // ── Helpers ───────────────────────────────────────────

        /// <summary>Keyboard and mouse are assumed to always be present.</summary>
        private void AddAlwaysPresent()
        {
            _devices.Add(new DeviceEntry { Category = "Keyboard", Name = "System Keyboard" });
            _devices.Add(new DeviceEntry { Category = "Mouse",    Name = "System Mouse"    });
        }

        /// <summary>
        /// Attempt gamepad enumeration via SDL-style heuristic.
        /// Falls back to a single "Generic Gamepad" placeholder
        /// when native interop is unavailable.
        /// </summary>
        private void ScanGamepads()
        {
            // OpenTK / SDL gamepad detection would go here.
            // For portability we use a cross-platform heuristic:
            // check /dev/input/js* on Linux.
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    int index = 0;
                    foreach (var js in System.IO.Directory.GetFiles("/dev/input", "js*"))
                    {
                        _devices.Add(new DeviceEntry
                        {
                            Category = "Gamepad",
                            Name     = $"Joystick {index++} ({System.IO.Path.GetFileName(js)})"
                        });
                    }
                }
                catch { /* /dev/input may not be accessible */ }
            }
            else
            {
                // Windows / macOS: XInput / HID enumeration requires native DLL.
                // Register a placeholder that InputSystem will replace at runtime.
                _devices.Add(new DeviceEntry
                {
                    Category  = "Gamepad",
                    Name      = "XInput/HID (enumerated at runtime)",
                    Available = false
                });
            }
        }

        /// <summary>
        /// List audio output devices available to the .NET runtime.
        /// Uses cross-platform fallback strings.
        /// </summary>
        private void ScanAudioDevices()
        {
            // Full enumeration requires OpenAL or WASAPI interop.
            // We register the default output as a known-good device.
            _devices.Add(new DeviceEntry { Category = "Audio Output", Name = "Default Audio Output" });
            _devices.Add(new DeviceEntry { Category = "Audio Input",  Name = "Default Microphone"   });
        }

        // ── Convenience queries ───────────────────────────────

        public IEnumerable<DeviceEntry> OfCategory(string category)
        {
            foreach (var d in _devices)
                if (d.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
                    yield return d;
        }

        public bool HasGamepad() => _devices.Exists(
            d => d.Category == "Gamepad" && d.Available);
    }
}
