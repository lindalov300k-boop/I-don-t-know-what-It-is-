// ============================================================
//  BADGE Engine – Boot/BootSystem.cs
//  Startup sequence, hardware scanning, splash screen.
// ============================================================
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Threading;

namespace BADGE.Engine.Boot
{
    /// <summary>Manages the engine startup sequence and boot screen.</summary>
    public sealed class BootSystem
    {
        public BootStatus Status   { get; private set; } = BootStatus.Idle;
        public float      Progress { get; private set; }

        private readonly string[] _bootSteps =
        {
            "Scanning hardware...",
            "Allocating memory pools...",
            "Initializing render pipeline...",
            "Loading core assets...",
            "Starting physics simulation...",
            "Initializing audio engine...",
            "Loading script runtime...",
            "Ready."
        };

        public void Execute(Action<string, float>? onProgress = null)
        {
            Status = BootStatus.Running;
            PrintSplash();

            for (int i = 0; i < _bootSteps.Length; i++)
            {
                Progress = (float)(i + 1) / _bootSteps.Length;
                var msg = _bootSteps[i];
                Console.WriteLine($"  [{Progress * 100,5:F1}%] {msg}");
                onProgress?.Invoke(msg, Progress);
                Thread.Sleep(50); // simulate real init time
            }

            Status = BootStatus.Complete;
        }

        private static void PrintSplash()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine();
            Console.WriteLine("  ██████╗  █████╗ ██████╗  ██████╗ ███████╗");
            Console.WriteLine("  ██╔══██╗██╔══██╗██╔══██╗██╔════╝ ██╔════╝");
            Console.WriteLine("  ██████╔╝███████║██║  ██║██║  ███╗█████╗  ");
            Console.WriteLine("  ██╔══██╗██╔══██║██║  ██║██║   ██║██╔══╝  ");
            Console.WriteLine("  ██████╔╝██║  ██║██████╔╝╚██████╔╝███████╗");
            Console.WriteLine("  ╚═════╝ ╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚══════╝");
            Console.ResetColor();
            Console.WriteLine("  Basic Atlas Dimensional Game Engine  v1.0.0");
            Console.WriteLine();
        }
    }

    public enum BootStatus { Idle, Running, Complete, Failed }
}

// ── Hardware Scanner ─────────────────────────────────────────
namespace BADGE.Engine.Hardware
{
    public sealed class HardwareInfo
    {
        public string OS            { get; set; } = string.Empty;
        public string CPU           { get; set; } = string.Empty;
        public int    LogicalCores  { get; set; }
        public int    PhysicalCores { get; set; }
        public long   TotalRamBytes { get; set; }
        public long   FreeRamBytes  { get; set; }
        public string GPU           { get; set; } = string.Empty;
        public long   VRamBytes     { get; set; }
        public List<string> InputDevices { get; set; } = new();
        public bool   Is64Bit       => RuntimeInformation.ProcessArchitecture == Architecture.X64
                                    || RuntimeInformation.ProcessArchitecture == Architecture.Arm64;
        public long   TotalRamMB   => TotalRamBytes / (1024 * 1024);
    }

    /// <summary>Scans the host machine for CPU, GPU, RAM, and peripherals.</summary>
    public sealed class BootHardwareChecker
    {
        public HardwareInfo Info { get; private set; } = new();

        public void Scan()
        {
            Info = new HardwareInfo
            {
                OS           = RuntimeInformation.OSDescription,
                CPU          = GetCPUName(),
                LogicalCores = Environment.ProcessorCount,
                PhysicalCores= System.Math.Max(1, Environment.ProcessorCount / 2),
                TotalRamBytes= GC.GetGCMemoryInfo().TotalAvailableMemoryBytes,
                FreeRamBytes = GetFreeRam(),
                GPU          = DetectGPU(),
            };

            Info.InputDevices.Add("Keyboard");
            Info.InputDevices.Add("Mouse");

            Console.WriteLine($"[HW] OS:  {Info.OS}");
            Console.WriteLine($"[HW] CPU: {Info.CPU} ({Info.LogicalCores} logical cores)");
            Console.WriteLine($"[HW] RAM: {Info.TotalRamMB} MB total");
            Console.WriteLine($"[HW] GPU: {Info.GPU}");
        }

        private string GetCPUName()
        {
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                try
                {
                    var key = Microsoft.Win32.Registry.LocalMachine
                        .OpenSubKey(@"HARDWARE\DESCRIPTION\System\CentralProcessor\0");
                    return key?.GetValue("ProcessorNameString")?.ToString() ?? "Unknown CPU";
                }
                catch { }
            }
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    var lines = System.IO.File.ReadAllLines("/proc/cpuinfo");
                    foreach (var l in lines)
                        if (l.StartsWith("model name"))
                            return l.Split(':')[1].Trim();
                }
                catch { }
            }
            return $"{RuntimeInformation.ProcessArchitecture} CPU";
        }

        private static long GetFreeRam()
        {
            var info = GC.GetGCMemoryInfo();
            return info.TotalAvailableMemoryBytes - info.HeapSizeBytes;
        }

        private static string DetectGPU()
        {
            // In a real engine this would query DXGI / Vulkan / Metal.
            // Here we return a descriptive placeholder.
            return "OpenGL/Vulkan compatible GPU (full detection requires native interop)";
        }
    }
}
