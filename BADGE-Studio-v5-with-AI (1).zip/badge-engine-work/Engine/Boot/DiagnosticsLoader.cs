// ============================================================
//  BADGE Engine – Boot/DiagnosticsLoader.cs
//  Configures and activates the diagnostics subsystem during
//  boot: CPU/frame profiler, memory tracker, log sinks, and
//  the optional diagnostic overlay (HUD).
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;

namespace BADGE.Engine.Boot
{
    /// <summary>Severity levels for the engine log.</summary>
    public enum LogLevel { Verbose, Info, Warning, Error, Fatal }

    /// <summary>Represents one diagnostic log entry.</summary>
    public sealed class LogEntry
    {
        public DateTime  Timestamp { get; } = DateTime.UtcNow;
        public LogLevel  Level     { get; init; }
        public string    Tag       { get; init; } = string.Empty;
        public string    Message   { get; init; } = string.Empty;
        public override string ToString()
            => $"[{Timestamp:HH:mm:ss.fff}][{Level,-7}][{Tag}] {Message}";
    }

    /// <summary>
    /// Loaded once during boot.  Sets up:
    ///   • Console log sink with colour coding
    ///   • Optional file log sink (engine.log)
    ///   • In-memory ring buffer for the editor diagnostics panel
    ///   • Basic CPU-time profiler hooks
    /// </summary>
    public sealed class DiagnosticsLoader
    {
        // ── Singleton ─────────────────────────────────────────
        private static DiagnosticsLoader? _instance;
        public  static DiagnosticsLoader  Instance => _instance ??= new DiagnosticsLoader();

        // ── Settings ──────────────────────────────────────────
        public bool     WriteToFile     { get; set; } = true;
        public string   LogFilePath     { get; set; } = "engine.log";
        public LogLevel MinLevel        { get; set; } = LogLevel.Info;
        public int      RingBufferSize  { get; set; } = 512;

        // ── State ─────────────────────────────────────────────
        public bool IsLoaded { get; private set; }

        private readonly Queue<LogEntry>  _ring = new();
        private StreamWriter?             _file;

        // ── Lifecycle ─────────────────────────────────────────

        public void Load()
        {
            if (IsLoaded) return;
            _instance = this;

            if (WriteToFile)
            {
                try
                {
                    _file = new StreamWriter(LogFilePath, append: false) { AutoFlush = true };
                    _file.WriteLine($"# BADGE Engine log — {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} UTC");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[DiagnosticsLoader] Cannot open log file: {ex.Message}");
                    _file = null;
                }
            }

            IsLoaded = true;
            Log(LogLevel.Info, "Diagnostics", "DiagnosticsLoader ready.");
        }

        public void Unload()
        {
            _file?.Flush();
            _file?.Dispose();
            _file = null;
            IsLoaded = false;
        }

        // ── Logging ───────────────────────────────────────────

        public void Log(LogLevel level, string tag, string message)
        {
            if (level < MinLevel) return;

            var entry = new LogEntry { Level = level, Tag = tag, Message = message };

            // Ring buffer
            _ring.Enqueue(entry);
            while (_ring.Count > RingBufferSize) _ring.Dequeue();

            // Console sink
            Console.ForegroundColor = level switch
            {
                LogLevel.Warning => ConsoleColor.Yellow,
                LogLevel.Error   => ConsoleColor.Red,
                LogLevel.Fatal   => ConsoleColor.Magenta,
                _                => ConsoleColor.Gray
            };
            Console.WriteLine(entry.ToString());
            Console.ResetColor();

            // File sink
            _file?.WriteLine(entry.ToString());
        }

        // Convenience helpers
        public void Info   (string tag, string msg) => Log(LogLevel.Info,    tag, msg);
        public void Warning(string tag, string msg) => Log(LogLevel.Warning, tag, msg);
        public void Error  (string tag, string msg) => Log(LogLevel.Error,   tag, msg);

        // ── Ring buffer query ─────────────────────────────────

        public IEnumerable<LogEntry> RecentEntries() => _ring;

        public IEnumerable<LogEntry> EntriesOfLevel(LogLevel level)
        {
            foreach (var e in _ring)
                if (e.Level == level) yield return e;
        }

        // ── Profiler stubs ────────────────────────────────────
        // These are thin wrappers; the heavy lifting is in Diagnostics/Profiler.cs

        private readonly Dictionary<string, long> _profileStart = new();

        public void BeginSample(string name)
            => _profileStart[name] = System.Diagnostics.Stopwatch.GetTimestamp();

        public double EndSample(string name)
        {
            if (!_profileStart.TryGetValue(name, out long start)) return 0;
            long elapsed = System.Diagnostics.Stopwatch.GetTimestamp() - start;
            double ms    = elapsed * 1000.0 / System.Diagnostics.Stopwatch.Frequency;
            _profileStart.Remove(name);
            return ms;
        }
    }
}
