// ============================================================
//  BADGE Engine – Engine/Kernel.cs
//  Low-level kernel layer. Sits between the raw hardware /
//  OS layer and Engine Core. Owns the boot orchestration,
//  memory primitives, and thread affinity.
// ============================================================
using System;
using BADGE.Engine.Boot;

namespace BADGE.Engine.Core
{
    /// <summary>
    /// The Kernel is the innermost layer of BADGE Engine.
    /// It is responsible for:
    ///   • Executing the full StartupSequence
    ///   • Surfacing HardwareInfo to higher systems
    ///   • Providing low-level timing and thread affinity helpers
    /// </summary>
    public sealed class Kernel
    {
        // ── Singleton ────────────────────────────────────────
        private static Kernel? _instance;
        public  static Kernel   Instance => _instance ??= new Kernel();

        // ── Exposed subsystems ───────────────────────────────
        public StartupSequence Startup  { get; } = new StartupSequence();
        public MemoryAllocator Memory   { get; } = new MemoryAllocator();

        // Hardware info populated after Boot()
        public BADGE.Engine.Hardware.HardwareInfo? Hardware { get; private set; }

        private Kernel() { }

        // ─────────────────────────────────────────────────────
        /// <summary>
        /// Run the full kernel boot: hardware scan → memory init
        /// → diagnostics → boot screen → startup sequence.
        /// Called by Engine.Initialize().
        /// </summary>
        public void Boot()
        {
            Console.WriteLine("[Kernel] Boot initiated.");

            // 1. Memory pools first so everything else can allocate
            Memory.Initialize();

            // 2. Run startup sequence (shows screen + scans hardware)
            Startup.Execute(out var hw);
            Hardware = hw;

            Console.WriteLine("[Kernel] Boot complete.");
        }

        // ─────────────────────────────────────────────────────
        /// <summary>
        /// High-resolution elapsed milliseconds since process start.
        /// </summary>
        public static long TicksMs()
            => System.Diagnostics.Stopwatch.GetTimestamp() * 1000L
               / System.Diagnostics.Stopwatch.Frequency;

        /// <summary>
        /// Hint to the OS to pin the calling thread to a specific
        /// logical core (best-effort; no-op on unsupported platforms).
        /// </summary>
        public static void SetThreadAffinity(int logicalCore)
        {
            try
            {
                var proc   = System.Diagnostics.Process.GetCurrentProcess();
                var thread = System.Threading.Thread.CurrentThread;
                // ProcessThread affinity is Windows-only; guard gracefully.
                if (System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform(
                        System.Runtime.InteropServices.OSPlatform.Windows))
                {
                    int mask = 1 << (logicalCore % Environment.ProcessorCount);
                    proc.ProcessorAffinity = (IntPtr)mask;
                }
            }
            catch
            {
                // Non-fatal: affinity is a hint, not a requirement.
            }
        }
    }
}
