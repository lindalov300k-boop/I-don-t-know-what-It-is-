// ============================================================
//  BADGE Engine – Engine/EngineKernel.cs
//  High-level engine facade.  Exposes every major subsystem
//  through a single well-known singleton so that Components,
//  Scripting, SDK, and Scene code can resolve systems without
//  knowing concrete types or instantiation order.
//
//  Previously this class was referenced everywhere but never
//  defined — fixed in this revision.
// ============================================================
using System;
using BADGE.Engine.Audio;
using BADGE.Engine.Input;
using BADGE.Engine.Physics;
using BADGE.Engine.Scene;
using BADGE.Engine.Core;

namespace BADGE.Engine.Core
{
    /// <summary>
    /// Central engine facade.  All subsystems are lazy-initialised
    /// and available from first access.  Use <see cref="Instance"/>
    /// to obtain the singleton.
    /// </summary>
    public sealed class EngineKernel
    {
        // ── Singleton ─────────────────────────────────────────────
        private static EngineKernel? _instance;
        public  static EngineKernel   Instance => _instance ??= new EngineKernel();

        // ── Subsystems ────────────────────────────────────────────

        /// <summary>Scene loading, object hierarchy, and scene-lifecycle events.</summary>
        public SceneManager  SceneManager { get; } = SceneManager.Instance;

        /// <summary>Rigid-body simulation, colliders, raycasts, and overlap queries.</summary>
        public PhysicsWorld  Physics      { get; } = new PhysicsWorld(new PhysicsConfig());

        /// <summary>Audio playback, 3-D spatialisation, mixer, and listener.</summary>
        public AudioEngine   Audio        { get; } = new AudioEngine(new AudioConfig());

        /// <summary>Keyboard, mouse, gamepad, and touch input.</summary>
        public InputManager  Input        { get; } = new InputManager();

        /// <summary>Publish/subscribe event bus shared across all systems.</summary>
        public EventSystem   Events       { get; } = EventSystem.Instance;

        /// <summary>Background job scheduler with priority queues.</summary>
        public ThreadScheduler Scheduler  { get; } = ThreadScheduler.Instance;

        // ── Private ctor (singleton) ──────────────────────────────
        private EngineKernel()
        {
            Console.WriteLine("[EngineKernel] Subsystems initialised.");
        }
    }
}
