using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Drives all procedural world generation.
/// Attach to an empty "WorldGenerator" GameObject.
/// </summary>
public class WorldGenerator : MonoBehaviour
{
    [Header("References")]
    public Transform player;
    public GameObject tilePrefab;
    public GameObject platformPrefab;
    public GameObject coinPrefab;
    public GameObject spikePrefab;

    [Header("Terrain")]
    public float tileWidth = 2f;
    public float groundY = 0f;
    public int tilesAhead = 30;
    public int tilesBehind = 10;

    [Header("Gap Settings")]
    [Range(0f, 1f)] public float baseGapChance = 0.12f;
    public int minSafeStart = 6;

    [Header("Platform")]
    public float platformMinY = 1.5f;
    public float platformMaxY = 4f;

    [Header("Coin")]
    [Range(0f, 1f)] public float coinOnTerrainChance = 0.2f;
    [Range(0f, 1f)] public float coinInGapChance = 0.7f;
    [Range(0f, 1f)] public float coinOnPlatformChance = 0.55f;

    [Header("Hazards")]
    [Range(0f, 1f)] public float baseSpikeChance = 0.04f;
    [Range(0f, 1f)] public float platformSpikeChance = 0.18f;

    private int _nextCol;
    private int _lastCleanedCol;
    private Dictionary<int, GameObject> _tiles = new Dictionary<int, GameObject>();
    private List<GameObject> _platforms = new List<GameObject>();
    private List<GameObject> _coins = new List<GameObject>();
    private List<GameObject> _spikes = new List<GameObject>();

    private void Start()
    {
        _nextCol = 0;
        GenerateUpTo(tilesAhead);
    }

    private void Update()
    {
        if (GameManager.Instance?.State != GameManager.GameState.Playing) return;

        int playerCol = Mathf.FloorToInt(player.position.x / tileWidth);
        GenerateUpTo(playerCol + tilesAhead);
        CleanBehind(playerCol - tilesBehind);
    }

    // ── Generation ────────────────────────────────────────────────────────────

    private void GenerateUpTo(int targetCol)
    {
        while (_nextCol <= targetCol)
        {
            GenerateColumn(_nextCol);
            _nextCol++;
        }
    }

    private void GenerateColumn(int col)
    {
        if (_tiles.ContainsKey(col)) return;

        float difficulty = GameManager.Instance != null ? GameManager.Instance.DifficultyFactor : 0f;
        float gapChance = Mathf.Min(0.4f, baseGapChance + difficulty * 0.08f);
        float spikeChance = Mathf.Min(0.25f, baseSpikeChance + difficulty * 0.06f);

        bool isGap = col >= minSafeStart && Random.value < gapChance;

        if (!isGap)
        {
            SpawnTile(col, spikeChance);
        }
        else
        {
            // Mark gap with null-sentinel so we don't re-generate
            _tiles[col] = null;
            SpawnGapContent(col, difficulty);
        }
    }

    private void SpawnTile(int col, float spikeChance)
    {
        float heightVariance = Random.Range(-0.15f, 0.15f);
        Vector3 pos = new Vector3(col * tileWidth, groundY + heightVariance, 0f);
        GameObject tile = Instantiate(tilePrefab, pos, Quaternion.identity, transform);
        tile.GetComponent<ProceduralTile>()?.Randomise();
        _tiles[col] = tile;

        // Coin on terrain
        if (Random.value < coinOnTerrainChance)
            SpawnCoin(pos + Vector3.up * 1.2f);

        // Spike on terrain
        if (col >= minSafeStart && Random.value < spikeChance)
            SpawnSpike(pos + Vector3.up * 0.5f);
    }

    private void SpawnGapContent(int col, float difficulty)
    {
        float x = col * tileWidth;

        // Platform above gap
        if (Random.value < 0.85f)
        {
            float py = groundY + Random.Range(platformMinY, platformMaxY + difficulty * 0.5f);
            Vector3 ppos = new Vector3(x + Random.Range(-0.3f, 0.3f), py, 0f);
            GameObject plat = Instantiate(platformPrefab, ppos, Quaternion.identity, transform);
            ProceduralPlatform pp = plat.GetComponent<ProceduralPlatform>();
            pp?.Randomise();
            _platforms.Add(plat);

            // Coins on platform
            if (Random.value < coinOnPlatformChance && pp != null)
            {
                int count = Random.Range(1, 4);
                for (int i = 0; i < count; i++)
                {
                    float ox = Random.Range(-pp.halfWidth * 0.8f, pp.halfWidth * 0.8f);
                    SpawnCoin(ppos + new Vector3(ox, 0.9f, 0f));
                }
            }

            // Spike on platform
            if (Random.value < platformSpikeChance && pp != null)
            {
                float ox = Random.Range(-pp.halfWidth * 0.6f, pp.halfWidth * 0.6f);
                SpawnSpike(ppos + new Vector3(ox, 0.5f, 0f));
            }
        }

        // Floating coin in gap
        if (Random.value < coinInGapChance)
        {
            float cy = groundY + Random.Range(0.8f, 2.5f);
            SpawnCoin(new Vector3(x, cy, 0f));
        }
    }

    private void SpawnCoin(Vector3 pos)
    {
        GameObject c = Instantiate(coinPrefab, pos, Quaternion.identity, transform);
        c.GetComponent<CoinPickup>()?.Randomise();
        _coins.Add(c);
    }

    private void SpawnSpike(Vector3 pos)
    {
        GameObject s = Instantiate(spikePrefab, pos, Quaternion.identity, transform);
        s.GetComponent<ProceduralSpike>()?.Randomise();
        _spikes.Add(s);
    }

    // ── Cleanup ───────────────────────────────────────────────────────────────

    private void CleanBehind(int minCol)
    {
        if (minCol <= _lastCleanedCol) return;
        _lastCleanedCol = minCol;

        List<int> toRemove = new List<int>();
        foreach (var kv in _tiles)
        {
            if (kv.Key < minCol)
            {
                if (kv.Value != null) Destroy(kv.Value);
                toRemove.Add(kv.Key);
            }
        }
        foreach (int k in toRemove) _tiles.Remove(k);

        float minX = minCol * tileWidth;
        CleanList(_platforms, minX);
        CleanList(_coins, minX);
        CleanList(_spikes, minX);
    }

    private void CleanList(List<GameObject> list, float minX)
    {
        for (int i = list.Count - 1; i >= 0; i--)
        {
            if (list[i] == null || list[i].transform.position.x < minX)
            {
                if (list[i] != null) Destroy(list[i]);
                list.RemoveAt(i);
            }
        }
    }
}
