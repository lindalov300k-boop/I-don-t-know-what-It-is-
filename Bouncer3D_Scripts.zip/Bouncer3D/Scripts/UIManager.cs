using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Manages all UI: start screen, HUD (coins + distance), and death screen.
/// Attach to an empty "UIManager" GameObject.
/// Requires: Canvas with the panels below wired in the Inspector.
/// </summary>
public class UIManager : MonoBehaviour
{
    public static UIManager Instance { get; private set; }

    [Header("Panels")]
    public GameObject startPanel;
    public GameObject hudPanel;
    public GameObject deathPanel;

    [Header("HUD")]
    public TMP_Text coinText;
    public TMP_Text distanceText;
    public TMP_Text bestText;

    [Header("Death Screen")]
    public TMP_Text deathCoinText;
    public TMP_Text deathDistText;
    public TMP_Text newBestLabel;

    [Header("Start Screen")]
    public TMP_Text startTitleText;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    private void OnEnable()
    {
        if (GameManager.Instance == null) return;
        GameManager.Instance.OnGameStart     += OnGameStart;
        GameManager.Instance.OnGameDeath     += OnGameDeath;
        GameManager.Instance.OnCoinCollected += OnCoinCollected;
        GameManager.Instance.OnDistanceUpdated += OnDistanceUpdated;
    }

    private void OnDisable()
    {
        if (GameManager.Instance == null) return;
        GameManager.Instance.OnGameStart     -= OnGameStart;
        GameManager.Instance.OnGameDeath     -= OnGameDeath;
        GameManager.Instance.OnCoinCollected -= OnCoinCollected;
        GameManager.Instance.OnDistanceUpdated -= OnDistanceUpdated;
    }

    // ── Panel helpers ─────────────────────────────────────────────────────────

    public void ShowStartScreen()
    {
        startPanel?.SetActive(true);
        hudPanel?.SetActive(false);
        deathPanel?.SetActive(false);
        if (bestText != null)
            bestText.text = $"BEST: {GameManager.Instance.BestDistance}m";
    }

    public void ShowHUD()
    {
        startPanel?.SetActive(false);
        hudPanel?.SetActive(true);
        deathPanel?.SetActive(false);
        UpdateHUD(0, 0);
    }

    // ── Event handlers ────────────────────────────────────────────────────────

    private void OnGameStart()
    {
        ShowHUD();
    }

    private void OnGameDeath()
    {
        hudPanel?.SetActive(false);
        deathPanel?.SetActive(true);

        if (deathCoinText != null) deathCoinText.text = $"COINS: {GameManager.Instance.CoinsCollected}";
        if (deathDistText != null) deathDistText.text = $"DISTANCE: {GameManager.Instance.Distance}m";

        bool newBest = GameManager.Instance.Distance >= GameManager.Instance.BestDistance;
        if (newBestLabel != null) newBestLabel.gameObject.SetActive(newBest);
    }

    private void OnCoinCollected(int total)
    {
        if (coinText != null) coinText.text = $"COINS: {total}";
    }

    private void OnDistanceUpdated(int dist)
    {
        if (distanceText != null) distanceText.text = $"{dist}m";
        if (bestText != null) bestText.text = $"BEST: {GameManager.Instance.BestDistance}m";
    }

    private void UpdateHUD(int coins, int dist)
    {
        if (coinText != null) coinText.text = $"COINS: {coins}";
        if (distanceText != null) distanceText.text = $"{dist}m";
        if (bestText != null) bestText.text = $"BEST: {GameManager.Instance.BestDistance}m";
    }
}
