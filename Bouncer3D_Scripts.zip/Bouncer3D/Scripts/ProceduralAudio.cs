using UnityEngine;
using System.Collections;

/// <summary>
/// Generates all game sounds procedurally using AudioSource + AnimationCurves.
/// No imported audio files needed. Attach to an empty "ProceduralAudio" GameObject.
/// </summary>
public class ProceduralAudio : MonoBehaviour
{
    public static ProceduralAudio Instance { get; private set; }

    [Header("Volume")]
    [Range(0f, 1f)] public float masterVolume = 0.5f;

    private AudioSource _source;
    private const int SampleRate = 44100;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        _source = gameObject.AddComponent<AudioSource>();
        _source.spatialBlend = 0f;
        _source.volume = masterVolume;
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public void PlayBounce(float impact)
    {
        float freq = Mathf.Lerp(180f, 380f, impact / 15f) + Random.Range(-15f, 15f);
        float dur  = Mathf.Lerp(0.08f, 0.18f, impact / 15f);
        StartCoroutine(PlayTone(freq, WaveType.Sine, dur, masterVolume * 0.7f,
            pitchEnvStart: 1.15f, pitchEnvEnd: 0.8f));
    }

    public void PlayCoin()
    {
        float freq = Random.Range(820f, 960f);
        StartCoroutine(PlayTone(freq, WaveType.Sine, 0.08f, masterVolume * 0.6f));
        StartCoroutine(DelayedTone(0.07f, freq * 1.5f, WaveType.Sine, 0.10f, masterVolume * 0.5f));
    }

    public void PlayDash()
    {
        float freq = Random.Range(350f, 500f);
        StartCoroutine(PlayTone(freq, WaveType.Square, 0.07f, masterVolume * 0.4f,
            pitchEnvStart: 0.8f, pitchEnvEnd: 1.3f));
    }

    public void PlayDeath()
    {
        StartCoroutine(PlayTone(220f, WaveType.Sawtooth, 0.25f, masterVolume * 0.8f,
            pitchEnvStart: 1f, pitchEnvEnd: 0.4f));
        StartCoroutine(DelayedTone(0.18f, 110f, WaveType.Sawtooth, 0.35f, masterVolume * 0.6f,
            pitchEnvStart: 1f, pitchEnvEnd: 0.3f));
    }

    // ── Synthesis ─────────────────────────────────────────────────────────────

    private enum WaveType { Sine, Square, Sawtooth, Triangle }

    private IEnumerator DelayedTone(float delay, float freq, WaveType wave, float duration,
        float vol, float pitchEnvStart = 1f, float pitchEnvEnd = 1f)
    {
        yield return new WaitForSeconds(delay);
        StartCoroutine(PlayTone(freq, wave, duration, vol, pitchEnvStart, pitchEnvEnd));
    }

    private IEnumerator PlayTone(float baseFreq, WaveType wave, float duration, float vol,
        float pitchEnvStart = 1f, float pitchEnvEnd = 1f)
    {
        int samples = Mathf.RoundToInt(SampleRate * duration);
        float[] data = new float[samples];

        for (int i = 0; i < samples; i++)
        {
            float t = (float)i / SampleRate;
            float progress = (float)i / samples;

            // Pitch envelope
            float pitchMult = Mathf.Lerp(pitchEnvStart, pitchEnvEnd, progress);
            float freq = baseFreq * pitchMult;
            float phase = t * freq;

            // Waveform
            float sample = wave switch
            {
                WaveType.Sine      => Mathf.Sin(phase * 2f * Mathf.PI),
                WaveType.Square    => Mathf.Sign(Mathf.Sin(phase * 2f * Mathf.PI)),
                WaveType.Sawtooth  => 2f * (phase - Mathf.Floor(phase + 0.5f)),
                WaveType.Triangle  => 2f * Mathf.Abs(2f * (phase - Mathf.Floor(phase + 0.5f))) - 1f,
                _                  => 0f
            };

            // Amplitude envelope (attack + exponential decay)
            float attack = Mathf.Clamp01(progress * 20f);
            float decay  = Mathf.Pow(1f - progress, 2.5f);
            data[i] = sample * attack * decay * vol;
        }

        AudioClip clip = AudioClip.Create("proc", samples, 1, SampleRate, false);
        clip.SetData(data, 0);

        AudioSource src = gameObject.AddComponent<AudioSource>();
        src.spatialBlend = 0f;
        src.clip = clip;
        src.Play();

        yield return new WaitForSeconds(duration + 0.05f);
        Destroy(src);
        Destroy(clip);
    }
}
