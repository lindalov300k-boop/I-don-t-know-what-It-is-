using UnityEngine;

/// <summary>
/// Attached to each spike prefab.
/// Randomises scale and colour; kills the player on contact.
/// </summary>
[RequireComponent(typeof(MeshRenderer))]
public class ProceduralSpike : MonoBehaviour
{
    private MeshRenderer _mr;

    private void Awake()
    {
        _mr = GetComponent<MeshRenderer>();
    }

    public void Randomise()
    {
        // Jagged size imperfection
        float w = Random.Range(0.18f, 0.32f);
        float h = Random.Range(0.5f, 0.9f);
        float tilt = Random.Range(-8f, 8f);
        transform.localScale = new Vector3(w, h, w * Random.Range(0.8f, 1.1f));
        transform.rotation = Quaternion.Euler(0f, 0f, tilt);

        Color c = ProceduralMaterial.Instance.GetSpikeColor();
        _mr.material = ProceduralMaterial.Instance.CreateSpikeMaterial(c);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        GameManager.Instance?.TriggerDeath();
        ProceduralAudio.Instance?.PlayDeath();
    }
}
