using UnityEngine;

/// <summary>
/// Attached to each platform prefab.
/// Handles randomised appearance and optional moving behaviour.
/// </summary>
[RequireComponent(typeof(MeshRenderer))]
public class ProceduralPlatform : MonoBehaviour
{
    [Header("Size")]
    public float minWidth = 1.2f;
    public float maxWidth = 3.5f;
    public float platformHeight = 0.25f;

    [Header("Movement")]
    [Range(0f, 1f)] public float movingChance = 0.45f;

    public float halfWidth { get; private set; }

    private bool _isMoving;
    private Vector3 _moveAxis;
    private float _moveSpeed;
    private float _moveRange;
    private float _moveAngle;
    private Vector3 _origin;
    private MeshRenderer _mr;

    private void Awake()
    {
        _mr = GetComponent<MeshRenderer>();
    }

    public void Randomise()
    {
        float width = Random.Range(minWidth, maxWidth);
        halfWidth = width * 0.5f;
        float heightVar = Random.Range(-0.05f, 0.05f);
        transform.localScale = new Vector3(width, platformHeight + heightVar, Random.Range(0.55f, 0.8f));

        // Colour
        Color c = ProceduralMaterial.Instance.GetRandomPlatformColor();
        _mr.material = ProceduralMaterial.Instance.CreatePlatformMaterial(c);

        // Decide movement
        float diff = GameManager.Instance != null ? GameManager.Instance.DifficultyFactor : 0f;
        float chance = movingChance + diff * 0.1f;
        _isMoving = Random.value < chance;

        if (_isMoving)
        {
            _moveAxis = Random.value < 0.5f ? Vector3.up : Vector3.right;
            _moveSpeed = Random.Range(0.6f, 1.8f + diff * 0.4f);
            _moveRange = Random.Range(0.8f, 2.2f);
            _moveAngle = Random.Range(0f, Mathf.PI * 2f);
            _origin = transform.position;
        }
    }

    private void Update()
    {
        if (!_isMoving) return;
        if (GameManager.Instance?.State != GameManager.GameState.Playing) return;

        _moveAngle += _moveSpeed * Time.deltaTime;
        transform.position = _origin + _moveAxis * (Mathf.Sin(_moveAngle) * _moveRange);
    }
}
