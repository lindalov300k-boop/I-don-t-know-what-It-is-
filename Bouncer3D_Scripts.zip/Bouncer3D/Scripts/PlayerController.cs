using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(SphereCollider))]
public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 7f;
    public float jumpForce = 9f;
    public float doubleJumpForce = 8f;
    public float dashForce = 14f;
    public float dashDuration = 0.18f;
    public float dashCooldown = 0.5f;

    [Header("Ground Check")]
    public LayerMask groundLayer;
    public float groundCheckRadius = 0.55f;
    public Transform groundCheckPoint;

    [Header("Squish")]
    public float squishLandScale = 1.35f;
    public float squishJumpScale = 0.72f;
    public float squishReturnSpeed = 8f;

    private Rigidbody _rb;
    private SphereCollider _col;
    private bool _onGround;
    private int _jumpsLeft;
    private bool _isDashing;
    private float _dashTimer;
    private float _dashCooldownTimer;
    private float _dashDir;
    private float _lastJumpTime;
    private Vector3 _originalScale;
    private Vector3 _targetScale;

    private void Start()
    {
        _rb = GetComponent<Rigidbody>();
        _col = GetComponent<SphereCollider>();
        _rb.constraints = RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationY;
        _originalScale = transform.localScale;
        _targetScale = _originalScale;
        _jumpsLeft = 2;

        GameManager.Instance?.RegisterPlayer(transform);
    }

    private void Update()
    {
        if (GameManager.Instance?.State != GameManager.GameState.Playing) return;

        CheckGround();
        HandleMovement();
        HandleJump();
        HandleDash();
        UpdateSquish();
        CheckFallDeath();
    }

    private void CheckGround()
    {
        bool wasOnGround = _onGround;
        _onGround = Physics.CheckSphere(groundCheckPoint.position, groundCheckRadius, groundLayer);

        if (!wasOnGround && _onGround)
        {
            float impact = Mathf.Abs(_rb.linearVelocity.y);
            _targetScale = new Vector3(
                _originalScale.x * Mathf.Lerp(1f, squishLandScale, impact / 15f),
                _originalScale.y * Mathf.Lerp(1f, squishJumpScale, impact / 15f),
                _originalScale.z
            );
            ProceduralAudio.Instance?.PlayBounce(impact);
            _jumpsLeft = 2;
        }
    }

    private void HandleMovement()
    {
        if (_isDashing) return;

        float h = 0f;
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) h = -1f;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) h = 1f;

        Vector3 vel = _rb.linearVelocity;
        vel.x = Mathf.Lerp(vel.x, h * moveSpeed, 0.2f);
        _rb.linearVelocity = vel;
    }

    private void HandleJump()
    {
        bool jumpPressed = Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.UpArrow);
        if (!jumpPressed) return;

        if (_onGround)
        {
            DoJump(jumpForce);
            _jumpsLeft = 1;
        }
        else if (_jumpsLeft > 0 && Time.time - _lastJumpTime > 0.15f)
        {
            DoJump(doubleJumpForce);
            _jumpsLeft--;
        }
    }

    private void DoJump(float force)
    {
        Vector3 vel = _rb.linearVelocity;
        vel.y = force;
        _rb.linearVelocity = vel;
        _lastJumpTime = Time.time;
        _targetScale = new Vector3(
            _originalScale.x * squishJumpScale,
            _originalScale.y * squishLandScale,
            _originalScale.z
        );
        ProceduralAudio.Instance?.PlayBounce(force * 0.8f);
    }

    private void HandleDash()
    {
        if (_dashCooldownTimer > 0f)
        {
            _dashCooldownTimer -= Time.deltaTime;
        }

        if (_isDashing)
        {
            _dashTimer -= Time.deltaTime;
            if (_dashTimer <= 0f) _isDashing = false;
            return;
        }

        bool dashLeft  = Input.GetKey(KeyCode.S) && (Input.GetKeyDown(KeyCode.A) || Input.GetKeyDown(KeyCode.LeftArrow));
        bool dashRight = Input.GetKey(KeyCode.S) && (Input.GetKeyDown(KeyCode.D) || Input.GetKeyDown(KeyCode.RightArrow));

        if ((dashLeft || dashRight) && _dashCooldownTimer <= 0f)
        {
            _dashDir = dashLeft ? -1f : 1f;
            Vector3 vel = _rb.linearVelocity;
            vel.x = _dashDir * dashForce;
            _rb.linearVelocity = vel;
            _isDashing = true;
            _dashTimer = dashDuration;
            _dashCooldownTimer = dashCooldown;
            ProceduralAudio.Instance?.PlayDash();
        }
    }

    private void UpdateSquish()
    {
        transform.localScale = Vector3.Lerp(transform.localScale, _targetScale, Time.deltaTime * squishReturnSpeed);
        _targetScale = Vector3.Lerp(_targetScale, _originalScale, Time.deltaTime * squishReturnSpeed);
    }

    private void CheckFallDeath()
    {
        if (transform.position.y < -12f)
            GameManager.Instance?.TriggerDeath();
    }
}
