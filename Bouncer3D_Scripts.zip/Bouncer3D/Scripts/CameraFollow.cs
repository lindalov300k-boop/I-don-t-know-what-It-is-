using UnityEngine;

/// <summary>
/// Side-view camera that follows the player horizontally with vertical tracking and smooth lag.
/// Attach to the Main Camera.
/// </summary>
public class CameraFollow : MonoBehaviour
{
    [Header("Target")]
    public Transform target;

    [Header("Offset")]
    public float xOffset = -4f;       // How far left of centre the player sits
    public float yOffset = 1.5f;      // Base vertical offset
    public float zPosition = -12f;    // 2.5D depth

    [Header("Smoothing")]
    public float horizontalSmooth = 8f;
    public float verticalSmooth   = 4f;

    [Header("Vertical Tracking")]
    public float verticalDeadZone = 1.2f;   // Vertical distance before camera catches up
    public float maxVerticalLead  = 4f;

    private Vector3 _velocity;
    private float _targetY;

    private void LateUpdate()
    {
        if (target == null) return;

        // Horizontal: always track
        float targetX = target.position.x + xOffset;

        // Vertical: only track outside dead zone
        float dy = target.position.y - (transform.position.y - yOffset);
        if (Mathf.Abs(dy) > verticalDeadZone)
            _targetY = Mathf.Clamp(target.position.y + yOffset, yOffset - maxVerticalLead, yOffset + maxVerticalLead);

        float newX = Mathf.Lerp(transform.position.x, targetX, Time.deltaTime * horizontalSmooth);
        float newY = Mathf.Lerp(transform.position.y, _targetY, Time.deltaTime * verticalSmooth);

        transform.position = new Vector3(newX, newY, zPosition);
    }

    private void Start()
    {
        if (target != null)
        {
            _targetY = target.position.y + yOffset;
            transform.position = new Vector3(target.position.x + xOffset, _targetY, zPosition);
        }
    }
}
