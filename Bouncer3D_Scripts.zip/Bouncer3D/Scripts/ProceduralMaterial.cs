using UnityEngine;

/// <summary>
/// Singleton that generates and caches procedural materials using Perlin noise tinting.
/// Attach to an empty "ProceduralMaterial" GameObject.
/// </summary>
public class ProceduralMaterial : MonoBehaviour
{
    public static ProceduralMaterial Instance { get; private set; }

    // ── Palette pools ─────────────────────────────────────────────────────────
    private static readonly Color[] TerrainPalette =
    {
        new Color(0.35f, 0.70f, 0.45f), new Color(0.25f, 0.55f, 0.80f),
        new Color(0.75f, 0.50f, 0.25f), new Color(0.60f, 0.35f, 0.70f),
        new Color(0.80f, 0.65f, 0.25f), new Color(0.35f, 0.65f, 0.75f),
    };
    private static readonly Color[] PlatformPalette =
    {
        new Color(0.90f, 0.45f, 0.45f), new Color(0.45f, 0.75f, 0.90f),
        new Color(0.90f, 0.75f, 0.35f), new Color(0.60f, 0.45f, 0.90f),
        new Color(0.45f, 0.90f, 0.65f), new Color(0.90f, 0.55f, 0.75f),
    };

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    // ── Color pickers ─────────────────────────────────────────────────────────

    public Color GetRandomTerrainColor()   => Tint(TerrainPalette[Random.Range(0, TerrainPalette.Length)]);
    public Color GetRandomPlatformColor()  => Tint(PlatformPalette[Random.Range(0, PlatformPalette.Length)]);
    public Color GetCoinColor()            => Tint(new Color(1f, 0.85f, 0.1f));
    public Color GetSpikeColor()           => Tint(new Color(0.9f, 0.2f, 0.2f));

    private Color Tint(Color base_)
    {
        float drift = 0.12f;
        return new Color(
            Mathf.Clamp01(base_.r + Random.Range(-drift, drift)),
            Mathf.Clamp01(base_.g + Random.Range(-drift, drift)),
            Mathf.Clamp01(base_.b + Random.Range(-drift, drift))
        );
    }

    // ── Material factories ────────────────────────────────────────────────────

    public Material CreateTileMaterial(Color c)
    {
        var mat = new Material(Shader.Find("Standard"));
        mat.color = c;
        ApplyNoiseTex(mat, 0.06f);
        mat.SetFloat("_Glossiness", Random.Range(0.1f, 0.35f));
        return mat;
    }

    public Material CreatePlatformMaterial(Color c)
    {
        var mat = new Material(Shader.Find("Standard"));
        mat.color = c;
        ApplyNoiseTex(mat, 0.08f);
        mat.SetFloat("_Glossiness", Random.Range(0.2f, 0.55f));
        return mat;
    }

    public Material CreateCoinMaterial(Color c)
    {
        var mat = new Material(Shader.Find("Standard"));
        mat.color = c;
        mat.SetFloat("_Glossiness", 0.9f);
        mat.SetFloat("_Metallic", 0.85f);
        return mat;
    }

    public Material CreateSpikeMaterial(Color c)
    {
        var mat = new Material(Shader.Find("Standard"));
        mat.color = c;
        ApplyNoiseTex(mat, 0.1f);
        mat.SetFloat("_Glossiness", 0.6f);
        mat.SetFloat("_Metallic", 0.4f);
        return mat;
    }

    public Material CreateBallMaterial(Color c)
    {
        var mat = new Material(Shader.Find("Standard"));
        mat.color = c;
        mat.SetFloat("_Glossiness", 0.85f);
        mat.SetFloat("_Metallic", 0.1f);
        return mat;
    }

    // ── Perlin noise texture ──────────────────────────────────────────────────

    private void ApplyNoiseTex(Material mat, float strength)
    {
        int size = 64;
        Texture2D tex = new Texture2D(size, size, TextureFormat.RGB24, false);
        float ox = Random.Range(0f, 100f);
        float oy = Random.Range(0f, 100f);

        for (int y = 0; y < size; y++)
        for (int x = 0; x < size; x++)
        {
            float n = Mathf.PerlinNoise(ox + x * 0.15f, oy + y * 0.15f);
            float v = Mathf.Lerp(1f - strength, 1f, n);
            tex.SetPixel(x, y, new Color(v, v, v));
        }
        tex.Apply();
        mat.mainTexture = tex;
    }
}
