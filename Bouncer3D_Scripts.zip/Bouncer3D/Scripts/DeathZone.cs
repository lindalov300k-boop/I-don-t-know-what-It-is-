using UnityEngine;

/// <summary>
/// Place a large flat trigger collider well below the terrain.
/// Any object tagged "Player" entering it triggers death.
/// </summary>
public class DeathZone : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        GameManager.Instance?.TriggerDeath();
        ProceduralAudio.Instance?.PlayDeath();
    }
}
