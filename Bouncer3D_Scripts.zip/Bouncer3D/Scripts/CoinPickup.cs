using UnityEngine;

/// <summary>
/// Attached to each coin prefab.
/// Rotates, bobs, and handles collection on trigger with the player.
/// </summary>
public class CoinPickup : MonoBehaviour
{
    [Header("Animation")]
    public float rotateSpeed = 180f;
    public float bobHeight = 0.18f;
    public float bobSpeed = 2.2f;

    [Header("Collection")]
    public GameObject collectParticlePrefab;

    private Vector3 _origin;
    private float _bobOffset;
    private bool _collected;
    private MeshRenderer _mr;

    private void Awake()
    {
        _mr = GetComponent<MeshRenderer>();
    }

    private void Start()
    {
        _origin = transform.position;
        _bobOffset = Random.Range(0f, Mathf.PI * 2f);
    }

    public void Randomise()
    {
        Color c = ProceduralMaterial.Instance.GetCoinColor();
        if (_mr == null) _mr = GetComponent<MeshRenderer>();
        _mr.material = ProceduralMaterial.Instance.CreateCoinMaterial(c);

        // Slight size variation
        float s = Random.Range(0.18f, 0.25f);
        transform.localScale = new Vector3(s, s, Random.Range(0.04f, 0.07f));
    }

    private void Update()
    {
        if (_collected) return;
        if (GameManager.Instance?.State != GameManager.GameState.Playing) return;

        transform.Rotate(Vector3.up, rotateSpeed * Time.deltaTime, Space.World);

        float bob = Mathf.Sin(Time.time * bobSpeed + _bobOffset) * bobHeight;
        transform.position = _origin + Vector3.up * bob;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (_collected) return;
        if (!other.CompareTag("Player")) return;

        _collected = true;
        GameManager.Instance?.AddCoin();
        ProceduralAudio.Instance?.PlayCoin();

        if (collectParticlePrefab != null)
            Instantiate(collectParticlePrefab, transform.position, Quaternion.identity);

        Destroy(gameObject);
    }
}
