using UnityEngine;

/// <summary>
/// Attached to each terrain tile prefab.
/// Randomises colour, slight scale imperfections, and applies procedural material.
/// </summary>
[RequireComponent(typeof(MeshRenderer))]
public class ProceduralTile : MonoBehaviour
{
    [Header("Size")]
    public float baseWidth = 2f;
    public float baseHeight = 0.5f;
    public float heightVariance = 0.12f;
    public float widthVariance = 0.08f;

    private MeshRenderer _mr;

    private void Awake()
    {
        _mr = GetComponent<MeshRenderer>();
    }

    public void Randomise()
    {
        // Slight scale imperfection
        float w = baseWidth  + Random.Range(-widthVariance,  widthVariance);
        float h = baseHeight + Random.Range(-heightVariance, heightVariance);
        transform.localScale = new Vector3(w, h, Random.Range(0.9f, 1.2f));

        // Random colour from palette
        Color c = ProceduralMaterial.Instance.GetRandomTerrainColor();
        _mr.material = ProceduralMaterial.Instance.CreateTileMaterial(c);
    }
}
