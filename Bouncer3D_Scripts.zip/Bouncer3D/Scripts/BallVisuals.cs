using UnityEngine;

/// <summary>
/// Gives the player sphere a procedural colour and rolling rotation.
/// Attach to the player sphere GameObject alongside PlayerController.
/// </summary>
[RequireComponent(typeof(MeshRenderer))]
public class BallVisuals : MonoBehaviour
{
    [Header("Trail")]
    public TrailRenderer trail;

    private MeshRenderer _mr;
    private Rigidbody _rb;
    private static readonly Color[] BallColors =
    {
        new Color(0.3f, 0.67f, 0.97f),
        new Color(0.97f, 0.42f, 0.42f),
        new Color(0.42f, 0.97f, 0.55f),
        new Color(0.97f, 0.85f, 0.25f),
        new Color(0.8f,  0.4f,  0.97f),
    };

    private void Awake()
    {
        _mr = GetComponent<MeshRenderer>();
        _rb  = GetComponent<Rigidbody>();
    }

    private void Start()
    {
        Color c = BallColors[Random.Range(0, BallColors.Length)];
        _mr.material = ProceduralMaterial.Instance.CreateBallMaterial(c);

        if (trail != null)
        {
            trail.startColor = new Color(c.r, c.g, c.b, 0.5f);
            trail.endColor   = new Color(c.r, c.g, c.b, 0f);
        }
    }

    private void Update()
    {
        // Roll the ball visually based on horizontal velocity
        if (_rb != null)
        {
            float roll = _rb.linearVelocity.x * Time.deltaTime * Mathf.Rad2Deg;
            transform.Rotate(Vector3.forward, -roll, Space.World);
        }
    }
}
