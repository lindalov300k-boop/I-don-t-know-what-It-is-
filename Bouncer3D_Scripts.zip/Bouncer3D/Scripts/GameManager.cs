using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    public enum GameState { Start, Playing, Dead }
    public GameState State { get; private set; } = GameState.Start;

    public int CoinsCollected { get; private set; }
    public int Distance { get; private set; }
    public int BestDistance { get; private set; }
    public float DifficultyFactor { get; private set; }

    public event System.Action OnGameStart;
    public event System.Action OnGameDeath;
    public event System.Action<int> OnCoinCollected;
    public event System.Action<int> OnDistanceUpdated;

    [Header("Difficulty")]
    public float maxDifficultyDistance = 400f;

    private Transform _playerTransform;
    private float _startX;

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
        BestDistance = PlayerPrefs.GetInt("BestDistance", 0);
    }

    private void Update()
    {
        if (State == GameState.Playing && _playerTransform != null)
        {
            int dist = Mathf.Max(0, Mathf.FloorToInt((_playerTransform.position.x - _startX)));
            if (dist != Distance)
            {
                Distance = dist;
                DifficultyFactor = Mathf.Clamp(Distance / maxDifficultyDistance, 0f, 3f);
                OnDistanceUpdated?.Invoke(Distance);
            }
        }

        if ((State == GameState.Start || State == GameState.Dead)
            && (Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Return)))
        {
            RestartGame();
        }
    }

    public void RegisterPlayer(Transform player)
    {
        _playerTransform = player;
        _startX = player.position.x;
        State = GameState.Playing;
        CoinsCollected = 0;
        Distance = 0;
        DifficultyFactor = 0f;
        OnGameStart?.Invoke();
    }

    public void AddCoin()
    {
        CoinsCollected++;
        OnCoinCollected?.Invoke(CoinsCollected);
    }

    public void TriggerDeath()
    {
        if (State != GameState.Playing) return;
        State = GameState.Dead;

        if (Distance > BestDistance)
        {
            BestDistance = Distance;
            PlayerPrefs.SetInt("BestDistance", BestDistance);
        }

        OnGameDeath?.Invoke();
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
