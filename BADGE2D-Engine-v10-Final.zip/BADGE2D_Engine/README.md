# BADGE2D Engine — Basic Atlas Dimensional Game Engine 2D
**Version 10.0 · C++20 · Phases 1–10 Complete**

> A from-scratch 2D game engine with ECS, physics, audio, animation, scene management, an asset pipeline, UI framework, and an ImGui-powered editor.

---

## Quick Start

### Dependencies

| Platform | Install command |
|----------|----------------|
| **Ubuntu/Debian** | `sudo apt install libglfw3-dev libgl1-mesa-dev cmake ninja-build g++-12` |
| **Fedora** | `sudo dnf install glfw-devel mesa-libGL-devel cmake ninja-build gcc-c++` |
| **macOS** | `brew install glfw cmake ninja` |
| **Windows** | Use vcpkg: `vcpkg install glfw3:x64-windows` |

### Third-Party Audio/Image Libraries
```bash
cd thirdparty && bash download_deps.sh && cd ..
```

### Build
```bash
cmake -B build -S . -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
```

### Run Demos
```bash
./build/bin/BADGE2D_PhysicsDemo
./build/bin/BADGE2D_RendererDemo
./build/bin/BADGE2D_InputDemo
```

---

## Phases

| Phase | System | Key APIs |
|-------|--------|---------|
| 1 | Core | `Engine`, `World`, `Logger`, `Profiler`, `JobSystem` |
| 2 | Renderer | `Renderer2D`, `SpriteBatch`, `Texture2D`, `Camera2D` |
| 3 | Physics | `PhysicsWorld`, `PhysicsSystem`, `Joints`, SAT collision |
| 4 | Input | `InputManager`, `ActionMap`, gamepad, combos |
| 5 | Audio | `AudioMixer`, `SoundClip`, `StreamingSource`, spatial audio |
| 6 | Animation | `AnimStateMachine`, `AnimatorSystem`, cross-fade |
| 7 | Scene | `SceneManager`, `SceneSerializer`, `Prefab`, async load |
| 8 | Assets | `AssetManager`, `AssetCache` (LRU), async `AssetLoader` |
| 9 | UI | `UICanvas`, `UIWidgets` (9 types), anchor layout |
| 10 | Editor | `EditorCore`, dockable panels, undo/redo, gizmos |

---

## Master Include

```cpp
#include "BADGE2D.h"    // Everything
using namespace BADGE2D;
```

---

## Minimal Game

```cpp
#include "BADGE2D.h"
using namespace BADGE2D;

class MyGame : public Application {
    void OnInit() override {
        SceneSettings s; s.name = "Level1"; s.id = 1;
        auto scene = new Scene(s);
        scene->OnLoad();
        auto e = scene->CreateEntity("Player");
        scene->AddComponent(e, TransformComponent{{400,300}});
    }
};

int main() { MyGame g; return g.Run(); }
```

---

## VS Code Setup

See `BADGE2D-Setup-Guide.docx` for the complete platform-specific guide
(Windows · Linux · macOS) covering VS Code extensions, launch.json, CMake
configuration, and common troubleshooting.
