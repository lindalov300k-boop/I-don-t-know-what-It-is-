#include <functional>
// ==============================================================================
// UIElement.cpp
// ==============================================================================

#include "UIElement.h"
#include "../renderer/UIRenderer.h"
#include <algorithm>

namespace BADGE2D {

UIElement::UIElement(UIElementID id, std::string name)
    : m_id(id), m_name(std::move(name)) {}

void UIElement::AddChild(std::shared_ptr<UIElement> child) {
    child->m_parent = this;
    m_children.push_back(std::move(child));
    m_dirty = true;
}

void UIElement::RemoveChild(UIElementID id) {
    m_children.erase(std::remove_if(m_children.begin(), m_children.end(),
        [id](const auto& c){ return c->GetID() == id; }), m_children.end());
}

UIElement* UIElement::FindChild(UIElementID id) const {
    for (auto& c : m_children) {
        if (c->GetID() == id) return c.get();
        if (auto* found = c->FindChild(id)) return found;
    }
    return nullptr;
}

UIElement* UIElement::FindByName(const std::string& name) const {
    for (auto& c : m_children) {
        if (c->GetName() == name) return c.get();
        if (auto* found = c->FindByName(name)) return found;
    }
    return nullptr;
}

// ==============================================================================
// Layout
// ==============================================================================
void UIElement::LayoutAll(float screenW, float screenH) {
    OnLayout(0, 0, screenW, screenH);
}

void UIElement::OnLayout(float parentX, float parentY, float parentW, float parentH) {
    // Anchor resolution
    switch (m_anchor) {
        case Anchor::TopLeft:    m_computedX = parentX + m_localX; m_computedY = parentY + m_localY; break;
        case Anchor::TopCenter:  m_computedX = parentX + parentW*0.5f - m_w*0.5f + m_localX; m_computedY = parentY + m_localY; break;
        case Anchor::TopRight:   m_computedX = parentX + parentW - m_w - m_localX; m_computedY = parentY + m_localY; break;
        case Anchor::MidLeft:    m_computedX = parentX + m_localX; m_computedY = parentY + parentH*0.5f - m_h*0.5f + m_localY; break;
        case Anchor::Center:     m_computedX = parentX + parentW*0.5f - m_w*0.5f + m_localX; m_computedY = parentY + parentH*0.5f - m_h*0.5f + m_localY; break;
        case Anchor::MidRight:   m_computedX = parentX + parentW - m_w - m_localX; m_computedY = parentY + parentH*0.5f - m_h*0.5f + m_localY; break;
        case Anchor::BotLeft:    m_computedX = parentX + m_localX; m_computedY = parentY + parentH - m_h - m_localY; break;
        case Anchor::BotCenter:  m_computedX = parentX + parentW*0.5f - m_w*0.5f + m_localX; m_computedY = parentY + parentH - m_h - m_localY; break;
        case Anchor::BotRight:   m_computedX = parentX + parentW - m_w - m_localX; m_computedY = parentY + parentH - m_h - m_localY; break;
        case Anchor::StretchH:   m_computedX = parentX + m_marginL; m_computedY = parentY + m_localY; m_w = parentW - m_marginL - m_marginR; break;
        case Anchor::StretchV:   m_computedX = parentX + m_localX; m_computedY = parentY + m_marginT; m_h = parentH - m_marginT - m_marginB; break;
        case Anchor::StretchFull:m_computedX = parentX + m_marginL; m_computedY = parentY + m_marginT; m_w = parentW - m_marginL - m_marginR; m_h = parentH - m_marginT - m_marginB; break;
    }
    m_dirty = false;

    // Layout children
    for (auto& child : m_children)
        child->OnLayout(m_computedX + m_padding, m_computedY + m_padding,
                        m_w - m_padding*2, m_h - m_padding*2);
}

// ==============================================================================
// Update
// ==============================================================================
void UIElement::OnUpdate(float dt) {
    if (!m_visible || !m_enabled) return;
    UpdateChildren(dt);
}

void UIElement::UpdateChildren(float dt) {
    for (auto& c : m_children) c->OnUpdate(dt);
}

// ==============================================================================
// Render
// ==============================================================================
void UIElement::OnRender(UIRenderer& renderer) {
    if (!m_visible) return;
    RenderBackground(renderer);
    RenderChildren(renderer);
}

void UIElement::RenderBackground(UIRenderer& renderer) {
    if (m_bgColor.a <= 0.001f) return;
    renderer.DrawRect(m_computedX, m_computedY, m_w, m_h,
                      m_bgColor, m_borderRadius, m_borderColor, m_borderWidth);
}

void UIElement::RenderChildren(UIRenderer& renderer) {
    for (auto& c : m_children) c->OnRender(renderer);
}

// ==============================================================================
// Input
// ==============================================================================
bool UIElement::OnMouseEvent(float mx, float my, bool pressed) {
    if (!m_visible || !m_enabled || !m_interactable) return false;

    bool inside = GetRect().Contains(mx, my);
    UIState prev = m_state;

    if (inside) {
        if (pressed) {
            if (m_state != UIState::Pressed) {
                m_state = UIState::Pressed;
                if (OnClick) OnClick();
            }
        } else {
            if (prev == UIState::Normal && OnHoverEnter) OnHoverEnter();
            m_state = UIState::Hovered;
        }
    } else {
        if (prev != UIState::Normal && OnHoverExit) OnHoverExit();
        m_state = UIState::Normal;
    }

    // Route to children (in reverse order — topmost first)
    RouteMouseEvent(mx, my, pressed);
    return inside;
}

bool UIElement::RouteMouseEvent(float mx, float my, bool pressed) {
    for (int i = (int)m_children.size()-1; i >= 0; --i) {
        if (m_children[i]->OnMouseEvent(mx, my, pressed)) return true;
    }
    return false;
}

} // namespace BADGE2D
