#pragma once
// ==============================================================================
// UIElement.h — Base class for all retained-mode UI elements
// Provides parent/child hierarchy, layout, input routing, and rendering.
// ==============================================================================

#include "../UITypes.h"
#include <vector>
#include <memory>
#include <string>
#include <functional>

namespace BADGE2D {

class UICanvas;
class UIRenderer;

// ==============================================================================
// UIElement
// ==============================================================================
class UIElement {
public:
    explicit UIElement(UIElementID id, std::string name = "");
    virtual ~UIElement() = default;

    // ---- Hierarchy ----
    void             AddChild   (std::shared_ptr<UIElement> child);
    void             RemoveChild(UIElementID id);
    UIElement*       FindChild  (UIElementID id)            const;
    UIElement*       FindByName (const std::string& name)   const;
    UIElement*       GetParent  ()                          const { return m_parent; }
    const std::vector<std::shared_ptr<UIElement>>& GetChildren() const { return m_children; }

    // ---- Position / size ----
    void     SetPosition(float x, float y)          { m_localX = x; m_localY = y; m_dirty = true; }
    void     SetSize    (float w, float h)          { m_w = w; m_h = h; m_dirty = true; }
    void     SetAnchor  (Anchor a)                  { m_anchor = a; m_dirty = true; }
    void     SetPivot   (float px, float py)        { m_pivotX = px; m_pivotY = py; }
    void     SetPadding (float p)                   { m_padding = p; m_dirty = true; }
    void     SetMargin  (float l, float t, float r, float b) {
        m_marginL=l; m_marginT=t; m_marginR=r; m_marginB=b; m_dirty=true;
    }

    float    GetX()     const { return m_computedX; }
    float    GetY()     const { return m_computedY; }
    float    GetW()     const { return m_w; }
    float    GetH()     const { return m_h; }
    UIRect   GetRect()  const { return { m_computedX, m_computedY, m_w, m_h }; }

    // ---- Visibility / interaction ----
    void  SetVisible  (bool v)  { m_visible   = v; }
    void  SetEnabled  (bool e)  { m_enabled   = e; }
    void  SetInteractable(bool i){ m_interactable = i; }
    bool  IsVisible   ()  const { return m_visible; }
    bool  IsEnabled   ()  const { return m_enabled; }
    bool  IsHovered   ()  const { return m_state == UIState::Hovered; }
    bool  IsPressed   ()  const { return m_state == UIState::Pressed; }

    // ---- Style ----
    void  SetBackgroundColor(const Color& c) { m_bgColor = c; }
    void  SetForegroundColor(const Color& c) { m_fgColor = c; }
    void  SetBorderColor    (const Color& c) { m_borderColor = c; }
    void  SetBorderRadius   (float r)        { m_borderRadius = r; }
    void  SetBorderWidth    (float w)        { m_borderWidth  = w; }
    void  SetOpacity        (float o)        { m_opacity      = o; }

    // ---- Identity ----
    UIElementID        GetID()   const { return m_id;   }
    const std::string& GetName() const { return m_name; }
    UIState            GetState()const { return m_state; }

    // ---- Callbacks ----
    std::function<void()>                    OnClick;
    std::function<void()>                    OnHoverEnter;
    std::function<void()>                    OnHoverExit;
    std::function<void(float x, float y)>   OnMouseMove;

    // ---- Virtual interface ----
    virtual void OnLayout  (float parentX, float parentY, float parentW, float parentH);
    virtual void OnUpdate  (float dt);
    virtual void OnRender  (UIRenderer& renderer);
    virtual bool OnMouseEvent(float mx, float my, bool pressed);

    // ---- Layout pass ----
    void  LayoutAll(float screenW, float screenH);
    void  MarkDirty() { m_dirty = true; }

    // Typed traversal for widgets (used by UICanvas::FeedChar, etc.)
    template<typename T>
    void Each(std::function<void(T&)> fn) {
        if (T* typed = dynamic_cast<T*>(this)) fn(*typed);
        for (auto& child : m_children) child->Each<T>(fn);
    }

protected:
    void RenderBackground(UIRenderer& renderer);
    void RenderChildren  (UIRenderer& renderer);
    void UpdateChildren  (float dt);
    bool RouteMouseEvent (float mx, float my, bool pressed);

    UIElementID   m_id;
    std::string   m_name;
    UIElement*    m_parent     = nullptr;
    std::vector<std::shared_ptr<UIElement>> m_children;

    float  m_localX = 0, m_localY = 0;
    float  m_w = 100, m_h = 30;
    float  m_computedX = 0, m_computedY = 0;
    float  m_pivotX = 0, m_pivotY = 0;
    float  m_padding = 0;
    float  m_marginL = 0, m_marginT = 0, m_marginR = 0, m_marginB = 0;
    Anchor m_anchor  = Anchor::TopLeft;

    Color  m_bgColor     = {0, 0, 0, 0};
    Color  m_fgColor     = {1, 1, 1, 1};
    Color  m_borderColor = {0, 0, 0, 0};
    float  m_borderRadius = 0;
    float  m_borderWidth  = 0;
    float  m_opacity      = 1.0f;

    UIState  m_state        = UIState::Normal;
    bool     m_visible      = true;
    bool     m_enabled      = true;
    bool     m_interactable = true;
    bool     m_dirty        = true;
};

} // namespace BADGE2D
