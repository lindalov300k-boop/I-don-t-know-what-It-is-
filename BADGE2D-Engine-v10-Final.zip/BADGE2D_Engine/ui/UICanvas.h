#pragma once
// ==============================================================================
// UICanvas.h — Root UI container and IModule
// Owns the element tree, routes input, drives layout + render.
// ==============================================================================

#include "../engine/ModuleSystem/ModuleInterface.h"
#include "UITypes.h"
#include "canvas/UIElement.h"
#include "renderer/UIRenderer.h"
#include "widgets/UIWidgets.h"
#include <memory>
#include <unordered_map>
#include <functional>
#include <string>

namespace BADGE2D {

// ==============================================================================
// UICanvas
// ==============================================================================
class UICanvas : public IModule {
public:
    bool        Initialize()          override;
    void        Shutdown  ()          override;
    void        Update    (double dt) override;
    void        Render    ()          override;
    const char* GetName   ()    const override { return "UICanvas"; }
    uint32_t    GetInitOrder() const  override { return (uint32_t)ModuleInitOrder::UI; }

    static UICanvas& Get();

    // ---- Screen ----
    void SetScreenSize(float w, float h) { m_screenW = w; m_screenH = h; }

    // ---- Input ----
    void FeedMousePos  (float x, float y)    { m_mx = x; m_my = y; }
    void FeedMousePress(bool pressed)        { m_pressed = pressed; }
    void FeedChar      (char c);
    void FeedKey       (int key);

    // ---- Theme ----
    void           SetTheme(const UITheme& t) { m_theme = t; }
    const UITheme& GetTheme()           const { return m_theme; }

    // ---- Element factory ----
    // Create and return a typed element. Caller may add it to any parent.
    template<typename T, typename... Args>
    std::shared_ptr<T> Create(Args&&... args) {
        UIElementID id = NextID();
        auto elem = std::make_shared<T>(id, std::forward<Args>(args)...);
        m_registry[id] = elem;
        return elem;
    }

    // Create and add to canvas root
    template<typename T, typename... Args>
    std::shared_ptr<T> Add(Args&&... args) {
        auto e = Create<T>(std::forward<Args>(args)...);
        m_root->AddChild(e);
        return e;
    }

    // Convenience factories
    std::shared_ptr<UILabel>      Label    (const std::string& text, float x, float y, float w=200, float h=24);
    std::shared_ptr<UIButton>     Button   (const std::string& label, float x, float y, float w=120, float h=32);
    std::shared_ptr<UICheckbox>   Checkbox (const std::string& label, float x, float y);
    std::shared_ptr<UISlider>     Slider   (float x, float y, float w=200, float h=20);
    std::shared_ptr<UIProgressBar>ProgressBar(float x, float y, float w=200, float h=16);
    std::shared_ptr<UIPanel>      Panel    (const std::string& title, float x, float y, float w=300, float h=200);
    std::shared_ptr<UITextInput>  TextInput(const std::string& placeholder, float x, float y, float w=200, float h=28);

    // ---- Element access ----
    UIElement* FindElement(UIElementID id)          const;
    UIElement* FindByName (const std::string& name) const;
    void       Remove     (UIElementID id);
    void       RemoveAll  ();

    int  GetElementCount() const { return (int)m_registry.size(); }

    // ---- Root ----
    UIElement& GetRoot() { return *m_root; }

private:
    UICanvas() = default;

    UIElementID NextID() { return ++m_nextID; }

    std::shared_ptr<UIElement>                           m_root;
    std::unordered_map<UIElementID, std::shared_ptr<UIElement>> m_registry;

    UITheme  m_theme;
    float    m_screenW  = 1280, m_screenH = 720;
    float    m_mx = 0, m_my = 0;
    bool     m_pressed  = false;
    bool     m_prevPressed = false;

    UIElementID m_nextID = 0;
    bool        m_initialized = false;
};

} // namespace BADGE2D
