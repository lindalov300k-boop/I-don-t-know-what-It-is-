// ==============================================================================
// UICanvas.cpp
// ==============================================================================

#include "UICanvas.h"
#include "../engine/Logging/Logger.h"

namespace BADGE2D {

UICanvas& UICanvas::Get() {
    static UICanvas instance;
    return instance;
}

bool UICanvas::Initialize() {
    if (m_initialized) return true;
    m_root = std::make_shared<UIElement>(NextID(), "Root");
    m_root->SetSize(m_screenW, m_screenH);
    UIRenderer::Get().Initialize(nullptr);  // SpriteBatch set later by RenderDevice
    m_initialized = true;
    LOG_INFO("[UICanvas] Initialized.");
    return true;
}

void UICanvas::Shutdown() {
    RemoveAll();
    m_initialized = false;
    LOG_INFO("[UICanvas] Shutdown.");
}

void UICanvas::Update(double dt) {
    if (!m_initialized) return;
    m_root->SetSize(m_screenW, m_screenH);
    m_root->LayoutAll(m_screenW, m_screenH);
    m_root->OnUpdate((float)dt);

    bool currentPressed = m_pressed;
    m_root->OnMouseEvent(m_mx, m_my, currentPressed);
    m_prevPressed = currentPressed;
}

void UICanvas::Render() {
    if (!m_initialized) return;
    UIRenderer::Get().BeginFrame(m_screenW, m_screenH);
    m_root->OnRender(UIRenderer::Get());
    UIRenderer::Get().EndFrame();
}

void UICanvas::FeedChar(char c) {
    // Route to focused TextInput
    m_root->Each<UITextInput>([c](UITextInput& ti) {
        if (ti.IsFocused()) ti.FeedChar(c);
    });
}

void UICanvas::FeedKey(int key) {
    m_root->Each<UITextInput>([key](UITextInput& ti) {
        if (ti.IsFocused()) ti.FeedKey(key);
    });
}

UIElement* UICanvas::FindElement(UIElementID id) const {
    auto it = m_registry.find(id);
    return (it != m_registry.end()) ? it->second.get() : nullptr;
}

UIElement* UICanvas::FindByName(const std::string& name) const {
    return m_root->FindByName(name);
}

void UICanvas::Remove(UIElementID id) {
    m_registry.erase(id);
    m_root->RemoveChild(id);
}

void UICanvas::RemoveAll() {
    m_registry.clear();
    m_root = std::make_shared<UIElement>(NextID(), "Root");
}

// ==============================================================================
// Convenience factories
// ==============================================================================
std::shared_ptr<UILabel> UICanvas::Label(const std::string& text, float x, float y, float w, float h) {
    auto e = Add<UILabel>(text);
    e->SetPosition(x, y); e->SetSize(w, h);
    return e;
}

std::shared_ptr<UIButton> UICanvas::Button(const std::string& label, float x, float y, float w, float h) {
    auto e = Add<UIButton>(label);
    e->SetPosition(x, y); e->SetSize(w, h);
    return e;
}

std::shared_ptr<UICheckbox> UICanvas::Checkbox(const std::string& label, float x, float y) {
    auto e = Add<UICheckbox>(label);
    e->SetPosition(x, y); e->SetSize(180, 24);
    return e;
}

std::shared_ptr<UISlider> UICanvas::Slider(float x, float y, float w, float h) {
    auto e = Add<UISlider>();
    e->SetPosition(x, y); e->SetSize(w, h);
    return e;
}

std::shared_ptr<UIProgressBar> UICanvas::ProgressBar(float x, float y, float w, float h) {
    auto e = Add<UIProgressBar>();
    e->SetPosition(x, y); e->SetSize(w, h);
    return e;
}

std::shared_ptr<UIPanel> UICanvas::Panel(const std::string& title, float x, float y, float w, float h) {
    auto e = Add<UIPanel>(title);
    e->SetPosition(x, y); e->SetSize(w, h);
    return e;
}

std::shared_ptr<UITextInput> UICanvas::TextInput(const std::string& ph, float x, float y, float w, float h) {
    auto e = Add<UITextInput>(ph);
    e->SetPosition(x, y); e->SetSize(w, h);
    return e;
}

} // namespace BADGE2D
