// ==============================================================================
// UIRenderer.cpp
// ==============================================================================

#include "UIRenderer.h"
#include "../../renderer/sprites/SpriteBatch.h"
#include "../../utilities/Math/MathUtils.h"
#include <cmath>
#include <algorithm>

namespace BADGE2D {

UIRenderer& UIRenderer::Get() {
    static UIRenderer instance;
    return instance;
}

void UIRenderer::Initialize(SpriteBatch* batch) {
    m_batch = batch;
}

void UIRenderer::BeginFrame(float screenW, float screenH) {
    m_screenW = screenW;
    m_screenH = screenH;
    while (!m_clipStack.empty()) m_clipStack.pop();
}

void UIRenderer::EndFrame() {}

// ==============================================================================
// DrawRect — renders a coloured quad via SpriteBatch white pixel
// Border radius is approximated by drawing 9-slice geometry.
// ==============================================================================
void UIRenderer::DrawRect(float x, float y, float w, float h,
                            const Color& fill,
                            float /*borderRadius*/,
                            const Color& border,
                            float borderWidth) {
    if (!m_batch) return;
    if (fill.a > 0.001f)
        m_batch->DrawQuad({x, y}, {w, h}, nullptr, fill);

    if (borderWidth > 0.001f && border.a > 0.001f) {
        m_batch->DrawQuad({x,         y},              {w,          borderWidth}, nullptr, border);
        m_batch->DrawQuad({x,         y+h-borderWidth},{w,          borderWidth}, nullptr, border);
        m_batch->DrawQuad({x,         y},              {borderWidth, h},          nullptr, border);
        m_batch->DrawQuad({x+w-borderWidth, y},        {borderWidth, h},          nullptr, border);
    }
}

void UIRenderer::DrawCircle(float cx, float cy, float radius, const Color& fill) {
    if (!m_batch) return;
    // Approximate circle with square (SpriteBatch doesn't have circle draw)
    // A full circle primitive would require custom geometry or a circle shader
    m_batch->DrawQuad({cx-radius, cy-radius}, {radius*2, radius*2}, nullptr, fill);
}

void UIRenderer::DrawLine(float x0, float y0, float x1, float y1,
                            const Color& color, float thickness) {
    if (!m_batch) return;
    float dx = x1-x0, dy = y1-y0;
    float len = std::sqrt(dx*dx+dy*dy);
    if (len < 0.001f) return;
    // Approximate with a thin quad
    m_batch->DrawQuad(x0, y0, len, thickness, nullptr, color);
}

void UIRenderer::DrawTexturedRect(float x, float y, float w, float h,
                                    Texture2D* texture, const Color& tint,
                                    float u0, float v0, float u1, float v1) {
    if (!m_batch) return;
    Rect2D uvRect{u0, v0, u1-u0, v1-v0};
    m_batch->DrawSubTexture({x,y},{w,h}, texture, uvRect, tint);
}

// ==============================================================================
// DrawText — bitmap font via SpriteBatch (placeholder — real glyph atlas needed)
// For now, draws one coloured pixel quad per visible character at a fixed size.
// A proper glyph atlas would be wired here from a FontAsset.
// ==============================================================================
void UIRenderer::DrawText(const std::string& text, float x, float y,
                            float fontSize, const Color& color, HAlign align) {
    if (!m_batch || text.empty()) return;
    float charW  = fontSize * 0.6f;
    float startX = x;
    if (align == HAlign::Center) startX -= MeasureTextWidth(text, fontSize) * 0.5f;
    if (align == HAlign::Right)  startX -= MeasureTextWidth(text, fontSize);

    float cx = startX;
    for (char c : text) {
        if (c == '\n') { cx = startX; y += fontSize + 2; continue; }
        // Draw glyph placeholder (1×1 scaled quad) — actual glyph atlas would sample here
        m_batch->DrawQuad({cx, y}, {charW*0.85f, fontSize*0.9f}, nullptr, color);
        cx += charW;
    }
}

void UIRenderer::DrawTextCentered(const std::string& text, float cx, float cy,
                                    float fontSize, const Color& color) {
    float tw = MeasureTextWidth(text, fontSize);
    DrawText(text, cx - tw*0.5f, cy - fontSize*0.5f, fontSize, color, HAlign::Left);
}

float UIRenderer::MeasureTextWidth(const std::string& text, float fontSize) const {
    return text.size() * fontSize * 0.6f;
}

// ==============================================================================
// Clip
// ==============================================================================
void UIRenderer::BeginClip(float x, float y, float w, float h) {
    m_clipStack.push({x, y, w, h});
    if (m_batch) m_batch->SetScissor((int)x, (int)y, (int)w, (int)h);
}

void UIRenderer::EndClip() {
    if (!m_clipStack.empty()) m_clipStack.pop();
    if (!m_clipStack.empty()) {
        auto& r = m_clipStack.top();
        if (m_batch) m_batch->SetScissor((int)r.x, (int)r.y, (int)r.w, (int)r.h);
    } else {
        if (m_batch) m_batch->ClearScissor();
    }
}

} // namespace BADGE2D
