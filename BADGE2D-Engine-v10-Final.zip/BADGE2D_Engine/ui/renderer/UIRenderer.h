#pragma once
// ==============================================================================
// UIRenderer.h — Thin UI draw layer on top of SpriteBatch
// All UI rendering goes through here: rects, text, textured quads, clips.
// ==============================================================================

#include "../UITypes.h"
#include "../../renderer/sprites/SpriteBatch.h"
#include "../../renderer/textures/Texture2D.h"
#include <stack>
#include <string>

namespace BADGE2D {

class UIRenderer {
public:
    static UIRenderer& Get();

    void Initialize(SpriteBatch* batch);
    void BeginFrame(float screenW, float screenH);
    void EndFrame();

    // ---- Primitives ----
    void DrawRect(float x, float y, float w, float h,
                  const Color& fill,
                  float borderRadius  = 0.0f,
                  const Color& border = {0,0,0,0},
                  float borderWidth   = 0.0f);

    void DrawCircle(float cx, float cy, float radius, const Color& fill);

    void DrawLine(float x0, float y0, float x1, float y1,
                  const Color& color, float thickness = 1.0f);

    void DrawTexturedRect(float x, float y, float w, float h,
                          Texture2D* texture, const Color& tint = {1,1,1,1},
                          float u0=0, float v0=0, float u1=1, float v1=1);

    // ---- Text ----
    void DrawText(const std::string& text,
                  float x, float y,
                  float fontSize,
                  const Color& color,
                  HAlign align = HAlign::Left);

    void DrawTextCentered(const std::string& text,
                          float cx, float cy,
                          float fontSize,
                          const Color& color);

    float MeasureTextWidth(const std::string& text, float fontSize) const;

    // ---- Clip regions ----
    void BeginClip(float x, float y, float w, float h);
    void EndClip();

    // ---- Screen ----
    float GetScreenW() const { return m_screenW; }
    float GetScreenH() const { return m_screenH; }

private:
    UIRenderer() = default;

    SpriteBatch*       m_batch    = nullptr;
    float              m_screenW  = 1280;
    float              m_screenH  = 720;

    struct ClipRect { float x, y, w, h; };
    std::stack<ClipRect> m_clipStack;
};

} // namespace BADGE2D
