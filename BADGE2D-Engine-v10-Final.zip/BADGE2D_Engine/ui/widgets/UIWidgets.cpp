// ==============================================================================
// UIWidgets.cpp
// ==============================================================================

#include "UIWidgets.h"
#include "../renderer/UIRenderer.h"
#include <cmath>
#include <algorithm>
#include <sstream>
#include <iomanip>

namespace BADGE2D {

// ==============================================================================
// UILabel
// ==============================================================================
UILabel::UILabel(UIElementID id, const std::string& text)
    : UIElement(id, "Label"), m_text(text) {
    m_bgColor = {0,0,0,0};
}

void UILabel::OnRender(UIRenderer& renderer) {
    if (!m_visible) return;
    float tx = m_computedX;
    float ty = m_computedY;
    switch (m_hAlign) {
        case HAlign::Center: tx += m_w * 0.5f; break;
        case HAlign::Right:  tx += m_w;        break;
        default: break;
    }
    switch (m_vAlign) {
        case VAlign::Center: ty += m_h * 0.5f - m_fontSize * 0.5f; break;
        case VAlign::Bottom: ty += m_h - m_fontSize;                break;
        default: break;
    }
    Color c = m_enabled ? m_fgColor : Color{0.5f,0.5f,0.5f,0.6f};
    renderer.DrawText(m_text, tx, ty, m_fontSize, c, m_hAlign);
    RenderChildren(renderer);
}

// ==============================================================================
// UIButton
// ==============================================================================
UIButton::UIButton(UIElementID id, const std::string& label)
    : UIElement(id, "Button"), m_label(label) {
    m_borderRadius = 4.0f;
    m_borderWidth  = 1.0f;
}

bool UIButton::OnMouseEvent(float mx, float my, bool pressed) {
    bool inside = GetRect().Contains(mx, my);
    if (!inside) { m_state = UIState::Normal; return false; }
    if (!m_enabled) { m_state = UIState::Disabled; return true; }

    bool wasPressed = (m_state == UIState::Pressed);
    m_state = pressed ? UIState::Pressed : UIState::Hovered;
    if (wasPressed && !pressed && OnClick) OnClick();
    return true;
}

void UIButton::OnRender(UIRenderer& renderer) {
    if (!m_visible) return;

    Color bg;
    switch (m_state) {
        case UIState::Pressed:  bg = {0.20f,0.48f,0.90f,1.0f}; break;
        case UIState::Hovered:  bg = {0.35f,0.35f,0.40f,0.95f};break;
        case UIState::Disabled: bg = {0.25f,0.25f,0.25f,0.6f}; break;
        default:                bg = {0.22f,0.22f,0.26f,0.95f};break;
    }
    Color border = (m_state==UIState::Pressed)
                 ? Color{0.26f,0.59f,0.98f,1.0f}
                 : Color{0.45f,0.45f,0.50f,0.80f};

    renderer.DrawRect(m_computedX, m_computedY, m_w, m_h, bg, m_borderRadius, border, m_borderWidth);
    Color tc = m_enabled ? Color{0.95f,0.95f,0.95f,1.0f} : Color{0.5f,0.5f,0.5f,1.0f};
    renderer.DrawTextCentered(m_label, m_computedX + m_w*0.5f, m_computedY + m_h*0.5f, m_fontSize, tc);
    RenderChildren(renderer);
}

// ==============================================================================
// UICheckbox
// ==============================================================================
UICheckbox::UICheckbox(UIElementID id, const std::string& label)
    : UIElement(id, "Checkbox"), m_label(label) {}

bool UICheckbox::OnMouseEvent(float mx, float my, bool pressed) {
    bool inside = GetRect().Contains(mx, my);
    if (!inside) { m_state = UIState::Normal; m_prevPressed = false; return false; }
    if (!m_enabled) return true;
    m_state = pressed ? UIState::Pressed : UIState::Hovered;
    if (m_prevPressed && !pressed) {
        m_checked = !m_checked;
        if (OnChanged) OnChanged(m_checked);
    }
    m_prevPressed = pressed;
    return true;
}

void UICheckbox::OnRender(UIRenderer& renderer) {
    if (!m_visible) return;
    float boxSize = m_h * 0.8f;
    float bx = m_computedX + 2;
    float by = m_computedY + (m_h - boxSize) * 0.5f;

    Color bg     = (m_state==UIState::Hovered) ? Color{0.35f,0.35f,0.40f,0.9f} : Color{0.18f,0.18f,0.22f,0.95f};
    Color border = Color{0.45f,0.45f,0.50f,0.8f};
    renderer.DrawRect(bx, by, boxSize, boxSize, bg, 3.0f, border, 1.0f);

    if (m_checked) {
        // Draw checkmark
        renderer.DrawText("✓", bx+1, by+1, boxSize-2, {0.26f,0.79f,0.35f,1.0f}, HAlign::Center);
    }
    if (!m_label.empty()) {
        renderer.DrawText(m_label, bx + boxSize + 6, m_computedY + m_h*0.5f - 7.0f,
                          14.0f, {0.95f,0.95f,0.95f,1.0f}, HAlign::Left);
    }
    RenderChildren(renderer);
}

// ==============================================================================
// UISlider
// ==============================================================================
UISlider::UISlider(UIElementID id) : UIElement(id, "Slider") {}

bool UISlider::OnMouseEvent(float mx, float my, bool pressed) {
    bool inside = GetRect().Contains(mx, my);
    if (!m_enabled) return inside;

    if (pressed && inside) m_dragging = true;
    if (!pressed) m_dragging = false;

    if (m_dragging) {
        float t     = std::clamp((mx - m_computedX) / m_w, 0.0f, 1.0f);
        float newVal = m_min + t * (m_max - m_min);
        if (m_step > 0) newVal = std::round(newVal / m_step) * m_step;
        if (newVal != m_value) {
            m_value = newVal;
            if (OnValueChanged) OnValueChanged(m_value);
        }
        m_state = UIState::Pressed;
        return true;
    }
    m_state = inside ? UIState::Hovered : UIState::Normal;
    return inside;
}

void UISlider::OnRender(UIRenderer& renderer) {
    if (!m_visible) return;
    float trackH  = 4.0f;
    float ty      = m_computedY + m_h * 0.5f - trackH * 0.5f;
    float filled  = GetNormalized() * m_w;

    // Track bg
    renderer.DrawRect(m_computedX, ty, m_w, trackH, {0.25f,0.25f,0.28f,1.0f}, 2.0f);
    // Filled portion
    if (filled > 0)
        renderer.DrawRect(m_computedX, ty, filled, trackH, {0.26f,0.59f,0.98f,1.0f}, 2.0f);
    // Thumb
    float thumbR = 7.0f;
    float tx = m_computedX + filled;
    Color thumbC = (m_state==UIState::Pressed) ? Color{0.20f,0.48f,0.90f,1.0f} : Color{0.85f,0.85f,0.90f,1.0f};
    renderer.DrawCircle(tx, m_computedY + m_h*0.5f, thumbR, thumbC);

    if (!m_label.empty()) {
        std::ostringstream oss;
        oss << m_label << ": " << std::setprecision(2) << m_value;
        renderer.DrawText(oss.str(), m_computedX, m_computedY, 12.0f, {0.7f,0.7f,0.7f,1.0f});
    }
}

// ==============================================================================
// UIProgressBar
// ==============================================================================
UIProgressBar::UIProgressBar(UIElementID id) : UIElement(id, "ProgressBar") {}

void UIProgressBar::OnRender(UIRenderer& renderer) {
    if (!m_visible) return;
    renderer.DrawRect(m_computedX, m_computedY, m_w, m_h, {0.18f,0.18f,0.22f,0.95f}, 3.0f,
                      {0.35f,0.35f,0.40f,0.8f}, 1.0f);
    if (m_progress > 0.001f)
        renderer.DrawRect(m_computedX+1, m_computedY+1, (m_w-2)*m_progress, m_h-2, m_fillColor, 3.0f);
    if (m_showText) {
        std::ostringstream oss;
        oss << (int)(m_progress*100) << "%";
        renderer.DrawTextCentered(oss.str(), m_computedX+m_w*0.5f, m_computedY+m_h*0.5f, 12.0f,
                                  {0.95f,0.95f,0.95f,1.0f});
    }
}

// ==============================================================================
// UIImage
// ==============================================================================
UIImage::UIImage(UIElementID id) : UIElement(id, "Image") {}

void UIImage::OnRender(UIRenderer& renderer) {
    if (!m_visible) return;
    if (m_texture)
        renderer.DrawTexturedRect(m_computedX, m_computedY, m_w, m_h, m_texture.get(), m_tint);
    else
        renderer.DrawRect(m_computedX, m_computedY, m_w, m_h, {0.3f,0.3f,0.3f,0.5f}, 0);
    RenderChildren(renderer);
}

// ==============================================================================
// UIPanel
// ==============================================================================
UIPanel::UIPanel(UIElementID id, const std::string& title)
    : UIElement(id, "Panel"), m_title(title) {
    m_borderRadius = 6.0f;
    m_borderWidth  = 1.0f;
}

void UIPanel::OnLayout(float px, float py, float pw, float ph) {
    UIElement::OnLayout(px, py, pw, ph);
    float contentY = m_computedY + (m_title.empty() ? 0 : m_titleH) + m_padding;
    float contentH = m_h - (m_title.empty() ? 0 : m_titleH) - m_padding * 2;
    for (auto& c : m_children)
        c->OnLayout(m_computedX + m_padding, contentY, m_w - m_padding*2, contentH);
}

void UIPanel::OnRender(UIRenderer& renderer) {
    if (!m_visible) return;
    Color bg     = {0.14f,0.14f,0.17f,0.95f};
    Color border = {0.35f,0.35f,0.40f,0.80f};
    renderer.DrawRect(m_computedX, m_computedY, m_w,
                      m_collapsed ? m_titleH : m_h, bg, m_borderRadius, border, m_borderWidth);

    if (!m_title.empty()) {
        Color titleBg = {0.18f,0.18f,0.22f,0.97f};
        renderer.DrawRect(m_computedX, m_computedY, m_w, m_titleH, titleBg, m_borderRadius, {0,0,0,0}, 0);
        renderer.DrawText(m_title, m_computedX+8, m_computedY+4, 14.0f, {0.9f,0.9f,0.95f,1.0f});
        if (m_collapsible) {
            std::string arrow = m_collapsed ? "▶" : "▼";
            renderer.DrawText(arrow, m_computedX+m_w-20, m_computedY+4, 12.0f, {0.7f,0.7f,0.7f,1.0f});
        }
    }
    if (!m_collapsed) RenderChildren(renderer);
}

bool UIPanel::OnMouseEvent(float mx, float my, bool pressed) {
    if (!m_visible || !m_enabled) return false;
    bool inPanel = GetRect().Contains(mx, my);

    // Title bar click — collapse or drag
    if (!m_title.empty()) {
        UIRect titleRect = { m_computedX, m_computedY, m_w, m_titleH };
        if (titleRect.Contains(mx, my)) {
            if (pressed) {
                if (m_collapsible) {
                    static bool lastPressed = false;
                    if (!lastPressed) m_collapsed = !m_collapsed;
                    lastPressed = true;
                } else if (m_draggable) {
                    m_dragging  = true;
                    m_dragOffX  = mx - m_computedX;
                    m_dragOffY  = my - m_computedY;
                }
            } else {
                m_dragging = false;
            }
        }
    }

    if (m_dragging && pressed) {
        m_localX = mx - m_dragOffX;
        m_localY = my - m_dragOffY;
        m_computedX = m_localX;
        m_computedY = m_localY;
    }

    if (!m_collapsed) RouteMouseEvent(mx, my, pressed);
    return inPanel;
}

// ==============================================================================
// UIScrollView
// ==============================================================================
UIScrollView::UIScrollView(UIElementID id) : UIElement(id, "ScrollView") {}

void UIScrollView::OnLayout(float px, float py, float pw, float ph) {
    UIElement::OnLayout(px, py, pw, ph);
    // Compute content height
    m_contentH = 0;
    for (auto& c : m_children) {
        c->OnLayout(m_computedX, m_computedY - m_scrollY, m_w, m_h);
        m_contentH += c->GetH() + 4;
    }
}

void UIScrollView::OnRender(UIRenderer& renderer) {
    if (!m_visible) return;
    renderer.BeginClip(m_computedX, m_computedY, m_w, m_h);
    RenderBackground(renderer);
    RenderChildren(renderer);
    renderer.EndClip();

    // Scrollbar
    if (m_showScrollBar && m_contentH > m_h) {
        float barH   = m_h * m_h / m_contentH;
        float barY   = m_computedY + (m_scrollY / (m_contentH - m_h)) * (m_h - barH);
        renderer.DrawRect(m_computedX + m_w - 6, barY, 4, barH, {0.5f,0.5f,0.5f,0.7f}, 2.0f);
    }
}

bool UIScrollView::OnMouseEvent(float mx, float my, bool pressed) {
    bool inside = GetRect().Contains(mx, my);
    if (!inside) return false;
    RouteMouseEvent(mx, my, pressed);
    return true;
}

// ==============================================================================
// UITextInput
// ==============================================================================
UITextInput::UITextInput(UIElementID id, const std::string& placeholder)
    : UIElement(id, "TextInput"), m_placeholder(placeholder) {
    m_borderRadius = 3.0f;
    m_borderWidth  = 1.0f;
}

bool UITextInput::OnMouseEvent(float mx, float my, bool pressed) {
    bool inside = GetRect().Contains(mx, my);
    if (pressed) m_focused = inside;
    m_state = inside ? UIState::Focused : UIState::Normal;
    return inside;
}

void UITextInput::FeedChar(char c) {
    if (!m_focused) return;
    if ((int)m_text.size() >= m_maxLen) return;
    m_text.insert(m_text.begin() + m_cursor, c);
    ++m_cursor;
    if (OnTextChanged) OnTextChanged(m_text);
}

void UITextInput::FeedKey(int key) {
    if (!m_focused) return;
    if (key == 259 && m_cursor > 0) { // GLFW_KEY_BACKSPACE
        m_text.erase(m_cursor-1, 1); --m_cursor;
        if (OnTextChanged) OnTextChanged(m_text);
    } else if (key == 263 && m_cursor > 0) --m_cursor;   // LEFT
    else if (key == 262 && m_cursor < (int)m_text.size()) ++m_cursor; // RIGHT
    else if (key == 257 || key == 335) { if (OnSubmit) OnSubmit(m_text); m_focused=false; } // ENTER
    else if (key == 256) m_focused = false; // ESC
}

void UITextInput::OnUpdate(float dt) {
    m_cursorBlink += dt;
    if (m_cursorBlink > 1.0f) m_cursorBlink = 0;
}

void UITextInput::OnRender(UIRenderer& renderer) {
    if (!m_visible) return;
    Color bg     = {0.12f,0.12f,0.15f,0.97f};
    Color border = m_focused ? Color{0.26f,0.59f,0.98f,1.0f} : Color{0.40f,0.40f,0.45f,0.8f};
    renderer.DrawRect(m_computedX, m_computedY, m_w, m_h, bg, m_borderRadius, border, m_borderWidth);

    const std::string& displayText = m_text.empty() && !m_focused ? m_placeholder : m_text;
    Color tc = (m_text.empty() && !m_focused) ? Color{0.45f,0.45f,0.45f,1.0f} : Color{0.95f,0.95f,0.95f,1.0f};
    renderer.DrawText(displayText, m_computedX+6, m_computedY + m_h*0.5f - 7.0f, 14.0f, tc);

    // Cursor
    if (m_focused && m_cursorBlink < 0.5f) {
        float cursorX = m_computedX + 6 + m_cursor * 8.0f;
        renderer.DrawRect(cursorX, m_computedY+4, 1, m_h-8, {0.9f,0.9f,0.9f,0.9f}, 0);
    }
}

} // namespace BADGE2D
