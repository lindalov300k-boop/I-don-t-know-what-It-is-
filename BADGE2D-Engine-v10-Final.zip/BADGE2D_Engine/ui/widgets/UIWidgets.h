#pragma once
// ==============================================================================
// UIWidgets.h — All built-in UI widget types
// ==============================================================================

#include "../canvas/UIElement.h"
#include <string>
#include <vector>
#include <functional>
#include "../../renderer/textures/Texture2D.h"

namespace BADGE2D {

// ==============================================================================
// UILabel
// ==============================================================================
class UILabel : public UIElement {
public:
    explicit UILabel(UIElementID id, const std::string& text = "");

    void SetText    (const std::string& t) { m_text = t; }
    void SetFontSize(float s)              { m_fontSize = s; }
    void SetHAlign  (HAlign a)             { m_hAlign = a; }
    void SetVAlign  (VAlign a)             { m_vAlign = a; }
    void SetWrap    (bool w)               { m_wrap = w; }

    const std::string& GetText() const     { return m_text; }

    void OnRender(UIRenderer& renderer) override;

private:
    std::string m_text;
    float       m_fontSize = 14.0f;
    HAlign      m_hAlign   = HAlign::Left;
    VAlign      m_vAlign   = VAlign::Center;
    bool        m_wrap     = false;
};

// ==============================================================================
// UIButton
// ==============================================================================
class UIButton : public UIElement {
public:
    explicit UIButton(UIElementID id, const std::string& label = "Button");

    void SetLabel   (const std::string& l) { m_label = l; }
    void SetFontSize(float s)              { m_fontSize = s; }

    void OnRender(UIRenderer& renderer)            override;
    bool OnMouseEvent(float mx, float my, bool pressed) override;

private:
    std::string m_label;
    float       m_fontSize = 14.0f;
};

// ==============================================================================
// UICheckbox
// ==============================================================================
class UICheckbox : public UIElement {
public:
    explicit UICheckbox(UIElementID id, const std::string& label = "");

    void SetChecked(bool c) { m_checked = c; }
    bool IsChecked()  const { return m_checked; }
    void SetLabel  (const std::string& l) { m_label = l; }

    std::function<void(bool)> OnChanged;

    void OnRender(UIRenderer& renderer)            override;
    bool OnMouseEvent(float mx, float my, bool pressed) override;

private:
    std::string m_label;
    bool        m_checked  = false;
    bool        m_prevPressed = false;
};

// ==============================================================================
// UISlider
// ==============================================================================
class UISlider : public UIElement {
public:
    explicit UISlider(UIElementID id);

    void  SetRange(float min, float max) { m_min = min; m_max = max; }
    void  SetValue(float v)              { m_value = std::clamp(v, m_min, m_max); }
    float GetValue()               const { return m_value; }
    float GetNormalized()          const { return (m_max>m_min)?(m_value-m_min)/(m_max-m_min):0.0f; }

    void  SetStep(float s)               { m_step = s; }
    void  SetLabel(const std::string& l) { m_label = l; }

    std::function<void(float)> OnValueChanged;

    void OnRender(UIRenderer& renderer)            override;
    bool OnMouseEvent(float mx, float my, bool pressed) override;

private:
    float m_min = 0, m_max = 1, m_value = 0, m_step = 0;
    bool  m_dragging = false;
    std::string m_label;
};

// ==============================================================================
// UIProgressBar
// ==============================================================================
class UIProgressBar : public UIElement {
public:
    explicit UIProgressBar(UIElementID id);

    void  SetProgress(float p) { m_progress = std::clamp(p, 0.0f, 1.0f); }
    float GetProgress()  const { return m_progress; }
    void  SetFillColor (const Color& c) { m_fillColor = c; }
    void  SetLabel     (const std::string& l) { m_label = l; }
    void  SetShowText  (bool s) { m_showText = s; }

    void OnRender(UIRenderer& renderer) override;

private:
    float   m_progress  = 0;
    Color   m_fillColor = {0.26f, 0.59f, 0.98f, 1.0f};
    bool    m_showText  = false;
    std::string m_label;
};

// ==============================================================================
// UIImage
// ==============================================================================
class UIImage : public UIElement {
public:
    explicit UIImage(UIElementID id);

    void SetTexture(std::shared_ptr<Texture2D> tex) { m_texture = std::move(tex); }
    void SetTint   (const Color& c)                 { m_tint    = c; }
    void SetUVRect (const UIRect& uv)               { m_uvRect  = uv; }

    void OnRender(UIRenderer& renderer) override;

private:
    std::shared_ptr<Texture2D> m_texture;
    Color   m_tint   = {1,1,1,1};
    UIRect  m_uvRect = {0,0,1,1};
};

// ==============================================================================
// UIPanel — Container with optional title bar
// ==============================================================================
class UIPanel : public UIElement {
public:
    explicit UIPanel(UIElementID id, const std::string& title = "");

    void  SetTitle    (const std::string& t) { m_title = t; }
    void  SetDraggable(bool d)               { m_draggable = d; }
    void  SetCollapsible(bool c)             { m_collapsible = c; }
    bool  IsCollapsed ()               const { return m_collapsed; }

    void OnLayout(float px, float py, float pw, float ph) override;
    void OnRender(UIRenderer& renderer)                    override;
    bool OnMouseEvent(float mx, float my, bool pressed)    override;

private:
    std::string m_title;
    bool        m_draggable   = false;
    bool        m_collapsible = false;
    bool        m_collapsed   = false;
    bool        m_dragging    = false;
    float       m_dragOffX    = 0, m_dragOffY = 0;
    float       m_titleH      = 24.0f;
};

// ==============================================================================
// UIScrollView — Scrollable container
// ==============================================================================
class UIScrollView : public UIElement {
public:
    explicit UIScrollView(UIElementID id);

    void SetScrollOffset(float x, float y) { m_scrollX = x; m_scrollY = y; }
    void SetScrollBarVisible(bool v)        { m_showScrollBar = v; }
    float GetScrollX() const { return m_scrollX; }
    float GetScrollY() const { return m_scrollY; }

    void OnLayout(float px, float py, float pw, float ph) override;
    void OnRender(UIRenderer& renderer)                    override;
    bool OnMouseEvent(float mx, float my, bool pressed)    override;

private:
    float  m_scrollX = 0, m_scrollY = 0;
    float  m_contentH = 0;
    bool   m_showScrollBar = true;
    bool   m_scrolling = false;
};

// ==============================================================================
// UITextInput — Single-line text entry
// ==============================================================================
class UITextInput : public UIElement {
public:
    explicit UITextInput(UIElementID id, const std::string& placeholder = "");

    void SetText(const std::string& t)        { m_text = t; }
    void SetPlaceholder(const std::string& p) { m_placeholder = p; }
    void SetMaxLength(int n)                  { m_maxLen = n; }
    const std::string& GetText()        const { return m_text; }
    bool IsFocused()                    const { return m_focused; }

    // Feed keyboard input from InputManager
    void FeedChar (char c);
    void FeedKey  (int key);  // GLFW-compatible

    std::function<void(const std::string&)> OnTextChanged;
    std::function<void(const std::string&)> OnSubmit;

    void OnUpdate(float dt)                            override;
    void OnRender(UIRenderer& renderer)                override;
    bool OnMouseEvent(float mx, float my, bool pressed) override;

private:
    std::string m_text;
    std::string m_placeholder;
    int         m_cursor    = 0;
    int         m_maxLen    = 256;
    bool        m_focused   = false;
    float       m_cursorBlink = 0;
};

} // namespace BADGE2D
