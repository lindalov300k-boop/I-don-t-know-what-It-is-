#pragma once
// ==============================================================================
// UITypes.h — UI framework shared types
// ==============================================================================

#include <cstdint>
#include "../utilities/Math/Vector2.h"
#include "../utilities/Math/MathUtils.h"
#include "../utilities/Math/MathUtils.h"
#include "../utilities/Math/MathUtils.h"

namespace BADGE2D {

using UIElementID = uint32_t;
constexpr UIElementID INVALID_UI_ID = 0;

// ==============================================================================
// Anchor — Element position relative to parent
// ==============================================================================
enum class Anchor : uint8_t {
    TopLeft,    TopCenter,    TopRight,
    MidLeft,    Center,       MidRight,
    BotLeft,    BotCenter,    BotRight,
    // Stretch modes
    StretchH,   StretchV,     StretchFull
};

// ==============================================================================
// HAlign / VAlign — Text / content alignment inside an element
// ==============================================================================
enum class HAlign { Left, Center, Right };
enum class VAlign { Top,  Center, Bottom };

// ==============================================================================
// LayoutDir — Stack direction for container elements
// ==============================================================================
enum class LayoutDir { Horizontal, Vertical };

// ==============================================================================
// UIState — Per-element interaction state
// ==============================================================================
enum class UIState : uint8_t {
    Normal,
    Hovered,
    Pressed,
    Focused,
    Disabled
};

// ==============================================================================
// UITheme — Global style defaults
// ==============================================================================
struct UITheme {
    Color  background     = {0.12f, 0.12f, 0.14f, 0.92f};
    Color  foreground     = {0.92f, 0.92f, 0.92f, 1.00f};
    Color  accent         = {0.26f, 0.59f, 0.98f, 1.00f};
    Color  hovered        = {0.35f, 0.35f, 0.40f, 0.95f};
    Color  pressed        = {0.20f, 0.48f, 0.90f, 1.00f};
    Color  disabled       = {0.40f, 0.40f, 0.40f, 0.60f};
    Color  border         = {0.45f, 0.45f, 0.50f, 0.80f};
    Color  textColor      = {0.95f, 0.95f, 0.95f, 1.00f};
    Color  textDisabled   = {0.55f, 0.55f, 0.55f, 1.00f};
    Color  windowBg       = {0.10f, 0.10f, 0.12f, 0.95f};
    Color  panelBg        = {0.16f, 0.16f, 0.18f, 0.90f};
    float  borderRadius   = 4.0f;
    float  borderWidth    = 1.0f;
    float  padding        = 8.0f;
    float  spacing        = 4.0f;
    float  fontSize       = 14.0f;
    float  titleFontSize  = 16.0f;
};

// ==============================================================================
// UIRect helpers
// ==============================================================================
struct UIRect {
    float x = 0, y = 0, w = 0, h = 0;

    bool Contains(float px, float py) const {
        return px >= x && px <= x+w && py >= y && py <= y+h;
    }
    bool Contains(const Vector2& p) const { return Contains(p.x, p.y); }

    UIRect Shrink(float amount) const {
        return { x+amount, y+amount, w-2*amount, h-2*amount };
    }
    UIRect Grow(float amount) const {
        return { x-amount, y-amount, w+2*amount, h+2*amount };
    }
    Vector2 Center() const { return { x + w*0.5f, y + h*0.5f }; }
};

} // namespace BADGE2D
