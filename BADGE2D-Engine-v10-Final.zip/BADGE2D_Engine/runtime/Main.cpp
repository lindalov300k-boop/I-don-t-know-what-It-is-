// ==============================================================================
// Main.cpp — BADGE2D Phase 1 Integration Test
// Demonstrates: Engine, ECS World, EventBus, Memory, Profiler, FileSystem
// ==============================================================================

#include "Application.h"
#include "../engine/Memory/MemoryTracker.h"
#include "../engine/Profiling/Profiler.h"
#include "../ecs/component/Components.h"
#include "../utilities/EventSystem.h"
#include "../utilities/Math/MathUtils.h"
#include <cstdio>

using namespace BADGE2D;

// ==============================================================================
// TestSystem — A simple ECS system
// ==============================================================================
class MovementSystem : public ISystem {
public:
    MovementSystem() {
        requiredMask.set(ComponentRegistry::GetTypeID<TransformComponent>());
        requiredMask.set(ComponentRegistry::GetTypeID<RigidBody2DComponent>());
    }

    const char* GetName() const override { return "MovementSystem"; }

    void OnFixedUpdate(double dt) override {
        BADGE2D_PROFILE_SCOPE("MovementSystem::FixedUpdate");
        m_dtAccum += dt;
        // In a real engine, would iterate world entities here
    }

    double m_dtAccum = 0.0;
};

// ==============================================================================
// TestApplication — Demonstrates Phase 1 systems
// ==============================================================================
class TestApplication : public Application {
public:
    TestApplication() {
        m_config.windowTitle   = "BADGE2D Phase 1 Test";
        m_config.targetFPS     = 60;
        m_config.enableProfiling = true;
    }

    void OnConfigure(EngineConfig& cfg) override {
        cfg.windowWidth  = 1280;
        cfg.windowHeight = 720;
        LOG_INFO("[TestApp] Configured.");
    }

    void OnInit() override {
        LOG_INFO("[TestApp] Initializing...");

        // --- ECS Demo ---
        Entity player = m_world->CreateEntity("Player");
        m_world->AddComponent<TransformComponent>(player, {
            Vector2{100.0f, 200.0f}, 0.0f, Vector2::One()
        });
        m_world->AddComponent<SpriteComponent>(player);
        m_world->AddComponent<RigidBody2DComponent>(player);
        m_world->AddComponent<TagComponent>(player);
        m_world->GetComponent<TagComponent>(player).AddTag("player");

        Entity enemy = m_world->CreateEntity("Enemy");
        m_world->AddComponent<TransformComponent>(enemy);
        m_world->AddComponent<SpriteComponent>(enemy);

        LOG_INFOF("[TestApp] World has %zu entities.", m_world->GetEntityCount());

        // --- ECS System ---
        m_world->AddSystem<MovementSystem>();

        // --- EventBus Demo ---
        m_resizeEventID = BADGE2D_SUBSCRIBE(WindowResizeEvent, [](const WindowResizeEvent& e) {
            LOG_INFOF("[TestApp] Window resized to %dx%d", e.width, e.height);
        });

        // Dispatch a test event
        BADGE2D_DISPATCH(WindowResizeEvent{1920, 1080});

        // --- Math Demo ---
        Vector2 a{3.0f, 4.0f};
        Vector2 b{1.0f, 0.0f};
        LOG_INFOF("[TestApp] |%s| = %.2f", a.ToString().c_str(), a.Length());
        LOG_INFOF("[TestApp] Dot(a,b) = %.2f", Vector2::Dot(a, b));

        Transform2D t{{100, 200}, Math::ToRadians(45.0f), {2.0f, 2.0f}};
        Vector2 world = t.TransformPoint({1.0f, 0.0f});
        LOG_INFOF("[TestApp] Transformed point: %s", world.ToString().c_str());

        // --- Memory Tracker Demo ---
        MemoryTracker::Get().SetEnabled(true);

        // --- Profiler Demo ---
        Profiler::Get().SetEnabled(true);

        m_frameLimit = 5;
        LOG_INFO("[TestApp] Init complete. Running 5 test frames...");
    }

    void OnUpdate(double dt) override {
        BADGE2D_PROFILE_SCOPE("TestApp::Update");

        m_frameCount++;
        LOG_TRACEF("[TestApp] Frame %d | dt=%.4f s", m_frameCount, dt);

        if (m_frameCount >= m_frameLimit) {
            LOG_INFO("[TestApp] Test complete. Requesting quit.");
            Profiler::Get().PrintSummary();
            Quit();
        }
    }

    void OnShutdown() override {
        EventBus::Get().Unsubscribe<WindowResizeEvent>(m_resizeEventID);
        LOG_INFO("[TestApp] Shutdown.");
    }

private:
    int      m_frameCount  = 0;
    int      m_frameLimit  = 5;
    EventID  m_resizeEventID = 0;
};

// ==============================================================================
// main()
// ==============================================================================
int main(int /*argc*/, char** /*argv*/) {
    printf("===========================================\n");
    printf("  BADGE2D Engine — Phase 1 Foundation Test\n");
    printf("===========================================\n\n");

    TestApplication app;
    int result = app.Run();

    printf("\nEngine exited with code: %d\n", result);
    return result;
}
