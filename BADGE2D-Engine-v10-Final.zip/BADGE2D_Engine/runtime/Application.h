#pragma once
// ==============================================================================
// Application.h — Base class for game/app entry point
// Game code derives from Application and overrides lifecycle methods
// ==============================================================================

#include "../engine/Engine/Engine.h"
#include "../engine/Engine/EngineConfig.h"
#include "../ecs/system/World.h"
#include <memory>

namespace BADGE2D {

// ==============================================================================
// Application — CRTP-free base for any BADGE2D game
//
// Usage:
//   class MyGame : public Application {
//   public:
//       void OnInit()         override { /* spawn entities */ }
//       void OnUpdate(double) override { /* game logic    */ }
//   };
//
//   int main() {
//       MyGame game;
//       return game.Run();
//   }
// ==============================================================================
class Application {
public:
    explicit Application(EngineConfig cfg = EngineConfig{});
    virtual ~Application() = default;

    // Entry point — call from main()
    int Run();

    // Lifecycle (override in game)
    virtual void OnConfigure(EngineConfig& cfg) {}   // Called before engine init
    virtual void OnInit()                       {}   // After engine init
    virtual void OnUpdate   (double dt)         {}   // Per-frame
    virtual void OnFixedUpdate(double dt)       {}   // Fixed timestep
    virtual void OnRender   ()                  {}   // After systems render
    virtual void OnShutdown ()                  {}   // Before engine shutdown

    // Accessors
    Engine& GetEngine() { return Engine::Get(); }
    World&  GetWorld()  { return *m_world; }

    void Quit() { Engine::Get().Quit(); }

protected:
    EngineConfig              m_config;
    std::unique_ptr<World>    m_world;
};

} // namespace BADGE2D
