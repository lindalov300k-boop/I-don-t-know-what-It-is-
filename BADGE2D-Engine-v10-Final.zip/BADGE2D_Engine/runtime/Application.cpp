// ==============================================================================
// Application.cpp
// ==============================================================================

#include "Application.h"

namespace BADGE2D {

Application::Application(EngineConfig cfg)
    : m_config(std::move(cfg))
{}

int Application::Run() {
    // Let game customize config before init
    OnConfigure(m_config);

    Engine& engine = Engine::Get();
    if (!engine.Initialize(m_config)) {
        return -1;
    }

    // Create world
    m_world = std::make_unique<World>();

    // Wire engine callbacks
    engine.OnStartup = [this]() {
        LOG_INFO("[Application] OnInit");
        OnInit();
    };

    engine.OnUpdate = [this](double dt) {
        // Flush deferred events
        EventBus::Get().FlushQueue();
        // Update world systems
        m_world->UpdateSystems(dt);
        // Game update
        OnUpdate(dt);
    };

    engine.OnFixedUpdate = [this](double dt) {
        m_world->FixedUpdateSystems(dt);
        OnFixedUpdate(dt);
    };

    engine.OnRender = [this]() {
        m_world->RenderSystems();
        OnRender();
    };

    engine.OnShutdown = [this]() {
        LOG_INFO("[Application] OnShutdown");
        OnShutdown();
        m_world.reset();
    };

    engine.Run();
    return 0;
}

} // namespace BADGE2D
