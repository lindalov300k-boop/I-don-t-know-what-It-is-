#pragma once
// ==============================================================================
// Logger.h — Thread-safe logging system with levels, sinks, and formatting
// ==============================================================================

#include <string>
#include <vector>
#include <memory>
#include <mutex>
#include <functional>
#include <sstream>
#include <chrono>
#include <cstdio>

namespace BADGE2D {

// ==============================================================================
// Log Levels
// ==============================================================================
enum class LogLevel : uint8_t {
    Trace   = 0,
    Debug   = 1,
    Info    = 2,
    Warning = 3,
    Error   = 4,
    Fatal   = 5,
    Off     = 6
};

// ==============================================================================
// LogRecord — a single log entry
// ==============================================================================
struct LogRecord {
    LogLevel    level;
    std::string message;
    std::string category;
    std::string file;
    int         line;
    std::string function;
    std::chrono::system_clock::time_point timestamp;
};

// ==============================================================================
// ILogSink — Abstract output target
// ==============================================================================
class ILogSink {
public:
    virtual ~ILogSink() = default;
    virtual void Write(const LogRecord& record) = 0;
    virtual void Flush() {}
};

// ==============================================================================
// ConsoleSink — writes to stdout/stderr
// ==============================================================================
class ConsoleSink : public ILogSink {
public:
    explicit ConsoleSink(bool useColor = true);
    void Write(const LogRecord& record) override;

private:
    bool m_useColor;
    const char* GetLevelColor(LogLevel level) const;
    const char* GetLevelString(LogLevel level) const;
};

// ==============================================================================
// FileSink — writes to a log file
// ==============================================================================
class FileSink : public ILogSink {
public:
    explicit FileSink(const std::string& filePath);
    ~FileSink() override;
    void Write(const LogRecord& record) override;
    void Flush() override;

private:
    FILE*       m_file  = nullptr;
    std::mutex  m_mutex;
    const char* GetLevelString(LogLevel level) const;
};

// ==============================================================================
// Logger — Core logging class
// ==============================================================================
class Logger {
public:
    static Logger& Get();

    // Configuration
    void SetLevel(LogLevel level);
    void SetCategory(const std::string& category);
    void AddSink(std::shared_ptr<ILogSink> sink);
    void ClearSinks();

    // Core log methods
    void Log(LogLevel level, const std::string& message,
             const std::string& file = "", int line = 0,
             const std::string& function = "");

    // Helpers
    void Trace  (const std::string& msg, const std::string& file="", int line=0, const std::string& fn="");
    void Debug  (const std::string& msg, const std::string& file="", int line=0, const std::string& fn="");
    void Info   (const std::string& msg, const std::string& file="", int line=0, const std::string& fn="");
    void Warning(const std::string& msg, const std::string& file="", int line=0, const std::string& fn="");
    void Error  (const std::string& msg, const std::string& file="", int line=0, const std::string& fn="");
    void Fatal  (const std::string& msg, const std::string& file="", int line=0, const std::string& fn="");

    bool IsEnabled(LogLevel level) const;

    // Formatted logging (variadic)
    template<typename... Args>
    void LogFmt(LogLevel level, const char* fmt, Args&&... args) {
        if (!IsEnabled(level)) return;
        char buf[4096];
        std::snprintf(buf, sizeof(buf), fmt, std::forward<Args>(args)...);
        Log(level, buf);
    }

private:
    Logger();
    ~Logger();

    LogLevel                            m_level    = LogLevel::Debug;
    std::string                         m_category = "Engine";
    std::vector<std::shared_ptr<ILogSink>> m_sinks;
    mutable std::mutex                  m_mutex;
};

// ==============================================================================
// Convenience macros
// ==============================================================================
#define LOG_TRACE(msg)   BADGE2D::Logger::Get().Trace  (msg, __FILE__, __LINE__, __func__)
#define LOG_DEBUG(msg)   BADGE2D::Logger::Get().Debug  (msg, __FILE__, __LINE__, __func__)
#define LOG_INFO(msg)    BADGE2D::Logger::Get().Info   (msg, __FILE__, __LINE__, __func__)
#define LOG_WARN(msg)    BADGE2D::Logger::Get().Warning(msg, __FILE__, __LINE__, __func__)
#define LOG_ERROR(msg)   BADGE2D::Logger::Get().Error  (msg, __FILE__, __LINE__, __func__)
#define LOG_FATAL(msg)   BADGE2D::Logger::Get().Fatal  (msg, __FILE__, __LINE__, __func__)

#define LOG_TRACEF(fmt, ...) BADGE2D::Logger::Get().LogFmt(BADGE2D::LogLevel::Trace,   fmt, ##__VA_ARGS__)
#define LOG_DEBUGF(fmt, ...) BADGE2D::Logger::Get().LogFmt(BADGE2D::LogLevel::Debug,   fmt, ##__VA_ARGS__)
#define LOG_INFOF(fmt, ...)  BADGE2D::Logger::Get().LogFmt(BADGE2D::LogLevel::Info,    fmt, ##__VA_ARGS__)
#define LOG_WARNF(fmt, ...)  BADGE2D::Logger::Get().LogFmt(BADGE2D::LogLevel::Warning, fmt, ##__VA_ARGS__)
#define LOG_ERRORF(fmt, ...) BADGE2D::Logger::Get().LogFmt(BADGE2D::LogLevel::Error,   fmt, ##__VA_ARGS__)
#define LOG_FATALF(fmt, ...) BADGE2D::Logger::Get().LogFmt(BADGE2D::LogLevel::Fatal,   fmt, ##__VA_ARGS__)

} // namespace BADGE2D
