// ==============================================================================
// Logger.cpp — Logger implementation
// ==============================================================================

#include "Logger.h"
#include <ctime>
#include <iomanip>
#include <cassert>
#include <cstring>

namespace BADGE2D {

// ==============================================================================
// ConsoleSink
// ==============================================================================
ConsoleSink::ConsoleSink(bool useColor)
    : m_useColor(useColor)
{}

const char* ConsoleSink::GetLevelColor(LogLevel level) const {
    switch (level) {
        case LogLevel::Trace:   return "\033[37m";     // White
        case LogLevel::Debug:   return "\033[36m";     // Cyan
        case LogLevel::Info:    return "\033[32m";     // Green
        case LogLevel::Warning: return "\033[33m";     // Yellow
        case LogLevel::Error:   return "\033[31m";     // Red
        case LogLevel::Fatal:   return "\033[1;31m";   // Bold Red
        default:                return "\033[0m";
    }
}

const char* ConsoleSink::GetLevelString(LogLevel level) const {
    switch (level) {
        case LogLevel::Trace:   return "TRACE";
        case LogLevel::Debug:   return "DEBUG";
        case LogLevel::Info:    return "INFO ";
        case LogLevel::Warning: return "WARN ";
        case LogLevel::Error:   return "ERROR";
        case LogLevel::Fatal:   return "FATAL";
        default:                return "?????";
    }
}

void ConsoleSink::Write(const LogRecord& record) {
    // Format timestamp
    auto time_t_val = std::chrono::system_clock::to_time_t(record.timestamp);
    struct tm tm_buf;
#if defined(_WIN32)
    localtime_s(&tm_buf, &time_t_val);
#else
    localtime_r(&time_t_val, &tm_buf);
#endif
    char timeBuf[32];
    std::strftime(timeBuf, sizeof(timeBuf), "%H:%M:%S", &tm_buf);

    FILE* out = (record.level >= LogLevel::Error) ? stderr : stdout;

    if (m_useColor) {
        fprintf(out, "%s[%s][%s][%s] %s\033[0m\n",
                GetLevelColor(record.level),
                timeBuf,
                GetLevelString(record.level),
                record.category.c_str(),
                record.message.c_str());
    } else {
        fprintf(out, "[%s][%s][%s] %s\n",
                timeBuf,
                GetLevelString(record.level),
                record.category.c_str(),
                record.message.c_str());
    }
}

// ==============================================================================
// FileSink
// ==============================================================================
FileSink::FileSink(const std::string& filePath) {
    m_file = fopen(filePath.c_str(), "a");
}

FileSink::~FileSink() {
    if (m_file) {
        fclose(m_file);
        m_file = nullptr;
    }
}

const char* FileSink::GetLevelString(LogLevel level) const {
    switch (level) {
        case LogLevel::Trace:   return "TRACE";
        case LogLevel::Debug:   return "DEBUG";
        case LogLevel::Info:    return "INFO ";
        case LogLevel::Warning: return "WARN ";
        case LogLevel::Error:   return "ERROR";
        case LogLevel::Fatal:   return "FATAL";
        default:                return "?????";
    }
}

void FileSink::Write(const LogRecord& record) {
    if (!m_file) return;
    std::lock_guard<std::mutex> lock(m_mutex);

    auto time_t_val = std::chrono::system_clock::to_time_t(record.timestamp);
    struct tm tm_buf;
#if defined(_WIN32)
    localtime_s(&tm_buf, &time_t_val);
#else
    localtime_r(&time_t_val, &tm_buf);
#endif
    char timeBuf[32];
    std::strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%d %H:%M:%S", &tm_buf);

    fprintf(m_file, "[%s][%s][%s] %s",
            timeBuf,
            GetLevelString(record.level),
            record.category.c_str(),
            record.message.c_str());

    if (!record.file.empty()) {
        fprintf(m_file, "  (%s:%d)", record.file.c_str(), record.line);
    }
    fprintf(m_file, "\n");
}

void FileSink::Flush() {
    if (m_file) fflush(m_file);
}

// ==============================================================================
// Logger
// ==============================================================================
Logger::Logger() {
    // Default: console sink
    m_sinks.push_back(std::make_shared<ConsoleSink>(true));
}

Logger::~Logger() {
    for (auto& sink : m_sinks) sink->Flush();
}

Logger& Logger::Get() {
    static Logger instance;
    return instance;
}

void Logger::SetLevel(LogLevel level) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_level = level;
}

void Logger::SetCategory(const std::string& category) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_category = category;
}

void Logger::AddSink(std::shared_ptr<ILogSink> sink) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_sinks.push_back(std::move(sink));
}

void Logger::ClearSinks() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_sinks.clear();
}

bool Logger::IsEnabled(LogLevel level) const {
    return level >= m_level;
}

void Logger::Log(LogLevel level, const std::string& message,
                 const std::string& file, int line, const std::string& function) {
    if (!IsEnabled(level)) return;

    LogRecord record;
    record.level     = level;
    record.message   = message;
    record.category  = m_category;
    record.file      = file;
    record.line      = line;
    record.function  = function;
    record.timestamp = std::chrono::system_clock::now();

    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& sink : m_sinks) sink->Write(record);
}

void Logger::Trace  (const std::string& msg, const std::string& f, int l, const std::string& fn) { Log(LogLevel::Trace,   msg, f, l, fn); }
void Logger::Debug  (const std::string& msg, const std::string& f, int l, const std::string& fn) { Log(LogLevel::Debug,   msg, f, l, fn); }
void Logger::Info   (const std::string& msg, const std::string& f, int l, const std::string& fn) { Log(LogLevel::Info,    msg, f, l, fn); }
void Logger::Warning(const std::string& msg, const std::string& f, int l, const std::string& fn) { Log(LogLevel::Warning, msg, f, l, fn); }
void Logger::Error  (const std::string& msg, const std::string& f, int l, const std::string& fn) { Log(LogLevel::Error,   msg, f, l, fn); }
void Logger::Fatal  (const std::string& msg, const std::string& f, int l, const std::string& fn) { Log(LogLevel::Fatal,   msg, f, l, fn); }

} // namespace BADGE2D
