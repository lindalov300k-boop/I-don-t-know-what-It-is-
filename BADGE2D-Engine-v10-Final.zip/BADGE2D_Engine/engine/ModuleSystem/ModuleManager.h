#pragma once
// ==============================================================================
// ModuleManager.h — Registers, orders, and drives all engine modules
// ==============================================================================

#include "ModuleInterface.h"
#include <vector>
#include <memory>
#include <string>
#include <unordered_map>
#include <typeindex>

namespace BADGE2D {

// ==============================================================================
// ModuleManager — Singleton
// ==============================================================================
class ModuleManager {
public:
    static ModuleManager& Get();

    // Registration (call before Initialize)
    template<typename T, typename... Args>
    T* RegisterModule(Args&&... args) {
        auto mod = std::make_unique<T>(std::forward<Args>(args)...);
        T* raw = mod.get();
        m_typeMap[std::type_index(typeid(T))] = raw;
        m_modules.push_back(std::move(mod));
        SortModules();
        return raw;
    }

    // Lookup by type
    template<typename T>
    T* GetModule() {
        auto it = m_typeMap.find(std::type_index(typeid(T)));
        return (it != m_typeMap.end()) ? static_cast<T*>(it->second) : nullptr;
    }

    // Lifecycle (called by Engine)
    bool InitializeAll();
    void ShutdownAll();        // Shuts down in reverse order
    void UpdateAll(double dt);
    void FixedUpdateAll(double dt);
    void PostUpdateAll(double dt);
    void RenderAll();

    const std::vector<std::unique_ptr<IModule>>& GetModules() const { return m_modules; }

private:
    ModuleManager() = default;
    void SortModules();

    std::vector<std::unique_ptr<IModule>>              m_modules;
    std::unordered_map<std::type_index, IModule*>      m_typeMap;
};

} // namespace BADGE2D
