#pragma once
// ==============================================================================
// ModuleInterface.h — Base class for all engine modules
// ==============================================================================

#include <string>
#include <cstdint>

namespace BADGE2D {

// ==============================================================================
// ModuleInitOrder — Load order priority (lower = earlier)
// ==============================================================================
enum class ModuleInitOrder : uint32_t {
    Core       = 0,
    Platform   = 100,
    Memory     = 200,
    Logging    = 300,
    Time       = 400,
    Profiling  = 500,
    ECS        = 600,
    Renderer   = 700,
    Physics    = 800,
    Audio      = 900,
    Input      = 1000,
    Animation  = 1100,
    Scene      = 1200,
    Assets     = 1250,
    Scripting  = 1300,
    UI         = 1400,
    Editor     = 1450,
    AI         = 1500,
    Network    = 1600,
    Game       = 9999
};

// ==============================================================================
// IModule — Abstract engine module interface
// Every subsystem (Renderer, Physics, Audio, etc.) implements this.
// ==============================================================================
class IModule {
public:
    virtual ~IModule() = default;

    // Lifecycle
    virtual bool        Initialize()          = 0;
    virtual void        Shutdown()            = 0;
    virtual void        Update(double dt)     {}
    virtual void        FixedUpdate(double dt){}
    virtual void        PostUpdate(double dt) {}
    virtual void        Render()              {}

    // Identity
    virtual const char* GetName()        const = 0;
    virtual uint32_t    GetInitOrder()   const = 0;
    virtual bool        IsInitialized()  const { return m_initialized; }

protected:
    bool m_initialized = false;
};

} // namespace BADGE2D
