// ==============================================================================
// ModuleManager.cpp
// ==============================================================================

#include "ModuleManager.h"
#include "../Logging/Logger.h"
#include <algorithm>

namespace BADGE2D {

ModuleManager& ModuleManager::Get() {
    static ModuleManager instance;
    return instance;
}

void ModuleManager::SortModules() {
    std::stable_sort(m_modules.begin(), m_modules.end(),
        [](const std::unique_ptr<IModule>& a, const std::unique_ptr<IModule>& b) {
            return a->GetInitOrder() < b->GetInitOrder();
        });
}

bool ModuleManager::InitializeAll() {
    LOG_INFO("[ModuleManager] Initializing all modules...");

    for (auto& mod : m_modules) {
        LOG_INFOF("[ModuleManager] Initializing: %s", mod->GetName());
        if (!mod->Initialize()) {
            LOG_ERRORF("[ModuleManager] FAILED to initialize module: %s", mod->GetName());
            return false;
        }
    }

    LOG_INFO("[ModuleManager] All modules initialized.");
    return true;
}

void ModuleManager::ShutdownAll() {
    LOG_INFO("[ModuleManager] Shutting down all modules (reverse order)...");

    // Shutdown in reverse order
    for (int i = static_cast<int>(m_modules.size()) - 1; i >= 0; --i) {
        auto& mod = m_modules[i];
        if (mod->IsInitialized()) {
            LOG_INFOF("[ModuleManager] Shutting down: %s", mod->GetName());
            mod->Shutdown();
        }
    }

    m_modules.clear();
    m_typeMap.clear();
    LOG_INFO("[ModuleManager] Shutdown complete.");
}

void ModuleManager::UpdateAll(double dt) {
    for (auto& mod : m_modules)
        if (mod->IsInitialized()) mod->Update(dt);
}

void ModuleManager::FixedUpdateAll(double dt) {
    for (auto& mod : m_modules)
        if (mod->IsInitialized()) mod->FixedUpdate(dt);
}

void ModuleManager::PostUpdateAll(double dt) {
    for (auto& mod : m_modules)
        if (mod->IsInitialized()) mod->PostUpdate(dt);
}

void ModuleManager::RenderAll() {
    for (auto& mod : m_modules)
        if (mod->IsInitialized()) mod->Render();
}

} // namespace BADGE2D
