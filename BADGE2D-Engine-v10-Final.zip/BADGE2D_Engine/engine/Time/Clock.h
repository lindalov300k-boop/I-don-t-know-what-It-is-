#pragma once
// ==============================================================================
// Clock.h — High-resolution clock and frame timing
// ==============================================================================

#include <chrono>
#include <cstdint>
#include <string>

namespace BADGE2D {

using Clock     = std::chrono::high_resolution_clock;
using TimePoint = std::chrono::time_point<Clock>;
using Duration  = std::chrono::duration<double>;

// ==============================================================================
// EngineTime — Global engine time state (updated each frame)
// ==============================================================================
struct EngineTime {
    double   deltaTime       = 0.0;    // Seconds since last frame
    double   totalTime       = 0.0;    // Total engine time elapsed
    double   unscaledDelta   = 0.0;    // DeltaTime without time scale
    float    timeScale       = 1.0f;   // Time multiplier (0.5 = half speed)
    uint64_t frameCount      = 0;      // Total frames elapsed
    double   fps             = 0.0;    // Current frames per second
    double   smoothFPS       = 0.0;    // Smoothed FPS over window
    double   fixedDelta      = 1.0/60.0; // Fixed timestep for physics
    double   fixedAccum      = 0.0;    // Accumulator for fixed updates
};

// ==============================================================================
// FrameTimer — Manages frame timing and FPS calculation
// ==============================================================================
class FrameTimer {
public:
    FrameTimer();

    void Start();
    void Tick();         // Call once per frame
    void SetMaxDelta(double maxSeconds) { m_maxDelta = maxSeconds; }
    void SetTimeScale(float scale);

    const EngineTime& GetTime() const { return m_time; }

    // Returns true if a fixed timestep step should run
    bool ConsumeFixedStep();

private:
    static constexpr int   FPS_WINDOW = 60;

    TimePoint    m_lastFrame;
    TimePoint    m_startTime;
    EngineTime   m_time;
    double       m_maxDelta      = 0.25;  // Cap delta at 250ms to prevent spiral
    double       m_fpsHistory[FPS_WINDOW] = {};
    int          m_fpsIdx        = 0;
    double       m_fpsAccum      = 0.0;
};

// ==============================================================================
// Timer — Countdown / elapsed timer
// ==============================================================================
class Timer {
public:
    Timer() = default;
    explicit Timer(double durationSeconds);

    void  Start();
    void  Stop();
    void  Reset();
    void  Restart();

    bool  IsRunning()  const { return m_running; }
    bool  IsFinished() const;

    double Elapsed()     const;   // Seconds elapsed
    double Remaining()   const;   // Seconds remaining (if duration set)
    float  Progress()    const;   // 0.0 - 1.0

    void  SetDuration(double seconds) { m_duration = seconds; }

private:
    TimePoint m_startPoint;
    double    m_duration    = 0.0;
    bool      m_running     = false;
};

// ==============================================================================
// Stopwatch — Simple elapsed time measurement
// ==============================================================================
class Stopwatch {
public:
    void  Start();
    void  Stop();
    void  Reset();
    double ElapsedSeconds()      const;
    double ElapsedMilliseconds() const;
    double ElapsedMicroseconds() const;
    bool   IsRunning() const { return m_running; }

private:
    TimePoint m_start;
    TimePoint m_stop;
    bool      m_running = false;
};

} // namespace BADGE2D
