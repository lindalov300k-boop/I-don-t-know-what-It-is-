// ==============================================================================
// Clock.cpp — FrameTimer, Timer, Stopwatch implementations
// ==============================================================================

#include "Clock.h"
#include <algorithm>
#include <numeric>
#include <cmath>
#include <cassert>

namespace BADGE2D {

// ==============================================================================
// FrameTimer
// ==============================================================================
FrameTimer::FrameTimer() {
    for (int i = 0; i < FPS_WINDOW; ++i) m_fpsHistory[i] = 0.0;
}

void FrameTimer::Start() {
    m_startTime = Clock::now();
    m_lastFrame = m_startTime;
    m_time      = {};
    m_time.fixedDelta = 1.0 / 60.0;
}

void FrameTimer::Tick() {
    TimePoint now   = Clock::now();
    Duration  delta = now - m_lastFrame;
    m_lastFrame     = now;

    double rawDelta = delta.count();

    // Clamp to avoid spiral of death
    rawDelta = std::min(rawDelta, m_maxDelta);

    m_time.unscaledDelta = rawDelta;
    m_time.deltaTime     = rawDelta * m_time.timeScale;
    m_time.totalTime     += m_time.deltaTime;
    m_time.frameCount++;

    // Accumulate fixed timestep
    m_time.fixedAccum += m_time.unscaledDelta;

    // FPS calculation (rolling window)
    m_fpsAccum -= m_fpsHistory[m_fpsIdx];
    m_fpsAccum += rawDelta;
    m_fpsHistory[m_fpsIdx] = rawDelta;
    m_fpsIdx = (m_fpsIdx + 1) % FPS_WINDOW;

    double avgDelta = m_fpsAccum / FPS_WINDOW;
    m_time.fps       = rawDelta > 0.0     ? 1.0 / rawDelta     : 0.0;
    m_time.smoothFPS = avgDelta > 1e-9 ? 1.0 / avgDelta : 0.0;
}

void FrameTimer::SetTimeScale(float scale) {
    m_time.timeScale = std::max(0.0f, scale);
}

bool FrameTimer::ConsumeFixedStep() {
    if (m_time.fixedAccum >= m_time.fixedDelta) {
        m_time.fixedAccum -= m_time.fixedDelta;
        return true;
    }
    return false;
}

// ==============================================================================
// Timer
// ==============================================================================
Timer::Timer(double durationSeconds)
    : m_duration(durationSeconds) {}

void Timer::Start() {
    m_startPoint = Clock::now();
    m_running    = true;
}

void Timer::Stop() {
    m_running = false;
}

void Timer::Reset() {
    m_running = false;
}

void Timer::Restart() {
    m_startPoint = Clock::now();
    m_running    = true;
}

double Timer::Elapsed() const {
    if (!m_running) return 0.0;
    Duration d = Clock::now() - m_startPoint;
    return d.count();
}

bool Timer::IsFinished() const {
    return m_duration > 0.0 && Elapsed() >= m_duration;
}

double Timer::Remaining() const {
    if (m_duration <= 0.0) return 0.0;
    return std::max(0.0, m_duration - Elapsed());
}

float Timer::Progress() const {
    if (m_duration <= 0.0) return 0.0f;
    return static_cast<float>(std::min(1.0, Elapsed() / m_duration));
}

// ==============================================================================
// Stopwatch
// ==============================================================================
void Stopwatch::Start() {
    m_start   = Clock::now();
    m_running = true;
}

void Stopwatch::Stop() {
    m_stop    = Clock::now();
    m_running = false;
}

void Stopwatch::Reset() {
    m_running = false;
}

double Stopwatch::ElapsedSeconds() const {
    auto end = m_running ? Clock::now() : m_stop;
    return std::chrono::duration<double>(end - m_start).count();
}

double Stopwatch::ElapsedMilliseconds() const {
    return ElapsedSeconds() * 1000.0;
}

double Stopwatch::ElapsedMicroseconds() const {
    return ElapsedSeconds() * 1000000.0;
}

} // namespace BADGE2D
