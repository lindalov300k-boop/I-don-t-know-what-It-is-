#pragma once
// ==============================================================================
// Allocator.h — Base allocator interface + general heap allocator
// ==============================================================================

#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>

namespace BADGE2D {

// ==============================================================================
// IAllocator — Base interface all allocators implement
// ==============================================================================
class IAllocator {
public:
    virtual ~IAllocator() = default;

    virtual void* Allocate(size_t bytes, size_t alignment = alignof(std::max_align_t)) = 0;
    virtual void  Deallocate(void* ptr) = 0;
    virtual void  Reset() {}   // Optional: free all at once

    virtual size_t GetUsedBytes()  const { return 0; }
    virtual size_t GetTotalBytes() const { return 0; }

    // Typed helpers
    template<typename T, typename... Args>
    T* New(Args&&... args) {
        void* mem = Allocate(sizeof(T), alignof(T));
        return new(mem) T(std::forward<Args>(args)...);
    }

    template<typename T>
    void Delete(T* ptr) {
        if (ptr) {
            ptr->~T();
            Deallocate(ptr);
        }
    }
};

// ==============================================================================
// HeapAllocator — Wraps std malloc/free
// ==============================================================================
class HeapAllocator : public IAllocator {
public:
    HeapAllocator() = default;
    ~HeapAllocator() override = default;

    void* Allocate(size_t bytes, size_t alignment = alignof(std::max_align_t)) override;
    void  Deallocate(void* ptr) override;
};

// ==============================================================================
// Alignment helpers
// ==============================================================================
inline size_t AlignUp(size_t value, size_t alignment) {
    return (value + alignment - 1) & ~(alignment - 1);
}

inline bool IsPowerOfTwo(size_t value) {
    return value && !(value & (value - 1));
}

} // namespace BADGE2D
