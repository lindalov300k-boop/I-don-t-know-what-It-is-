#pragma once
// ==============================================================================
// PoolAllocator.h — Fixed-size block pool allocator
// Allocates from pre-allocated slabs. O(1) alloc and dealloc.
// ==============================================================================

#include "Allocator.h"
#include <vector>
#include <cassert>

namespace BADGE2D {

// ==============================================================================
// PoolAllocator
// Manages N fixed-size blocks from a single contiguous slab.
// Not thread-safe — use external locking if needed.
// ==============================================================================
class PoolAllocator : public IAllocator {
public:
    /// @param blockSize   Size of each individual allocation block (bytes)
    /// @param blockCount  Number of blocks in the pool
    PoolAllocator(size_t blockSize, size_t blockCount);
    ~PoolAllocator() override;

    // Disable copy
    PoolAllocator(const PoolAllocator&) = delete;
    PoolAllocator& operator=(const PoolAllocator&) = delete;

    void* Allocate(size_t bytes, size_t alignment = alignof(std::max_align_t)) override;
    void  Deallocate(void* ptr) override;
    void  Reset() override;

    size_t GetUsedBytes()  const override { return m_usedBlocks * m_blockSize; }
    size_t GetTotalBytes() const override { return m_blockCount * m_blockSize; }
    size_t GetFreeBlocks() const          { return m_blockCount - m_usedBlocks; }
    size_t GetUsedBlocks() const          { return m_usedBlocks; }
    bool   IsFull()        const          { return m_freeList == nullptr; }

private:
    struct FreeBlock {
        FreeBlock* next = nullptr;
    };

    void BuildFreeList();

    uint8_t*   m_slab       = nullptr;
    FreeBlock* m_freeList   = nullptr;
    size_t     m_blockSize  = 0;
    size_t     m_blockCount = 0;
    size_t     m_usedBlocks = 0;
};

// ==============================================================================
// StackAllocator — Linear stack allocator with rollback
// ==============================================================================
class StackAllocator : public IAllocator {
public:
    explicit StackAllocator(size_t capacityBytes);
    ~StackAllocator() override;

    StackAllocator(const StackAllocator&) = delete;
    StackAllocator& operator=(const StackAllocator&) = delete;

    void* Allocate(size_t bytes, size_t alignment = alignof(std::max_align_t)) override;
    void  Deallocate(void* ptr) override; // Noop; use markers
    void  Reset() override;

    // Marker-based rollback
    size_t GetMarker() const       { return m_top; }
    void   RollbackTo(size_t marker);

    size_t GetUsedBytes()  const override { return m_top; }
    size_t GetTotalBytes() const override { return m_capacity; }

private:
    uint8_t* m_buffer   = nullptr;
    size_t   m_capacity = 0;
    size_t   m_top      = 0;
};

} // namespace BADGE2D
