#pragma once
// ==============================================================================
// MemoryTracker.h — Tracks allocations and detects leaks
// ==============================================================================

#include <cstddef>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <mutex>
#include <vector>

namespace BADGE2D {

// ==============================================================================
// AllocationRecord
// ==============================================================================
struct AllocationRecord {
    void*       ptr        = nullptr;
    size_t      size       = 0;
    std::string file;
    int         line       = 0;
    std::string function;
    uint64_t    id         = 0;  // Sequential allocation ID
};

// ==============================================================================
// MemoryStats
// ==============================================================================
struct MemoryStats {
    size_t   totalAllocated   = 0;   // Bytes ever allocated
    size_t   totalFreed        = 0;  // Bytes ever freed
    size_t   currentUsage      = 0;  // Currently live bytes
    size_t   peakUsage         = 0;  // High-water mark
    uint64_t allocationCount   = 0;  // Total alloc calls
    uint64_t deallocationCount = 0;  // Total free calls
    size_t   liveAllocations   = 0;  // Currently unfreed allocs
};

// ==============================================================================
// MemoryTracker — Singleton
// ==============================================================================
class MemoryTracker {
public:
    static MemoryTracker& Get();

    void TrackAllocation  (void* ptr, size_t size, const char* file, int line, const char* fn);
    void TrackDeallocation(void* ptr);

    const MemoryStats& GetStats() const { return m_stats; }

    // Report all live allocations (leaks)
    void ReportLeaks() const;

    // Reset all tracking data
    void Reset();

    bool IsEnabled() const   { return m_enabled; }
    void SetEnabled(bool en) { m_enabled = en;    }

private:
    MemoryTracker() = default;

    mutable std::mutex                             m_mutex;
    std::unordered_map<void*, AllocationRecord>    m_records;
    MemoryStats                                    m_stats;
    uint64_t                                       m_nextId  = 1;
    bool                                           m_enabled = true;
};

// ==============================================================================
// Override macros (opt-in; define BADGE2D_TRACK_MEMORY to activate)
// ==============================================================================
#ifdef BADGE2D_TRACK_MEMORY
    #define BADGE2D_NEW(T, ...)       ([]{ \
        void* mem = ::operator new(sizeof(T)); \
        BADGE2D::MemoryTracker::Get().TrackAllocation(mem, sizeof(T), __FILE__, __LINE__, __func__); \
        return new(mem) T(__VA_ARGS__); \
    }())
    #define BADGE2D_DELETE(ptr)       do { \
        BADGE2D::MemoryTracker::Get().TrackDeallocation(ptr); \
        delete (ptr); \
    } while(0)
#else
    #define BADGE2D_NEW(T, ...)       new T(__VA_ARGS__)
    #define BADGE2D_DELETE(ptr)       delete (ptr)
#endif

} // namespace BADGE2D
