// ==============================================================================
// Allocator.cpp + PoolAllocator.cpp — Memory allocator implementations
// ==============================================================================

#include "Allocator.h"
#include "PoolAllocator.h"
#include <cstdlib>
#include <cstring>
#include <stdexcept>
#include <cassert>
#include <new>

namespace BADGE2D {

// ==============================================================================
// HeapAllocator
// ==============================================================================
void* HeapAllocator::Allocate(size_t bytes, size_t alignment) {
    if (bytes == 0) return nullptr;
    assert(IsPowerOfTwo(alignment));

    // Use aligned allocation
#if defined(_WIN32)
    void* ptr = _aligned_malloc(bytes, alignment);
#else
    void* ptr = nullptr;
    if (posix_memalign(&ptr, alignment, bytes) != 0)
        ptr = nullptr;
#endif
    if (!ptr) throw std::bad_alloc();
    return ptr;
}

void HeapAllocator::Deallocate(void* ptr) {
    if (!ptr) return;
#if defined(_WIN32)
    _aligned_free(ptr);
#else
    free(ptr);
#endif
}

// ==============================================================================
// PoolAllocator
// ==============================================================================
PoolAllocator::PoolAllocator(size_t blockSize, size_t blockCount)
    : m_blockSize(blockSize < sizeof(FreeBlock) ? sizeof(FreeBlock) : blockSize)
    , m_blockCount(blockCount)
{
    assert(blockCount > 0);
    m_slab = static_cast<uint8_t*>(::operator new(m_blockSize * m_blockCount));
    BuildFreeList();
}

PoolAllocator::~PoolAllocator() {
    ::operator delete(m_slab);
    m_slab = nullptr;
}

void PoolAllocator::BuildFreeList() {
    m_freeList   = nullptr;
    m_usedBlocks = 0;

    // Link each block into the free list (reverse order)
    for (size_t i = m_blockCount; i > 0; --i) {
        uint8_t* block = m_slab + (i - 1) * m_blockSize;
        FreeBlock* fb  = reinterpret_cast<FreeBlock*>(block);
        fb->next       = m_freeList;
        m_freeList     = fb;
    }
}

void* PoolAllocator::Allocate(size_t bytes, size_t /*alignment*/) {
    if (!m_freeList) return nullptr;         // Pool exhausted
    if (bytes > m_blockSize) return nullptr; // Too large for this pool

    FreeBlock* block = m_freeList;
    m_freeList       = block->next;
    ++m_usedBlocks;
    return block;
}

void PoolAllocator::Deallocate(void* ptr) {
    if (!ptr) return;

    // Validate the pointer belongs to this slab (debug)
    assert(ptr >= m_slab && ptr < m_slab + m_blockCount * m_blockSize);

    FreeBlock* fb = reinterpret_cast<FreeBlock*>(ptr);
    fb->next      = m_freeList;
    m_freeList    = fb;
    --m_usedBlocks;
}

void PoolAllocator::Reset() {
    BuildFreeList();
}

// ==============================================================================
// StackAllocator
// ==============================================================================
StackAllocator::StackAllocator(size_t capacityBytes)
    : m_capacity(capacityBytes)
{
    assert(capacityBytes > 0);
    m_buffer = static_cast<uint8_t*>(::operator new(capacityBytes));
    m_top    = 0;
}

StackAllocator::~StackAllocator() {
    ::operator delete(m_buffer);
    m_buffer = nullptr;
}

void* StackAllocator::Allocate(size_t bytes, size_t alignment) {
    assert(IsPowerOfTwo(alignment));
    size_t aligned = AlignUp(m_top, alignment);

    if (aligned + bytes > m_capacity) {
        return nullptr; // Out of stack memory
    }

    void* ptr = m_buffer + aligned;
    m_top     = aligned + bytes;
    return ptr;
}

void StackAllocator::Deallocate(void* /*ptr*/) {
    // Stack allocator does not support per-pointer dealloc.
    // Use RollbackTo(marker) instead.
}

void StackAllocator::Reset() {
    m_top = 0;
}

void StackAllocator::RollbackTo(size_t marker) {
    assert(marker <= m_top);
    m_top = marker;
}

} // namespace BADGE2D
