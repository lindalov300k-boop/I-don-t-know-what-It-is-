// ==============================================================================
// MemoryTracker.cpp
// ==============================================================================

#include "MemoryTracker.h"
#include "../Logging/Logger.h"
#include <cstdio>

namespace BADGE2D {

MemoryTracker& MemoryTracker::Get() {
    static MemoryTracker instance;
    return instance;
}

void MemoryTracker::TrackAllocation(void* ptr, size_t size,
                                     const char* file, int line, const char* fn) {
    if (!m_enabled || !ptr) return;
    std::lock_guard<std::mutex> lock(m_mutex);

    AllocationRecord rec;
    rec.ptr      = ptr;
    rec.size     = size;
    rec.file     = file ? file : "";
    rec.line     = line;
    rec.function = fn ? fn : "";
    rec.id       = m_nextId++;

    m_records[ptr] = rec;

    m_stats.totalAllocated    += size;
    m_stats.currentUsage      += size;
    m_stats.allocationCount++;
    m_stats.liveAllocations++;

    if (m_stats.currentUsage > m_stats.peakUsage)
        m_stats.peakUsage = m_stats.currentUsage;
}

void MemoryTracker::TrackDeallocation(void* ptr) {
    if (!m_enabled || !ptr) return;
    std::lock_guard<std::mutex> lock(m_mutex);

    auto it = m_records.find(ptr);
    if (it == m_records.end()) {
        // Double-free or untracked ptr
        Logger::Get().Warning("MemoryTracker: Deallocation of untracked pointer");
        return;
    }

    m_stats.totalFreed         += it->second.size;
    m_stats.currentUsage       -= it->second.size;
    m_stats.deallocationCount++;
    m_stats.liveAllocations--;

    m_records.erase(it);
}

void MemoryTracker::ReportLeaks() const {
    std::lock_guard<std::mutex> lock(m_mutex);

    if (m_records.empty()) {
        Logger::Get().Info("[MemoryTracker] No leaks detected.");
        return;
    }

    char buf[512];
    std::snprintf(buf, sizeof(buf),
        "[MemoryTracker] %zu leak(s) detected! Total leaked: %zu bytes",
        m_records.size(), m_stats.currentUsage);
    Logger::Get().Warning(buf);

    for (auto& [ptr, rec] : m_records) {
        std::snprintf(buf, sizeof(buf),
            "  Leak #%llu: %zu bytes @ %p  [%s:%d in %s()]",
            (unsigned long long)rec.id, rec.size, ptr,
            rec.file.c_str(), rec.line, rec.function.c_str());
        Logger::Get().Warning(buf);
    }
}

void MemoryTracker::Reset() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_records.clear();
    m_stats   = {};
    m_nextId  = 1;
}

} // namespace BADGE2D
