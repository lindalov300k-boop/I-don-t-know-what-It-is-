#pragma once
// ==============================================================================
// EngineConfig.h — Compile-time and runtime engine configuration
// ==============================================================================

#include <string>
#include <cstdint>

namespace BADGE2D {

// ==============================================================================
// Platform Detection
// ==============================================================================
#if defined(_WIN32) || defined(_WIN64)
    #define BADGE2D_PLATFORM_WINDOWS 1
#elif defined(__linux__)
    #define BADGE2D_PLATFORM_LINUX   1
#elif defined(__APPLE__)
    #define BADGE2D_PLATFORM_MACOS   1
#else
    #error "Unsupported platform"
#endif

// ==============================================================================
// Build Mode
// ==============================================================================
#ifdef NDEBUG
    #define BADGE2D_RELEASE 1
    #define BADGE2D_DEBUG   0
#else
    #define BADGE2D_DEBUG   1
    #define BADGE2D_RELEASE 0
#endif

// ==============================================================================
// Version
// ==============================================================================
constexpr uint32_t ENGINE_VERSION_MAJOR = 1;
constexpr uint32_t ENGINE_VERSION_MINOR = 0;
constexpr uint32_t ENGINE_VERSION_PATCH = 0;
constexpr const char* ENGINE_NAME       = "BADGE2D";
constexpr const char* ENGINE_VERSION_STRING = "1.0.0";

// ==============================================================================
// EngineConfig — runtime configuration struct
// ==============================================================================
struct EngineConfig {
    // Window
    std::string  windowTitle    = "BADGE2D Application";
    uint32_t     windowWidth    = 1280;
    uint32_t     windowHeight   = 720;
    bool         windowFullscreen = false;
    bool         windowVSync    = true;

    // Render
    uint32_t     targetFPS      = 60;
    bool         showFPSInTitle = true;

    // Memory
    size_t       heapBudgetMB      = 512;
    size_t       poolAllocSlabsMB  = 64;
    size_t       stackAllocSizeKB  = 4096;

    // Physics
    float        fixedTimestep   = 1.0f / 60.0f;
    int          physicsSubsteps = 1;

    // Debug
    bool         enableProfiling = true;
    bool         enableLogging   = true;
    bool         logToFile       = false;
    std::string  logFilePath     = "badge2d.log";

    // Asset
    std::string  assetRootPath   = "assets/";
};

} // namespace BADGE2D
