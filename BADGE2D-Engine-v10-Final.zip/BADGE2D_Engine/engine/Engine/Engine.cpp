// ==============================================================================
// Engine.cpp — Engine implementation
// ==============================================================================

#include "Engine.h"
#include "../Logging/Logger.h"
#include "../Memory/MemoryTracker.h"
#include "../Profiling/Profiler.h"
#include <stdexcept>
#include <cstdio>

namespace BADGE2D {

Engine::~Engine() {
    if (m_initialized) Shutdown();
}

Engine& Engine::Get() {
    static Engine instance;
    return instance;
}

bool Engine::Initialize(const EngineConfig& config) {
    if (m_initialized) {
        LOG_WARN("[Engine] Already initialized.");
        return true;
    }

    m_config = config;

    // Setup logger
    Logger::Get().SetCategory("Engine");
    if (config.logToFile) {
        Logger::Get().AddSink(std::make_shared<FileSink>(config.logFilePath));
    }

    LOG_INFO("========================================");
    LOG_INFOF("  %s Engine v%s", ENGINE_NAME, ENGINE_VERSION_STRING);
    LOG_INFO("========================================");
    LOG_INFOF("  Window: %ux%u  VSync=%s",
              config.windowWidth, config.windowHeight,
              config.windowVSync ? "on" : "off");
    LOG_INFOF("  Target FPS: %u", config.targetFPS);
    LOG_INFOF("  Asset Path: %s", config.assetRootPath.c_str());

    // Initialize module system
    if (!ModuleManager::Get().InitializeAll()) {
        LOG_FATAL("[Engine] Failed to initialize modules.");
        return false;
    }

    // Start frame timer
    m_frameTimer.Start();

    m_initialized = true;
    LOG_INFO("[Engine] Initialization complete.");
    return true;
}

void Engine::Run() {
    if (!m_initialized) {
        LOG_FATAL("[Engine] Run() called before Initialize().");
        return;
    }

    m_running.store(true);
    LOG_INFO("[Engine] Entering main loop.");

    if (OnStartup) OnStartup();

    MainLoop();

    LOG_INFO("[Engine] Exiting main loop.");
    Shutdown();
}

void Engine::Quit() {
    m_running.store(false);
}

void Engine::MainLoop() {
    const EngineConfig& cfg = m_config;

    // Target frame duration (0 = unlimited)
    const double targetFrameTime = cfg.targetFPS > 0
        ? 1.0 / static_cast<double>(cfg.targetFPS)
        : 0.0;

    Stopwatch frameClock;

    while (m_running.load()) {
        frameClock.Start();

        // Tick frame timer (calculates deltaTime, FPS, etc.)
        m_frameTimer.Tick();
        const EngineTime& time = m_frameTimer.GetTime();

        // Begin profiler frame
        if (cfg.enableProfiling) {
            Profiler::Get().BeginFrame(time.frameCount);
        }

        // Fixed timestep updates (physics, deterministic logic)
        {
            BADGE2D_PROFILE_SCOPE("FixedUpdate");
            while (m_frameTimer.ConsumeFixedStep()) {
                ModuleManager::Get().FixedUpdateAll(time.fixedDelta);
                if (OnFixedUpdate) OnFixedUpdate(time.fixedDelta);
            }
        }

        // Variable update
        {
            BADGE2D_PROFILE_SCOPE("Update");
            ModuleManager::Get().UpdateAll(time.deltaTime);
            if (OnUpdate) OnUpdate(time.deltaTime);
        }

        // Post update
        {
            BADGE2D_PROFILE_SCOPE("PostUpdate");
            ModuleManager::Get().PostUpdateAll(time.deltaTime);
        }

        // Render
        {
            BADGE2D_PROFILE_SCOPE("Render");
            ModuleManager::Get().RenderAll();
            if (OnRender) OnRender();
        }

        // End profiler frame
        if (cfg.enableProfiling) {
            Profiler::Get().EndFrame();
        }

        // FPS in title (if enabled)
        if (cfg.showFPSInTitle && (time.frameCount % 30 == 0)) {
            LOG_TRACEF("[Engine] Frame %llu | FPS: %.1f | dt: %.2f ms",
                      (unsigned long long)time.frameCount,
                      time.smoothFPS,
                      time.deltaTime * 1000.0);
        }

        // Frame rate limiter
        if (targetFrameTime > 0.0) {
            frameClock.Stop();
            double elapsed = frameClock.ElapsedSeconds();
            if (elapsed < targetFrameTime) {
                // Simple busy-wait for now; platform layer will use proper sleep
                Stopwatch wait;
                wait.Start();
                while (wait.ElapsedSeconds() < (targetFrameTime - elapsed)) {}
            }
        }
    }
}

void Engine::Shutdown() {
    if (!m_initialized) return;

    LOG_INFO("[Engine] Shutting down...");

    if (OnShutdown) OnShutdown();

    ModuleManager::Get().ShutdownAll();

    // Report memory leaks in debug
#if BADGE2D_DEBUG
    MemoryTracker::Get().ReportLeaks();
    const MemoryStats& ms = MemoryTracker::Get().GetStats();
    LOG_INFOF("[Engine] Memory: %llu allocs, peak %.2f KB",
              (unsigned long long)ms.allocationCount,
              ms.peakUsage / 1024.0);
#endif

    m_initialized = false;
    LOG_INFO("[Engine] Shutdown complete.");
}

} // namespace BADGE2D
