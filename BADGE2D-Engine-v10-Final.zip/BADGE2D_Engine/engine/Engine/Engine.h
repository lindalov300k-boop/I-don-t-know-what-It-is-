#pragma once
// ==============================================================================
// Engine.h — Main engine controller. Entry point for all engine systems.
// ==============================================================================

#include "EngineConfig.h"
#include "../ModuleSystem/ModuleManager.h"
#include "../Time/Clock.h"
#include <functional>
#include <string>
#include <atomic>

namespace BADGE2D {

// ==============================================================================
// Engine — Singleton engine controller
// Drives the main loop and owns all core systems.
// ==============================================================================
class Engine {
public:
    static Engine& Get();

    // Delete copy/move
    Engine(const Engine&)            = delete;
    Engine& operator=(const Engine&) = delete;

    // ==============================================================================
    // Startup / Shutdown
    // ==============================================================================
    bool Initialize(const EngineConfig& config = EngineConfig{});
    void Run();         // Blocks until Quit() is called
    void Quit();
    void Shutdown();

    // ==============================================================================
    // Application hooks — override these in your game or use callbacks
    // ==============================================================================
    std::function<void()>          OnStartup;
    std::function<void(double dt)> OnUpdate;
    std::function<void(double dt)> OnFixedUpdate;
    std::function<void()>          OnRender;
    std::function<void()>          OnShutdown;

    // ==============================================================================
    // Accessors
    // ==============================================================================
    const EngineConfig& GetConfig()    const { return m_config; }
    const EngineTime&   GetTime()      const { return m_frameTimer.GetTime(); }
    ModuleManager&      GetModules()         { return ModuleManager::Get(); }
    bool                IsRunning()    const { return m_running.load(); }
    bool                IsInitialized()const { return m_initialized; }

    template<typename T, typename... Args>
    T* RegisterModule(Args&&... args) {
        return ModuleManager::Get().RegisterModule<T>(std::forward<Args>(args)...);
    }

    template<typename T>
    T* GetModule() {
        return ModuleManager::Get().GetModule<T>();
    }

private:
    Engine() = default;
    ~Engine();

    void MainLoop();
    void RegisterCoreModules();

    EngineConfig      m_config;
    FrameTimer        m_frameTimer;
    std::atomic<bool> m_running     {false};
    bool              m_initialized {false};
};

// ==============================================================================
// Global access helper
// ==============================================================================
inline Engine& GEngine() { return Engine::Get(); }

} // namespace BADGE2D
