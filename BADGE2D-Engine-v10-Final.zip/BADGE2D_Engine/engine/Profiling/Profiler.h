#pragma once
// ==============================================================================
// Profiler.h — Scoped performance profiler with frame-level capture
// ==============================================================================

#include "../Time/Clock.h"
#include <string>
#include <vector>
#include <unordered_map>
#include <mutex>
#include <cstdint>

namespace BADGE2D {

// ==============================================================================
// ProfilerSample — A single named measurement
// ==============================================================================
struct ProfilerSample {
    std::string name;
    double      elapsedMs   = 0.0;
    uint64_t    callCount   = 0;
    double      minMs       = 1e9;
    double      maxMs       = 0.0;
    double      avgMs       = 0.0;  // Rolling average

    void Record(double ms) {
        elapsedMs += ms;
        callCount++;
        if (ms < minMs) minMs = ms;
        if (ms > maxMs) maxMs = ms;
        avgMs = elapsedMs / static_cast<double>(callCount);
    }

    void Reset() {
        elapsedMs = 0.0;
        callCount = 0;
    }
};

// ==============================================================================
// FrameCapture — Snapshot of all samples in a single frame
// ==============================================================================
struct FrameCapture {
    uint64_t                                  frameIndex  = 0;
    double                                    frameTimeMs = 0.0;
    std::unordered_map<std::string, ProfilerSample> samples;
};

// ==============================================================================
// Profiler — Singleton profiler
// ==============================================================================
class Profiler {
public:
    static Profiler& Get();

    void BeginFrame(uint64_t frameIndex);
    void EndFrame();

    void Begin(const std::string& name);
    void End  (const std::string& name);

    const FrameCapture&                            GetLastFrame()    const { return m_lastFrame; }
    const std::unordered_map<std::string, ProfilerSample>& GetSamples() const { return m_currentSamples; }

    bool IsEnabled()        const { return m_enabled; }
    void SetEnabled(bool v)       { m_enabled = v; }

    void PrintSummary() const;

private:
    Profiler() = default;

    bool                                          m_enabled       = true;
    uint64_t                                      m_currentFrame  = 0;
    std::unordered_map<std::string, Stopwatch>    m_activeTimers;
    std::unordered_map<std::string, ProfilerSample> m_currentSamples;
    FrameCapture                                  m_lastFrame;
    mutable std::mutex                            m_mutex;
    Stopwatch                                     m_frameTimer;
};

// ==============================================================================
// ScopedProfile — RAII scoped profiling block
// ==============================================================================
struct ScopedProfile {
    explicit ScopedProfile(const char* name)
        : m_name(name) {
        Profiler::Get().Begin(name);
    }
    ~ScopedProfile() {
        Profiler::Get().End(m_name);
    }
    const char* m_name;
};

// ==============================================================================
// Macros
// ==============================================================================
#define BADGE2D_PROFILE_SCOPE(name) BADGE2D::ScopedProfile _prof_##__LINE__(name)
#define BADGE2D_PROFILE_FUNCTION()  BADGE2D::ScopedProfile _prof_##__LINE__(__func__)

} // namespace BADGE2D
