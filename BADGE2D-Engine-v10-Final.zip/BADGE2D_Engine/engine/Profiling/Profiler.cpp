// ==============================================================================
// Profiler.cpp
// ==============================================================================

#include "Profiler.h"
#include "../Logging/Logger.h"
#include <cstdio>
#include <algorithm>
#include <vector>

namespace BADGE2D {

Profiler& Profiler::Get() {
    static Profiler instance;
    return instance;
}

void Profiler::BeginFrame(uint64_t frameIndex) {
    if (!m_enabled) return;
    std::lock_guard<std::mutex> lock(m_mutex);
    m_currentFrame = frameIndex;
    m_frameTimer.Start();

    // Reset per-frame counts
    for (auto& [name, sample] : m_currentSamples)
        sample.Reset();
}

void Profiler::EndFrame() {
    if (!m_enabled) return;
    std::lock_guard<std::mutex> lock(m_mutex);
    m_frameTimer.Stop();

    m_lastFrame.frameIndex  = m_currentFrame;
    m_lastFrame.frameTimeMs = m_frameTimer.ElapsedMilliseconds();
    m_lastFrame.samples     = m_currentSamples;
}

void Profiler::Begin(const std::string& name) {
    if (!m_enabled) return;
    std::lock_guard<std::mutex> lock(m_mutex);
    m_activeTimers[name].Start();
}

void Profiler::End(const std::string& name) {
    if (!m_enabled) return;
    std::lock_guard<std::mutex> lock(m_mutex);

    auto it = m_activeTimers.find(name);
    if (it == m_activeTimers.end()) return;

    it->second.Stop();
    double ms = it->second.ElapsedMilliseconds();
    m_currentSamples[name].name = name;
    m_currentSamples[name].Record(ms);
}

void Profiler::PrintSummary() const {
    std::lock_guard<std::mutex> lock(m_mutex);

    // Sort by elapsed time descending
    std::vector<const ProfilerSample*> sorted;
    sorted.reserve(m_currentSamples.size());
    for (auto& [name, s] : m_currentSamples)
        sorted.push_back(&s);

    std::sort(sorted.begin(), sorted.end(),
        [](const ProfilerSample* a, const ProfilerSample* b){
            return a->elapsedMs > b->elapsedMs;
        });

    LOG_INFO("===== PROFILER SUMMARY =====");
    char buf[256];
    for (auto* s : sorted) {
        std::snprintf(buf, sizeof(buf),
            "  %-40s  total=%6.2f ms  avg=%6.2f ms  calls=%llu",
            s->name.c_str(), s->elapsedMs, s->avgMs,
            (unsigned long long)s->callCount);
        LOG_INFO(buf);
    }
    LOG_INFO("============================");
}

} // namespace BADGE2D
