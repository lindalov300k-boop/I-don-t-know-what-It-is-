// ==============================================================================
// Mouse.cpp
// ==============================================================================

#include "Mouse.h"
#include <cmath>

namespace BADGE2D {

static constexpr int GLFW_PRESS   = 1;
static constexpr int GLFW_RELEASE = 0;

Mouse& Mouse::Get() {
    static Mouse instance;
    return instance;
}

// ==============================================================================
// Button queries
// ==============================================================================
bool Mouse::IsButton(MouseButton btn) const {
    int i = (int)btn;
    return (i >= 0 && i < BTN_COUNT) ? m_curr[i] : false;
}
bool Mouse::IsButtonDown(MouseButton btn) const {
    int i = (int)btn;
    return (i >= 0 && i < BTN_COUNT) ? m_curr[i] && !m_prev[i] : false;
}
bool Mouse::IsButtonUp(MouseButton btn) const {
    int i = (int)btn;
    return (i >= 0 && i < BTN_COUNT) ? !m_curr[i] && m_prev[i] : false;
}
bool Mouse::IsButtonHeld(MouseButton btn) const {
    int i = (int)btn;
    return (i >= 0 && i < BTN_COUNT) ? m_curr[i] && m_prev[i] : false;
}

// ==============================================================================
// Drag
// ==============================================================================
bool Mouse::IsDragging(MouseButton btn) const {
    if (!IsButton(btn)) return false;
    int i = (int)btn;
    return Vector2::Distance(m_position, m_pressPos[i]) >= dragThreshold;
}

Vector2 Mouse::GetDragStart(MouseButton btn) const {
    int i = (int)btn;
    return (i >= 0 && i < BTN_COUNT) ? m_pressPos[i] : Vector2{};
}

Vector2 Mouse::GetDragDelta(MouseButton btn) const {
    int i = (int)btn;
    if (i < 0 || i >= BTN_COUNT || !m_curr[i]) return {};
    return m_position - m_pressPos[i];
}

// ==============================================================================
// Double click
// ==============================================================================
bool Mouse::IsDoubleClick(MouseButton btn) const {
    int i = (int)btn;
    return (i >= 0 && i < BTN_COUNT) ? m_doubleClick[i] : false;
}

// ==============================================================================
// Cursor mode
// ==============================================================================
void Mouse::SetCursorMode(CursorMode mode) {
    m_cursorMode = mode;
    // Actual GLFW cursor mode change is triggered via RenderDevice callback
    // (avoids GLFW header dependency here)
}

// ==============================================================================
// Events
// ==============================================================================
void Mouse::OnMoveEvent(double x, double y) {
    m_position = {(float)x, (float)y};
}

void Mouse::OnButtonEvent(int button, int action, int /*mods*/) {
    if (button < 0 || button >= BTN_COUNT) return;

    if (action == GLFW_PRESS) {
        m_curr[button]      = true;
        m_pressPos[button]  = m_position;
        m_pressTime[button] = m_time;

        // Double click check
        double elapsed = m_time - m_lastClick[button];
        m_doubleClick[button] = (elapsed <= doubleClickTime && elapsed > 0.0);

        if (OnButtonStateChange)
            OnButtonStateChange((MouseButton)button, InputState::Pressed);
    } else if (action == GLFW_RELEASE) {
        m_curr[button]       = false;
        m_lastClick[button]  = m_time;

        if (OnButtonStateChange)
            OnButtonStateChange((MouseButton)button, InputState::Released);
    }
}

void Mouse::OnScrollEvent(double dx, double dy) {
    m_scrollDelta.x += (float)dx;
    m_scrollDelta.y += (float)dy;
}

// ==============================================================================
// Frame lifecycle
// ==============================================================================
void Mouse::BeginFrame(double dt) {
    m_time += dt;
    m_prev   = m_curr;
    m_delta  = m_position - m_prevPos;
    m_prevPos = m_position;
    m_doubleClick.fill(false);
}

void Mouse::EndFrame() {
    m_scrollDelta = {};
}

} // namespace BADGE2D
