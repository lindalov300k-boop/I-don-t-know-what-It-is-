#pragma once
// ==============================================================================
// Mouse.h — Mouse position, delta, scroll, buttons, cursor, world conversion
// ==============================================================================

#include "../InputCodes.h"
#include "../../utilities/Math/MathUtils.h"
#include <array>
#include <functional>

namespace BADGE2D {

// ==============================================================================
// Mouse — Per-frame mouse state
// ==============================================================================
class Mouse {
public:
    static Mouse& Get();

    // ==============================================================================
    // Position — screen space (pixels, top-left origin)
    // ==============================================================================
    Vector2 GetPosition ()       const { return m_position; }
    Vector2 GetDelta    ()       const { return m_delta; }
    float   GetX        ()       const { return m_position.x; }
    float   GetY        ()       const { return m_position.y; }

    // ==============================================================================
    // Scroll
    // ==============================================================================
    float   GetScrollX  ()       const { return m_scrollDelta.x; }
    float   GetScrollY  ()       const { return m_scrollDelta.y; }
    Vector2 GetScroll   ()       const { return m_scrollDelta; }
    bool    HasScrolled ()       const { return m_scrollDelta.LengthSq() > 0.0001f; }

    // ==============================================================================
    // Buttons
    // ==============================================================================
    bool IsButton    (MouseButton btn) const;
    bool IsButtonDown(MouseButton btn) const;
    bool IsButtonUp  (MouseButton btn) const;
    bool IsButtonHeld(MouseButton btn) const;

    // Convenience
    bool IsLeftDown  () const { return IsButtonDown(MouseButton::Left);   }
    bool IsRightDown () const { return IsButtonDown(MouseButton::Right);  }
    bool IsMiddleDown() const { return IsButtonDown(MouseButton::Middle); }
    bool IsLeft      () const { return IsButton(MouseButton::Left);       }
    bool IsRight     () const { return IsButton(MouseButton::Right);      }

    // ==============================================================================
    // Drag detection
    // ==============================================================================
    bool    IsDragging   (MouseButton btn = MouseButton::Left) const;
    Vector2 GetDragStart (MouseButton btn = MouseButton::Left) const;
    Vector2 GetDragDelta (MouseButton btn = MouseButton::Left) const;

    // Minimum pixels moved before drag is recognised
    float   dragThreshold = 4.0f;

    // ==============================================================================
    // Double-click
    // ==============================================================================
    bool    IsDoubleClick(MouseButton btn = MouseButton::Left) const;
    double  doubleClickTime = 0.3;   // seconds

    // ==============================================================================
    // Cursor
    // ==============================================================================
    void    SetCursorMode(CursorMode mode);
    CursorMode GetCursorMode() const { return m_cursorMode; }

    // ==============================================================================
    // Events (called by RenderDevice / GLFW callback)
    // ==============================================================================
    void OnMoveEvent  (double x, double y);
    void OnButtonEvent(int button, int action, int mods);
    void OnScrollEvent(double dx, double dy);

    // ==============================================================================
    // Frame lifecycle
    // ==============================================================================
    void BeginFrame(double dt);
    void EndFrame();

    // Callback for action system
    std::function<void(MouseButton, InputState)> OnButtonStateChange;

private:
    Mouse() = default;

    static constexpr int BTN_COUNT = (int)MouseButton::Count;

    Vector2  m_position    = {};
    Vector2  m_prevPos     = {};
    Vector2  m_delta       = {};
    Vector2  m_scrollDelta = {};

    std::array<bool, BTN_COUNT> m_curr       = {};
    std::array<bool, BTN_COUNT> m_prev       = {};
    std::array<Vector2, BTN_COUNT> m_pressPos= {};    // Where button went down
    std::array<double,  BTN_COUNT> m_pressTime= {};   // When button went down
    std::array<double,  BTN_COUNT> m_lastClick= {};   // Time of previous click (for double)
    std::array<bool,    BTN_COUNT> m_doubleClick={};

    CursorMode m_cursorMode = CursorMode::Normal;
    double     m_time       = 0.0;
};

} // namespace BADGE2D
