#pragma once
// ==============================================================================
// InputManager.h — Master input IModule.
// Owns Keyboard, Mouse, GamepadManager, ActionMaps, and InputBuffer.
// Single entry point for all game input.
// ==============================================================================

#include "keyboard/Keyboard.h"
#include "mouse/Mouse.h"
#include "gamepad/Gamepad.h"
#include "actions/ActionMap.h"
#include "buffering/InputBuffer.h"
#include "../engine/ModuleSystem/ModuleInterface.h"
#include <unordered_map>
#include <vector>
#include <memory>
#include <string>
#include <functional>

namespace BADGE2D {

// ==============================================================================
// RebindListener state (for in-game rebind UI)
// ==============================================================================
struct RebindRequest {
    ActionName  actionName;
    std::string mapName;
    int         bindingIndex = 0;
    bool        active       = false;

    std::function<void(InputBinding)> OnComplete;
    std::function<void()>             OnCancelled;
};

// ==============================================================================
// InputManager
// ==============================================================================
class InputManager : public IModule {
public:
    // IModule
    bool        Initialize()           override;
    void        Shutdown  ()           override;
    void        BeginFrame(double dt)  override;  // Poll all devices
    void        EndFrame  ()           override;  // Flush scroll etc.
    const char* GetName   ()     const override { return "InputManager"; }
    uint32_t    GetInitOrder() const   override { return (uint32_t)ModuleInitOrder::Input; }

    static InputManager& Get();

    // ==============================================================================
    // Device access
    // ==============================================================================
    Keyboard&      GetKeyboard()  { return Keyboard::Get();      }
    Mouse&         GetMouse()     { return Mouse::Get();          }
    GamepadManager& GetGamepads() { return GamepadManager::Get(); }
    InputBuffer&   GetBuffer()    { return m_buffer;              }

    // ==============================================================================
    // Action maps
    // ==============================================================================
    ActionMap& CreateMap    (const std::string& name, int priority = 0);
    ActionMap* GetMap       (const std::string& name);
    void       RemoveMap    (const std::string& name);
    void       EnableMap    (const std::string& name, bool enable = true);
    void       PushMap      (const std::string& name);  // Activate + push to stack
    void       PopMap       ();                          // Deactivate top of stack

    // Evaluate all enabled maps each frame (called automatically by BeginFrame)
    void       UpdateMaps();

    // ==============================================================================
    // Shorthand queries (checks all enabled maps, returns first match)
    // ==============================================================================
    bool    IsPressed (const ActionName& action) const;
    bool    IsHeld    (const ActionName& action) const;
    bool    IsReleased(const ActionName& action) const;
    float   GetValue  (const ActionName& action) const;
    Vector2 GetAxis2D (const ActionName& action) const;

    // ==============================================================================
    // Direct device queries (bypass action system)
    // ==============================================================================
    bool  IsKeyDown  (KeyCode key)       const { return Keyboard::Get().IsKeyDown(key);    }
    bool  IsKey      (KeyCode key)       const { return Keyboard::Get().IsKey(key);        }
    bool  IsKeyUp    (KeyCode key)       const { return Keyboard::Get().IsKeyUp(key);      }

    bool  IsMouseDown(MouseButton btn)   const { return Mouse::Get().IsButtonDown(btn);    }
    bool  IsMouse    (MouseButton btn)   const { return Mouse::Get().IsButton(btn);        }
    Vector2 GetMousePos()                const { return Mouse::Get().GetPosition();        }
    Vector2 GetMouseDelta()              const { return Mouse::Get().GetDelta();           }
    float   GetScrollY()                 const { return Mouse::Get().GetScrollY();         }

    // ==============================================================================
    // Rebind UI
    // ==============================================================================
    // Start listening for next input; when received, applies it to the binding.
    void StartRebind(const std::string& mapName, const ActionName& action,
                     int bindingIndex,
                     std::function<void(InputBinding)> onComplete = nullptr,
                     std::function<void()> onCancelled = nullptr);
    void CancelRebind();
    bool IsRebinding() const { return m_rebind.active; }

    // ==============================================================================
    // Preset profiles (keyboard layouts, controller schemes)
    // ==============================================================================
    bool SaveProfile (const std::string& mapName, const std::string& filepath) const;
    bool LoadProfile (const std::string& mapName, const std::string& filepath);

    // ==============================================================================
    // Cursor
    // ==============================================================================
    void SetCursorMode(CursorMode mode);

    // ==============================================================================
    // Text input (delegates to Keyboard)
    // ==============================================================================
    const std::string& GetTextInput() const { return Keyboard::Get().GetTextInput(); }
    bool HasTextInput()                const { return Keyboard::Get().HasTextInput(); }

    // ==============================================================================
    // Vibration shorthand
    // ==============================================================================
    void Rumble(float low = 0.5f, float high = 0.5f,
                float duration = 0.2f, int pad = 0);

private:
    InputManager() : m_buffer(0.5) {}

    void PollRebind();
    void FeedActionsToBuffer(double now);

    std::unordered_map<std::string, std::unique_ptr<ActionMap>> m_maps;
    std::vector<std::string>  m_mapStack;  // For push/pop
    InputBuffer               m_buffer;
    RebindRequest             m_rebind;
    double                    m_time = 0.0;
    bool                      m_initialized = false;
};

} // namespace BADGE2D
