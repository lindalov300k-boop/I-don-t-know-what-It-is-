#pragma once
// ==============================================================================
// InputAction.h — Named action mapping: bind keyboard/mouse/gamepad to actions.
// An action can have multiple bindings (KB+M primary, gamepad secondary).
// ==============================================================================

#include "../InputCodes.h"
#include "../../utilities/Math/MathUtils.h"
#include <string>
#include <vector>
#include <functional>
#include <variant>

namespace BADGE2D {

using ActionName = std::string;

// ==============================================================================
// BindingType — What kind of input drives a binding
// ==============================================================================
enum class BindingType {
    Key,              // Keyboard key → digital (0/1)
    MouseButton,      // Mouse button → digital
    MouseAxisX,       // Mouse delta X → analog
    MouseAxisY,       // Mouse delta Y → analog
    MouseScrollX,     // Scroll X → analog
    MouseScrollY,     // Scroll Y → analog
    GamepadButton,    // Gamepad button → digital
    GamepadAxis,      // Gamepad axis → analog (axis value)
    GamepadAxisPos,   // Positive half of axis → digital (e.g. right trigger as button)
    GamepadAxisNeg,   // Negative half of axis → digital
};

// ==============================================================================
// InputBinding — One concrete input binding for an action
// ==============================================================================
struct InputBinding {
    BindingType type = BindingType::Key;

    // Source
    KeyCode       key         = KeyCode::Unknown;
    MouseButton   mouseButton = MouseButton::Left;
    GamepadButton padButton   = GamepadButton::A;
    GamepadAxis   padAxis     = GamepadAxis::LeftX;
    int           gamepadIndex = 0;   // Which controller (0 = any/primary)

    // Scale / invert for analog bindings
    float scale    = 1.0f;
    bool  inverted = false;

    // Modifiers required (keyboard only)
    KeyMod requiredMods = KeyMod::None;

    // Human-readable label (e.g. "W", "LMB", "Left Stick X")
    std::string label;

    // ---- Factories ----
    static InputBinding FromKey(KeyCode k, KeyMod mods = KeyMod::None, float s = 1.0f) {
        InputBinding b; b.type = BindingType::Key; b.key = k;
        b.requiredMods = mods; b.scale = s;
        return b;
    }
    static InputBinding FromMouseButton(MouseButton btn) {
        InputBinding b; b.type = BindingType::MouseButton; b.mouseButton = btn; return b;
    }
    static InputBinding FromMouseScrollY(float s = 1.0f) {
        InputBinding b; b.type = BindingType::MouseScrollY; b.scale = s; return b;
    }
    static InputBinding FromGamepadButton(GamepadButton btn, int pad = 0) {
        InputBinding b; b.type = BindingType::GamepadButton;
        b.padButton = btn; b.gamepadIndex = pad; return b;
    }
    static InputBinding FromGamepadAxis(GamepadAxis axis, float s = 1.0f, int pad = 0) {
        InputBinding b; b.type = BindingType::GamepadAxis;
        b.padAxis = axis; b.scale = s; b.gamepadIndex = pad; return b;
    }
    static InputBinding FromGamepadAxisPos(GamepadAxis axis, int pad = 0) {
        InputBinding b; b.type = BindingType::GamepadAxisPos;
        b.padAxis = axis; b.gamepadIndex = pad; return b;
    }
    static InputBinding FromGamepadAxisNeg(GamepadAxis axis, int pad = 0) {
        InputBinding b; b.type = BindingType::GamepadAxisNeg;
        b.padAxis = axis; b.gamepadIndex = pad; return b;
    }
};

// ==============================================================================
// ActionType — Digital (button) or Analog (axis)
// ==============================================================================
enum class ActionType { Digital, Analog };

// ==============================================================================
// InputAction — A named logical action with one or more bindings
// ==============================================================================
struct InputAction {
    ActionName  name;
    ActionType  type     = ActionType::Digital;
    std::vector<InputBinding> bindings;

    // Current evaluated state
    float       value    = 0.0f;    // Analog: axis value; Digital: 0 or 1
    InputState  state    = InputState::None;

    // Per-action callbacks
    std::function<void(float)>       OnChange;    // Called when value changes
    std::function<void()>            OnPress;     // Digital: pressed this frame
    std::function<void()>            OnRelease;   // Digital: released this frame

    // Convenience
    bool IsPressed () const { return state == InputState::Pressed;  }
    bool IsHeld    () const { return state == InputState::Held;     }
    bool IsReleased() const { return state == InputState::Released; }
    bool IsActive  () const { return value != 0.0f; }
    float GetValue () const { return value; }
};

// ==============================================================================
// Axis2DAction — Combines two actions (or four keys) into a 2D vector
// Commonly used for movement (WASD / left stick).
// ==============================================================================
struct Axis2DAction {
    ActionName  name;
    ActionName  positiveX;    // e.g. "MoveRight"
    ActionName  negativeX;    // e.g. "MoveLeft"
    ActionName  positiveY;    // e.g. "MoveUp"
    ActionName  negativeY;    // e.g. "MoveDown"
    bool        normalize = true;  // Normalize diagonal to magnitude 1

    Vector2  value = {};

    // Or use a direct gamepad stick binding
    GamepadAxis stickX = GamepadAxis::LeftX;
    GamepadAxis stickY = GamepadAxis::LeftY;
    int         gamepadIndex = 0;
    bool        useStick  = false;
};

} // namespace BADGE2D
