#pragma once
// ==============================================================================
// ActionMap.h — Owns a set of InputActions, evaluates them each frame.
// Supports multiple maps (Gameplay / UI / Debug) that can be enabled/disabled.
// ==============================================================================

#include "InputAction.h"
#include "../keyboard/Keyboard.h"
#include "../mouse/Mouse.h"
#include "../gamepad/Gamepad.h"
#include <unordered_map>
#include <memory>

namespace BADGE2D {

// ==============================================================================
// ActionMap — A named group of actions (e.g. "Gameplay", "UI", "Vehicle")
// ==============================================================================
class ActionMap {
public:
    explicit ActionMap(std::string name, int priority = 0);

    const std::string& GetName()     const { return m_name; }
    int                GetPriority() const { return m_priority; }
    bool               IsEnabled()   const { return m_enabled; }
    void               SetEnabled(bool e)  { m_enabled = e; }

    // ==============================================================================
    // Action registration
    // ==============================================================================
    InputAction&  AddAction   (const ActionName& name, ActionType type = ActionType::Digital);
    Axis2DAction& AddAxis2D   (const ActionName& name);
    void          RemoveAction(const ActionName& name);

    // Add binding to existing action
    ActionMap& Bind(const ActionName& action, InputBinding binding);

    // Shorthand binding factories
    ActionMap& BindKey        (const ActionName& action, KeyCode key,
                                KeyMod mods = KeyMod::None);
    ActionMap& BindMouseButton(const ActionName& action, MouseButton btn);
    ActionMap& BindGamepadBtn (const ActionName& action, GamepadButton btn, int pad = 0);
    ActionMap& BindGamepadAxis(const ActionName& action, GamepadAxis axis,
                                float scale = 1.0f, int pad = 0);

    // ==============================================================================
    // Query
    // ==============================================================================
    InputAction*  FindAction (const ActionName& name);
    Axis2DAction* FindAxis2D (const ActionName& name);

    bool    IsPressed (const ActionName& name) const;
    bool    IsHeld    (const ActionName& name) const;
    bool    IsReleased(const ActionName& name) const;
    float   GetValue  (const ActionName& name) const;
    Vector2 GetAxis2D (const ActionName& name) const;

    // ==============================================================================
    // Frame update — called by InputManager
    // ==============================================================================
    void Update(const Keyboard&      kb,
                const Mouse&         mouse,
                const GamepadManager& gamepads);

    // ==============================================================================
    // Rebinding support
    // ==============================================================================
    // Replace binding at index for action
    void RebindAction(const ActionName& action, int bindingIndex, InputBinding newBinding);
    // Clear all bindings for action
    void ClearBindings(const ActionName& action);
    // Serialize to / restore from a simple key=value string
    std::string  Serialize() const;
    bool         Deserialize(const std::string& data);

    const std::unordered_map<ActionName, InputAction>&  GetActions() const { return m_actions;  }
    const std::unordered_map<ActionName, Axis2DAction>& GetAxes2D()  const { return m_axes2D;   }

private:
    float EvaluateBinding(const InputBinding& b,
                           const Keyboard& kb,
                           const Mouse& mouse,
                           const GamepadManager& pads) const;

    void  EvaluateAction (InputAction& action,
                           const Keyboard& kb,
                           const Mouse& mouse,
                           const GamepadManager& pads);

    void  EvaluateAxis2D (Axis2DAction& axis,
                           const Keyboard& kb,
                           const Mouse& mouse,
                           const GamepadManager& pads);

    std::string                                  m_name;
    int                                          m_priority = 0;
    bool                                         m_enabled  = true;
    std::unordered_map<ActionName, InputAction>  m_actions;
    std::unordered_map<ActionName, Axis2DAction> m_axes2D;
};

} // namespace BADGE2D
