// ==============================================================================
// ActionMap.cpp
// ==============================================================================

#include "ActionMap.h"
#include <cmath>
#include <sstream>
#include <algorithm>

namespace BADGE2D {

ActionMap::ActionMap(std::string name, int priority)
    : m_name(std::move(name)), m_priority(priority) {}

// ==============================================================================
// Registration
// ==============================================================================
InputAction& ActionMap::AddAction(const ActionName& name, ActionType type) {
    auto& a = m_actions[name];
    a.name  = name;
    a.type  = type;
    return a;
}

Axis2DAction& ActionMap::AddAxis2D(const ActionName& name) {
    auto& a = m_axes2D[name];
    a.name  = name;
    return a;
}

void ActionMap::RemoveAction(const ActionName& name) {
    m_actions.erase(name);
    m_axes2D.erase(name);
}

ActionMap& ActionMap::Bind(const ActionName& action, InputBinding binding) {
    m_actions[action].bindings.push_back(std::move(binding));
    return *this;
}

ActionMap& ActionMap::BindKey(const ActionName& action, KeyCode key, KeyMod mods) {
    if (m_actions.find(action) == m_actions.end()) AddAction(action);
    return Bind(action, InputBinding::FromKey(key, mods));
}

ActionMap& ActionMap::BindMouseButton(const ActionName& action, MouseButton btn) {
    if (m_actions.find(action) == m_actions.end()) AddAction(action);
    return Bind(action, InputBinding::FromMouseButton(btn));
}

ActionMap& ActionMap::BindGamepadBtn(const ActionName& action, GamepadButton btn, int pad) {
    if (m_actions.find(action) == m_actions.end()) AddAction(action);
    return Bind(action, InputBinding::FromGamepadButton(btn, pad));
}

ActionMap& ActionMap::BindGamepadAxis(const ActionName& action,
                                        GamepadAxis axis, float scale, int pad) {
    if (m_actions.find(action) == m_actions.end()) AddAction(ActionType::Analog);
    return Bind(action, InputBinding::FromGamepadAxis(axis, scale, pad));
}

// ==============================================================================
// Query
// ==============================================================================
InputAction* ActionMap::FindAction(const ActionName& name) {
    auto it = m_actions.find(name); return it != m_actions.end() ? &it->second : nullptr;
}
Axis2DAction* ActionMap::FindAxis2D(const ActionName& name) {
    auto it = m_axes2D.find(name);  return it != m_axes2D.end()  ? &it->second : nullptr;
}

bool ActionMap::IsPressed (const ActionName& n) const {
    auto it = m_actions.find(n);
    return it != m_actions.end() && it->second.state == InputState::Pressed;
}
bool ActionMap::IsHeld    (const ActionName& n) const {
    auto it = m_actions.find(n);
    return it != m_actions.end() && (it->second.state == InputState::Held ||
                                      it->second.state == InputState::Pressed);
}
bool ActionMap::IsReleased(const ActionName& n) const {
    auto it = m_actions.find(n);
    return it != m_actions.end() && it->second.state == InputState::Released;
}
float ActionMap::GetValue(const ActionName& n) const {
    auto it = m_actions.find(n);
    return it != m_actions.end() ? it->second.value : 0.0f;
}
Vector2 ActionMap::GetAxis2D(const ActionName& n) const {
    auto it = m_axes2D.find(n);
    return it != m_axes2D.end() ? it->second.value : Vector2{};
}

// ==============================================================================
// Binding evaluation
// ==============================================================================
float ActionMap::EvaluateBinding(const InputBinding& b,
                                   const Keyboard&      kb,
                                   const Mouse&         mouse,
                                   const GamepadManager& pads) const {
    switch (b.type) {

    case BindingType::Key: {
        // Check modifier requirements
        if (b.requiredMods != KeyMod::None &&
            (kb.GetModifiers() & b.requiredMods) != b.requiredMods) return 0.0f;
        return kb.IsKey(b.key) ? b.scale : 0.0f;
    }

    case BindingType::MouseButton:
        return mouse.IsButton(b.mouseButton) ? b.scale : 0.0f;

    case BindingType::MouseAxisX:
        return mouse.GetDelta().x * b.scale * (b.inverted ? -1.0f : 1.0f);

    case BindingType::MouseAxisY:
        return mouse.GetDelta().y * b.scale * (b.inverted ? -1.0f : 1.0f);

    case BindingType::MouseScrollX:
        return mouse.GetScrollX() * b.scale;

    case BindingType::MouseScrollY:
        return mouse.GetScrollY() * b.scale;

    case BindingType::GamepadButton: {
        const Gamepad* pad = pads.GetGamepad(b.gamepadIndex);
        if (!pad || !pad->IsConnected()) return 0.0f;
        return pad->IsButton(b.padButton) ? b.scale : 0.0f;
    }

    case BindingType::GamepadAxis: {
        const Gamepad* pad = pads.GetGamepad(b.gamepadIndex);
        if (!pad || !pad->IsConnected()) return 0.0f;
        float v = pad->GetAxis(b.padAxis) * b.scale;
        return b.inverted ? -v : v;
    }

    case BindingType::GamepadAxisPos: {
        const Gamepad* pad = pads.GetGamepad(b.gamepadIndex);
        if (!pad || !pad->IsConnected()) return 0.0f;
        float v = pad->GetAxis(b.padAxis);
        return (v > 0.0f) ? v : 0.0f;
    }

    case BindingType::GamepadAxisNeg: {
        const Gamepad* pad = pads.GetGamepad(b.gamepadIndex);
        if (!pad || !pad->IsConnected()) return 0.0f;
        float v = pad->GetAxis(b.padAxis);
        return (v < 0.0f) ? -v : 0.0f;
    }

    default: return 0.0f;
    }
}

// ==============================================================================
// Returns true if a binding is "just pressed" (rising edge) this frame
// ==============================================================================
static bool IsBindingPressed(const InputBinding& b,
                               const Keyboard& kb,
                               const Mouse& mouse,
                               const GamepadManager& pads) {
    switch (b.type) {
    case BindingType::Key:
        return kb.IsKeyDown(b.key);
    case BindingType::MouseButton:
        return mouse.IsButtonDown(b.mouseButton);
    case BindingType::GamepadButton: {
        const Gamepad* pad = pads.GetGamepad(b.gamepadIndex);
        return pad && pad->IsButtonDown(b.padButton);
    }
    default: return false;
    }
}

static bool IsBindingReleased(const InputBinding& b,
                                const Keyboard& kb,
                                const Mouse& mouse,
                                const GamepadManager& pads) {
    switch (b.type) {
    case BindingType::Key:
        return kb.IsKeyUp(b.key);
    case BindingType::MouseButton:
        return mouse.IsButtonUp(b.mouseButton);
    case BindingType::GamepadButton: {
        const Gamepad* pad = pads.GetGamepad(b.gamepadIndex);
        return pad && pad->IsButtonUp(b.padButton);
    }
    default: return false;
    }
}

// ==============================================================================
// EvaluateAction
// ==============================================================================
void ActionMap::EvaluateAction(InputAction& action,
                                 const Keyboard& kb,
                                 const Mouse& mouse,
                                 const GamepadManager& pads) {
    float prevValue = action.value;
    InputState prevState = action.state;

    // Accumulate across bindings (max absolute value wins for analog)
    float newValue  = 0.0f;
    bool  anyPressed  = false;
    bool  anyReleased = false;

    for (const auto& b : action.bindings) {
        float v = EvaluateBinding(b, kb, mouse, pads);
        if (std::abs(v) > std::abs(newValue)) newValue = v;

        anyPressed  = anyPressed  || IsBindingPressed (b, kb, mouse, pads);
        anyReleased = anyReleased || IsBindingReleased(b, kb, mouse, pads);
    }

    action.value = newValue;

    // State machine
    if (action.type == ActionType::Digital) {
        bool active   = (std::abs(newValue) > 0.5f);
        bool wasActive= (std::abs(prevValue) > 0.5f);

        if (active && !wasActive)       action.state = InputState::Pressed;
        else if (active && wasActive)   action.state = InputState::Held;
        else if (!active && wasActive)  action.state = InputState::Released;
        else                            action.state = InputState::None;
    } else {
        // Analog: use change threshold for Pressed/Released events
        bool active    = (std::abs(newValue) > 0.01f);
        bool wasActive = (std::abs(prevValue) > 0.01f);
        if (active && !wasActive)       action.state = InputState::Pressed;
        else if (active)                action.state = InputState::Held;
        else if (!active && wasActive)  action.state = InputState::Released;
        else                            action.state = InputState::None;
    }

    // Fire callbacks
    if (action.state != prevState || newValue != prevValue) {
        if (action.OnChange)  action.OnChange(newValue);
    }
    if (action.state == InputState::Pressed  && action.OnPress)   action.OnPress();
    if (action.state == InputState::Released && action.OnRelease) action.OnRelease();
}

// ==============================================================================
// EvaluateAxis2D
// ==============================================================================
void ActionMap::EvaluateAxis2D(Axis2DAction& axis,
                                 const Keyboard& kb,
                                 const Mouse& mouse,
                                 const GamepadManager& pads) {
    Vector2 v = {};

    if (axis.useStick) {
        const Gamepad* pad = pads.GetGamepad(axis.gamepadIndex);
        if (pad && pad->IsConnected()) {
            v.x = pad->GetAxis(axis.stickX);
            v.y = pad->GetAxis(axis.stickY);
        }
    } else {
        // Compose from four digital actions
        auto get = [&](const ActionName& n) -> float {
            if (n.empty()) return 0.0f;
            auto it = m_actions.find(n);
            return it != m_actions.end() ? it->second.value : 0.0f;
        };
        v.x = get(axis.positiveX) - get(axis.negativeX);
        v.y = get(axis.positiveY) - get(axis.negativeY);
    }

    if (axis.normalize) {
        float len = v.Length();
        if (len > 1.0f) v = v * (1.0f / len);
    }
    axis.value = v;
}

// ==============================================================================
// Update — full frame evaluation
// ==============================================================================
void ActionMap::Update(const Keyboard&       kb,
                         const Mouse&         mouse,
                         const GamepadManager& pads) {
    if (!m_enabled) return;
    for (auto& [name, action] : m_actions)
        EvaluateAction(action, kb, mouse, pads);
    for (auto& [name, axis] : m_axes2D)
        EvaluateAxis2D(axis, kb, mouse, pads);
}

// ==============================================================================
// Rebinding
// ==============================================================================
void ActionMap::RebindAction(const ActionName& name,
                               int index, InputBinding newBinding) {
    auto it = m_actions.find(name);
    if (it == m_actions.end()) return;
    auto& bindings = it->second.bindings;
    if (index >= 0 && index < (int)bindings.size())
        bindings[index] = std::move(newBinding);
}

void ActionMap::ClearBindings(const ActionName& name) {
    auto it = m_actions.find(name);
    if (it != m_actions.end()) it->second.bindings.clear();
}

// ==============================================================================
// Serialization — simple "action:type:code\n" format
// ==============================================================================
std::string ActionMap::Serialize() const {
    std::ostringstream ss;
    ss << "[ActionMap:" << m_name << "]\n";
    for (const auto& [name, action] : m_actions) {
        for (const auto& b : action.bindings) {
            ss << name << "=";
            switch (b.type) {
            case BindingType::Key:
                ss << "key:" << (int)b.key << ":" << (int)b.requiredMods; break;
            case BindingType::MouseButton:
                ss << "mouse:" << (int)b.mouseButton; break;
            case BindingType::GamepadButton:
                ss << "gpbtn:" << (int)b.padButton << ":" << b.gamepadIndex; break;
            case BindingType::GamepadAxis:
                ss << "gpaxis:" << (int)b.padAxis << ":" << b.scale << ":" << b.gamepadIndex; break;
            default:
                ss << "other:" << (int)b.type; break;
            }
            ss << "\n";
        }
    }
    return ss.str();
}

bool ActionMap::Deserialize(const std::string& data) {
    std::istringstream ss(data);
    std::string line;
    while (std::getline(ss, line)) {
        if (line.empty() || line[0] == '[' || line[0] == '#') continue;
        auto eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string name = line.substr(0, eq);
        std::string rest = line.substr(eq + 1);

        InputBinding b;
        auto colon = rest.find(':');
        std::string typeStr = rest.substr(0, colon);
        rest = (colon != std::string::npos) ? rest.substr(colon + 1) : "";

        if (typeStr == "key") {
            b.type = BindingType::Key;
            auto c2 = rest.find(':');
            b.key = (KeyCode)std::stoi(rest.substr(0, c2));
            if (c2 != std::string::npos)
                b.requiredMods = (KeyMod)std::stoi(rest.substr(c2 + 1));
        } else if (typeStr == "mouse") {
            b.type = BindingType::MouseButton;
            b.mouseButton = (MouseButton)std::stoi(rest);
        } else if (typeStr == "gpbtn") {
            b.type = BindingType::GamepadButton;
            auto c2 = rest.find(':');
            b.padButton = (GamepadButton)std::stoi(rest.substr(0, c2));
            if (c2 != std::string::npos) b.gamepadIndex = std::stoi(rest.substr(c2 + 1));
        }

        if (m_actions.find(name) != m_actions.end())
            m_actions[name].bindings.push_back(b);
    }
    return true;
}

} // namespace BADGE2D
