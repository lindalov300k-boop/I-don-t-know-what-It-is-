// ==============================================================================
// Gamepad.cpp — Gamepad polling via GLFW joystick API
// ==============================================================================

#include "Gamepad.h"
#include "../../engine/Logging/Logger.h"
#include <cstring>
#include <cmath>
#include <algorithm>

// GLFW forward declarations (avoid full header dependency)
#ifdef __has_include
  #if __has_include(<GLFW/glfw3.h>)
    #include <GLFW/glfw3.h>
    #define BADGE2D_HAS_GLFW_GAMEPAD 1
  #endif
#endif

#ifndef GLFW_JOYSTICK_1
  // Stub constants for headless builds
  #define GLFW_JOYSTICK_1  0
  #define GLFW_JOYSTICK_LAST 15
  #define GLFW_TRUE  1
  #define GLFW_FALSE 0
  struct GLFWgamepadstate {
    unsigned char buttons[15];
    float axes[6];
  };
  inline int  glfwJoystickPresent(int)               { return 0; }
  inline int  glfwJoystickIsGamepad(int)              { return 0; }
  inline const char* glfwGetJoystickName(int)         { return ""; }
  inline int  glfwGetGamepadState(int, GLFWgamepadstate*) { return 0; }
#endif

namespace BADGE2D {

// ==============================================================================
// Deadzone helpers
// ==============================================================================
float Gamepad::ApplyDeadzone(float value, float deadzone) const {
    if (std::abs(value) < deadzone) return 0.0f;
    if (m_deadzoneMode == DeadzoneMode::ScaledRadial)
        return (value - std::copysign(deadzone, value)) / (1.0f - deadzone);
    return value;
}

Vector2 Gamepad::ApplyRadialDeadzone(Vector2 stick, float deadzone) const {
    float len = stick.Length();
    if (len < deadzone) return {};
    if (m_deadzoneMode == DeadzoneMode::ScaledRadial) {
        float scale = (len - deadzone) / (1.0f - deadzone) / len;
        return stick * scale;
    }
    return stick;
}

// ==============================================================================
// Buttons
// ==============================================================================
bool Gamepad::IsButton(GamepadButton btn) const {
    int i = (int)btn;
    return m_state.connected && i >= 0 && i < (int)GamepadButton::Count
        && m_state.buttons[i];
}
bool Gamepad::IsButtonDown(GamepadButton btn) const {
    int i = (int)btn;
    if (!m_state.connected || i < 0 || i >= (int)GamepadButton::Count) return false;
    return m_state.buttons[i] && !m_state.prevButtons[i];
}
bool Gamepad::IsButtonUp(GamepadButton btn) const {
    int i = (int)btn;
    if (!m_state.connected || i < 0 || i >= (int)GamepadButton::Count) return false;
    return !m_state.buttons[i] && m_state.prevButtons[i];
}
bool Gamepad::IsButtonHeld(GamepadButton btn) const {
    int i = (int)btn;
    if (!m_state.connected || i < 0 || i >= (int)GamepadButton::Count) return false;
    return m_state.buttons[i] && m_state.prevButtons[i];
}

// ==============================================================================
// Axes
// ==============================================================================
float Gamepad::GetAxisRaw(GamepadAxis axis) const {
    int i = (int)axis;
    if (!m_state.connected || i < 0 || i >= (int)GamepadAxis::Count) return 0.0f;
    return m_state.axes[i];
}

float Gamepad::GetAxis(GamepadAxis axis) const {
    float raw = GetAxisRaw(axis);
    switch (axis) {
        case GamepadAxis::LeftX:
        case GamepadAxis::LeftY:
            return ApplyDeadzone(raw, m_state.leftDeadzone);
        case GamepadAxis::RightX:
        case GamepadAxis::RightY:
            return ApplyDeadzone(raw, m_state.rightDeadzone);
        case GamepadAxis::LeftTrigger:
        case GamepadAxis::RightTrigger:
            return raw < m_state.triggerDeadzone ? 0.0f : raw;
        default:
            return raw;
    }
}

Vector2 Gamepad::GetLeftStick() const {
    Vector2 raw = { GetAxisRaw(GamepadAxis::LeftX), GetAxisRaw(GamepadAxis::LeftY) };
    return ApplyRadialDeadzone(raw, m_state.leftDeadzone);
}

Vector2 Gamepad::GetRightStick() const {
    Vector2 raw = { GetAxisRaw(GamepadAxis::RightX), GetAxisRaw(GamepadAxis::RightY) };
    return ApplyRadialDeadzone(raw, m_state.rightDeadzone);
}

float Gamepad::GetLeftTrigger()  const { return GetAxis(GamepadAxis::LeftTrigger);  }
float Gamepad::GetRightTrigger() const { return GetAxis(GamepadAxis::RightTrigger); }

// ==============================================================================
// Rumble
// ==============================================================================
void Gamepad::SetRumble(float low, float high, float duration) {
    m_rumbleLow   = std::clamp(low,  0.0f, 1.0f);
    m_rumbleHigh  = std::clamp(high, 0.0f, 1.0f);
    m_rumbleTimer = duration;
    // Note: GLFW 3.3+ supports glfwSetJoystickUserPointer but not rumble natively.
    // Real rumble requires platform-specific APIs (XInput on Windows, evdev on Linux).
    // This tracks the intent; platform layer can hook in.
    LOG_DEBUGF("[Gamepad %d] Rumble: low=%.2f high=%.2f dur=%.2f",
               m_index, low, high, duration);
}

void Gamepad::StopRumble() {
    m_rumbleTimer = 0.0f;
    m_rumbleLow = m_rumbleHigh = 0.0f;
}

void Gamepad::UpdateRumble(float dt) {
    if (m_rumbleTimer > 0.0f) {
        m_rumbleTimer -= dt;
        if (m_rumbleTimer <= 0.0f) StopRumble();
    }
}

// ==============================================================================
// Poll
// ==============================================================================
void Gamepad::Poll() {
#ifdef BADGE2D_HAS_GLFW_GAMEPAD
    bool wasConnected = m_state.connected;

    m_state.connected = (glfwJoystickPresent(m_index) == GLFW_TRUE &&
                         glfwJoystickIsGamepad(m_index) == GLFW_TRUE);

    if (m_state.connected != wasConnected) {
        if (m_state.connected) {
            m_state.name = glfwGetJoystickName(m_index);
            LOG_INFOF("[Gamepad %d] Connected: %s", m_index, m_state.name.c_str());
        } else {
            LOG_INFOF("[Gamepad %d] Disconnected.", m_index);
        }
        if (OnConnectionChange) OnConnectionChange(m_index, m_state.connected);
    }

    if (!m_state.connected) return;

    GLFWgamepadstate gs;
    if (glfwGetGamepadState(m_index, &gs) == GLFW_TRUE) {
        for (int i = 0; i < (int)GamepadButton::Count; ++i) {
            bool prev = m_state.buttons[i];
            m_state.buttons[i] = (gs.buttons[i] == GLFW_TRUE);
            if (OnButtonChange && m_state.buttons[i] != prev)
                OnButtonChange((GamepadButton)i, m_state.buttons[i]);
        }
        for (int i = 0; i < (int)GamepadAxis::Count; ++i)
            m_state.axes[i] = gs.axes[i];
    }
#else
    m_state.connected = false;
#endif
}

void Gamepad::BeginFrame() {
    m_state.prevButtons = m_state.buttons;
    m_state.prevAxes    = m_state.axes;
}

// ==============================================================================
// GamepadManager
// ==============================================================================
GamepadManager& GamepadManager::Get() {
    static GamepadManager instance;
    return instance;
}

void GamepadManager::Initialize() {
    m_initialized = true;
    PollConnectionStatus();
    LOG_INFO("[GamepadManager] Initialized.");
}

void GamepadManager::Shutdown() {
    for (auto& p : m_pads) p.StopRumble();
    m_initialized = false;
}

void GamepadManager::BeginFrame() {
    for (auto& pad : m_pads) {
        pad.BeginFrame();
        pad.Poll();
    }
}

void GamepadManager::EndFrame() {
    // Nothing needed currently
}

void GamepadManager::PollConnectionStatus() {
    for (auto& pad : m_pads) pad.Poll();
}

Gamepad* GamepadManager::GetGamepad(int index) {
    if (index < 0 || index >= MAX_GAMEPADS) return nullptr;
    return &m_pads[index];
}

const Gamepad* GamepadManager::GetGamepad(int index) const {
    if (index < 0 || index >= MAX_GAMEPADS) return nullptr;
    return &m_pads[index];
}

Gamepad* GamepadManager::GetPrimary() {
    for (auto& p : m_pads)
        if (p.IsConnected()) return &p;
    return &m_pads[0];  // Return pad 0 even if disconnected
}

int GamepadManager::GetConnectedCount() const {
    int count = 0;
    for (const auto& p : m_pads) if (p.IsConnected()) ++count;
    return count;
}

} // namespace BADGE2D
