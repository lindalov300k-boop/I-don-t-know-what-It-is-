#pragma once
// ==============================================================================
// Gamepad.h — Gamepad / controller input with deadzone, rumble, hot-plug
// Supports up to 4 controllers simultaneously.
// ==============================================================================

#include "../InputCodes.h"
#include "../../utilities/Math/MathUtils.h"
#include <array>
#include <string>
#include <functional>

namespace BADGE2D {

constexpr int MAX_GAMEPADS = 4;

// ==============================================================================
// DeadzoneMode — How to apply deadzone processing
// ==============================================================================
enum class DeadzoneMode {
    None,        // Raw axis value (no deadzone)
    Axial,       // Deadzone per-axis independently
    Radial,      // Deadzone as circle on stick
    ScaledRadial // Radial + scale remaining range to [0, 1]
};

// ==============================================================================
// GamepadState — All state for one controller
// ==============================================================================
struct GamepadState {
    bool connected = false;
    std::string name;

    std::array<bool,  (int)GamepadButton::Count> buttons     = {};
    std::array<bool,  (int)GamepadButton::Count> prevButtons = {};
    std::array<float, (int)GamepadAxis::Count>   axes        = {};
    std::array<float, (int)GamepadAxis::Count>   prevAxes    = {};

    float leftDeadzone  = 0.12f;
    float rightDeadzone = 0.12f;
    float triggerDeadzone = 0.05f;
};

// ==============================================================================
// Gamepad — Single controller interface
// ==============================================================================
class Gamepad {
public:
    explicit Gamepad(int index) : m_index(index) {}

    // ==============================================================================
    // Connection
    // ==============================================================================
    bool IsConnected() const { return m_state.connected; }
    int  GetIndex()    const { return m_index; }
    const std::string& GetName() const { return m_state.name; }

    // ==============================================================================
    // Buttons
    // ==============================================================================
    bool IsButton    (GamepadButton btn) const;
    bool IsButtonDown(GamepadButton btn) const;  // Pressed this frame
    bool IsButtonUp  (GamepadButton btn) const;  // Released this frame
    bool IsButtonHeld(GamepadButton btn) const;  // Held > 1 frame

    // Common aliases
    bool IsFaceDown ()  const { return IsButton(GamepadButton::A); }
    bool IsFaceRight()  const { return IsButton(GamepadButton::B); }
    bool IsFaceLeft ()  const { return IsButton(GamepadButton::X); }
    bool IsFaceUp   ()  const { return IsButton(GamepadButton::Y); }
    bool IsStart    ()  const { return IsButtonDown(GamepadButton::Start); }
    bool IsBack     ()  const { return IsButtonDown(GamepadButton::Back); }

    // ==============================================================================
    // Axes — values after deadzone processing, in [-1, 1] or [0, 1] for triggers
    // ==============================================================================
    float     GetAxis      (GamepadAxis axis) const;
    Vector2   GetLeftStick ()  const;
    Vector2   GetRightStick()  const;
    float     GetLeftTrigger ()  const;
    float     GetRightTrigger()  const;

    // Raw axis (no deadzone)
    float     GetAxisRaw(GamepadAxis axis) const;

    // ==============================================================================
    // Rumble / vibration
    // ==============================================================================
    void SetRumble(float lowFreq, float highFreq, float duration = 0.1f);
    void StopRumble();
    void UpdateRumble(float dt);
    bool IsRumbling() const { return m_rumbleTimer > 0.0f; }

    // ==============================================================================
    // Deadzone configuration
    // ==============================================================================
    void SetDeadzoneMode(DeadzoneMode mode)      { m_deadzoneMode = mode; }
    void SetLeftDeadzone(float d)                { m_state.leftDeadzone  = d; }
    void SetRightDeadzone(float d)               { m_state.rightDeadzone = d; }

    // ==============================================================================
    // Frame update — called by GamepadManager
    // ==============================================================================
    void Poll();
    void BeginFrame();

    // Callbacks
    std::function<void(int, bool)>          OnConnectionChange;  // (index, connected)
    std::function<void(GamepadButton, bool)> OnButtonChange;

private:
    float ApplyDeadzone(float value, float deadzone) const;
    Vector2 ApplyRadialDeadzone(Vector2 stick, float deadzone) const;

    int           m_index        = 0;
    GamepadState  m_state;
    DeadzoneMode  m_deadzoneMode = DeadzoneMode::ScaledRadial;

    float   m_rumbleTimer  = 0.0f;
    float   m_rumbleLow    = 0.0f;
    float   m_rumbleHigh   = 0.0f;
};

// ==============================================================================
// GamepadManager — Manages all connected controllers
// ==============================================================================
class GamepadManager {
public:
    static GamepadManager& Get();

    void Initialize();
    void Shutdown();

    void BeginFrame();  // Poll all pads, update state
    void EndFrame();

    // Access a specific controller (0–3)
    Gamepad*       GetGamepad(int index);
    const Gamepad* GetGamepad(int index) const;

    // Get the first connected controller (common case)
    Gamepad*       GetPrimary();

    int GetConnectedCount() const;

    // Hot-plug callbacks
    std::function<void(int /*index*/)> OnConnected;
    std::function<void(int /*index*/)> OnDisconnected;

private:
    GamepadManager() = default;
    void PollConnectionStatus();

    std::array<Gamepad, MAX_GAMEPADS> m_pads = {
        Gamepad(0), Gamepad(1), Gamepad(2), Gamepad(3)
    };
    bool m_initialized = false;
};

} // namespace BADGE2D
