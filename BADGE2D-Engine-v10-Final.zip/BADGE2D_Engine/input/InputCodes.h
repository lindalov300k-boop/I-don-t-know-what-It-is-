#pragma once
// ==============================================================================
// InputCodes.h — Platform-independent input code enumerations
// Key codes mirror GLFW where practical so they can be used directly.
// ==============================================================================

#include <cstdint>

namespace BADGE2D {

// ==============================================================================
// KeyCode — Keyboard keys (GLFW-compatible values)
// ==============================================================================
enum class KeyCode : int {
    Unknown       = -1,

    // Printable
    Space         = 32,
    Apostrophe    = 39,
    Comma         = 44,
    Minus         = 45,
    Period        = 46,
    Slash         = 47,

    D0 = 48, D1, D2, D3, D4, D5, D6, D7, D8, D9,

    Semicolon     = 59,
    Equal         = 61,

    A = 65, B, C, D, E, F, G, H, I, J, K, L, M,
    N, O, P, Q, R, S, T, U, V, W, X, Y, Z,

    LeftBracket   = 91,
    Backslash     = 92,
    RightBracket  = 93,
    GraveAccent   = 96,

    // Function keys
    Escape        = 256,
    Enter         = 257,
    Tab           = 258,
    Backspace     = 259,
    Insert        = 260,
    Delete        = 261,
    Right         = 262,
    Left          = 263,
    Down          = 264,
    Up            = 265,
    PageUp        = 266,
    PageDown      = 267,
    Home          = 268,
    End           = 269,
    CapsLock      = 280,
    ScrollLock    = 281,
    NumLock       = 282,
    PrintScreen   = 283,
    Pause         = 284,
    F1  = 290, F2,  F3,  F4,  F5,  F6,
    F7  = 296, F8,  F9, F10, F11, F12,

    // Numpad
    KP0 = 320, KP1, KP2, KP3, KP4,
    KP5 = 325, KP6, KP7, KP8, KP9,
    KPDecimal  = 330,
    KPDivide   = 331,
    KPMultiply = 332,
    KPSubtract = 333,
    KPAdd      = 334,
    KPEnter    = 335,
    KPEqual    = 336,

    // Modifiers
    LeftShift   = 340,
    LeftControl = 341,
    LeftAlt     = 342,
    LeftSuper   = 343,
    RightShift  = 344,
    RightControl= 345,
    RightAlt    = 346,
    RightSuper  = 347,
    Menu        = 348,

    Count       = 349
};

// ==============================================================================
// KeyMod — Modifier key bitmask
// ==============================================================================
enum class KeyMod : int {
    None    = 0,
    Shift   = (1 << 0),
    Control = (1 << 1),
    Alt     = (1 << 2),
    Super   = (1 << 3),
    CapsLock= (1 << 4),
    NumLock = (1 << 5)
};
inline KeyMod operator|(KeyMod a, KeyMod b) { return (KeyMod)((int)a | (int)b); }
inline KeyMod operator&(KeyMod a, KeyMod b) { return (KeyMod)((int)a & (int)b); }
inline bool HasMod(KeyMod mods, KeyMod flag) { return ((int)mods & (int)flag) != 0; }

// ==============================================================================
// MouseButton
// ==============================================================================
enum class MouseButton : int {
    Left    = 0,
    Right   = 1,
    Middle  = 2,
    X1      = 3,
    X2      = 4,
    Count   = 8
};

// ==============================================================================
// GamepadButton — Xbox/generic naming
// ==============================================================================
enum class GamepadButton : int {
    // Face
    A            = 0,   // Cross (PS) / A (Xbox) / B (Nintendo)
    B            = 1,   // Circle / B / A
    X            = 2,   // Square / X / Y
    Y            = 3,   // Triangle / Y / X

    // Shoulder
    LeftBumper   = 4,
    RightBumper  = 5,

    // View/Menu
    Back         = 6,
    Start        = 7,
    Guide        = 8,   // Xbox button

    // Thumb
    LeftThumb    = 9,
    RightThumb   = 10,

    // D-Pad
    DPadUp       = 11,
    DPadRight    = 12,
    DPadDown     = 13,
    DPadLeft     = 14,

    Count        = 15
};

// ==============================================================================
// GamepadAxis
// ==============================================================================
enum class GamepadAxis : int {
    LeftX        = 0,
    LeftY        = 1,
    RightX       = 2,
    RightY       = 3,
    LeftTrigger  = 4,   // [0, 1]
    RightTrigger = 5,   // [0, 1]
    Count        = 6
};

// ==============================================================================
// InputAction state
// ==============================================================================
enum class InputState : uint8_t {
    None      = 0,
    Pressed   = 1,   // First frame down
    Held      = 2,   // Held down
    Released  = 3    // First frame up
};

// ==============================================================================
// CursorMode
// ==============================================================================
enum class CursorMode {
    Normal,          // Visible, free
    Hidden,          // Hidden, free
    Locked           // Captured (FPS-style)
};

} // namespace BADGE2D
