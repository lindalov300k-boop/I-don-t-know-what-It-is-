// ==============================================================================
// Keyboard.cpp
// ==============================================================================

#include "Keyboard.h"
#include <algorithm>

namespace BADGE2D {

// GLFW action constants (avoid including GLFW header here)
static constexpr int GLFW_PRESS   = 1;
static constexpr int GLFW_RELEASE = 0;
static constexpr int GLFW_REPEAT  = 2;

static constexpr int GLFW_MOD_SHIFT   = 0x0001;
static constexpr int GLFW_MOD_CONTROL = 0x0002;
static constexpr int GLFW_MOD_ALT     = 0x0004;
static constexpr int GLFW_MOD_SUPER   = 0x0008;

Keyboard& Keyboard::Get() {
    static Keyboard instance;
    return instance;
}

// ==============================================================================
// Queries
// ==============================================================================
bool Keyboard::IsKey(KeyCode key) const {
    int idx = (int)key;
    if (idx < 0 || idx >= KEY_COUNT) return false;
    return m_curr[idx];
}

bool Keyboard::IsKeyDown(KeyCode key) const {
    int idx = (int)key;
    if (idx < 0 || idx >= KEY_COUNT) return false;
    return m_curr[idx] && !m_prev[idx];
}

bool Keyboard::IsKeyUp(KeyCode key) const {
    int idx = (int)key;
    if (idx < 0 || idx >= KEY_COUNT) return false;
    return !m_curr[idx] && m_prev[idx];
}

bool Keyboard::IsKeyHeld(KeyCode key) const {
    int idx = (int)key;
    if (idx < 0 || idx >= KEY_COUNT) return false;
    return m_curr[idx] && m_prev[idx];
}

bool Keyboard::IsKeyRepeating(KeyCode key) const {
    int idx = (int)key;
    if (idx < 0 || idx >= KEY_COUNT) return false;
    return m_repeat[idx];
}

bool Keyboard::IsShiftHeld()  const { return HasMod(m_mods, KeyMod::Shift); }
bool Keyboard::IsCtrlHeld()   const { return HasMod(m_mods, KeyMod::Control); }
bool Keyboard::IsAltHeld()    const { return HasMod(m_mods, KeyMod::Alt); }

// ==============================================================================
// Events (called by RenderDevice GLFW callback)
// ==============================================================================
void Keyboard::OnKeyEvent(int glfwKey, int /*scancode*/, int action, int mods) {
    // Build modifier mask
    KeyMod newMods = KeyMod::None;
    if (mods & GLFW_MOD_SHIFT)   newMods = newMods | KeyMod::Shift;
    if (mods & GLFW_MOD_CONTROL) newMods = newMods | KeyMod::Control;
    if (mods & GLFW_MOD_ALT)     newMods = newMods | KeyMod::Alt;
    if (mods & GLFW_MOD_SUPER)   newMods = newMods | KeyMod::Super;
    m_mods = newMods;

    int idx = glfwKey;
    if (idx < 0 || idx >= KEY_COUNT) return;

    if (action == GLFW_PRESS) {
        m_curr[idx]   = true;
        m_repeat[idx] = false;
        if (OnKeyStateChange) OnKeyStateChange((KeyCode)idx, InputState::Pressed);
    } else if (action == GLFW_RELEASE) {
        m_curr[idx]   = false;
        m_repeat[idx] = false;
        if (OnKeyStateChange) OnKeyStateChange((KeyCode)idx, InputState::Released);
    } else if (action == GLFW_REPEAT) {
        m_repeat[idx] = true;
    }
}

void Keyboard::OnCharEvent(unsigned int codepoint) {
    // Encode UTF-32 codepoint as UTF-8
    if (codepoint < 0x80) {
        m_textInput += (char)codepoint;
    } else if (codepoint < 0x800) {
        m_textInput += (char)(0xC0 | (codepoint >> 6));
        m_textInput += (char)(0x80 | (codepoint & 0x3F));
    } else if (codepoint < 0x10000) {
        m_textInput += (char)(0xE0 | (codepoint >> 12));
        m_textInput += (char)(0x80 | ((codepoint >> 6) & 0x3F));
        m_textInput += (char)(0x80 | (codepoint & 0x3F));
    }
}

// ==============================================================================
// Frame lifecycle
// ==============================================================================
void Keyboard::BeginFrame() {
    m_prev      = m_curr;
    m_textInput.clear();
    m_repeat.fill(false);
}

void Keyboard::EndFrame() {
    // Nothing additional needed — prev is updated at BeginFrame
}

} // namespace BADGE2D
