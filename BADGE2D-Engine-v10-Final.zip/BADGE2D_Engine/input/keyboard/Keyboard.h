#pragma once
// ==============================================================================
// Keyboard.h — Per-frame keyboard state with held / pressed / released
// ==============================================================================

#include "../InputCodes.h"
#include <array>
#include <vector>
#include <string>
#include <functional>

namespace BADGE2D {

// ==============================================================================
// Keyboard — Tracks all key states for the current and previous frame
// ==============================================================================
class Keyboard {
public:
    static Keyboard& Get();

    // ==============================================================================
    // State queries — call these during Update()
    // ==============================================================================
    bool IsKey      (KeyCode key) const;   // Held OR pressed this frame
    bool IsKeyDown  (KeyCode key) const;   // Pressed this frame (rising edge)
    bool IsKeyUp    (KeyCode key) const;   // Released this frame (falling edge)
    bool IsKeyHeld  (KeyCode key) const;   // Held for > 1 frame

    // Modifier helpers
    bool IsShiftHeld()   const;
    bool IsCtrlHeld()    const;
    bool IsAltHeld()     const;

    KeyMod GetModifiers() const { return m_mods; }

    // ==============================================================================
    // Text input — collects typed characters between BeginFrame/EndFrame
    // ==============================================================================
    const std::string& GetTextInput() const { return m_textInput; }
    bool HasTextInput() const { return !m_textInput.empty(); }

    // ==============================================================================
    // Repeat key — fires once on press, then repeats after delay
    // ==============================================================================
    bool IsKeyRepeating(KeyCode key) const;

    // ==============================================================================
    // Callbacks (registered by RenderDevice, called by GLFW)
    // ==============================================================================
    void OnKeyEvent  (int glfwKey, int /*scancode*/, int action, int mods);
    void OnCharEvent (unsigned int codepoint);

    // ==============================================================================
    // Frame lifecycle
    // ==============================================================================
    void BeginFrame();   // Snapshot current → previous
    void EndFrame();     // Clear per-frame state

    // For use by action system
    std::function<void(KeyCode, InputState)> OnKeyStateChange;

private:
    Keyboard() = default;

    static constexpr int KEY_COUNT = (int)KeyCode::Count;

    std::array<bool, KEY_COUNT> m_curr    = {};  // Current frame: is key down?
    std::array<bool, KEY_COUNT> m_prev    = {};  // Previous frame
    std::array<bool, KEY_COUNT> m_repeat  = {};  // OS-driven repeat

    KeyMod      m_mods      = KeyMod::None;
    std::string m_textInput;
};

} // namespace BADGE2D
