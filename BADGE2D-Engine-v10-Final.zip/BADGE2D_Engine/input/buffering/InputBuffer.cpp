// ==============================================================================
// InputBuffer.cpp
// ==============================================================================

#include "InputBuffer.h"
#include <algorithm>
#include <cfloat>

namespace BADGE2D {

InputBuffer::InputBuffer(double bufferDuration)
    : m_bufferDuration(bufferDuration) {}

// ==============================================================================
// Record / Tick
// ==============================================================================
void InputBuffer::RecordEvent(const ActionName& action, float value,
                                InputState state, double now) {
    m_now = now;
    BufferedEvent ev;
    ev.action    = action;
    ev.value     = value;
    ev.state     = state;
    ev.timestamp = now;
    m_events.push_back(ev);
}

void InputBuffer::Tick(double now) {
    m_now = now;
    m_triggeredCombos.clear();

    // Prune events older than buffer window
    while (!m_events.empty() &&
           (now - m_events.front().timestamp) > m_bufferDuration) {
        m_events.pop_front();
    }
}

// ==============================================================================
// WasPressed / WasReleased
// ==============================================================================
bool InputBuffer::WasPressed(const ActionName& action, double window) const {
    for (const auto& ev : m_events) {
        if (ev.consumed) continue;
        if (ev.action == action && ev.state == InputState::Pressed) {
            if ((m_now - ev.timestamp) <= window) return true;
        }
    }
    return false;
}

bool InputBuffer::WasReleased(const ActionName& action, double window) const {
    for (const auto& ev : m_events) {
        if (ev.consumed) continue;
        if (ev.action == action && ev.state == InputState::Released) {
            if ((m_now - ev.timestamp) <= window) return true;
        }
    }
    return false;
}

// ==============================================================================
// Consume
// ==============================================================================
bool InputBuffer::ConsumePress(const ActionName& action, double window) {
    // Search newest-first
    for (auto it = m_events.rbegin(); it != m_events.rend(); ++it) {
        if (it->consumed) continue;
        if (it->action == action && it->state == InputState::Pressed) {
            if ((m_now - it->timestamp) <= window) {
                it->consumed = true;
                return true;
            }
        }
    }
    return false;
}

bool InputBuffer::ConsumeRelease(const ActionName& action, double window) {
    for (auto it = m_events.rbegin(); it != m_events.rend(); ++it) {
        if (it->consumed) continue;
        if (it->action == action && it->state == InputState::Released) {
            if ((m_now - it->timestamp) <= window) {
                it->consumed = true;
                return true;
            }
        }
    }
    return false;
}

// ==============================================================================
// TimeSince
// ==============================================================================
double InputBuffer::TimeSincePressed(const ActionName& action) const {
    for (auto it = m_events.rbegin(); it != m_events.rend(); ++it) {
        if (it->action == action && it->state == InputState::Pressed)
            return m_now - it->timestamp;
    }
    return DBL_MAX;
}

double InputBuffer::TimeSinceReleased(const ActionName& action) const {
    for (auto it = m_events.rbegin(); it != m_events.rend(); ++it) {
        if (it->action == action && it->state == InputState::Released)
            return m_now - it->timestamp;
    }
    return DBL_MAX;
}

// ==============================================================================
// Coyote time
// ==============================================================================
bool InputBuffer::IsCoyotePress(const ActionName& action,
                                  double coyoteWindow, double now) const {
    double t = (now >= 0.0) ? now : m_now;
    return TimeSincePressed(action) <= coyoteWindow;
}

// ==============================================================================
// Combo system
// ==============================================================================
void InputBuffer::RegisterCombo(ComboDefinition combo) {
    m_combos.push_back(std::move(combo));
}

void InputBuffer::ClearCombos() {
    m_combos.clear();
}

void InputBuffer::CheckCombos(double now) {
    m_triggeredCombos.clear();
    if (m_events.empty()) return;

    for (auto& combo : m_combos) {
        if (combo.steps.empty()) continue;

        // Try to match the sequence from the most recent event backwards
        int stepIdx = (int)combo.steps.size() - 1;
        double prevTimestamp = now;

        for (auto it = m_events.rbegin(); it != m_events.rend() && stepIdx >= 0; ++it) {
            if (it->consumed) continue;
            const ComboStep& step = combo.steps[stepIdx];

            if (it->action == step.action && it->state == step.requiredState) {
                double gap = prevTimestamp - it->timestamp;
                if (gap <= step.maxGap) {
                    prevTimestamp = it->timestamp;
                    --stepIdx;
                }
            }
        }

        if (stepIdx < 0) {
            // All steps matched!
            m_triggeredCombos.push_back(combo.name);
            if (combo.OnTriggered) combo.OnTriggered();
        }
    }
}

bool InputBuffer::WasComboTriggered(const std::string& name) const {
    for (const auto& n : m_triggeredCombos)
        if (n == name) return true;
    return false;
}

// ==============================================================================
// Sequence match
// ==============================================================================
bool InputBuffer::MatchSequence(const std::vector<ActionName>& sequence,
                                  double totalWindow) const {
    if (sequence.empty() || m_events.empty()) return false;

    // Find the most recent press of the last action
    double endTime = -1.0;
    for (auto it = m_events.rbegin(); it != m_events.rend(); ++it) {
        if (it->action == sequence.back() && it->state == InputState::Pressed) {
            endTime = it->timestamp;
            break;
        }
    }
    if (endTime < 0.0) return false;

    double startTime = endTime - totalWindow;
    int stepIdx = (int)sequence.size() - 1;
    double prevTime = endTime + 0.001;

    for (auto it = m_events.rbegin(); it != m_events.rend() && stepIdx >= 0; ++it) {
        if (it->timestamp < startTime) break;
        if (it->state != InputState::Pressed) continue;
        if (it->action == sequence[stepIdx] && it->timestamp < prevTime) {
            prevTime = it->timestamp;
            --stepIdx;
        }
    }
    return stepIdx < 0;
}

} // namespace BADGE2D
