#pragma once
// ==============================================================================
// InputBuffer.h — Temporal input buffer for combo detection, coyote time,
// input anticipation, and buffered jumps in platformers.
//
// The buffer records (action, value, timestamp) tuples for a configurable
// number of seconds. Consumers query whether an action fired within a window.
// ==============================================================================

#include "../InputCodes.h"
#include "../actions/InputAction.h"
#include <string>
#include <vector>
#include <deque>
#include <functional>

namespace BADGE2D {

// ==============================================================================
// BufferedEvent — One input event record
// ==============================================================================
struct BufferedEvent {
    ActionName  action;
    float       value       = 0.0f;
    InputState  state       = InputState::None;
    double      timestamp   = 0.0;   // Engine time in seconds
    bool        consumed    = false; // Mark consumed to prevent double-triggering
};

// ==============================================================================
// ComboStep — One step of a combo sequence
// ==============================================================================
struct ComboStep {
    ActionName action;
    InputState requiredState = InputState::Pressed;
    float      maxGap        = 0.3f;  // Max seconds after previous step
};

// ==============================================================================
// ComboDefinition — A named sequence of combo steps
// ==============================================================================
struct ComboDefinition {
    std::string             name;
    std::vector<ComboStep>  steps;
    std::function<void()>   OnTriggered;
};

// ==============================================================================
// InputBuffer
// ==============================================================================
class InputBuffer {
public:
    // bufferDuration: how many seconds of events to retain
    explicit InputBuffer(double bufferDuration = 0.5);

    // ==============================================================================
    // Record events (called by InputManager each frame)
    // ==============================================================================
    void RecordEvent(const ActionName& action, float value, InputState state, double now);
    void Tick(double now);   // Prune old events

    // ==============================================================================
    // Query — "did this action happen recently?"
    // ==============================================================================
    // Was action pressed within the last windowSeconds?
    bool WasPressed (const ActionName& action, double windowSeconds = 0.1) const;
    bool WasReleased(const ActionName& action, double windowSeconds = 0.1) const;

    // Consume the most recent matching event (prevents re-use)
    // Returns true if it found and consumed an event
    bool ConsumePress  (const ActionName& action, double windowSeconds = 0.1);
    bool ConsumeRelease(const ActionName& action, double windowSeconds = 0.1);

    // How long ago was this action pressed (FLT_MAX if not in buffer)
    double TimeSincePressed (const ActionName& action) const;
    double TimeSinceReleased(const ActionName& action) const;

    // ==============================================================================
    // Coyote time — true if action was pressed within coyoteTime after missing
    // the ideal frame (e.g. player presses jump slightly after leaving a ledge)
    // ==============================================================================
    bool IsCoyotePress(const ActionName& action,
                       double coyoteWindow = 0.12,
                       double now = -1.0) const;

    // ==============================================================================
    // Combo detection
    // ==============================================================================
    void RegisterCombo(ComboDefinition combo);
    void ClearCombos();
    void CheckCombos(double now);
    bool WasComboTriggered(const std::string& comboName) const;

    // ==============================================================================
    // Sequence history query (fighting game style)
    // Did these actions happen in order within totalWindow?
    // ==============================================================================
    bool MatchSequence(const std::vector<ActionName>& sequence,
                       double totalWindow = 0.5) const;

    // ==============================================================================
    // Config
    // ==============================================================================
    void  SetBufferDuration(double d) { m_bufferDuration = d; }
    double GetBufferDuration() const  { return m_bufferDuration; }
    void  Clear()                     { m_events.clear(); m_triggeredCombos.clear(); }

    const std::deque<BufferedEvent>& GetEvents() const { return m_events; }

private:
    double                       m_bufferDuration;
    double                       m_now = 0.0;
    std::deque<BufferedEvent>    m_events;
    std::vector<ComboDefinition> m_combos;
    std::vector<std::string>     m_triggeredCombos;  // Combos fired this frame
};

} // namespace BADGE2D
