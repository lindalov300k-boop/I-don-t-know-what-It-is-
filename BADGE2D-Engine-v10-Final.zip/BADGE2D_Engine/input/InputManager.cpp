// ==============================================================================
// InputManager.cpp
// ==============================================================================

#include "InputManager.h"
#include "../engine/Logging/Logger.h"
#include <algorithm>
#include <fstream>

namespace BADGE2D {

InputManager& InputManager::Get() {
    static InputManager instance;
    return instance;
}

// ==============================================================================
// IModule
// ==============================================================================
bool InputManager::Initialize() {
    if (m_initialized) return true;

    GamepadManager::Get().Initialize();

    // Wire Keyboard callbacks to buffer
    Keyboard::Get().OnKeyStateChange = [this](KeyCode key, InputState state) {
        // Raw key events fed into buffer under synthetic action name "key:N"
        std::string synth = "key:" + std::to_string((int)key);
        float v = (state == InputState::Pressed || state == InputState::Held) ? 1.0f : 0.0f;
        m_buffer.RecordEvent(synth, v, state, m_time);
    };

    // Wire Mouse button callbacks to buffer
    Mouse::Get().OnButtonStateChange = [this](MouseButton btn, InputState state) {
        std::string synth = "mouse:" + std::to_string((int)btn);
        float v = (state == InputState::Pressed) ? 1.0f : 0.0f;
        m_buffer.RecordEvent(synth, v, state, m_time);
    };

    m_initialized = true;
    LOG_INFO("[InputManager] Initialized.");
    return true;
}

void InputManager::Shutdown() {
    if (!m_initialized) return;
    GamepadManager::Get().Shutdown();
    m_maps.clear();
    m_mapStack.clear();
    m_initialized = false;
    LOG_INFO("[InputManager] Shutdown.");
}

void InputManager::BeginFrame(double dt) {
    m_time += dt;

    Keyboard::Get().BeginFrame();
    Mouse::Get().BeginFrame(dt);
    GamepadManager::Get().BeginFrame();

    // Update and prune the input buffer
    m_buffer.Tick(m_time);

    // Evaluate all action maps
    UpdateMaps();

    // Feed named action events into buffer
    FeedActionsToBuffer(m_time);

    // Check for in-progress rebind
    if (m_rebind.active) PollRebind();

    // Check combos
    m_buffer.CheckCombos(m_time);
}

void InputManager::EndFrame() {
    Mouse::Get().EndFrame();
    Keyboard::Get().EndFrame();
}

// ==============================================================================
// Action maps
// ==============================================================================
ActionMap& InputManager::CreateMap(const std::string& name, int priority) {
    auto it = m_maps.find(name);
    if (it != m_maps.end()) return *it->second;
    m_maps[name] = std::make_unique<ActionMap>(name, priority);
    return *m_maps[name];
}

ActionMap* InputManager::GetMap(const std::string& name) {
    auto it = m_maps.find(name);
    return (it != m_maps.end()) ? it->second.get() : nullptr;
}

void InputManager::RemoveMap(const std::string& name) {
    m_maps.erase(name);
    m_mapStack.erase(std::remove(m_mapStack.begin(), m_mapStack.end(), name),
                      m_mapStack.end());
}

void InputManager::EnableMap(const std::string& name, bool enable) {
    auto* map = GetMap(name);
    if (map) map->SetEnabled(enable);
}

void InputManager::PushMap(const std::string& name) {
    if (auto* map = GetMap(name)) {
        map->SetEnabled(true);
        // Avoid duplicates
        m_mapStack.erase(std::remove(m_mapStack.begin(), m_mapStack.end(), name),
                          m_mapStack.end());
        m_mapStack.push_back(name);
    }
}

void InputManager::PopMap() {
    if (m_mapStack.empty()) return;
    std::string top = m_mapStack.back();
    m_mapStack.pop_back();
    if (auto* map = GetMap(top)) map->SetEnabled(false);
}

void InputManager::UpdateMaps() {
    // Sort by priority (higher priority wins for consumed events)
    std::vector<ActionMap*> sorted;
    sorted.reserve(m_maps.size());
    for (auto& [name, map] : m_maps)
        if (map->IsEnabled()) sorted.push_back(map.get());
    std::sort(sorted.begin(), sorted.end(),
        [](const ActionMap* a, const ActionMap* b){ return a->GetPriority() > b->GetPriority(); });

    auto& kb   = Keyboard::Get();
    auto& ms   = Mouse::Get();
    auto& pads = GamepadManager::Get();

    for (auto* map : sorted)
        map->Update(kb, ms, pads);
}

// ==============================================================================
// Query (first enabled map wins)
// ==============================================================================
bool InputManager::IsPressed(const ActionName& action) const {
    for (auto& [name, map] : m_maps)
        if (map->IsEnabled() && map->IsPressed(action)) return true;
    return false;
}
bool InputManager::IsHeld(const ActionName& action) const {
    for (auto& [name, map] : m_maps)
        if (map->IsEnabled() && map->IsHeld(action)) return true;
    return false;
}
bool InputManager::IsReleased(const ActionName& action) const {
    for (auto& [name, map] : m_maps)
        if (map->IsEnabled() && map->IsReleased(action)) return true;
    return false;
}
float InputManager::GetValue(const ActionName& action) const {
    for (auto& [name, map] : m_maps) {
        if (!map->IsEnabled()) continue;
        float v = map->GetValue(action);
        if (v != 0.0f) return v;
    }
    return 0.0f;
}
Vector2 InputManager::GetAxis2D(const ActionName& action) const {
    for (auto& [name, map] : m_maps) {
        if (!map->IsEnabled()) continue;
        Vector2 v = map->GetAxis2D(action);
        if (v.LengthSq() > 0.0001f) return v;
    }
    return {};
}

// ==============================================================================
// Feed named-action events to buffer (fires once per state-change per action)
// ==============================================================================
void InputManager::FeedActionsToBuffer(double now) {
    for (auto& [mapName, map] : m_maps) {
        if (!map->IsEnabled()) continue;
        for (auto& [actionName, action] : map->GetActions()) {
            if (action.state == InputState::Pressed ||
                action.state == InputState::Released) {
                m_buffer.RecordEvent(actionName, action.value, action.state, now);
            }
        }
    }
}

// ==============================================================================
// Rebinding
// ==============================================================================
void InputManager::StartRebind(const std::string& mapName,
                                 const ActionName& action,
                                 int bindingIndex,
                                 std::function<void(InputBinding)> onComplete,
                                 std::function<void()> onCancelled) {
    m_rebind.mapName      = mapName;
    m_rebind.actionName   = action;
    m_rebind.bindingIndex = bindingIndex;
    m_rebind.OnComplete   = std::move(onComplete);
    m_rebind.OnCancelled  = std::move(onCancelled);
    m_rebind.active       = true;
    LOG_INFOF("[InputManager] Listening for rebind: %s / %s",
              mapName.c_str(), action.c_str());
}

void InputManager::CancelRebind() {
    if (m_rebind.active && m_rebind.OnCancelled) m_rebind.OnCancelled();
    m_rebind.active = false;
}

void InputManager::PollRebind() {
    // Check every possible key
    InputBinding detected;
    bool found = false;

    auto& kb = Keyboard::Get();
    for (int i = 0; i < (int)KeyCode::Count && !found; ++i) {
        KeyCode k = (KeyCode)i;
        if (k == KeyCode::Escape) { CancelRebind(); return; }
        if (kb.IsKeyDown(k)) {
            detected = InputBinding::FromKey(k, kb.GetModifiers());
            found = true;
        }
    }

    auto& ms = Mouse::Get();
    for (int i = 0; i < (int)MouseButton::Count && !found; ++i) {
        if (ms.IsButtonDown((MouseButton)i)) {
            detected = InputBinding::FromMouseButton((MouseButton)i);
            found = true;
        }
    }

    auto& pads = GamepadManager::Get();
    for (int pad = 0; pad < MAX_GAMEPADS && !found; ++pad) {
        auto* gp = pads.GetGamepad(pad);
        if (!gp || !gp->IsConnected()) continue;
        for (int b = 0; b < (int)GamepadButton::Count && !found; ++b) {
            if (gp->IsButtonDown((GamepadButton)b)) {
                detected = InputBinding::FromGamepadButton((GamepadButton)b, pad);
                found = true;
            }
        }
    }

    if (found) {
        // Apply
        if (auto* map = GetMap(m_rebind.mapName)) {
            map->RebindAction(m_rebind.actionName, m_rebind.bindingIndex, detected);
        }
        if (m_rebind.OnComplete) m_rebind.OnComplete(detected);
        m_rebind.active = false;
        LOG_INFOF("[InputManager] Rebind complete: %s", m_rebind.actionName.c_str());
    }
}

// ==============================================================================
// Profile save / load
// ==============================================================================
bool InputManager::SaveProfile(const std::string& mapName,
                                 const std::string& filepath) const {
    auto it = m_maps.find(mapName);
    if (it == m_maps.end()) return false;
    std::ofstream f(filepath);
    if (!f) return false;
    f << it->second->Serialize();
    LOG_INFOF("[InputManager] Profile saved: %s", filepath.c_str());
    return true;
}

bool InputManager::LoadProfile(const std::string& mapName,
                                 const std::string& filepath) {
    auto* map = GetMap(mapName);
    if (!map) return false;
    std::ifstream f(filepath);
    if (!f) return false;
    std::string data((std::istreambuf_iterator<char>(f)),
                      std::istreambuf_iterator<char>());
    bool ok = map->Deserialize(data);
    if (ok) LOG_INFOF("[InputManager] Profile loaded: %s", filepath.c_str());
    return ok;
}

// ==============================================================================
// Cursor
// ==============================================================================
void InputManager::SetCursorMode(CursorMode mode) {
    Mouse::Get().SetCursorMode(mode);
    // RenderDevice listens to Mouse::CursorMode and applies GLFW cursor mode
}

// ==============================================================================
// Rumble
// ==============================================================================
void InputManager::Rumble(float low, float high, float duration, int pad) {
    auto* gp = GamepadManager::Get().GetGamepad(pad);
    if (gp) gp->SetRumble(low, high, duration);
}

} // namespace BADGE2D
