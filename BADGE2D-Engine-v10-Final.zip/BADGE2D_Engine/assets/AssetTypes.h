#pragma once
// ==============================================================================
// AssetTypes.h — Asset pipeline shared types
// ==============================================================================

#include <cstdint>
#include <string>
#include <functional>

namespace BADGE2D {

using AssetID   = uint64_t;
using AssetHash = uint64_t;

constexpr AssetID INVALID_ASSET = 0;

// ==============================================================================
// AssetType — Registered asset categories
// ==============================================================================
enum class AssetType : uint32_t {
    Unknown     = 0,
    Texture     = 1,
    Sound       = 2,
    Music       = 3,
    Font        = 4,
    AnimClip    = 5,
    Scene       = 6,
    Prefab      = 7,
    Shader      = 8,
    TileMap     = 9,
    Script      = 10,
    Count
};

static constexpr const char* AssetTypeNames[] = {
    "Unknown","Texture","Sound","Music","Font",
    "AnimClip","Scene","Prefab","Shader","TileMap","Script"
};

inline const char* GetAssetTypeName(AssetType t) {
    int i = (int)t;
    return (i >= 0 && i < (int)AssetType::Count) ? AssetTypeNames[i] : "Unknown";
}

inline AssetType ExtensionToAssetType(const std::string& ext) {
    if (ext=="png"||ext=="jpg"||ext=="bmp"||ext=="tga") return AssetType::Texture;
    if (ext=="wav"||ext=="ogg")                          return AssetType::Sound;
    if (ext=="mp3"||ext=="flac")                         return AssetType::Music;
    if (ext=="ttf"||ext=="otf")                          return AssetType::Font;
    if (ext=="anim")                                     return AssetType::AnimClip;
    if (ext=="scene")                                    return AssetType::Scene;
    if (ext=="prefab")                                   return AssetType::Prefab;
    if (ext=="glsl"||ext=="vert"||ext=="frag")           return AssetType::Shader;
    if (ext=="tmx"||ext=="tilemap")                      return AssetType::TileMap;
    return AssetType::Unknown;
}

// ==============================================================================
// LoadState
// ==============================================================================
enum class LoadState {
    Unloaded,
    Queued,
    Loading,
    Ready,
    Failed
};

// ==============================================================================
// AssetMeta — Descriptor stored in manifest and cache
// ==============================================================================
struct AssetMeta {
    AssetID     id           = INVALID_ASSET;
    AssetType   type         = AssetType::Unknown;
    std::string name;            // Logical asset name ("player_idle")
    std::string path;            // Relative path from asset root
    AssetHash   contentHash  = 0;
    uint64_t    lastModified = 0;
    uint64_t    sizeBytes    = 0;
    LoadState   state        = LoadState::Unloaded;
    bool        keepLoaded   = false;  // Never evict from cache
    int         refCount     = 0;
};

// ==============================================================================
// AssetHandle<T> — Type-safe reference-counted asset pointer
// ==============================================================================
template<typename T>
class AssetHandle {
public:
    AssetHandle() = default;
    explicit AssetHandle(AssetID id, std::shared_ptr<T> ptr)
        : m_id(id), m_ptr(std::move(ptr)) {}

    T*         Get()      const { return m_ptr.get();      }
    T*         operator->()const{ return m_ptr.get();      }
    T&         operator* ()const{ return *m_ptr;           }
    bool       IsValid()  const { return m_ptr != nullptr; }
    AssetID    GetID()    const { return m_id;             }
    explicit   operator bool() const { return IsValid(); }

    bool operator==(const AssetHandle& o) const { return m_id == o.m_id; }
    bool operator!=(const AssetHandle& o) const { return m_id != o.m_id; }

private:
    AssetID             m_id  = INVALID_ASSET;
    std::shared_ptr<T>  m_ptr;
};

} // namespace BADGE2D
