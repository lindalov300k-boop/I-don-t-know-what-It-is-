#pragma once
// ==============================================================================
// AssetManager.h — Phase 8 master IModule
// Ties together Manifest + Cache + Loader into one clean game-facing API.
// ==============================================================================

#include "../engine/ModuleSystem/ModuleInterface.h"
#include "AssetTypes.h"
#include "manifest/AssetManifest.h"
#include "cache/AssetCache.h"
#include "loader/AssetLoader.h"
#include "../renderer/textures/Texture2D.h"
#include "../audio/clips/SoundClip.h"
#include <string>

namespace BADGE2D {

class AssetManager : public IModule {
public:
    bool        Initialize()          override;
    void        Shutdown  ()          override;
    void        Update    (double dt) override;
    const char* GetName   ()    const override { return "AssetManager"; }
    uint32_t    GetInitOrder() const  override { return (uint32_t)ModuleInitOrder::Assets; }

    static AssetManager& Get();

    // ---- Setup ----
    void SetAssetRoot(const std::string& path);
    void SetCacheBudgetMB(int mb) { AssetCache::Get().SetBudgetBytes((size_t)mb * 1024 * 1024); }

    // ---- Scan + preload ----
    int  ScanAssets();    // Walk asset root, populate manifest
    void PreloadAll(std::function<void(float)> progress = nullptr,
                    std::function<void()>      complete = nullptr);
    void PreloadGroup(const std::vector<std::string>& names,
                      std::function<void(float)> progress = nullptr,
                      std::function<void()>      complete = nullptr);

    // ---- Typed getters ----
    AssetHandle<Texture2D>  GetTexture(const std::string& name);
    AssetHandle<Texture2D>  GetTexture(AssetID id);
    AssetHandle<SoundClip>  GetSound  (const std::string& name);
    AssetHandle<SoundClip>  GetSound  (AssetID id);

    // Generic
    template<typename T>
    AssetHandle<T> Get(const std::string& name) {
        return AssetLoader::Get().Load<T>(name);
    }

    template<typename T>
    AssetHandle<T> Get(AssetID id) {
        return AssetLoader::Get().Load<T>(id);
    }

    void LoadAsync(const std::string& name,
                   std::function<void(AssetID,bool)> cb = nullptr) {
        AssetLoader::Get().LoadAsync(name, std::move(cb));
    }

    // ---- Manifest queries ----
    AssetID    FindID  (const std::string& name) const;
    AssetType  FindType(const std::string& name) const;
    bool       Exists  (const std::string& name) const;

    // Register a run-time virtual asset (procedurally generated, not on disk)
    AssetID RegisterVirtual(const std::string& name, AssetType type) {
        return AssetManifest::Get().RegisterVirtual(name, type);
    }

    // ---- Cache control ----
    void Evict   (const std::string& name);
    void EvictAll()             { AssetCache::Get().EvictAll(); }
    void Pin     (const std::string& name, bool pin);

    // ---- Stats ----
    void PrintStats() const;

private:
    AssetManager() = default;
    bool m_initialized = false;
};

} // namespace BADGE2D
