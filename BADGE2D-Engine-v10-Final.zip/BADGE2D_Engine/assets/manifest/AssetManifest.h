#pragma once
// ==============================================================================
// AssetManifest.h — Scans the asset directory, hashes files, tracks changes
// The manifest is serialised to assets/manifest.json and loaded at startup.
// ==============================================================================

#include "../AssetTypes.h"
#include <vector>
#include <unordered_map>
#include <string>
#include <filesystem>

namespace fs = std::filesystem;

namespace BADGE2D {

// ==============================================================================
// AssetManifest
// ==============================================================================
class AssetManifest {
public:
    static AssetManifest& Get();

    // ---- Setup ----
    void SetAssetRoot(const std::string& path) { m_assetRoot = path; }
    const std::string& GetAssetRoot()    const { return m_assetRoot; }

    // ---- Scanning ----
    // Walk the asset root and register every recognised file
    int Scan();

    // ---- Hashing / change detection ----
    static AssetHash HashFile(const std::string& path);
    static AssetHash HashString(const std::string& s);

    // ---- Lookup ----
    const AssetMeta* FindByName(const std::string& name)  const;
    const AssetMeta* FindByPath(const std::string& path)  const;
    const AssetMeta* FindByID  (AssetID id)               const;

    // Returns all assets of a given type
    std::vector<const AssetMeta*> GetAllOfType(AssetType type) const;
    std::vector<const AssetMeta*> GetAll()                     const;

    // Register a programmatic asset (not on disk)
    AssetID RegisterVirtual(const std::string& name, AssetType type);

    // ---- Persistence ----
    bool SaveToFile  (const std::string& path = "") const;
    bool LoadFromFile(const std::string& path = "");

    int  GetCount() const { return (int)m_assets.size(); }

private:
    AssetManifest() = default;

    AssetID NextID() { return ++m_nextID; }

    std::string MakeLogicalName(const fs::path& p) const;

    std::unordered_map<AssetID,     AssetMeta> m_assets;
    std::unordered_map<std::string, AssetID>   m_nameIndex;
    std::unordered_map<std::string, AssetID>   m_pathIndex;

    std::string m_assetRoot  = "assets/";
    std::string m_manifestPath = "assets/manifest.json";
    AssetID     m_nextID     = 0;
};

} // namespace BADGE2D
