#include <filesystem>
// ==============================================================================
// AssetManifest.cpp
// ==============================================================================

#include "AssetManifest.h"
#include "../../engine/Logging/Logger.h"
#include <fstream>
#include <sstream>
#include <chrono>
#include <cstring>

namespace BADGE2D {

AssetManifest& AssetManifest::Get() {
    static AssetManifest instance;
    return instance;
}

// ==============================================================================
// FNV-1a 64-bit hash — fast, no deps
// ==============================================================================
AssetHash AssetManifest::HashString(const std::string& s) {
    uint64_t hash = 14695981039346656037ULL;
    for (unsigned char c : s) {
        hash ^= c;
        hash *= 1099511628211ULL;
    }
    return hash;
}

AssetHash AssetManifest::HashFile(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return 0;
    std::string content((std::istreambuf_iterator<char>(f)),
                          std::istreambuf_iterator<char>());
    return HashString(content);
}

// ==============================================================================
// Scan
// ==============================================================================
std::string AssetManifest::MakeLogicalName(const fs::path& p) const {
    fs::path rel = fs::relative(p, m_assetRoot);
    std::string s = rel.stem().string();
    return s;
}

int AssetManifest::Scan() {
    if (!fs::exists(m_assetRoot)) {
        LOG_WARNF("[AssetManifest] Asset root not found: %s", m_assetRoot.c_str());
        return 0;
    }

    int count = 0;
    for (const auto& entry : fs::recursive_directory_iterator(m_assetRoot)) {
        if (!entry.is_regular_file()) continue;

        std::string ext = entry.path().extension().string();
        if (!ext.empty()) ext = ext.substr(1); // Remove leading dot
        for (auto& c : ext) c = (char)tolower((unsigned char)c);

        AssetType type = ExtensionToAssetType(ext);
        if (type == AssetType::Unknown) continue;

        std::string path = entry.path().string();
        std::string name = MakeLogicalName(entry.path());

        if (m_pathIndex.count(path)) continue;  // Already registered

        AssetID id = NextID();
        AssetMeta meta;
        meta.id          = id;
        meta.type        = type;
        meta.name        = name;
        meta.path        = path;
        meta.sizeBytes   = (uint64_t)entry.file_size();
        meta.state       = LoadState::Unloaded;

        auto ftime        = entry.last_write_time();
        meta.lastModified = (uint64_t)ftime.time_since_epoch().count();
        // Defer hashing to first access (expensive)
        meta.contentHash = 0;

        m_assets[id]     = meta;
        m_nameIndex[name]= id;
        m_pathIndex[path]= id;
        ++count;
    }

    LOG_INFOF("[AssetManifest] Scanned '%s': %d assets found.", m_assetRoot.c_str(), count);
    return count;
}

AssetID AssetManifest::RegisterVirtual(const std::string& name, AssetType type) {
    if (m_nameIndex.count(name)) return m_nameIndex[name];
    AssetID id = NextID();
    AssetMeta meta;
    meta.id   = id;
    meta.name = name;
    meta.type = type;
    meta.path = "<virtual>";
    meta.state= LoadState::Unloaded;
    m_assets[id]      = meta;
    m_nameIndex[name] = id;
    return id;
}

// ==============================================================================
// Lookup
// ==============================================================================
const AssetMeta* AssetManifest::FindByName(const std::string& name) const {
    auto it = m_nameIndex.find(name);
    if (it == m_nameIndex.end()) return nullptr;
    return FindByID(it->second);
}

const AssetMeta* AssetManifest::FindByPath(const std::string& path) const {
    auto it = m_pathIndex.find(path);
    if (it == m_pathIndex.end()) return nullptr;
    return FindByID(it->second);
}

const AssetMeta* AssetManifest::FindByID(AssetID id) const {
    auto it = m_assets.find(id);
    return (it != m_assets.end()) ? &it->second : nullptr;
}

std::vector<const AssetMeta*> AssetManifest::GetAllOfType(AssetType type) const {
    std::vector<const AssetMeta*> result;
    for (const auto& [id, meta] : m_assets)
        if (meta.type == type) result.push_back(&meta);
    return result;
}

std::vector<const AssetMeta*> AssetManifest::GetAll() const {
    std::vector<const AssetMeta*> result;
    result.reserve(m_assets.size());
    for (const auto& [id, meta] : m_assets) result.push_back(&meta);
    return result;
}

// ==============================================================================
// Persistence — minimal JSON
// ==============================================================================
bool AssetManifest::SaveToFile(const std::string& path) const {
    std::string outPath = path.empty() ? m_manifestPath : path;
    std::ofstream f(outPath);
    if (!f) return false;

    f << "{\n  \"version\": 1,\n  \"assets\": [\n";
    bool first = true;
    for (const auto& [id, meta] : m_assets) {
        if (!first) f << ",\n";
        first = false;
        f << "    {\"id\":" << id
          << ",\"type\":" << (int)meta.type
          << ",\"name\":\"" << meta.name << "\""
          << ",\"path\":\"" << meta.path << "\""
          << ",\"hash\":" << meta.contentHash
          << ",\"size\":" << meta.sizeBytes
          << "}";
    }
    f << "\n  ]\n}\n";
    LOG_INFOF("[AssetManifest] Saved %d entries → %s", (int)m_assets.size(), outPath.c_str());
    return true;
}

bool AssetManifest::LoadFromFile(const std::string& path) {
    std::string inPath = path.empty() ? m_manifestPath : path;
    std::ifstream f(inPath);
    if (!f) return false;

    // Very simple line-by-line extraction (avoids full JSON parse dependency)
    std::string line;
    while (std::getline(f, line)) {
        if (line.find("\"id\":") == std::string::npos) continue;
        // Extract fields — regex-free minimal parsing
        auto getField = [&](const std::string& key) -> std::string {
            auto pos = line.find("\"" + key + "\":");
            if (pos == std::string::npos) return "";
            pos += key.size() + 3;
            if (pos >= line.size()) return "";
            char delim = (line[pos] == '"') ? '"' : 0;
            if (delim) ++pos;
            std::string val;
            while (pos < line.size() && line[pos] != (delim ? '"' : ',') && line[pos] != '}')
                val += line[pos++];
            return val;
        };

        AssetID id      = (AssetID)std::stoull(getField("id").empty() ? "0" : getField("id"));
        AssetType type  = (AssetType)std::stoi(getField("type").empty() ? "0" : getField("type"));
        std::string name= getField("name");
        std::string pth = getField("path");
        if (id == 0 || name.empty()) continue;

        AssetMeta meta;
        meta.id   = id;
        meta.type = type;
        meta.name = name;
        meta.path = pth;
        meta.state= LoadState::Unloaded;
        m_assets[id]      = meta;
        m_nameIndex[name] = id;
        m_pathIndex[pth]  = id;
        if (id >= m_nextID) m_nextID = id + 1;
    }
    LOG_INFOF("[AssetManifest] Loaded %d assets from %s", (int)m_assets.size(), inPath.c_str());
    return true;
}

} // namespace BADGE2D
