// ==============================================================================
// AssetLoader.cpp
// ==============================================================================

#include "AssetLoader.h"
#include "../../renderer/textures/Texture2D.h"
#include "../../audio/clips/SoundClip.h"
#include "../../engine/Logging/Logger.h"
#include <algorithm>

namespace BADGE2D {

AssetLoader& AssetLoader::Get() {
    static AssetLoader instance;
    return instance;
}

void AssetLoader::Initialize(int workerThreads) {
    if (m_initialized) return;
    m_shutdown = false;

    for (int i = 0; i < workerThreads; ++i)
        m_workers.emplace_back([this]{ WorkerThread(); });

    m_initialized = true;
    LOG_INFOF("[AssetLoader] Initialized with %d worker threads.", workerThreads);
}

void AssetLoader::Shutdown() {
    if (!m_initialized) return;
    {
        std::lock_guard<std::mutex> lock(m_queueMutex);
        m_shutdown = true;
    }
    m_queueCV.notify_all();
    for (auto& t : m_workers) if (t.joinable()) t.join();
    m_workers.clear();
    m_initialized = false;
    LOG_INFO("[AssetLoader] Shutdown.");
}

// ==============================================================================
// LoadImmediate — synchronous, on calling thread
// ==============================================================================
bool AssetLoader::LoadImmediate(AssetID id, const std::string& path, AssetType type) {
    for (auto& imp : m_importers) {
        if (imp->GetType() == type) {
            bool ok = imp->Load(path, id);
            if (ok) ++m_loadedCount; else ++m_failedCount;
            return ok;
        }
    }
    // Fallback: try all importers
    LOG_WARNF("[AssetLoader] No importer for type %d, trying all.", (int)type);
    for (auto& imp : m_importers) {
        if (imp->Load(path, id)) { ++m_loadedCount; return true; }
    }
    ++m_failedCount;
    LOG_ERRORF("[AssetLoader] Failed to load: %s", path.c_str());
    return false;
}

// ==============================================================================
// LoadAsync
// ==============================================================================
void AssetLoader::LoadAsync(AssetID id, std::function<void(AssetID,bool)> onComplete) {
    if (AssetCache::Get().Has(id)) {
        if (onComplete) onComplete(id, true);
        return;
    }
    const AssetMeta* meta = AssetManifest::Get().FindByID(id);
    if (!meta) { if (onComplete) onComplete(id, false); return; }

    LoadJob job{ id, meta->path, meta->type, std::move(onComplete) };
    {
        std::lock_guard<std::mutex> lock(m_queueMutex);
        m_jobQueue.push(std::move(job));
        ++m_queuedCount;
    }
    m_queueCV.notify_one();
}

void AssetLoader::LoadAsync(const std::string& name, std::function<void(AssetID,bool)> cb) {
    const AssetMeta* meta = AssetManifest::Get().FindByName(name);
    if (!meta) { LOG_ERRORF("[AssetLoader] Async: not found '%s'", name.c_str()); return; }
    LoadAsync(meta->id, std::move(cb));
}

void AssetLoader::Flush() {
    // Wait until queue drains
    while (true) {
        std::unique_lock<std::mutex> lock(m_queueMutex);
        if (m_jobQueue.empty()) break;
        lock.unlock();
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    PumpCallbacks();
}

void AssetLoader::RegisterImporter(std::unique_ptr<IAssetImporter> importer) {
    m_importers.push_back(std::move(importer));
}

int AssetLoader::GetQueuedCount() const {
    std::lock_guard<std::mutex> lock(const_cast<std::mutex&>(m_queueMutex));
    return (int)m_jobQueue.size();
}

float AssetLoader::GetProgress() const {
    int total = m_batchTotal.load();
    if (total == 0) return 1.0f;
    return (float)m_batchDone.load() / (float)total;
}

void AssetLoader::PreloadBatch(const std::vector<std::string>& names,
                                  std::function<void(float)> onProgress,
                                  std::function<void()> onComplete) {
    m_batchTotal.store((int)names.size());
    m_batchDone.store(0);
    m_batchProgress = std::move(onProgress);
    m_batchComplete = std::move(onComplete);

    for (const auto& name : names) {
        LoadAsync(name, [this](AssetID, bool) {
            int done  = ++m_batchDone;
            int total = m_batchTotal.load();
            if (m_batchProgress) m_batchProgress((float)done / total);
            if (done >= total && m_batchComplete) m_batchComplete();
        });
    }
}

// ==============================================================================
// WorkerThread
// ==============================================================================
void AssetLoader::WorkerThread() {
    while (true) {
        LoadJob job;
        {
            std::unique_lock<std::mutex> lock(m_queueMutex);
            m_queueCV.wait(lock, [this]{ return !m_jobQueue.empty() || m_shutdown; });
            if (m_shutdown && m_jobQueue.empty()) return;
            job = std::move(m_jobQueue.front());
            m_jobQueue.pop();
            --m_queuedCount;
        }

        bool ok = LoadImmediate(job.id, job.path, job.type);

        if (job.onComplete) {
            std::lock_guard<std::mutex> lock(m_completedMutex);
            m_completed.push({ job.id, ok, std::move(job.onComplete) });
        }
    }
}

void AssetLoader::PumpCallbacks() {
    std::queue<CompletedJob> done;
    {
        std::lock_guard<std::mutex> lock(m_completedMutex);
        std::swap(done, m_completed);
    }
    while (!done.empty()) {
        auto& j = done.front();
        if (j.cb) j.cb(j.id, j.ok);
        done.pop();
    }
}

// ==============================================================================
// TextureImporter
// ==============================================================================
bool TextureImporter::Load(const std::string& path, AssetID id) {
    auto tex = std::make_shared<Texture2D>();
    if (!tex->LoadFromFile(path)) return false;
    size_t bytes = (size_t)tex->GetWidth() * tex->GetHeight() * 4;
    AssetCache::Get().Store<Texture2D>(id, tex, bytes);
    return true;
}

// ==============================================================================
// SoundImporter
// ==============================================================================
bool SoundImporter::Load(const std::string& path, AssetID id) {
    auto clip = SoundLoader::Load(path, (SoundID)id);
    if (!clip || !clip->IsLoaded()) return false;
    size_t bytes = clip->GetSamples().size() * sizeof(float);
    AssetCache::Get().Store<SoundClip>(id, clip, bytes);
    return true;
}

// ==============================================================================
// MusicImporter — just registers the path; streaming loads on-demand
// ==============================================================================
bool MusicImporter::Load(const std::string& path, AssetID id) {
    // Music is streamed; store the path as a tiny string-only placeholder
    auto pathHolder = std::make_shared<std::string>(path);
    AssetCache::Get().Store<std::string>(id, pathHolder, path.size());
    return true;
}

} // namespace BADGE2D
