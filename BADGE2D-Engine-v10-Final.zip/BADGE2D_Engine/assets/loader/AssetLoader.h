#pragma once
// ==============================================================================
// AssetLoader.h — Synchronous + asynchronous asset loading
// Dispatches to type-specific loaders, stores results in AssetCache.
// ==============================================================================

#include "../AssetTypes.h"
#include "../cache/AssetCache.h"
#include "../manifest/AssetManifest.h"
#include <functional>
#include <future>
#include <queue>
#include <mutex>
#include <thread>
#include <condition_variable>
#include <vector>

namespace BADGE2D {

// ==============================================================================
// LoadJob — One async load task
// ==============================================================================
struct LoadJob {
    AssetID   id;
    std::string path;
    AssetType   type;
    std::function<void(AssetID, bool)> onComplete;  // id, success
};

// ==============================================================================
// IAssetImporter — Extend to add new asset type loaders
// ==============================================================================
struct IAssetImporter {
    virtual ~IAssetImporter() = default;
    virtual AssetType GetType()  const = 0;
    virtual bool      Load(const std::string& path, AssetID id) = 0;
};

// ==============================================================================
// AssetLoader
// ==============================================================================
class AssetLoader {
public:
    static AssetLoader& Get();

    void Initialize(int workerThreads = 2);
    void Shutdown();

    // ---- Synchronous ----
    template<typename T>
    AssetHandle<T> Load(const std::string& nameOrPath) {
        const AssetMeta* meta = AssetManifest::Get().FindByName(nameOrPath);
        if (!meta) meta = AssetManifest::Get().FindByPath(nameOrPath);
        if (!meta) {
            LOG_ERRORF("[AssetLoader] Asset not found: %s", nameOrPath.c_str());
            return {};
        }
        return Load<T>(meta->id);
    }

    template<typename T>
    AssetHandle<T> Load(AssetID id) {
        // Check cache first
        auto cached = AssetCache::Get().Get<T>(id);
        if (cached) return AssetHandle<T>(id, cached);

        // Synchronous load
        const AssetMeta* meta = AssetManifest::Get().FindByID(id);
        if (!meta) return {};

        bool ok = LoadImmediate(id, meta->path, meta->type);
        if (!ok) return {};

        auto ptr = AssetCache::Get().Get<T>(id);
        return ptr ? AssetHandle<T>(id, ptr) : AssetHandle<T>{};
    }

    // ---- Asynchronous ----
    void LoadAsync(AssetID id,
                   std::function<void(AssetID, bool)> onComplete = nullptr);
    void LoadAsync(const std::string& name,
                   std::function<void(AssetID, bool)> onComplete = nullptr);

    // Wait for all queued jobs to finish
    void Flush();

    // ---- Importer registry ----
    void RegisterImporter(std::unique_ptr<IAssetImporter> importer);

    // ---- Progress ----
    int GetQueuedCount()   const;
    int GetLoadedCount()   const { return m_loadedCount; }
    int GetFailedCount()   const { return m_failedCount; }

    float GetProgress()    const;  // 0..1 of a batch load

    // Preload a batch of assets and get a progress callback
    void PreloadBatch(const std::vector<std::string>& names,
                      std::function<void(float /*progress*/)> onProgress,
                      std::function<void()> onComplete);

private:
    AssetLoader() = default;

    bool LoadImmediate(AssetID id, const std::string& path, AssetType type);
    void WorkerThread();
    void PumpCallbacks();

    std::vector<std::unique_ptr<IAssetImporter>> m_importers;
    std::vector<std::thread>                     m_workers;

    std::queue<LoadJob>      m_jobQueue;
    std::mutex               m_queueMutex;
    std::condition_variable  m_queueCV;
    bool                     m_shutdown    = false;

    // Completed callbacks to dispatch on main thread
    struct CompletedJob { AssetID id; bool ok; std::function<void(AssetID,bool)> cb; };
    std::queue<CompletedJob> m_completed;
    std::mutex               m_completedMutex;

    std::atomic<int>  m_loadedCount {0};
    std::atomic<int>  m_failedCount {0};
    std::atomic<int>  m_queuedCount {0};

    // Batch tracking
    std::atomic<int>  m_batchTotal   {0};
    std::atomic<int>  m_batchDone    {0};
    std::function<void(float)> m_batchProgress;
    std::function<void()>      m_batchComplete;

    bool m_initialized = false;
};

// ==============================================================================
// Built-in importers (registered automatically by AssetManager)
// ==============================================================================
struct TextureImporter : IAssetImporter {
    AssetType GetType() const override { return AssetType::Texture; }
    bool Load(const std::string& path, AssetID id) override;
};

struct SoundImporter : IAssetImporter {
    AssetType GetType() const override { return AssetType::Sound; }
    bool Load(const std::string& path, AssetID id) override;
};

struct MusicImporter : IAssetImporter {
    AssetType GetType() const override { return AssetType::Music; }
    bool Load(const std::string& path, AssetID id) override;
};

} // namespace BADGE2D
