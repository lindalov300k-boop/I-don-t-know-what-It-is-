#pragma once
// ==============================================================================
// AssetCache.h — Thread-safe LRU asset cache
// Evicts least-recently-used assets when memory budget is exceeded.
// ==============================================================================

#include "../AssetTypes.h"
#include <unordered_map>
#include <list>
#include <mutex>
#include <memory>
#include <typeindex>
#include <any>

namespace BADGE2D {

// ==============================================================================
// CacheEntry — One slot in the LRU cache
// ==============================================================================
struct CacheEntry {
    AssetID     id;
    std::any    asset;   // std::shared_ptr<T>
    size_t      sizeBytes = 0;
    bool        pinned    = false;
    uint64_t    lastAccess= 0;
};

// ==============================================================================
// AssetCache
// ==============================================================================
class AssetCache {
public:
    static AssetCache& Get();

    void  SetBudgetBytes(size_t bytes) { m_budgetBytes = bytes; }
    size_t GetBudgetBytes()    const   { return m_budgetBytes; }
    size_t GetUsedBytes()      const   { return m_usedBytes;   }
    float  GetUsageRatio()     const   { return m_budgetBytes > 0 ? (float)m_usedBytes / m_budgetBytes : 0; }

    // Store an asset (evicts LRU if over budget)
    template<typename T>
    void Store(AssetID id, std::shared_ptr<T> asset, size_t sizeBytes = 0, bool pin = false) {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (m_entries.count(id)) {
            Touch(id);
            return;
        }
        CacheEntry entry;
        entry.id        = id;
        entry.asset     = asset;
        entry.sizeBytes = sizeBytes;
        entry.pinned    = pin;
        entry.lastAccess= ++m_clock;
        m_entries[id]   = entry;
        m_usedBytes    += sizeBytes;
        m_lruOrder.push_back(id);
        TryEvict();
    }

    // Retrieve a typed asset pointer
    template<typename T>
    std::shared_ptr<T> Get(AssetID id) {
        std::lock_guard<std::mutex> lock(m_mutex);
        auto it = m_entries.find(id);
        if (it == m_entries.end()) return nullptr;
        it->second.lastAccess = ++m_clock;
        Touch(id);
        try {
            return std::any_cast<std::shared_ptr<T>>(it->second.asset);
        } catch (...) {
            return nullptr;
        }
    }

    bool  Has   (AssetID id) const;
    void  Evict (AssetID id);
    void  EvictAll();
    void  Pin   (AssetID id, bool pinned);

    int   GetEntryCount()     const { return (int)m_entries.size(); }
    void  PrintStats()        const;

private:
    AssetCache() = default;

    void TryEvict();
    void Touch(AssetID id);

    std::unordered_map<AssetID, CacheEntry> m_entries;
    std::list<AssetID>                       m_lruOrder;
    mutable std::mutex                       m_mutex;

    size_t   m_budgetBytes = 512 * 1024 * 1024;  // 512MB default
    size_t   m_usedBytes   = 0;
    uint64_t m_clock       = 0;
};

} // namespace BADGE2D
