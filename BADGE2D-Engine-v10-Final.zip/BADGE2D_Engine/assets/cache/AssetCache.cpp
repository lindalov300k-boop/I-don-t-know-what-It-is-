// ==============================================================================
// AssetCache.cpp
// ==============================================================================

#include "AssetCache.h"
#include "../../engine/Logging/Logger.h"
#include <algorithm>

namespace BADGE2D {

AssetCache& AssetCache::Get() {
    static AssetCache instance;
    return instance;
}

bool AssetCache::Has(AssetID id) const {
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_entries.count(id) > 0;
}

void AssetCache::Evict(AssetID id) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_entries.find(id);
    if (it == m_entries.end()) return;
    if (it->second.pinned) return;
    m_usedBytes -= it->second.sizeBytes;
    m_lruOrder.remove(id);
    m_entries.erase(it);
}

void AssetCache::EvictAll() {
    std::lock_guard<std::mutex> lock(m_mutex);
    std::vector<AssetID> toRemove;
    for (auto& [id, e] : m_entries)
        if (!e.pinned) toRemove.push_back(id);
    for (AssetID id : toRemove) {
        m_usedBytes -= m_entries[id].sizeBytes;
        m_lruOrder.remove(id);
        m_entries.erase(id);
    }
}

void AssetCache::Pin(AssetID id, bool pinned) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_entries.find(id);
    if (it != m_entries.end()) it->second.pinned = pinned;
}

void AssetCache::TryEvict() {
    // Called with lock held
    while (m_usedBytes > m_budgetBytes && !m_lruOrder.empty()) {
        AssetID oldest = m_lruOrder.front();
        auto it = m_entries.find(oldest);
        if (it != m_entries.end() && !it->second.pinned) {
            m_usedBytes -= it->second.sizeBytes;
            m_entries.erase(it);
        }
        m_lruOrder.pop_front();
    }
}

void AssetCache::Touch(AssetID id) {
    // Move id to back of LRU list (most recently used)
    m_lruOrder.remove(id);
    m_lruOrder.push_back(id);
}

void AssetCache::PrintStats() const {
    std::lock_guard<std::mutex> lock(m_mutex);
    LOG_INFOF("[AssetCache] Entries=%d Used=%zuMB Budget=%zuMB (%.1f%%)",
              (int)m_entries.size(),
              m_usedBytes   / (1024*1024),
              m_budgetBytes / (1024*1024),
              GetUsageRatio() * 100.0f);
}

} // namespace BADGE2D
