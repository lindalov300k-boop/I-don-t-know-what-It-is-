// ==============================================================================
// AssetManager.cpp
// ==============================================================================

#include "AssetManager.h"
#include "../engine/Logging/Logger.h"

namespace BADGE2D {

AssetManager& AssetManager::Get() {
    static AssetManager instance;
    return instance;
}

bool AssetManager::Initialize() {
    if (m_initialized) return true;

    AssetLoader::Get().RegisterImporter(std::make_unique<TextureImporter>());
    AssetLoader::Get().RegisterImporter(std::make_unique<SoundImporter>());
    AssetLoader::Get().RegisterImporter(std::make_unique<MusicImporter>());
    AssetLoader::Get().Initialize(2);

    // Try loading existing manifest
    AssetManifest::Get().LoadFromFile();

    m_initialized = true;
    LOG_INFO("[AssetManager] Initialized.");
    return true;
}

void AssetManager::Shutdown() {
    if (!m_initialized) return;
    AssetLoader::Get().Flush();
    AssetLoader::Get().Shutdown();
    AssetCache::Get().EvictAll();
    m_initialized = false;
    LOG_INFO("[AssetManager] Shutdown.");
}

void AssetManager::Update(double /*dt*/) {
    // Pump async completion callbacks on main thread
    // (AssetLoader internal — would expose PumpCallbacks here)
}

void AssetManager::SetAssetRoot(const std::string& path) {
    AssetManifest::Get().SetAssetRoot(path);
}

int AssetManager::ScanAssets() {
    int n = AssetManifest::Get().Scan();
    AssetManifest::Get().SaveToFile();
    return n;
}

void AssetManager::PreloadAll(std::function<void(float)> progress,
                               std::function<void()>      complete) {
    auto all = AssetManifest::Get().GetAll();
    std::vector<std::string> names;
    names.reserve(all.size());
    for (auto* m : all) names.push_back(m->name);
    AssetLoader::Get().PreloadBatch(names, std::move(progress), std::move(complete));
}

void AssetManager::PreloadGroup(const std::vector<std::string>& names,
                                  std::function<void(float)> progress,
                                  std::function<void()>      complete) {
    AssetLoader::Get().PreloadBatch(names, std::move(progress), std::move(complete));
}

AssetHandle<Texture2D> AssetManager::GetTexture(const std::string& name) {
    return AssetLoader::Get().Load<Texture2D>(name);
}

AssetHandle<Texture2D> AssetManager::GetTexture(AssetID id) {
    return AssetLoader::Get().Load<Texture2D>(id);
}

AssetHandle<SoundClip> AssetManager::GetSound(const std::string& name) {
    return AssetLoader::Get().Load<SoundClip>(name);
}

AssetHandle<SoundClip> AssetManager::GetSound(AssetID id) {
    return AssetLoader::Get().Load<SoundClip>(id);
}

AssetID   AssetManager::FindID  (const std::string& name) const {
    auto* m = AssetManifest::Get().FindByName(name);
    return m ? m->id : INVALID_ASSET;
}

AssetType AssetManager::FindType(const std::string& name) const {
    auto* m = AssetManifest::Get().FindByName(name);
    return m ? m->type : AssetType::Unknown;
}

bool AssetManager::Exists(const std::string& name) const {
    return AssetManifest::Get().FindByName(name) != nullptr;
}

void AssetManager::Evict(const std::string& name) {
    AssetID id = FindID(name);
    if (id != INVALID_ASSET) AssetCache::Get().Evict(id);
}

void AssetManager::Pin(const std::string& name, bool pin) {
    AssetID id = FindID(name);
    if (id != INVALID_ASSET) AssetCache::Get().Pin(id, pin);
}

void AssetManager::PrintStats() const {
    AssetCache::Get().PrintStats();
    LOG_INFOF("[AssetManager] Assets: %d manifest | %d loaded | %d failed",
              AssetManifest::Get().GetCount(),
              AssetLoader::Get().GetLoadedCount(),
              AssetLoader::Get().GetFailedCount());
}

} // namespace BADGE2D
