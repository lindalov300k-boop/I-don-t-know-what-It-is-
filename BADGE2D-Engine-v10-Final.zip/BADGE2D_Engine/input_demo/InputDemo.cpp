// ==============================================================================
// InputDemo.cpp — Phase 4 Input Demonstration
// Shows: action maps, bindings, axis2D, input buffer, combos, rebinding, gamepad
// ==============================================================================

#include "../BADGE2D.h"
#include "../input/InputManager.h"
#include <cstdio>
#include <string>
#include <vector>

using namespace BADGE2D;

// ==============================================================================
// Minimal console demo (no renderer dependency for portability)
// Outputs input state to stdout each frame.
// When linked with renderer, prints overlay HUD.
// ==============================================================================

// Simple on-screen text line accumulator
struct HUD {
    std::vector<std::string> lines;
    void Clear() { lines.clear(); }
    void Print(const std::string& s) { lines.push_back(s); }
    void PrintF(const char* fmt, ...) {
        char buf[256]; va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof(buf), fmt, ap); va_end(ap);
        lines.push_back(buf);
    }
    void Flush() { for (auto& l : lines) printf("%s\n", l.c_str()); }
};

// ==============================================================================
// Game-specific action names (avoids string literals scattered in game code)
// ==============================================================================
namespace Actions {
    inline constexpr const char* MoveRight  = "MoveRight";
    inline constexpr const char* MoveLeft   = "MoveLeft";
    inline constexpr const char* MoveUp     = "MoveUp";
    inline constexpr const char* MoveDown   = "MoveDown";
    inline constexpr const char* Move       = "Move";       // Axis2D

    inline constexpr const char* Jump       = "Jump";
    inline constexpr const char* Attack     = "Attack";
    inline constexpr const char* Dash       = "Dash";
    inline constexpr const char* Interact   = "Interact";

    inline constexpr const char* LookX      = "LookX";
    inline constexpr const char* LookY      = "LookY";

    inline constexpr const char* Pause      = "Pause";
    inline constexpr const char* DebugMenu  = "DebugMenu";

    // UI map
    inline constexpr const char* UIUp       = "UIUp";
    inline constexpr const char* UIDown     = "UIDown";
    inline constexpr const char* UIConfirm  = "UIConfirm";
    inline constexpr const char* UIBack     = "UIBack";
}

// ==============================================================================
// SetupInputMaps — define all bindings
// ==============================================================================
static void SetupInputMaps(InputManager& input) {
    // ----- Gameplay map (priority 10) -----
    ActionMap& gp = input.CreateMap("Gameplay", 10);

    // Movement — digital actions combined into Axis2D
    gp.AddAction(Actions::MoveRight).bindings = {
        InputBinding::FromKey(KeyCode::D),
        InputBinding::FromKey(KeyCode::Right),
        InputBinding::FromGamepadAxisPos(GamepadAxis::LeftX)
    };
    gp.AddAction(Actions::MoveLeft).bindings = {
        InputBinding::FromKey(KeyCode::A),
        InputBinding::FromKey(KeyCode::Left),
        InputBinding::FromGamepadAxisNeg(GamepadAxis::LeftX)
    };
    gp.AddAction(Actions::MoveUp).bindings = {
        InputBinding::FromKey(KeyCode::W),
        InputBinding::FromKey(KeyCode::Up),
        InputBinding::FromGamepadAxisNeg(GamepadAxis::LeftY)  // Y axis: up = negative
    };
    gp.AddAction(Actions::MoveDown).bindings = {
        InputBinding::FromKey(KeyCode::S),
        InputBinding::FromKey(KeyCode::Down),
        InputBinding::FromGamepadAxisPos(GamepadAxis::LeftY)
    };

    // Axis2D composed from the four movement actions
    auto& moveAxis = gp.AddAxis2D(Actions::Move);
    moveAxis.positiveX = Actions::MoveRight;
    moveAxis.negativeX = Actions::MoveLeft;
    moveAxis.positiveY = Actions::MoveUp;
    moveAxis.negativeY = Actions::MoveDown;
    moveAxis.normalize = true;
    // Also bind gamepad stick directly
    moveAxis.useStick     = false;  // compose from actions above
    moveAxis.stickX       = GamepadAxis::LeftX;
    moveAxis.stickY       = GamepadAxis::LeftY;

    // Jump (press only)
    gp.AddAction(Actions::Jump).bindings = {
        InputBinding::FromKey(KeyCode::Space),
        InputBinding::FromKey(KeyCode::Z),
        InputBinding::FromGamepadButton(GamepadButton::A)
    };
    gp.FindAction(Actions::Jump)->OnPress = [](){
        printf("[INPUT] Jump!\n");
    };

    // Attack
    gp.AddAction(Actions::Attack).bindings = {
        InputBinding::FromMouseButton(MouseButton::Left),
        InputBinding::FromKey(KeyCode::J),
        InputBinding::FromGamepadButton(GamepadButton::X)
    };

    // Dash
    gp.AddAction(Actions::Dash).bindings = {
        InputBinding::FromKey(KeyCode::LeftShift),
        InputBinding::FromKey(KeyCode::RightShift),
        InputBinding::FromGamepadButton(GamepadButton::B)
    };

    // Interact
    gp.AddAction(Actions::Interact).bindings = {
        InputBinding::FromKey(KeyCode::E),
        InputBinding::FromKey(KeyCode::F),
        InputBinding::FromGamepadButton(GamepadButton::Y)
    };

    // Look (mouse)
    gp.AddAction(Actions::LookX, ActionType::Analog).bindings = {
        InputBinding::FromMouseAxisX(-0.002f),
        InputBinding::FromGamepadAxis(GamepadAxis::RightX, 1.0f)
    };
    gp.AddAction(Actions::LookY, ActionType::Analog).bindings = {
        InputBinding::FromMouseAxisY(-0.002f),
        InputBinding::FromGamepadAxis(GamepadAxis::RightY, -1.0f)
    };

    // Pause
    gp.AddAction(Actions::Pause).bindings = {
        InputBinding::FromKey(KeyCode::Escape),
        InputBinding::FromKey(KeyCode::P),
        InputBinding::FromGamepadButton(GamepadButton::Start)
    };

    // Debug — requires Ctrl+F1
    gp.AddAction(Actions::DebugMenu).bindings = {
        InputBinding::FromKey(KeyCode::F1, KeyMod::Control)
    };

    gp.SetEnabled(true);

    // ----- UI map (priority 20 — higher priority, enabled when menu is open) -----
    ActionMap& ui = input.CreateMap("UI", 20);
    ui.AddAction(Actions::UIUp).bindings    = { InputBinding::FromKey(KeyCode::Up),    InputBinding::FromGamepadButton(GamepadButton::DPadUp)   };
    ui.AddAction(Actions::UIDown).bindings  = { InputBinding::FromKey(KeyCode::Down),  InputBinding::FromGamepadButton(GamepadButton::DPadDown) };
    ui.AddAction(Actions::UIConfirm).bindings = { InputBinding::FromKey(KeyCode::Enter), InputBinding::FromGamepadButton(GamepadButton::A)       };
    ui.AddAction(Actions::UIBack).bindings  = { InputBinding::FromKey(KeyCode::Escape), InputBinding::FromGamepadButton(GamepadButton::B)      };
    ui.SetEnabled(false);  // Disabled until menu opens

    // ----- Register combos -----
    auto& buffer = input.GetBuffer();

    // Dash-attack combo: Dash then Attack within 300ms
    ComboDefinition dashAttack;
    dashAttack.name = "DashAttack";
    dashAttack.steps = {
        { Actions::Dash,   InputState::Pressed, 0.5f },
        { Actions::Attack, InputState::Pressed, 0.3f }
    };
    dashAttack.OnTriggered = []() { printf("[COMBO] Dash Attack!\n"); };
    buffer.RegisterCombo(std::move(dashAttack));

    // Double-jump: Jump pressed twice within 350ms
    ComboDefinition doubleJump;
    doubleJump.name = "DoubleJump";
    doubleJump.steps = {
        { Actions::Jump, InputState::Pressed, 0.5f },
        { Actions::Jump, InputState::Pressed, 0.35f }
    };
    doubleJump.OnTriggered = []() { printf("[COMBO] Double Jump!\n"); };
    buffer.RegisterCombo(std::move(doubleJump));
}

// ==============================================================================
// PlayerController — example consumer of the input system
// ==============================================================================
struct PlayerController {
    Vector2 position = {400, 300};
    Vector2 velocity = {};
    bool    grounded = true;
    float   speed    = 200.0f;
    float   jumpForce= 400.0f;
    int     jumpCount= 0;
    bool    menuOpen = false;

    void Update(InputManager& input, float dt) {
        // Movement
        Vector2 move = input.GetAxis2D(Actions::Move);
        velocity.x   = move.x * speed;

        // Jump with coyote time
        auto& buf = input.GetBuffer();
        if (grounded) jumpCount = 0;

        bool wantsJump = buf.ConsumePress(Actions::Jump, 0.15);
        if (wantsJump && jumpCount < 2) {
            velocity.y = -jumpForce;
            ++jumpCount;
            grounded   = false;
        }

        // Gravity
        velocity.y += 980.0f * dt;
        position   += velocity * dt;

        // Ground clamp
        if (position.y >= 500.0f) {
            position.y = 500.0f;
            velocity.y = 0.0f;
            grounded   = true;
        }

        // Pause / menu toggle
        if (input.IsPressed(Actions::Pause)) {
            menuOpen = !menuOpen;
            input.EnableMap("UI", menuOpen);
            printf("[INPUT] Menu %s\n", menuOpen ? "opened" : "closed");
        }

        // Dash
        if (input.IsPressed(Actions::Dash))
            printf("[INPUT] Dash! (pos=%.0f,%.0f)\n", position.x, position.y);
    }

    void Print(HUD& hud) const {
        hud.PrintF("  pos=(%.0f, %.0f) vel=(%.0f, %.0f) grounded=%d jumps=%d",
                   position.x, position.y, velocity.x, velocity.y,
                   grounded ? 1 : 0, jumpCount);
    }
};

// ==============================================================================
// ConsoleDemoApp — thin application loop without renderer
// ==============================================================================
class InputDemoApp {
public:
    void Run() {
        InputManager& input = InputManager::Get();
        input.Initialize();
        SetupInputMaps(input);

        printf("========================================\n");
        printf("  BADGE2D Phase 4 — Input Demo\n");
        printf("  (console mode — run with renderer for HUD)\n");
        printf("========================================\n");
        printf("Bindings:\n");
        printf("  WASD/Arrows   — Move\n");
        printf("  Space/Z       — Jump (double-jump works)\n");
        printf("  LShift        — Dash\n");
        printf("  LMB / J       — Attack\n");
        printf("  E             — Interact\n");
        printf("  P/Esc         — Pause/Menu\n");
        printf("  Ctrl+F1       — Debug Menu\n");
        printf("  Combos: Dash→Attack (300ms), Double Jump\n\n");

        printf("Input maps created. Connect a gamepad for controller input.\n");
        printf("Gamepad count: %d\n\n", input.GetGamepads().GetConnectedCount());

        // List all registered actions
        auto* map = input.GetMap("Gameplay");
        if (map) {
            printf("Registered actions in 'Gameplay':\n");
            for (auto& [name, action] : map->GetActions())
                printf("  %-15s  (%zu bindings)\n",
                       name.c_str(), action.bindings.size());
            printf("\n");
        }

        // Run a few synthetic "frames" to exercise the system
        struct FakeFrame { const char* desc; KeyCode key; float dt; };
        FakeFrame frames[] = {
            {"Press D (move right)",  KeyCode::D,     0.016f},
            {"Hold D (move right)",   KeyCode::D,     0.016f},
            {"Release D",             KeyCode::Unknown, 0.016f},
            {"Press Space (jump)",    KeyCode::Space, 0.016f},
            {"Press Space (2nd jump)",KeyCode::Space, 0.20f },
            {"Press LShift (dash)",   KeyCode::LeftShift, 0.016f},
            {"Press J (attack→combo)",KeyCode::J,     0.05f },
            {"Press Escape (pause)",  KeyCode::Escape,0.016f},
        };

        PlayerController player;
        HUD hud;
        double simTime = 0.0;

        for (auto& frame : frames) {
            // Simulate key event
            if (frame.key != KeyCode::Unknown)
                Keyboard::Get().OnKeyEvent((int)frame.key, 0, 1, 0);

            // Tick
            input.BeginFrame(frame.dt);
            simTime += frame.dt;

            // Game logic
            player.Update(input, frame.dt);

            // Print
            printf("[t=%.3f] %s\n", simTime, frame.desc);
            hud.Clear();
            player.Print(hud);
            hud.Print("  Move=" + std::to_string(input.GetAxis2D(Actions::Move).x)
                       + "," + std::to_string(input.GetAxis2D(Actions::Move).y));
            hud.Print("  Jump=" + std::string(input.IsHeld(Actions::Jump) ? "HELD" :
                                  input.IsPressed(Actions::Jump) ? "PRESS" : "..."));
            hud.Flush();

            input.EndFrame();

            // Release the key
            if (frame.key != KeyCode::Unknown)
                Keyboard::Get().OnKeyEvent((int)frame.key, 0, 0, 0);
        }

        printf("\n[InputDemo] Demo complete.\n");

        // Demonstrate profile save
        input.SaveProfile("Gameplay", "gameplay_bindings.cfg");
        printf("[InputDemo] Bindings saved to gameplay_bindings.cfg\n");

        input.Shutdown();
    }
};

int main() {
    InputDemoApp app;
    app.Run();
    return 0;
}
