// ==============================================================================
// Animator.cpp
// ==============================================================================

#include "Animator.h"

namespace BADGE2D {

// ==============================================================================
// AnimatorSystem helpers
// ==============================================================================
AnimatorComponent& AnimatorSystem::Attach(World& world, EntityID entity) {
    AnimatorComponent comp;
    comp.stateMachine = std::make_unique<AnimStateMachine>();
    return *world.AddComponent(entity, std::move(comp));
}

AnimStateMachine* AnimatorSystem::GetMachine(World& world, EntityID entity) {
    auto* comp = world.TryGetComponent<AnimatorComponent>(entity);
    return comp ? comp->stateMachine.get() : nullptr;
}

// ==============================================================================
// AnimatorBuilder
// ==============================================================================
AnimatorBuilder& AnimatorBuilder::State(const std::string& name,
                                          const std::string& clipName) {
    auto clip = SpriteAnimLibrary::Get().Find(clipName);
    return State(name, std::move(clip));
}

AnimatorBuilder& AnimatorBuilder::State(const std::string& name,
                                          std::shared_ptr<SpriteAnimClip> clip) {
    m_sm.AddState(name, std::move(clip));
    return *this;
}

AnimatorBuilder& AnimatorBuilder::Transition(const std::string& from,
                                               const std::string& to,
                                               float duration) {
    auto& t = m_sm.AddTransition(from, to, duration);
    m_lastTransition = &t;
    return *this;
}

AnimatorBuilder& AnimatorBuilder::AnyState(const std::string& to, float duration) {
    auto& t = m_sm.AddAnyTransition(to, duration);
    m_lastTransition = &t;
    return *this;
}

AnimatorBuilder& AnimatorBuilder::OnParam(const std::string& name,
                                            ConditionOp op, float threshold) {
    if (!m_lastTransition) return *this;
    TransitionCondition cond;
    cond.paramName = name;
    cond.op        = op;
    cond.threshold = threshold;
    m_lastTransition->conditions.push_back(cond);
    return *this;
}

AnimatorBuilder& AnimatorBuilder::OnBool(const std::string& name, bool value) {
    return OnParam(name, value ? ConditionOp::IsTrue : ConditionOp::IsFalse);
}

AnimatorBuilder& AnimatorBuilder::OnTrigger(const std::string& name) {
    return OnParam(name, ConditionOp::IsTriggered);
}

AnimatorBuilder& AnimatorBuilder::ExitTime(float t) {
    if (m_lastTransition) {
        m_lastTransition->hasExitTime = true;
        m_lastTransition->exitTime    = t;
    }
    return *this;
}

AnimatorBuilder& AnimatorBuilder::DefaultState(const std::string& name) {
    m_sm.SetDefaultState(name);
    return *this;
}

} // namespace BADGE2D
