#pragma once
// ==============================================================================
// SpriteAnimation.h — Frame-based sprite sheet animation
// A SpriteAnimClip is a sequence of atlas regions + frame durations.
// Works directly with TextureAtlas from Phase 2.
// ==============================================================================

#include "../AnimationTypes.h"
#include "../../renderer/textures/Texture2D.h"
#include "../../utilities/Math/MathUtils.h"
#include <vector>
#include <string>
#include <memory>
#include <unordered_map>
#include <functional>

namespace BADGE2D {

// ==============================================================================
// SpriteFrame — One animation frame
// ==============================================================================
struct SpriteFrame {
    Rect2D       uvRect;            // Normalized UV region in the texture [0,1]
    float        duration   = 0.1f; // Seconds this frame is shown
    Vector2      pivot      = {0.5f, 0.5f}; // Normalised pivot (0,0=topleft)
    Vector2      offset     = {};           // Sprite offset for this frame
    std::vector<AnimationEvent> events;     // Events fired when this frame starts
};

// ==============================================================================
// SpriteAnimClip — A named sequence of SpriteFrames
// ==============================================================================
class SpriteAnimClip {
public:
    explicit SpriteAnimClip(AnimClipID id, std::string name)
        : m_id(id), m_name(std::move(name)) {}

    // ---- Build ----
    void AddFrame(const SpriteFrame& frame);
    void AddFrames(std::shared_ptr<Texture2D> texture,
                   int firstCol, int firstRow,
                   int count, int columns,
                   int frameW, int frameH,
                   float frameDuration = 0.1f);

    // Add event at time t seconds (auto-sorted)
    void AddEvent(float t, const std::string& eventName, float param = 0.0f);

    // ---- Query ----
    AnimClipID         GetID()        const { return m_id;      }
    const std::string& GetName()      const { return m_name;    }
    WrapMode           GetWrapMode()  const { return m_wrapMode;}
    int                GetFrameCount()const { return (int)m_frames.size(); }
    float              GetDuration()  const { return m_totalDuration; }
    float              GetFPS()       const { return m_frames.empty() ? 0 : (float)m_frames.size() / m_totalDuration; }

    const SpriteFrame& GetFrame(int index) const;

    // Get the frame index for a given time (0..duration)
    int   GetFrameAtTime(float t) const;

    // All events between t0 and t1 (exclusive, handles looping)
    std::vector<const AnimationEvent*> GetEventsBetween(float t0, float t1) const;

    // Texture (all frames must share the same atlas)
    void SetTexture(std::shared_ptr<Texture2D> tex) { m_texture = std::move(tex); }
    Texture2D* GetTexture() const { return m_texture.get(); }

    WrapMode  m_wrapMode    = WrapMode::Loop;
    float     m_playbackSpeed = 1.0f;
    bool      m_flipX         = false;
    bool      m_flipY         = false;

private:
    AnimClipID   m_id;
    std::string  m_name;
    float        m_totalDuration = 0.0f;

    std::vector<SpriteFrame>     m_frames;
    std::vector<AnimationEvent>  m_events;  // Sorted by time
    std::shared_ptr<Texture2D>   m_texture;
};

// ==============================================================================
// SpriteAnimPlayer — Plays one SpriteAnimClip; manages time, frame, events
// ==============================================================================
class SpriteAnimPlayer {
public:
    // ---- Playback ----
    void  Play   (std::shared_ptr<SpriteAnimClip> clip, bool restart = false);
    void  Stop   ();
    void  Pause  ();
    void  Resume ();
    void  Update (float dt);

    void  SetSpeed (float s)  { m_speed = s; }
    float GetSpeed ()  const  { return m_speed; }

    // ---- State query ----
    bool               IsPlaying  ()  const { return m_playing; }
    bool               IsPaused   ()  const { return m_paused;  }
    bool               IsFinished ()  const { return m_finished;}
    float              GetTime    ()  const { return m_time;     }
    int                GetFrame   ()  const { return m_frame;    }
    float              GetProgress()  const;
    SpriteAnimClip*    GetClip    ()  const { return m_clip.get(); }
    const SpriteFrame* GetCurrentFrame() const;

    // ---- Callbacks ----
    std::function<void(const AnimationEvent&)> OnEvent;
    std::function<void()>                       OnFinished;
    std::function<void(int /*newFrame*/)>       OnFrameChanged;

private:
    std::shared_ptr<SpriteAnimClip> m_clip;
    float  m_time     = 0.0f;
    int    m_frame    = 0;
    float  m_speed    = 1.0f;
    bool   m_playing  = false;
    bool   m_paused   = false;
    bool   m_finished = false;
    bool   m_reverse  = false;  // For PingPong
};

// ==============================================================================
// SpriteAnimLibrary — Named clip registry
// ==============================================================================
class SpriteAnimLibrary {
public:
    static SpriteAnimLibrary& Get();

    AnimClipID  Register  (std::shared_ptr<SpriteAnimClip> clip);
    AnimClipID  GetID     (const std::string& name) const;
    std::shared_ptr<SpriteAnimClip> Find(const std::string& name) const;
    std::shared_ptr<SpriteAnimClip> Find(AnimClipID id)           const;
    void        Unregister(AnimClipID id);

    // Build a clip from a strip (row) in a uniform spritesheet
    std::shared_ptr<SpriteAnimClip> CreateStrip(
        const std::string& name,
        std::shared_ptr<Texture2D> texture,
        int frameCount, int columns, int rows,
        int row, float frameDuration,
        WrapMode wrap = WrapMode::Loop);

private:
    SpriteAnimLibrary() = default;
    AnimClipID m_nextID = 1;
    std::unordered_map<AnimClipID,   std::shared_ptr<SpriteAnimClip>> m_clips;
    std::unordered_map<std::string,  AnimClipID>                      m_names;
};

} // namespace BADGE2D
