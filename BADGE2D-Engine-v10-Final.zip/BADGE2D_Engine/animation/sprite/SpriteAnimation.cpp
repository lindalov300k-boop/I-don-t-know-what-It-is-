// ==============================================================================
// SpriteAnimation.cpp
// ==============================================================================

#include "SpriteAnimation.h"
#include "../../engine/Logging/Logger.h"
#include <algorithm>
#include <cmath>

namespace BADGE2D {

// ==============================================================================
// SpriteAnimClip
// ==============================================================================
void SpriteAnimClip::AddFrame(const SpriteFrame& frame) {
    m_frames.push_back(frame);
    m_totalDuration += frame.duration;
}

void SpriteAnimClip::AddFrames(std::shared_ptr<Texture2D> texture,
                                  int firstCol, int firstRow,
                                  int count, int columns,
                                  int frameW, int frameH,
                                  float frameDuration) {
    if (!texture) return;
    if (!m_texture) m_texture = texture;

    float texW = (float)texture->GetWidth();
    float texH = (float)texture->GetHeight();

    int col = firstCol, row = firstRow;
    for (int i = 0; i < count; ++i) {
        SpriteFrame f;
        f.duration = frameDuration;
        f.uvRect.x = (col * frameW) / texW;
        f.uvRect.y = (row * frameH) / texH;
        f.uvRect.w = frameW / texW;
        f.uvRect.h = frameH / texH;
        AddFrame(f);

        ++col;
        if (col >= columns) { col = 0; ++row; }
    }
}

void SpriteAnimClip::AddEvent(float t, const std::string& name, float param) {
    AnimationEvent ev;
    ev.time       = t;
    ev.name       = name;
    ev.floatParam = param;
    // Insert sorted by time
    auto it = std::lower_bound(m_events.begin(), m_events.end(), ev,
        [](const AnimationEvent& a, const AnimationEvent& b){ return a.time < b.time; });
    m_events.insert(it, ev);
}

const SpriteFrame& SpriteAnimClip::GetFrame(int index) const {
    static SpriteFrame empty;
    if (index < 0 || index >= (int)m_frames.size()) return empty;
    return m_frames[index];
}

int SpriteAnimClip::GetFrameAtTime(float t) const {
    if (m_frames.empty()) return 0;
    float cursor = 0.0f;
    for (int i = 0; i < (int)m_frames.size(); ++i) {
        cursor += m_frames[i].duration;
        if (t < cursor) return i;
    }
    return (int)m_frames.size() - 1;
}

std::vector<const AnimationEvent*>
SpriteAnimClip::GetEventsBetween(float t0, float t1) const {
    std::vector<const AnimationEvent*> result;
    for (const auto& ev : m_events) {
        if (ev.time > t0 && ev.time <= t1)
            result.push_back(&ev);
    }
    return result;
}

// ==============================================================================
// SpriteAnimPlayer
// ==============================================================================
void SpriteAnimPlayer::Play(std::shared_ptr<SpriteAnimClip> clip, bool restart) {
    if (!clip) return;
    bool sameClip = (m_clip == clip);
    if (sameClip && !restart && m_playing) return;

    m_clip    = std::move(clip);
    m_time    = 0.0f;
    m_frame   = 0;
    m_playing = true;
    m_paused  = false;
    m_finished= false;
    m_reverse = false;
}

void SpriteAnimPlayer::Stop() {
    m_playing  = false;
    m_paused   = false;
    m_finished = false;
    m_time     = 0.0f;
    m_frame    = 0;
}

void SpriteAnimPlayer::Pause()  { if (m_playing) m_paused = true; }
void SpriteAnimPlayer::Resume() { if (m_paused)  m_paused = false; }

float SpriteAnimPlayer::GetProgress() const {
    if (!m_clip || m_clip->GetDuration() <= 0) return 0.0f;
    return m_time / m_clip->GetDuration();
}

const SpriteFrame* SpriteAnimPlayer::GetCurrentFrame() const {
    if (!m_clip) return nullptr;
    return &m_clip->GetFrame(m_frame);
}

void SpriteAnimPlayer::Update(float dt) {
    if (!m_clip || !m_playing || m_paused || m_finished) return;

    float prevTime = m_time;
    float advance  = dt * m_speed * m_clip->m_playbackSpeed;
    if (m_reverse) advance = -advance;
    m_time += advance;

    float dur = m_clip->GetDuration();
    if (dur <= 0.0f) return;

    // Fire events between prevTime and m_time
    auto events = m_clip->GetEventsBetween(prevTime, m_time);
    for (auto* ev : events)
        if (OnEvent) OnEvent(*ev);

    // Handle wrap
    switch (m_clip->m_wrapMode) {
    case WrapMode::Once:
        if (m_time >= dur) {
            m_time    = dur;
            m_finished = true;
            m_playing  = false;
            if (OnFinished) OnFinished();
        }
        break;
    case WrapMode::Loop:
        while (m_time >= dur) m_time -= dur;
        while (m_time < 0.0f) m_time += dur;
        break;
    case WrapMode::PingPong:
        if (m_time >= dur) { m_time = dur - (m_time - dur); m_reverse = true; }
        if (m_time < 0.0f) { m_time = -m_time; m_reverse = false; }
        break;
    case WrapMode::ClampForever:
        m_time = std::clamp(m_time, 0.0f, dur);
        break;
    }

    int prevFrame = m_frame;
    m_frame = m_clip->GetFrameAtTime(m_time);
    if (m_frame != prevFrame && OnFrameChanged) OnFrameChanged(m_frame);
}

// ==============================================================================
// SpriteAnimLibrary
// ==============================================================================
SpriteAnimLibrary& SpriteAnimLibrary::Get() {
    static SpriteAnimLibrary instance;
    return instance;
}

AnimClipID SpriteAnimLibrary::Register(std::shared_ptr<SpriteAnimClip> clip) {
    if (!clip) return INVALID_CLIP;
    AnimClipID id = clip->GetID();
    m_clips[id]   = clip;
    m_names[clip->GetName()] = id;
    return id;
}

AnimClipID SpriteAnimLibrary::GetID(const std::string& name) const {
    auto it = m_names.find(name);
    return (it != m_names.end()) ? it->second : INVALID_CLIP;
}

std::shared_ptr<SpriteAnimClip> SpriteAnimLibrary::Find(const std::string& name) const {
    return Find(GetID(name));
}

std::shared_ptr<SpriteAnimClip> SpriteAnimLibrary::Find(AnimClipID id) const {
    auto it = m_clips.find(id);
    return (it != m_clips.end()) ? it->second : nullptr;
}

void SpriteAnimLibrary::Unregister(AnimClipID id) {
    auto it = m_clips.find(id);
    if (it == m_clips.end()) return;
    for (auto& [name, nid] : m_names) if (nid == id) { m_names.erase(name); break; }
    m_clips.erase(it);
}

std::shared_ptr<SpriteAnimClip> SpriteAnimLibrary::CreateStrip(
    const std::string& name, std::shared_ptr<Texture2D> texture,
    int frameCount, int columns, int /*rows*/,
    int row, float frameDuration, WrapMode wrap) {

    AnimClipID id = m_nextID++;
    auto clip = std::make_shared<SpriteAnimClip>(id, name);
    clip->m_wrapMode = wrap;

    if (texture) {
        int frameW = texture->GetWidth()  / columns;
        int frameH = texture->GetHeight() / ((frameCount + columns - 1) / columns);
        clip->AddFrames(texture, 0, row, frameCount, columns, frameW, frameH, frameDuration);
    }
    Register(clip);
    return clip;
}

} // namespace BADGE2D
