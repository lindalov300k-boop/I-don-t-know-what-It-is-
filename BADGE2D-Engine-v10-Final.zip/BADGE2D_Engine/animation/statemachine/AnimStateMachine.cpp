// ==============================================================================
// AnimStateMachine.cpp
// ==============================================================================

#include "AnimStateMachine.h"
#include "../../engine/Logging/Logger.h"
#include <algorithm>
#include <cmath>

namespace BADGE2D {

// ==============================================================================
// TransitionCondition
// ==============================================================================
bool TransitionCondition::Evaluate(const AnimParam& param) const {
    switch (op) {
    case ConditionOp::IsTrue:      return param.bVal;
    case ConditionOp::IsFalse:     return !param.bVal;
    case ConditionOp::IsTriggered: return param.triggered;
    case ConditionOp::Equals:
        if (param.type == ParamType::Int)   return param.iVal == (int)threshold;
        if (param.type == ParamType::Float) return std::abs(param.fVal - threshold) < 0.001f;
        return false;
    case ConditionOp::NotEquals:
        if (param.type == ParamType::Int)   return param.iVal != (int)threshold;
        if (param.type == ParamType::Float) return std::abs(param.fVal - threshold) >= 0.001f;
        return false;
    case ConditionOp::Greater:    return param.fVal > threshold || param.iVal > (int)threshold;
    case ConditionOp::Less:       return param.fVal < threshold || param.iVal < (int)threshold;
    case ConditionOp::GreaterEq:  return param.fVal >= threshold || param.iVal >= (int)threshold;
    case ConditionOp::LessEq:     return param.fVal <= threshold || param.iVal <= (int)threshold;
    }
    return false;
}

// ==============================================================================
// AnimTransition::CanFire
// ==============================================================================
bool AnimTransition::CanFire(const std::unordered_map<ParamName, AnimParam>& params,
                               float clipProgress) const {
    if (hasExitTime && clipProgress < exitTime) return false;

    for (const auto& cond : conditions) {
        auto it = params.find(cond.paramName);
        if (it == params.end()) return false;
        if (!cond.Evaluate(it->second)) return false;
    }
    return true;
}

// ==============================================================================
// AnimStateMachine — Build
// ==============================================================================
AnimState& AnimStateMachine::AddState(const std::string& name,
                                        std::shared_ptr<SpriteAnimClip> clip) {
    AnimStateID id = NextStateID();
    AnimState& s   = m_states[id];
    s = AnimState(id, name);
    if (clip) s.SetClip(std::move(clip));
    m_stateNames[name] = id;

    if (m_defaultStateID == INVALID_STATE) m_defaultStateID = id;
    return s;
}

void AnimStateMachine::RemoveState(AnimStateID id) {
    auto it = m_states.find(id);
    if (it == m_states.end()) return;
    m_stateNames.erase(it->second.GetName());
    m_states.erase(it);
    m_transitions.erase(std::remove_if(m_transitions.begin(), m_transitions.end(),
        [id](const AnimTransition& t){ return t.fromState == id || t.toState == id; }),
        m_transitions.end());
}

AnimTransition& AnimStateMachine::AddTransition(const std::string& from,
                                                   const std::string& to,
                                                   float duration) {
    AnimTransition t;
    t.fromState = GetStateID(from);
    t.toState   = GetStateID(to);
    t.duration  = duration;
    m_transitions.push_back(t);
    return m_transitions.back();
}

AnimTransition& AnimStateMachine::AddAnyTransition(const std::string& to, float duration) {
    AnimTransition t;
    t.fromState = INVALID_STATE;  // INVALID = any state
    t.toState   = GetStateID(to);
    t.duration  = duration;
    m_transitions.push_back(t);
    return m_transitions.back();
}

// ==============================================================================
// Parameters
// ==============================================================================
void AnimStateMachine::SetFloat  (const ParamName& name, float v) {
    auto& p = m_params[name]; p.type = ParamType::Float; p.fVal = v;
}
void AnimStateMachine::SetInt    (const ParamName& name, int v)   {
    auto& p = m_params[name]; p.type = ParamType::Int;   p.iVal = v;
}
void AnimStateMachine::SetBool   (const ParamName& name, bool v)  {
    auto& p = m_params[name]; p.type = ParamType::Bool;  p.bVal = v;
}
void AnimStateMachine::SetTrigger(const ParamName& name)          {
    auto& p = m_params[name]; p.type = ParamType::Trigger; p.triggered = true;
}

float AnimStateMachine::GetFloat (const ParamName& n) const {
    auto it = m_params.find(n); return it != m_params.end() ? it->second.fVal : 0.0f;
}
int   AnimStateMachine::GetInt   (const ParamName& n) const {
    auto it = m_params.find(n); return it != m_params.end() ? it->second.iVal : 0;
}
bool  AnimStateMachine::GetBool  (const ParamName& n) const {
    auto it = m_params.find(n); return it != m_params.end() && it->second.bVal;
}

// ==============================================================================
// State control
// ==============================================================================
void AnimStateMachine::SetDefaultState(const std::string& name) {
    m_defaultStateID = GetStateID(name);
}

void AnimStateMachine::ForceState(const std::string& name) {
    ForceState(GetStateID(name));
}

void AnimStateMachine::ForceState(AnimStateID id) {
    AnimState* prev = FindState(m_currentStateID);
    if (prev && prev->OnExit) prev->OnExit();

    AnimStateID prevID  = m_currentStateID;
    m_currentStateID    = id;
    m_transitioning     = false;

    AnimState* next = FindState(id);
    if (next) {
        m_currentPlayer.Play(next->GetClip(), true);
        if (next->OnEnter) next->OnEnter();
    }
    if (OnStateChanged && prevID != id) OnStateChanged(prevID, id);
}

// ==============================================================================
// Update
// ==============================================================================
void AnimStateMachine::Update(float dt) {
    // Boot into default state
    if (m_currentStateID == INVALID_STATE && m_defaultStateID != INVALID_STATE) {
        ForceState(m_defaultStateID);
    }

    // Update current player
    m_currentPlayer.OnEvent = [this](const AnimationEvent& ev) {
        if (OnAnimEvent) OnAnimEvent(ev);
    };
    m_currentPlayer.Update(dt * GetCurrentState()->GetSpeed());

    // Update transition
    if (m_transitioning) {
        UpdateTransition(dt);
    }

    if (!m_transitioning) {
        float progress = m_currentPlayer.GetProgress();

        // Check transitions: Any-State first, then from current
        for (auto& t : m_transitions) {
            bool fromMatches = (t.fromState == INVALID_STATE ||
                                t.fromState == m_currentStateID);
            if (!fromMatches) continue;
            if (t.toState == m_currentStateID) continue;

            if (t.CanFire(m_params, progress)) {
                BeginTransition(t.toState, t.duration);
                ConsumeTriggers();
                break;
            }
        }
    }
}

void AnimStateMachine::BeginTransition(AnimStateID toID, float duration) {
    if (toID == INVALID_STATE) return;

    m_prevPlayer      = m_currentPlayer;   // snapshot outgoing state
    m_transitioning   = true;
    m_transitionDuration = std::max(duration, AnimConst::TRANSITION_EPS);
    m_transitionTime  = 0.0f;

    AnimStateID prevID = m_currentStateID;
    m_currentStateID   = toID;

    AnimState* prev = FindState(prevID);
    AnimState* next = FindState(toID);

    if (prev && prev->OnExit)  prev->OnExit();
    if (next) {
        m_currentPlayer.Play(next->GetClip(), true);
        if (next->OnEnter) next->OnEnter();
    }
    if (OnStateChanged) OnStateChanged(prevID, toID);
}

void AnimStateMachine::UpdateTransition(float dt) {
    m_transitionTime += dt;
    if (m_transitionTime >= m_transitionDuration) {
        m_transitioning = false;
        m_prevPlayer.Stop();
    } else {
        m_prevPlayer.Update(dt);
    }
}

void AnimStateMachine::ConsumeTriggers() {
    for (auto& [name, param] : m_params)
        if (param.type == ParamType::Trigger) param.triggered = false;
}

// ==============================================================================
// Queries
// ==============================================================================
AnimState* AnimStateMachine::FindState(AnimStateID id) {
    if (id == INVALID_STATE) return nullptr;
    auto it = m_states.find(id);
    return (it != m_states.end()) ? &it->second : nullptr;
}

AnimState* AnimStateMachine::FindState(const std::string& name) {
    return FindState(GetStateID(name));
}

AnimStateID AnimStateMachine::GetStateID(const std::string& name) const {
    auto it = m_stateNames.find(name);
    return (it != m_stateNames.end()) ? it->second : INVALID_STATE;
}

AnimState* AnimStateMachine::GetCurrentState() {
    return FindState(m_currentStateID);
}

const AnimState* AnimStateMachine::GetCurrentState() const {
    auto it = m_states.find(m_currentStateID);
    return (it != m_states.end()) ? &it->second : nullptr;
}

const std::string& AnimStateMachine::GetCurrentStateName() const {
    static std::string empty;
    auto* s = GetCurrentState();
    return s ? s->GetName() : empty;
}

bool AnimStateMachine::IsInState(const std::string& name) const {
    return m_currentStateID == GetStateID(name);
}

float AnimStateMachine::GetTransitionProgress() const {
    if (!m_transitioning || m_transitionDuration <= 0) return 1.0f;
    return m_transitionTime / m_transitionDuration;
}

const SpriteFrame* AnimStateMachine::GetCurrentFrame() const {
    return m_currentPlayer.GetCurrentFrame();
}

Texture2D* AnimStateMachine::GetCurrentTexture() const {
    auto* state = GetCurrentState();
    if (!state) return nullptr;
    auto clip = state->GetClip();
    return clip ? clip->GetTexture() : nullptr;
}

float AnimStateMachine::GetCurrentFlipX() const {
    auto* state = GetCurrentState();
    if (!state || !state->GetClip()) return false;
    return state->GetClip()->m_flipX;
}

float AnimStateMachine::GetCurrentFlipY() const {
    auto* state = GetCurrentState();
    if (!state || !state->GetClip()) return false;
    return state->GetClip()->m_flipY;
}

} // namespace BADGE2D
