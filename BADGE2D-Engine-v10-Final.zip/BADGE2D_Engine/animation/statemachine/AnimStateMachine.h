#pragma once
// ==============================================================================
// AnimStateMachine.h — Animation state machine (ASM)
// States hold clips. Transitions have conditions. Parameters drive conditions.
// ==============================================================================

#include "../AnimationTypes.h"
#include "../sprite/SpriteAnimation.h"
#include <string>
#include <vector>
#include <unordered_map>
#include <variant>
#include <functional>
#include <memory>

namespace BADGE2D {

// ==============================================================================
// AnimParam — Named parameter (float, int, bool, trigger)
// ==============================================================================
using ParamName = std::string;

enum class ParamType { Float, Int, Bool, Trigger };

struct AnimParam {
    ParamType type  = ParamType::Bool;
    float     fVal  = 0.0f;
    int       iVal  = 0;
    bool      bVal  = false;
    bool      triggered = false;  // Triggers consume themselves
};

// ==============================================================================
// TransitionCondition — One condition for a transition to fire
// ==============================================================================
enum class ConditionOp {
    Equals, NotEquals, Greater, Less, GreaterEq, LessEq, IsTrue, IsFalse, IsTriggered
};

struct TransitionCondition {
    ParamName   paramName;
    ConditionOp op        = ConditionOp::IsTrue;
    float       threshold = 0.0f;

    bool Evaluate(const AnimParam& param) const;
};

// ==============================================================================
// AnimTransition — Edge between states
// ==============================================================================
struct AnimTransition {
    AnimStateID   fromState      = INVALID_STATE;  // INVALID = Any State
    AnimStateID   toState        = INVALID_STATE;
    float         duration       = AnimConst::DEFAULT_TRANSITION_TIME;
    bool          hasExitTime    = false;
    float         exitTime       = 1.0f;  // Normalized (0..1) clip progress
    bool          canInterrupt   = false;

    std::vector<TransitionCondition> conditions;

    // Transition fires if ALL conditions are met (AND logic)
    bool CanFire(const std::unordered_map<ParamName, AnimParam>& params,
                 float clipProgress) const;
};

// ==============================================================================
// AnimState — One node in the state machine
// ==============================================================================
class AnimState {
public:
    AnimState() = default;
    explicit AnimState(AnimStateID id, std::string name)
        : m_id(id), m_name(std::move(name)) {}

    AnimStateID        GetID()     const { return m_id; }
    const std::string& GetName()   const { return m_name; }

    void SetClip(std::shared_ptr<SpriteAnimClip> clip) { m_clip = std::move(clip); }
    std::shared_ptr<SpriteAnimClip> GetClip() const { return m_clip; }

    float GetSpeed()   const { return m_speed; }
    void  SetSpeed(float s)  { m_speed = s; }

    // Blend tree support (for future Phase 7 upgrade)
    bool  IsBlendTree() const { return m_isBlendTree; }

    // Callbacks
    std::function<void()> OnEnter;
    std::function<void()> OnExit;
    std::function<void(float /*dt*/)> OnUpdate;

private:
    AnimStateID  m_id    = INVALID_STATE;
    std::string  m_name;
    float        m_speed = 1.0f;
    bool         m_isBlendTree = false;
    std::shared_ptr<SpriteAnimClip> m_clip;
};

// ==============================================================================
// AnimStateMachine — Drives an AnimState graph
// ==============================================================================
class AnimStateMachine {
public:
    // ---- Build ----
    AnimState&  AddState (const std::string& name, std::shared_ptr<SpriteAnimClip> clip = nullptr);
    void        RemoveState(AnimStateID id);

    AnimTransition& AddTransition(const std::string& fromState,
                                   const std::string& toState,
                                   float duration = AnimConst::DEFAULT_TRANSITION_TIME);
    AnimTransition& AddAnyTransition(const std::string& toState,
                                      float duration = AnimConst::DEFAULT_TRANSITION_TIME);

    // ---- Parameters ----
    void SetFloat  (const ParamName& name, float v);
    void SetInt    (const ParamName& name, int v);
    void SetBool   (const ParamName& name, bool v);
    void SetTrigger(const ParamName& name);

    float GetFloat (const ParamName& name) const;
    int   GetInt   (const ParamName& name) const;
    bool  GetBool  (const ParamName& name) const;

    // ---- Playback ----
    void  SetDefaultState(const std::string& name);
    void  ForceState     (const std::string& name);
    void  ForceState     (AnimStateID id);
    void  Update         (float dt);

    // ---- Queries ----
    AnimState*       GetCurrentState();
    const AnimState* GetCurrentState()     const;
    AnimStateID      GetCurrentStateID()   const { return m_currentStateID; }
    const std::string& GetCurrentStateName() const;
    bool             IsInState(const std::string& name) const;
    bool             IsTransitioning()     const { return m_transitioning; }
    float            GetTransitionProgress()const;

    // ---- Animation output ----
    // Returns the current SpriteFrame to render (blended during transitions)
    const SpriteFrame* GetCurrentFrame() const;
    Texture2D*         GetCurrentTexture() const;
    float              GetCurrentFlipX() const;
    float              GetCurrentFlipY() const;

    // ---- Callbacks ----
    std::function<void(AnimStateID /*from*/, AnimStateID /*to*/)> OnStateChanged;
    std::function<void(const AnimationEvent&)>                     OnAnimEvent;

    // ---- Layer ----
    void   SetLayerWeight(int layer, float w) { m_layerWeight = w; }
    float  GetLayerWeight(int layer) const    { return m_layerWeight; }

private:
    AnimStateID NextStateID() { return ++m_nextStateID; }

    AnimState* FindState (AnimStateID id);
    AnimState* FindState (const std::string& name);
    AnimStateID GetStateID(const std::string& name) const;

    void BeginTransition(AnimStateID toID, float duration);
    void UpdateTransition(float dt);
    void ConsumeTriggers();

    std::unordered_map<AnimStateID,  AnimState>   m_states;
    std::unordered_map<std::string,  AnimStateID> m_stateNames;
    std::vector<AnimTransition>                    m_transitions;
    std::unordered_map<ParamName, AnimParam>       m_params;

    AnimStateID  m_currentStateID = INVALID_STATE;
    AnimStateID  m_defaultStateID = INVALID_STATE;
    AnimStateID  m_nextStateID    = 0;

    SpriteAnimPlayer  m_currentPlayer;
    SpriteAnimPlayer  m_prevPlayer;     // For blend-during-transition

    bool   m_transitioning      = false;
    float  m_transitionTime     = 0.0f;
    float  m_transitionDuration = 0.0f;
    float  m_layerWeight        = 1.0f;
};

} // namespace BADGE2D
