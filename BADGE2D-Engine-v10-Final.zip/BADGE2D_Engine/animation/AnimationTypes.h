#pragma once
// ==============================================================================
// AnimationTypes.h — Animation system shared types
// ==============================================================================

#include <cstdint>
#include <string>

namespace BADGE2D {

using AnimClipID    = uint32_t;
using AnimStateID   = uint32_t;
using AnimLayerID   = uint32_t;

constexpr AnimClipID  INVALID_CLIP  = 0;
constexpr AnimStateID INVALID_STATE = 0;

// ==============================================================================
// WrapMode — How a clip behaves at the end
// ==============================================================================
enum class WrapMode {
    Once,        // Play once and stop
    Loop,        // Loop back to start
    PingPong,    // Forward then backward
    ClampForever // Hold the last frame
};

// ==============================================================================
// EasingType — Interpolation for keyframes
// ==============================================================================
enum class EasingType {
    Linear,
    Step,
    EaseIn,
    EaseOut,
    EaseInOut,
    Bezier      // Custom control points
};

// ==============================================================================
// AnimationEvent — Fired at specific clip timestamps
// ==============================================================================
struct AnimationEvent {
    float       time       = 0.0f;   // Seconds into clip
    std::string name;                // Event name (e.g. "footstep", "attack_hit")
    float       floatParam = 0.0f;
    std::string stringParam;
};

// ==============================================================================
// BlendMode — How layers blend together
// ==============================================================================
enum class LayerBlendMode {
    Override,    // This layer completely replaces layers below
    Additive     // This layer's delta is added on top
};

// ==============================================================================
// AnimationConstants
// ==============================================================================
namespace AnimConst {
    constexpr int   MAX_LAYERS      = 8;
    constexpr int   MAX_BLEND_STATES= 8;
    constexpr float TRANSITION_EPS  = 0.001f;
    constexpr float DEFAULT_TRANSITION_TIME = 0.15f;
}

} // namespace BADGE2D
