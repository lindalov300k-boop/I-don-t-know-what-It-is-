#pragma once
// ==============================================================================
// EventSystem.h — Type-safe event bus (publish/subscribe)
// ==============================================================================

#include <functional>
#include <unordered_map>
#include <vector>
#include <typeindex>
#include <memory>
#include <mutex>
#include <cstdint>

namespace BADGE2D {

// ==============================================================================
// EventID — Unique ID for each listener subscription
// ==============================================================================
using EventID = uint64_t;

// ==============================================================================
// IEventHandler — Base for type-erased event handlers
// ==============================================================================
struct IEventHandler {
    virtual ~IEventHandler() = default;
    virtual void Invoke(const void* event) = 0;
    EventID id = 0;
};

// ==============================================================================
// EventHandler<T> — Typed event handler
// ==============================================================================
template<typename EventT>
struct EventHandler : IEventHandler {
    std::function<void(const EventT&)> fn;

    explicit EventHandler(std::function<void(const EventT&)> f)
        : fn(std::move(f)) {}

    void Invoke(const void* event) override {
        fn(*static_cast<const EventT*>(event));
    }
};

// ==============================================================================
// EventBus — Global event bus singleton
// ==============================================================================
class EventBus {
public:
    static EventBus& Get();

    // Subscribe: returns an EventID to unsubscribe later
    template<typename EventT>
    EventID Subscribe(std::function<void(const EventT&)> callback) {
        std::lock_guard<std::mutex> lock(m_mutex);
        auto handler = std::make_unique<EventHandler<EventT>>(std::move(callback));
        handler->id  = m_nextId++;
        EventID id   = handler->id;
        m_handlers[std::type_index(typeid(EventT))].push_back(std::move(handler));
        return id;
    }

    // Unsubscribe by ID
    template<typename EventT>
    void Unsubscribe(EventID id) {
        std::lock_guard<std::mutex> lock(m_mutex);
        auto& vec = m_handlers[std::type_index(typeid(EventT))];
        vec.erase(
            std::remove_if(vec.begin(), vec.end(),
                [id](const std::unique_ptr<IEventHandler>& h) { return h->id == id; }),
            vec.end()
        );
    }

    // Dispatch: immediately calls all subscribers
    template<typename EventT>
    void Dispatch(const EventT& event) {
        std::vector<IEventHandler*> handlers;
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            auto it = m_handlers.find(std::type_index(typeid(EventT)));
            if (it == m_handlers.end()) return;
            for (auto& h : it->second) handlers.push_back(h.get());
        }
        for (auto* h : handlers) h->Invoke(&event);
    }

    // Queue an event for deferred dispatch (call FlushQueue each frame)
    template<typename EventT>
    void Enqueue(const EventT& event) {
        std::lock_guard<std::mutex> lock(m_queueMutex);
        m_queue.push_back(std::make_unique<DeferredEvent<EventT>>(event));
    }

    void FlushQueue();

    void Clear();

private:
    EventBus() = default;

    // Deferred event base
    struct IDeferredEvent {
        virtual ~IDeferredEvent() = default;
        virtual void Dispatch(EventBus& bus) = 0;
    };

    template<typename EventT>
    struct DeferredEvent : IDeferredEvent {
        EventT data;
        explicit DeferredEvent(const EventT& e) : data(e) {}
        void Dispatch(EventBus& bus) override { bus.Dispatch(data); }
    };

    std::unordered_map<std::type_index, std::vector<std::unique_ptr<IEventHandler>>> m_handlers;
    std::vector<std::unique_ptr<IDeferredEvent>> m_queue;
    std::mutex m_mutex;
    std::mutex m_queueMutex;
    EventID    m_nextId = 1;
};

// ==============================================================================
// Common engine events
// ==============================================================================

// Window events
struct WindowResizeEvent  { int width; int height; };
struct WindowCloseEvent   {};
struct WindowFocusEvent   { bool focused; };

// Application lifecycle
struct AppStartEvent      {};
struct AppQuitEvent       {};

// Frame events
struct PreUpdateEvent     { double dt; };
struct PostUpdateEvent    { double dt; };
struct PreRenderEvent     {};
struct PostRenderEvent    {};

// ==============================================================================
// Convenience macro
// ==============================================================================
#define BADGE2D_SUBSCRIBE(EventType, handler) \
    BADGE2D::EventBus::Get().Subscribe<EventType>(handler)

#define BADGE2D_DISPATCH(event) \
    BADGE2D::EventBus::Get().Dispatch(event)

} // namespace BADGE2D
