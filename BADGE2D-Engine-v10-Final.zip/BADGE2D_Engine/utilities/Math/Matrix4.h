#pragma once
// ==============================================================================
// Matrix4.h — Column-major 4x4 float matrix for OpenGL transforms
// ==============================================================================

#include "Vector2.h"
#include <cmath>
#include <cstring>
#include <string>

namespace BADGE2D {

// ==============================================================================
// Matrix4 — Column-major 4x4 float matrix (OpenGL convention)
// ==============================================================================
struct Matrix4 {
    float m[16] = {};  // Column-major: m[col*4 + row]

    Matrix4() { SetIdentity(); }

    static Matrix4 Identity() {
        Matrix4 r;
        r.SetIdentity();
        return r;
    }

    void SetIdentity() {
        memset(m, 0, sizeof(m));
        m[0] = m[5] = m[10] = m[15] = 1.0f;
    }

    // Element access: row, col (0-indexed)
    float& At(int row, int col)       { return m[col*4 + row]; }
    float  At(int row, int col) const { return m[col*4 + row]; }

    const float* Data() const { return m; }

    // ==============================================================================
    // Multiply
    // ==============================================================================
    Matrix4 operator*(const Matrix4& o) const {
        Matrix4 r;
        for (int col = 0; col < 4; ++col)
            for (int row = 0; row < 4; ++row) {
                r.At(row,col) = 0;
                for (int k = 0; k < 4; ++k)
                    r.At(row,col) += At(row,k) * o.At(k,col);
            }
        return r;
    }

    Matrix4& operator*=(const Matrix4& o) { *this = *this * o; return *this; }

    // ==============================================================================
    // Factory methods
    // ==============================================================================
    static Matrix4 Ortho(float left, float right, float bottom, float top,
                          float near = -1.0f, float far = 1.0f) {
        Matrix4 r;
        r.SetIdentity();
        r.At(0,0) =  2.0f / (right - left);
        r.At(1,1) =  2.0f / (top   - bottom);
        r.At(2,2) = -2.0f / (far   - near);
        r.At(0,3) = -(right + left)   / (right - left);
        r.At(1,3) = -(top   + bottom) / (top   - bottom);
        r.At(2,3) = -(far   + near)   / (far   - near);
        return r;
    }

    static Matrix4 Translation(float x, float y, float z = 0.0f) {
        Matrix4 r;
        r.At(0,3) = x;
        r.At(1,3) = y;
        r.At(2,3) = z;
        return r;
    }

    static Matrix4 Translation(const Vector2& v) {
        return Translation(v.x, v.y, 0.0f);
    }

    static Matrix4 Scale(float x, float y, float z = 1.0f) {
        Matrix4 r;
        r.At(0,0) = x;
        r.At(1,1) = y;
        r.At(2,2) = z;
        return r;
    }

    static Matrix4 Scale(const Vector2& s) {
        return Scale(s.x, s.y, 1.0f);
    }

    static Matrix4 RotationZ(float radians) {
        Matrix4 r;
        float c = std::cos(radians);
        float s = std::sin(radians);
        r.At(0,0) =  c;  r.At(0,1) = -s;
        r.At(1,0) =  s;  r.At(1,1) =  c;
        return r;
    }

    // TRS: Translation * RotationZ * Scale
    static Matrix4 TRS(const Vector2& pos, float rotRad, const Vector2& scale) {
        return Translation(pos) * RotationZ(rotRad) * Scale(scale);
    }

    // Transpose
    Matrix4 Transposed() const {
        Matrix4 r;
        for (int i = 0; i < 4; ++i)
            for (int j = 0; j < 4; ++j)
                r.At(i,j) = At(j,i);
        return r;
    }

    // Inverse (for 2D ortho cameras this is fast-path)
    Matrix4 Inversed() const;

    std::string ToString() const {
        char buf[256];
        std::snprintf(buf, sizeof(buf),
            "[%.2f %.2f %.2f %.2f]\n"
            "[%.2f %.2f %.2f %.2f]\n"
            "[%.2f %.2f %.2f %.2f]\n"
            "[%.2f %.2f %.2f %.2f]",
            m[0],m[4],m[8], m[12],
            m[1],m[5],m[9], m[13],
            m[2],m[6],m[10],m[14],
            m[3],m[7],m[11],m[15]);
        return buf;
    }
};

// Vector2 transformed by Matrix4 (w=1)
inline Vector2 operator*(const Matrix4& m, const Vector2& v) {
    float x = m.At(0,0)*v.x + m.At(0,1)*v.y + m.At(0,3);
    float y = m.At(1,0)*v.x + m.At(1,1)*v.y + m.At(1,3);
    return {x, y};
}

} // namespace BADGE2D
