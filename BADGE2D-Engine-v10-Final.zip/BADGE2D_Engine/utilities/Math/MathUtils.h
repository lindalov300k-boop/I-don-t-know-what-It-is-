#pragma once
// ==============================================================================
// MathUtils.h — Rect2D, Transform2D, and general math helpers
// ==============================================================================

#include "Vector2.h"
#include <cmath>
#include <algorithm>

namespace BADGE2D {

// ==============================================================================
// Math constants
// ==============================================================================
namespace Math {
    constexpr float PI       = 3.14159265358979323846f;
    constexpr float TAU      = PI * 2.0f;
    constexpr float DEG2RAD  = PI / 180.0f;
    constexpr float RAD2DEG  = 180.0f / PI;
    constexpr float EPSILON  = 1e-6f;
    constexpr float SQRT2    = 1.41421356237f;
    constexpr float INFINITY_F = std::numeric_limits<float>::infinity();

    inline float ToRadians(float deg) { return deg * DEG2RAD; }
    inline float ToDegrees(float rad) { return rad * RAD2DEG; }

    inline float Lerp  (float a, float b, float t) { return a + (b-a)*t; }
    inline float InvLerp(float a, float b, float v){ return (v-a)/(b-a); }
    inline float Remap (float v, float a0, float b0, float a1, float b1) {
        return Lerp(a1, b1, InvLerp(a0, b0, v));
    }

    inline float Clamp (float v, float lo, float hi) { return std::clamp(v, lo, hi); }
    inline float Clamp01(float v) { return Clamp(v, 0.0f, 1.0f); }
    inline float SmoothStep(float e0, float e1, float x) {
        float t = Clamp01((x - e0) / (e1 - e0));
        return t * t * (3.0f - 2.0f * t);
    }

    inline bool NearlyEqual(float a, float b, float tol = EPSILON) {
        return std::abs(a - b) < tol;
    }

    inline float WrapAngle(float rad) {
        while (rad >  PI) rad -= TAU;
        while (rad < -PI) rad += TAU;
        return rad;
    }

    inline int NextPowerOfTwo(int v) {
        v--;
        v |= v >> 1; v |= v >> 2; v |= v >> 4; v |= v >> 8; v |= v >> 16;
        return v + 1;
    }
}

// ==============================================================================
// Rect2D — Axis-aligned rectangle
// ==============================================================================
struct Rect2D {
    float x = 0.0f;
    float y = 0.0f;
    float w = 0.0f;
    float h = 0.0f;

    constexpr Rect2D() = default;
    constexpr Rect2D(float x, float y, float w, float h) : x(x), y(y), w(w), h(h) {}
    Rect2D(const Vector2& pos, const Vector2& size)
        : x(pos.x), y(pos.y), w(size.x), h(size.y) {}

    Vector2 Position() const { return {x, y}; }
    Vector2 Size()     const { return {w, h}; }
    Vector2 Center()   const { return {x + w*0.5f, y + h*0.5f}; }
    Vector2 Min()      const { return {x, y}; }
    Vector2 Max()      const { return {x+w, y+h}; }

    float Left()   const { return x; }
    float Right()  const { return x + w; }
    float Top()    const { return y; }
    float Bottom() const { return y + h; }
    float Area()   const { return w * h; }

    bool Contains(const Vector2& p) const {
        return p.x >= x && p.x <= x+w && p.y >= y && p.y <= y+h;
    }

    bool Overlaps(const Rect2D& o) const {
        return x < o.x+o.w && x+w > o.x && y < o.y+o.h && y+h > o.y;
    }

    Rect2D Intersection(const Rect2D& o) const {
        float ix = std::max(x, o.x);
        float iy = std::max(y, o.y);
        float iw = std::min(x+w, o.x+o.w) - ix;
        float ih = std::min(y+h, o.y+o.h) - iy;
        if (iw <= 0 || ih <= 0) return {};
        return {ix, iy, iw, ih};
    }

    Rect2D Union(const Rect2D& o) const {
        float ux = std::min(x, o.x);
        float uy = std::min(y, o.y);
        float ur = std::max(x+w, o.x+o.w);
        float ub = std::max(y+h, o.y+o.h);
        return {ux, uy, ur-ux, ub-uy};
    }

    Rect2D Expanded(float amount) const {
        return {x-amount, y-amount, w+amount*2, h+amount*2};
    }

    Rect2D Moved(const Vector2& delta) const { return {x+delta.x, y+delta.y, w, h}; }

    bool IsEmpty() const { return w <= 0 || h <= 0; }

    static Rect2D FromMinMax(const Vector2& mn, const Vector2& mx) {
        return {mn.x, mn.y, mx.x - mn.x, mx.y - mn.y};
    }

    std::string ToString() const {
        char buf[128];
        std::snprintf(buf, sizeof(buf),
            "Rect(%.2f, %.2f, %.2f x %.2f)", x, y, w, h);
        return buf;
    }
};

// ==============================================================================
// Transform2D — Position, rotation, scale
// ==============================================================================
struct Transform2D {
    Vector2 position = Vector2::Zero();
    float   rotation = 0.0f;           // Radians
    Vector2 scale    = Vector2::One();

    Transform2D() = default;
    Transform2D(const Vector2& pos, float rot = 0.0f, const Vector2& scl = Vector2::One())
        : position(pos), rotation(rot), scale(scl) {}

    // Transform a local-space point to world-space
    Vector2 TransformPoint(const Vector2& local) const {
        Vector2 scaled  = {local.x * scale.x, local.y * scale.y};
        Vector2 rotated = scaled.Rotated(rotation);
        return rotated + position;
    }

    // Transform a world-space point to local-space (inverse)
    Vector2 InverseTransformPoint(const Vector2& world) const {
        Vector2 delta   = world - position;
        Vector2 unrot   = delta.Rotated(-rotation);
        return {scale.x != 0 ? unrot.x / scale.x : 0.0f,
                scale.y != 0 ? unrot.y / scale.y : 0.0f};
    }

    Transform2D Combined(const Transform2D& child) const {
        Transform2D result;
        result.position = TransformPoint(child.position);
        result.rotation = rotation + child.rotation;
        result.scale    = {scale.x * child.scale.x, scale.y * child.scale.y};
        return result;
    }

    static Transform2D Lerp(const Transform2D& a, const Transform2D& b, float t) {
        return {
            Vector2::Lerp(a.position, b.position, t),
            Math::Lerp(a.rotation, b.rotation, t),
            Vector2::Lerp(a.scale, b.scale, t)
        };
    }

    bool IsIdentity() const {
        return position.IsZero() && Math::NearlyEqual(rotation, 0.0f)
               && Math::NearlyEqual(scale.x, 1.0f) && Math::NearlyEqual(scale.y, 1.0f);
    }
};

// ==============================================================================
// Color — RGBA float color
// ==============================================================================
struct Color {
    float r = 1.0f;
    float g = 1.0f;
    float b = 1.0f;
    float a = 1.0f;

    constexpr Color() = default;
    constexpr Color(float r, float g, float b, float a = 1.0f) : r(r), g(g), b(b), a(a) {}

    static constexpr Color White()       { return {1,1,1,1}; }
    static constexpr Color Black()       { return {0,0,0,1}; }
    static constexpr Color Red()         { return {1,0,0,1}; }
    static constexpr Color Green()       { return {0,1,0,1}; }
    static constexpr Color Blue()        { return {0,0,1,1}; }
    static constexpr Color Yellow()      { return {1,1,0,1}; }
    static constexpr Color Cyan()        { return {0,1,1,1}; }
    static constexpr Color Magenta()     { return {1,0,1,1}; }
    static constexpr Color Transparent() { return {0,0,0,0}; }

    static Color Lerp(const Color& a, const Color& b, float t) {
        return {Math::Lerp(a.r, b.r, t), Math::Lerp(a.g, b.g, t),
                Math::Lerp(a.b, b.b, t), Math::Lerp(a.a, b.a, t)};
    }

    // Convert to 0xRRGGBBAA
    uint32_t ToRGBA8() const {
        auto clamp8 = [](float v) -> uint8_t {
            return static_cast<uint8_t>(std::clamp(v, 0.0f, 1.0f) * 255.0f);
        };
        return ((uint32_t)clamp8(r) << 24) | ((uint32_t)clamp8(g) << 16)
             | ((uint32_t)clamp8(b) << 8)  |  (uint32_t)clamp8(a);
    }

    static Color FromRGBA8(uint32_t rgba) {
        return {
            ((rgba >> 24) & 0xFF) / 255.0f,
            ((rgba >> 16) & 0xFF) / 255.0f,
            ((rgba >>  8) & 0xFF) / 255.0f,
            ( rgba        & 0xFF) / 255.0f
        };
    }

    static Color FromHex(const char* hex);  // "#RRGGBB" or "#RRGGBBAA"

    bool operator==(const Color& o) const { return r==o.r && g==o.g && b==o.b && a==o.a; }
    bool operator!=(const Color& o) const { return !(*this==o); }
};

} // namespace BADGE2D
