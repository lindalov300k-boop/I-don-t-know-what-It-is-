#pragma once
// ==============================================================================
// Vector2.h — 2D vector with full math operations
// ==============================================================================

#include <cmath>
#include <string>
#include <cassert>
#include <algorithm>

namespace BADGE2D {

// ==============================================================================
// Vector2 — 2-component float vector
// ==============================================================================
struct Vector2 {
    float x = 0.0f;
    float y = 0.0f;

    // Construction
    constexpr Vector2() = default;
    constexpr Vector2(float x, float y) : x(x), y(y) {}
    explicit  constexpr Vector2(float scalar) : x(scalar), y(scalar) {}

    // Common constants
    static constexpr Vector2 Zero()    { return {0.0f,  0.0f}; }
    static constexpr Vector2 One()     { return {1.0f,  1.0f}; }
    static constexpr Vector2 Up()      { return {0.0f,  1.0f}; }
    static constexpr Vector2 Down()    { return {0.0f, -1.0f}; }
    static constexpr Vector2 Left()    { return {-1.0f, 0.0f}; }
    static constexpr Vector2 Right()   { return {1.0f,  0.0f}; }

    // Arithmetic operators
    Vector2 operator+(const Vector2& o) const { return {x + o.x, y + o.y}; }
    Vector2 operator-(const Vector2& o) const { return {x - o.x, y - o.y}; }
    Vector2 operator*(const Vector2& o) const { return {x * o.x, y * o.y}; }
    Vector2 operator/(const Vector2& o) const { return {x / o.x, y / o.y}; }
    Vector2 operator*(float s)          const { return {x * s,   y * s};   }
    Vector2 operator/(float s)          const { float r=1.f/s; return {x*r, y*r}; }
    Vector2 operator-()                 const { return {-x, -y}; }

    Vector2& operator+=(const Vector2& o) { x+=o.x; y+=o.y; return *this; }
    Vector2& operator-=(const Vector2& o) { x-=o.x; y-=o.y; return *this; }
    Vector2& operator*=(const Vector2& o) { x*=o.x; y*=o.y; return *this; }
    Vector2& operator*=(float s)          { x*=s;   y*=s;   return *this; }
    Vector2& operator/=(float s)          { float r=1.f/s; x*=r; y*=r; return *this; }

    // Comparison
    bool operator==(const Vector2& o) const { return x==o.x && y==o.y; }
    bool operator!=(const Vector2& o) const { return !(*this==o); }

    // Element access
    float  operator[](int i) const { return (&x)[i]; }
    float& operator[](int i)       { return (&x)[i]; }

    // Length
    float LengthSq()   const { return x*x + y*y; }
    float Length()     const { return std::sqrt(LengthSq()); }
    float InvLength()  const { return 1.0f / Length(); }

    // Normalise
    Vector2 Normalized() const {
        float len = Length();
        if (len < 1e-8f) return Zero();
        return {x / len, y / len};
    }
    void Normalize() {
        float len = Length();
        if (len > 1e-8f) { x /= len; y /= len; }
    }
    bool IsNormalized(float tol = 1e-4f) const {
        return std::abs(LengthSq() - 1.0f) < tol;
    }

    // Dot / Cross
    static float Dot  (const Vector2& a, const Vector2& b) { return a.x*b.x + a.y*b.y; }
    static float Cross(const Vector2& a, const Vector2& b) { return a.x*b.y - a.y*b.x; }
    float Dot  (const Vector2& o) const { return Dot(*this, o); }
    float Cross(const Vector2& o) const { return Cross(*this, o); }

    // Distance
    static float Distance  (const Vector2& a, const Vector2& b) { return (b-a).Length(); }
    static float DistanceSq(const Vector2& a, const Vector2& b) { return (b-a).LengthSq(); }

    // Interpolation
    static Vector2 Lerp (const Vector2& a, const Vector2& b, float t) {
        return a + (b - a) * t;
    }
    static Vector2 Slerp(const Vector2& a, const Vector2& b, float t);

    // Reflection and projection
    Vector2 Reflect(const Vector2& normal) const {
        return *this - normal * (2.0f * Dot(normal));
    }
    Vector2 Project(const Vector2& onto) const {
        float d = onto.LengthSq();
        if (d < 1e-8f) return Zero();
        return onto * (Dot(onto) / d);
    }

    // Perpendicular (90 degree rotation)
    Vector2 Perpendicular() const { return {-y, x}; }

    // Angle
    float Angle() const { return std::atan2(y, x); }
    static float AngleBetween(const Vector2& a, const Vector2& b) {
        float d = a.Dot(b);
        float l = a.Length() * b.Length();
        if (l < 1e-8f) return 0.0f;
        return std::acos(std::clamp(d / l, -1.0f, 1.0f));
    }

    // Rotate by radians
    Vector2 Rotated(float radians) const {
        float c = std::cos(radians);
        float s = std::sin(radians);
        return {x*c - y*s, x*s + y*c};
    }

    // Component-wise min/max/clamp/abs
    static Vector2 Min  (const Vector2& a, const Vector2& b) { return {std::min(a.x,b.x), std::min(a.y,b.y)}; }
    static Vector2 Max  (const Vector2& a, const Vector2& b) { return {std::max(a.x,b.x), std::max(a.y,b.y)}; }
    static Vector2 Clamp(const Vector2& v, const Vector2& lo, const Vector2& hi) {
        return {std::clamp(v.x,lo.x,hi.x), std::clamp(v.y,lo.y,hi.y)};
    }
    Vector2 Abs() const { return {std::abs(x), std::abs(y)}; }
    Vector2 Floor()const { return {std::floor(x), std::floor(y)}; }
    Vector2 Ceil() const { return {std::ceil(x),  std::ceil(y)};  }
    Vector2 Round()const { return {std::round(x), std::round(y)}; }

    // Direction from angle
    static Vector2 FromAngle(float radians) {
        return {std::cos(radians), std::sin(radians)};
    }

    std::string ToString() const {
        char buf[64];
        std::snprintf(buf, sizeof(buf), "(%.3f, %.3f)", x, y);
        return buf;
    }

    bool IsZero(float tol = 1e-8f) const { return LengthSq() < tol * tol; }
    bool IsNaN()  const { return std::isnan(x) || std::isnan(y); }
    bool IsFinite()const{ return std::isfinite(x) && std::isfinite(y); }
};

// Scalar * Vector2
inline Vector2 operator*(float s, const Vector2& v) { return v * s; }

// ==============================================================================
// Vector2i — Integer 2D vector (grid coords, tile indices, etc.)
// ==============================================================================
struct Vector2i {
    int x = 0;
    int y = 0;

    constexpr Vector2i() = default;
    constexpr Vector2i(int x, int y) : x(x), y(y) {}

    Vector2i operator+(const Vector2i& o) const { return {x+o.x, y+o.y}; }
    Vector2i operator-(const Vector2i& o) const { return {x-o.x, y-o.y}; }
    Vector2i operator*(int s)             const { return {x*s, y*s}; }
    Vector2i operator-()                  const { return {-x, -y}; }
    bool     operator==(const Vector2i& o)const { return x==o.x && y==o.y; }
    bool     operator!=(const Vector2i& o)const { return !(*this==o); }

    explicit operator Vector2() const { return {(float)x, (float)y}; }

    static constexpr Vector2i Zero()  { return {0, 0}; }
    static constexpr Vector2i One()   { return {1, 1}; }

    std::string ToString() const {
        char buf[64];
        std::snprintf(buf, sizeof(buf), "(%d, %d)", x, y);
        return buf;
    }
};

} // namespace BADGE2D

// std::hash specializations for use in unordered containers
namespace std {
    template<> struct hash<BADGE2D::Vector2i> {
        size_t operator()(const BADGE2D::Vector2i& v) const noexcept {
            return hash<int>()(v.x) ^ (hash<int>()(v.y) << 16);
        }
    };
}
