// ==============================================================================
// EventSystem.cpp
// ==============================================================================

#include "EventSystem.h"
#include <vector>
#include <memory>

namespace BADGE2D {

EventBus& EventBus::Get() {
    static EventBus instance;
    return instance;
}

void EventBus::FlushQueue() {
    std::vector<std::unique_ptr<IDeferredEvent>> toProcess;
    {
        std::lock_guard<std::mutex> lock(m_queueMutex);
        toProcess.swap(m_queue);
    }
    for (auto& ev : toProcess)
        ev->Dispatch(*this);
}

void EventBus::Clear() {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_handlers.clear();
}

} // namespace BADGE2D
