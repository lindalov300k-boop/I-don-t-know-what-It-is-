#pragma once
// ==============================================================================
// BADGE2D.h — Master include header (Phase 1 + Phase 2: Renderer)
// ==============================================================================

// ---- Phase 1: Core ----
#include "engine/Engine/Engine.h"
#include "engine/Engine/EngineConfig.h"
#include "engine/Logging/Logger.h"
#include "engine/Memory/Allocator.h"
#include "engine/Memory/PoolAllocator.h"
#include "engine/Memory/MemoryTracker.h"
#include "engine/Time/Clock.h"
#include "engine/Profiling/Profiler.h"
#include "engine/ModuleSystem/ModuleInterface.h"
#include "engine/ModuleSystem/ModuleManager.h"
#include "platform/filesystem/FileSystem.h"
#include "platform/threading/JobSystem.h"
#include "ecs/entity/Entity.h"
#include "ecs/component/ComponentManager.h"
#include "ecs/component/Components.h"
#include "ecs/system/World.h"
#include "utilities/Math/Vector2.h"
#include "utilities/Math/Matrix4.h"
#include "utilities/Math/MathUtils.h"
#include "utilities/EventSystem.h"

// ---- Phase 2: Renderer ----
#include "renderer/core/RenderDevice.h"
#include "renderer/core/Renderer2D.h"
#include "renderer/shaders/Shader.h"
#include "renderer/textures/Texture2D.h"
#include "renderer/camera/Camera2D.h"
#include "renderer/sprites/SpriteBatch.h"
#include "renderer/tilemaps/TileRenderer.h"
#include "renderer/particles/ParticleSystem.h"
#include "renderer/postprocessing/Framebuffer.h"

// ---- Runtime ----
#include "runtime/Application.h"

// ---- Phase 3: Physics ----
#include "physics/PhysicsMath.h"
#include "physics/colliders/Shape.h"
#include "physics/bodies/PhysicsBody.h"
#include "physics/collision/Broadphase.h"
#include "physics/collision/NarrowPhase.h"
#include "physics/collision/CollisionResolver.h"
#include "physics/constraints/Joints.h"
#include "physics/world/PhysicsWorld.h"
#include "physics/world/PhysicsSystem.h"
#include "physics/debug/PhysicsDebugDraw.h"

// ---- Phase 4: Input ----
#include "input/InputCodes.h"
#include "input/keyboard/Keyboard.h"
#include "input/mouse/Mouse.h"
#include "input/gamepad/Gamepad.h"
#include "input/actions/InputAction.h"
#include "input/actions/ActionMap.h"
#include "input/buffering/InputBuffer.h"
#include "input/InputManager.h"

// ---- Phase 5: Audio ----
#include "audio/AudioTypes.h"
#include "audio/device/AudioDevice.h"
#include "audio/clips/SoundClip.h"
#include "audio/mixer/AudioChannel.h"
#include "audio/mixer/AudioMixer.h"
#include "audio/streaming/StreamingSource.h"
#include "audio/AudioManager.h"

// ---- Phase 7: Scene ----
#include "scene/SceneTypes.h"
#include "scene/manager/Scene.h"
#include "scene/manager/SceneManager.h"
#include "scene/serialization/SceneSerializer.h"
#include "scene/prefab/Prefab.h"

// ---- Phase 8: Assets ----
#include "assets/AssetTypes.h"
#include "assets/cache/AssetCache.h"
#include "assets/manifest/AssetManifest.h"
#include "assets/loader/AssetLoader.h"
#include "assets/AssetManager.h"

// ---- Phase 9: UI ----
#include "ui/UITypes.h"
#include "ui/canvas/UIElement.h"
#include "ui/renderer/UIRenderer.h"
#include "ui/widgets/UIWidgets.h"
#include "ui/UICanvas.h"

// ---- Phase 10: Editor ----
#include "editor/commands/EditorCommand.h"
#include "editor/panels/EditorPanels.h"
#include "editor/gizmos/TransformGizmo.h"
#include "editor/core/EditorCore.h"

// ---- Phase 6: Animation ----
#include "animation/AnimationTypes.h"
#include "animation/sprite/SpriteAnimation.h"
#include "animation/statemachine/AnimStateMachine.h"
#include "animation/Animator.h"
