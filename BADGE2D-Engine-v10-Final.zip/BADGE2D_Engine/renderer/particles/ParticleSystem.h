#pragma once
// ==============================================================================
// ParticleSystem.h — CPU-simulated particle emitter with GPU rendering
// ==============================================================================

#include "../../thirdparty/glad/include/glad/glad_stub.h"
#include "../../utilities/Math/MathUtils.h"
#include "../textures/Texture2D.h"
#include "../sprites/SpriteBatch.h"
#include <vector>
#include <memory>
#include <random>

namespace BADGE2D {

// ==============================================================================
// Particle — Single particle state
// ==============================================================================
struct Particle {
    Vector2  position     = {};
    Vector2  velocity     = {};
    float    rotation     = 0.0f;
    float    angularVel   = 0.0f;
    Color    color        = Color::White();
    Color    colorEnd     = Color::Transparent();
    float    size         = 16.0f;
    float    sizeEnd      = 0.0f;
    float    life         = 1.0f;       // Seconds remaining
    float    lifeTotal    = 1.0f;       // Total lifespan
    bool     alive        = false;

    float Progress() const { return 1.0f - (life / lifeTotal); }
};

// ==============================================================================
// EmitterConfig — Controls how particles are spawned and simulated
// ==============================================================================
struct EmitterConfig {
    // Spawn
    float    emissionRate    = 50.0f;   // Particles per second
    int      burst           = 0;       // Instant burst count (0 = continuous)
    float    duration        = -1.0f;   // -1 = infinite
    bool     looping         = true;

    // Initial state ranges
    float    lifetimeMin     = 0.5f;
    float    lifetimeMax     = 1.5f;
    float    speedMin        = 50.0f;
    float    speedMax        = 150.0f;
    float    angleMin        = 0.0f;    // Radians (emission cone)
    float    angleMax        = Math::TAU;
    float    sizeStartMin    = 8.0f;
    float    sizeStartMax    = 24.0f;
    float    sizeEndMin      = 0.0f;
    float    sizeEndMax      = 0.0f;
    Color    colorStart      = Color::White();
    Color    colorEnd        = Color::Transparent();
    float    rotationMin     = 0.0f;
    float    rotationMax     = 0.0f;
    float    angularVelMin   = -1.0f;
    float    angularVelMax   = 1.0f;

    // Physics
    Vector2  gravity         = {0.0f, -200.0f};
    float    drag            = 0.0f;         // Linear damping per second

    // Rendering
    std::shared_ptr<Texture2D> texture;
    int      maxParticles    = 500;
    int      sortOrder       = 0;
};

// ==============================================================================
// ParticleEmitter — Manages one pool of particles
// ==============================================================================
class ParticleEmitter {
public:
    ParticleEmitter() = default;
    explicit ParticleEmitter(const EmitterConfig& config);

    void   SetConfig(const EmitterConfig& config);
    void   SetPosition(const Vector2& pos) { m_position = pos; }
    Vector2 GetPosition() const            { return m_position; }

    void   Play();
    void   Stop();
    void   Burst(int count = -1);   // -1 = use config burst count

    void   Update(float dt);
    void   Render(SpriteBatch& batch);

    bool   IsAlive()   const;   // Any active particles
    bool   IsPlaying() const    { return m_playing; }
    int    GetActiveCount() const;

    void   Reset();

private:
    void   Emit(int count);
    Particle& GetDeadParticle();

    EmitterConfig        m_config;
    std::vector<Particle> m_particles;
    Vector2              m_position  = {};
    float                m_emitAccum = 0.0f;
    float                m_elapsed   = 0.0f;
    bool                 m_playing   = false;

    std::mt19937         m_rng;
    float RandF(float lo, float hi) {
        std::uniform_real_distribution<float> d(lo, hi);
        return d(m_rng);
    }
};

// ==============================================================================
// ParticleSystem — Manages multiple named emitters
// ==============================================================================
class ParticleSystem {
public:
    static ParticleSystem& Get();

    ParticleEmitter* CreateEmitter(const std::string& name, const EmitterConfig& cfg);
    ParticleEmitter* GetEmitter   (const std::string& name);
    void             DestroyEmitter(const std::string& name);

    void UpdateAll(float dt);
    void RenderAll(SpriteBatch& batch);

    void StopAll();
    void Clear();

private:
    ParticleSystem() = default;
    std::unordered_map<std::string, std::unique_ptr<ParticleEmitter>> m_emitters;
};

} // namespace BADGE2D
