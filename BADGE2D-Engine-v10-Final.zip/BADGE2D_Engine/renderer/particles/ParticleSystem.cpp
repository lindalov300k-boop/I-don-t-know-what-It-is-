// ==============================================================================
// ParticleSystem.cpp
// ==============================================================================

#include "ParticleSystem.h"
#include "../../engine/Logging/Logger.h"
#include <algorithm>
#include <chrono>

namespace BADGE2D {

// ==============================================================================
// ParticleEmitter
// ==============================================================================
ParticleEmitter::ParticleEmitter(const EmitterConfig& config) {
    SetConfig(config);
    m_rng.seed(static_cast<uint32_t>(
        std::chrono::steady_clock::now().time_since_epoch().count()));
}

void ParticleEmitter::SetConfig(const EmitterConfig& config) {
    m_config = config;
    m_particles.resize(static_cast<size_t>(std::max(1, config.maxParticles)));
    for (auto& p : m_particles) p.alive = false;
}

void ParticleEmitter::Play() {
    m_playing   = true;
    m_elapsed   = 0.0f;
    m_emitAccum = 0.0f;
}

void ParticleEmitter::Stop() {
    m_playing = false;
}

void ParticleEmitter::Reset() {
    Stop();
    for (auto& p : m_particles) p.alive = false;
    m_emitAccum = 0.0f;
    m_elapsed   = 0.0f;
}

void ParticleEmitter::Burst(int count) {
    int n = (count < 0) ? m_config.burst : count;
    if (n > 0) Emit(n);
}

Particle& ParticleEmitter::GetDeadParticle() {
    for (auto& p : m_particles)
        if (!p.alive) return p;
    // Reuse oldest (overwrite)
    return m_particles[0];
}

void ParticleEmitter::Emit(int count) {
    for (int i = 0; i < count; ++i) {
        Particle& p = GetDeadParticle();

        float life  = RandF(m_config.lifetimeMin, m_config.lifetimeMax);
        float speed = RandF(m_config.speedMin,    m_config.speedMax);
        float angle = RandF(m_config.angleMin,    m_config.angleMax);

        p.position   = m_position;
        p.velocity   = {speed * std::cos(angle), speed * std::sin(angle)};
        p.rotation   = RandF(m_config.rotationMin,   m_config.rotationMax);
        p.angularVel = RandF(m_config.angularVelMin,  m_config.angularVelMax);
        p.color      = m_config.colorStart;
        p.colorEnd   = m_config.colorEnd;
        p.size       = RandF(m_config.sizeStartMin, m_config.sizeStartMax);
        p.sizeEnd    = RandF(m_config.sizeEndMin,   m_config.sizeEndMax);
        p.life       = life;
        p.lifeTotal  = life;
        p.alive      = true;
    }
}

void ParticleEmitter::Update(float dt) {
    m_elapsed += dt;

    // Check duration
    if (!m_config.looping && m_config.duration >= 0.0f) {
        if (m_elapsed >= m_config.duration) m_playing = false;
    }

    // Continuous emission
    if (m_playing && m_config.burst == 0) {
        m_emitAccum += m_config.emissionRate * dt;
        int toEmit = (int)m_emitAccum;
        m_emitAccum -= (float)toEmit;
        if (toEmit > 0) Emit(toEmit);
    }

    // Simulate all alive particles
    for (auto& p : m_particles) {
        if (!p.alive) continue;

        p.life -= dt;
        if (p.life <= 0.0f) { p.alive = false; continue; }

        float t = p.Progress();

        // Physics
        p.velocity += m_config.gravity * dt;
        if (m_config.drag > 0.0f)
            p.velocity *= (1.0f - m_config.drag * dt);
        p.position  += p.velocity * dt;
        p.rotation  += p.angularVel * dt;

        // Interpolate color and size
        p.color = Color::Lerp(m_config.colorStart, m_config.colorEnd, t);
        p.size  = Math::Lerp(p.size, p.sizeEnd, dt / std::max(p.lifeTotal, 0.001f));
    }
}

void ParticleEmitter::Render(SpriteBatch& batch) {
    for (const auto& p : m_particles) {
        if (!p.alive) continue;

        DrawSpriteParams sp;
        sp.position = p.position;
        sp.size     = {p.size, p.size};
        sp.rotation = p.rotation;
        sp.color    = p.color;
        sp.texture  = m_config.texture;
        batch.DrawSprite(sp);
    }
}

bool ParticleEmitter::IsAlive() const {
    for (const auto& p : m_particles)
        if (p.alive) return true;
    return false;
}

int ParticleEmitter::GetActiveCount() const {
    int count = 0;
    for (const auto& p : m_particles)
        if (p.alive) ++count;
    return count;
}

// ==============================================================================
// ParticleSystem
// ==============================================================================
ParticleSystem& ParticleSystem::Get() {
    static ParticleSystem instance;
    return instance;
}

ParticleEmitter* ParticleSystem::CreateEmitter(const std::string& name,
                                                  const EmitterConfig& cfg) {
    auto em = std::make_unique<ParticleEmitter>(cfg);
    ParticleEmitter* raw = em.get();
    m_emitters[name] = std::move(em);
    return raw;
}

ParticleEmitter* ParticleSystem::GetEmitter(const std::string& name) {
    auto it = m_emitters.find(name);
    return (it != m_emitters.end()) ? it->second.get() : nullptr;
}

void ParticleSystem::DestroyEmitter(const std::string& name) {
    m_emitters.erase(name);
}

void ParticleSystem::UpdateAll(float dt) {
    for (auto& [name, em] : m_emitters) em->Update(dt);
}

void ParticleSystem::RenderAll(SpriteBatch& batch) {
    for (auto& [name, em] : m_emitters) em->Render(batch);
}

void ParticleSystem::StopAll() {
    for (auto& [name, em] : m_emitters) em->Stop();
}

void ParticleSystem::Clear() {
    m_emitters.clear();
}

} // namespace BADGE2D
