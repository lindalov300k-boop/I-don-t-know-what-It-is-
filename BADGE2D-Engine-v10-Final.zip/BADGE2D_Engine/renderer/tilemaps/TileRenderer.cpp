// ==============================================================================
// TileRenderer.cpp
// ==============================================================================

#include "TileRenderer.h"
#include "../../engine/Logging/Logger.h"
#include <cstring>
#include <vector>

namespace BADGE2D {

// ==============================================================================
// TileSetDef
// ==============================================================================
Rect2D TileSetDef::GetUVRect(uint16_t tileID) const {
    if (!texture || tileID == 0) return {0,0,0,0};
    tileID--;  // 1-based ID -> 0-based index

    int texW = (int)texture->GetWidth();
    int texH = (int)texture->GetHeight();
    int effectiveCols = columns > 0 ? columns :
        (texW - margin * 2 + spacing) / (tileWidth + spacing);
    if (effectiveCols <= 0) return {0,0,1,1};

    int col = tileID % effectiveCols;
    int row = tileID / effectiveCols;

    float px = (float)(margin + col * (tileWidth  + spacing));
    float py = (float)(margin + row * (tileHeight + spacing));
    float pw = (float)tileWidth;
    float ph = (float)tileHeight;

    float iw = 1.0f / texW;
    float ih = 1.0f / texH;
    return { px*iw, py*ih, pw*iw, ph*ih };
}

// ==============================================================================
// TileRenderer
// ==============================================================================
TileRenderer::~TileRenderer() {
    Shutdown();
}

bool TileRenderer::Initialize() {
    if (m_initialized) return true;

    m_shader = ShaderLibrary::Get().Get("tilemap");
    if (!m_shader) {
        ShaderLibrary::Get().LoadBuiltins();
        m_shader = ShaderLibrary::Get().Get("tilemap");
    }
    m_initialized = true;
    LOG_INFO("[TileRenderer] Initialized.");
    return true;
}

void TileRenderer::Shutdown() {
    if (!m_initialized) return;
    for (auto& [key, mesh] : m_meshCache) DestroyMesh(mesh);
    m_meshCache.clear();
    m_initialized = false;
}

uint32_t TileRenderer::RegisterTileSet(const TileSetDef& def) {
    uint32_t id = (uint32_t)m_tileSets.size() + 1;
    m_tileSets.push_back(def);
    LOG_INFOF("[TileRenderer] Registered tileset id=%u (%dx%d tiles)",
              id, def.tileWidth, def.tileHeight);
    return id;
}

const TileSetDef* TileRenderer::GetTileSet(uint32_t id) const {
    if (id == 0 || id > m_tileSets.size()) return nullptr;
    return &m_tileSets[id - 1];
}

void TileRenderer::DestroyMesh(LayerMesh& mesh) {
    if (mesh.vao) { glDeleteVertexArrays(1, &mesh.vao); mesh.vao = 0; }
    if (mesh.vbo) { glDeleteBuffers(1, &mesh.vbo);      mesh.vbo = 0; }
    if (mesh.ibo) { glDeleteBuffers(1, &mesh.ibo);      mesh.ibo = 0; }
    mesh.indexCount = 0;
}

// ==============================================================================
// Build tile mesh — one quad per non-empty tile
// ==============================================================================
void TileRenderer::BuildMesh(LayerMesh& mesh, const TilemapLayer& layer,
                               const TileSetDef& ts) {
    DestroyMesh(mesh);

    struct TileVertex { float x, y, u, v; };
    std::vector<TileVertex> verts;
    std::vector<uint32_t>   indices;
    verts.reserve((size_t)(layer.cols * layer.rows * 4));
    indices.reserve((size_t)(layer.cols * layer.rows * 6));

    uint32_t vi = 0;
    for (int row = 0; row < layer.rows; ++row) {
        for (int col = 0; col < layer.cols; ++col) {
            uint16_t id = layer.GetTile(col, row);
            if (id == 0) continue;

            float wx = layer.offset.x + col * layer.tileW;
            float wy = layer.offset.y + row * layer.tileH;
            float tw = layer.tileW;
            float th = layer.tileH;

            Rect2D uv = ts.GetUVRect(id);

            verts.push_back({wx,      wy,      uv.x,          uv.y + uv.h});
            verts.push_back({wx + tw, wy,      uv.x + uv.w,   uv.y + uv.h});
            verts.push_back({wx + tw, wy + th, uv.x + uv.w,   uv.y});
            verts.push_back({wx,      wy + th, uv.x,          uv.y});

            indices.push_back(vi+0); indices.push_back(vi+1); indices.push_back(vi+2);
            indices.push_back(vi+2); indices.push_back(vi+3); indices.push_back(vi+0);
            vi += 4;
        }
    }

    if (indices.empty()) return;

    mesh.indexCount = (uint32_t)indices.size();

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER,
                 verts.size() * sizeof(TileVertex), verts.data(), GL_STATIC_DRAW);

    glGenBuffers(1, &mesh.ibo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                 indices.size() * sizeof(uint32_t), indices.data(), GL_STATIC_DRAW);

    constexpr GLsizei stride = sizeof(TileVertex);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, stride, (void*)(2 * sizeof(float)));

    glBindVertexArray(0);
    LOG_DEBUGF("[TileRenderer] Built mesh: %u tiles, %u indices", vi/4, mesh.indexCount);
}

void TileRenderer::RebuildLayerMesh(const std::string& key, const TilemapLayer& layer) {
    const TileSetDef* ts = GetTileSet(layer.tilesetID);
    if (!ts) {
        LOG_WARNF("[TileRenderer] Tileset %u not found for layer '%s'",
                  layer.tilesetID, layer.name.c_str());
        return;
    }
    BuildMesh(m_meshCache[key], layer, *ts);
}

void TileRenderer::Render(const TilemapLayer& layer, const Camera2D& camera) {
    Render(layer, camera.GetViewProjectionMatrix(), camera.GetPosition());
}

void TileRenderer::Render(const TilemapLayer& layer, const Matrix4& vp,
                            const Vector2& cameraPos) {
    if (!layer.visible || !m_shader) return;

    const TileSetDef* ts = GetTileSet(layer.tilesetID);
    if (!ts || !ts->texture) return;

    // Rebuild if dirty
    auto& mesh = m_meshCache[layer.name];
    if (layer.IsDirty() || mesh.vao == 0) {
        BuildMesh(mesh, layer, *ts);
        const_cast<TilemapLayer&>(layer).MarkClean();
    }

    if (mesh.indexCount == 0) return;

    // Parallax offset
    Vector2 parallaxOffset = {
        cameraPos.x * (1.0f - layer.parallaxX),
        cameraPos.y * (1.0f - layer.parallaxY)
    };

    Matrix4 model = Matrix4::Translation(parallaxOffset);

    m_shader->Bind();
    m_shader->SetMat4("u_ViewProjection", vp);
    m_shader->SetMat4("u_Model", model);
    m_shader->SetVec4("u_Tint", layer.tint.r, layer.tint.g, layer.tint.b,
                       layer.tint.a * layer.opacity);
    m_shader->SetInt("u_Tileset", 0);

    ts->texture->Bind(0);

    glBindVertexArray(mesh.vao);
    glDrawElements(GL_TRIANGLES, (GLsizei)mesh.indexCount, GL_UNSIGNED_INT, nullptr);
    glBindVertexArray(0);
}

} // namespace BADGE2D
