#pragma once
// ==============================================================================
// TileRenderer.h — Efficient layer-based tilemap rendering
// ==============================================================================

#include "../../thirdparty/glad/include/glad/glad_stub.h"
#include "../../utilities/Math/MathUtils.h"
#include "../../utilities/Math/Matrix4.h"
#include "../textures/Texture2D.h"
#include "../shaders/Shader.h"
#include "../camera/Camera2D.h"
#include "../../ecs/component/Components.h"
#include <vector>
#include <memory>
#include <cstdint>

namespace BADGE2D {

// ==============================================================================
// TileSet — Defines how tiles map to texture regions
// ==============================================================================
struct TileSetDef {
    std::shared_ptr<Texture2D> texture;
    int    tileWidth    = 32;
    int    tileHeight   = 32;
    int    columns      = 0;    // Auto-computed from texture width
    int    rows         = 0;
    int    spacing      = 0;
    int    margin       = 0;
    float  pixelsPerUnit = 1.0f;  // How many pixels = 1 world unit

    // Get UV rect for tile ID (0-based, left-to-right, top-to-bottom)
    Rect2D GetUVRect(uint16_t tileID) const;
};

// ==============================================================================
// TilemapLayer — One layer of tiles (background, foreground, collision, etc.)
// ==============================================================================
struct TilemapLayer {
    std::string    name;
    int            cols        = 0;
    int            rows        = 0;
    float          tileW       = 32.0f;
    float          tileH       = 32.0f;
    float          opacity     = 1.0f;
    Color          tint        = Color::White();
    bool           visible     = true;
    Vector2        offset      = {};        // Layer parallax offset
    float          parallaxX   = 1.0f;
    float          parallaxY   = 1.0f;
    uint32_t       tilesetID   = 0;

    std::vector<uint16_t> tiles;            // 0 = empty

    uint16_t GetTile(int c, int r) const {
        if (c < 0 || r < 0 || c >= cols || r >= rows) return 0;
        return tiles[(size_t)(r * cols + c)];
    }
    void SetTile(int c, int r, uint16_t id) {
        if (c < 0 || r < 0 || c >= cols || r >= rows) return;
        tiles[(size_t)(r * cols + c)] = id;
        m_dirty = true;
    }
    void Resize(int c, int r, float tw, float th) {
        cols = c; rows = r; tileW = tw; tileH = th;
        tiles.assign((size_t)(c * r), 0);
        m_dirty = true;
    }
    void Fill(uint16_t id)  { std::fill(tiles.begin(), tiles.end(), id); m_dirty = true; }
    void Clear()             { Fill(0); }

    bool IsDirty()       const { return m_dirty; }
    void MarkClean()           { m_dirty = false; }
    void MarkDirty()           { m_dirty = true; }

    // World rect for this layer
    Rect2D GetWorldRect() const {
        return {0, 0, cols * tileW, rows * tileH};
    }

    bool m_dirty = true;
};

// ==============================================================================
// TilemapChunk — GPU batch for a region of tiles
// ==============================================================================
struct TilemapChunk {
    GLuint   vao = 0;
    GLuint   vbo = 0;
    GLuint   ibo = 0;
    uint32_t indexCount = 0;
    Rect2D   worldRect;
    bool     needsRebuild = true;
};

// ==============================================================================
// TileRenderer — Renders TilemapLayers efficiently
// ==============================================================================
class TileRenderer {
public:
    TileRenderer() = default;
    ~TileRenderer();

    bool Initialize();
    void Shutdown();

    // Register a tileset
    uint32_t RegisterTileSet(const TileSetDef& def);
    const TileSetDef* GetTileSet(uint32_t id) const;

    // Render a tilemap layer
    void Render(const TilemapLayer& layer, const Camera2D& camera);
    void Render(const TilemapLayer& layer, const Matrix4& viewProjection,
                const Vector2& cameraPos);

    // Rebuild GPU buffers for a layer (call when tiles change)
    void RebuildLayerMesh(const std::string& layerKey, const TilemapLayer& layer);

private:
    struct LayerMesh {
        GLuint   vao = 0;
        GLuint   vbo = 0;
        GLuint   ibo = 0;
        uint32_t indexCount = 0;
    };

    void BuildMesh(LayerMesh& mesh, const TilemapLayer& layer, const TileSetDef& ts);
    void DestroyMesh(LayerMesh& mesh);

    std::vector<TileSetDef>                        m_tileSets;
    std::unordered_map<std::string, LayerMesh>     m_meshCache;
    Shader*                                        m_shader = nullptr;
    bool                                           m_initialized = false;
};

} // namespace BADGE2D
