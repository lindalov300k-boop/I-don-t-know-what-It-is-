// ==============================================================================
// Framebuffer.cpp + PostProcessor implementation
// ==============================================================================

#include "Framebuffer.h"
#include "../../engine/Logging/Logger.h"

namespace BADGE2D {

// ==============================================================================
// Framebuffer
// ==============================================================================
Framebuffer::~Framebuffer() {
    Destroy();
}

bool Framebuffer::Create(const Spec& spec) {
    m_spec = spec;
    Destroy();

    glGenFramebuffers(1, &m_fbo);
    glBindFramebuffer(GL_FRAMEBUFFER, m_fbo);

    // Color attachment
    glGenTextures(1, &m_colorTexID);
    glBindTexture(GL_TEXTURE_2D, m_colorTexID);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8,
                 (GLsizei)spec.width, (GLsizei)spec.height, 0,
                 GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                           GL_TEXTURE_2D, m_colorTexID, 0);

    // Depth/stencil renderbuffer
    if (spec.hasDepth) {
        glGenRenderbuffers(1, &m_rbo);
        glBindRenderbuffer(GL_RENDERBUFFER, m_rbo);
        glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_ATTACHMENT,
                               (GLsizei)spec.width, (GLsizei)spec.height);
        glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,
                                  GL_RENDERBUFFER, m_rbo);
    }

    GLenum status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    if (status != GL_FRAMEBUFFER_COMPLETE) {
        LOG_ERRORF("[Framebuffer] Incomplete! Status: 0x%X", status);
        Destroy();
        return false;
    }

    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    LOG_DEBUGF("[Framebuffer] Created %ux%u FBO (id=%u)", spec.width, spec.height, m_fbo);
    return true;
}

void Framebuffer::Destroy() {
    if (m_colorTexID) { glDeleteTextures(1, &m_colorTexID); m_colorTexID = 0; }
    if (m_rbo)        { glDeleteRenderbuffers(1, &m_rbo); m_rbo = 0; }
    if (m_fbo)        { glDeleteFramebuffers(1, &m_fbo);  m_fbo = 0; }
}

void Framebuffer::Bind() const {
    glBindFramebuffer(GL_FRAMEBUFFER, m_fbo);
    glViewport(0, 0, (GLsizei)m_spec.width, (GLsizei)m_spec.height);
}

void Framebuffer::Unbind() const {
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void Framebuffer::Clear(const Color& c) const {
    glClearColor(c.r, c.g, c.b, c.a);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void Framebuffer::Resize(uint32_t w, uint32_t h) {
    if (w == m_spec.width && h == m_spec.height) return;
    m_spec.width  = w;
    m_spec.height = h;
    Create(m_spec);
}

void Framebuffer::BindColorTexture(uint32_t slot) const {
    glActiveTexture(GL_TEXTURE0 + slot);
    glBindTexture(GL_TEXTURE_2D, m_colorTexID);
}

// ==============================================================================
// PostProcessor
// ==============================================================================
bool PostProcessor::Initialize(uint32_t w, uint32_t h) {
    if (m_initialized) return true;

    Framebuffer::Spec spec{w, h, true};
    if (!m_sceneBuffer.Create(spec)) return false;
    if (!m_ping.Create(spec))        return false;
    if (!m_pong.Create(spec))        return false;

    BuildScreenQuad();

    m_passthroughShader = ShaderLibrary::Get().Get("screen");
    if (!m_passthroughShader) {
        ShaderLibrary::Get().LoadBuiltins();
        m_passthroughShader = ShaderLibrary::Get().Get("screen");
    }

    m_initialized = true;
    LOG_INFOF("[PostProcessor] Initialized (%ux%u).", w, h);
    return true;
}

void PostProcessor::BuildScreenQuad() {
    // NDC full-screen triangle pair
    float verts[] = {
        -1.f, -1.f,  0.f, 0.f,
         1.f, -1.f,  1.f, 0.f,
         1.f,  1.f,  1.f, 1.f,
        -1.f,  1.f,  0.f, 1.f
    };
    glGenVertexArrays(1, &m_quadVAO);
    glBindVertexArray(m_quadVAO);
    glGenBuffers(1, &m_quadVBO);
    glBindBuffer(GL_ARRAY_BUFFER, m_quadVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2*sizeof(float)));
    glBindVertexArray(0);
}

void PostProcessor::Shutdown() {
    if (!m_initialized) return;
    m_sceneBuffer.Destroy();
    m_ping.Destroy();
    m_pong.Destroy();
    if (m_quadVAO) { glDeleteVertexArrays(1, &m_quadVAO); m_quadVAO = 0; }
    if (m_quadVBO) { glDeleteBuffers(1, &m_quadVBO); m_quadVBO = 0; }
    m_effects.clear();
    m_initialized = false;
}

void PostProcessor::Resize(uint32_t w, uint32_t h) {
    m_sceneBuffer.Resize(w, h);
    m_ping.Resize(w, h);
    m_pong.Resize(w, h);
}

void PostProcessor::BeginSceneCapture() {
    m_sceneBuffer.Bind();
    m_sceneBuffer.Clear();
}

void PostProcessor::EndSceneCapture() {
    m_sceneBuffer.Unbind();

    if (m_effects.empty()) {
        // Passthrough: blit scene to screen
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        m_passthroughShader->Bind();
        m_sceneBuffer.BindColorTexture(0);
        m_passthroughShader->SetInt("u_Screen", 0);
        DrawScreenQuad();
        return;
    }

    // Ping-pong through enabled effects
    bool pingActive = true;
    Framebuffer* src = &m_sceneBuffer;
    Framebuffer* dst = &m_ping;

    for (auto& fx : m_effects) {
        if (!fx.enabled) continue;

        Shader* sh = fx.shader ? fx.shader : m_passthroughShader;
        dst->Bind();
        dst->Clear();
        sh->Bind();
        src->BindColorTexture(0);
        sh->SetInt("u_Screen", 0);
        if (fx.OnSetUniforms) fx.OnSetUniforms(*sh);
        DrawScreenQuad();
        dst->Unbind();

        src = dst;
        dst = pingActive ? &m_pong : &m_ping;
        pingActive = !pingActive;
    }

    // Final blit to screen
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    m_passthroughShader->Bind();
    src->BindColorTexture(0);
    m_passthroughShader->SetInt("u_Screen", 0);
    DrawScreenQuad();
}

void PostProcessor::DrawScreenQuad() {
    glBindVertexArray(m_quadVAO);
    glDrawArrays(GL_TRIANGLES, 0, 6);
    glBindVertexArray(0);
}

void PostProcessor::AddEffect(const PostEffect& fx) {
    m_effects.push_back(fx);
}

void PostProcessor::RemoveEffect(const std::string& name) {
    m_effects.erase(
        std::remove_if(m_effects.begin(), m_effects.end(),
            [&](const PostEffect& f){ return f.name == name; }),
        m_effects.end());
}

void PostProcessor::SetEffectEnabled(const std::string& name, bool en) {
    for (auto& fx : m_effects) if (fx.name == name) { fx.enabled = en; return; }
}

void PostProcessor::ClearEffects() { m_effects.clear(); }

void PostProcessor::AddBloom(float threshold, float intensity) {
    static bool registered = false;
    if (!registered) {
        ShaderLibrary::Get().Add("bloom",
            BuiltinShaders::SCREEN_VERT, PostShaders::BLOOM_FRAG);
        registered = true;
    }
    PostEffect fx;
    fx.name    = "bloom";
    fx.shader  = ShaderLibrary::Get().Get("bloom");
    float t = threshold, i = intensity;
    fx.OnSetUniforms = [t, i](Shader& sh) {
        sh.SetFloat("u_Threshold", t);
        sh.SetFloat("u_Intensity", i);
    };
    AddEffect(fx);
}

void PostProcessor::AddVignette(float radius, float softness) {
    static bool registered = false;
    if (!registered) {
        ShaderLibrary::Get().Add("vignette",
            BuiltinShaders::SCREEN_VERT, PostShaders::VIGNETTE_FRAG);
        registered = true;
    }
    PostEffect fx;
    fx.name   = "vignette";
    fx.shader = ShaderLibrary::Get().Get("vignette");
    float r = radius, s = softness;
    fx.OnSetUniforms = [r, s](Shader& sh) {
        sh.SetFloat("u_Radius",   r);
        sh.SetFloat("u_Softness", s);
    };
    AddEffect(fx);
}

void PostProcessor::AddColorGrading(float brightness, float contrast, float saturation) {
    static bool registered = false;
    if (!registered) {
        ShaderLibrary::Get().Add("colorgrade",
            BuiltinShaders::SCREEN_VERT, PostShaders::COLOR_GRADE_FRAG);
        registered = true;
    }
    PostEffect fx;
    fx.name   = "colorgrade";
    fx.shader = ShaderLibrary::Get().Get("colorgrade");
    float b=brightness, c=contrast, sa=saturation;
    fx.OnSetUniforms = [b, c, sa](Shader& sh) {
        sh.SetFloat("u_Brightness",  b);
        sh.SetFloat("u_Contrast",    c);
        sh.SetFloat("u_Saturation",  sa);
    };
    AddEffect(fx);
}

} // namespace BADGE2D
