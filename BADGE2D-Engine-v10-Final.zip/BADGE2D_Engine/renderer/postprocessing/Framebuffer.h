#pragma once
// ==============================================================================
// Framebuffer.h + PostProcessor.h — Off-screen rendering and post-FX pipeline
// ==============================================================================

#include "../../thirdparty/glad/include/glad/glad_stub.h"
#include "../../utilities/Math/MathUtils.h"
#include "../shaders/Shader.h"
#include "../textures/Texture2D.h"
#include <memory>
#include <vector>
#include <functional>
#include <string>

namespace BADGE2D {

// ==============================================================================
// Framebuffer — Off-screen render target (FBO)
// ==============================================================================
class Framebuffer {
public:
    struct Spec {
        uint32_t width  = 1280;
        uint32_t height = 720;
        bool     hasDepth = true;
        bool     hasStencil = false;
    };

    Framebuffer() = default;
    ~Framebuffer();

    Framebuffer(const Framebuffer&) = delete;
    Framebuffer& operator=(const Framebuffer&) = delete;

    bool   Create(const Spec& spec);
    void   Destroy();
    void   Bind()   const;
    void   Unbind() const;   // Bind default (screen) framebuffer
    void   Resize(uint32_t w, uint32_t h);
    void   Clear(const Color& color = Color::Black()) const;

    bool   IsValid()       const { return m_fbo != 0; }
    GLuint GetFBO()        const { return m_fbo; }
    GLuint GetColorTexID() const { return m_colorTexID; }
    uint32_t GetWidth()    const { return m_spec.width; }
    uint32_t GetHeight()   const { return m_spec.height; }
    const Spec& GetSpec()  const { return m_spec; }

    // Bind the color texture to a slot for use as shader input
    void BindColorTexture(uint32_t slot = 0) const;

private:
    GLuint m_fbo        = 0;
    GLuint m_colorTexID = 0;
    GLuint m_rbo        = 0;   // Depth/stencil renderbuffer
    Spec   m_spec;
};

// ==============================================================================
// PostEffect — A single post-processing pass
// ==============================================================================
struct PostEffect {
    std::string name;
    bool        enabled = true;

    // Called to set shader uniforms before the pass renders
    std::function<void(Shader& shader)> OnSetUniforms;

    // Custom shader for this effect; if null, uses "screen" passthrough
    Shader*     shader  = nullptr;
};

// ==============================================================================
// PostProcessor — Manages the FBO chain and effect passes
// ==============================================================================
class PostProcessor {
public:
    PostProcessor() = default;
    ~PostProcessor() = default;

    bool Initialize(uint32_t width, uint32_t height);
    void Shutdown();
    void Resize(uint32_t width, uint32_t height);

    // Start rendering the scene to the off-screen buffer
    void BeginSceneCapture();
    // Finish scene, apply all effects, blit to screen
    void EndSceneCapture();

    // Effect management
    void AddEffect   (const PostEffect& effect);
    void RemoveEffect(const std::string& name);
    void SetEffectEnabled(const std::string& name, bool enabled);
    void ClearEffects();

    bool IsInitialized() const { return m_initialized; }

    // Convenience built-in effects
    void AddBloom   (float threshold = 0.8f, float intensity = 1.2f);
    void AddVignette(float radius = 0.75f, float softness = 0.45f);
    void AddChromaticAberration(float offset = 0.005f);
    void AddColorGrading(float brightness = 0.0f, float contrast = 1.0f,
                          float saturation = 1.0f);

    Framebuffer& GetSceneBuffer()   { return m_sceneBuffer; }
    Framebuffer& GetPingBuffer()    { return m_ping; }
    Framebuffer& GetPongBuffer()    { return m_pong; }

private:
    void DrawScreenQuad();
    void BuildScreenQuad();

    Framebuffer           m_sceneBuffer;
    Framebuffer           m_ping;
    Framebuffer           m_pong;
    std::vector<PostEffect> m_effects;

    // Screen quad VAO/VBO
    GLuint  m_quadVAO = 0;
    GLuint  m_quadVBO = 0;
    Shader* m_passthroughShader = nullptr;

    bool    m_initialized = false;
};

// ==============================================================================
// PostProcessor GLSL effect shaders
// ==============================================================================
namespace PostShaders {

    inline constexpr const char* BLOOM_FRAG = R"glsl(
#version 410 core
in vec2 v_TexCoord;
uniform sampler2D u_Screen;
uniform float u_Threshold;
uniform float u_Intensity;
out vec4 FragColor;

vec3 BlurH(sampler2D tex, vec2 uv, vec2 texelSize) {
    vec3 result = vec3(0.0);
    float weights[5] = float[](0.227027, 0.316216, 0.070270, 0.316216, 0.227027);
    for (int i = -2; i <= 2; ++i)
        result += texture(tex, uv + vec2(texelSize.x * i, 0.0)).rgb * weights[i+2];
    return result;
}

void main() {
    vec3 color  = texture(u_Screen, v_TexCoord).rgb;
    float lum   = dot(color, vec3(0.2126, 0.7152, 0.0722));
    vec3  bloom = lum > u_Threshold ? color * u_Intensity : vec3(0.0);
    FragColor   = vec4(color + bloom, 1.0);
}
)glsl";

    inline constexpr const char* VIGNETTE_FRAG = R"glsl(
#version 410 core
in vec2 v_TexCoord;
uniform sampler2D u_Screen;
uniform float u_Radius;
uniform float u_Softness;
out vec4 FragColor;
void main() {
    vec4  color  = texture(u_Screen, v_TexCoord);
    vec2  uv     = v_TexCoord - 0.5;
    float dist   = length(uv);
    float vign   = smoothstep(u_Radius, u_Radius - u_Softness, dist);
    FragColor    = vec4(color.rgb * vign, color.a);
}
)glsl";

    inline constexpr const char* COLOR_GRADE_FRAG = R"glsl(
#version 410 core
in vec2 v_TexCoord;
uniform sampler2D u_Screen;
uniform float u_Brightness;
uniform float u_Contrast;
uniform float u_Saturation;
out vec4 FragColor;
void main() {
    vec3  c    = texture(u_Screen, v_TexCoord).rgb;
    c          += u_Brightness;
    c           = (c - 0.5) * u_Contrast + 0.5;
    float gray  = dot(c, vec3(0.299, 0.587, 0.114));
    c           = mix(vec3(gray), c, u_Saturation);
    FragColor   = vec4(clamp(c, 0.0, 1.0), 1.0);
}
)glsl";

} // namespace PostShaders

} // namespace BADGE2D
