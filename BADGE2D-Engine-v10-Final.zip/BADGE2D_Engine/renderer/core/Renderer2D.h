#pragma once
// ==============================================================================
// Renderer2D.h — High-level 2D renderer facade
// Integrates: SpriteBatch, TileRenderer, ParticleSystem, PostProcessor
// This is what game code calls.
// ==============================================================================

#include "../core/RenderDevice.h"
#include "../sprites/SpriteBatch.h"
#include "../tilemaps/TileRenderer.h"
#include "../particles/ParticleSystem.h"
#include "../postprocessing/Framebuffer.h"
#include "../camera/Camera2D.h"
#include "../../engine/ModuleSystem/ModuleInterface.h"
#include <memory>

namespace BADGE2D {

// ==============================================================================
// Renderer2D — Engine module that owns all rendering subsystems
// ==============================================================================
class Renderer2D : public IModule {
public:
    Renderer2D() = default;
    ~Renderer2D() override;

    // IModule
    bool        Initialize()           override;
    void        Shutdown()             override;
    void        Update(double dt)      override;
    void        Render()               override;
    const char* GetName()        const override { return "Renderer2D"; }
    uint32_t    GetInitOrder()   const override { return (uint32_t)ModuleInitOrder::Renderer; }

    // ==============================================================================
    // Frame API (game code calls these)
    // ==============================================================================
    void BeginFrame();
    void EndFrame();

    // Attach camera for this frame's view
    void SetCamera(Camera2D* camera);

    // ==============================================================================
    // Subsystem accessors
    // ==============================================================================
    SpriteBatch&   GetSpriteBatch()   { return m_spriteBatch; }
    TileRenderer&  GetTileRenderer()  { return m_tileRenderer; }
    PostProcessor& GetPostProcessor() { return m_postProcessor; }
    RenderDevice&  GetDevice()        { return RenderDevice::Get(); }

    // ==============================================================================
    // Quick draw API (thin wrappers over SpriteBatch)
    // ==============================================================================
    void DrawSprite(const Vector2& pos, const Vector2& size,
                    std::shared_ptr<Texture2D> tex,
                    const Color& tint = Color::White(), float rot = 0.0f);

    void DrawQuad  (const Vector2& pos, const Vector2& size,
                    const Color& color,  float rot = 0.0f);

    void DrawLine  (const Vector2& a, const Vector2& b,
                    const Color& color, float thickness = 1.0f);

    void DrawRect  (const Rect2D& rect, const Color& color, float thickness = 1.0f);

    void DrawTilemap(const TilemapLayer& layer);
    void DrawFullscreenQuad(const Color& color);  // Used by scene transitions

    // ==============================================================================
    // Clear / viewport
    // ==============================================================================
    void Clear    (const Color& color = {0.1f, 0.1f, 0.15f, 1.0f});
    void SetViewport(uint32_t x, uint32_t y, uint32_t w, uint32_t h);
    void ResetViewport();

    // ==============================================================================
    // Stats
    // ==============================================================================
    const RenderStats& GetStats() const { return m_spriteBatch.GetStats(); }
    void               PrintStats() const;

    static Renderer2D& Get();

private:
    SpriteBatch   m_spriteBatch;
    TileRenderer  m_tileRenderer;
    PostProcessor m_postProcessor;
    Camera2D*     m_activeCamera  = nullptr;
    Camera2D      m_defaultCamera;
    bool          m_inFrame       = false;
};

} // namespace BADGE2D
