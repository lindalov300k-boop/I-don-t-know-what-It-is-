#pragma once
// ==============================================================================
// RenderDevice.h — GLFW window + OpenGL context + viewport management
// ==============================================================================

#include "../../utilities/Math/MathUtils.h"
#include "../../utilities/EventSystem.h"
#include "../../engine/Engine/EngineConfig.h"
#include <string>
#include <functional>
#include <cstdint>

// Forward declare GLFW types (avoids including glfw in headers)
struct GLFWwindow;

namespace BADGE2D {

// ==============================================================================
// RenderDeviceSpec — window creation parameters
// ==============================================================================
struct RenderDeviceSpec {
    std::string title     = "BADGE2D";
    uint32_t    width     = 1280;
    uint32_t    height    = 720;
    bool        vsync     = true;
    bool        fullscreen= false;
    bool        resizable = true;
    int         msaa      = 0;           // 0 = off, 4 = 4x MSAA
    int         glMajor   = 4;
    int         glMinor   = 1;
    bool        coreProfile = true;
};

// ==============================================================================
// RenderDevice — Owns the GLFW window and OpenGL context
// ==============================================================================
class RenderDevice {
public:
    static RenderDevice& Get();

    bool Initialize(const RenderDeviceSpec& spec);
    void Shutdown();

    // Called at the end of each frame
    void SwapBuffers();
    void PollEvents();

    // Window state
    bool       IsOpen()         const;
    bool       ShouldClose()    const;
    void       Close();
    void       SetTitle(const std::string& title);
    void       SetVSync(bool enable);
    void       SetFullscreen(bool fullscreen);
    Vector2    GetWindowSize()  const { return {(float)m_width, (float)m_height}; }
    uint32_t   GetWidth()       const { return m_width; }
    uint32_t   GetHeight()      const { return m_height; }
    float      GetAspect()      const { return (float)m_width / (float)m_height; }
    GLFWwindow* GetGLFWWindow() const { return m_window; }

    // Time
    double     GetTime()        const;

    // Callbacks (set these before Initialize to customize)
    std::function<void(int,int)>   OnResize;
    std::function<void()>          OnClose;
    std::function<void(int,int,int,int)> OnKey;
    std::function<void(double,double)>   OnMouseMove;
    std::function<void(int,int,int)>     OnMouseButton;
    std::function<void(double,double)>   OnMouseScroll;
    std::function<void(unsigned int)>    OnChar;

    bool IsInitialized() const { return m_initialized; }

private:
    RenderDevice() = default;
    static void GLFWErrorCallback(int error, const char* desc);
    static void FramebufferSizeCallback(GLFWwindow* w, int width, int height);
    static void KeyCallback(GLFWwindow* w, int key, int scan, int action, int mods);
    static void MouseMoveCallback(GLFWwindow* w, double x, double y);
    static void MouseButtonCallback(GLFWwindow* w, int button, int action, int mods);
    static void ScrollCallback(GLFWwindow* w, double dx, double dy);
    static void CharCallback(GLFWwindow* w, unsigned int c);

    GLFWwindow*     m_window      = nullptr;
    uint32_t        m_width       = 1280;
    uint32_t        m_height      = 720;
    bool            m_vsync       = true;
    bool            m_initialized = false;
};

} // namespace BADGE2D
