// ==============================================================================
// Renderer2D.cpp — High-level renderer facade
// ==============================================================================

#include "Renderer2D.h"
#include "../../engine/Logging/Logger.h"
#include "../../engine/Profiling/Profiler.h"

namespace BADGE2D {

Renderer2D& Renderer2D::Get() {
    static Renderer2D instance;
    return instance;
}

Renderer2D::~Renderer2D() {
    if (m_initialized) Shutdown();
}

bool Renderer2D::Initialize() {
    if (m_initialized) return true;

    LOG_INFO("[Renderer2D] Initializing...");

    // Load built-in shaders
    ShaderLibrary::Get().LoadBuiltins();

    // Initialize sprite batch
    if (!m_spriteBatch.Initialize()) {
        LOG_ERROR("[Renderer2D] SpriteBatch init failed.");
        return false;
    }

    // Initialize tile renderer
    if (!m_tileRenderer.Initialize()) {
        LOG_ERROR("[Renderer2D] TileRenderer init failed.");
        return false;
    }

    // Post-processor (use window size from RenderDevice)
    auto& dev = RenderDevice::Get();
    if (dev.IsInitialized()) {
        uint32_t w = dev.GetWidth();
        uint32_t h = dev.GetHeight();
        m_postProcessor.Initialize(w, h);
        m_defaultCamera.SetViewportSize((float)w, (float)h);

        // Update post-processor on resize
        dev.OnResize = [this](int w, int h) {
            m_postProcessor.Resize((uint32_t)w, (uint32_t)h);
            m_defaultCamera.SetViewportSize((float)w, (float)h);
            if (m_activeCamera) m_activeCamera->SetViewportSize((float)w, (float)h);
            LOG_DEBUGF("[Renderer2D] Viewport resized to %dx%d", w, h);
        };
    }

    m_initialized = true;
    LOG_INFO("[Renderer2D] Ready.");
    return true;
}

void Renderer2D::Shutdown() {
    if (!m_initialized) return;
    m_spriteBatch.Shutdown();
    m_tileRenderer.Shutdown();
    m_postProcessor.Shutdown();
    ShaderLibrary::Get().Clear();
    TextureCache::Get().Clear();
    m_initialized = false;
    LOG_INFO("[Renderer2D] Shutdown complete.");
}

void Renderer2D::Update(double dt) {
    if (m_activeCamera) m_activeCamera->UpdateShake((float)dt);
}

void Renderer2D::Render() {
    // This is called by the engine's module render pass.
    // Most rendering is driven by BeginFrame/EndFrame called directly by game code.
}

void Renderer2D::SetCamera(Camera2D* camera) {
    m_activeCamera = camera;
}

void Renderer2D::BeginFrame() {
    BADGE2D_PROFILE_SCOPE("Renderer2D::BeginFrame");
    assert(!m_inFrame && "EndFrame() must be called first");
    m_inFrame = true;

    Camera2D& cam = m_activeCamera ? *m_activeCamera : m_defaultCamera;

    if (m_postProcessor.IsInitialized())
        m_postProcessor.BeginSceneCapture();

    m_spriteBatch.Begin(cam);
}

void Renderer2D::EndFrame() {
    BADGE2D_PROFILE_SCOPE("Renderer2D::EndFrame");
    assert(m_inFrame && "BeginFrame() must be called first");

    m_spriteBatch.End();

    if (m_postProcessor.IsInitialized())
        m_postProcessor.EndSceneCapture();

    RenderDevice::Get().SwapBuffers();
    RenderDevice::Get().PollEvents();

    m_spriteBatch.ResetStats();
    m_inFrame = false;
}

// ==============================================================================
// Quick draw helpers
// ==============================================================================
void Renderer2D::DrawSprite(const Vector2& pos, const Vector2& size,
                              std::shared_ptr<Texture2D> tex,
                              const Color& tint, float rot) {
    m_spriteBatch.DrawSprite(pos, size, std::move(tex), tint, rot);
}

void Renderer2D::DrawQuad(const Vector2& pos, const Vector2& size,
                           const Color& color, float rot) {
    m_spriteBatch.DrawQuad(pos, size, color, rot);
}

void Renderer2D::DrawLine(const Vector2& a, const Vector2& b,
                           const Color& color, float thickness) {
    m_spriteBatch.DrawLine(a, b, color, thickness);
}

void Renderer2D::DrawRect(const Rect2D& rect, const Color& color, float thickness) {
    m_spriteBatch.DrawRect(rect, color, thickness);
}

void Renderer2D::DrawTilemap(const TilemapLayer& layer) {
    Camera2D& cam = m_activeCamera ? *m_activeCamera : m_defaultCamera;
    m_tileRenderer.Render(layer, cam);
}

void Renderer2D::Clear(const Color& color) {
    glClearColor(color.r, color.g, color.b, color.a);
    glClear(GL_COLOR_BUFFER_BIT);
}

void Renderer2D::SetViewport(uint32_t x, uint32_t y, uint32_t w, uint32_t h) {
    glViewport((GLint)x, (GLint)y, (GLsizei)w, (GLsizei)h);
}

void Renderer2D::ResetViewport() {
    auto& dev = RenderDevice::Get();
    glViewport(0, 0, (GLsizei)dev.GetWidth(), (GLsizei)dev.GetHeight());
}

void Renderer2D::PrintStats() const {
    const auto& s = m_spriteBatch.GetStats();
    LOG_INFOF("[Renderer2D] DrawCalls=%u  Quads=%u  TexSwaps=%u",
              s.drawCalls, s.quadCount, s.textureSwaps);
}

} // namespace BADGE2D

void Renderer2D::DrawFullscreenQuad(const Color& color) {
    // Draw a fullscreen overlay quad — used for scene fade transitions
    if (m_batch) {
        m_batch->DrawQuad({0.0f,0.0f}, {(float)m_width, (float)m_height}, nullptr, nullptr, color);
    }
}
