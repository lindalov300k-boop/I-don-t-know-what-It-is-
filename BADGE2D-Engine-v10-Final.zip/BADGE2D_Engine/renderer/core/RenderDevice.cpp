// ==============================================================================
// RenderDevice.cpp — GLFW + OpenGL context management
// ==============================================================================

#include "RenderDevice.h"
#include "../../engine/Logging/Logger.h"

// GLFW inclusion (requires libglfw3-dev)
#ifdef __has_include
  #if __has_include(<GLFW/glfw3.h>)
    #include <GLFW/glfw3.h>
    #define BADGE2D_HAS_GLFW 1
  #endif
#endif

#ifndef BADGE2D_HAS_GLFW
  // Stub for systems without GLFW headers during offline compilation
  struct GLFWwindow {};
  inline bool glfwInit()                                    { return false; }
  inline void glfwTerminate()                               {}
  inline void glfwWindowHint(int, int)                      {}
  inline GLFWwindow* glfwCreateWindow(int,int,const char*,void*,void*) { return nullptr; }
  inline void glfwDestroyWindow(GLFWwindow*)                {}
  inline bool glfwWindowShouldClose(GLFWwindow*)            { return true; }
  inline void glfwSetWindowShouldClose(GLFWwindow*,int)     {}
  inline void glfwMakeContextCurrent(GLFWwindow*)           {}
  inline void glfwSwapBuffers(GLFWwindow*)                  {}
  inline void glfwPollEvents()                              {}
  inline void glfwSwapInterval(int)                         {}
  inline void glfwSetWindowTitle(GLFWwindow*,const char*)   {}
  inline void glfwSetWindowUserPointer(GLFWwindow*,void*)   {}
  inline void* glfwGetWindowUserPointer(GLFWwindow*)        { return nullptr; }
  inline double glfwGetTime()                               { return 0.0; }
  inline void glfwSetFramebufferSizeCallback(GLFWwindow*,void*){}
  inline void glfwSetKeyCallback(GLFWwindow*,void*)         {}
  inline void glfwSetCursorPosCallback(GLFWwindow*,void*)   {}
  inline void glfwSetMouseButtonCallback(GLFWwindow*,void*) {}
  inline void glfwSetScrollCallback(GLFWwindow*,void*)      {}
  inline void glfwSetCharCallback(GLFWwindow*,void*)        {}
  inline void glfwSetErrorCallback(void*)                   {}
  #define GLFW_RESIZABLE 0x00020003
  #define GLFW_CONTEXT_VERSION_MAJOR 0x00022002
  #define GLFW_CONTEXT_VERSION_MINOR 0x00022003
  #define GLFW_OPENGL_PROFILE 0x00022008
  #define GLFW_OPENGL_CORE_PROFILE 0x00032001
  #define GLFW_SAMPLES 0x0002100D
#endif

namespace BADGE2D {

RenderDevice& RenderDevice::Get() {
    static RenderDevice instance;
    return instance;
}

void RenderDevice::GLFWErrorCallback(int error, const char* desc) {
    LOG_ERRORF("[GLFW] Error %d: %s", error, desc);
}

bool RenderDevice::Initialize(const RenderDeviceSpec& spec) {
    if (m_initialized) return true;

    m_width  = spec.width;
    m_height = spec.height;
    m_vsync  = spec.vsync;

    LOG_INFOF("[RenderDevice] Initializing GLFW (%ux%u, vsync=%s)...",
              spec.width, spec.height, spec.vsync ? "on" : "off");

    glfwSetErrorCallback(GLFWErrorCallback);

    if (!glfwInit()) {
        LOG_FATAL("[RenderDevice] Failed to initialize GLFW.");
        return false;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, spec.glMajor);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, spec.glMinor);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_RESIZABLE, spec.resizable ? 1 : 0);
    if (spec.msaa > 0) glfwWindowHint(GLFW_SAMPLES, spec.msaa);

#ifdef __APPLE__
    // Required on macOS for OpenGL 4.1 Core
    glfwWindowHint(0x00022008, 0x00032001); // OPENGL_FORWARD_COMPAT
#endif

    m_window = glfwCreateWindow(
        (int)spec.width, (int)spec.height,
        spec.title.c_str(),
        spec.fullscreen ? (void*)1 : nullptr,  // monitor placeholder
        nullptr
    );

    if (!m_window) {
        LOG_FATAL("[RenderDevice] Failed to create GLFW window.");
        glfwTerminate();
        return false;
    }

    glfwMakeContextCurrent(m_window);
    glfwSwapInterval(spec.vsync ? 1 : 0);

    // Store 'this' pointer for callbacks
    glfwSetWindowUserPointer(m_window, this);

    // Install callbacks
    glfwSetFramebufferSizeCallback(m_window,
        (void(*)(GLFWwindow*,int,int))FramebufferSizeCallback);
    glfwSetKeyCallback(m_window,
        (void(*)(GLFWwindow*,int,int,int,int))KeyCallback);
    glfwSetCursorPosCallback(m_window,
        (void(*)(GLFWwindow*,double,double))MouseMoveCallback);
    glfwSetMouseButtonCallback(m_window,
        (void(*)(GLFWwindow*,int,int,int))MouseButtonCallback);
    glfwSetScrollCallback(m_window,
        (void(*)(GLFWwindow*,double,double))ScrollCallback);
    glfwSetCharCallback(m_window,
        (void(*)(GLFWwindow*,unsigned int))CharCallback);

    m_initialized = true;
    LOG_INFOF("[RenderDevice] Context created. OpenGL %d.%d Core.", spec.glMajor, spec.glMinor);

    // Set initial GL state
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_DEPTH_TEST);
    glViewport(0, 0, (GLsizei)spec.width, (GLsizei)spec.height);

    LOG_INFO("[RenderDevice] GL blend enabled. Viewport set.");
    return true;
}

void RenderDevice::Shutdown() {
    if (!m_initialized) return;
    if (m_window) {
        glfwDestroyWindow(m_window);
        m_window = nullptr;
    }
    glfwTerminate();
    m_initialized = false;
    LOG_INFO("[RenderDevice] Shutdown.");
}

void RenderDevice::SwapBuffers() {
    if (m_window) glfwSwapBuffers(m_window);
}

void RenderDevice::PollEvents() {
    glfwPollEvents();
}

bool RenderDevice::IsOpen()       const { return m_window != nullptr; }
bool RenderDevice::ShouldClose()  const { return m_window && glfwWindowShouldClose(m_window); }
void RenderDevice::Close()              { if (m_window) glfwSetWindowShouldClose(m_window, 1); }
void RenderDevice::SetTitle(const std::string& t) { if (m_window) glfwSetWindowTitle(m_window, t.c_str()); }
void RenderDevice::SetVSync(bool v) {
    m_vsync = v;
    glfwSwapInterval(v ? 1 : 0);
}
double RenderDevice::GetTime() const { return glfwGetTime(); }

// ==============================================================================
// GLFW Callbacks
// ==============================================================================
void RenderDevice::FramebufferSizeCallback(GLFWwindow* w, int width, int height) {
    glViewport(0, 0, width, height);
    auto* dev = static_cast<RenderDevice*>(glfwGetWindowUserPointer(w));
    if (!dev) return;
    dev->m_width  = (uint32_t)width;
    dev->m_height = (uint32_t)height;
    if (dev->OnResize) dev->OnResize(width, height);
    EventBus::Get().Dispatch(WindowResizeEvent{width, height});
}

void RenderDevice::KeyCallback(GLFWwindow* w, int key, int scan, int action, int mods) {
    auto* dev = static_cast<RenderDevice*>(glfwGetWindowUserPointer(w));
    if (dev && dev->OnKey) dev->OnKey(key, scan, action, mods);
}

void RenderDevice::MouseMoveCallback(GLFWwindow* w, double x, double y) {
    auto* dev = static_cast<RenderDevice*>(glfwGetWindowUserPointer(w));
    if (dev && dev->OnMouseMove) dev->OnMouseMove(x, y);
}

void RenderDevice::MouseButtonCallback(GLFWwindow* w, int btn, int action, int mods) {
    auto* dev = static_cast<RenderDevice*>(glfwGetWindowUserPointer(w));
    if (dev && dev->OnMouseButton) dev->OnMouseButton(btn, action, mods);
}

void RenderDevice::ScrollCallback(GLFWwindow* w, double dx, double dy) {
    auto* dev = static_cast<RenderDevice*>(glfwGetWindowUserPointer(w));
    if (dev && dev->OnMouseScroll) dev->OnMouseScroll(dx, dy);
}

void RenderDevice::CharCallback(GLFWwindow* w, unsigned int c) {
    auto* dev = static_cast<RenderDevice*>(glfwGetWindowUserPointer(w));
    if (dev && dev->OnChar) dev->OnChar(c);
}

void RenderDevice::SetFullscreen(bool /*fullscreen*/) {
    // TODO: glfwSetWindowMonitor() toggle
    LOG_WARN("[RenderDevice] Fullscreen toggle not yet implemented.");
}

} // namespace BADGE2D
