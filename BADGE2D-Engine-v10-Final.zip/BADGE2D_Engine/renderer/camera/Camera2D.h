#pragma once
// ==============================================================================
// Camera2D.h — 2D camera with zoom, rotation, scroll, screen<->world conversion
// ==============================================================================

#include "../../utilities/Math/Matrix4.h"
#include "../../utilities/Math/MathUtils.h"
#include <functional>

namespace BADGE2D {

// ==============================================================================
// Camera2D
// ==============================================================================
class Camera2D {
public:
    Camera2D() = default;
    Camera2D(float viewportW, float viewportH);

    // ==============================================================================
    // Configuration
    // ==============================================================================
    void SetViewportSize(float w, float h);
    void SetPosition    (const Vector2& pos);
    void SetRotation    (float radians);
    void SetZoom        (float zoom);        // 1.0 = normal
    void SetBounds      (const Rect2D& worldBounds, bool constrain = true);
    void ClearBounds    ();

    // Smooth follow
    void Follow(const Vector2& target, float smoothing = 0.1f, float dt = 0.016f);

    // Shake
    void AddShake(float intensity, float duration);
    void UpdateShake(float dt);

    // ==============================================================================
    // Transform accessors
    // ==============================================================================
    const Vector2&   GetPosition()   const { return m_position; }
    float            GetRotation()   const { return m_rotation; }
    float            GetZoom()       const { return m_zoom; }
    Vector2          GetViewportSize()const { return m_viewport; }

    // ==============================================================================
    // Matrices
    // ==============================================================================
    const Matrix4& GetViewMatrix()       const;
    const Matrix4& GetProjectionMatrix() const;
    Matrix4        GetViewProjectionMatrix() const;

    // ==============================================================================
    // Coordinate conversion
    // ==============================================================================
    Vector2 WorldToScreen(const Vector2& world) const;
    Vector2 ScreenToWorld(const Vector2& screen) const;
    bool    IsInView(const Vector2& worldPos, float radius = 0.0f) const;
    bool    IsInView(const Rect2D& worldRect) const;
    Rect2D  GetVisibleRect() const;

    void    RecalculateMatrices();

    // ==============================================================================
    // Pixel-perfect mode
    // ==============================================================================
    void  SetPixelPerfect(bool enabled) { m_pixelPerfect = enabled; }
    bool  IsPixelPerfect()        const { return m_pixelPerfect; }

private:
    void ConstrainToBounds();
    void DirtyMatrices() { m_dirty = true; }

    Vector2  m_position    = {0.0f, 0.0f};
    float    m_rotation    = 0.0f;
    float    m_zoom        = 1.0f;
    Vector2  m_viewport    = {1280.0f, 720.0f};

    // Shake
    float    m_shakeIntensity = 0.0f;
    float    m_shakeDuration  = 0.0f;
    float    m_shakeTimer     = 0.0f;
    Vector2  m_shakeOffset    = {};

    // Bounds constraint
    Rect2D   m_bounds         = {};
    bool     m_hasBounds      = false;
    bool     m_constrainBounds= false;

    bool     m_pixelPerfect   = false;

    mutable bool    m_dirty      = true;
    mutable Matrix4 m_view;
    mutable Matrix4 m_projection;
};

// ==============================================================================
// CameraController — Keyboard/mouse pan & zoom for editor/debug
// ==============================================================================
class CameraController {
public:
    explicit CameraController(Camera2D* camera);

    void Update(float dt);

    // Configurable speeds
    float panSpeed    = 400.0f;  // World units per second
    float zoomSpeed   = 0.1f;
    float minZoom     = 0.1f;
    float maxZoom     = 10.0f;

    // Input state (set by InputManager)
    bool  keyLeft  = false;
    bool  keyRight = false;
    bool  keyUp    = false;
    bool  keyDown  = false;
    float scrollDelta = 0.0f;
    bool  dragging    = false;
    Vector2 dragDelta = {};

private:
    Camera2D* m_camera = nullptr;
};

} // namespace BADGE2D
