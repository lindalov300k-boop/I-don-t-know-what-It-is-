// ==============================================================================
// Camera2D.cpp — Camera implementation
// ==============================================================================

#include "Camera2D.h"
#include "../../utilities/Math/MathUtils.h"
#include <cmath>
#include <algorithm>

namespace BADGE2D {

Camera2D::Camera2D(float viewportW, float viewportH) {
    m_viewport = {viewportW, viewportH};
}

void Camera2D::SetViewportSize(float w, float h) {
    m_viewport = {w, h};
    DirtyMatrices();
}

void Camera2D::SetPosition(const Vector2& pos) {
    m_position = pos;
    if (m_hasBounds && m_constrainBounds) ConstrainToBounds();
    DirtyMatrices();
}

void Camera2D::SetRotation(float rad) {
    m_rotation = rad;
    DirtyMatrices();
}

void Camera2D::SetZoom(float z) {
    m_zoom = std::max(0.01f, z);
    DirtyMatrices();
}

void Camera2D::SetBounds(const Rect2D& bounds, bool constrain) {
    m_bounds          = bounds;
    m_hasBounds       = true;
    m_constrainBounds = constrain;
    ConstrainToBounds();
    DirtyMatrices();
}

void Camera2D::ClearBounds() {
    m_hasBounds = false;
}

void Camera2D::Follow(const Vector2& target, float smoothing, float dt) {
    Vector2 newPos = Vector2::Lerp(m_position, target, 1.0f - std::pow(1.0f - smoothing, dt * 60.0f));
    SetPosition(newPos);
}

void Camera2D::AddShake(float intensity, float duration) {
    m_shakeIntensity = std::max(m_shakeIntensity, intensity);
    m_shakeDuration  = std::max(m_shakeDuration,  duration);
    m_shakeTimer     = m_shakeDuration;
}

void Camera2D::UpdateShake(float dt) {
    if (m_shakeTimer <= 0.0f) {
        m_shakeOffset = Vector2::Zero();
        return;
    }
    m_shakeTimer -= dt;
    float t = m_shakeTimer / m_shakeDuration;
    float mag = m_shakeIntensity * t;

    // Pseudo-random offset using time
    float angle = m_shakeTimer * 37.3f;
    m_shakeOffset = {std::sin(angle) * mag, std::cos(angle * 1.3f) * mag};
    DirtyMatrices();
}

void Camera2D::ConstrainToBounds() {
    if (!m_hasBounds || !m_constrainBounds) return;
    float hw = (m_viewport.x * 0.5f) / m_zoom;
    float hh = (m_viewport.y * 0.5f) / m_zoom;

    m_position.x = std::clamp(m_position.x,
                               m_bounds.x + hw, m_bounds.x + m_bounds.w - hw);
    m_position.y = std::clamp(m_position.y,
                               m_bounds.y + hh, m_bounds.y + m_bounds.h - hh);
}

void Camera2D::RecalculateMatrices() {
    if (!m_dirty) return;
    m_dirty = false;

    // Projection: orthographic centered on viewport
    float hw = m_viewport.x * 0.5f;
    float hh = m_viewport.y * 0.5f;
    m_projection = Matrix4::Ortho(-hw, hw, -hh, hh, -1.0f, 1.0f);

    // View: inverse of camera TRS
    Vector2 camPos = m_position + m_shakeOffset;
    if (m_pixelPerfect) {
        camPos.x = std::round(camPos.x);
        camPos.y = std::round(camPos.y);
    }

    // View = Scale(zoom) * RotZ(-rot) * Translate(-pos)
    m_view = Matrix4::Scale(m_zoom, m_zoom)
           * Matrix4::RotationZ(-m_rotation)
           * Matrix4::Translation(-camPos.x, -camPos.y);
}

const Matrix4& Camera2D::GetViewMatrix() const {
    if (m_dirty) const_cast<Camera2D*>(this)->RecalculateMatrices();
    return m_view;
}

const Matrix4& Camera2D::GetProjectionMatrix() const {
    if (m_dirty) const_cast<Camera2D*>(this)->RecalculateMatrices();
    return m_projection;
}

Matrix4 Camera2D::GetViewProjectionMatrix() const {
    return GetProjectionMatrix() * GetViewMatrix();
}

Vector2 Camera2D::WorldToScreen(const Vector2& world) const {
    Matrix4 vp = GetViewProjectionMatrix();
    Vector2 ndc = vp * world;
    // NDC [-1,1] to screen [0,viewport]
    return {
        (ndc.x + 1.0f) * 0.5f * m_viewport.x,
        (1.0f - (ndc.y + 1.0f) * 0.5f) * m_viewport.y
    };
}

Vector2 Camera2D::ScreenToWorld(const Vector2& screen) const {
    // Screen [0,viewport] -> NDC [-1,1]
    float ndcX = (screen.x / m_viewport.x) * 2.0f - 1.0f;
    float ndcY = 1.0f - (screen.y / m_viewport.y) * 2.0f;

    // Inverse view: translate, rotate, scale
    Vector2 camPos = m_position + m_shakeOffset;
    // Undo scale
    float wx = ndcX / m_zoom * (m_viewport.x * 0.5f);
    float wy = ndcY / m_zoom * (m_viewport.y * 0.5f);
    // Undo rotation
    Vector2 rotated = Vector2{wx, wy}.Rotated(m_rotation);
    return rotated + camPos;
}

bool Camera2D::IsInView(const Vector2& worldPos, float radius) const {
    Rect2D vis = GetVisibleRect();
    Rect2D expanded = vis.Expanded(radius);
    return expanded.Contains(worldPos);
}

bool Camera2D::IsInView(const Rect2D& worldRect) const {
    return GetVisibleRect().Overlaps(worldRect);
}

Rect2D Camera2D::GetVisibleRect() const {
    float hw = (m_viewport.x * 0.5f) / m_zoom;
    float hh = (m_viewport.y * 0.5f) / m_zoom;
    return {m_position.x - hw, m_position.y - hh, hw * 2.0f, hh * 2.0f};
}

// ==============================================================================
// CameraController
// ==============================================================================
CameraController::CameraController(Camera2D* camera) : m_camera(camera) {}

void CameraController::Update(float dt) {
    if (!m_camera) return;

    Vector2 pos = m_camera->GetPosition();
    float   spd = panSpeed / m_camera->GetZoom();

    if (keyLeft)  pos.x -= spd * dt;
    if (keyRight) pos.x += spd * dt;
    if (keyDown)  pos.y -= spd * dt;
    if (keyUp)    pos.y += spd * dt;

    if (dragging) pos = pos - dragDelta / m_camera->GetZoom();
    dragDelta = Vector2::Zero();

    m_camera->SetPosition(pos);

    if (scrollDelta != 0.0f) {
        float newZoom = m_camera->GetZoom() * (1.0f + scrollDelta * zoomSpeed);
        newZoom = std::clamp(newZoom, minZoom, maxZoom);
        m_camera->SetZoom(newZoom);
        scrollDelta = 0.0f;
    }
}

} // namespace BADGE2D
