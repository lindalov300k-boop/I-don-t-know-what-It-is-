// ==============================================================================
// Texture2D.cpp — Texture loading and atlas management
// ==============================================================================

#include "Texture2D.h"
#include "../../engine/Logging/Logger.h"

// stb_image (define implementation in ONE .cpp)
#define STB_IMAGE_IMPLEMENTATION
#ifdef __has_include
  #if __has_include("../../thirdparty/stb/stb_image.h")
    #include "../../thirdparty/stb/stb_image.h"
    #define BADGE2D_HAS_STB_IMAGE 1
  #endif
#endif

#include <cassert>
#include <cstring>
#include <algorithm>

namespace BADGE2D {

// ==============================================================================
// Helper: GL enums from spec
// ==============================================================================
static GLenum FilterToGL(TextureFilter f, bool isMag = false) {
    switch (f) {
        case TextureFilter::Nearest:      return GL_NEAREST;
        case TextureFilter::Linear:       return GL_LINEAR;
        case TextureFilter::LinearMipmap: return isMag ? GL_LINEAR : GL_LINEAR; // GL_LINEAR_MIPMAP_LINEAR
    }
    return GL_LINEAR;
}

static GLenum WrapToGL(TextureWrap w) {
    switch (w) {
        case TextureWrap::Repeat:          return GL_REPEAT;
        case TextureWrap::ClampToEdge:     return GL_CLAMP_TO_EDGE;
        case TextureWrap::MirroredRepeat:  return GL_REPEAT; // GL_MIRRORED_REPEAT
    }
    return GL_REPEAT;
}

// ==============================================================================
// Texture2D
// ==============================================================================
Texture2D::~Texture2D() {
    if (m_id) {
        glDeleteTextures(1, &m_id);
        m_id = 0;
    }
}

Texture2D::Texture2D(Texture2D&& o) noexcept
    : m_id(o.m_id), m_width(o.m_width), m_height(o.m_height),
      m_channels(o.m_channels), m_path(std::move(o.m_path))
{
    o.m_id = 0;
}

Texture2D& Texture2D::operator=(Texture2D&& o) noexcept {
    if (this != &o) {
        if (m_id) glDeleteTextures(1, &m_id);
        m_id       = o.m_id;
        m_width    = o.m_width;
        m_height   = o.m_height;
        m_channels = o.m_channels;
        m_path     = std::move(o.m_path);
        o.m_id     = 0;
    }
    return *this;
}

bool Texture2D::LoadFromFile(const std::string& path, const TextureSpec& spec) {
    m_path = path;
#ifdef BADGE2D_HAS_STB_IMAGE
    stbi_set_flip_vertically_on_load(1);
    int w, h, c;
    uint8_t* data = stbi_load(path.c_str(), &w, &h, &c, 0);
    if (!data) {
        LOG_ERRORF("[Texture2D] Failed to load: %s  (%s)", path.c_str(), stbi_failure_reason());
        return false;
    }
    bool ok = LoadFromMemory(data, (uint32_t)w, (uint32_t)h, c, spec);
    stbi_image_free(data);
    return ok;
#else
    LOG_WARNF("[Texture2D] stb_image not available. Stub texture created for: %s", path.c_str());
    // Create a 2x2 magenta checkerboard as fallback
    uint8_t fallback[16] = {
        255,0,255,255,  0,0,0,255,
        0,0,0,255,      255,0,255,255
    };
    return LoadFromMemory(fallback, 2, 2, 4, spec);
#endif
}

bool Texture2D::LoadFromMemory(const uint8_t* data, uint32_t w, uint32_t h,
                                 int channels, const TextureSpec& spec) {
    if (m_id) glDeleteTextures(1, &m_id);

    m_width    = w;
    m_height   = h;
    m_channels = channels;

    GLenum internalFmt = (channels == 4) ? GL_RGBA8 : GL_RGBA8;
    GLenum fmt         = (channels == 4) ? GL_RGBA  : GL_RGB;
    if (channels == 1) { fmt = GL_RGBA; internalFmt = GL_RGBA8; } // grayscale -> RGBA

    glGenTextures(1, &m_id);
    glBindTexture(GL_TEXTURE_2D, m_id);
    glTexImage2D(GL_TEXTURE_2D, 0, (GLint)internalFmt,
                 (GLsizei)w, (GLsizei)h, 0, fmt, GL_UNSIGNED_BYTE, data);

    ApplySpec(spec);

    glBindTexture(GL_TEXTURE_2D, 0);
    LOG_DEBUGF("[Texture2D] Uploaded %ux%u %dch (id=%u)", w, h, channels, m_id);
    return true;
}

std::shared_ptr<Texture2D> Texture2D::CreateSolidColor(uint8_t r, uint8_t g,
                                                          uint8_t b, uint8_t a) {
    uint8_t data[4] = {r, g, b, a};
    TextureSpec spec;
    spec.genMipmaps = false;
    spec.minFilter  = TextureFilter::Nearest;
    spec.magFilter  = TextureFilter::Nearest;
    spec.wrapS      = TextureWrap::Repeat;
    spec.wrapT      = TextureWrap::Repeat;
    auto t = std::make_shared<Texture2D>();
    t->LoadFromMemory(data, 1, 1, 4, spec);
    return t;
}

bool Texture2D::CreateEmpty(uint32_t width, uint32_t height, const TextureSpec& spec) {
    if (m_id) glDeleteTextures(1, &m_id);
    m_width    = width;
    m_height   = height;
    m_channels = 4;
    glGenTextures(1, &m_id);
    glBindTexture(GL_TEXTURE_2D, m_id);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, (GLsizei)width, (GLsizei)height,
                 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    ApplySpec(spec);
    glBindTexture(GL_TEXTURE_2D, 0);
    return true;
}

void Texture2D::ApplySpec(const TextureSpec& spec) {
    GLenum minF = FilterToGL(spec.minFilter, false);
    GLenum magF = FilterToGL(spec.magFilter, true);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, (GLint)minF);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, (GLint)magF);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, (GLint)WrapToGL(spec.wrapS));
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, (GLint)WrapToGL(spec.wrapT));
    if (spec.genMipmaps) glGenerateMipmap(GL_TEXTURE_2D);
}

void Texture2D::Bind(uint32_t slot) const {
    glActiveTexture(GL_TEXTURE0 + slot);
    glBindTexture(GL_TEXTURE_2D, m_id);
}

void Texture2D::Unbind() const {
    glBindTexture(GL_TEXTURE_2D, 0);
}

Rect2D Texture2D::UVRectForPixels(float px, float py, float pw, float ph) const {
    float iw = 1.0f / m_width;
    float ih = 1.0f / m_height;
    return { px*iw, py*ih, pw*iw, ph*ih };
}

// ==============================================================================
// SubTexture
// ==============================================================================
void SubTexture::GetUVCorners(float uvs[8]) const {
    // Bottom-left, bottom-right, top-right, top-left (counter-clockwise)
    uvs[0] = uvRect.x;              uvs[1] = uvRect.y;
    uvs[2] = uvRect.x + uvRect.w;   uvs[3] = uvRect.y;
    uvs[4] = uvRect.x + uvRect.w;   uvs[5] = uvRect.y + uvRect.h;
    uvs[6] = uvRect.x;              uvs[7] = uvRect.y + uvRect.h;
}

// ==============================================================================
// TextureAtlas
// ==============================================================================
bool TextureAtlas::LoadFromFile(const std::string& imagePath) {
    m_texture = std::make_shared<Texture2D>();
    if (!m_texture->LoadFromFile(imagePath)) {
        m_texture.reset();
        return false;
    }
    LOG_INFOF("[TextureAtlas] Loaded atlas texture: %s (%ux%u)",
              imagePath.c_str(), m_texture->GetWidth(), m_texture->GetHeight());
    return true;
}

bool TextureAtlas::LoadFromSpriteSheet(const std::string& imagePath,
                                         int cols, int rows,
                                         int spriteW, int spriteH,
                                         int spacing, int margin) {
    if (!LoadFromFile(imagePath)) return false;

    m_regions.clear();
    m_nameToIndex.clear();

    for (int row = 0; row < rows; ++row) {
        for (int col = 0; col < cols; ++col) {
            float px = (float)(margin + col * (spriteW + spacing));
            float py = (float)(margin + row * (spriteH + spacing));
            char name[64];
            std::snprintf(name, sizeof(name), "sprite_%d_%d", col, row);
            AddRegion(name, px, py, (float)spriteW, (float)spriteH);
        }
    }

    LOG_INFOF("[TextureAtlas] Generated %zu sprites from %dx%d sheet",
              m_regions.size(), cols, rows);
    return true;
}

void TextureAtlas::AddRegion(const std::string& name,
                               float px, float py, float pw, float ph) {
    SubTexture sub;
    sub.name      = name;
    sub.texture   = m_texture;
    sub.pixelRect = {px, py, pw, ph};
    sub.size      = {pw, ph};

    if (m_texture) {
        sub.uvRect = m_texture->UVRectForPixels(px, py, pw, ph);
    } else {
        sub.uvRect = {0,0,1,1};
    }

    size_t idx = m_regions.size();
    m_regions.push_back(sub);
    m_nameToIndex[name] = idx;
}

SubTexture* TextureAtlas::GetSubTexture(const std::string& name) {
    auto it = m_nameToIndex.find(name);
    if (it == m_nameToIndex.end()) return nullptr;
    return &m_regions[it->second];
}

const SubTexture* TextureAtlas::GetSubTexture(const std::string& name) const {
    auto it = m_nameToIndex.find(name);
    if (it == m_nameToIndex.end()) return nullptr;
    return &m_regions[it->second];
}

SubTexture* TextureAtlas::GetSubTextureByIndex(size_t idx) {
    if (idx >= m_regions.size()) return nullptr;
    return &m_regions[idx];
}

// ==============================================================================
// TextureCache
// ==============================================================================
TextureCache::TextureCache() {}

TextureCache& TextureCache::Get() {
    static TextureCache instance;
    return instance;
}

std::shared_ptr<Texture2D> TextureCache::Load(const std::string& path,
                                                const TextureSpec& spec) {
    auto it = m_cache.find(path);
    if (it != m_cache.end()) return it->second;

    auto tex = std::make_shared<Texture2D>();
    if (!tex->LoadFromFile(path, spec)) {
        LOG_WARNF("[TextureCache] Failed to load, using fallback: %s", path.c_str());
        return GetWhiteTexture();
    }
    m_cache[path] = tex;
    return tex;
}

std::shared_ptr<Texture2D> TextureCache::GetWhiteTexture() {
    if (!m_whiteTexture)
        m_whiteTexture = Texture2D::CreateSolidColor(255, 255, 255, 255);
    return m_whiteTexture;
}

std::shared_ptr<Texture2D> TextureCache::GetBlackTexture() {
    if (!m_blackTexture)
        m_blackTexture = Texture2D::CreateSolidColor(0, 0, 0, 255);
    return m_blackTexture;
}

bool TextureCache::IsCached(const std::string& path) const {
    return m_cache.count(path) > 0;
}

void TextureCache::Unload(const std::string& path) {
    m_cache.erase(path);
}

void TextureCache::Clear() {
    m_cache.clear();
    m_whiteTexture.reset();
    m_blackTexture.reset();
}

} // namespace BADGE2D
