#pragma once
// ==============================================================================
// Texture2D.h — GPU texture wrapper with atlas and cache support
// ==============================================================================

#include "../../thirdparty/glad/include/glad/glad_stub.h"
#include "../../utilities/Math/MathUtils.h"
#include <string>
#include <memory>
#include <unordered_map>
#include <vector>
#include <cstdint>

namespace BADGE2D {

// ==============================================================================
// TextureFilter / TextureWrap
// ==============================================================================
enum class TextureFilter { Nearest, Linear, LinearMipmap };
enum class TextureWrap   { Repeat, ClampToEdge, MirroredRepeat };

// ==============================================================================
// TextureSpec — Creation descriptor
// ==============================================================================
struct TextureSpec {
    uint32_t      width        = 1;
    uint32_t      height       = 1;
    bool          genMipmaps   = true;
    bool          sRGB         = false;
    TextureFilter minFilter    = TextureFilter::LinearMipmap;
    TextureFilter magFilter    = TextureFilter::Linear;
    TextureWrap   wrapS        = TextureWrap::Repeat;
    TextureWrap   wrapT        = TextureWrap::Repeat;
};

// ==============================================================================
// Texture2D — OpenGL texture wrapper
// ==============================================================================
class Texture2D : public std::enable_shared_from_this<Texture2D> {
public:
    Texture2D() = default;
    ~Texture2D();

    Texture2D(const Texture2D&) = delete;
    Texture2D& operator=(const Texture2D&) = delete;
    Texture2D(Texture2D&&) noexcept;
    Texture2D& operator=(Texture2D&&) noexcept;

    // Create from file (stb_image)
    bool LoadFromFile(const std::string& path, const TextureSpec& spec = {});

    // Create from raw pixel data
    bool LoadFromMemory(const uint8_t* data, uint32_t width, uint32_t height,
                        int channels, const TextureSpec& spec = {});

    // Create a solid color 1x1 texture
    static std::shared_ptr<Texture2D> CreateSolidColor(uint8_t r, uint8_t g,
                                                         uint8_t b, uint8_t a = 255);

    // Create empty (render target ready)
    bool CreateEmpty(uint32_t width, uint32_t height, const TextureSpec& spec = {});

    void Bind  (uint32_t slot = 0) const;
    void Unbind() const;

    bool     IsValid()  const { return m_id != 0; }
    GLuint   GetID()    const { return m_id; }
    uint32_t GetWidth() const { return m_width; }
    uint32_t GetHeight()const { return m_height; }
    int      GetChannels() const { return m_channels; }
    const std::string& GetPath() const { return m_path; }

    Vector2  GetSize()  const { return {(float)m_width, (float)m_height}; }

    // Texel UV helpers
    Rect2D   UVRectForPixels(float px, float py, float pw, float ph) const;

private:
    void ApplySpec(const TextureSpec& spec);

    GLuint      m_id       = 0;
    uint32_t    m_width    = 0;
    uint32_t    m_height   = 0;
    int         m_channels = 0;
    std::string m_path;
};

// ==============================================================================
// SubTexture — A named region within a TextureAtlas
// ==============================================================================
struct SubTexture {
    std::string             name;
    std::shared_ptr<Texture2D> texture;   // Parent atlas texture
    Rect2D                  pixelRect;    // Pixel coordinates in atlas
    Rect2D                  uvRect;       // Normalized UVs [0,1]
    Vector2                 size;         // Width/height in pixels

    // Helper to build 4 UV corners for rendering
    void GetUVCorners(float uvs[8]) const;
};

// ==============================================================================
// TextureAtlas — Sprite sheet / texture atlas
// ==============================================================================
class TextureAtlas {
public:
    TextureAtlas() = default;

    // Load atlas from image + JSON/metadata
    bool LoadFromFile    (const std::string& imagePath);
    bool LoadFromSpriteSheet(const std::string& imagePath,
                              int cols, int rows,
                              int spriteW, int spriteH,
                              int spacing = 0, int margin = 0);

    // Manual region registration
    void AddRegion(const std::string& name,
                   float pixelX, float pixelY,
                   float pixelW, float pixelH);

    SubTexture*       GetSubTexture(const std::string& name);
    const SubTexture* GetSubTexture(const std::string& name) const;
    SubTexture*       GetSubTextureByIndex(size_t index);

    std::shared_ptr<Texture2D> GetTexture() const { return m_texture; }
    size_t GetRegionCount() const { return m_regions.size(); }

    const std::vector<SubTexture>& GetAllRegions() const { return m_regions; }

private:
    std::shared_ptr<Texture2D>                       m_texture;
    std::vector<SubTexture>                          m_regions;
    std::unordered_map<std::string, size_t>          m_nameToIndex;
};

// ==============================================================================
// TextureCache — Global texture asset cache
// ==============================================================================
class TextureCache {
public:
    static TextureCache& Get();

    std::shared_ptr<Texture2D> Load(const std::string& path,
                                     const TextureSpec& spec = {});

    std::shared_ptr<Texture2D> GetWhiteTexture();   // 1x1 white
    std::shared_ptr<Texture2D> GetBlackTexture();   // 1x1 black

    bool   IsCached(const std::string& path) const;
    void   Unload  (const std::string& path);
    void   Clear   ();

    size_t GetCacheSize() const { return m_cache.size(); }

private:
    TextureCache();
    std::unordered_map<std::string, std::shared_ptr<Texture2D>> m_cache;
    std::shared_ptr<Texture2D> m_whiteTexture;
    std::shared_ptr<Texture2D> m_blackTexture;
};

} // namespace BADGE2D
