// ==============================================================================
// Shader.cpp — Shader compilation and uniform management
// ==============================================================================

#include "Shader.h"
#include "../../engine/Logging/Logger.h"
#include "../../platform/filesystem/FileSystem.h"
#include <cassert>

namespace BADGE2D {

// ==============================================================================
// Shader
// ==============================================================================
Shader::~Shader() {
    if (m_programID) {
        glDeleteProgram(m_programID);
        m_programID = 0;
    }
}

Shader::Shader(Shader&& o) noexcept
    : m_programID(o.m_programID), m_name(std::move(o.m_name)),
      m_uniformCache(std::move(o.m_uniformCache))
{
    o.m_programID = 0;
}

Shader& Shader::operator=(Shader&& o) noexcept {
    if (this != &o) {
        if (m_programID) glDeleteProgram(m_programID);
        m_programID    = o.m_programID;
        m_name         = std::move(o.m_name);
        m_uniformCache = std::move(o.m_uniformCache);
        o.m_programID  = 0;
    }
    return *this;
}

bool Shader::CompileShader(GLuint id, const std::string& src, const std::string& type) {
    const char* csrc = src.c_str();
    glShaderSource(id, 1, &csrc, nullptr);
    glCompileShader(id);

    GLint success = 0;
    glGetShaderiv(id, GL_COMPILE_STATUS, &success);
    if (!success) {
        GLint logLen = 0;
        glGetShaderiv(id, GL_INFO_LOG_LENGTH, &logLen);
        std::string log(static_cast<size_t>(logLen), '\0');
        glGetShaderInfoLog(id, logLen, nullptr, log.data());
        LOG_ERRORF("[Shader] %s compile error in '%s':\n%s",
                   type.c_str(), m_name.c_str(), log.c_str());
        return false;
    }
    return true;
}

bool Shader::LoadFromSource(const std::string& vertSrc, const std::string& fragSrc,
                             const std::string& debugName) {
    m_name = debugName;
    m_uniformCache.clear();

    GLuint vert = glCreateShader(GL_VERTEX_SHADER);
    GLuint frag = glCreateShader(GL_FRAGMENT_SHADER);

    bool ok = CompileShader(vert, vertSrc, "Vertex") &&
              CompileShader(frag, fragSrc, "Fragment");

    if (ok) {
        GLuint prog = glCreateProgram();
        glAttachShader(prog, vert);
        glAttachShader(prog, frag);
        glLinkProgram(prog);

        GLint linked = 0;
        glGetProgramiv(prog, GL_LINK_STATUS, &linked);
        if (!linked) {
            GLint logLen = 0;
            glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &logLen);
            std::string log(static_cast<size_t>(logLen), '\0');
            glGetProgramInfoLog(prog, logLen, nullptr, log.data());
            LOG_ERRORF("[Shader] Link error in '%s':\n%s", m_name.c_str(), log.c_str());
            glDeleteProgram(prog);
            ok = false;
        } else {
            if (m_programID) glDeleteProgram(m_programID);
            m_programID = prog;
            LOG_DEBUGF("[Shader] Compiled '%s' (id=%u)", m_name.c_str(), m_programID);
        }
    }

    glDeleteShader(vert);
    glDeleteShader(frag);
    return ok;
}

bool Shader::LoadFromFiles(const std::string& vertPath, const std::string& fragPath) {
    std::string vertSrc = FileSystem::ReadTextFile(vertPath);
    std::string fragSrc = FileSystem::ReadTextFile(fragPath);
    if (vertSrc.empty()) { LOG_ERRORF("[Shader] Cannot read vert: %s", vertPath.c_str()); return false; }
    if (fragSrc.empty()) { LOG_ERRORF("[Shader] Cannot read frag: %s", fragPath.c_str()); return false; }
    return LoadFromSource(vertSrc, fragSrc, vertPath);
}

void Shader::Bind()   const { glUseProgram(m_programID); }
void Shader::Unbind() const { glUseProgram(0); }

GLint Shader::GetUniformLocation(const std::string& name) {
    auto it = m_uniformCache.find(name);
    if (it != m_uniformCache.end()) return it->second;
    GLint loc = glGetUniformLocation(m_programID, name.c_str());
    if (loc == -1)
        LOG_TRACEF("[Shader] Uniform '%s' not found in '%s'", name.c_str(), m_name.c_str());
    m_uniformCache[name] = loc;
    return loc;
}

void Shader::SetInt  (const std::string& n, int v)              { glUniform1i(GetUniformLocation(n), v); }
void Shader::SetFloat(const std::string& n, float v)            { glUniform1f(GetUniformLocation(n), v); }
void Shader::SetVec2 (const std::string& n, float x, float y)   { glUniform2f(GetUniformLocation(n), x, y); }
void Shader::SetVec2 (const std::string& n, const Vector2& v)   { glUniform2f(GetUniformLocation(n), v.x, v.y); }
void Shader::SetVec3 (const std::string& n, float x, float y, float z) { glUniform3f(GetUniformLocation(n), x, y, z); }
void Shader::SetVec4 (const std::string& n, float x, float y, float z, float w) { glUniform4f(GetUniformLocation(n), x, y, z, w); }
void Shader::SetVec4 (const std::string& n, const Color& c)     { glUniform4f(GetUniformLocation(n), c.r, c.g, c.b, c.a); }
void Shader::SetMat4 (const std::string& n, const Matrix4& mat, bool t) {
    glUniformMatrix4fv(GetUniformLocation(n), 1, t ? GL_TRUE : GL_FALSE, mat.Data());
}
void Shader::SetIntArray(const std::string& n, int* v, int count) {
    glUniform1i(GetUniformLocation(n), count); // simplified; full impl uses glUniform1iv
}

// ==============================================================================
// ShaderLibrary
// ==============================================================================
ShaderLibrary& ShaderLibrary::Get() {
    static ShaderLibrary instance;
    return instance;
}

Shader* ShaderLibrary::Add(const std::string& name, const std::string& vs, const std::string& fs) {
    auto shader = std::make_unique<Shader>();
    if (!shader->LoadFromSource(vs, fs, name)) return nullptr;
    Shader* raw = shader.get();
    m_shaders[name] = std::move(shader);
    return raw;
}

Shader* ShaderLibrary::AddFromFiles(const std::string& name,
                                     const std::string& vp,
                                     const std::string& fp) {
    auto shader = std::make_unique<Shader>();
    if (!shader->LoadFromFiles(vp, fp)) return nullptr;
    Shader* raw = shader.get();
    m_shaders[name] = std::move(shader);
    return raw;
}

Shader* ShaderLibrary::Get(const std::string& name) {
    auto it = m_shaders.find(name);
    return (it != m_shaders.end()) ? it->second.get() : nullptr;
}

bool ShaderLibrary::Exists(const std::string& name) const {
    return m_shaders.count(name) > 0;
}

void ShaderLibrary::Remove(const std::string& name) {
    m_shaders.erase(name);
}

void ShaderLibrary::Clear() {
    m_shaders.clear();
}

void ShaderLibrary::LoadBuiltins() {
    Add("sprite",   BuiltinShaders::SPRITE_VERT,  BuiltinShaders::SPRITE_FRAG);
    Add("flat",     BuiltinShaders::FLAT_VERT,    BuiltinShaders::FLAT_FRAG);
    Add("screen",   BuiltinShaders::SCREEN_VERT,  BuiltinShaders::SCREEN_FRAG);
    Add("tilemap",  BuiltinShaders::TILEMAP_VERT, BuiltinShaders::TILEMAP_FRAG);
    LOG_INFO("[ShaderLibrary] Built-in shaders loaded: sprite, flat, screen, tilemap");
}

} // namespace BADGE2D
