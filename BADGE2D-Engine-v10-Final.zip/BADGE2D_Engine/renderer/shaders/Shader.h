#pragma once
// ==============================================================================
// Shader.h — GLSL shader compilation, linking, uniform management
// ==============================================================================

#include "../../thirdparty/glad/include/glad/glad_stub.h"
#include "../../utilities/Math/Vector2.h"
#include "../../utilities/Math/Matrix4.h"
#include "../../utilities/Math/MathUtils.h"
#include <string>
#include <unordered_map>
#include <memory>

namespace BADGE2D {

// ==============================================================================
// Shader — Compiled GLSL program (vertex + fragment)
// ==============================================================================
class Shader {
public:
    Shader() = default;
    ~Shader();

    // Disable copy, allow move
    Shader(const Shader&) = delete;
    Shader& operator=(const Shader&) = delete;
    Shader(Shader&& o) noexcept;
    Shader& operator=(Shader&& o) noexcept;

    // Compilation
    bool LoadFromSource(const std::string& vertSrc, const std::string& fragSrc,
                        const std::string& debugName = "");
    bool LoadFromFiles (const std::string& vertPath, const std::string& fragPath);

    void Bind()   const;
    void Unbind() const;

    bool IsValid() const { return m_programID != 0; }
    GLuint GetProgramID() const { return m_programID; }
    const std::string& GetName() const { return m_name; }

    // ==============================================================================
    // Uniform setters — cached location lookup
    // ==============================================================================
    void SetInt   (const std::string& name, int value);
    void SetFloat (const std::string& name, float value);
    void SetVec2  (const std::string& name, float x, float y);
    void SetVec2  (const std::string& name, const Vector2& v);
    void SetVec3  (const std::string& name, float x, float y, float z);
    void SetVec4  (const std::string& name, float x, float y, float z, float w);
    void SetVec4  (const std::string& name, const Color& c);
    void SetMat4  (const std::string& name, const Matrix4& mat, bool transpose = false);
    void SetIntArray(const std::string& name, int* values, int count);

private:
    GLint GetUniformLocation(const std::string& name);
    bool  CompileShader(GLuint id, const std::string& src, const std::string& type);

    GLuint m_programID = 0;
    std::string m_name;
    mutable std::unordered_map<std::string, GLint> m_uniformCache;
};

// ==============================================================================
// ShaderLibrary — Named shader registry (singleton)
// ==============================================================================
class ShaderLibrary {
public:
    static ShaderLibrary& Get();

    // Add from source strings
    Shader* Add(const std::string& name, const std::string& vertSrc,
                const std::string& fragSrc);

    // Add from file paths
    Shader* AddFromFiles(const std::string& name,
                         const std::string& vertPath,
                         const std::string& fragPath);

    Shader* Get(const std::string& name);
    bool    Exists(const std::string& name) const;
    void    Remove(const std::string& name);
    void    Clear();

    // Load all built-in engine shaders
    void LoadBuiltins();

private:
    ShaderLibrary() = default;
    std::unordered_map<std::string, std::unique_ptr<Shader>> m_shaders;
};

// ==============================================================================
// Built-in GLSL sources (embedded as string literals)
// ==============================================================================
namespace BuiltinShaders {

    // --- Sprite Batch shader ---
    inline constexpr const char* SPRITE_VERT = R"glsl(
#version 410 core
layout(location = 0) in vec2  a_Position;
layout(location = 1) in vec4  a_Color;
layout(location = 2) in vec2  a_TexCoord;
layout(location = 3) in float a_TexIndex;
layout(location = 4) in float a_TilingFactor;

uniform mat4 u_ViewProjection;

out vec4  v_Color;
out vec2  v_TexCoord;
out float v_TexIndex;
out float v_TilingFactor;

void main() {
    v_Color        = a_Color;
    v_TexCoord     = a_TexCoord;
    v_TexIndex     = a_TexIndex;
    v_TilingFactor = a_TilingFactor;
    gl_Position    = u_ViewProjection * vec4(a_Position, 0.0, 1.0);
}
)glsl";

    inline constexpr const char* SPRITE_FRAG = R"glsl(
#version 410 core
in vec4  v_Color;
in vec2  v_TexCoord;
in float v_TexIndex;
in float v_TilingFactor;

uniform sampler2D u_Textures[16];

out vec4 FragColor;

void main() {
    int idx = int(v_TexIndex);
    vec4 texColor;
    // Dynamic indexing (requires OpenGL 4.0+ or GLSL extension)
    if      (idx == 0)  texColor = texture(u_Textures[0],  v_TexCoord * v_TilingFactor);
    else if (idx == 1)  texColor = texture(u_Textures[1],  v_TexCoord * v_TilingFactor);
    else if (idx == 2)  texColor = texture(u_Textures[2],  v_TexCoord * v_TilingFactor);
    else if (idx == 3)  texColor = texture(u_Textures[3],  v_TexCoord * v_TilingFactor);
    else if (idx == 4)  texColor = texture(u_Textures[4],  v_TexCoord * v_TilingFactor);
    else if (idx == 5)  texColor = texture(u_Textures[5],  v_TexCoord * v_TilingFactor);
    else if (idx == 6)  texColor = texture(u_Textures[6],  v_TexCoord * v_TilingFactor);
    else if (idx == 7)  texColor = texture(u_Textures[7],  v_TexCoord * v_TilingFactor);
    else if (idx == 8)  texColor = texture(u_Textures[8],  v_TexCoord * v_TilingFactor);
    else if (idx == 9)  texColor = texture(u_Textures[9],  v_TexCoord * v_TilingFactor);
    else if (idx == 10) texColor = texture(u_Textures[10], v_TexCoord * v_TilingFactor);
    else if (idx == 11) texColor = texture(u_Textures[11], v_TexCoord * v_TilingFactor);
    else if (idx == 12) texColor = texture(u_Textures[12], v_TexCoord * v_TilingFactor);
    else if (idx == 13) texColor = texture(u_Textures[13], v_TexCoord * v_TilingFactor);
    else if (idx == 14) texColor = texture(u_Textures[14], v_TexCoord * v_TilingFactor);
    else                texColor = texture(u_Textures[15], v_TexCoord * v_TilingFactor);

    if (texColor.a < 0.01) discard;
    FragColor = texColor * v_Color;
}
)glsl";

    // --- Flat color / debug shader ---
    inline constexpr const char* FLAT_VERT = R"glsl(
#version 410 core
layout(location = 0) in vec2 a_Position;
layout(location = 1) in vec4 a_Color;
uniform mat4 u_ViewProjection;
out vec4 v_Color;
void main() {
    v_Color     = a_Color;
    gl_Position = u_ViewProjection * vec4(a_Position, 0.0, 1.0);
}
)glsl";

    inline constexpr const char* FLAT_FRAG = R"glsl(
#version 410 core
in vec4 v_Color;
out vec4 FragColor;
void main() { FragColor = v_Color; }
)glsl";

    // --- Post-process / screen-quad shader ---
    inline constexpr const char* SCREEN_VERT = R"glsl(
#version 410 core
layout(location = 0) in vec2 a_Position;
layout(location = 1) in vec2 a_TexCoord;
out vec2 v_TexCoord;
void main() {
    v_TexCoord  = a_TexCoord;
    gl_Position = vec4(a_Position, 0.0, 1.0);
}
)glsl";

    inline constexpr const char* SCREEN_FRAG = R"glsl(
#version 410 core
in vec2 v_TexCoord;
uniform sampler2D u_Screen;
out vec4 FragColor;
void main() { FragColor = texture(u_Screen, v_TexCoord); }
)glsl";

    // --- Tilemap shader ---
    inline constexpr const char* TILEMAP_VERT = R"glsl(
#version 410 core
layout(location = 0) in vec2 a_Position;
layout(location = 1) in vec2 a_TexCoord;
uniform mat4 u_ViewProjection;
uniform mat4 u_Model;
out vec2 v_TexCoord;
void main() {
    v_TexCoord  = a_TexCoord;
    gl_Position = u_ViewProjection * u_Model * vec4(a_Position, 0.0, 1.0);
}
)glsl";

    inline constexpr const char* TILEMAP_FRAG = R"glsl(
#version 410 core
in vec2 v_TexCoord;
uniform sampler2D u_Tileset;
uniform vec4 u_Tint;
out vec4 FragColor;
void main() {
    vec4 c = texture(u_Tileset, v_TexCoord) * u_Tint;
    if (c.a < 0.01) discard;
    FragColor = c;
}
)glsl";

} // namespace BuiltinShaders

} // namespace BADGE2D
