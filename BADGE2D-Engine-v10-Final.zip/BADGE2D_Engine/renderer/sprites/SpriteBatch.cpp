// ==============================================================================
// SpriteBatch.cpp — Batched 2D renderer implementation
// ==============================================================================

#include "SpriteBatch.h"
#include "../../engine/Logging/Logger.h"
#include "../../engine/Profiling/Profiler.h"
#include <cmath>
#include <cassert>
#include <cstring>

namespace BADGE2D {

constexpr float SpriteBatch::QUAD_POSITIONS[8];

// ==============================================================================
// Initialize — allocate GPU resources
// ==============================================================================
bool SpriteBatch::Initialize() {
    if (m_initialized) return true;

    // Allocate CPU vertex buffer
    m_vertexBuffer = new SpriteVertex[SPRITE_BATCH_MAX_VERTICES];

    // Generate index buffer (static, never changes)
    auto* indices = new uint32_t[SPRITE_BATCH_MAX_INDICES];
    uint32_t offset = 0;
    for (uint32_t i = 0; i < SPRITE_BATCH_MAX_INDICES; i += SPRITE_BATCH_INDICES_PER_QUAD) {
        indices[i + 0] = offset + 0;
        indices[i + 1] = offset + 1;
        indices[i + 2] = offset + 2;
        indices[i + 3] = offset + 2;
        indices[i + 4] = offset + 3;
        indices[i + 5] = offset + 0;
        offset += 4;
    }

    // Create VAO/VBO/IBO
    glGenVertexArrays(1, &m_vao);
    glBindVertexArray(m_vao);

    glGenBuffers(1, &m_vbo);
    glBindBuffer(GL_ARRAY_BUFFER, m_vbo);
    glBufferData(GL_ARRAY_BUFFER,
                 SPRITE_BATCH_MAX_VERTICES * sizeof(SpriteVertex),
                 nullptr, GL_DYNAMIC_DRAW);

    glGenBuffers(1, &m_ibo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m_ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                 SPRITE_BATCH_MAX_INDICES * sizeof(uint32_t),
                 indices, GL_STATIC_DRAW);

    delete[] indices;

    // Vertex attribute layout: Position(2) + Color(4) + TexCoord(2) + TexIdx(1) + Tiling(1)
    constexpr GLsizei stride = sizeof(SpriteVertex);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, stride, (void*)offsetof(SpriteVertex, position));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, stride, (void*)offsetof(SpriteVertex, color));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)offsetof(SpriteVertex, texCoord));
    glEnableVertexAttribArray(3);
    glVertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, stride, (void*)offsetof(SpriteVertex, texIndex));
    glEnableVertexAttribArray(4);
    glVertexAttribPointer(4, 1, GL_FLOAT, GL_FALSE, stride, (void*)offsetof(SpriteVertex, tilingFactor));

    glBindVertexArray(0);

    // Get shader from library
    m_shader = ShaderLibrary::Get().Get("sprite");
    if (!m_shader) {
        LOG_ERROR("[SpriteBatch] 'sprite' shader not found — call ShaderLibrary::LoadBuiltins() first");
        // Create builtin on the fly
        ShaderLibrary::Get().LoadBuiltins();
        m_shader = ShaderLibrary::Get().Get("sprite");
    }

    // White fallback texture in slot 0
    m_textureSlots[0] = TextureCache::Get().GetWhiteTexture();

    m_initialized = true;

    LOG_INFOF("[SpriteBatch] Initialized. Max %u sprites/batch, %u texture slots.",
              SPRITE_BATCH_MAX_SPRITES, SPRITE_BATCH_MAX_TEXTURES);
    return true;
}

// ==============================================================================
// Shutdown
// ==============================================================================
void SpriteBatch::Shutdown() {
    if (!m_initialized) return;

    delete[] m_vertexBuffer;
    m_vertexBuffer = nullptr;

    if (m_vao) { glDeleteVertexArrays(1, &m_vao); m_vao = 0; }
    if (m_vbo) { glDeleteBuffers(1, &m_vbo); m_vbo = 0; }
    if (m_ibo) { glDeleteBuffers(1, &m_ibo); m_ibo = 0; }

    for (auto& slot : m_textureSlots) slot.reset();
    m_textureSlotIndex = 1;
    m_initialized = false;
}

SpriteBatch::~SpriteBatch() {
    Shutdown();
}

// ==============================================================================
// Begin
// ==============================================================================
void SpriteBatch::Begin(const Camera2D& camera) {
    Begin(camera.GetViewProjectionMatrix());
}

void SpriteBatch::Begin(const Matrix4& vp) {
    assert(!m_inBatch && "SpriteBatch::End() must be called before Begin()");
    m_viewProjection = vp;
    m_inBatch = true;
    StartBatch();
}

void SpriteBatch::StartBatch() {
    m_vertexBufferPtr  = m_vertexBuffer;
    m_indexCount       = 0;
    m_textureSlotIndex = 1;
}

// ==============================================================================
// End / Flush
// ==============================================================================
void SpriteBatch::End() {
    assert(m_inBatch && "SpriteBatch::Begin() must be called first");
    Flush();
    m_inBatch = false;
}

void SpriteBatch::Flush() {
    BADGE2D_PROFILE_SCOPE("SpriteBatch::Flush");

    if (m_indexCount == 0) return;

    // Upload vertex data
    uint32_t dataSize = (uint32_t)((uint8_t*)m_vertexBufferPtr - (uint8_t*)m_vertexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, m_vbo);
    glBufferSubData(GL_ARRAY_BUFFER, 0, dataSize, m_vertexBuffer);

    // Bind textures
    for (uint32_t i = 0; i < m_textureSlotIndex; ++i) {
        if (m_textureSlots[i]) m_textureSlots[i]->Bind(i);
    }

    // Set shader uniforms
    m_shader->Bind();
    m_shader->SetMat4("u_ViewProjection", m_viewProjection);

    // Set texture samplers (u_Textures[0..15] = 0..15)
    int samplers[SPRITE_BATCH_MAX_TEXTURES];
    for (int i = 0; i < (int)SPRITE_BATCH_MAX_TEXTURES; ++i) samplers[i] = i;
    // Set each individually since our stub doesn't support glUniform1iv directly
    for (int i = 0; i < (int)SPRITE_BATCH_MAX_TEXTURES; ++i) {
        char name[32];
        std::snprintf(name, sizeof(name), "u_Textures[%d]", i);
        m_shader->SetInt(name, i);
    }

    // Draw
    glBindVertexArray(m_vao);
    glDrawElements(GL_TRIANGLES, (GLsizei)m_indexCount, GL_UNSIGNED_INT, nullptr);
    glBindVertexArray(0);

    // Stats
    m_stats.drawCalls++;
    m_stats.vertCount += m_indexCount / SPRITE_BATCH_INDICES_PER_QUAD * SPRITE_BATCH_VERTS_PER_QUAD;

    // Reset batch
    StartBatch();
}

void SpriteBatch::NextBatch() {
    Flush();
}

// ==============================================================================
// Texture slot management
// ==============================================================================
float SpriteBatch::GetTextureSlot(const std::shared_ptr<Texture2D>& tex) {
    if (!tex) return 0.0f;  // White

    // Check if already in a slot
    for (uint32_t i = 1; i < m_textureSlotIndex; ++i) {
        if (m_textureSlots[i] && m_textureSlots[i]->GetID() == tex->GetID())
            return (float)i;
    }

    // Need new slot
    if (m_textureSlotIndex >= SPRITE_BATCH_MAX_TEXTURES) {
        NextBatch();
        m_stats.textureSwaps++;
    }

    float slot = (float)m_textureSlotIndex;
    m_textureSlots[m_textureSlotIndex++] = tex;
    return slot;
}

// ==============================================================================
// Submit quad vertices
// ==============================================================================
void SpriteBatch::SubmitQuad(const Vector2 positions[4],
                               const float uvs[8],
                               const Color& color,
                               float texIndex,
                               float tilingFactor) {
    if (m_indexCount >= SPRITE_BATCH_MAX_INDICES)
        NextBatch();

    for (int i = 0; i < 4; ++i) {
        m_vertexBufferPtr->position[0]  = positions[i].x;
        m_vertexBufferPtr->position[1]  = positions[i].y;
        m_vertexBufferPtr->color[0]     = color.r;
        m_vertexBufferPtr->color[1]     = color.g;
        m_vertexBufferPtr->color[2]     = color.b;
        m_vertexBufferPtr->color[3]     = color.a;
        m_vertexBufferPtr->texCoord[0]  = uvs[i * 2 + 0];
        m_vertexBufferPtr->texCoord[1]  = uvs[i * 2 + 1];
        m_vertexBufferPtr->texIndex     = texIndex;
        m_vertexBufferPtr->tilingFactor = tilingFactor;
        ++m_vertexBufferPtr;
    }
    m_indexCount   += SPRITE_BATCH_INDICES_PER_QUAD;
    m_stats.quadCount++;
}

// ==============================================================================
// DrawSprite (full params)
// ==============================================================================
void SpriteBatch::DrawSprite(const DrawSpriteParams& p) {
    assert(m_inBatch && "Must call Begin() first");

    float texSlot = GetTextureSlot(p.texture);

    // Build corner positions around pivot
    float hw = p.size.x * (1.0f - p.pivot.x);
    float lw = p.size.x * p.pivot.x;
    float hh = p.size.y * (1.0f - p.pivot.y);
    float lh = p.size.y * p.pivot.y;

    // Local corners (bottom-left, bottom-right, top-right, top-left)
    Vector2 local[4] = {
        {-lw, -lh},
        { hw, -lh},
        { hw,  hh},
        {-lw,  hh}
    };

    // Apply rotation and translation
    Vector2 world[4];
    float c = std::cos(p.rotation);
    float s = std::sin(p.rotation);
    for (int i = 0; i < 4; ++i) {
        float rx = local[i].x * c - local[i].y * s;
        float ry = local[i].x * s + local[i].y * c;
        world[i] = {rx + p.position.x, ry + p.position.y};
    }

    // UV corners (with optional flip)
    float u0 = p.flipX ? p.uvRect.x + p.uvRect.w : p.uvRect.x;
    float u1 = p.flipX ? p.uvRect.x               : p.uvRect.x + p.uvRect.w;
    float v0 = p.flipY ? p.uvRect.y + p.uvRect.h  : p.uvRect.y;
    float v1 = p.flipY ? p.uvRect.y                : p.uvRect.y + p.uvRect.h;

    float uvs[8] = { u0, v0,  u1, v0,  u1, v1,  u0, v1 };

    SubmitQuad(world, uvs, p.color, texSlot, p.tilingFactor);
}

// ==============================================================================
// Convenience overloads
// ==============================================================================
void SpriteBatch::DrawSprite(const Vector2& pos, const Vector2& size,
                               std::shared_ptr<Texture2D> texture,
                               const Color& tint, float rotation) {
    DrawSpriteParams p;
    p.position = pos;
    p.size     = size;
    p.texture  = std::move(texture);
    p.color    = tint;
    p.rotation = rotation;
    DrawSprite(p);
}

void SpriteBatch::DrawQuad(const Vector2& pos, const Vector2& size,
                            const Color& color, float rotation) {
    DrawSpriteParams p;
    p.position = pos;
    p.size     = size;
    p.color    = color;
    p.rotation = rotation;
    // No texture: white quad
    DrawSprite(p);
}

void SpriteBatch::DrawSubTexture(const Vector2& pos, const Vector2& size,
                                   const SubTexture& sub,
                                   const Color& tint, float rotation) {
    DrawSpriteParams p;
    p.position = pos;
    p.size     = size;
    p.texture  = sub.texture;
    p.uvRect   = sub.uvRect;
    p.color    = tint;
    p.rotation = rotation;
    DrawSprite(p);
}

void SpriteBatch::DrawSprite(const Transform2D& transform, const Vector2& size,
                               std::shared_ptr<Texture2D> texture, const Color& tint) {
    DrawSpriteParams p;
    p.position = transform.position;
    p.size     = {size.x * transform.scale.x, size.y * transform.scale.y};
    p.rotation = transform.rotation;
    p.texture  = std::move(texture);
    p.color    = tint;
    DrawSprite(p);
}

// ==============================================================================
// Debug draw helpers
// ==============================================================================
void SpriteBatch::DrawRectFill(const Rect2D& rect, const Color& color) {
    DrawQuad({rect.x + rect.w * 0.5f, rect.y + rect.h * 0.5f},
             {rect.w, rect.h}, color);
}

void SpriteBatch::DrawRect(const Rect2D& rect, const Color& color, float thickness) {
    // Draw 4 thin filled quads as borders
    DrawRectFill({rect.x,              rect.y,              rect.w, thickness}, color);
    DrawRectFill({rect.x,              rect.y + rect.h - thickness, rect.w, thickness}, color);
    DrawRectFill({rect.x,              rect.y,              thickness, rect.h}, color);
    DrawRectFill({rect.x + rect.w - thickness, rect.y,     thickness, rect.h}, color);
}

void SpriteBatch::DrawLine(const Vector2& a, const Vector2& b,
                            const Color& color, float thickness) {
    Vector2 dir = (b - a).Normalized();
    Vector2 perp = {-dir.y, dir.x};
    float   len  = Vector2::Distance(a, b);
    Vector2 center = {(a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f};
    float   angle  = std::atan2(dir.y, dir.x);

    DrawQuad(center, {len, thickness}, color, angle);
}

void SpriteBatch::DrawCircle(const Vector2& center, float radius,
                               const Color& color, int segments, float thickness) {
    float step = Math::TAU / (float)segments;
    for (int i = 0; i < segments; ++i) {
        float a0 = step * i;
        float a1 = step * (i + 1);
        Vector2 p0 = center + Vector2{std::cos(a0), std::sin(a0)} * radius;
        Vector2 p1 = center + Vector2{std::cos(a1), std::sin(a1)} * radius;
        DrawLine(p0, p1, color, thickness);
    }
}

} // namespace BADGE2D
