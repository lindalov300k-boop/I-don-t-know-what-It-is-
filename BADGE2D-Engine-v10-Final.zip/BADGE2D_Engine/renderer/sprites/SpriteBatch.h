#pragma once
// ==============================================================================
// SpriteBatch.h — High-performance batched 2D sprite renderer
// Batches up to 10,000 sprites into a single draw call per texture set.
// ==============================================================================

#include "../../thirdparty/glad/include/glad/glad_stub.h"
#include "../../utilities/Math/MathUtils.h"
#include "../../utilities/Math/Matrix4.h"
#include "../textures/Texture2D.h"
#include "../shaders/Shader.h"
#include "../camera/Camera2D.h"
#include <array>
#include <memory>
#include <cstdint>
#include <functional>

namespace BADGE2D {

// ==============================================================================
// SpriteBatch constants
// ==============================================================================
constexpr uint32_t SPRITE_BATCH_MAX_SPRITES    = 10000;
constexpr uint32_t SPRITE_BATCH_MAX_TEXTURES   = 16;
constexpr uint32_t SPRITE_BATCH_VERTS_PER_QUAD = 4;
constexpr uint32_t SPRITE_BATCH_INDICES_PER_QUAD = 6;
constexpr uint32_t SPRITE_BATCH_MAX_VERTICES   = SPRITE_BATCH_MAX_SPRITES * SPRITE_BATCH_VERTS_PER_QUAD;
constexpr uint32_t SPRITE_BATCH_MAX_INDICES    = SPRITE_BATCH_MAX_SPRITES * SPRITE_BATCH_INDICES_PER_QUAD;

// ==============================================================================
// SpriteVertex — per-vertex data for sprite rendering
// ==============================================================================
struct SpriteVertex {
    float  position[2];    // x, y world position
    float  color[4];       // r, g, b, a
    float  texCoord[2];    // u, v
    float  texIndex;       // which texture slot (0-15)
    float  tilingFactor;   // UV tiling multiplier
};

// ==============================================================================
// DrawSpriteParams — everything needed to draw a sprite quad
// ==============================================================================
struct DrawSpriteParams {
    Vector2   position    = {};
    Vector2   size        = {64.0f, 64.0f};
    Vector2   pivot       = {0.5f, 0.5f};   // 0-1, relative to size
    float     rotation    = 0.0f;
    Color     color       = Color::White();
    Rect2D    uvRect      = {0,0,1,1};       // Normalized UV region
    std::shared_ptr<Texture2D> texture;
    float     tilingFactor = 1.0f;
    int       sortOrder   = 0;
    bool      flipX       = false;
    bool      flipY       = false;
};

// ==============================================================================
// RenderStats — per-frame draw call statistics
// ==============================================================================
struct RenderStats {
    uint32_t drawCalls  = 0;
    uint32_t quadCount  = 0;
    uint32_t vertCount  = 0;
    uint32_t textureSwaps = 0;

    void Reset() { drawCalls = quadCount = vertCount = textureSwaps = 0; }
};

// ==============================================================================
// SpriteBatch — the renderer
// ==============================================================================
class SpriteBatch {
public:
    SpriteBatch() = default;
    ~SpriteBatch();

    SpriteBatch(const SpriteBatch&) = delete;
    SpriteBatch& operator=(const SpriteBatch&) = delete;

    bool Initialize();
    void Shutdown();

    // ==============================================================================
    // Frame lifecycle
    // ==============================================================================
    void Begin(const Camera2D& camera);
    void Begin(const Matrix4& viewProjection);
    void End();
    void Flush();   // Force submit current batch

    // ==============================================================================
    // Draw calls (call between Begin/End)
    // ==============================================================================

    // Draw textured quad
    void DrawSprite(const DrawSpriteParams& params);

    // Convenience overloads
    void DrawSprite(const Vector2& pos, const Vector2& size,
                    std::shared_ptr<Texture2D> texture,
                    const Color& tint = Color::White(),
                    float rotation = 0.0f);

    // Draw solid color quad
    void DrawQuad(const Vector2& pos, const Vector2& size,
                  const Color& color, float rotation = 0.0f);

    // Draw from sub-texture (atlas region)
    void DrawSubTexture(const Vector2& pos, const Vector2& size,
                        const SubTexture& sub,
                        const Color& tint = Color::White(),
                        float rotation = 0.0f);

    // Draw at transform
    void DrawSprite(const Transform2D& transform, const Vector2& size,
                    std::shared_ptr<Texture2D> texture,
                    const Color& tint = Color::White());

    // ==============================================================================
    // Debug/utility draws
    // ==============================================================================
    void DrawLine    (const Vector2& a, const Vector2& b, const Color& color, float thickness = 1.0f);
    void DrawRect    (const Rect2D& rect, const Color& color, float thickness = 1.0f);
    void DrawRectFill(const Rect2D& rect, const Color& color);
    void DrawCircle  (const Vector2& center, float radius, const Color& color,
                      int segments = 32, float thickness = 1.0f);

    // ==============================================================================
    // Stats
    // ==============================================================================
    const RenderStats& GetStats() const { return m_stats; }
    void               ResetStats()     { m_stats.Reset(); }

    bool IsInitialized() const { return m_initialized; }

private:
    void StartBatch();
    void NextBatch();

    float GetTextureSlot(const std::shared_ptr<Texture2D>& tex);

    void SubmitQuad(const Vector2 positions[4],
                    const float uvs[8],
                    const Color& color,
                    float texIndex,
                    float tilingFactor);

    // GPU objects
    GLuint m_vao          = 0;
    GLuint m_vbo          = 0;
    GLuint m_ibo          = 0;

    // CPU-side vertex buffer
    SpriteVertex* m_vertexBuffer     = nullptr;
    SpriteVertex* m_vertexBufferPtr  = nullptr;
    uint32_t      m_indexCount       = 0;

    // Texture slots
    std::array<std::shared_ptr<Texture2D>, SPRITE_BATCH_MAX_TEXTURES> m_textureSlots;
    uint32_t      m_textureSlotIndex = 1;  // Slot 0 = white texture

    // Shader
    Shader*       m_shader           = nullptr;

    // State
    Matrix4       m_viewProjection;
    bool          m_inBatch          = false;
    bool          m_initialized      = false;

    // Stats
    RenderStats   m_stats;

    // Unit quad corner offsets (before transform)
    static constexpr float QUAD_POSITIONS[8] = {
        -0.5f, -0.5f,
         0.5f, -0.5f,
         0.5f,  0.5f,
        -0.5f,  0.5f
    };
    // ---- Convenience overloads used by UIRenderer (float-based) ----
    void DrawQuad(float x, float y, float w, float h,
                  Texture2D* tex, const Color& color = Color::White()) {
        if (tex)
            DrawSubTexture({x,y},{w,h}, tex, Rect2D{0,0,1,1}, color);
        else
            DrawQuad({x,y},{w,h}, color, 0.0f);
    }
    void DrawQuadUV(float x, float y, float w, float h,
                    Texture2D* texture, const Color& tint,
                    float u0, float v0, float u1, float v1) {
        Rect2D uv{u0, v0, u1-u0, v1-v0};
        DrawSubTexture({x,y}, {w,h}, texture, uv, tint);
    }
    void DrawLine(float x0, float y0, float x1, float y1,
                  const Color& color, float thickness = 1.0f) {
        DrawLine({x0,y0}, {x1,y1}, color, thickness);
    }
    // Scissor clip (no-op stub — real impl sets GL scissor)
    void SetScissor   (int x, int y, int w, int h) { (void)x;(void)y;(void)w;(void)h; }
    void ClearScissor ()                            {}

};

} // namespace BADGE2D
