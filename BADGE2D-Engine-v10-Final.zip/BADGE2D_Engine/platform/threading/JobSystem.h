#pragma once
// ==============================================================================
// JobSystem.h — Thread pool and task/job scheduling
// ==============================================================================

#include <functional>
#include <vector>
#include <queue>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <future>
#include <memory>
#include <cstdint>

namespace BADGE2D {

// ==============================================================================
// Job — A unit of work
// ==============================================================================
using JobFn = std::function<void()>;

struct Job {
    JobFn        fn;
    int          priority  = 0;   // Higher = more important
    std::string  debugName;

    bool operator<(const Job& o) const { return priority < o.priority; }
};

// ==============================================================================
// ThreadPool — Fixed worker thread pool
// ==============================================================================
class ThreadPool {
public:
    explicit ThreadPool(size_t threadCount = 0);
    ~ThreadPool();

    // Submit a job. Returns a future to query completion.
    template<typename F, typename... Args>
    auto Submit(F&& fn, Args&&... args)
        -> std::future<std::invoke_result_t<F, Args...>>
    {
        using RetT = std::invoke_result_t<F, Args...>;
        auto task  = std::make_shared<std::packaged_task<RetT()>>(
            std::bind(std::forward<F>(fn), std::forward<Args>(args)...)
        );
        std::future<RetT> fut = task->get_future();
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            if (m_stopping) throw std::runtime_error("ThreadPool is stopped");
            m_queue.push([task]{ (*task)(); });
        }
        m_cv.notify_one();
        return fut;
    }

    // Fire-and-forget
    void Enqueue(JobFn fn);

    // Wait for all pending jobs to complete
    void WaitAll();

    size_t GetThreadCount()   const { return m_threads.size(); }
    size_t GetPendingCount()  const {
        std::lock_guard<std::mutex> lock(m_mutex);
        return m_queue.size();
    }

    static size_t GetHardwareConcurrency() {
        return std::thread::hardware_concurrency();
    }

private:
    void WorkerLoop();

    std::vector<std::thread>   m_threads;
    std::queue<JobFn>          m_queue;
    mutable std::mutex         m_mutex;
    std::condition_variable    m_cv;
    std::condition_variable    m_finishedCv;
    std::atomic<bool>          m_stopping     {false};
    std::atomic<int>           m_activeJobs   {0};
};

// ==============================================================================
// JobSystem — High-level job system singleton
// Wraps ThreadPool with named job groups and dependencies
// ==============================================================================
class JobSystem {
public:
    static JobSystem& Get();

    void Initialize(size_t threadCount = 0);
    void Shutdown();

    // Submit a named background job
    void Submit(const std::string& name, JobFn fn, int priority = 0);

    // Schedule a job that runs on the main thread (next frame)
    void SubmitMainThread(JobFn fn);

    // Flush main-thread queue (call from main loop)
    void FlushMainThread();

    // Wait for all background jobs
    void WaitAll();

    size_t GetWorkerCount() const;

private:
    JobSystem() = default;

    std::unique_ptr<ThreadPool>  m_pool;
    std::queue<JobFn>            m_mainQueue;
    mutable std::mutex           m_mainMutex;
    bool                         m_initialized = false;
};

} // namespace BADGE2D
