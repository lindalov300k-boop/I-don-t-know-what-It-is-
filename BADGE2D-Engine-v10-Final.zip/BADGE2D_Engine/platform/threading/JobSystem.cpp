// ==============================================================================
// JobSystem.cpp — ThreadPool and JobSystem implementation
// ==============================================================================

#include "JobSystem.h"
#include "../../engine/Logging/Logger.h"
#include <cassert>

namespace BADGE2D {

// ==============================================================================
// ThreadPool
// ==============================================================================
ThreadPool::ThreadPool(size_t threadCount) {
    if (threadCount == 0)
        threadCount = std::max(1u, std::thread::hardware_concurrency() - 1);

    m_threads.reserve(threadCount);
    for (size_t i = 0; i < threadCount; ++i)
        m_threads.emplace_back(&ThreadPool::WorkerLoop, this);

    LOG_INFOF("[ThreadPool] Started %zu worker thread(s).", threadCount);
}

ThreadPool::~ThreadPool() {
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        m_stopping = true;
    }
    m_cv.notify_all();
    for (auto& t : m_threads)
        if (t.joinable()) t.join();
}

void ThreadPool::Enqueue(JobFn fn) {
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (m_stopping) return;
        m_queue.push(std::move(fn));
    }
    m_cv.notify_one();
}

void ThreadPool::WaitAll() {
    std::unique_lock<std::mutex> lock(m_mutex);
    m_finishedCv.wait(lock, [this]{
        return m_queue.empty() && m_activeJobs.load() == 0;
    });
}

void ThreadPool::WorkerLoop() {
    while (true) {
        JobFn job;
        {
            std::unique_lock<std::mutex> lock(m_mutex);
            m_cv.wait(lock, [this]{
                return !m_queue.empty() || m_stopping.load();
            });
            if (m_stopping && m_queue.empty()) return;
            if (m_queue.empty()) continue;
            job = std::move(m_queue.front());
            m_queue.pop();
            ++m_activeJobs;
        }

        job();
        --m_activeJobs;

        {
            std::lock_guard<std::mutex> lock(m_mutex);
            if (m_queue.empty() && m_activeJobs.load() == 0)
                m_finishedCv.notify_all();
        }
    }
}

// ==============================================================================
// JobSystem
// ==============================================================================
JobSystem& JobSystem::Get() {
    static JobSystem instance;
    return instance;
}

void JobSystem::Initialize(size_t threadCount) {
    if (m_initialized) return;
    m_pool = std::make_unique<ThreadPool>(threadCount);
    m_initialized = true;
    LOG_INFOF("[JobSystem] Initialized with %zu worker threads.", m_pool->GetThreadCount());
}

void JobSystem::Shutdown() {
    if (!m_initialized) return;
    WaitAll();
    m_pool.reset();
    m_initialized = false;
    LOG_INFO("[JobSystem] Shut down.");
}

void JobSystem::Submit(const std::string& name, JobFn fn, int /*priority*/) {
    assert(m_initialized && "JobSystem not initialized");
    m_pool->Enqueue([name, fn = std::move(fn)]{
        fn();
    });
}

void JobSystem::SubmitMainThread(JobFn fn) {
    std::lock_guard<std::mutex> lock(m_mainMutex);
    m_mainQueue.push(std::move(fn));
}

void JobSystem::FlushMainThread() {
    std::queue<JobFn> toRun;
    {
        std::lock_guard<std::mutex> lock(m_mainMutex);
        toRun.swap(m_mainQueue);
    }
    while (!toRun.empty()) {
        toRun.front()();
        toRun.pop();
    }
}

void JobSystem::WaitAll() {
    if (m_pool) m_pool->WaitAll();
}

size_t JobSystem::GetWorkerCount() const {
    return m_pool ? m_pool->GetThreadCount() : 0;
}

} // namespace BADGE2D
