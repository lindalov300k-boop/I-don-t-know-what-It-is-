// ==============================================================================
// FileSystem.cpp — Cross-platform file system implementation
// ==============================================================================

#include "FileSystem.h"
#include <fstream>
#include <sstream>
#include <filesystem>
#include <algorithm>
#include <cstdio>

namespace fs = std::filesystem;

namespace BADGE2D {

// ==============================================================================
// Read/Write
// ==============================================================================
FileResult FileSystem::ReadFile(const std::string& path) {
    FileResult result;
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    if (!file.is_open()) {
        result.errorMsg = "Could not open file: " + path;
        return result;
    }
    std::streamsize size = file.tellg();
    file.seekg(0, std::ios::beg);
    result.data.resize(static_cast<size_t>(size));
    if (!file.read(reinterpret_cast<char*>(result.data.data()), size)) {
        result.errorMsg = "Failed to read file: " + path;
        return result;
    }
    result.success = true;
    return result;
}

std::string FileSystem::ReadTextFile(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) return {};
    std::ostringstream ss;
    ss << file.rdbuf();
    return ss.str();
}

bool FileSystem::WriteFile(const std::string& path, const void* data, size_t size) {
    std::ofstream file(path, std::ios::binary);
    if (!file.is_open()) return false;
    file.write(static_cast<const char*>(data), static_cast<std::streamsize>(size));
    return file.good();
}

bool FileSystem::WriteTextFile(const std::string& path, const std::string& text) {
    std::ofstream file(path);
    if (!file.is_open()) return false;
    file << text;
    return file.good();
}

bool FileSystem::AppendTextFile(const std::string& path, const std::string& text) {
    std::ofstream file(path, std::ios::app);
    if (!file.is_open()) return false;
    file << text;
    return file.good();
}

// ==============================================================================
// Existence / Info
// ==============================================================================
bool FileSystem::Exists(const std::string& path) {
    return fs::exists(path);
}

bool FileSystem::IsFile(const std::string& path) {
    return fs::is_regular_file(path);
}

bool FileSystem::IsDirectory(const std::string& path) {
    return fs::is_directory(path);
}

std::optional<FileInfo> FileSystem::GetInfo(const std::string& path) {
    if (!fs::exists(path)) return std::nullopt;
    FileInfo info;
    info.path      = path;
    info.name      = GetFileName(path);
    info.extension = GetExtension(path);
    info.isDir     = fs::is_directory(path);
    if (!info.isDir) {
        std::error_code ec;
        info.sizeBytes = fs::file_size(path, ec);
    }
    auto lwt = fs::last_write_time(path);
    info.modifiedAt = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::seconds>(
            lwt.time_since_epoch()).count());
    return info;
}

// ==============================================================================
// Paths
// ==============================================================================
std::string FileSystem::GetExtension(const std::string& path) {
    return fs::path(path).extension().string();
}

std::string FileSystem::GetFileName(const std::string& path) {
    return fs::path(path).filename().string();
}

std::string FileSystem::GetFileNameNoExt(const std::string& path) {
    return fs::path(path).stem().string();
}

std::string FileSystem::GetDirectory(const std::string& path) {
    return fs::path(path).parent_path().string();
}

std::string FileSystem::JoinPath(const std::string& a, const std::string& b) {
    return (fs::path(a) / b).string();
}

std::string FileSystem::NormalizePath(const std::string& path) {
    std::error_code ec;
    fs::path p = fs::weakly_canonical(path, ec);
    return ec ? path : p.string();
}

std::string FileSystem::GetAbsolutePath(const std::string& path) {
    return fs::absolute(path).string();
}

// ==============================================================================
// Directory operations
// ==============================================================================
bool FileSystem::CreateDirectory(const std::string& path) {
    std::error_code ec;
    return fs::create_directories(path, ec);
}

bool FileSystem::DeleteFile(const std::string& path) {
    std::error_code ec;
    return fs::remove(path, ec);
}

bool FileSystem::CopyFile(const std::string& src, const std::string& dst) {
    std::error_code ec;
    return fs::copy_file(src, dst, fs::copy_options::overwrite_existing, ec);
}

bool FileSystem::MoveFile(const std::string& src, const std::string& dst) {
    std::error_code ec;
    fs::rename(src, dst, ec);
    return !ec;
}

// ==============================================================================
// Listing
// ==============================================================================
std::vector<FileInfo> FileSystem::ListDirectory(const std::string& dir, bool recursive) {
    std::vector<FileInfo> result;
    if (!fs::exists(dir)) return result;

    auto iterate = [&](auto& it) {
        for (auto& entry : it) {
            if (auto info = GetInfo(entry.path().string()))
                result.push_back(*info);
        }
    };

    if (recursive) {
        fs::recursive_directory_iterator it(dir);
        iterate(it);
    } else {
        fs::directory_iterator it(dir);
        iterate(it);
    }
    return result;
}

std::vector<std::string> FileSystem::FindFiles(const std::string& dir,
                                                 const std::string& ext,
                                                 bool recursive) {
    std::vector<std::string> result;
    auto files = ListDirectory(dir, recursive);
    for (auto& f : files) {
        if (!f.isDir && f.extension == ext)
            result.push_back(f.path);
    }
    return result;
}

// ==============================================================================
// Working directory / Executable
// ==============================================================================
std::string FileSystem::GetWorkingDirectory() {
    return fs::current_path().string();
}

bool FileSystem::SetWorkingDirectory(const std::string& path) {
    std::error_code ec;
    fs::current_path(path, ec);
    return !ec;
}

std::string FileSystem::GetExecutablePath() {
#if defined(_WIN32)
    char buf[4096];
    DWORD len = GetModuleFileNameA(nullptr, buf, sizeof(buf));
    return (len > 0) ? std::string(buf, len) : "";
#elif defined(__linux__)
    char buf[4096] = {};
    ssize_t len = readlink("/proc/self/exe", buf, sizeof(buf)-1);
    return (len > 0) ? std::string(buf, len) : "";
#elif defined(__APPLE__)
    char buf[4096] = {};
    uint32_t size = sizeof(buf);
    _NSGetExecutablePath(buf, &size);
    return buf;
#else
    return "";
#endif
}

std::string FileSystem::GetExecutableDir() {
    return GetDirectory(GetExecutablePath());
}

} // namespace BADGE2D
