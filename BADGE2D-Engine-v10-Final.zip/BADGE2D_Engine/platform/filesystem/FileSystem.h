#pragma once
// ==============================================================================
// FileSystem.h — Cross-platform file system abstraction
// ==============================================================================

#include <string>
#include <vector>
#include <cstdint>
#include <functional>
#include <optional>

namespace BADGE2D {

// ==============================================================================
// FileResult — Holds raw file bytes
// ==============================================================================
struct FileResult {
    std::vector<uint8_t> data;
    bool success = false;
    std::string errorMsg;

    std::string AsString() const {
        return std::string(reinterpret_cast<const char*>(data.data()), data.size());
    }
};

// ==============================================================================
// FileInfo — Metadata about a file or directory
// ==============================================================================
struct FileInfo {
    std::string path;
    std::string name;
    std::string extension;
    size_t      sizeBytes  = 0;
    bool        isDir      = false;
    uint64_t    modifiedAt = 0;  // Unix timestamp
};

// ==============================================================================
// FileSystem — Static utility class
// ==============================================================================
class FileSystem {
public:
    // Read/Write
    static FileResult   ReadFile       (const std::string& path);
    static std::string  ReadTextFile   (const std::string& path);
    static bool         WriteFile      (const std::string& path, const void* data, size_t size);
    static bool         WriteTextFile  (const std::string& path, const std::string& text);
    static bool         AppendTextFile (const std::string& path, const std::string& text);

    // Existence / info
    static bool         Exists         (const std::string& path);
    static bool         IsFile         (const std::string& path);
    static bool         IsDirectory    (const std::string& path);
    static std::optional<FileInfo> GetInfo(const std::string& path);

    // Paths
    static std::string  GetExtension   (const std::string& path);
    static std::string  GetFileName    (const std::string& path);
    static std::string  GetFileNameNoExt(const std::string& path);
    static std::string  GetDirectory   (const std::string& path);
    static std::string  JoinPath       (const std::string& a, const std::string& b);
    static std::string  NormalizePath  (const std::string& path);
    static std::string  GetAbsolutePath(const std::string& path);

    // Directory operations
    static bool         CreateDirectory(const std::string& path);
    static bool         DeleteFile     (const std::string& path);
    static bool         CopyFile       (const std::string& src, const std::string& dst);
    static bool         MoveFile       (const std::string& src, const std::string& dst);

    // Listing
    static std::vector<FileInfo> ListDirectory  (const std::string& dir, bool recursive = false);
    static std::vector<std::string> FindFiles   (const std::string& dir,
                                                  const std::string& ext,
                                                  bool recursive = false);

    // Working directory
    static std::string  GetWorkingDirectory();
    static bool         SetWorkingDirectory(const std::string& path);

    // Executable
    static std::string  GetExecutablePath();
    static std::string  GetExecutableDir();
};

} // namespace BADGE2D
