#pragma once
// ==============================================================================
// SceneManager.h — Scene lifecycle manager: load, unload, transition, additive.
// Supports synchronous and asynchronous loading with progress callbacks.
// ==============================================================================

#include "Scene.h"
#include "../SceneTypes.h"
#include "../../engine/ModuleSystem/ModuleInterface.h"
#include <unordered_map>
#include <vector>
#include <memory>
#include <string>
#include <functional>
#include <future>
#include <queue>

namespace BADGE2D {

// ==============================================================================
// SceneTransition — Animation between scenes
// ==============================================================================
enum class TransitionType {
    None,
    Fade,
    Crossfade,
    Slide
};

struct SceneTransitionConfig {
    TransitionType type     = TransitionType::Fade;
    float          duration = 0.4f;
    float          r = 0, g = 0, b = 0;  // Fade colour
};

// ==============================================================================
// SceneLoadRequest — Queued load operation
// ==============================================================================
struct SceneLoadRequest {
    std::string  sceneName;
    LoadMode     mode       = LoadMode::Single;
    SceneTransitionConfig transition;
    std::function<void(Scene*)> onLoaded;
};

// ==============================================================================
// SceneManager
// ==============================================================================
class SceneManager : public IModule {
public:
    // IModule
    bool        Initialize()          override;
    void        Shutdown  ()          override;
    void        Update    (double dt) override;
    void        FixedUpdate(double dt)override;
    void        Render    ()          override;
    const char* GetName   ()    const override { return "SceneManager"; }
    uint32_t    GetInitOrder() const  override { return (uint32_t)ModuleInitOrder::Scene; }

    static SceneManager& Get();

    // ==============================================================================
    // Scene registration
    // ==============================================================================
    // Register a scene by name + settings (does NOT load it)
    void RegisterScene(SceneSettings settings);

    // Register with a factory lambda (called when the scene needs to be populated)
    void RegisterScene(const std::string& name, const std::string& filePath,
                       std::function<void(Scene&)> populateCallback = nullptr);

    // ==============================================================================
    // Loading
    // ==============================================================================
    // Synchronous load
    Scene* LoadScene(const std::string& name,
                     LoadMode mode = LoadMode::Single,
                     const SceneTransitionConfig& transition = {});

    // Asynchronous load — returns immediately, calls onLoaded on completion
    void   LoadSceneAsync(const std::string& name,
                          LoadMode mode = LoadMode::Single,
                          std::function<void(Scene*)> onLoaded = nullptr,
                          const SceneTransitionConfig& transition = {});

    void   UnloadScene(const std::string& name);
    void   UnloadScene(SceneID id);

    // Unload all except the named scene
    void   UnloadAllExcept(const std::string& name);

    // ==============================================================================
    // Access
    // ==============================================================================
    Scene*         GetActiveScene()                 const;
    Scene*         GetScene(const std::string& name)const;
    Scene*         GetScene(SceneID id)             const;
    bool           IsLoaded(const std::string& name)const;
    int            GetLoadedCount()                 const { return (int)m_loaded.size(); }
    const std::vector<Scene*>& GetAllLoaded()       const { return m_loadedList; }

    // ==============================================================================
    // Transition state
    // ==============================================================================
    bool  IsTransitioning()    const { return m_transitioning; }
    float GetTransitionProgress() const;

    // ==============================================================================
    // Callbacks
    // ==============================================================================
    std::function<void(Scene*)>               OnSceneLoaded;
    std::function<void(const std::string&)>   OnSceneUnloaded;
    std::function<void(Scene*, Scene*)>        OnSceneChanged;  // (old, new)

private:
    SceneManager() = default;

    void ExecuteLoad   (const SceneLoadRequest& req);
    void ProcessQueue  ();
    void UpdateTransition(double dt);
    void RenderTransition();

    SceneID NextSceneID() { return ++m_nextID; }

    struct RegisteredScene {
        SceneSettings                    settings;
        std::function<void(Scene&)>      populate;
    };

    std::unordered_map<std::string, RegisteredScene>   m_registry;
    std::unordered_map<SceneID,     std::unique_ptr<Scene>> m_loaded;
    std::vector<Scene*>                                m_loadedList;
    Scene*                                             m_activeScene = nullptr;

    std::queue<SceneLoadRequest>  m_loadQueue;
    std::future<void>             m_asyncFuture;

    // Transition state
    bool      m_transitioning    = false;
    float     m_transitionTime   = 0.0f;
    float     m_transitionDur    = 0.0f;
    bool      m_transitionHalfway= false;
    SceneTransitionConfig m_currentTransition;
    SceneLoadRequest      m_pendingLoad;
    bool                  m_hasPendingLoad = false;

    SceneID  m_nextID = 0;
    bool     m_initialized = false;
};

} // namespace BADGE2D
