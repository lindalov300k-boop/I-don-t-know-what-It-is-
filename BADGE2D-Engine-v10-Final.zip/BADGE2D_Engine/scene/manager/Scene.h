#pragma once
// ==============================================================================
// Scene.h — A self-contained scene: ECS World + PhysicsWorld + settings
// Scenes are loaded/unloaded by SceneManager.
// ==============================================================================

#include "../SceneTypes.h"
#include "../../ecs/system/World.h"
#include "../../physics/world/PhysicsWorld.h"
#include "../../renderer/camera/Camera2D.h"
#include <string>
#include <memory>
#include <functional>
#include <vector>

namespace BADGE2D {

// ==============================================================================
// Scene
// ==============================================================================
class Scene {
public:
    explicit Scene(SceneSettings settings);
    ~Scene();

    // ---- Lifecycle (called by SceneManager) ----
    void OnLoad   ();   // Allocate, run OnEnter callbacks
    void OnUnload ();   // Cleanup, run OnExit callbacks
    void OnUpdate (double dt);
    void OnFixedUpdate(double dt);
    void OnRender ();
    void OnPause  ();
    void OnResume ();

    // ---- Entity API (thin delegation to m_world) ----
    EntityID     CreateEntity (const std::string& name = "Entity");
    void         DestroyEntity(EntityID id);
    EntityID     FindByName   (const std::string& name) const;
    EntityID     FindByTag    (const std::string& tag)  const;
    std::vector<EntityID> FindAllByTag(const std::string& tag) const;

    template<typename T>
    T* AddComponent(EntityID e, T comp)    { return m_world->AddComponent(e, std::move(comp)); }
    template<typename T>
    T* GetComponent(EntityID e)            { return m_world->TryGetComponent<T>(e); }
    template<typename T>
    void RemoveComponent(EntityID e)       { m_world->RemoveComponent<T>(e); }

    template<typename T, typename... Args>
    T* AddSystem(Args&&... args)           { return m_world->AddSystem<T>(std::forward<Args>(args)...); }

    // ---- Access ----
    World&              GetWorld()    { return *m_world;   }
    PhysicsWorld&       GetPhysics()  { return *m_physics; }
    Camera2D&           GetCamera()   { return m_camera;   }
    const SceneSettings& GetSettings()const { return m_settings; }
    SceneID              GetID()       const { return m_settings.id; }
    const std::string&   GetName()     const { return m_settings.name; }
    SceneState           GetState()    const { return m_state; }
    bool                 IsActive()    const { return m_state == SceneState::Active; }

    // ---- Callbacks ----
    std::function<void()>          OnEnter;
    std::function<void()>          OnExit;
    std::function<void(double)>    OnTick;   // Called in addition to system updates

private:
    SceneSettings               m_settings;
    SceneState                  m_state   = SceneState::Unloaded;

    std::unique_ptr<World>          m_world;
    std::unique_ptr<PhysicsWorld>   m_physics;
    Camera2D                        m_camera;
};

} // namespace BADGE2D
