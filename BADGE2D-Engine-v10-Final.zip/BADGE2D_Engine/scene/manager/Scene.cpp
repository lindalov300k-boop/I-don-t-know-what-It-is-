// ==============================================================================
// Scene.cpp
// ==============================================================================

#include "Scene.h"
#include "../../physics/world/PhysicsSystem.h"
#include "../../animation/Animator.h"
#include "../../engine/Logging/Logger.h"

namespace BADGE2D {

Scene::Scene(SceneSettings settings)
    : m_settings(std::move(settings))
{
    m_world   = std::make_unique<World>();
    PhysicsWorldConfig pcfg;
    pcfg.gravity = Vector2{ m_settings.gravityX, m_settings.gravityY };
    m_physics = std::make_unique<PhysicsWorld>(pcfg);
    m_camera.SetPosition({ m_settings.camX, m_settings.camY });
    m_camera.SetZoom(m_settings.camZoom);
}

Scene::~Scene() {
    OnUnload();
}

void Scene::OnLoad() {
    m_state = SceneState::Loading;

    m_physics->Initialize();

    // Register default systems
    m_world->AddSystem<PhysicsSystem>(m_physics.get());
    m_world->AddSystem<AnimatorSystem>();

    m_state = SceneState::Active;
    LOG_INFOF("[Scene] Loaded: '%s'", m_settings.name.c_str());

    if (OnEnter) OnEnter();
}

void Scene::OnUnload() {
    if (m_state == SceneState::Unloaded) return;
    if (OnExit) OnExit();
    m_physics->Shutdown();
    m_state = SceneState::Unloaded;
    LOG_INFOF("[Scene] Unloaded: '%s'", m_settings.name.c_str());
}

void Scene::OnUpdate(double dt) {
    if (m_state != SceneState::Active) return;
    if (OnTick) OnTick(dt);
    m_world->UpdateSystems(dt);
}

void Scene::OnFixedUpdate(double dt) {
    if (m_state != SceneState::Active) return;
    m_world->FixedUpdateSystems(dt);
}

void Scene::OnRender() {
    if (m_state == SceneState::Unloaded) return;
    // Renderer reads from ECS SpriteComponent — no explicit call needed here.
    // Future: culling pass, layer sorting.
}

void Scene::OnPause()  {
    if (m_state == SceneState::Active) m_state = SceneState::Paused;
}
void Scene::OnResume() {
    if (m_state == SceneState::Paused)  m_state = SceneState::Active;
}

// ==============================================================================
// Entity helpers
// ==============================================================================
EntityID Scene::CreateEntity(const std::string& name) {
    EntityID id = m_world->CreateEntity();
    NameComponent nc; nc.name = name;
    m_world->AddComponent(id, std::move(nc));
    return id;
}

void Scene::DestroyEntity(EntityID id) {
    m_world->DestroyEntity(id);
    // Also remove physics body if any
}

EntityID Scene::FindByName(const std::string& name) const {
    EntityID found = INVALID_ENTITY;
    m_world->Each<NameComponent>([&](EntityID id, NameComponent& nc) {
        if (found == INVALID_ENTITY && nc.name == name) found = id;
    });
    return found;
}

EntityID Scene::FindByTag(const std::string& tag) const {
    EntityID found = INVALID_ENTITY;
    m_world->Each<TagComponent>([&](EntityID id, TagComponent& tc) {
        if (found == INVALID_ENTITY && tc.tag == tag) found = id;
    });
    return found;
}

std::vector<EntityID> Scene::FindAllByTag(const std::string& tag) const {
    std::vector<EntityID> result;
    m_world->Each<TagComponent>([&](EntityID id, TagComponent& tc) {
        if (tc.tag == tag) result.push_back(id);
    });
    return result;
}

} // namespace BADGE2D
