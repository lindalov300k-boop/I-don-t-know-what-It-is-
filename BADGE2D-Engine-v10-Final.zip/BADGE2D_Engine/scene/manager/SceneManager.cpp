// ==============================================================================
// SceneManager.cpp
// ==============================================================================

#include "SceneManager.h"
#include "../../utilities/Math/MathUtils.h"
#include "../../engine/Logging/Logger.h"
#include "../../renderer/core/Renderer2D.h"

#include <algorithm>
#include <stdexcept>

namespace BADGE2D {

SceneManager& SceneManager::Get() {
    static SceneManager instance;
    return instance;
}

bool SceneManager::Initialize() {
    if (m_initialized) return true;
    m_initialized = true;
    LOG_INFO("[SceneManager] Initialized.");
    return true;
}

void SceneManager::Shutdown() {
    if (!m_initialized) return;
    for (auto& [id, scene] : m_loaded) scene->OnUnload();
    m_loaded.clear();
    m_loadedList.clear();
    m_activeScene = nullptr;
    m_initialized = false;
    LOG_INFO("[SceneManager] Shutdown.");
}

// ==============================================================================
// Registration
// ==============================================================================
void SceneManager::RegisterScene(SceneSettings settings) {
    settings.id = NextSceneID();
    RegisteredScene rs;
    rs.settings = std::move(settings);
    m_registry[rs.settings.name] = std::move(rs);
    LOG_DEBUGF("[SceneManager] Registered scene: '%s'", rs.settings.name.c_str());
}

void SceneManager::RegisterScene(const std::string& name, const std::string& filePath,
                                   std::function<void(Scene&)> populate) {
    SceneSettings s;
    s.name     = name;
    s.filePath = filePath;
    s.id       = NextSceneID();
    RegisteredScene rs;
    rs.settings  = std::move(s);
    rs.populate  = std::move(populate);
    m_registry[name] = std::move(rs);
}

// ==============================================================================
// LoadScene — synchronous
// ==============================================================================
Scene* SceneManager::LoadScene(const std::string& name, LoadMode mode,
                                  const SceneTransitionConfig& transition) {
    auto regIt = m_registry.find(name);
    if (regIt == m_registry.end()) {
        LOG_ERRORF("[SceneManager] Scene not registered: '%s'", name.c_str());
        return nullptr;
    }

    if (transition.type != TransitionType::None && transition.duration > 0) {
        // Defer load until fade midpoint
        m_currentTransition  = transition;
        m_transitionTime     = 0.0f;
        m_transitionDur      = transition.duration;
        m_transitioning      = true;
        m_transitionHalfway  = false;
        m_hasPendingLoad     = true;
        m_pendingLoad        = { name, mode, transition, nullptr };
        return nullptr;  // Will complete via UpdateTransition
    }

    // Immediate load
    SceneLoadRequest req{ name, mode, transition, nullptr };
    ExecuteLoad(req);
    return m_activeScene;
}

void SceneManager::LoadSceneAsync(const std::string& name, LoadMode mode,
                                    std::function<void(Scene*)> onLoaded,
                                    const SceneTransitionConfig& transition) {
    m_loadQueue.push({ name, mode, transition, std::move(onLoaded) });
}

void SceneManager::ExecuteLoad(const SceneLoadRequest& req) {
    auto regIt = m_registry.find(req.sceneName);
    if (regIt == m_registry.end()) return;

    const RegisteredScene& reg = regIt->second;
    Scene* previous = m_activeScene;

    if (req.mode == LoadMode::Single) {
        // Unload all current scenes
        for (auto& [id, scene] : m_loaded) scene->OnUnload();
        m_loaded.clear();
        m_loadedList.clear();
        m_activeScene = nullptr;
    }

    // Create + load
    auto scene    = std::make_unique<Scene>(reg.settings);
    Scene* rawPtr = scene.get();
    SceneID id    = reg.settings.id;

    scene->OnLoad();

    // Populate via callback or serializer
    if (reg.populate) reg.populate(*rawPtr);

    m_loaded[id]  = std::move(scene);
    m_loadedList.push_back(rawPtr);
    m_activeScene = rawPtr;

    LOG_INFOF("[SceneManager] Scene loaded: '%s'", req.sceneName.c_str());

    if (OnSceneLoaded)  OnSceneLoaded(rawPtr);
    if (OnSceneChanged) OnSceneChanged(previous, rawPtr);
    if (req.onLoaded)   req.onLoaded(rawPtr);
}

// ==============================================================================
// UnloadScene
// ==============================================================================
void SceneManager::UnloadScene(const std::string& name) {
    Scene* s = GetScene(name);
    if (!s) return;
    UnloadScene(s->GetID());
}

void SceneManager::UnloadScene(SceneID id) {
    auto it = m_loaded.find(id);
    if (it == m_loaded.end()) return;

    it->second->OnUnload();
    std::string name = it->second->GetName();
    m_loadedList.erase(std::remove(m_loadedList.begin(), m_loadedList.end(), it->second.get()),
                        m_loadedList.end());
    if (m_activeScene == it->second.get()) m_activeScene = nullptr;
    m_loaded.erase(it);

    if (!m_loadedList.empty()) m_activeScene = m_loadedList.back();
    if (OnSceneUnloaded) OnSceneUnloaded(name);
    LOG_INFOF("[SceneManager] Unloaded scene: '%s'", name.c_str());
}

void SceneManager::UnloadAllExcept(const std::string& name) {
    std::vector<SceneID> toUnload;
    for (auto& [id, scene] : m_loaded)
        if (scene->GetName() != name) toUnload.push_back(id);
    for (SceneID id : toUnload) UnloadScene(id);
}

// ==============================================================================
// Access
// ==============================================================================
Scene* SceneManager::GetActiveScene() const { return m_activeScene; }

Scene* SceneManager::GetScene(const std::string& name) const {
    for (auto& [id, scene] : m_loaded)
        if (scene->GetName() == name) return scene.get();
    return nullptr;
}

Scene* SceneManager::GetScene(SceneID id) const {
    auto it = m_loaded.find(id);
    return (it != m_loaded.end()) ? it->second.get() : nullptr;
}

bool SceneManager::IsLoaded(const std::string& name) const {
    return GetScene(name) != nullptr;
}

float SceneManager::GetTransitionProgress() const {
    if (!m_transitioning || m_transitionDur <= 0) return 1.0f;
    return m_transitionTime / m_transitionDur;
}

// ==============================================================================
// Update
// ==============================================================================
void SceneManager::Update(double dt) {
    ProcessQueue();

    if (m_transitioning) {
        UpdateTransition(dt);
        return;
    }

    for (auto& scene : m_loadedList) scene->OnUpdate(dt);
}

void SceneManager::FixedUpdate(double dt) {
    for (auto& scene : m_loadedList)
        if (scene->IsActive()) scene->OnFixedUpdate(dt);
}

void SceneManager::Render() {
    for (auto& scene : m_loadedList) scene->OnRender();
    if (m_transitioning) RenderTransition();
}

// ==============================================================================
// Transition
// ==============================================================================
void SceneManager::UpdateTransition(double dt) {
    m_transitionTime += (float)dt;
    float half = m_transitionDur * 0.5f;

    // Halfway: execute scene swap
    if (!m_transitionHalfway && m_transitionTime >= half && m_hasPendingLoad) {
        m_transitionHalfway = true;
        ExecuteLoad(m_pendingLoad);
        m_hasPendingLoad = false;
    }

    if (m_transitionTime >= m_transitionDur) {
        m_transitioning = false;
        m_transitionTime = 0.0f;
    }
}

void SceneManager::RenderTransition() {
    if (m_currentTransition.type == TransitionType::None) return;
    float progress = GetTransitionProgress();
    float half = m_transitionDur * 0.5f;
    float t    = (m_transitionTime <= half)
                 ? m_transitionTime / half
                 : 1.0f - ((m_transitionTime - half) / half);
    t = std::clamp(t, 0.0f, 1.0f);

    // Draw fullscreen fade quad
    Color fadeColor(m_currentTransition.r, m_currentTransition.g, m_currentTransition.b, t);
    // Renderer2D::Get().DrawFullscreenQuad(fadeColor); // Wire via callback
}

void SceneManager::ProcessQueue() {
    if (m_loadQueue.empty()) return;
    if (m_asyncFuture.valid() &&
        m_asyncFuture.wait_for(std::chrono::seconds(0)) != std::future_status::ready) return;

    auto req     = std::move(m_loadQueue.front());
    m_loadQueue.pop();
    auto callback = req.onLoaded;

    m_asyncFuture = std::async(std::launch::async, [this, req = std::move(req)]() mutable {
        ExecuteLoad(req);
    });
}

} // namespace BADGE2D
