#pragma once
// ==============================================================================
// SceneTypes.h — Shared scene system types
// ==============================================================================

#include <cstdint>
#include <string>
#include <vector>

namespace BADGE2D {

using SceneID  = uint32_t;
using LayerID  = uint32_t;
using TagID    = uint32_t;

constexpr SceneID INVALID_SCENE = 0;

// ==============================================================================
// SceneState
// ==============================================================================
enum class SceneState {
    Unloaded,
    Loading,
    Active,
    Paused,       // Update halted, rendered at reduced frequency
    Unloading
};

// ==============================================================================
// LoadMode — How the scene loads relative to the active scene
// ==============================================================================
enum class LoadMode {
    Single,       // Unload current scene, load new one
    Additive,     // Keep current scene, add new one alongside
    Replace       // Swap out one specific scene
};

// ==============================================================================
// LayerMask — Render/physics layer system (up to 32 layers)
// ==============================================================================
namespace Layer {
    constexpr uint32_t Default    = (1u << 0);
    constexpr uint32_t Background = (1u << 1);
    constexpr uint32_t Foreground = (1u << 2);
    constexpr uint32_t UI         = (1u << 3);
    constexpr uint32_t Ignored    = (1u << 4);
    constexpr uint32_t All        = 0xFFFFFFFF;

    inline std::string Name(LayerID id) {
        switch (id) {
            case 0:  return "Default";
            case 1:  return "Background";
            case 2:  return "Foreground";
            case 3:  return "UI";
            case 4:  return "Ignored";
            default: return "Layer" + std::to_string(id);
        }
    }
}

// ==============================================================================
// SceneSettings — Per-scene configuration
// ==============================================================================
struct SceneSettings {
    std::string name;
    std::string filePath;
    SceneID     id          = INVALID_SCENE;

    // Physics
    float       gravityX    =  0.0f;
    float       gravityY    = -980.0f;

    // Render
    float       ambientR    = 0.1f;
    float       ambientG    = 0.1f;
    float       ambientB    = 0.15f;
    float       ambientA    = 1.0f;

    // Camera
    float       camX        = 0.0f;
    float       camY        = 0.0f;
    float       camZoom     = 1.0f;

    bool        autoLoad    = false;  // Load on startup
};

} // namespace BADGE2D
