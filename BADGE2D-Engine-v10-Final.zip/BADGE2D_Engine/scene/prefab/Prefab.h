#pragma once
// ==============================================================================
// Prefab.h — Reusable entity templates (Prefabs)
// A Prefab is a JSON-serialized entity snapshot that can be instantiated
// into any Scene any number of times with optional property overrides.
// ==============================================================================

#include "../manager/Scene.h"
#include "../serialization/SceneSerializer.h"
#include "../../utilities/Math/Vector2.h"
#include <string>
#include <memory>
#include <functional>
#include <unordered_map>

namespace BADGE2D {

using PrefabID = uint32_t;
constexpr PrefabID INVALID_PREFAB = 0;

// ==============================================================================
// PrefabOverride — Property override when instantiating a prefab
// ==============================================================================
struct PrefabOverride {
    std::string  componentType;
    std::string  fieldName;
    std::string  value;   // String-encoded value
};

// ==============================================================================
// Prefab — Serialized entity template
// ==============================================================================
class Prefab {
public:
    explicit Prefab(PrefabID id, std::string name)
        : m_id(id), m_name(std::move(name)) {}

    PrefabID           GetID()   const { return m_id;   }
    const std::string& GetName() const { return m_name; }

    // Capture entity state into this prefab
    bool CaptureFrom(EntityID entity, const Scene& scene);

    // Instantiate into scene at a given position/rotation
    EntityID Instantiate(Scene& scene,
                          const Vector2& position = {},
                          float          rotation = 0.0f,
                          const std::vector<PrefabOverride>& overrides = {}) const;

    // Serialise/deserialise prefab definition
    std::string ToJson()            const;
    bool        FromJson(const std::string& json);
    bool        SaveToFile(const std::string& path) const;
    bool        LoadFromFile(const std::string& path);

    const std::string& GetJson() const { return m_json; }

private:
    PrefabID     m_id;
    std::string  m_name;
    std::string  m_json;  // Serialised entity JSON fragment
};

// ==============================================================================
// PrefabLibrary — Global named prefab registry
// ==============================================================================
class PrefabLibrary {
public:
    static PrefabLibrary& Get();

    // Register a prefab (from file or built from entity)
    PrefabID Register  (std::shared_ptr<Prefab> prefab);
    PrefabID Load      (const std::string& filepath);
    Prefab*  Find      (const std::string& name) const;
    Prefab*  Find      (PrefabID id)             const;
    void     Unregister(PrefabID id);

    // Capture a live entity as a new named prefab
    PrefabID CreateFromEntity(const std::string& name,
                               EntityID entity, const Scene& scene);

    // Instantiate shorthand
    EntityID Spawn(const std::string& prefabName,
                   Scene& scene,
                   const Vector2& position = {},
                   float          rotation = 0.0f) const;

    int GetCount() const { return (int)m_prefabs.size(); }

private:
    PrefabLibrary() = default;
    PrefabID NextID() { return ++m_nextID; }

    std::unordered_map<PrefabID,    std::shared_ptr<Prefab>> m_prefabs;
    std::unordered_map<std::string, PrefabID>                m_names;
    PrefabID m_nextID = 0;
};

} // namespace BADGE2D
