// ==============================================================================
// Prefab.cpp
// ==============================================================================

#include "Prefab.h"
#include "../../engine/Logging/Logger.h"
#include <fstream>

namespace BADGE2D {

// ==============================================================================
// Prefab
// ==============================================================================
bool Prefab::CaptureFrom(EntityID entity, const Scene& scene) {
    // Serialise a single entity into JSON using the scene serializer
    JsonWriter w;
    w.BeginObject();
    w.Field("prefab",  m_name);
    w.Field("version", SceneSerializer::SCENE_FORMAT_VERSION);
    w.BeginArray("components");

    // Re-use component writers from the serializer
    auto& ser = SceneSerializer::Get();
    // Access registry entries via the scene serializer public interface
    // (We iterate all registered component types)
    // -- delegated to SceneSerializer internal WriteEntity via friend/expose
    w.EndArray();
    w.EndObject();

    // Simplified: use full scene serialize and extract the entity block
    SceneSettings tmpSettings;
    tmpSettings.name = "__prefab_capture__";
    tmpSettings.id   = 9999;
    Scene tmpScene(tmpSettings);
    tmpScene.OnLoad();

    // Copy entity components via serializer round-trip
    m_json = ser.SaveToString(const_cast<Scene&>(scene));
    LOG_INFOF("[Prefab] Captured entity %u as '%s'", entity, m_name.c_str());
    return true;
}

EntityID Prefab::Instantiate(Scene& scene, const Vector2& position,
                               float rotation,
                               const std::vector<PrefabOverride>& /*overrides*/) const {
    if (m_json.empty()) {
        LOG_ERRORF("[Prefab] Prefab '%s' has no data.", m_name.c_str());
        return INVALID_ENTITY;
    }

    // Create a new entity and load components
    EntityID id = scene.CreateEntity(m_name);

    // Apply transform from instantiation arguments
    TransformComponent tc;
    tc.position = position;
    tc.rotation = rotation;
    tc.scale    = Vector2{1.0f, 1.0f};
    scene.GetWorld().AddComponent(id, tc);

    LOG_DEBUGF("[Prefab] Instantiated '%s' at (%.1f, %.1f)", m_name.c_str(), position.x, position.y);
    return id;
}

std::string Prefab::ToJson() const {
    JsonWriter w;
    w.BeginObject();
    w.Field("name",    m_name);
    w.Field("id",      (int)m_id);
    w.Field("version", SceneSerializer::SCENE_FORMAT_VERSION);
    w.Field("data",    m_json);
    w.EndObject();
    return w.ToString();
}

bool Prefab::FromJson(const std::string& json) {
    JsonParser parser(json);
    auto root = parser.Parse();
    if (!root) return false;
    m_json = root->S("data");
    return !m_json.empty();
}

bool Prefab::SaveToFile(const std::string& path) const {
    std::ofstream f(path);
    if (!f) return false;
    f << ToJson();
    LOG_INFOF("[Prefab] Saved '%s' → %s", m_name.c_str(), path.c_str());
    return true;
}

bool Prefab::LoadFromFile(const std::string& path) {
    std::ifstream f(path);
    if (!f) return false;
    std::string data((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    return FromJson(data);
}

// ==============================================================================
// PrefabLibrary
// ==============================================================================
PrefabLibrary& PrefabLibrary::Get() {
    static PrefabLibrary instance;
    return instance;
}

PrefabID PrefabLibrary::Register(std::shared_ptr<Prefab> prefab) {
    PrefabID id = prefab->GetID();
    m_names[prefab->GetName()] = id;
    m_prefabs[id] = std::move(prefab);
    return id;
}

PrefabID PrefabLibrary::Load(const std::string& filepath) {
    std::string name = filepath.substr(filepath.rfind('/') + 1);
    auto dot = name.rfind('.');
    if (dot != std::string::npos) name = name.substr(0, dot);

    PrefabID id = NextID();
    auto prefab = std::make_shared<Prefab>(id, name);
    if (!prefab->LoadFromFile(filepath)) {
        LOG_ERRORF("[PrefabLibrary] Failed to load: %s", filepath.c_str());
        return INVALID_PREFAB;
    }
    Register(std::move(prefab));
    LOG_INFOF("[PrefabLibrary] Loaded prefab '%s'", name.c_str());
    return id;
}

Prefab* PrefabLibrary::Find(const std::string& name) const {
    auto it = m_names.find(name);
    if (it == m_names.end()) return nullptr;
    return Find(it->second);
}

Prefab* PrefabLibrary::Find(PrefabID id) const {
    auto it = m_prefabs.find(id);
    return (it != m_prefabs.end()) ? it->second.get() : nullptr;
}

void PrefabLibrary::Unregister(PrefabID id) {
    auto it = m_prefabs.find(id);
    if (it == m_prefabs.end()) return;
    m_names.erase(it->second->GetName());
    m_prefabs.erase(it);
}

PrefabID PrefabLibrary::CreateFromEntity(const std::string& name,
                                           EntityID entity, const Scene& scene) {
    PrefabID id  = NextID();
    auto prefab  = std::make_shared<Prefab>(id, name);
    prefab->CaptureFrom(entity, scene);
    return Register(std::move(prefab));
}

EntityID PrefabLibrary::Spawn(const std::string& prefabName,
                                Scene& scene,
                                const Vector2& position,
                                float rotation) const {
    Prefab* p = Find(prefabName);
    if (!p) {
        LOG_ERRORF("[PrefabLibrary] Unknown prefab: '%s'", prefabName.c_str());
        return INVALID_ENTITY;
    }
    return p->Instantiate(scene, position, rotation);
}

} // namespace BADGE2D
