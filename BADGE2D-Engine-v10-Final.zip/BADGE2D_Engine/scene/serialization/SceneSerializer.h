#pragma once
// ==============================================================================
// SceneSerializer.h — Save/load scenes to/from JSON
// Uses a hand-rolled minimal JSON writer/reader — no third-party JSON dep.
// Format is human-readable and version-tagged.
// ==============================================================================

#include "../manager/Scene.h"
#include "../../ecs/component/Components.h"
#include <string>
#include <sstream>
#include <functional>
#include <unordered_map>

namespace BADGE2D {

// ==============================================================================
// JsonWriter — Minimal streaming JSON builder
// ==============================================================================
class JsonWriter {
public:
    void BeginObject();
    void EndObject();
    void BeginArray(const std::string& key);
    void EndArray();
    void Key(const std::string& k);
    void Value(const std::string& v);
    void Value(float v);
    void Value(double v);
    void Value(int v);
    void Value(uint32_t v);
    void Value(bool v);
    void Field(const std::string& k, const std::string& v);
    void Field(const std::string& k, float v);
    void Field(const std::string& k, int v);
    void Field(const std::string& k, bool v);
    void FieldVec2(const std::string& k, float x, float y);

    std::string ToString() const { return m_ss.str(); }

private:
    void Indent();
    void Comma();

    std::ostringstream m_ss;
    int                m_depth     = 0;
    bool               m_needComma = false;
};

// ==============================================================================
// JsonNode — Parsed JSON value (minimal DOM)
// ==============================================================================
struct JsonNode;
using JsonNodePtr = std::shared_ptr<JsonNode>;

struct JsonNode {
    enum class Type { Null, Bool, Number, String, Array, Object };
    Type type = Type::Null;

    bool        bVal  = false;
    double      nVal  = 0.0;
    std::string sVal;
    std::vector<JsonNodePtr>                      array;
    std::unordered_map<std::string, JsonNodePtr>  object;

    // Access helpers
    bool        IsNull  ()  const { return type == Type::Null; }
    double      GetNum  ()  const { return nVal; }
    float       GetFloat()  const { return (float)nVal; }
    int         GetInt  ()  const { return (int)nVal; }
    bool        GetBool ()  const { return bVal; }
    const std::string& GetStr() const { return sVal; }

    JsonNode*   Get(const std::string& key) const {
        auto it = object.find(key);
        return (it != object.end()) ? it->second.get() : nullptr;
    }
    JsonNode*   operator[](const std::string& k) const { return Get(k); }

    float   F(const std::string& k, float def = 0.0f) const {
        auto* n = Get(k); return n ? n->GetFloat() : def;
    }
    int     I(const std::string& k, int def = 0) const {
        auto* n = Get(k); return n ? n->GetInt() : def;
    }
    bool    B(const std::string& k, bool def = false) const {
        auto* n = Get(k); return n ? n->GetBool() : def;
    }
    std::string S(const std::string& k, const std::string& def = "") const {
        auto* n = Get(k); return n ? n->sVal : def;
    }
};

// ==============================================================================
// JsonParser — Minimal recursive-descent JSON parser
// ==============================================================================
class JsonParser {
public:
    explicit JsonParser(const std::string& text) : m_text(text), m_pos(0) {}
    JsonNodePtr Parse();

private:
    JsonNodePtr ParseValue();
    JsonNodePtr ParseObject();
    JsonNodePtr ParseArray();
    JsonNodePtr ParseString();
    JsonNodePtr ParseNumber();
    JsonNodePtr ParseLiteral();

    void SkipWhitespace();
    char Peek() const;
    char Consume();
    bool Expect(char c);

    const std::string& m_text;
    size_t             m_pos;
};

// ==============================================================================
// ComponentSerializer — Extensible component read/write registry
// ==============================================================================
using ComponentWriteFn = std::function<void(JsonWriter&, EntityID, World&)>;
using ComponentReadFn  = std::function<void(const JsonNode&, EntityID, World&)>;

struct ComponentSerializerEntry {
    std::string       typeName;
    ComponentWriteFn  write;
    ComponentReadFn   read;
};

// ==============================================================================
// SceneSerializer
// ==============================================================================
class SceneSerializer {
public:
    static SceneSerializer& Get();

    // ---- Built-in component registration (called in Initialize) ----
    void RegisterBuiltins();

    // ---- Custom component extension point ----
    void RegisterComponent(const std::string& typeName,
                            ComponentWriteFn write,
                            ComponentReadFn  read);

    // ---- Save ----
    bool SaveToFile  (const Scene& scene, const std::string& filepath) const;
    std::string SaveToString(const Scene& scene) const;

    // ---- Load ----
    bool LoadFromFile  (Scene& scene, const std::string& filepath) const;
    bool LoadFromString(Scene& scene, const std::string& json) const;

    // Version
    static constexpr int SCENE_FORMAT_VERSION = 1;

private:
    SceneSerializer() = default;

    void WriteScene   (JsonWriter& w, const Scene& scene) const;
    void WriteEntities(JsonWriter& w, const Scene& scene) const;
    void WriteEntity  (JsonWriter& w, EntityID id, const Scene& scene) const;

    bool ReadScene    (const JsonNode& root, Scene& scene) const;
    bool ReadEntities (const JsonNode& node,  Scene& scene) const;
    bool ReadEntity   (const JsonNode& node,  Scene& scene) const;

    std::vector<ComponentSerializerEntry> m_entries;
    bool m_builtinsRegistered = false;
};

} // namespace BADGE2D
