// ==============================================================================
// SceneSerializer.cpp — Scene save/load (JSON)
// ==============================================================================

#include "SceneSerializer.h"
#include "../../engine/Logging/Logger.h"
#include <fstream>
#include <sstream>
#include <cmath>
#include <iomanip>
#include <algorithm>

namespace BADGE2D {

// ==============================================================================
// JsonWriter
// ==============================================================================
void JsonWriter::Indent() {
    for (int i = 0; i < m_depth; ++i) m_ss << "  ";
}

void JsonWriter::Comma() {
    if (m_needComma) { m_ss << ",\n"; m_needComma = false; }
}

void JsonWriter::BeginObject() {
    Comma();
    Indent();
    m_ss << "{\n";
    ++m_depth;
    m_needComma = false;
}

void JsonWriter::EndObject() {
    --m_depth;
    m_ss << "\n";
    Indent();
    m_ss << "}";
    m_needComma = true;
}

void JsonWriter::BeginArray(const std::string& key) {
    Comma();
    Indent();
    m_ss << "\"" << key << "\": [\n";
    ++m_depth;
    m_needComma = false;
}

void JsonWriter::EndArray() {
    --m_depth;
    m_ss << "\n";
    Indent();
    m_ss << "]";
    m_needComma = true;
}

void JsonWriter::Key(const std::string& k) {
    Comma();
    Indent();
    m_ss << "\"" << k << "\": ";
    m_needComma = false;
}

void JsonWriter::Value(const std::string& v) {
    // Escape basic chars
    m_ss << "\"";
    for (char c : v) {
        if (c == '"')  m_ss << "\\\"";
        else if (c == '\\') m_ss << "\\\\";
        else if (c == '\n') m_ss << "\\n";
        else           m_ss << c;
    }
    m_ss << "\"";
    m_needComma = true;
}

void JsonWriter::Value(float v) {
    if (std::isnan(v) || std::isinf(v)) m_ss << "0";
    else m_ss << std::setprecision(6) << v;
    m_needComma = true;
}

void JsonWriter::Value(double v) {
    if (std::isnan(v) || std::isinf(v)) m_ss << "0";
    else m_ss << std::setprecision(8) << v;
    m_needComma = true;
}

void JsonWriter::Value(int v)      { m_ss << v; m_needComma = true; }
void JsonWriter::Value(uint32_t v) { m_ss << v; m_needComma = true; }
void JsonWriter::Value(bool v)     { m_ss << (v ? "true" : "false"); m_needComma = true; }

void JsonWriter::Field(const std::string& k, const std::string& v) { Key(k); Value(v); }
void JsonWriter::Field(const std::string& k, float v)              { Key(k); Value(v); }
void JsonWriter::Field(const std::string& k, int v)                { Key(k); Value(v); }
void JsonWriter::Field(const std::string& k, bool v)               { Key(k); Value(v); }
void JsonWriter::FieldVec2(const std::string& k, float x, float y) {
    Key(k);
    m_ss << "[";
    m_ss << std::setprecision(6) << x << ", " << y;
    m_ss << "]";
    m_needComma = true;
}

// ==============================================================================
// JsonParser
// ==============================================================================
void JsonParser::SkipWhitespace() {
    while (m_pos < m_text.size() && isspace((unsigned char)m_text[m_pos])) ++m_pos;
}

char JsonParser::Peek() const {
    return (m_pos < m_text.size()) ? m_text[m_pos] : '\0';
}

char JsonParser::Consume() {
    return (m_pos < m_text.size()) ? m_text[m_pos++] : '\0';
}

bool JsonParser::Expect(char c) {
    SkipWhitespace();
    if (Peek() != c) return false;
    Consume();
    return true;
}

JsonNodePtr JsonParser::Parse() {
    SkipWhitespace();
    return ParseValue();
}

JsonNodePtr JsonParser::ParseValue() {
    SkipWhitespace();
    char c = Peek();
    if (c == '{')  return ParseObject();
    if (c == '[')  return ParseArray();
    if (c == '"')  return ParseString();
    if (c == 't' || c == 'f' || c == 'n') return ParseLiteral();
    if (c == '-' || isdigit((unsigned char)c)) return ParseNumber();
    return std::make_shared<JsonNode>();
}

JsonNodePtr JsonParser::ParseObject() {
    auto node = std::make_shared<JsonNode>();
    node->type = JsonNode::Type::Object;
    Consume(); // {
    while (true) {
        SkipWhitespace();
        if (Peek() == '}') { Consume(); break; }
        if (Peek() == ',') { Consume(); continue; }
        // Key
        auto keyNode = ParseString();
        std::string key = keyNode ? keyNode->sVal : "";
        Expect(':');
        auto val = ParseValue();
        node->object[key] = val;
        SkipWhitespace();
    }
    return node;
}

JsonNodePtr JsonParser::ParseArray() {
    auto node = std::make_shared<JsonNode>();
    node->type = JsonNode::Type::Array;
    Consume(); // [
    while (true) {
        SkipWhitespace();
        if (Peek() == ']') { Consume(); break; }
        if (Peek() == ',') { Consume(); continue; }
        node->array.push_back(ParseValue());
        SkipWhitespace();
    }
    return node;
}

JsonNodePtr JsonParser::ParseString() {
    auto node = std::make_shared<JsonNode>();
    node->type = JsonNode::Type::String;
    Consume(); // "
    while (m_pos < m_text.size()) {
        char c = Consume();
        if (c == '"') break;
        if (c == '\\') {
            char e = Consume();
            if (e == 'n') node->sVal += '\n';
            else if (e == '"') node->sVal += '"';
            else node->sVal += e;
        } else {
            node->sVal += c;
        }
    }
    return node;
}

JsonNodePtr JsonParser::ParseNumber() {
    auto node = std::make_shared<JsonNode>();
    node->type = JsonNode::Type::Number;
    std::string s;
    if (Peek() == '-') s += Consume();
    while (m_pos < m_text.size() && (isdigit((unsigned char)Peek()) ||
           Peek() == '.' || Peek() == 'e' || Peek() == 'E' ||
           Peek() == '+' || Peek() == '-')) {
        s += Consume();
    }
    try { node->nVal = std::stod(s); } catch (...) { node->nVal = 0; }
    return node;
}

JsonNodePtr JsonParser::ParseLiteral() {
    auto node = std::make_shared<JsonNode>();
    if (m_text.substr(m_pos, 4) == "true") {
        node->type = JsonNode::Type::Bool; node->bVal = true; m_pos += 4;
    } else if (m_text.substr(m_pos, 5) == "false") {
        node->type = JsonNode::Type::Bool; node->bVal = false; m_pos += 5;
    } else {
        node->type = JsonNode::Type::Null; m_pos += 4; // null
    }
    return node;
}

// ==============================================================================
// SceneSerializer — singleton
// ==============================================================================
SceneSerializer& SceneSerializer::Get() {
    static SceneSerializer instance;
    return instance;
}

// ==============================================================================
// RegisterBuiltins — all ECS component serializers
// ==============================================================================
void SceneSerializer::RegisterBuiltins() {
    if (m_builtinsRegistered) return;
    m_builtinsRegistered = true;

    // TransformComponent
    RegisterComponent("Transform",
        [](JsonWriter& w, EntityID id, World& world) {
            auto* tc = world.TryGetComponent<TransformComponent>(id);
            if (!tc) return;
            w.BeginObject();
            w.Field("type", std::string("Transform"));
            w.FieldVec2("position", tc->position.x, tc->position.y);
            w.FieldVec2("scale",    tc->scale.x,    tc->scale.y);
            w.Field("rotation", tc->rotation);
            w.EndObject();
        },
        [](const JsonNode& n, EntityID id, World& world) {
            TransformComponent tc;
            auto* pos = n["position"];
            auto* scl = n["scale"];
            if (pos && pos->array.size() >= 2) {
                tc.position.x = pos->array[0]->GetFloat();
                tc.position.y = pos->array[1]->GetFloat();
            }
            if (scl && scl->array.size() >= 2) {
                tc.scale.x = scl->array[0]->GetFloat();
                tc.scale.y = scl->array[1]->GetFloat();
            }
            tc.rotation = n.F("rotation");
            world.AddComponent(id, tc);
        });

    // SpriteComponent
    RegisterComponent("Sprite",
        [](JsonWriter& w, EntityID id, World& world) {
            auto* sc = world.TryGetComponent<SpriteComponent>(id);
            if (!sc) return;
            w.BeginObject();
            w.Field("type", std::string("Sprite"));
            w.Field("r",    sc->tint.r);
            w.Field("g",    sc->tint.g);
            w.Field("b",    sc->tint.b);
            w.Field("a",    sc->tint.a);
            w.Field("flipX",sc->flipX);
            w.Field("flipY",sc->flipY);
            w.FieldVec2("size", sc->size.x, sc->size.y);
            w.EndObject();
        },
        [](const JsonNode& n, EntityID id, World& world) {
            SpriteComponent sc;
            sc.tint.r = n.F("r", 1); sc.tint.g = n.F("g", 1);
            sc.tint.b = n.F("b", 1); sc.tint.a = n.F("a", 1);
            sc.flipX  = n.B("flipX");
            sc.flipY  = n.B("flipY");
            auto* sz  = n["size"];
            if (sz && sz->array.size() >= 2) {
                sc.size.x = sz->array[0]->GetFloat();
                sc.size.y = sz->array[1]->GetFloat();
            }
            world.AddComponent(id, sc);
        });

    // NameComponent
    RegisterComponent("Name",
        [](JsonWriter& w, EntityID id, World& world) {
            auto* nc = world.TryGetComponent<NameComponent>(id);
            if (!nc) return;
            w.BeginObject();
            w.Field("type", std::string("Name"));
            w.Field("name", nc->name);
            w.EndObject();
        },
        [](const JsonNode& n, EntityID id, World& world) {
            NameComponent nc;
            nc.name = n.S("name");
            world.AddComponent(id, nc);
        });

    // TagComponent
    RegisterComponent("Tag",
        [](JsonWriter& w, EntityID id, World& world) {
            auto* tc = world.TryGetComponent<TagComponent>(id);
            if (!tc) return;
            w.BeginObject();
            w.Field("type", std::string("Tag"));
            w.Field("tag",  tc->tag);
            w.EndObject();
        },
        [](const JsonNode& n, EntityID id, World& world) {
            TagComponent tc;
            tc.tag = n.S("tag");
            world.AddComponent(id, tc);
        });

    // PhysicsBodyComponent
    RegisterComponent("PhysicsBody",
        [](JsonWriter& w, EntityID id, World& world) {
            auto* pb = world.TryGetComponent<PhysicsBodyComponent>(id);
            if (!pb || !pb->body) return;
            w.BeginObject();
            w.Field("type",     std::string("PhysicsBody"));
            w.Field("bodyType", 1); // Dynamic by default
            w.EndObject();
        },
        [](const JsonNode& n, EntityID id, World& /*world*/) {
            // Physics bodies are re-created by the game code;
            // serialize their initial state for the editor and prefab system.
            LOG_DEBUGF("[Serializer] PhysicsBody read for entity %u (factory required)", id);
            (void)n;
        });
}

void SceneSerializer::RegisterComponent(const std::string& typeName,
                                          ComponentWriteFn write, ComponentReadFn read) {
    m_entries.push_back({ typeName, std::move(write), std::move(read) });
}

// ==============================================================================
// Save
// ==============================================================================
void SceneSerializer::WriteScene(JsonWriter& w, const Scene& scene) const {
    w.BeginObject();
    w.Field("version",  SCENE_FORMAT_VERSION);
    w.Field("name",     scene.GetName());
    w.Field("gravityX", scene.GetSettings().gravityX);
    w.Field("gravityY", scene.GetSettings().gravityY);
    w.Field("camX",     scene.GetSettings().camX);
    w.Field("camY",     scene.GetSettings().camY);
    w.Field("camZoom",  scene.GetSettings().camZoom);
    WriteEntities(w, scene);
    w.EndObject();
}

void SceneSerializer::WriteEntities(JsonWriter& w, const Scene& scene) const {
    w.BeginArray("entities");
    const_cast<Scene&>(scene).GetWorld().Each<NameComponent>(
        [&](EntityID id, NameComponent&) {
            WriteEntity(w, id, const_cast<Scene&>(scene));
        });
    w.EndArray();
}

void SceneSerializer::WriteEntity(JsonWriter& w, EntityID id, const Scene& scene) const {
    w.BeginObject();
    w.Field("id", (int)id);
    w.BeginArray("components");
    for (const auto& entry : m_entries) {
        entry.write(w, id, const_cast<Scene&>(scene).GetWorld());
    }
    w.EndArray();
    w.EndObject();
}

std::string SceneSerializer::SaveToString(const Scene& scene) const {
    const_cast<SceneSerializer*>(this)->RegisterBuiltins();
    JsonWriter w;
    WriteScene(w, scene);
    return w.ToString();
}

bool SceneSerializer::SaveToFile(const Scene& scene, const std::string& filepath) const {
    std::string json = SaveToString(scene);
    std::ofstream f(filepath);
    if (!f) { LOG_ERRORF("[SceneSerializer] Cannot write: %s", filepath.c_str()); return false; }
    f << json;
    LOG_INFOF("[SceneSerializer] Saved scene '%s' → %s", scene.GetName().c_str(), filepath.c_str());
    return true;
}

// ==============================================================================
// Load
// ==============================================================================
bool SceneSerializer::ReadScene(const JsonNode& root, Scene& scene) const {
    int ver = root.I("version", 0);
    if (ver != SCENE_FORMAT_VERSION)
        LOG_WARNF("[SceneSerializer] Format version mismatch (%d vs %d)", ver, SCENE_FORMAT_VERSION);

    auto* entities = root["entities"];
    if (entities) ReadEntities(*entities, scene);
    return true;
}

bool SceneSerializer::ReadEntities(const JsonNode& node, Scene& scene) const {
    for (const auto& eNode : node.array) {
        if (eNode) ReadEntity(*eNode, scene);
    }
    return true;
}

bool SceneSerializer::ReadEntity(const JsonNode& node, Scene& scene) const {
    EntityID id = (EntityID)node.I("id", -1);
    // Create entity with the serialized name (from Name component)
    id = scene.GetWorld().CreateEntity();

    auto* comps = node["components"];
    if (!comps) return true;

    for (const auto& compNode : comps->array) {
        if (!compNode) continue;
        std::string typeName = compNode->S("type");
        for (const auto& entry : m_entries) {
            if (entry.typeName == typeName) {
                entry.read(*compNode, id, scene.GetWorld());
                break;
            }
        }
    }
    return true;
}

bool SceneSerializer::LoadFromString(Scene& scene, const std::string& json) const {
    const_cast<SceneSerializer*>(this)->RegisterBuiltins();
    JsonParser parser(json);
    auto root = parser.Parse();
    if (!root) { LOG_ERROR("[SceneSerializer] JSON parse failed."); return false; }
    return ReadScene(*root, scene);
}

bool SceneSerializer::LoadFromFile(Scene& scene, const std::string& filepath) const {
    std::ifstream f(filepath);
    if (!f) { LOG_ERRORF("[SceneSerializer] Cannot open: %s", filepath.c_str()); return false; }
    std::string json((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    bool ok = LoadFromString(scene, json);
    if (ok) LOG_INFOF("[SceneSerializer] Loaded '%s' from %s", scene.GetName().c_str(), filepath.c_str());
    return ok;
}

} // namespace BADGE2D
