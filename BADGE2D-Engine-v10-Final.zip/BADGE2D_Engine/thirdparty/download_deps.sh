#!/usr/bin/env bash
# ============================================================
# download_deps.sh — Fetch BADGE2D third-party dependencies
# Run from the thirdparty/ directory
# ============================================================
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "Downloading BADGE2D third-party dependencies..."

# dr_libs (audio decoding)
echo " -> dr_wav.h"
curl -fsSLo dr_wav.h https://raw.githubusercontent.com/mackron/dr_libs/master/dr_wav.h
echo " -> dr_mp3.h"
curl -fsSLo dr_mp3.h https://raw.githubusercontent.com/mackron/dr_libs/master/dr_mp3.h

# stb_vorbis (OGG decoding)
echo " -> stb_vorbis.c"
curl -fsSLo stb_vorbis.c https://raw.githubusercontent.com/nothings/stb/master/stb_vorbis.c

# stb_image (texture loading)
echo " -> stb/stb_image.h"
mkdir -p stb
curl -fsSLo stb/stb_image.h https://raw.githubusercontent.com/nothings/stb/master/stb_image.h

# miniaudio (audio device I/O)
echo " -> miniaudio/miniaudio.h"
mkdir -p miniaudio
curl -fsSLo miniaudio/miniaudio.h https://raw.githubusercontent.com/mackron/miniaudio/master/miniaudio.h

echo ""
echo "All dependencies downloaded!"
echo "Now run from the project root:"
echo "  cmake -B build -S . -G Ninja -DCMAKE_BUILD_TYPE=Release"
echo "  cmake --build build --parallel"
