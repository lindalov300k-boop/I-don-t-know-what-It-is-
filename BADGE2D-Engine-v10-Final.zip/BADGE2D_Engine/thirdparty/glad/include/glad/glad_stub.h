// ==============================================================================
// glad_stub.h — Placeholder until real GLAD is installed
// Replace this entire directory with a real GLAD generate from:
//   https://glad.dav1d.de  (OpenGL Core 4.1, Generate Loader = ON)
// ==============================================================================
#pragma once

// If real GLAD exists, use it; otherwise provide no-op stubs for IDE parsing
#ifdef BADGE2D_HAS_GLAD
    #include "glad.h"
#else
    // Minimal GL type stubs for compilation without a display server
    #include <cstdint>
    typedef unsigned int  GLenum;
    typedef unsigned int  GLbitfield;
    typedef unsigned int  GLuint;
    typedef int           GLint;
    typedef int           GLsizei;
    typedef unsigned char GLboolean;
    typedef signed char   GLbyte;
    typedef short         GLshort;
    typedef unsigned char GLubyte;
    typedef unsigned short GLushort;
    typedef unsigned long  GLulong;
    typedef float         GLfloat;
    typedef float         GLclampf;
    typedef double        GLdouble;
    typedef double        GLclampd;
    typedef void          GLvoid;
    typedef char          GLchar;
    typedef ptrdiff_t     GLsizeiptr;
    typedef ptrdiff_t     GLintptr;

    #define GL_FALSE                    0
    #define GL_TRUE                     1
    #define GL_TRIANGLES                0x0004
    #define GL_UNSIGNED_INT             0x1405
    #define GL_UNSIGNED_BYTE            0x1401
    #define GL_FLOAT                    0x1406
    #define GL_RGBA                     0x1908
    #define GL_RGBA8                    0x8058
    #define GL_RGB                      0x1907
    #define GL_TEXTURE_2D               0x0DE1
    #define GL_TEXTURE_WRAP_S           0x2802
    #define GL_TEXTURE_WRAP_T           0x2803
    #define GL_TEXTURE_MIN_FILTER       0x2801
    #define GL_TEXTURE_MAG_FILTER       0x2800
    #define GL_LINEAR                   0x2601
    #define GL_NEAREST                  0x2600
    #define GL_CLAMP_TO_EDGE            0x812F
    #define GL_REPEAT                   0x2901
    #define GL_VERTEX_SHADER            0x8B31
    #define GL_FRAGMENT_SHADER          0x8B30
    #define GL_COMPILE_STATUS           0x8B81
    #define GL_LINK_STATUS              0x8B82
    #define GL_INFO_LOG_LENGTH          0x8B84
    #define GL_ARRAY_BUFFER             0x8892
    #define GL_ELEMENT_ARRAY_BUFFER     0x8893
    #define GL_STATIC_DRAW              0x88B4
    #define GL_DYNAMIC_DRAW             0x88E8
    #define GL_STREAM_DRAW              0x88E0
    #define GL_BLEND                    0x0BE2
    #define GL_SRC_ALPHA                0x0302
    #define GL_ONE_MINUS_SRC_ALPHA      0x0303
    #define GL_DEPTH_TEST               0x0B71
    #define GL_COLOR_BUFFER_BIT         0x00004000
    #define GL_DEPTH_BUFFER_BIT         0x00000100
    #define GL_FRAMEBUFFER              0x8D40
    #define GL_RENDERBUFFER             0x8D41
    #define GL_COLOR_ATTACHMENT0        0x8CE0
    #define GL_DEPTH_ATTACHMENT         0x8D00
    #define GL_FRAMEBUFFER_COMPLETE     0x8CD5
    #define GL_TEXTURE0                 0x84C0

    // No-op GL function stubs (replaced by real GLAD at link time)
    inline void glViewport(GLint,GLint,GLsizei,GLsizei){}
    inline void glClearColor(GLfloat,GLfloat,GLfloat,GLfloat){}
    inline void glClear(GLbitfield){}
    inline void glEnable(GLenum){}
    inline void glDisable(GLenum){}
    inline void glBlendFunc(GLenum,GLenum){}
    inline void glGenVertexArrays(GLsizei,GLuint*){}
    inline void glBindVertexArray(GLuint){}
    inline void glDeleteVertexArrays(GLsizei,const GLuint*){}
    inline void glGenBuffers(GLsizei,GLuint*){}
    inline void glBindBuffer(GLenum,GLuint){}
    inline void glBufferData(GLenum,GLsizeiptr,const void*,GLenum){}
    inline void glBufferSubData(GLenum,GLintptr,GLsizeiptr,const void*){}
    inline void glDeleteBuffers(GLsizei,const GLuint*){}
    inline void glVertexAttribPointer(GLuint,GLint,GLenum,GLboolean,GLsizei,const void*){}
    inline void glEnableVertexAttribArray(GLuint){}
    inline void glDrawElements(GLenum,GLsizei,GLenum,const void*){}
    inline void glDrawArrays(GLenum,GLint,GLsizei){}
    inline GLuint glCreateShader(GLenum){return 0;}
    inline void glShaderSource(GLuint,GLsizei,const GLchar**,const GLint*){}
    inline void glCompileShader(GLuint){}
    inline void glGetShaderiv(GLuint,GLenum,GLint*){}
    inline void glGetShaderInfoLog(GLuint,GLsizei,GLsizei*,GLchar*){}
    inline void glDeleteShader(GLuint){}
    inline GLuint glCreateProgram(){return 0;}
    inline void glAttachShader(GLuint,GLuint){}
    inline void glLinkProgram(GLuint){}
    inline void glGetProgramiv(GLuint,GLenum,GLint*){}
    inline void glGetProgramInfoLog(GLuint,GLsizei,GLsizei*,GLchar*){}
    inline void glUseProgram(GLuint){}
    inline void glDeleteProgram(GLuint){}
    inline GLint glGetUniformLocation(GLuint,const GLchar*){return -1;}
    inline void glUniform1i(GLint,GLint){}
    inline void glUniform1f(GLint,GLfloat){}
    inline void glUniform2f(GLint,GLfloat,GLfloat){}
    inline void glUniform3f(GLint,GLfloat,GLfloat,GLfloat){}
    inline void glUniform4f(GLint,GLfloat,GLfloat,GLfloat,GLfloat){}
    inline void glUniformMatrix4fv(GLint,GLsizei,GLboolean,const GLfloat*){}
    inline void glGenTextures(GLsizei,GLuint*){}
    inline void glBindTexture(GLenum,GLuint){}
    inline void glTexImage2D(GLenum,GLint,GLint,GLsizei,GLsizei,GLint,GLenum,GLenum,const void*){}
    inline void glTexParameteri(GLenum,GLenum,GLint){}
    inline void glGenerateMipmap(GLenum){}
    inline void glDeleteTextures(GLsizei,const GLuint*){}
    inline void glActiveTexture(GLenum){}
    inline void glGenFramebuffers(GLsizei,GLuint*){}
    inline void glBindFramebuffer(GLenum,GLuint){}
    inline void glFramebufferTexture2D(GLenum,GLenum,GLenum,GLuint,GLint){}
    inline void glGenRenderbuffers(GLsizei,GLuint*){}
    inline void glBindRenderbuffer(GLenum,GLuint){}
    inline void glRenderbufferStorage(GLenum,GLenum,GLsizei,GLsizei){}
    inline void glFramebufferRenderbuffer(GLenum,GLenum,GLenum,GLuint){}
    inline GLenum glCheckFramebufferStatus(GLenum){return GL_FRAMEBUFFER_COMPLETE;}
    inline void glDeleteFramebuffers(GLsizei,const GLuint*){}
    inline void glDeleteRenderbuffers(GLsizei,const GLuint*){}
    inline void glScissor(GLint,GLint,GLsizei,GLsizei){}
    inline void glLineWidth(GLfloat){}
    inline void glPointSize(GLfloat){}
#endif
