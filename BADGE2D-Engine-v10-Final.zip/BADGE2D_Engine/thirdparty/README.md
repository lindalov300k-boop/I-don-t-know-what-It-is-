# BADGE2D Third-Party Libraries

The following libraries must be downloaded and placed in this directory for full build.
All are single-header or small-footprint, freely licensed libraries.

---

## Required (Audio)

### dr_wav.h, dr_mp3.h
**License**: MIT or Public Domain (your choice)
**Source**: https://github.com/mackron/dr_libs

```
curl -O https://raw.githubusercontent.com/mackron/dr_libs/master/dr_wav.h
curl -O https://raw.githubusercontent.com/mackron/dr_libs/master/dr_mp3.h
```

### stb_vorbis.c
**License**: MIT or Public Domain
**Source**: https://github.com/nothings/stb

```
curl -O https://raw.githubusercontent.com/nothings/stb/master/stb_vorbis.c
```

### miniaudio/miniaudio.h
**License**: MIT-0 or Public Domain
**Source**: https://miniaud.io / https://github.com/mackron/miniaudio

```
mkdir -p miniaudio
curl -o miniaudio/miniaudio.h https://raw.githubusercontent.com/mackron/miniaudio/master/miniaudio.h
```

---

## Required (Renderer)

### stb/stb_image.h
**License**: MIT or Public Domain
**Source**: https://github.com/nothings/stb

```
mkdir -p stb
curl -o stb/stb_image.h https://raw.githubusercontent.com/nothings/stb/master/stb_image.h
```

### glad/
Already included in this repository. Contains OpenGL 4.1 Core Profile loader
generated from https://glad.dav1d.de with the following settings:
- Language: C
- Specification: OpenGL
- Profile: Core
- API gl: Version 4.1
- Extensions: GL_EXT_framebuffer_object (if needed)

---

## Optional (Editor UI — Phase 10)

### imgui/
**License**: MIT
**Source**: https://github.com/ocornut/imgui

```
git clone https://github.com/ocornut/imgui.git
# Or pin to v1.90.4:
cd imgui && git checkout v1.90.4
```

The CMakeLists.txt auto-detects imgui/ and enables the editor UI if found.
Without imgui, the engine compiles cleanly but the editor has no visual panels.

---

## Quick Setup Script

Save as `thirdparty/download_deps.sh` and run `bash download_deps.sh`:

```bash
#!/usr/bin/env bash
set -e
echo "Downloading BADGE2D third-party dependencies..."

# dr_libs
curl -fO https://raw.githubusercontent.com/mackron/dr_libs/master/dr_wav.h
curl -fO https://raw.githubusercontent.com/mackron/dr_libs/master/dr_mp3.h

# stb
mkdir -p stb
curl -fo stb/stb_vorbis.c https://raw.githubusercontent.com/nothings/stb/master/stb_vorbis.c
curl -fo stb/stb_image.h  https://raw.githubusercontent.com/nothings/stb/master/stb_image.h
cp stb/stb_vorbis.c stb_vorbis.c  # also place in thirdparty/ root

# miniaudio
mkdir -p miniaudio
curl -fo miniaudio/miniaudio.h https://raw.githubusercontent.com/mackron/miniaudio/master/miniaudio.h

echo "Done! Now run cmake from the project root."
```
