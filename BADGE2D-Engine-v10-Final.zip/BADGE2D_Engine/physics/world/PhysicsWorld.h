#pragma once
// ==============================================================================
// PhysicsWorld.h — Main physics simulation world
// Owns bodies, joints, broadphase, runs the full simulation step.
// ==============================================================================

#include "../PhysicsMath.h"
#include "../bodies/PhysicsBody.h"
#include "../collision/Broadphase.h"
#include "../collision/NarrowPhase.h"
#include "../collision/CollisionResolver.h"
#include "../constraints/Joints.h"
#include "../../engine/ModuleSystem/ModuleInterface.h"
#include <vector>
#include <unordered_map>
#include <memory>
#include <functional>

namespace BADGE2D {

// ==============================================================================
// CollisionEvent — Dispatched when bodies start/stop touching
// ==============================================================================
struct CollisionBeginEvent {
    PhysicsBody* bodyA;
    PhysicsBody* bodyB;
    CollisionManifold manifold;
};
struct CollisionEndEvent {
    PhysicsBody* bodyA;
    PhysicsBody* bodyB;
};
struct TriggerBeginEvent {
    PhysicsBody* trigger;
    PhysicsBody* other;
};
struct TriggerEndEvent {
    PhysicsBody* trigger;
    PhysicsBody* other;
};

// ==============================================================================
// PhysicsWorldConfig
// ==============================================================================
struct PhysicsWorldConfig {
    Vector2 gravity             = { 0.0f, -980.0f };  // cm/s² (~9.8 m/s²)
    float   fixedTimestep       = 1.0f / 60.0f;
    int     velocityIterations  = PhysicsConst::VELOCITY_ITERATIONS;
    int     positionIterations  = PhysicsConst::POSITION_ITERATIONS;
    bool    enableSleep         = true;
    bool    enableWarmStarting  = true;
    bool    useSpacialHash      = true;   // false = AABB broadphase (small worlds)
    float   spatialHashCellSize = 64.0f;
    int     maxBodiesPerFrame   = 10000;
};

// ==============================================================================
// PhysicsWorld — IModule
// ==============================================================================
class PhysicsWorld : public IModule {
public:
    explicit PhysicsWorld(const PhysicsWorldConfig& cfg = {});
    ~PhysicsWorld() override;

    // IModule
    bool        Initialize()         override;
    void        Shutdown ()          override;
    void        FixedUpdate(double dt) override;
    const char* GetName()      const override { return "PhysicsWorld"; }
    uint32_t    GetInitOrder() const override { return (uint32_t)ModuleInitOrder::Physics; }

    // ==============================================================================
    // Body management
    // ==============================================================================
    PhysicsBody* CreateBody    (BodyType type = BodyType::Dynamic);
    PhysicsBody* CreateBoxBody (BodyType type, const Vector2& pos,
                                 float w, float h,
                                 const PhysicsMaterial& mat = {});
    PhysicsBody* CreateCircleBody(BodyType type, const Vector2& pos,
                                   float radius,
                                   const PhysicsMaterial& mat = {});
    PhysicsBody* CreateCapsuleBody(BodyType type, const Vector2& pos,
                                    float height, float radius,
                                    const PhysicsMaterial& mat = {});

    void         DestroyBody   (PhysicsBody* body);
    void         DestroyBody   (BodyID id);
    PhysicsBody* GetBody       (BodyID id) const;

    size_t       GetBodyCount  ()  const { return m_bodies.size(); }
    const std::vector<std::unique_ptr<PhysicsBody>>& GetBodies() const { return m_bodies; }

    // ==============================================================================
    // Joint management
    // ==============================================================================
    DistanceJoint* CreateDistanceJoint(PhysicsBody* a, PhysicsBody* b,
                                         const Vector2& anchorA, const Vector2& anchorB,
                                         float length = -1.0f);

    HingeJoint*    CreateHingeJoint   (PhysicsBody* a, PhysicsBody* b,
                                         const Vector2& worldAnchor);

    WeldJoint*     CreateWeldJoint    (PhysicsBody* a, PhysicsBody* b,
                                         const Vector2& worldAnchor);

    SpringJoint*   CreateSpringJoint  (PhysicsBody* a, PhysicsBody* b,
                                         const Vector2& anchorA, const Vector2& anchorB,
                                         float restLength, float stiffness = 50.0f,
                                         float damping = 5.0f);

    MouseJoint*    CreateMouseJoint   (PhysicsBody* body, const Vector2& target);

    void           DestroyJoint       (JointID id);
    void           DestroyJoint       (IJoint* joint);

    // ==============================================================================
    // Queries
    // ==============================================================================
    bool          Raycast     (const Vector2& origin, const Vector2& direction,
                                float maxDistance, RaycastHit& hit,
                                uint32_t layerMask = PhysicsLayer::All) const;

    int           RaycastAll  (const Vector2& origin, const Vector2& direction,
                                float maxDistance, std::vector<RaycastHit>& hits,
                                uint32_t layerMask = PhysicsLayer::All) const;

    PhysicsBody*  PointQuery  (const Vector2& point,
                                uint32_t layerMask = PhysicsLayer::All) const;

    int           OverlapBox  (const Vector2& center, const Vector2& halfExtents,
                                float angle, std::vector<PhysicsBody*>& out,
                                uint32_t layerMask = PhysicsLayer::All) const;

    int           OverlapCircle(const Vector2& center, float radius,
                                 std::vector<PhysicsBody*>& out,
                                 uint32_t layerMask = PhysicsLayer::All) const;

    // ==============================================================================
    // World settings
    // ==============================================================================
    void    SetGravity(const Vector2& g)   { m_config.gravity = g; }
    Vector2 GetGravity()              const { return m_config.gravity; }
    void    SetGravity(float x, float y)   { m_config.gravity = {x, y}; }

    const PhysicsWorldConfig& GetConfig() const { return m_config; }

    // ==============================================================================
    // Manual step (if not using FixedUpdate)
    // ==============================================================================
    void Step(float dt);

    // ==============================================================================
    // Collision callbacks (set globally or per-body)
    // ==============================================================================
    std::function<void(const CollisionBeginEvent&)> OnCollisionBegin;
    std::function<void(const CollisionEndEvent&)>   OnCollisionEnd;
    std::function<void(const TriggerBeginEvent&)>   OnTriggerBegin;
    std::function<void(const TriggerEndEvent&)>     OnTriggerEnd;

    // ==============================================================================
    // Debug stats
    // ==============================================================================
    struct Stats {
        int   bodies        = 0;
        int   sleepingBodies= 0;
        int   joints        = 0;
        int   broadphasePairs = 0;
        int   contacts      = 0;
        int   triggers      = 0;
        float stepTime      = 0.0f;   // ms
    };
    const Stats& GetStats() const { return m_stats; }

    static PhysicsWorld& Get();

private:
    void StepInternal(float dt);
    void DetectCollisions();
    void SolveConstraints(float dt);
    void IntegrateBodies(float dt);
    void UpdateContactState();

    BodyID NextBodyID()   { return ++m_nextBodyID; }
    JointID NextJointID() { return ++m_nextJointID; }

    PhysicsWorldConfig  m_config;

    std::vector<std::unique_ptr<PhysicsBody>>  m_bodies;
    std::unordered_map<BodyID, PhysicsBody*>   m_bodyMap;

    std::vector<std::unique_ptr<IJoint>>       m_joints;
    std::unordered_map<JointID, IJoint*>       m_jointMap;

    BroadphaseAABB       m_broadphaseSimple;
    BroadphaseSpatialHash m_broadphaseHash;

    std::vector<ContactConstraint>             m_contacts;

    // Previous frame contacts (for begin/end events)
    using BodyPair = std::pair<BodyID, BodyID>;
    std::unordered_map<uint64_t, bool>         m_prevContacts;
    std::unordered_map<uint64_t, bool>         m_currContacts;

    BodyID   m_nextBodyID  = 0;
    JointID  m_nextJointID = 0;

    Stats    m_stats;
    bool     m_initialized = false;
};

} // namespace BADGE2D
