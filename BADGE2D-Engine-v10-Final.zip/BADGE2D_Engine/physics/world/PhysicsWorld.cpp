// ==============================================================================
// PhysicsWorld.cpp — Main simulation step
// ==============================================================================

#include "PhysicsWorld.h"
#include "../../engine/Logging/Logger.h"
#include "../../engine/Profiling/Profiler.h"
#include "../../utilities/EventSystem.h"
#include <algorithm>
#include <chrono>

namespace BADGE2D {

static PhysicsWorld* s_instance = nullptr;

PhysicsWorld::PhysicsWorld(const PhysicsWorldConfig& cfg) : m_config(cfg) {
    if (!s_instance) s_instance = this;
}

PhysicsWorld::~PhysicsWorld() {
    Shutdown();
    if (s_instance == this) s_instance = nullptr;
}

PhysicsWorld& PhysicsWorld::Get() {
    static PhysicsWorld instance;
    return instance;
}

// ==============================================================================
// IModule
// ==============================================================================
bool PhysicsWorld::Initialize() {
    if (m_initialized) return true;
    m_broadphaseHash.SetCellSize(m_config.spatialHashCellSize);
    m_initialized = true;
    LOG_INFOF("[PhysicsWorld] Initialized. Gravity=(%.1f,%.1f) TS=%.4f",
              m_config.gravity.x, m_config.gravity.y, m_config.fixedTimestep);
    return true;
}

void PhysicsWorld::Shutdown() {
    if (!m_initialized) return;
    m_joints.clear();
    m_jointMap.clear();
    m_bodies.clear();
    m_bodyMap.clear();
    m_broadphaseSimple.Clear();
    m_broadphaseHash.Clear();
    m_contacts.clear();
    m_initialized = false;
    LOG_INFO("[PhysicsWorld] Shutdown.");
}

void PhysicsWorld::FixedUpdate(double dt) {
    Step((float)dt);
}

// ==============================================================================
// Body factories
// ==============================================================================
PhysicsBody* PhysicsWorld::CreateBody(BodyType type) {
    BodyID id  = NextBodyID();
    auto   ptr = std::make_unique<PhysicsBody>(id);
    ptr->SetBodyType(type);
    PhysicsBody* raw = ptr.get();
    m_bodies.push_back(std::move(ptr));
    m_bodyMap[id] = raw;

    if (m_config.useSpacialHash) m_broadphaseHash.Insert(raw);
    else                          m_broadphaseSimple.Insert(raw);

    return raw;
}

PhysicsBody* PhysicsWorld::CreateBoxBody(BodyType type, const Vector2& pos,
                                           float w, float h,
                                           const PhysicsMaterial& mat) {
    PhysicsBody* b = CreateBody(type);
    b->SetPosition(pos);
    b->SetMaterial(mat);
    b->SetShape(std::make_shared<BoxShape>(BoxShape::FromSize(w, h)));
    return b;
}

PhysicsBody* PhysicsWorld::CreateCircleBody(BodyType type, const Vector2& pos,
                                              float radius,
                                              const PhysicsMaterial& mat) {
    PhysicsBody* b = CreateBody(type);
    b->SetPosition(pos);
    b->SetMaterial(mat);
    b->SetShape(std::make_shared<CircleShape>(radius));
    return b;
}

PhysicsBody* PhysicsWorld::CreateCapsuleBody(BodyType type, const Vector2& pos,
                                               float height, float radius,
                                               const PhysicsMaterial& mat) {
    PhysicsBody* b = CreateBody(type);
    b->SetPosition(pos);
    b->SetMaterial(mat);
    b->SetShape(std::make_shared<CapsuleShape>(height, radius));
    return b;
}

void PhysicsWorld::DestroyBody(PhysicsBody* body) {
    if (!body) return;
    DestroyBody(body->GetID());
}

void PhysicsWorld::DestroyBody(BodyID id) {
    auto it = m_bodyMap.find(id);
    if (it == m_bodyMap.end()) return;
    PhysicsBody* raw = it->second;

    if (m_config.useSpacialHash) m_broadphaseHash.Remove(raw);
    else                          m_broadphaseSimple.Remove(raw);

    m_bodyMap.erase(it);
    m_bodies.erase(std::remove_if(m_bodies.begin(), m_bodies.end(),
        [id](const auto& b){ return b->GetID() == id; }), m_bodies.end());
}

PhysicsBody* PhysicsWorld::GetBody(BodyID id) const {
    auto it = m_bodyMap.find(id);
    return (it != m_bodyMap.end()) ? it->second : nullptr;
}

// ==============================================================================
// Joint factories
// ==============================================================================
DistanceJoint* PhysicsWorld::CreateDistanceJoint(PhysicsBody* a, PhysicsBody* b,
                                                    const Vector2& ancA, const Vector2& ancB,
                                                    float length) {
    JointID id = NextJointID();
    auto j = std::make_unique<DistanceJoint>(id, a, b, ancA, ancB, length);
    DistanceJoint* raw = j.get();
    m_joints.push_back(std::move(j));
    m_jointMap[id] = raw;
    return raw;
}

HingeJoint* PhysicsWorld::CreateHingeJoint(PhysicsBody* a, PhysicsBody* b,
                                              const Vector2& anchor) {
    JointID id = NextJointID();
    auto j = std::make_unique<HingeJoint>(id, a, b, anchor);
    HingeJoint* raw = j.get();
    m_joints.push_back(std::move(j));
    m_jointMap[id] = raw;
    return raw;
}

WeldJoint* PhysicsWorld::CreateWeldJoint(PhysicsBody* a, PhysicsBody* b,
                                           const Vector2& anchor) {
    JointID id = NextJointID();
    auto j = std::make_unique<WeldJoint>(id, a, b, anchor);
    WeldJoint* raw = j.get();
    m_joints.push_back(std::move(j));
    m_jointMap[id] = raw;
    return raw;
}

SpringJoint* PhysicsWorld::CreateSpringJoint(PhysicsBody* a, PhysicsBody* b,
                                               const Vector2& ancA, const Vector2& ancB,
                                               float rest, float stiff, float damp) {
    JointID id = NextJointID();
    auto j = std::make_unique<SpringJoint>(id, a, b, ancA, ancB, rest, stiff, damp);
    SpringJoint* raw = j.get();
    m_joints.push_back(std::move(j));
    m_jointMap[id] = raw;
    return raw;
}

MouseJoint* PhysicsWorld::CreateMouseJoint(PhysicsBody* body, const Vector2& target) {
    JointID id = NextJointID();
    auto j = std::make_unique<MouseJoint>(id, body, target);
    MouseJoint* raw = j.get();
    m_joints.push_back(std::move(j));
    m_jointMap[id] = raw;
    return raw;
}

void PhysicsWorld::DestroyJoint(JointID id) {
    auto it = m_jointMap.find(id);
    if (it == m_jointMap.end()) return;
    m_jointMap.erase(it);
    m_joints.erase(std::remove_if(m_joints.begin(), m_joints.end(),
        [id](const auto& j){ return j->GetID() == id; }), m_joints.end());
}

void PhysicsWorld::DestroyJoint(IJoint* joint) {
    if (joint) DestroyJoint(joint->GetID());
}

// ==============================================================================
// Step
// ==============================================================================
void PhysicsWorld::Step(float dt) {
    BADGE2D_PROFILE_SCOPE("PhysicsWorld::Step");

    auto t0 = std::chrono::high_resolution_clock::now();

    // 1. Integrate velocities (forces, gravity, damping)
    IntegrateBodies(dt);

    // 2. Broadphase + Narrowphase collision detection
    DetectCollisions();

    // 3. Solve constraints (joints + contacts)
    SolveConstraints(dt);

    // 4. Integrate positions
    for (auto& b : m_bodies) b->IntegratePosition(dt);

    // 5. Update broadphase (body positions changed)
    if (m_config.useSpacialHash) {
        for (auto& b : m_bodies) {
            if (!b->IsSleeping())
                m_broadphaseHash.Update(b.get());
        }
    }

    // 6. Update contact events
    UpdateContactState();

    // Stats
    auto t1 = std::chrono::high_resolution_clock::now();
    m_stats.stepTime = std::chrono::duration<float, std::milli>(t1 - t0).count();
    m_stats.bodies   = (int)m_bodies.size();
    m_stats.joints   = (int)m_joints.size();
    m_stats.contacts = (int)m_contacts.size();

    int sleeping = 0;
    for (auto& b : m_bodies) if (b->IsSleeping()) ++sleeping;
    m_stats.sleepingBodies = sleeping;
}

void PhysicsWorld::IntegrateBodies(float dt) {
    for (auto& b : m_bodies)
        b->IntegrateVelocity(dt, m_config.gravity);
}

void PhysicsWorld::DetectCollisions() {
    BADGE2D_PROFILE_SCOPE("PhysicsWorld::DetectCollisions");

    m_contacts.clear();
    m_currContacts.clear();

    std::vector<BroadphasePair> pairs;
    if (m_config.useSpacialHash) m_broadphaseHash.QueryPairs(pairs);
    else                          m_broadphaseSimple.QueryPairs(pairs);

    m_stats.broadphasePairs = (int)pairs.size();

    for (auto& pair : pairs) {
        CollisionManifold manifold = NarrowPhase::Test(*pair.bodyA, *pair.bodyB);
        if (!manifold.hasCollision) continue;

        bool isTrigger = pair.bodyA->IsTrigger() || pair.bodyB->IsTrigger();

        // Stable pair hash
        uint64_t key = (pair.bodyA->GetID() < pair.bodyB->GetID())
            ? ((uint64_t)pair.bodyA->GetID() << 32 | pair.bodyB->GetID())
            : ((uint64_t)pair.bodyB->GetID() << 32 | pair.bodyA->GetID());
        m_currContacts[key] = isTrigger;

        if (!isTrigger) {
            ContactConstraint cc;
            cc.bodyA    = pair.bodyA;
            cc.bodyB    = pair.bodyB;
            cc.manifold = manifold;
            m_contacts.push_back(cc);

            // Per-body callbacks
            if (pair.bodyA->OnCollisionEnter) pair.bodyA->OnCollisionEnter(pair.bodyB);
            if (pair.bodyB->OnCollisionEnter) pair.bodyB->OnCollisionEnter(pair.bodyA);
        } else {
            if (pair.bodyA->OnTriggerEnter) pair.bodyA->OnTriggerEnter(pair.bodyB);
            if (pair.bodyB->OnTriggerEnter) pair.bodyB->OnTriggerEnter(pair.bodyA);
        }
    }
}

void PhysicsWorld::SolveConstraints(float dt) {
    BADGE2D_PROFILE_SCOPE("PhysicsWorld::SolveConstraints");

    // Pre-solve contacts
    for (auto& c : m_contacts) {
        // inline PreSolve with real dt
        PhysicsBody* a = c.bodyA; PhysicsBody* b = c.bodyB;
        Vector2 n = c.manifold.normal;
        Vector2 cp = c.manifold.contactPoint;
        Vector2 rA = cp - a->GetPosition();
        Vector2 rB = cp - b->GetPosition();

        float rACrossN = Vector2::Cross(rA, n);
        float rBCrossN = Vector2::Cross(rB, n);
        float invMassSum = a->GetInvMass() + b->GetInvMass()
            + rACrossN*rACrossN*a->GetInvInertia()
            + rBCrossN*rBCrossN*b->GetInvInertia();
        c.normalMass = (invMassSum > 1e-8f) ? 1.0f / invMassSum : 0.0f;

        Vector2 tangent = {-n.y, n.x};
        float rACrossT  = Vector2::Cross(rA, tangent);
        float rBCrossT  = Vector2::Cross(rB, tangent);
        float invMassT  = a->GetInvMass() + b->GetInvMass()
            + rACrossT*rACrossT*a->GetInvInertia()
            + rBCrossT*rBCrossT*b->GetInvInertia();
        c.tangentMass = (invMassT > 1e-8f) ? 1.0f / invMassT : 0.0f;

        float combinedR = std::max(a->GetMaterial().restitution, b->GetMaterial().restitution);
        float combinedF = std::sqrt(a->GetMaterial().friction * b->GetMaterial().friction);
        c.friction    = combinedF;
        c.restitution = combinedR;

        Vector2 vA = a->GetLinearVelocity() + Vector2{-a->GetAngularVelocity()*rA.y, a->GetAngularVelocity()*rA.x};
        Vector2 vB = b->GetLinearVelocity() + Vector2{-b->GetAngularVelocity()*rB.y, b->GetAngularVelocity()*rB.x};
        float relVn = Vector2::Dot(vB - vA, n);
        c.restitutionBias = 0;
        if (std::abs(relVn) > PhysicsConst::RESTITUTION_THRESHOLD)
            c.restitutionBias = -c.restitution * relVn;
        c.positionBias = PhysicsConst::BAUMGARTE_FACTOR
            * std::max(c.manifold.penetration - PhysicsConst::CONTACT_SLOP, 0.0f) / dt;
    }

    // Pre-solve joints
    for (auto& j : m_joints)
        if (j->IsEnabled()) j->PreSolve(dt);

    // Velocity iterations
    for (int i = 0; i < m_config.velocityIterations; ++i) {
        for (auto& c : m_contacts) CollisionResolver::Resolve({c}, 1, 0);
        for (auto& j : m_joints) if (j->IsEnabled()) j->SolveVelocity();
    }

    // Position iterations
    for (int i = 0; i < m_config.positionIterations; ++i) {
        for (auto& c : m_contacts) CollisionResolver::Resolve({c}, 0, 1);
        for (auto& j : m_joints) if (j->IsEnabled()) j->SolvePosition();
    }
}

void PhysicsWorld::UpdateContactState() {
    // Fire begin/end events
    for (auto& [key, isTrigger] : m_currContacts) {
        if (m_prevContacts.find(key) == m_prevContacts.end()) {
            // New contact
            // Extract body IDs from key
            BodyID idA = (BodyID)(key >> 32);
            BodyID idB = (BodyID)(key & 0xFFFFFFFF);
            PhysicsBody* ba = GetBody(idA);
            PhysicsBody* bb = GetBody(idB);
            if (ba && bb) {
                if (isTrigger) {
                    if (OnTriggerBegin) OnTriggerBegin({ba, bb});
                } else {
                    if (OnCollisionBegin) {
                        CollisionManifold m;
                        OnCollisionBegin({ba, bb, m});
                    }
                }
            }
        }
    }
    for (auto& [key, isTrigger] : m_prevContacts) {
        if (m_currContacts.find(key) == m_currContacts.end()) {
            BodyID idA = (BodyID)(key >> 32);
            BodyID idB = (BodyID)(key & 0xFFFFFFFF);
            PhysicsBody* ba = GetBody(idA);
            PhysicsBody* bb = GetBody(idB);
            if (ba && bb) {
                if (isTrigger) { if (OnTriggerEnd) OnTriggerEnd({ba, bb}); }
                else            { if (OnCollisionEnd) OnCollisionEnd({ba, bb}); }
            }
        }
    }
    m_prevContacts = m_currContacts;
}

// ==============================================================================
// Queries
// ==============================================================================
bool PhysicsWorld::Raycast(const Vector2& origin, const Vector2& dir,
                             float maxDist, RaycastHit& hit, uint32_t mask) const {
    AABB queryBox = AABB::FromCenter(origin + dir * (maxDist * 0.5f),
                                      { std::abs(dir.x)*maxDist*0.5f + 1,
                                        std::abs(dir.y)*maxDist*0.5f + 1 });

    std::vector<PhysicsBody*> candidates;
    if (m_config.useSpacialHash)
        m_broadphaseHash.QueryAABB(queryBox, candidates);
    else
        m_broadphaseSimple.QueryAABB(queryBox, candidates);

    hit = {};
    hit.distance = maxDist;

    Vector2 normDir = dir.Normalized();

    for (auto* body : candidates) {
        if (!(body->GetLayer() & mask)) continue;
        RaycastHit h;
        bool didHit = false;

        if (!body->GetShape()) continue;
        switch (body->GetShape()->GetType()) {
            case ShapeType::Circle:
                didHit = NarrowPhase::RaycastCircle(origin, normDir, maxDist,
                    *static_cast<CircleShape*>(body->GetShape()), body->GetPosition(), h);
                break;
            case ShapeType::Box:
                didHit = NarrowPhase::RaycastBox(origin, normDir, maxDist,
                    *static_cast<BoxShape*>(body->GetShape()), body->GetPosition(),
                    body->GetRotation(), h);
                break;
            case ShapeType::Capsule:
                didHit = NarrowPhase::RaycastCapsule(origin, normDir, maxDist,
                    *static_cast<CapsuleShape*>(body->GetShape()), body->GetPosition(),
                    body->GetRotation(), h);
                break;
            default: break;
        }

        if (didHit && h.distance < hit.distance) {
            hit        = h;
            hit.bodyID = body->GetID();
        }
    }
    return hit.hit;
}

int PhysicsWorld::RaycastAll(const Vector2& origin, const Vector2& dir,
                               float maxDist, std::vector<RaycastHit>& hits,
                               uint32_t mask) const {
    std::vector<PhysicsBody*> all;
    m_broadphaseSimple.QueryAABB(AABB{origin - Vector2(maxDist), origin + Vector2(maxDist)}, all);

    Vector2 normDir = dir.Normalized();
    for (auto* body : all) {
        if (!(body->GetLayer() & mask) || !body->GetShape()) continue;
        RaycastHit h;
        bool didHit = false;
        switch (body->GetShape()->GetType()) {
            case ShapeType::Circle:
                didHit = NarrowPhase::RaycastCircle(origin, normDir, maxDist,
                    *static_cast<CircleShape*>(body->GetShape()), body->GetPosition(), h);
                break;
            case ShapeType::Box:
                didHit = NarrowPhase::RaycastBox(origin, normDir, maxDist,
                    *static_cast<BoxShape*>(body->GetShape()), body->GetPosition(), body->GetRotation(), h);
                break;
            default: break;
        }
        if (didHit) { h.bodyID = body->GetID(); hits.push_back(h); }
    }
    std::sort(hits.begin(), hits.end(), [](const RaycastHit& a, const RaycastHit& b){ return a.distance < b.distance; });
    return (int)hits.size();
}

PhysicsBody* PhysicsWorld::PointQuery(const Vector2& pt, uint32_t mask) const {
    std::vector<PhysicsBody*> candidates;
    AABB small = AABB::FromCenter(pt, {1,1});
    if (m_config.useSpacialHash) m_broadphaseHash.QueryAABB(small, candidates);
    else                          m_broadphaseSimple.QueryAABB(small, candidates);

    for (auto* b : candidates) {
        if (!(b->GetLayer() & mask)) continue;
        if (b->GetAABB().Contains(pt)) return b;
    }
    return nullptr;
}

int PhysicsWorld::OverlapCircle(const Vector2& center, float radius,
                                  std::vector<PhysicsBody*>& out, uint32_t mask) const {
    AABB query = AABB::FromCenter(center, {radius, radius});
    std::vector<PhysicsBody*> candidates;
    if (m_config.useSpacialHash) m_broadphaseHash.QueryAABB(query, candidates);
    else                          m_broadphaseSimple.QueryAABB(query, candidates);

    for (auto* b : candidates) {
        if (!(b->GetLayer() & mask)) continue;
        float dist = Vector2::Distance(center, b->GetPosition());
        if (dist <= radius) out.push_back(b);
    }
    return (int)out.size();
}

int PhysicsWorld::OverlapBox(const Vector2& center, const Vector2& he, float angle,
                               std::vector<PhysicsBody*>& out, uint32_t mask) const {
    AABB query = AABB::FromCenter(center, he * 1.5f);
    std::vector<PhysicsBody*> candidates;
    if (m_config.useSpacialHash) m_broadphaseHash.QueryAABB(query, candidates);
    else                          m_broadphaseSimple.QueryAABB(query, candidates);

    BoxShape queryBox(he.x, he.y);
    for (auto* b : candidates) {
        if (!(b->GetLayer() & mask)) continue;
        if (!b->GetShape()) continue;
        CollisionManifold m = NarrowPhase::BoxVsBox(queryBox, center, angle,
            *static_cast<BoxShape*>(b->GetShape()), b->GetPosition(), b->GetRotation());
        if (m.hasCollision) out.push_back(b);
    }
    return (int)out.size();
}

} // namespace BADGE2D
