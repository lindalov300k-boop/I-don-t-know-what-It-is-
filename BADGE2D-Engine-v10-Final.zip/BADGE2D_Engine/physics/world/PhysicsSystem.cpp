// ==============================================================================
// PhysicsSystem.cpp — ECS <-> PhysicsWorld bridge
// ==============================================================================

#include "PhysicsSystem.h"

namespace BADGE2D {

PhysicsSystem::PhysicsSystem(PhysicsWorld* world) : m_world(world) {
    // Require PhysicsBodyComponent + TransformComponent
    // (requiredMask set in constructor if World exposes component IDs)
}

void PhysicsSystem::OnFixedUpdate(World& world, double dt) {
    if (!m_world) return;

    // 1. Sync kinematic bodies: ECS transform -> physics position
    world.Each<PhysicsBodyComponent, TransformComponent>(
        [&](EntityID /*e*/, PhysicsBodyComponent& pbc, TransformComponent& tc) {
            if (!pbc.body || !pbc.syncFromECS) return;
            if (pbc.body->GetBodyType() == BodyType::Kinematic) {
                pbc.body->SetPosition(tc.position + pbc.positionOffset);
                pbc.body->SetRotation(tc.rotation);
            }
        });

    // 2. Step the physics world
    m_world->Step((float)dt);

    // 3. Sync dynamic bodies: physics position -> ECS transform
    world.Each<PhysicsBodyComponent, TransformComponent>(
        [&](EntityID /*e*/, PhysicsBodyComponent& pbc, TransformComponent& tc) {
            if (!pbc.body || !pbc.syncToECS) return;
            if (pbc.body->GetBodyType() == BodyType::Dynamic) {
                tc.position = pbc.body->GetPosition() - pbc.positionOffset;
                tc.rotation = pbc.body->GetRotation();
                tc.dirty    = true;
            }
        });
}

void PhysicsSystem::OnUpdate(World& /*world*/, double /*dt*/) {
    // Nothing to do in variable update — physics only runs in fixed step
}

// ==============================================================================
// Helper factories
// ==============================================================================
PhysicsBody* PhysicsSystem::AttachBoxBody(World& world, EntityID entity,
                                            PhysicsWorld& physics,
                                            BodyType type, float w, float h,
                                            const PhysicsMaterial& mat) {
    auto* tc = world.TryGetComponent<TransformComponent>(entity);
    Vector2 pos = tc ? tc->position : Vector2{};

    PhysicsBody* body = physics.CreateBoxBody(type, pos, w, h, mat);
    body->SetEntityID(entity);

    PhysicsBodyComponent pbc;
    pbc.body = body;
    world.AddComponent(entity, pbc);
    return body;
}

PhysicsBody* PhysicsSystem::AttachCircleBody(World& world, EntityID entity,
                                               PhysicsWorld& physics,
                                               BodyType type, float radius,
                                               const PhysicsMaterial& mat) {
    auto* tc = world.TryGetComponent<TransformComponent>(entity);
    Vector2 pos = tc ? tc->position : Vector2{};

    PhysicsBody* body = physics.CreateCircleBody(type, pos, radius, mat);
    body->SetEntityID(entity);

    PhysicsBodyComponent pbc;
    pbc.body = body;
    world.AddComponent(entity, pbc);
    return body;
}

PhysicsBody* PhysicsSystem::AttachCapsuleBody(World& world, EntityID entity,
                                                PhysicsWorld& physics,
                                                BodyType type, float height, float radius,
                                                const PhysicsMaterial& mat) {
    auto* tc = world.TryGetComponent<TransformComponent>(entity);
    Vector2 pos = tc ? tc->position : Vector2{};

    PhysicsBody* body = physics.CreateCapsuleBody(type, pos, height, radius, mat);
    body->SetEntityID(entity);

    PhysicsBodyComponent pbc;
    pbc.body = body;
    world.AddComponent(entity, pbc);
    return body;
}

} // namespace BADGE2D
