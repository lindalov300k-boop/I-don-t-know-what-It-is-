#pragma once
// ==============================================================================
// PhysicsSystem.h — ECS bridge: syncs PhysicsBody <-> TransformComponent
// Registers with World, runs each fixed update step.
// ==============================================================================

#include "../../ecs/system/World.h"
#include "../../ecs/component/Components.h"
#include "../world/PhysicsWorld.h"

namespace BADGE2D {

// ==============================================================================
// PhysicsBodyComponent — ECS component that holds a PhysicsBody reference
// ==============================================================================
struct PhysicsBodyComponent {
    PhysicsBody* body       = nullptr;
    bool         syncToECS  = true;   // Write physics pos -> TransformComponent
    bool         syncFromECS= false;  // Read TransformComponent -> physics pos (kinematic)
    Vector2      positionOffset = {};  // Optional offset between physics and sprite origin
};

// ==============================================================================
// PhysicsSystem — ISystem that runs the physics world and syncs ECS
// ==============================================================================
class PhysicsSystem : public ISystem {
public:
    explicit PhysicsSystem(PhysicsWorld* world);

    const char* GetName() const override { return "PhysicsSystem"; }

    // Called by World::FixedUpdateSystems
    void OnFixedUpdate(World& world, double dt) override;

    // Called by World::UpdateSystems (non-fixed) — optional sync for rendering
    void OnUpdate(World& world, double dt) override;

    PhysicsWorld* GetPhysicsWorld() { return m_world; }

    // Helper: add a box body to an entity and attach PhysicsBodyComponent
    // Full-arg versions (explicit BodyType)
    static PhysicsBody* AttachBoxBody(World& world, EntityID entity,
                                       PhysicsWorld& physics,
                                       BodyType type, float w, float h,
                                       const PhysicsMaterial& mat = {});

    // Convenience: Dynamic by default
    static PhysicsBody* AttachBoxBody(World& world, EntityID entity,
                                       PhysicsWorld& physics,
                                       float w, float h,
                                       BodyType type = BodyType::Dynamic,
                                       const PhysicsMaterial& mat = {}) {
        return AttachBoxBody(world, entity, physics, type, w, h, mat);
    }

    static PhysicsBody* AttachCircleBody(World& world, EntityID entity,
                                          PhysicsWorld& physics,
                                          BodyType type, float radius,
                                          const PhysicsMaterial& mat = {});

    static PhysicsBody* AttachCapsuleBody(World& world, EntityID entity,
                                           PhysicsWorld& physics,
                                           BodyType type,
                                           float height, float radius,
                                           const PhysicsMaterial& mat = {});

private:
    PhysicsWorld* m_world = nullptr;
};

} // namespace BADGE2D
