#pragma once
// ==============================================================================
// PhysicsDebugDraw.h — Visualizes physics state through SpriteBatch
// ==============================================================================

#include "../world/PhysicsWorld.h"
#include "../../renderer/sprites/SpriteBatch.h"

namespace BADGE2D {

namespace DebugDrawFlags {
    constexpr uint32_t Colliders     = (1 << 0);
    constexpr uint32_t AABBs         = (1 << 1);
    constexpr uint32_t Velocities    = (1 << 2);
    constexpr uint32_t Contacts      = (1 << 3);
    constexpr uint32_t SleepState    = (1 << 4);
    constexpr uint32_t Joints        = (1 << 5);
    constexpr uint32_t All           = 0xFFFFFFFF;
}

class PhysicsDebugDraw {
public:
    void Draw(const PhysicsWorld& world, SpriteBatch& batch,
              uint32_t flags = DebugDrawFlags::Colliders
                             | DebugDrawFlags::Velocities
                             | DebugDrawFlags::Joints);

    Color colorDynamic    = {0.3f, 0.9f, 0.3f, 0.8f};
    Color colorStatic     = {0.7f, 0.7f, 0.7f, 0.8f};
    Color colorKinematic  = {0.3f, 0.7f, 1.0f, 0.8f};
    Color colorSleeping   = {0.5f, 0.5f, 0.5f, 0.5f};
    Color colorTrigger    = {0.9f, 0.9f, 0.1f, 0.6f};
    Color colorAABB       = {0.2f, 0.2f, 0.9f, 0.4f};
    Color colorVelocity   = {1.0f, 0.8f, 0.0f, 0.9f};
    Color colorJoint      = {1.0f, 0.4f, 0.0f, 0.9f};

    float lineThickness   = 1.5f;
    float velocityScale   = 0.05f;

private:
    Color ColorForBody(const PhysicsBody& body) const;
    void  DrawBody   (const PhysicsBody& body,    SpriteBatch& batch, uint32_t flags);
    void  DrawCircle (const CircleShape&  shape,  const Vector2& pos, float rot, const Color& c, SpriteBatch& b);
    void  DrawBox    (const BoxShape&     shape,  const Vector2& pos, float rot, const Color& c, SpriteBatch& b);
    void  DrawCapsule(const CapsuleShape& shape,  const Vector2& pos, float rot, const Color& c, SpriteBatch& b);
    void  DrawPolygon(const PolygonShape& shape,  const Vector2& pos, float rot, const Color& c, SpriteBatch& b);
};

} // namespace BADGE2D
