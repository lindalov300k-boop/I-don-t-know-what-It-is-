// ==============================================================================
// PhysicsDebugDraw.cpp
// ==============================================================================
#include "PhysicsDebugDraw.h"
#include <cmath>

namespace BADGE2D {

Color PhysicsDebugDraw::ColorForBody(const PhysicsBody& body) const {
    if (body.IsTrigger())   return colorTrigger;
    if (body.IsSleeping())  return colorSleeping;
    switch (body.GetBodyType()) {
        case BodyType::Static:    return colorStatic;
        case BodyType::Kinematic: return colorKinematic;
        case BodyType::Dynamic:   return colorDynamic;
    }
    return colorDynamic;
}

void PhysicsDebugDraw::Draw(const PhysicsWorld& world, SpriteBatch& batch, uint32_t flags) {
    for (const auto& body : world.GetBodies())
        DrawBody(*body, batch, flags);
}

void PhysicsDebugDraw::DrawBody(const PhysicsBody& body, SpriteBatch& batch, uint32_t flags) {
    IShape* shape = body.GetShape();
    Color   c     = ColorForBody(body);

    if ((flags & DebugDrawFlags::Colliders) && shape) {
        switch (shape->GetType()) {
            case ShapeType::Circle:
                DrawCircle (*static_cast<CircleShape*>(shape),
                            body.GetPosition(), body.GetRotation(), c, batch); break;
            case ShapeType::Box:
                DrawBox    (*static_cast<BoxShape*>(shape),
                            body.GetPosition(), body.GetRotation(), c, batch); break;
            case ShapeType::Capsule:
                DrawCapsule(*static_cast<CapsuleShape*>(shape),
                            body.GetPosition(), body.GetRotation(), c, batch); break;
            case ShapeType::Polygon:
                DrawPolygon(*static_cast<PolygonShape*>(shape),
                            body.GetPosition(), body.GetRotation(), c, batch); break;
        }
    }

    if (flags & DebugDrawFlags::AABBs) {
        AABB aabb = body.GetAABB();
        batch.DrawRect({aabb.min.x, aabb.min.y, aabb.Width(), aabb.Height()},
                       colorAABB, lineThickness);
    }

    if ((flags & DebugDrawFlags::Velocities) && body.GetBodyType() == BodyType::Dynamic) {
        Vector2 vel = body.GetLinearVelocity() * velocityScale;
        if (vel.LengthSq() > 0.01f)
            batch.DrawLine(body.GetPosition(), body.GetPosition() + vel,
                           colorVelocity, lineThickness);
    }
}

void PhysicsDebugDraw::DrawCircle(const CircleShape& s, const Vector2& pos,
                                    float rot, const Color& c, SpriteBatch& b) {
    Vector2 center = pos + s.offset;
    b.DrawCircle(center, s.radius, c, 20, lineThickness);
    Vector2 dir = Vector2{s.radius, 0}.Rotated(rot);
    b.DrawLine(center, center + dir, c, lineThickness);
}

void PhysicsDebugDraw::DrawBox(const BoxShape& s, const Vector2& pos,
                                 float rot, const Color& c, SpriteBatch& b) {
    Vector2 corners[4];
    s.GetCorners(corners, pos, rot);
    for (int i = 0; i < 4; ++i)
        b.DrawLine(corners[i], corners[(i+1)%4], c, lineThickness);
}

void PhysicsDebugDraw::DrawCapsule(const CapsuleShape& s, const Vector2& pos,
                                     float rot, const Color& c, SpriteBatch& b) {
    float halfH = s.height * 0.5f - s.radius;
    Vector2 dir = Vector2{0, 1}.Rotated(rot);
    Vector2 ctr = pos + s.offset.Rotated(rot);
    Vector2 p1  = ctr + dir * halfH, p2 = ctr - dir * halfH;
    b.DrawCircle(p1, s.radius, c, 16, lineThickness);
    b.DrawCircle(p2, s.radius, c, 16, lineThickness);
    Vector2 perp = {-dir.y, dir.x};
    b.DrawLine(p1 + perp*s.radius, p2 + perp*s.radius, c, lineThickness);
    b.DrawLine(p1 - perp*s.radius, p2 - perp*s.radius, c, lineThickness);
}

void PhysicsDebugDraw::DrawPolygon(const PolygonShape& s, const Vector2& pos,
                                     float rot, const Color& c, SpriteBatch& b) {
    for (size_t i = 0; i < s.vertices.size(); ++i) {
        Vector2 a = pos + s.vertices[i].Rotated(rot);
        Vector2 vb = pos + s.vertices[(i+1)%s.vertices.size()].Rotated(rot);
        b.DrawLine(a, vb, c, lineThickness);
    }
}

} // namespace BADGE2D
