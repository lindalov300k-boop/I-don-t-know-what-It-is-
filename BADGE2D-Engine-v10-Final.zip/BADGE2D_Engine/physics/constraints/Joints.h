#pragma once
// ==============================================================================
// Joints.h — Physics constraints (joints) between pairs of bodies
// Implements: Distance, Hinge, Prismatic, Weld, Spring, Mouse
// ==============================================================================

#include "../bodies/PhysicsBody.h"
#include <memory>
#include <string>

namespace BADGE2D {

using JointID = uint32_t;
constexpr JointID INVALID_JOINT = 0;

// ==============================================================================
// JointType
// ==============================================================================
enum class JointType {
    Distance,    // Fixed-length rod / rope
    Hinge,       // Pin joint — rotation allowed
    Prismatic,   // Slider — translation along one axis only
    Weld,        // Fully rigid connection
    Spring,      // Damped spring
    Mouse        // Drag constraint (kinematic target)
};

// ==============================================================================
// IJoint — Abstract joint base
// ==============================================================================
class IJoint {
public:
    explicit IJoint(JointID id, PhysicsBody* a, PhysicsBody* b = nullptr)
        : m_id(id), m_bodyA(a), m_bodyB(b) {}
    virtual ~IJoint() = default;

    virtual JointType GetType() const = 0;
    virtual void PreSolve  (float dt) = 0;
    virtual void SolveVelocity()      = 0;
    virtual void SolvePosition()      = 0;

    JointID      GetID()     const { return m_id; }
    PhysicsBody* GetBodyA()  const { return m_bodyA; }
    PhysicsBody* GetBodyB()  const { return m_bodyB; }
    bool         IsEnabled() const { return m_enabled; }
    void         SetEnabled(bool e){ m_enabled = e; }

    bool         CollideConnected = false;  // Allow collision between joined bodies

protected:
    JointID      m_id;
    PhysicsBody* m_bodyA   = nullptr;
    PhysicsBody* m_bodyB   = nullptr;
    bool         m_enabled = true;
};

// ==============================================================================
// DistanceJoint — Maintains a fixed (or min/max) distance between anchor points
// ==============================================================================
class DistanceJoint : public IJoint {
public:
    DistanceJoint(JointID id, PhysicsBody* a, PhysicsBody* b,
                  const Vector2& anchorA, const Vector2& anchorB,
                  float length = -1.0f);

    JointType GetType() const override { return JointType::Distance; }
    void PreSolve    (float dt)  override;
    void SolveVelocity()         override;
    void SolvePosition()         override;

    void  SetLength      (float l)   { m_length = l; }
    float GetLength      ()  const   { return m_length; }
    void  SetFrequency   (float hz)  { m_frequencyHz  = hz; }
    void  SetDampingRatio(float d)   { m_dampingRatio = d; }
    void  SetMinLength   (float l)   { m_minLength = l; }
    void  SetMaxLength   (float l)   { m_maxLength = l; }

private:
    Vector2 m_localAnchorA, m_localAnchorB;
    float   m_length        = 100.0f;
    float   m_minLength     = 0.0f;
    float   m_maxLength     = FLT_MAX;
    float   m_frequencyHz   = 0.0f;   // 0 = rigid
    float   m_dampingRatio  = 0.7f;

    // Runtime
    Vector2 m_u             = {};
    float   m_mass          = 0.0f;
    float   m_impulse       = 0.0f;
    float   m_gamma         = 0.0f;
    float   m_bias          = 0.0f;
    Vector2 m_rA, m_rB;
};

// ==============================================================================
// HingeJoint — Pin joint. Bodies rotate freely around shared point.
//              Optional motor + angle limits.
// ==============================================================================
class HingeJoint : public IJoint {
public:
    HingeJoint(JointID id, PhysicsBody* a, PhysicsBody* b,
               const Vector2& worldAnchor);

    JointType GetType() const override { return JointType::Hinge; }
    void PreSolve    (float dt)  override;
    void SolveVelocity()         override;
    void SolvePosition()         override;

    // Motor
    void  EnableMotor   (bool e)      { m_motorEnabled = e; }
    void  SetMotorSpeed (float rps)   { m_motorSpeed   = rps; }
    void  SetMaxTorque  (float t)     { m_maxMotorTorque = t; }

    // Limits
    void  EnableLimits  (bool e)      { m_limitsEnabled = e; }
    void  SetLimits     (float lo, float hi) { m_lowerAngle = lo; m_upperAngle = hi; }
    float GetAngle      ()  const;

private:
    Vector2 m_localAnchorA, m_localAnchorB;

    // Motor
    bool    m_motorEnabled    = false;
    float   m_motorSpeed      = 0.0f;
    float   m_maxMotorTorque  = 10.0f;
    float   m_motorImpulse    = 0.0f;

    // Limits
    bool    m_limitsEnabled   = false;
    float   m_lowerAngle      = -Math::PI;
    float   m_upperAngle      =  Math::PI;

    // Runtime
    float   m_mass2x2[4]      = {};  // 2x2 effective mass matrix
    Vector2 m_impulse2D       = {};
    float   m_limitImpulse    = 0.0f;
    Vector2 m_rA, m_rB;
    float   m_referenceAngle  = 0.0f;
};

// ==============================================================================
// WeldJoint — Fully rigid weld (no relative motion)
// ==============================================================================
class WeldJoint : public IJoint {
public:
    WeldJoint(JointID id, PhysicsBody* a, PhysicsBody* b,
              const Vector2& worldAnchor);

    JointType GetType() const override { return JointType::Weld; }
    void PreSolve    (float dt)  override;
    void SolveVelocity()         override;
    void SolvePosition()         override;

    void SetFrequency   (float hz)  { m_frequencyHz   = hz; }
    void SetDampingRatio(float d)   { m_dampingRatio  = d; }

private:
    Vector2 m_localAnchorA, m_localAnchorB;
    float   m_referenceAngle  = 0.0f;
    float   m_frequencyHz     = 0.0f;
    float   m_dampingRatio    = 0.7f;
    float   m_gamma           = 0.0f;
    float   m_bias            = 0.0f;

    // Runtime
    float   m_mass3x3[9]      = {};
    Vector3 m_impulse3D       = {};  // Using Vector3 for 3-DOF constraint
    Vector2 m_rA, m_rB;
};

// ==============================================================================
// SpringJoint — Soft damped spring
// ==============================================================================
class SpringJoint : public IJoint {
public:
    SpringJoint(JointID id, PhysicsBody* a, PhysicsBody* b,
                const Vector2& anchorA, const Vector2& anchorB,
                float restLength, float stiffness = 50.0f, float damping = 5.0f);

    JointType GetType() const override { return JointType::Spring; }
    void PreSolve    (float dt)  override;
    void SolveVelocity()         override;
    void SolvePosition()         override { }  // Soft constraint: velocity-only

    void SetRestLength(float l) { m_restLength = l; }
    void SetStiffness (float k) { m_stiffness  = k; }
    void SetDamping   (float d) { m_damping    = d; }
    void SetBreakForce(float f) { m_breakForce = f; }
    bool IsBroken     ()  const { return m_broken; }

private:
    Vector2 m_localAnchorA, m_localAnchorB;
    float   m_restLength  = 100.0f;
    float   m_stiffness   = 50.0f;
    float   m_damping     = 5.0f;
    float   m_breakForce  = FLT_MAX;
    bool    m_broken      = false;

    // Runtime
    float   m_mass        = 0.0f;
    float   m_gamma       = 0.0f;
    float   m_bias        = 0.0f;
    float   m_impulse     = 0.0f;
    Vector2 m_u;
    Vector2 m_rA, m_rB;
};

// ==============================================================================
// MouseJoint — Drag a body to a target point (like grabbing with mouse)
// ==============================================================================
class MouseJoint : public IJoint {
public:
    MouseJoint(JointID id, PhysicsBody* body, const Vector2& target,
               float stiffness = 200.0f, float damping = 10.0f);

    JointType GetType() const override { return JointType::Mouse; }
    void PreSolve    (float dt)  override;
    void SolveVelocity()         override;
    void SolvePosition()         override { }

    void SetTarget(const Vector2& t) { m_target = t; }
    Vector2 GetTarget() const        { return m_target; }

private:
    Vector2 m_target;
    Vector2 m_localAnchor;
    float   m_stiffness   = 200.0f;
    float   m_damping     = 10.0f;
    float   m_maxForce    = 10000.0f;

    // Runtime
    float   m_mass2[4]    = {};
    Vector2 m_impulse;
    Vector2 m_beta;
    float   m_gamma       = 0.0f;
    Vector2 m_rB;
};

// Minimal Vector3 for weld joint (avoids pulling in a full 3D dependency)
struct Vector3 { float x=0,y=0,z=0; };

} // namespace BADGE2D
