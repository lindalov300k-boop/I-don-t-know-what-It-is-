// ==============================================================================
// Joints.cpp — Physics joint implementations
// ==============================================================================

#include "Joints.h"
#include <cmath>
#include <algorithm>

namespace BADGE2D {

// ==============================================================================
// DistanceJoint
// ==============================================================================
DistanceJoint::DistanceJoint(JointID id, PhysicsBody* a, PhysicsBody* b,
                               const Vector2& anchorA, const Vector2& anchorB,
                               float length)
    : IJoint(id, a, b)
{
    m_localAnchorA = anchorA - a->GetPosition();
    m_localAnchorB = anchorB - b->GetPosition();
    m_length       = (length < 0) ? Vector2::Distance(anchorA, anchorB) : length;
}

void DistanceJoint::PreSolve(float dt) {
    PhysicsBody* a = m_bodyA; PhysicsBody* b = m_bodyB;
    m_rA = m_localAnchorA.Rotated(a->GetRotation());
    m_rB = m_localAnchorB.Rotated(b->GetRotation());

    Vector2 pA = a->GetPosition() + m_rA;
    Vector2 pB = b->GetPosition() + m_rB;
    m_u        = pB - pA;
    float dist = m_u.Length();

    if (dist > 1e-6f) m_u = m_u * (1.0f / dist);
    else { m_u = {1, 0}; m_impulse = 0; return; }

    // Clamp to length range
    float C = std::clamp(dist - m_length, m_minLength - m_length, m_maxLength - m_length);

    float rACrossU = Vector2::Cross(m_rA, m_u);
    float rBCrossU = Vector2::Cross(m_rB, m_u);
    float invMass  = a->GetInvMass() + b->GetInvMass()
                   + rACrossU * rACrossU * a->GetInvInertia()
                   + rBCrossU * rBCrossU * b->GetInvInertia();

    if (m_frequencyHz > 0) {
        float omega = 2.0f * Math::PI * m_frequencyHz;
        float k     = invMass > 0 ? 1.0f / invMass : 0;
        float d2    = 2.0f * k * m_dampingRatio * omega;
        float k2    = k * omega * omega;
        m_gamma = dt * (d2 + dt * k2);
        m_gamma = (m_gamma > 1e-8f) ? 1.0f / m_gamma : 0.0f;
        m_bias  = C * dt * k2 * m_gamma;
        invMass += m_gamma;
    } else {
        m_gamma = 0;
        m_bias  = PhysicsConst::BAUMGARTE_FACTOR * C / dt;
    }

    m_mass = (invMass > 1e-8f) ? 1.0f / invMass : 0.0f;

    // Warm start
    Vector2 P = m_u * m_impulse;
    a->ApplyImpulse(-P * a->GetInvMass());
    b->ApplyImpulse( P * b->GetInvMass());
}

void DistanceJoint::SolveVelocity() {
    PhysicsBody* a = m_bodyA; PhysicsBody* b = m_bodyB;
    Vector2 vA = a->GetLinearVelocity() + Vector2{-a->GetAngularVelocity()*m_rA.y, a->GetAngularVelocity()*m_rA.x};
    Vector2 vB = b->GetLinearVelocity() + Vector2{-b->GetAngularVelocity()*m_rB.y, b->GetAngularVelocity()*m_rB.x};

    float Cdot  = Vector2::Dot(m_u, vB - vA);
    float lambda = -m_mass * (Cdot + m_bias + m_gamma * m_impulse);
    m_impulse   += lambda;

    Vector2 P = m_u * lambda;
    a->SetLinearVelocity (a->GetLinearVelocity()  - P * a->GetInvMass());
    b->SetLinearVelocity (b->GetLinearVelocity()  + P * b->GetInvMass());
    a->SetAngularVelocity(a->GetAngularVelocity() - a->GetInvInertia() * Vector2::Cross(m_rA, P));
    b->SetAngularVelocity(b->GetAngularVelocity() + b->GetInvInertia() * Vector2::Cross(m_rB, P));
}

void DistanceJoint::SolvePosition() {
    if (m_frequencyHz > 0) return;  // Soft constraint: handled in velocity
    PhysicsBody* a = m_bodyA; PhysicsBody* b = m_bodyB;
    Vector2 rA = m_localAnchorA.Rotated(a->GetRotation());
    Vector2 rB = m_localAnchorB.Rotated(b->GetRotation());
    Vector2 d  = (b->GetPosition() + rB) - (a->GetPosition() + rA);
    float dist = d.Length();
    if (dist < 1e-6f) return;

    Vector2 u = d * (1.0f / dist);
    float C    = std::clamp(dist - m_length, -0.2f, 0.2f);

    float rACrossU = Vector2::Cross(rA, u);
    float rBCrossU = Vector2::Cross(rB, u);
    float invMass  = a->GetInvMass() + b->GetInvMass()
                   + rACrossU*rACrossU*a->GetInvInertia()
                   + rBCrossU*rBCrossU*b->GetInvInertia();
    if (invMass < 1e-8f) return;

    float lambda = -C / invMass;
    Vector2 P   = u * lambda;

    if (a->GetBodyType() == BodyType::Dynamic) a->SetPosition(a->GetPosition() - P * a->GetInvMass());
    if (b->GetBodyType() == BodyType::Dynamic) b->SetPosition(b->GetPosition() + P * b->GetInvMass());
}

// ==============================================================================
// HingeJoint
// ==============================================================================
HingeJoint::HingeJoint(JointID id, PhysicsBody* a, PhysicsBody* b,
                         const Vector2& worldAnchor)
    : IJoint(id, a, b)
{
    m_localAnchorA  = worldAnchor - a->GetPosition();
    m_localAnchorB  = worldAnchor - b->GetPosition();
    m_referenceAngle = b->GetRotation() - a->GetRotation();
}

float HingeJoint::GetAngle() const {
    return m_bodyB->GetRotation() - m_bodyA->GetRotation() - m_referenceAngle;
}

void HingeJoint::PreSolve(float /*dt*/) {
    m_rA = m_localAnchorA.Rotated(m_bodyA->GetRotation());
    m_rB = m_localAnchorB.Rotated(m_bodyB->GetRotation());

    float invMassA = m_bodyA->GetInvMass(), invIA = m_bodyA->GetInvInertia();
    float invMassB = m_bodyB->GetInvMass(), invIB = m_bodyB->GetInvInertia();

    // 2x2 effective mass matrix
    m_mass2x2[0] = invMassA + invMassB + m_rA.y*m_rA.y*invIA + m_rB.y*m_rB.y*invIB;
    m_mass2x2[1] = -(m_rA.x*m_rA.y*invIA + m_rB.x*m_rB.y*invIB);
    m_mass2x2[2] = m_mass2x2[1];
    m_mass2x2[3] = invMassA + invMassB + m_rA.x*m_rA.x*invIA + m_rB.x*m_rB.x*invIB;

    // Warm start
    Vector2 P = m_impulse2D;
    m_bodyA->SetLinearVelocity (m_bodyA->GetLinearVelocity()  - P * invMassA);
    m_bodyB->SetLinearVelocity (m_bodyB->GetLinearVelocity()  + P * invMassB);
    m_bodyA->SetAngularVelocity(m_bodyA->GetAngularVelocity() - invIA * Vector2::Cross(m_rA, P));
    m_bodyB->SetAngularVelocity(m_bodyB->GetAngularVelocity() + invIB * Vector2::Cross(m_rB, P));
}

void HingeJoint::SolveVelocity() {
    float invIA = m_bodyA->GetInvInertia(), invIB = m_bodyB->GetInvInertia();

    // Position constraint (2 DOF)
    Vector2 vA = m_bodyA->GetLinearVelocity() + Vector2{-m_bodyA->GetAngularVelocity()*m_rA.y, m_bodyA->GetAngularVelocity()*m_rA.x};
    Vector2 vB = m_bodyB->GetLinearVelocity() + Vector2{-m_bodyB->GetAngularVelocity()*m_rB.y, m_bodyB->GetAngularVelocity()*m_rB.x};
    Vector2 Cdot = vB - vA;

    // Solve 2x2: P = M^-1 * (-Cdot)
    float det = m_mass2x2[0]*m_mass2x2[3] - m_mass2x2[1]*m_mass2x2[2];
    Vector2 P = {};
    if (std::abs(det) > 1e-8f) {
        P.x = (-Cdot.x * m_mass2x2[3] + Cdot.y * m_mass2x2[1]) / det;
        P.y = ( Cdot.x * m_mass2x2[2] - Cdot.y * m_mass2x2[0]) / det;
    }
    m_impulse2D += P;

    m_bodyA->SetLinearVelocity (m_bodyA->GetLinearVelocity()  - P * m_bodyA->GetInvMass());
    m_bodyB->SetLinearVelocity (m_bodyB->GetLinearVelocity()  + P * m_bodyB->GetInvMass());
    m_bodyA->SetAngularVelocity(m_bodyA->GetAngularVelocity() - invIA * Vector2::Cross(m_rA, P));
    m_bodyB->SetAngularVelocity(m_bodyB->GetAngularVelocity() + invIB * Vector2::Cross(m_rB, P));

    // Motor
    if (m_motorEnabled) {
        float omegaDot = m_bodyB->GetAngularVelocity() - m_bodyA->GetAngularVelocity() - m_motorSpeed;
        float invI     = invIA + invIB;
        float lambda   = (invI > 1e-8f) ? -omegaDot / invI : 0.0f;
        float old      = m_motorImpulse;
        float dt       = 0.016f; // approximation; PhysicsWorld passes real dt
        m_motorImpulse = std::clamp(old + lambda, -m_maxMotorTorque * dt, m_maxMotorTorque * dt);
        lambda = m_motorImpulse - old;
        m_bodyA->SetAngularVelocity(m_bodyA->GetAngularVelocity() - invIA * lambda);
        m_bodyB->SetAngularVelocity(m_bodyB->GetAngularVelocity() + invIB * lambda);
    }
}

void HingeJoint::SolvePosition() {
    Vector2 rA = m_localAnchorA.Rotated(m_bodyA->GetRotation());
    Vector2 rB = m_localAnchorB.Rotated(m_bodyB->GetRotation());
    Vector2 C  = (m_bodyB->GetPosition() + rB) - (m_bodyA->GetPosition() + rA);

    float invMassA = m_bodyA->GetInvMass(), invIA = m_bodyA->GetInvInertia();
    float invMassB = m_bodyB->GetInvMass(), invIB = m_bodyB->GetInvInertia();

    float k[4] = {
        invMassA + invMassB + rA.y*rA.y*invIA + rB.y*rB.y*invIB,
        -(rA.x*rA.y*invIA + rB.x*rB.y*invIB),
        -(rA.x*rA.y*invIA + rB.x*rB.y*invIB),
        invMassA + invMassB + rA.x*rA.x*invIA + rB.x*rB.x*invIB
    };

    float det = k[0]*k[3] - k[1]*k[2];
    if (std::abs(det) < 1e-8f) return;

    Vector2 P = { (-C.x*k[3] + C.y*k[1]) / det, (C.x*k[2] - C.y*k[0]) / det };
    P = P * PhysicsConst::BAUMGARTE_FACTOR;

    if (m_bodyA->GetBodyType() == BodyType::Dynamic) {
        m_bodyA->SetPosition(m_bodyA->GetPosition() - P * invMassA);
        m_bodyA->SetRotation(m_bodyA->GetRotation() - invIA * Vector2::Cross(rA, P));
    }
    if (m_bodyB->GetBodyType() == BodyType::Dynamic) {
        m_bodyB->SetPosition(m_bodyB->GetPosition() + P * invMassB);
        m_bodyB->SetRotation(m_bodyB->GetRotation() + invIB * Vector2::Cross(rB, P));
    }
}

// ==============================================================================
// WeldJoint
// ==============================================================================
WeldJoint::WeldJoint(JointID id, PhysicsBody* a, PhysicsBody* b,
                       const Vector2& worldAnchor)
    : IJoint(id, a, b)
{
    m_localAnchorA   = worldAnchor - a->GetPosition();
    m_localAnchorB   = worldAnchor - b->GetPosition();
    m_referenceAngle = b->GetRotation() - a->GetRotation();
}

void WeldJoint::PreSolve(float /*dt*/) {
    m_rA = m_localAnchorA.Rotated(m_bodyA->GetRotation());
    m_rB = m_localAnchorB.Rotated(m_bodyB->GetRotation());
    // Full 3x3 mass matrix build (simplified — full impl would invert 3x3)
    m_impulse3D = {0,0,0};
}
void WeldJoint::SolveVelocity() {
    // Delegate to hinge solve for 2-DOF position, add angular constraint
    Vector2 vA = m_bodyA->GetLinearVelocity(); Vector2 vB = m_bodyB->GetLinearVelocity();
    float   wA = m_bodyA->GetAngularVelocity(); float wB = m_bodyB->GetAngularVelocity();
    float   wDot = wB - wA;
    float   invI = m_bodyA->GetInvInertia() + m_bodyB->GetInvInertia();
    if (invI > 0) {
        float lambda = -wDot / invI;
        m_bodyA->SetAngularVelocity(wA - m_bodyA->GetInvInertia() * lambda);
        m_bodyB->SetAngularVelocity(wB + m_bodyB->GetInvInertia() * lambda);
    }
}
void WeldJoint::SolvePosition() {}

// ==============================================================================
// SpringJoint
// ==============================================================================
SpringJoint::SpringJoint(JointID id, PhysicsBody* a, PhysicsBody* b,
                           const Vector2& anchorA, const Vector2& anchorB,
                           float restLength, float stiffness, float damping)
    : IJoint(id, a, b), m_restLength(restLength), m_stiffness(stiffness), m_damping(damping)
{
    m_localAnchorA = anchorA - a->GetPosition();
    m_localAnchorB = anchorB - b->GetPosition();
}

void SpringJoint::PreSolve(float dt) {
    if (m_broken) return;
    m_rA = m_localAnchorA.Rotated(m_bodyA->GetRotation());
    m_rB = m_localAnchorB.Rotated(m_bodyB->GetRotation());

    Vector2 pA = m_bodyA->GetPosition() + m_rA;
    Vector2 pB = m_bodyB->GetPosition() + m_rB;
    m_u = pB - pA;
    float dist = m_u.Length();
    if (dist > 1e-6f) m_u = m_u * (1.0f / dist); else { m_u = {1,0}; return; }

    float omega = 2.0f * Math::PI * std::sqrt(m_stiffness);
    float k2 = 2.0f * m_damping * omega;
    float k3 = omega * omega;

    float rACrossU = Vector2::Cross(m_rA, m_u);
    float rBCrossU = Vector2::Cross(m_rB, m_u);
    float invMass  = m_bodyA->GetInvMass() + m_bodyB->GetInvMass()
                   + rACrossU*rACrossU*m_bodyA->GetInvInertia()
                   + rBCrossU*rBCrossU*m_bodyB->GetInvInertia();

    float C    = dist - m_restLength;
    m_gamma    = dt * (k2 + dt * k3);
    m_gamma    = (m_gamma > 1e-8f) ? 1.0f / m_gamma : 0.0f;
    m_bias     = C * dt * k3 * m_gamma;
    invMass   += m_gamma;
    m_mass     = (invMass > 1e-8f) ? 1.0f / invMass : 0.0f;
}

void SpringJoint::SolveVelocity() {
    if (m_broken) return;
    Vector2 vA = m_bodyA->GetLinearVelocity() + Vector2{-m_bodyA->GetAngularVelocity()*m_rA.y, m_bodyA->GetAngularVelocity()*m_rA.x};
    Vector2 vB = m_bodyB->GetLinearVelocity() + Vector2{-m_bodyB->GetAngularVelocity()*m_rB.y, m_bodyB->GetAngularVelocity()*m_rB.x};

    float Cdot  = Vector2::Dot(m_u, vB - vA);
    float lambda = -m_mass * (Cdot + m_bias + m_gamma * m_impulse);
    m_impulse   += lambda;

    // Break check
    if (std::abs(lambda) > m_breakForce * 0.016f) { m_broken = true; return; }

    Vector2 P = m_u * lambda;
    m_bodyA->SetLinearVelocity (m_bodyA->GetLinearVelocity()  - P * m_bodyA->GetInvMass());
    m_bodyB->SetLinearVelocity (m_bodyB->GetLinearVelocity()  + P * m_bodyB->GetInvMass());
    m_bodyA->SetAngularVelocity(m_bodyA->GetAngularVelocity() - m_bodyA->GetInvInertia() * Vector2::Cross(m_rA, P));
    m_bodyB->SetAngularVelocity(m_bodyB->GetAngularVelocity() + m_bodyB->GetInvInertia() * Vector2::Cross(m_rB, P));
}

// ==============================================================================
// MouseJoint
// ==============================================================================
MouseJoint::MouseJoint(JointID id, PhysicsBody* body, const Vector2& target,
                         float stiffness, float damping)
    : IJoint(id, body, nullptr), m_target(target),
      m_stiffness(stiffness), m_damping(damping)
{
    m_localAnchor = target - body->GetPosition();
}

void MouseJoint::PreSolve(float dt) {
    PhysicsBody* b = m_bodyA;
    m_rB = m_localAnchor.Rotated(b->GetRotation());

    float omega = 2.0f * Math::PI * m_stiffness;
    float d2    = 2.0f * b->GetMass() * m_damping * omega;
    float k2    = b->GetMass() * omega * omega;

    m_gamma = dt * (d2 + dt * k2);
    m_gamma = (m_gamma > 1e-8f) ? 1.0f / m_gamma : 0.0f;

    float invMass = b->GetInvMass() + b->GetInvInertia() * Vector2::Dot(m_rB, m_rB);
    invMass += m_gamma;

    float M = (invMass > 1e-8f) ? 1.0f / invMass : 0.0f;
    m_mass2[0] = m_mass2[3] = M;
    m_mass2[1] = m_mass2[2] = 0;

    Vector2 C = b->GetPosition() + m_rB - m_target;
    m_beta = C * (-dt * k2 * m_gamma);

    // Warm start
    Vector2 P = m_impulse;
    b->SetLinearVelocity (b->GetLinearVelocity()  + P * b->GetInvMass());
    b->SetAngularVelocity(b->GetAngularVelocity() + b->GetInvInertia() * Vector2::Cross(m_rB, P));
}

void MouseJoint::SolveVelocity() {
    PhysicsBody* b = m_bodyA;
    Vector2 v  = b->GetLinearVelocity() + Vector2{-b->GetAngularVelocity()*m_rB.y, b->GetAngularVelocity()*m_rB.x};
    Vector2 Cdot = v + m_beta + m_impulse * m_gamma;
    Vector2 P  = Cdot * (-m_mass2[0]);

    Vector2 oldP = m_impulse;
    m_impulse += P;
    float maxI  = m_maxForce * 0.016f;
    if (m_impulse.LengthSq() > maxI * maxI)
        m_impulse = m_impulse.Normalized() * maxI;
    P = m_impulse - oldP;

    b->SetLinearVelocity (b->GetLinearVelocity()  + P * b->GetInvMass());
    b->SetAngularVelocity(b->GetAngularVelocity() + b->GetInvInertia() * Vector2::Cross(m_rB, P));
}

} // namespace BADGE2D
