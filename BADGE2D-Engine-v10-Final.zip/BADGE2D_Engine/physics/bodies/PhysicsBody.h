#pragma once
// ==============================================================================
// PhysicsBody.h — 2D Rigid Body with full dynamics state
// ==============================================================================

#include "../PhysicsMath.h"
#include "../colliders/Shape.h"
#include <memory>
#include <functional>
#include <cstdint>
#include <string>

namespace BADGE2D {

// ==============================================================================
// BodyType
// ==============================================================================
enum class BodyType : uint8_t {
    Static    = 0,  // Never moves, infinite mass
    Kinematic = 1,  // Moves via velocity, not forces; infinite mass for resolution
    Dynamic   = 2   // Full physics simulation
};

// ==============================================================================
// PhysicsMaterial
// ==============================================================================
struct PhysicsMaterial {
    float friction      = 0.4f;     // Coulomb friction (0 = frictionless)
    float restitution   = 0.2f;     // Bounciness (0 = inelastic, 1 = elastic)
    float density       = 1.0f;     // kg/m²

    static PhysicsMaterial Ice()      { return {0.01f, 0.05f, 0.5f}; }
    static PhysicsMaterial Rubber()   { return {0.80f, 0.80f, 1.2f}; }
    static PhysicsMaterial Stone()    { return {0.65f, 0.05f, 2.5f}; }
    static PhysicsMaterial Wood()     { return {0.50f, 0.20f, 0.8f}; }
    static PhysicsMaterial Metal()    { return {0.45f, 0.10f, 7.8f}; }
    static PhysicsMaterial Slime()    { return {0.30f, 0.90f, 0.9f}; }
};

// ==============================================================================
// BodyID — Unique body handle
// ==============================================================================
using BodyID = uint32_t;
constexpr BodyID INVALID_BODY = 0;

// ==============================================================================
// PhysicsBody — Core rigid body simulation state
// ==============================================================================
class PhysicsBody {
public:
    explicit PhysicsBody(BodyID id);

    // =========================================================
    // Identity
    // =========================================================
    BodyID      GetID()       const { return m_id; }
    BodyType    GetBodyType() const { return m_type; }
    void        SetBodyType(BodyType t);

    // Entity link (optional — physics can run standalone)
    void        SetEntityID(uint32_t eid) { m_entityID = eid; }
    uint32_t    GetEntityID()       const { return m_entityID; }

    void        SetTag(const std::string& tag) { m_tag = tag; }
    const std::string& GetTag() const          { return m_tag; }

    // =========================================================
    // Transform
    // =========================================================
    void        SetPosition (const Vector2& pos);
    void        SetRotation (float radians);
    Vector2     GetPosition ()  const { return m_position; }
    float       GetRotation ()  const { return m_rotation; }
    Transform2D GetTransform()  const { return {m_position, m_rotation, Vector2::One()}; }

    // =========================================================
    // Velocity / Angular
    // =========================================================
    void    SetLinearVelocity (const Vector2& v)  { m_linearVel  = v; }
    void    SetAngularVelocity(float omega)        { m_angularVel = omega; }
    Vector2 GetLinearVelocity ()  const            { return m_linearVel; }
    float   GetAngularVelocity()  const            { return m_angularVel; }
    float   GetSpeed()            const            { return m_linearVel.Length(); }

    // =========================================================
    // Forces / Impulses
    // =========================================================
    void ApplyForce        (const Vector2& force);
    void ApplyForceAtPoint (const Vector2& force, const Vector2& worldPoint);
    void ApplyTorque       (float torque);
    void ApplyImpulse      (const Vector2& impulse);
    void ApplyImpulseAtPoint(const Vector2& impulse, const Vector2& worldPoint);
    void ApplyAngularImpulse(float impulse);
    void ClearForces();

    // =========================================================
    // Mass / Inertia (auto-computed from shape + material)
    // =========================================================
    float   GetMass()        const { return m_mass; }
    float   GetInvMass()     const { return m_invMass; }
    float   GetInertia()     const { return m_inertia; }
    float   GetInvInertia()  const { return m_invInertia; }

    void    SetMassOverride(float mass);
    void    RecomputeMass();          // From shape + material density

    // =========================================================
    // Shape & Material
    // =========================================================
    void        SetShape   (std::shared_ptr<IShape> shape);
    IShape*     GetShape   ()  const { return m_shape.get(); }
    ShapeType   GetShapeType() const;
    AABB        GetAABB    ()  const;

    void        SetMaterial(const PhysicsMaterial& mat) { m_material = mat; }
    const PhysicsMaterial& GetMaterial() const          { return m_material; }

    // =========================================================
    // Properties
    // =========================================================
    float   GetLinearDamping()   const { return m_linearDamping; }
    float   GetAngularDamping()  const { return m_angularDamping; }
    float   GetGravityScale()    const { return m_gravityScale; }

    void    SetLinearDamping (float d) { m_linearDamping  = std::max(0.0f, d); }
    void    SetAngularDamping(float d) { m_angularDamping = std::max(0.0f, d); }
    void    SetGravityScale  (float s) { m_gravityScale   = s; }
    void    SetFixedRotation (bool f)  { m_fixedRotation  = f; if (f) { m_angularVel=0; m_invInertia=0; } }
    bool    IsFixedRotation  ()  const { return m_fixedRotation; }

    // =========================================================
    // Sleep state
    // =========================================================
    bool    IsSleeping()    const { return m_sleeping; }
    void    WakeUp();
    void    PutToSleep();

    // =========================================================
    // Trigger / Sensor
    // =========================================================
    bool    IsTrigger()         const { return m_isTrigger; }
    void    SetTrigger(bool t)        { m_isTrigger = t; }

    // =========================================================
    // Layer filtering
    // =========================================================
    uint32_t GetLayer() const       { return m_layer; }
    uint32_t GetMask()  const       { return m_mask; }
    void     SetLayer(uint32_t l)   { m_layer = l; }
    void     SetMask (uint32_t m)   { m_mask  = m; }
    bool     CanCollideWith(const PhysicsBody& o) const {
        return (m_mask & o.m_layer) && (o.m_mask & m_layer);
    }

    // =========================================================
    // Callbacks
    // =========================================================
    std::function<void(PhysicsBody*)> OnCollisionEnter;
    std::function<void(PhysicsBody*)> OnCollisionExit;
    std::function<void(PhysicsBody*)> OnTriggerEnter;
    std::function<void(PhysicsBody*)> OnTriggerExit;

    // =========================================================
    // Internal (used by PhysicsWorld)
    // =========================================================
    void IntegrateVelocity(float dt, const Vector2& gravity);
    void IntegratePosition(float dt);

private:
    void UpdateInertia();

    BodyID              m_id            = INVALID_BODY;
    uint32_t            m_entityID      = 0;
    std::string         m_tag;

    BodyType            m_type          = BodyType::Dynamic;

    // Transform
    Vector2             m_position      = {};
    float               m_rotation      = 0.0f;

    // Velocity
    Vector2             m_linearVel     = {};
    float               m_angularVel    = 0.0f;

    // Forces (accumulated, cleared each step)
    Vector2             m_force         = {};
    float               m_torque        = 0.0f;

    // Mass
    float               m_mass          = 1.0f;
    float               m_invMass       = 1.0f;
    float               m_inertia       = 1.0f;
    float               m_invInertia    = 1.0f;

    // Properties
    float               m_linearDamping = 0.01f;
    float               m_angularDamping= 0.01f;
    float               m_gravityScale  = 1.0f;
    bool                m_fixedRotation = false;

    // Sleep
    bool                m_sleeping      = false;
    float               m_sleepTimer    = 0.0f;

    // Flags
    bool                m_isTrigger     = false;

    // Filtering
    uint32_t            m_layer         = PhysicsLayer::Default;
    uint32_t            m_mask          = PhysicsLayer::All;

    // Geometry
    std::shared_ptr<IShape> m_shape;
    PhysicsMaterial     m_material;
};

} // namespace BADGE2D
