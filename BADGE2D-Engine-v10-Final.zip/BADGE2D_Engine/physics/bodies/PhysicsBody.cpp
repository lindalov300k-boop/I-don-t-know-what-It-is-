// ==============================================================================
// PhysicsBody.cpp — Rigid body dynamics implementation
// ==============================================================================

#include "PhysicsBody.h"
#include <algorithm>
#include <cmath>

namespace BADGE2D {

PhysicsBody::PhysicsBody(BodyID id) : m_id(id) {}

// ==============================================================================
// Type
// ==============================================================================
void PhysicsBody::SetBodyType(BodyType t) {
    m_type = t;
    if (t == BodyType::Static || t == BodyType::Kinematic) {
        m_invMass    = 0.0f;
        m_invInertia = 0.0f;
        m_linearVel  = {};
        m_angularVel = 0.0f;
    } else {
        RecomputeMass();
    }
}

// ==============================================================================
// Transform
// ==============================================================================
void PhysicsBody::SetPosition(const Vector2& pos) {
    m_position = pos;
    WakeUp();
}

void PhysicsBody::SetRotation(float r) {
    m_rotation = r;
    WakeUp();
}

// ==============================================================================
// Forces
// ==============================================================================
void PhysicsBody::ApplyForce(const Vector2& force) {
    if (m_type != BodyType::Dynamic) return;
    m_force += force;
    WakeUp();
}

void PhysicsBody::ApplyForceAtPoint(const Vector2& force, const Vector2& worldPt) {
    if (m_type != BodyType::Dynamic) return;
    m_force  += force;
    m_torque += Vector2::Cross(worldPt - m_position, force);
    WakeUp();
}

void PhysicsBody::ApplyTorque(float t) {
    if (m_type != BodyType::Dynamic) return;
    m_torque += t;
    WakeUp();
}

void PhysicsBody::ApplyImpulse(const Vector2& impulse) {
    if (m_invMass == 0.0f) return;
    m_linearVel += impulse * m_invMass;
    WakeUp();
}

void PhysicsBody::ApplyImpulseAtPoint(const Vector2& impulse, const Vector2& worldPt) {
    if (m_invMass == 0.0f) return;
    m_linearVel  += impulse * m_invMass;
    m_angularVel += m_invInertia * Vector2::Cross(worldPt - m_position, impulse);
    WakeUp();
}

void PhysicsBody::ApplyAngularImpulse(float impulse) {
    if (m_invInertia == 0.0f) return;
    m_angularVel += impulse * m_invInertia;
    WakeUp();
}

void PhysicsBody::ClearForces() {
    m_force  = {};
    m_torque = 0.0f;
}

// ==============================================================================
// Mass
// ==============================================================================
void PhysicsBody::SetMassOverride(float mass) {
    if (m_type != BodyType::Dynamic) return;
    m_mass    = std::max(0.001f, mass);
    m_invMass = 1.0f / m_mass;
    UpdateInertia();
}

void PhysicsBody::RecomputeMass() {
    if (m_type != BodyType::Dynamic) {
        m_invMass = m_invInertia = 0.0f;
        return;
    }
    if (!m_shape) {
        m_mass = m_inertia = 1.0f;
        m_invMass = m_invInertia = 1.0f;
        return;
    }
    float area = m_shape->ComputeArea();
    m_mass    = area * m_material.density;
    m_mass    = std::max(0.001f, m_mass);
    m_invMass = 1.0f / m_mass;
    UpdateInertia();
}

void PhysicsBody::UpdateInertia() {
    if (!m_shape || m_type != BodyType::Dynamic || m_fixedRotation) {
        m_invInertia = 0.0f;
        m_inertia    = 0.0f;
        return;
    }
    m_inertia    = m_shape->ComputeInertia(m_mass);
    m_invInertia = (m_inertia > 0.001f) ? 1.0f / m_inertia : 0.0f;
}

// ==============================================================================
// Shape
// ==============================================================================
void PhysicsBody::SetShape(std::shared_ptr<IShape> shape) {
    m_shape = std::move(shape);
    RecomputeMass();
}

ShapeType PhysicsBody::GetShapeType() const {
    return m_shape ? m_shape->GetType() : ShapeType::Box;
}

AABB PhysicsBody::GetAABB() const {
    if (!m_shape) return AABB(m_position - Vector2(0.5f), m_position + Vector2(0.5f));
    return m_shape->ComputeAABB(m_position, m_rotation);
}

// ==============================================================================
// Sleep
// ==============================================================================
void PhysicsBody::WakeUp() {
    m_sleeping   = false;
    m_sleepTimer = 0.0f;
}

void PhysicsBody::PutToSleep() {
    m_sleeping   = true;
    m_linearVel  = {};
    m_angularVel = 0.0f;
    m_force      = {};
    m_torque     = 0.0f;
}

// ==============================================================================
// Integration (called by PhysicsWorld each step)
// ==============================================================================
void PhysicsBody::IntegrateVelocity(float dt, const Vector2& gravity) {
    if (m_type != BodyType::Dynamic || m_sleeping) return;

    // Apply gravity
    m_linearVel += gravity * m_gravityScale * dt;

    // Apply accumulated forces
    m_linearVel  += m_force  * m_invMass * dt;
    m_angularVel += m_torque * m_invInertia * dt;

    // Linear damping
    float ld = std::pow(1.0f - m_linearDamping,  dt);
    float ad = std::pow(1.0f - m_angularDamping, dt);
    m_linearVel  *= ld;
    m_angularVel *= ad;

    // Clamp angular velocity
    m_angularVel = std::clamp(m_angularVel,
        -PhysicsConst::MAX_ANGULAR_VELOCITY,
         PhysicsConst::MAX_ANGULAR_VELOCITY);

    // Clear accumulated forces
    ClearForces();

    // Sleep check
    float vsq = m_linearVel.LengthSq();
    float asq = m_angularVel * m_angularVel;
    float threshold = PhysicsConst::SLEEP_VELOCITY_THRESHOLD;
    if (vsq < threshold * threshold && asq < threshold * threshold) {
        m_sleepTimer += dt;
        if (m_sleepTimer >= PhysicsConst::SLEEP_TIME_THRESHOLD) PutToSleep();
    } else {
        m_sleepTimer = 0.0f;
    }
}

void PhysicsBody::IntegratePosition(float dt) {
    if (m_type == BodyType::Static || m_sleeping) return;
    m_position += m_linearVel  * dt;
    m_rotation += m_angularVel * dt;
}

} // namespace BADGE2D
