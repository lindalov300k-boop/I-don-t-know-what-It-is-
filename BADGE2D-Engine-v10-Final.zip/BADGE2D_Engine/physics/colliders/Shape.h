#pragma once
// ==============================================================================
// Shape.h — Collider shape geometry (Box, Circle, Polygon, Capsule)
// Shapes are pure geometry — no mass, no transform, no entity.
// ==============================================================================

#include "../PhysicsMath.h"
#include <vector>
#include <memory>

namespace BADGE2D {

// ==============================================================================
// ShapeType
// ==============================================================================
enum class ShapeType : uint8_t {
    Circle  = 0,
    Box     = 1,
    Capsule = 2,
    Polygon = 3
};

// ==============================================================================
// IShape — Abstract shape interface
// ==============================================================================
class IShape {
public:
    virtual ~IShape() = default;

    virtual ShapeType GetType()       const = 0;
    virtual AABB      ComputeAABB  (const Vector2& pos, float angle) const = 0;
    virtual float     ComputeArea  ()                                 const = 0;
    virtual float     ComputeInertia(float mass)                      const = 0;
    virtual Vector2   GetCentroid  ()                                 const = 0;
    virtual Interval  ProjectOnAxis(const Vector2& axis,
                                     const Vector2& pos, float angle) const = 0;
};

// ==============================================================================
// CircleShape
// ==============================================================================
class CircleShape : public IShape {
public:
    float radius = 0.5f;
    Vector2 offset = {};  // Local offset from body center

    explicit CircleShape(float r = 0.5f, const Vector2& off = {}) : radius(r), offset(off) {}

    ShapeType GetType() const override { return ShapeType::Circle; }

    AABB ComputeAABB(const Vector2& pos, float /*angle*/) const override {
        Vector2 center = pos + offset;
        return { center - Vector2(radius), center + Vector2(radius) };
    }

    float ComputeArea() const override { return Math::PI * radius * radius; }

    float ComputeInertia(float mass) const override {
        return 0.5f * mass * radius * radius;
    }

    Vector2 GetCentroid() const override { return offset; }

    Interval ProjectOnAxis(const Vector2& axis, const Vector2& pos, float /*angle*/) const override {
        float center = Vector2::Dot(pos + offset, axis);
        return { center - radius, center + radius };
    }
};

// ==============================================================================
// BoxShape
// ==============================================================================
class BoxShape : public IShape {
public:
    Vector2 halfExtents = { 0.5f, 0.5f };
    Vector2 offset      = {};

    BoxShape() = default;
    BoxShape(float hw, float hh, const Vector2& off = {})
        : halfExtents(hw, hh), offset(off) {}

    static BoxShape FromSize(float w, float h, const Vector2& off = {}) {
        return BoxShape(w * 0.5f, h * 0.5f, off);
    }

    ShapeType GetType() const override { return ShapeType::Box; }

    // Returns 4 world-space corners
    void GetCorners(Vector2 corners[4], const Vector2& pos, float angle) const {
        float c = std::cos(angle);
        float s = std::sin(angle);
        Vector2 hx = { halfExtents.x * c,  halfExtents.x * s };
        Vector2 hy = { halfExtents.y * -s, halfExtents.y * c };
        Vector2 center = pos + offset.Rotated(angle);
        corners[0] = center - hx - hy;
        corners[1] = center + hx - hy;
        corners[2] = center + hx + hy;
        corners[3] = center - hx + hy;
    }

    AABB ComputeAABB(const Vector2& pos, float angle) const override {
        Vector2 corners[4];
        GetCorners(corners, pos, angle);
        AABB box;
        for (auto& c : corners) {
            box.min = Vector2::Min(box.min, c);
            box.max = Vector2::Max(box.max, c);
        }
        return box;
    }

    float ComputeArea() const override {
        return 4.0f * halfExtents.x * halfExtents.y;
    }

    float ComputeInertia(float mass) const override {
        float w = halfExtents.x * 2.0f;
        float h = halfExtents.y * 2.0f;
        return mass * (w*w + h*h) / 12.0f;
    }

    Vector2 GetCentroid() const override { return offset; }

    Interval ProjectOnAxis(const Vector2& axis, const Vector2& pos, float angle) const override {
        Vector2 corners[4];
        GetCorners(corners, pos, angle);
        Interval iv;
        for (auto& c : corners) iv.Extend(Vector2::Dot(c, axis));
        return iv;
    }
};

// ==============================================================================
// CapsuleShape — A box with semicircular caps
// ==============================================================================
class CapsuleShape : public IShape {
public:
    float   height = 1.0f;   // Total height (including caps)
    float   radius = 0.25f;
    Vector2 offset = {};

    CapsuleShape() = default;
    CapsuleShape(float h, float r, const Vector2& off = {})
        : height(h), radius(r), offset(off) {}

    ShapeType GetType() const override { return ShapeType::Capsule; }

    AABB ComputeAABB(const Vector2& pos, float angle) const override {
        Vector2 center = pos + offset.Rotated(angle);
        float halfH = height * 0.5f;
        float c = std::cos(angle), s = std::sin(angle);
        Vector2 up = { -s * halfH, c * halfH };
        AABB box;
        box.min = Vector2::Min(center + up, center - up) - Vector2(radius);
        box.max = Vector2::Max(center + up, center - up) + Vector2(radius);
        return box;
    }

    float ComputeArea() const override {
        float boxH = height - 2.0f * radius;
        return 2.0f * radius * boxH + Math::PI * radius * radius;
    }

    float ComputeInertia(float mass) const override {
        // Approximate as box
        float w = radius * 2.0f, h = height;
        return mass * (w*w + h*h) / 12.0f;
    }

    Vector2 GetCentroid() const override { return offset; }

    Interval ProjectOnAxis(const Vector2& axis,
                            const Vector2& pos, float angle) const override {
        Vector2 center = pos + offset.Rotated(angle);
        float halfH = height * 0.5f - radius;
        float c = std::cos(angle), s = std::sin(angle);
        Vector2 up = { -s * halfH, c * halfH };
        Vector2 p1 = center + up;
        Vector2 p2 = center - up;
        float d1 = Vector2::Dot(p1, axis);
        float d2 = Vector2::Dot(p2, axis);
        return { std::min(d1, d2) - radius, std::max(d1, d2) + radius };
    }
};

// ==============================================================================
// PolygonShape — Convex polygon (up to 8 vertices)
// ==============================================================================
class PolygonShape : public IShape {
public:
    static constexpr int MAX_VERTS = 8;

    std::vector<Vector2> vertices;  // Local space, convex, CCW winding
    std::vector<Vector2> normals;   // Pre-computed face normals
    Vector2              offset = {};

    PolygonShape() = default;

    // Build from a list of points (computes convex hull)
    static PolygonShape FromVertices(const std::vector<Vector2>& pts,
                                      const Vector2& off = {});

    // Regular polygon
    static PolygonShape Regular(int sides, float radius, const Vector2& off = {});

    void ComputeNormals();

    ShapeType GetType() const override { return ShapeType::Polygon; }

    AABB ComputeAABB(const Vector2& pos, float angle) const override {
        AABB box;
        for (auto& v : vertices) {
            Vector2 world = pos + v.Rotated(angle);
            box.min = Vector2::Min(box.min, world);
            box.max = Vector2::Max(box.max, world);
        }
        return box;
    }

    float ComputeArea() const override {
        float area = 0;
        for (size_t i = 0; i < vertices.size(); ++i) {
            auto& a = vertices[i];
            auto& b = vertices[(i + 1) % vertices.size()];
            area += a.x * b.y - b.x * a.y;
        }
        return std::abs(area) * 0.5f;
    }

    float ComputeInertia(float mass) const override {
        // Shoelace + second moment
        float num = 0, den = 0;
        for (size_t i = 0; i < vertices.size(); ++i) {
            auto& p0 = vertices[i];
            auto& p1 = vertices[(i + 1) % vertices.size()];
            float cross = std::abs(p0.Cross(p1));
            num += cross * (p0.Dot(p0) + p0.Dot(p1) + p1.Dot(p1));
            den += cross;
        }
        return (den > 0) ? mass * num / (6.0f * den) : 1.0f;
    }

    Vector2 GetCentroid() const override {
        Vector2 c;
        for (auto& v : vertices) c += v;
        return c * (1.0f / vertices.size()) + offset;
    }

    Interval ProjectOnAxis(const Vector2& axis,
                            const Vector2& pos, float angle) const override {
        Interval iv;
        for (auto& v : vertices) {
            float d = Vector2::Dot(pos + v.Rotated(angle), axis);
            iv.Extend(d);
        }
        return iv;
    }
};

} // namespace BADGE2D
