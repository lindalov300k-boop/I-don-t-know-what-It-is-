// ==============================================================================
// Shape.cpp — PolygonShape construction and convex hull
// ==============================================================================

#include "Shape.h"
#include <algorithm>
#include <cstring>

namespace BADGE2D {

// ==============================================================================
// Gift-wrap convex hull
// ==============================================================================
static std::vector<Vector2> ConvexHull(std::vector<Vector2> pts) {
    int n = (int)pts.size();
    if (n < 3) return pts;

    // Find leftmost point
    int pivot = 0;
    for (int i = 1; i < n; ++i)
        if (pts[i].x < pts[pivot].x ||
            (pts[i].x == pts[pivot].x && pts[i].y < pts[pivot].y))
            pivot = i;

    std::vector<Vector2> hull;
    int current = pivot;

    do {
        hull.push_back(pts[current]);
        int next = (current + 1) % n;
        for (int i = 0; i < n; ++i) {
            float cross = Vector2::Cross(pts[next] - pts[current], pts[i] - pts[current]);
            if (cross < 0) next = i;
        }
        current = next;
    } while (current != pivot && hull.size() <= (size_t)PolygonShape::MAX_VERTS);

    return hull;
}

PolygonShape PolygonShape::FromVertices(const std::vector<Vector2>& pts,
                                          const Vector2& off) {
    PolygonShape s;
    s.offset   = off;
    s.vertices = ConvexHull(pts);
    // Truncate to max verts
    if (s.vertices.size() > MAX_VERTS) s.vertices.resize(MAX_VERTS);
    s.ComputeNormals();
    return s;
}

PolygonShape PolygonShape::Regular(int sides, float radius, const Vector2& off) {
    sides = std::clamp(sides, 3, MAX_VERTS);
    std::vector<Vector2> pts;
    pts.reserve(sides);
    float step = Math::TAU / sides;
    for (int i = 0; i < sides; ++i) {
        float a = step * i;
        pts.push_back({ radius * std::cos(a), radius * std::sin(a) });
    }
    return FromVertices(pts, off);
}

void PolygonShape::ComputeNormals() {
    normals.clear();
    normals.reserve(vertices.size());
    for (size_t i = 0; i < vertices.size(); ++i) {
        Vector2 edge = vertices[(i + 1) % vertices.size()] - vertices[i];
        normals.push_back(Vector2{ edge.y, -edge.x }.Normalized());
    }
}

} // namespace BADGE2D
