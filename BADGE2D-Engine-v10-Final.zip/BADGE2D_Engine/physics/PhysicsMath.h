#pragma once
// ==============================================================================
// PhysicsMath.h — Shapes, manifolds, and math primitives for the physics engine
// ==============================================================================

#include "../utilities/Math/MathUtils.h"
#include <cmath>
#include <cfloat>
#include <algorithm>
#include <string>

namespace BADGE2D {

// ==============================================================================
// AABB — Axis-Aligned Bounding Box (used everywhere for broadphase)
// ==============================================================================
struct AABB {
    Vector2 min = {  FLT_MAX,  FLT_MAX };
    Vector2 max = { -FLT_MAX, -FLT_MAX };

    AABB() = default;
    AABB(const Vector2& mn, const Vector2& mx) : min(mn), max(mx) {}
    AABB(float x, float y, float w, float h)
        : min(x, y), max(x + w, y + h) {}

    static AABB FromCenter(const Vector2& center, const Vector2& halfExtents) {
        return { center - halfExtents, center + halfExtents };
    }

    Vector2 Center()      const { return (min + max) * 0.5f; }
    Vector2 HalfExtents() const { return (max - min) * 0.5f; }
    Vector2 Size()        const { return max - min; }
    float   Width()       const { return max.x - min.x; }
    float   Height()      const { return max.y - min.y; }
    float   Area()        const { return Width() * Height(); }
    float   Perimeter()   const { return 2.0f * (Width() + Height()); }

    bool Overlaps(const AABB& o) const {
        return min.x <= o.max.x && max.x >= o.min.x
            && min.y <= o.max.y && max.y >= o.min.y;
    }
    bool Contains(const Vector2& p) const {
        return p.x >= min.x && p.x <= max.x
            && p.y >= min.y && p.y <= max.y;
    }
    bool Contains(const AABB& o) const {
        return o.min.x >= min.x && o.max.x <= max.x
            && o.min.y >= min.y && o.max.y <= max.y;
    }

    AABB Expanded(float amount) const {
        return { min - Vector2(amount), max + Vector2(amount) };
    }
    AABB Merged(const AABB& o) const {
        return { Vector2::Min(min, o.min), Vector2::Max(max, o.max) };
    }

    bool IsValid() const { return min.x <= max.x && min.y <= max.y; }

    std::string ToString() const {
        char buf[128];
        std::snprintf(buf, sizeof(buf),
            "AABB[min=(%.2f,%.2f) max=(%.2f,%.2f)]",
            min.x, min.y, max.x, max.y);
        return buf;
    }
};

// ==============================================================================
// CollisionManifold — Result of a narrow-phase collision test
// ==============================================================================
struct CollisionManifold {
    bool    hasCollision    = false;
    Vector2 normal          = {};     // Points from B toward A (separating normal)
    float   penetration     = 0.0f;  // Overlap depth
    Vector2 contactPoint    = {};    // World-space contact point
    Vector2 contactPoint2   = {};    // Second contact (for edge-edge)
    int     contactCount    = 0;

    // Flip normal direction
    CollisionManifold Flipped() const {
        CollisionManifold m = *this;
        m.normal = -m.normal;
        return m;
    }
};

// ==============================================================================
// Interval — 1D projection interval used by SAT
// ==============================================================================
struct Interval {
    float min =  FLT_MAX;
    float max = -FLT_MAX;

    void Extend(float v) {
        if (v < min) min = v;
        if (v > max) max = v;
    }

    float Overlap(const Interval& o) const {
        return std::min(max, o.max) - std::max(min, o.min);
    }

    bool Overlaps(const Interval& o) const {
        return min <= o.max && max >= o.min;
    }
};

// ==============================================================================
// RaycastHit — Result of a ray query
// ==============================================================================
struct RaycastHit {
    bool    hit         = false;
    float   distance    = FLT_MAX;
    Vector2 point       = {};
    Vector2 normal      = {};
    uint32_t bodyID     = 0;      // Which body was hit
    bool    isTrigger   = false;
};

// ==============================================================================
// PhysicsLayer — Bitmask collision filtering
// ==============================================================================
namespace PhysicsLayer {
    constexpr uint32_t Default  = (1 << 0);
    constexpr uint32_t Player   = (1 << 1);
    constexpr uint32_t Enemy    = (1 << 2);
    constexpr uint32_t Ground   = (1 << 3);
    constexpr uint32_t Trigger  = (1 << 4);
    constexpr uint32_t Projectile = (1 << 5);
    constexpr uint32_t All      = 0xFFFFFFFF;
    constexpr uint32_t None     = 0;
}

// ==============================================================================
// Physics constants
// ==============================================================================
namespace PhysicsConst {
    constexpr float SLEEP_VELOCITY_THRESHOLD = 0.5f;   // Units/s
    constexpr float SLEEP_TIME_THRESHOLD     = 0.5f;   // Seconds
    constexpr float CONTACT_SLOP             = 0.01f;  // Penetration allowance
    constexpr float BAUMGARTE_FACTOR         = 0.2f;   // Position correction
    constexpr float RESTITUTION_THRESHOLD    = 1.0f;   // Min velocity for bounce
    constexpr float MAX_ANGULAR_VELOCITY     = 50.0f;  // Rad/s
    constexpr int   VELOCITY_ITERATIONS      = 10;
    constexpr int   POSITION_ITERATIONS      = 3;
}

} // namespace BADGE2D
