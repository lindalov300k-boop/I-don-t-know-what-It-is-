// ==============================================================================
// Broadphase.cpp
// ==============================================================================

#include "Broadphase.h"
#include <algorithm>

namespace BADGE2D {

// ==============================================================================
// BroadphaseAABB
// ==============================================================================
void BroadphaseAABB::Remove(PhysicsBody* b) {
    m_bodies.erase(std::remove(m_bodies.begin(), m_bodies.end(), b), m_bodies.end());
}

void BroadphaseAABB::QueryPairs(std::vector<BroadphasePair>& out) const {
    for (size_t i = 0; i < m_bodies.size(); ++i) {
        for (size_t j = i + 1; j < m_bodies.size(); ++j) {
            PhysicsBody* a = m_bodies[i];
            PhysicsBody* b = m_bodies[j];

            // Skip static-static pairs
            if (a->GetBodyType() == BodyType::Static &&
                b->GetBodyType() == BodyType::Static) continue;

            // Layer filter
            if (!a->CanCollideWith(*b)) continue;

            // Skip both sleeping
            if (a->IsSleeping() && b->IsSleeping()) continue;

            if (a->GetAABB().Overlaps(b->GetAABB()))
                out.push_back({a, b});
        }
    }
}

void BroadphaseAABB::QueryAABB(const AABB& q, std::vector<PhysicsBody*>& out) const {
    for (auto* b : m_bodies)
        if (b->GetAABB().Overlaps(q)) out.push_back(b);
}

// ==============================================================================
// BroadphaseSpatialHash
// ==============================================================================
BroadphaseSpatialHash::BroadphaseSpatialHash(float cellSize) {
    SetCellSize(cellSize);
}

void BroadphaseSpatialHash::SetCellSize(float size) {
    m_cellSize    = std::max(1.0f, size);
    m_invCellSize = 1.0f / m_cellSize;
}

void BroadphaseSpatialHash::Clear() {
    m_cells.clear();
    m_bodyToCells.clear();
}

void BroadphaseSpatialHash::Insert(PhysicsBody* b) {
    AABB aabb = b->GetAABB();
    Vector2i minC = WorldToCell(aabb.min);
    Vector2i maxC = WorldToCell(aabb.max);

    std::vector<CellKey> keys;
    for (int y = minC.y; y <= maxC.y; ++y) {
        for (int x = minC.x; x <= maxC.x; ++x) {
            CellKey key = Hash(x, y);
            m_cells[key].push_back(b);
            keys.push_back(key);
        }
    }
    m_bodyToCells[b] = std::move(keys);
}

void BroadphaseSpatialHash::Remove(PhysicsBody* b) {
    auto it = m_bodyToCells.find(b);
    if (it == m_bodyToCells.end()) return;

    for (auto key : it->second) {
        auto& cell = m_cells[key];
        cell.erase(std::remove(cell.begin(), cell.end(), b), cell.end());
        if (cell.empty()) m_cells.erase(key);
    }
    m_bodyToCells.erase(it);
}

void BroadphaseSpatialHash::Update(PhysicsBody* b) {
    Remove(b);
    Insert(b);
}

void BroadphaseSpatialHash::QueryPairs(std::vector<BroadphasePair>& out) const {
    // Use a set to avoid duplicate pairs
    std::unordered_set<uint64_t> seen;

    for (auto& [key, cell] : m_cells) {
        for (size_t i = 0; i < cell.size(); ++i) {
            for (size_t j = i + 1; j < cell.size(); ++j) {
                PhysicsBody* a = cell[i];
                PhysicsBody* b = cell[j];

                // Stable pair hash (order-independent)
                uintptr_t pa = reinterpret_cast<uintptr_t>(a);
                uintptr_t pb = reinterpret_cast<uintptr_t>(b);
                uint64_t  pairHash = (pa < pb)
                    ? (pa << 32 | pb) : (pb << 32 | pa);

                if (!seen.insert(pairHash).second) continue;

                if (a->GetBodyType() == BodyType::Static &&
                    b->GetBodyType() == BodyType::Static) continue;
                if (!a->CanCollideWith(*b)) continue;
                if (a->IsSleeping() && b->IsSleeping()) continue;

                if (a->GetAABB().Overlaps(b->GetAABB()))
                    out.push_back({a, b});
            }
        }
    }
}

void BroadphaseSpatialHash::QueryAABB(const AABB& q, std::vector<PhysicsBody*>& out) const {
    Vector2i minC = WorldToCell(q.min);
    Vector2i maxC = WorldToCell(q.max);

    std::unordered_set<PhysicsBody*> seen;
    for (int y = minC.y; y <= maxC.y; ++y) {
        for (int x = minC.x; x <= maxC.x; ++x) {
            auto it = m_cells.find(Hash(x, y));
            if (it == m_cells.end()) continue;
            for (auto* b : it->second) {
                if (seen.insert(b).second && b->GetAABB().Overlaps(q))
                    out.push_back(b);
            }
        }
    }
}

void BroadphaseSpatialHash::QueryPoint(const Vector2& pt, std::vector<PhysicsBody*>& out) const {
    Vector2i c = WorldToCell(pt);
    auto it = m_cells.find(Hash(c.x, c.y));
    if (it == m_cells.end()) return;
    for (auto* b : it->second)
        if (b->GetAABB().Contains(pt)) out.push_back(b);
}

} // namespace BADGE2D
