#pragma once
// ==============================================================================
// NarrowPhase.h — SAT-based narrow phase collision detection
// Handles: Circle-Circle, Circle-Box, Box-Box, Circle-Capsule, Box-Capsule,
//          Polygon-Polygon, Circle-Polygon, Box-Polygon
// ==============================================================================

#include "../PhysicsMath.h"
#include "../bodies/PhysicsBody.h"
#include "../colliders/Shape.h"

namespace BADGE2D {

// ==============================================================================
// NarrowPhase — Stateless narrow-phase dispatcher
// ==============================================================================
class NarrowPhase {
public:
    // Main entry: dispatch to correct test based on shape types
    static CollisionManifold Test(const PhysicsBody& a, const PhysicsBody& b);

    // Individual tests (public for unit testing)
    static CollisionManifold CircleVsCircle(
        const CircleShape& a, const Vector2& posA,
        const CircleShape& b, const Vector2& posB);

    static CollisionManifold CircleVsBox(
        const CircleShape& circle, const Vector2& posC, float rotC,
        const BoxShape&    box,    const Vector2& posB, float rotB);

    static CollisionManifold BoxVsBox(
        const BoxShape& a, const Vector2& posA, float rotA,
        const BoxShape& b, const Vector2& posB, float rotB);

    static CollisionManifold CircleVsCapsule(
        const CircleShape&  circle,  const Vector2& posC,
        const CapsuleShape& capsule, const Vector2& posK, float rotK);

    static CollisionManifold CapsuleVsCapsule(
        const CapsuleShape& a, const Vector2& posA, float rotA,
        const CapsuleShape& b, const Vector2& posB, float rotB);

    static CollisionManifold PolygonVsPolygon(
        const PolygonShape& a, const Vector2& posA, float rotA,
        const PolygonShape& b, const Vector2& posB, float rotB);

    static CollisionManifold CircleVsPolygon(
        const CircleShape&  circle, const Vector2& posC,
        const PolygonShape& poly,   const Vector2& posP, float rotP);

    // Raycast
    static bool RaycastCircle (const Vector2& origin, const Vector2& dir, float maxDist,
                                const CircleShape& circle, const Vector2& circlePos,
                                RaycastHit& hit);

    static bool RaycastBox    (const Vector2& origin, const Vector2& dir, float maxDist,
                                const BoxShape& box, const Vector2& boxPos, float boxRot,
                                RaycastHit& hit);

    static bool RaycastCapsule(const Vector2& origin, const Vector2& dir, float maxDist,
                                const CapsuleShape& caps, const Vector2& pos, float rot,
                                RaycastHit& hit);

private:
    // SAT helper: find minimum penetration axis for a polygon pair
    struct SATResult {
        float   penetration = FLT_MAX;
        Vector2 normal;
        bool    isValid = false;
    };

    static SATResult SATQueryFaceAxes(
        const PolygonShape& a, const Vector2& posA, float rotA,
        const PolygonShape& b, const Vector2& posB, float rotB);

    // Closest point on a line segment to a point
    static Vector2 ClosestPointOnSegment(const Vector2& a, const Vector2& b, const Vector2& p);

    // Clip polygon against a plane
    static int ClipSegmentToLine(Vector2 out[2],
                                  const Vector2 in[2],
                                  const Vector2& normal,
                                  float          offset);
};

} // namespace BADGE2D
