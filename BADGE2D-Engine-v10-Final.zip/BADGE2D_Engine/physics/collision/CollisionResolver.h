#pragma once
// ==============================================================================
// CollisionResolver.h — Impulse-based collision resolution with friction
// Implements Sequential Impulse (SI) solver — same algorithm as Box2D.
// ==============================================================================

#include "../PhysicsMath.h"
#include "../bodies/PhysicsBody.h"
#include <vector>

namespace BADGE2D {

// ==============================================================================
// ContactConstraint — One contact manifold between two bodies
// ==============================================================================
struct ContactConstraint {
    PhysicsBody*       bodyA         = nullptr;
    PhysicsBody*       bodyB         = nullptr;
    CollisionManifold  manifold;

    // Pre-computed per-contact data (Warm-starting)
    float  normalImpulseAccum   = 0.0f;
    float  tangentImpulseAccum  = 0.0f;
    float  normalMass           = 0.0f;  // Effective mass along normal
    float  tangentMass          = 0.0f;  // Effective mass along tangent
    float  restitutionBias      = 0.0f;
    float  positionBias         = 0.0f;  // Baumgarte

    // Combined material properties
    float  friction             = 0.4f;
    float  restitution          = 0.2f;
};

// ==============================================================================
// CollisionResolver — Iterative impulse solver
// ==============================================================================
class CollisionResolver {
public:
    // Resolve a set of contact constraints
    // velocityIterations: number of velocity correction passes (default 10)
    // positionIterations: number of position correction passes (default 3)
    static void Resolve(std::vector<ContactConstraint>& contacts,
                        int velocityIterations = PhysicsConst::VELOCITY_ITERATIONS,
                        int positionIterations = PhysicsConst::POSITION_ITERATIONS);

private:
    // Pre-solve: compute effective masses, biases, warm-start
    static void PreSolve(ContactConstraint& c, float dt);

    // One velocity iteration
    static void SolveVelocity(ContactConstraint& c);

    // One position correction iteration (Baumgarte / pseudo-velocity)
    static void SolvePosition(ContactConstraint& c);

    // Combine two material properties (geometric mean for friction, max for restitution)
    static float CombineFriction   (float a, float b) { return std::sqrt(a * b); }
    static float CombineRestitution(float a, float b) { return std::max(a, b); }
};

} // namespace BADGE2D
