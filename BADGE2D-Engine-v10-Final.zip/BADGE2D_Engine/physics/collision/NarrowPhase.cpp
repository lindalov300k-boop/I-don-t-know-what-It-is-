// ==============================================================================
// NarrowPhase.cpp — SAT + GJK narrow phase implementation
// ==============================================================================

#include "NarrowPhase.h"
#include <cmath>
#include <cfloat>
#include <algorithm>

namespace BADGE2D {

// ==============================================================================
// Dispatcher
// ==============================================================================
CollisionManifold NarrowPhase::Test(const PhysicsBody& a, const PhysicsBody& b) {
    IShape* sa = a.GetShape();
    IShape* sb = b.GetShape();
    if (!sa || !sb) return {};

    ShapeType ta = sa->GetType();
    ShapeType tb = sb->GetType();

    // Normalise order: Circle < Box < Capsule < Polygon
    if ((int)ta > (int)tb) {
        auto m = Test(b, a);
        m.normal = -m.normal;
        return m;
    }

    Vector2 pa = a.GetPosition(), pb = b.GetPosition();
    float   ra = a.GetRotation(), rb = b.GetRotation();

    if (ta == ShapeType::Circle && tb == ShapeType::Circle)
        return CircleVsCircle(
            *static_cast<CircleShape*>(sa), pa,
            *static_cast<CircleShape*>(sb), pb);

    if (ta == ShapeType::Circle && tb == ShapeType::Box)
        return CircleVsBox(
            *static_cast<CircleShape*>(sa), pa, ra,
            *static_cast<BoxShape*>(sb),    pb, rb);

    if (ta == ShapeType::Box && tb == ShapeType::Box)
        return BoxVsBox(
            *static_cast<BoxShape*>(sa), pa, ra,
            *static_cast<BoxShape*>(sb), pb, rb);

    if (ta == ShapeType::Circle && tb == ShapeType::Capsule)
        return CircleVsCapsule(
            *static_cast<CircleShape*>(sa),  pa,
            *static_cast<CapsuleShape*>(sb), pb, rb);

    if (ta == ShapeType::Capsule && tb == ShapeType::Capsule)
        return CapsuleVsCapsule(
            *static_cast<CapsuleShape*>(sa), pa, ra,
            *static_cast<CapsuleShape*>(sb), pb, rb);

    if (ta == ShapeType::Polygon && tb == ShapeType::Polygon)
        return PolygonVsPolygon(
            *static_cast<PolygonShape*>(sa), pa, ra,
            *static_cast<PolygonShape*>(sb), pb, rb);

    if (ta == ShapeType::Circle && tb == ShapeType::Polygon)
        return CircleVsPolygon(
            *static_cast<CircleShape*>(sa),  pa,
            *static_cast<PolygonShape*>(sb), pb, rb);

    // Box vs Polygon: treat box as polygon
    if (ta == ShapeType::Box && tb == ShapeType::Polygon) {
        const BoxShape& box = *static_cast<BoxShape*>(sa);
        PolygonShape bpoly;
        bpoly.vertices = {
            {-box.halfExtents.x, -box.halfExtents.y},
            { box.halfExtents.x, -box.halfExtents.y},
            { box.halfExtents.x,  box.halfExtents.y},
            {-box.halfExtents.x,  box.halfExtents.y}
        };
        bpoly.offset = box.offset;
        bpoly.ComputeNormals();
        return PolygonVsPolygon(bpoly, pa, ra,
            *static_cast<PolygonShape*>(sb), pb, rb);
    }

    return {};
}

// ==============================================================================
// Circle vs Circle
// ==============================================================================
CollisionManifold NarrowPhase::CircleVsCircle(
    const CircleShape& a, const Vector2& posA,
    const CircleShape& b, const Vector2& posB)
{
    Vector2 cA = posA + a.offset;
    Vector2 cB = posB + b.offset;
    Vector2 d  = cB - cA;
    float   distSq = d.LengthSq();
    float   radSum = a.radius + b.radius;

    if (distSq >= radSum * radSum) return {};

    CollisionManifold m;
    m.hasCollision = true;
    float dist = std::sqrt(distSq);

    if (dist < 1e-6f) {
        m.normal       = {0, 1};
        m.penetration  = radSum;
        m.contactPoint = cA;
    } else {
        m.normal       = d * (1.0f / dist);
        m.penetration  = radSum - dist;
        m.contactPoint = cA + m.normal * a.radius;
    }
    m.contactCount = 1;
    return m;
}

// ==============================================================================
// Closest point on segment
// ==============================================================================
Vector2 NarrowPhase::ClosestPointOnSegment(const Vector2& a, const Vector2& b, const Vector2& p) {
    Vector2 ab = b - a;
    float   t  = Vector2::Dot(p - a, ab);
    float   denom = ab.LengthSq();
    if (denom < 1e-8f) return a;
    t = std::clamp(t / denom, 0.0f, 1.0f);
    return a + ab * t;
}

// ==============================================================================
// Circle vs Box
// ==============================================================================
CollisionManifold NarrowPhase::CircleVsBox(
    const CircleShape& circle, const Vector2& posC, float /*rotC*/,
    const BoxShape&    box,    const Vector2& posB, float rotB)
{
    // Transform circle center to box local space
    Vector2 worldCenter = posC + circle.offset;
    Vector2 delta       = worldCenter - (posB + box.offset.Rotated(rotB));

    float cosA = std::cos(-rotB);
    float sinA = std::sin(-rotB);
    Vector2 local = {
        delta.x * cosA - delta.y * sinA,
        delta.x * sinA + delta.y * cosA
    };

    Vector2 he   = box.halfExtents;
    Vector2 closest = {
        std::clamp(local.x, -he.x, he.x),
        std::clamp(local.y, -he.y, he.y)
    };

    bool inside = (local.x > -he.x && local.x < he.x &&
                   local.y > -he.y && local.y < he.y);

    Vector2 diff = local - closest;
    float   distSq = diff.LengthSq();
    float   r = circle.radius;

    if (!inside && distSq >= r * r) return {};

    CollisionManifold m;
    m.hasCollision = true;
    m.contactCount = 1;

    Vector2 localNormal;
    float   pen;

    if (inside) {
        // Push out along smallest axis
        float dx = he.x - std::abs(local.x);
        float dy = he.y - std::abs(local.y);
        if (dx < dy) {
            pen = dx + r;
            localNormal = {local.x > 0 ? 1.0f : -1.0f, 0};
        } else {
            pen = dy + r;
            localNormal = {0, local.y > 0 ? 1.0f : -1.0f};
        }
    } else {
        float dist = std::sqrt(distSq);
        pen = r - dist;
        localNormal = diff * (dist > 1e-6f ? 1.0f / dist : 1.0f);
    }

    // Rotate normal back to world space
    m.normal = {
        localNormal.x * std::cos(rotB) - localNormal.y * std::sin(rotB),
        localNormal.x * std::sin(rotB) + localNormal.y * std::cos(rotB)
    };
    m.penetration  = pen;
    m.contactPoint = worldCenter - m.normal * r;
    return m;
}

// ==============================================================================
// Box vs Box (SAT)
// ==============================================================================
CollisionManifold NarrowPhase::BoxVsBox(
    const BoxShape& a, const Vector2& posA, float rotA,
    const BoxShape& b, const Vector2& posB, float rotB)
{
    Vector2 cornersA[4], cornersB[4];
    a.GetCorners(cornersA, posA, rotA);
    b.GetCorners(cornersB, posB, rotB);

    // Test axes: 2 from A, 2 from B
    Vector2 axes[4];
    float cA = std::cos(rotA), sA = std::sin(rotA);
    float cB = std::cos(rotB), sB = std::sin(rotB);
    axes[0] = { cA, sA };  axes[1] = {-sA, cA };
    axes[2] = { cB, sB };  axes[3] = {-sB, cB };

    float minPen = FLT_MAX;
    Vector2 bestNormal;

    for (auto& axis : axes) {
        Interval ivA, ivB;
        for (auto& c : cornersA) ivA.Extend(Vector2::Dot(c, axis));
        for (auto& c : cornersB) ivB.Extend(Vector2::Dot(c, axis));

        float pen = ivA.Overlap(ivB);
        if (pen <= 0) return {};  // Separating axis found

        if (pen < minPen) {
            minPen   = pen;
            bestNormal = axis;
        }
    }

    // Ensure normal points from B to A
    Vector2 d = (posB + b.offset.Rotated(rotB)) - (posA + a.offset.Rotated(rotA));
    if (Vector2::Dot(bestNormal, d) < 0) bestNormal = -bestNormal;

    CollisionManifold m;
    m.hasCollision = true;
    m.normal       = bestNormal;
    m.penetration  = minPen;
    m.contactCount = 1;

    // Approximate contact point
    m.contactPoint = posA + a.offset.Rotated(rotA) + bestNormal * a.halfExtents.Length();
    return m;
}

// ==============================================================================
// Circle vs Capsule
// ==============================================================================
CollisionManifold NarrowPhase::CircleVsCapsule(
    const CircleShape&  circle,  const Vector2& posC,
    const CapsuleShape& capsule, const Vector2& posK, float rotK)
{
    Vector2 circCenter = posC + circle.offset;
    float   halfH = capsule.height * 0.5f - capsule.radius;

    // Capsule axis endpoints
    Vector2 dir  = Vector2{0, 1}.Rotated(rotK);
    Vector2 kCenter = posK + capsule.offset.Rotated(rotK);
    Vector2 p1   = kCenter + dir * halfH;
    Vector2 p2   = kCenter - dir * halfH;

    Vector2 closest = ClosestPointOnSegment(p1, p2, circCenter);
    float   totalR  = circle.radius + capsule.radius;
    Vector2 d       = circCenter - closest;
    float   distSq  = d.LengthSq();

    if (distSq >= totalR * totalR) return {};

    CollisionManifold m;
    m.hasCollision = true;
    m.contactCount = 1;

    float dist = std::sqrt(distSq);
    if (dist < 1e-6f) {
        m.normal = {0, 1};
        m.penetration = totalR;
    } else {
        m.normal = d * (1.0f / dist);
        m.penetration = totalR - dist;
    }
    m.contactPoint = closest;
    return m;
}

// ==============================================================================
// Capsule vs Capsule
// ==============================================================================
CollisionManifold NarrowPhase::CapsuleVsCapsule(
    const CapsuleShape& a, const Vector2& posA, float rotA,
    const CapsuleShape& b, const Vector2& posB, float rotB)
{
    auto getEndpoints = [](const CapsuleShape& c, const Vector2& pos, float rot,
                            Vector2& p1, Vector2& p2) {
        float hh  = c.height * 0.5f - c.radius;
        Vector2 dir = Vector2{0, 1}.Rotated(rot);
        Vector2 center = pos + c.offset.Rotated(rot);
        p1 = center + dir * hh;
        p2 = center - dir * hh;
    };

    Vector2 a1, a2, b1, b2;
    getEndpoints(a, posA, rotA, a1, a2);
    getEndpoints(b, posB, rotB, b1, b2);

    // Find closest points between two segments
    Vector2 d1 = a2 - a1;
    Vector2 d2 = b2 - b1;
    Vector2 r  = a1 - b1;
    float   e  = d2.LengthSq();
    float   f  = Vector2::Dot(d2, r);
    float   s, t;

    float c2 = d1.LengthSq();
    if (c2 < 1e-8f) {
        s = 0.0f;
        t = (e > 1e-8f) ? std::clamp(f / e, 0.0f, 1.0f) : 0.0f;
    } else {
        float b2d = Vector2::Dot(d1, r);
        if (e < 1e-8f) {
            t = 0.0f;
            s = std::clamp(-b2d / c2, 0.0f, 1.0f);
        } else {
            float denom = c2 * e - Vector2::Dot(d1, d2) * Vector2::Dot(d1, d2);
            if (std::abs(denom) > 1e-8f) {
                s = std::clamp((Vector2::Dot(d1, d2) * f - b2d * e) / denom, 0.0f, 1.0f);
            } else {
                s = 0.0f;
            }
            t = std::clamp((Vector2::Dot(d1, d2) * s + f) / e, 0.0f, 1.0f);
            s = std::clamp((t * Vector2::Dot(d1, d2) - b2d) / c2, 0.0f, 1.0f);
        }
    }

    Vector2 pa = a1 + d1 * s;
    Vector2 pb = b1 + d2 * t;

    float totalR = a.radius + b.radius;
    Vector2 d    = pa - pb;
    float   dist = d.Length();
    if (dist >= totalR) return {};

    CollisionManifold m;
    m.hasCollision = true;
    m.contactCount = 1;
    m.normal       = (dist > 1e-6f) ? d * (1.0f / dist) : Vector2{0,1};
    m.penetration  = totalR - dist;
    m.contactPoint = pb + m.normal * b.radius;
    return m;
}

// ==============================================================================
// SAT helper for polygon faces
// ==============================================================================
NarrowPhase::SATResult NarrowPhase::SATQueryFaceAxes(
    const PolygonShape& a, const Vector2& posA, float rotA,
    const PolygonShape& b, const Vector2& posB, float rotB)
{
    SATResult best;
    best.penetration = -FLT_MAX;

    for (size_t i = 0; i < a.normals.size(); ++i) {
        Vector2 worldNormal = a.normals[i].Rotated(rotA);
        Interval ivA = a.ProjectOnAxis(worldNormal, posA, rotA);
        Interval ivB = b.ProjectOnAxis(worldNormal, posB, rotB);
        float pen = ivA.Overlap(ivB);
        if (pen <= 0) { best.isValid = false; return best; }
        if (pen > best.penetration) {
            best.penetration = pen;
            best.normal      = worldNormal;
        }
    }
    best.isValid = true;
    return best;
}

// ==============================================================================
// Polygon vs Polygon (SAT)
// ==============================================================================
CollisionManifold NarrowPhase::PolygonVsPolygon(
    const PolygonShape& a, const Vector2& posA, float rotA,
    const PolygonShape& b, const Vector2& posB, float rotB)
{
    SATResult fA = SATQueryFaceAxes(a, posA, rotA, b, posB, rotB);
    if (!fA.isValid) return {};

    SATResult fB = SATQueryFaceAxes(b, posB, rotB, a, posA, rotA);
    if (!fB.isValid) return {};

    CollisionManifold m;
    m.hasCollision = true;
    m.contactCount = 1;

    // Pick smallest penetration
    if (fA.penetration < fB.penetration) {
        m.penetration = fA.penetration;
        m.normal      = fA.normal;
    } else {
        m.penetration = fB.penetration;
        m.normal      = fB.normal;
    }

    // Ensure normal from B to A
    Vector2 d = posB - posA;
    if (Vector2::Dot(m.normal, d) < 0) m.normal = -m.normal;

    m.contactPoint = posA + m.normal * m.penetration;
    return m;
}

// ==============================================================================
// Circle vs Polygon (SAT)
// ==============================================================================
CollisionManifold NarrowPhase::CircleVsPolygon(
    const CircleShape&  circle, const Vector2& posC,
    const PolygonShape& poly,   const Vector2& posP, float rotP)
{
    Vector2 circWorld = posC + circle.offset;

    float   minPen = FLT_MAX;
    Vector2 bestNormal;

    for (size_t i = 0; i < poly.normals.size(); ++i) {
        Vector2 n    = poly.normals[i].Rotated(rotP);
        Interval ivP = poly.ProjectOnAxis(n, posP, rotP);
        float cProj  = Vector2::Dot(circWorld, n);
        Interval ivC = { cProj - circle.radius, cProj + circle.radius };
        float pen = ivC.Overlap(ivP);
        if (pen <= 0) return {};
        if (pen < minPen) { minPen = pen; bestNormal = n; }
    }

    // Also test axis from polygon vertices to circle center
    for (auto& v : poly.vertices) {
        Vector2 worldV = posP + v.Rotated(rotP);
        Vector2 axis   = (circWorld - worldV).Normalized();
        if (axis.IsZero()) continue;

        Interval ivP = poly.ProjectOnAxis(axis, posP, rotP);
        float cProj  = Vector2::Dot(circWorld, axis);
        Interval ivC = { cProj - circle.radius, cProj + circle.radius };
        float pen = ivC.Overlap(ivP);
        if (pen <= 0) return {};
        if (pen < minPen) { minPen = pen; bestNormal = axis; }
    }

    Vector2 d = posP - circWorld;
    if (Vector2::Dot(bestNormal, d) < 0) bestNormal = -bestNormal;

    CollisionManifold m;
    m.hasCollision  = true;
    m.normal        = bestNormal;
    m.penetration   = minPen;
    m.contactPoint  = circWorld + bestNormal * circle.radius;
    m.contactCount  = 1;
    return m;
}

// ==============================================================================
// Raycasts
// ==============================================================================
bool NarrowPhase::RaycastCircle(const Vector2& origin, const Vector2& dir, float maxDist,
                                  const CircleShape& circle, const Vector2& circlePos,
                                  RaycastHit& hit)
{
    Vector2 oc = origin - (circlePos + circle.offset);
    float a = dir.LengthSq();
    float b = 2.0f * Vector2::Dot(oc, dir);
    float c = oc.LengthSq() - circle.radius * circle.radius;
    float disc = b * b - 4.0f * a * c;
    if (disc < 0) return false;

    float t = (-b - std::sqrt(disc)) / (2.0f * a);
    if (t < 0 || t > maxDist) {
        t = (-b + std::sqrt(disc)) / (2.0f * a);
        if (t < 0 || t > maxDist) return false;
    }

    hit.hit      = true;
    hit.distance = t;
    hit.point    = origin + dir * t;
    hit.normal   = (hit.point - (circlePos + circle.offset)).Normalized();
    return true;
}

bool NarrowPhase::RaycastBox(const Vector2& origin, const Vector2& dir, float maxDist,
                               const BoxShape& box, const Vector2& boxPos, float boxRot,
                               RaycastHit& hit)
{
    // Transform ray to box local space
    float cosA = std::cos(-boxRot), sinA = std::sin(-boxRot);
    Vector2 localOrigin = {
        (origin.x - boxPos.x) * cosA - (origin.y - boxPos.y) * sinA,
        (origin.x - boxPos.x) * sinA + (origin.y - boxPos.y) * cosA
    };
    Vector2 localDir = {
        dir.x * cosA - dir.y * sinA,
        dir.x * sinA + dir.y * cosA
    };

    float tMin = 0.0f, tMax = maxDist;
    Vector2 hitNormalLocal = {};

    for (int i = 0; i < 2; ++i) {
        float orig = (i == 0) ? localOrigin.x : localOrigin.y;
        float d    = (i == 0) ? localDir.x    : localDir.y;
        float he   = (i == 0) ? box.halfExtents.x : box.halfExtents.y;

        if (std::abs(d) < 1e-8f) {
            if (orig < -he || orig > he) return false;
            continue;
        }

        float t1 = (-he - orig) / d;
        float t2 = ( he - orig) / d;
        if (t1 > t2) std::swap(t1, t2);

        if (t1 > tMin) {
            tMin = t1;
            hitNormalLocal = (i == 0) ? Vector2{d < 0 ? 1.0f : -1.0f, 0}
                                       : Vector2{0, d < 0 ? 1.0f : -1.0f};
        }
        tMax = std::min(tMax, t2);
        if (tMin > tMax) return false;
    }

    hit.hit      = true;
    hit.distance = tMin;
    hit.point    = origin + dir * tMin;
    // Rotate normal back to world space
    hit.normal = {
        hitNormalLocal.x * std::cos(boxRot) - hitNormalLocal.y * std::sin(boxRot),
        hitNormalLocal.x * std::sin(boxRot) + hitNormalLocal.y * std::cos(boxRot)
    };
    return true;
}

bool NarrowPhase::RaycastCapsule(const Vector2& origin, const Vector2& dir, float maxDist,
                                   const CapsuleShape& caps, const Vector2& pos, float rot,
                                   RaycastHit& hit)
{
    // Test ray vs expanded circle at each endpoint + segment
    float   halfH = caps.height * 0.5f - caps.radius;
    Vector2 axis  = Vector2{0, 1}.Rotated(rot);
    Vector2 p1    = pos + axis * halfH;
    Vector2 p2    = pos - axis * halfH;

    CircleShape c1(caps.radius), c2(caps.radius);
    RaycastHit h1, h2;
    bool r1 = RaycastCircle(origin, dir, maxDist, c1, p1, h1);
    bool r2 = RaycastCircle(origin, dir, maxDist, c2, p2, h2);

    if (!r1 && !r2) return false;

    if (r1 && (!r2 || h1.distance < h2.distance)) hit = h1;
    else hit = h2;

    return true;
}

} // namespace BADGE2D
