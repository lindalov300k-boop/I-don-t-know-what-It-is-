#pragma once
// ==============================================================================
// Broadphase.h — Spatial hash grid broadphase collision detection
// O(1) average insertion/removal, O(k) pair detection where k = local density.
// ==============================================================================

#include "../PhysicsMath.h"
#include "../bodies/PhysicsBody.h"
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <cstdint>

namespace BADGE2D {

// ==============================================================================
// BroadphasePair — Candidate pair from broadphase
// ==============================================================================
struct BroadphasePair {
    PhysicsBody* bodyA;
    PhysicsBody* bodyB;

    bool operator==(const BroadphasePair& o) const {
        return (bodyA == o.bodyA && bodyB == o.bodyB) ||
               (bodyA == o.bodyB && bodyB == o.bodyA);
    }
};

// ==============================================================================
// BroadphaseAABB — simple AABB overlap broadphase (for small worlds)
// Tests all pairs: O(n²) but zero allocations, excellent for <200 bodies.
// ==============================================================================
class BroadphaseAABB {
public:
    void Clear()                                    { m_bodies.clear(); }
    void Insert(PhysicsBody* b)                     { m_bodies.push_back(b); }
    void Remove(PhysicsBody* b);

    // Returns all overlapping AABB pairs
    void QueryPairs(std::vector<BroadphasePair>& out) const;

    // Returns all bodies whose AABB overlaps queryAABB
    void QueryAABB(const AABB& query, std::vector<PhysicsBody*>& out) const;

    size_t GetBodyCount() const { return m_bodies.size(); }

private:
    std::vector<PhysicsBody*> m_bodies;
};

// ==============================================================================
// BroadphaseSpatialHash — Hash-grid broadphase (for large worlds, many bodies)
// Cells are sized to ~2x the average collider size.
// ==============================================================================
class BroadphaseSpatialHash {
public:
    explicit BroadphaseSpatialHash(float cellSize = 64.0f);

    void SetCellSize(float size);
    void Clear();
    void Insert(PhysicsBody* b);
    void Remove(PhysicsBody* b);
    void Update(PhysicsBody* b);      // Call when body moves

    void QueryPairs(std::vector<BroadphasePair>& out) const;
    void QueryAABB (const AABB& query, std::vector<PhysicsBody*>& out) const;
    void QueryPoint(const Vector2& pt,  std::vector<PhysicsBody*>& out) const;

    size_t GetCellCount() const { return m_cells.size(); }

private:
    using CellKey = uint64_t;

    CellKey Hash(int cx, int cy) const {
        uint32_t x = static_cast<uint32_t>(cx + 0x8000);
        uint32_t y = static_cast<uint32_t>(cy + 0x8000);
        return (static_cast<uint64_t>(x) << 32) | y;
    }

    Vector2i WorldToCell(const Vector2& pos) const {
        return {
            static_cast<int>(std::floor(pos.x * m_invCellSize)),
            static_cast<int>(std::floor(pos.y * m_invCellSize))
        };
    }

    float                                              m_cellSize    = 64.0f;
    float                                              m_invCellSize = 1.0f / 64.0f;
    std::unordered_map<CellKey, std::vector<PhysicsBody*>> m_cells;
    std::unordered_map<PhysicsBody*, std::vector<CellKey>> m_bodyToCells;
};

// ==============================================================================
// DynamicAABBTree — BVH (for complex scenes / raycasts, future use)
// Placeholder — full BVH implementation in later phase.
// ==============================================================================
class DynamicAABBTree {
public:
    // Inserted for completeness; full BVH coming in Phase 7 (Scene phase)
    void Insert(PhysicsBody*) {}
    void Remove(PhysicsBody*) {}
    void QueryPairs(std::vector<BroadphasePair>&) const {}
    void QueryAABB (const AABB&, std::vector<PhysicsBody*>&) const {}
};

} // namespace BADGE2D
