// ==============================================================================
// CollisionResolver.cpp — Sequential Impulse constraint solver
// ==============================================================================

#include "CollisionResolver.h"
#include <cmath>
#include <algorithm>

namespace BADGE2D {

// ==============================================================================
// PreSolve — compute effective mass and biases, apply warm-starting
// ==============================================================================
void CollisionResolver::PreSolve(ContactConstraint& c, float dt) {
    PhysicsBody* a = c.bodyA;
    PhysicsBody* b = c.bodyB;
    const CollisionManifold& m = c.manifold;

    // Combined material properties
    c.friction    = CombineFriction   (a->GetMaterial().friction,    b->GetMaterial().friction);
    c.restitution = CombineRestitution(a->GetMaterial().restitution,  b->GetMaterial().restitution);

    Vector2 n  = m.normal;
    Vector2 cp = m.contactPoint;

    // Radius vectors from center of mass to contact point
    Vector2 rA = cp - a->GetPosition();
    Vector2 rB = cp - b->GetPosition();

    // Cross products (2D: scalar)
    float rACrossN = Vector2::Cross(rA, n);
    float rBCrossN = Vector2::Cross(rB, n);

    // Normal effective mass: 1 / (1/mA + 1/mB + (rA×n)²/IA + (rB×n)²/IB)
    float invMassSum = a->GetInvMass() + b->GetInvMass()
        + rACrossN * rACrossN * a->GetInvInertia()
        + rBCrossN * rBCrossN * b->GetInvInertia();

    c.normalMass = (invMassSum > 1e-8f) ? 1.0f / invMassSum : 0.0f;

    // Tangent effective mass
    Vector2 tangent = {-n.y, n.x};
    float rACrossT  = Vector2::Cross(rA, tangent);
    float rBCrossT  = Vector2::Cross(rB, tangent);
    float invMassT  = a->GetInvMass() + b->GetInvMass()
        + rACrossT * rACrossT * a->GetInvInertia()
        + rBCrossT * rBCrossT * b->GetInvInertia();
    c.tangentMass = (invMassT > 1e-8f) ? 1.0f / invMassT : 0.0f;

    // Restitution velocity bias
    Vector2 vA  = a->GetLinearVelocity() + Vector2{-a->GetAngularVelocity() * rA.y,
                                                     a->GetAngularVelocity() * rA.x};
    Vector2 vB  = b->GetLinearVelocity() + Vector2{-b->GetAngularVelocity() * rB.y,
                                                     b->GetAngularVelocity() * rB.x};
    float   relVn = Vector2::Dot(vB - vA, n);

    c.restitutionBias = 0.0f;
    if (std::abs(relVn) > PhysicsConst::RESTITUTION_THRESHOLD)
        c.restitutionBias = -c.restitution * relVn;

    // Baumgarte position bias
    float slop = PhysicsConst::CONTACT_SLOP;
    float pen  = m.penetration;
    c.positionBias = PhysicsConst::BAUMGARTE_FACTOR
                   * std::max(pen - slop, 0.0f) / dt;

    // Warm-starting: re-apply previous frame's impulse
    if (c.normalImpulseAccum != 0.0f || c.tangentImpulseAccum != 0.0f) {
        Vector2 P = n * c.normalImpulseAccum + tangent * c.tangentImpulseAccum;
        a->ApplyImpulse(-P);
        b->ApplyImpulse( P);
        // Angular
        a->ApplyAngularImpulse(-Vector2::Cross(rA, P) * a->GetInvInertia() / (a->GetInvInertia() > 0 ? 1.0f : 1.0f));
        b->ApplyAngularImpulse( Vector2::Cross(rB, P) * b->GetInvInertia() / (b->GetInvInertia() > 0 ? 1.0f : 1.0f));
    }
}

// ==============================================================================
// SolveVelocity — one velocity correction pass
// ==============================================================================
void CollisionResolver::SolveVelocity(ContactConstraint& c) {
    PhysicsBody* a = c.bodyA;
    PhysicsBody* b = c.bodyB;
    Vector2 n  = c.manifold.normal;
    Vector2 cp = c.manifold.contactPoint;

    Vector2 rA = cp - a->GetPosition();
    Vector2 rB = cp - b->GetPosition();

    // Relative velocity at contact
    Vector2 vA = a->GetLinearVelocity() + Vector2{-a->GetAngularVelocity() * rA.y,
                                                     a->GetAngularVelocity() * rA.x};
    Vector2 vB = b->GetLinearVelocity() + Vector2{-b->GetAngularVelocity() * rB.y,
                                                     b->GetAngularVelocity() * rB.x};
    Vector2 vRel = vB - vA;

    // --- Normal impulse ---
    float  vn        = Vector2::Dot(vRel, n);
    float  lambda    = c.normalMass * (-vn + c.restitutionBias + c.positionBias);
    float  oldAccum  = c.normalImpulseAccum;
    c.normalImpulseAccum = std::max(0.0f, oldAccum + lambda);
    float  dLambda   = c.normalImpulseAccum - oldAccum;

    Vector2 Pn = n * dLambda;
    a->ApplyImpulse(-Pn);
    b->ApplyImpulse( Pn);
    float rACrossN = Vector2::Cross(rA, n);
    float rBCrossN = Vector2::Cross(rB, n);
    if (a->GetInvInertia() > 0) a->SetAngularVelocity(a->GetAngularVelocity() + a->GetInvInertia() * (-Vector2::Cross(rA, Pn)));
    if (b->GetInvInertia() > 0) b->SetAngularVelocity(b->GetAngularVelocity() + b->GetInvInertia() * ( Vector2::Cross(rB, Pn)));

    // --- Tangent impulse (friction) ---
    // Re-compute relative velocity after normal impulse
    vA = a->GetLinearVelocity() + Vector2{-a->GetAngularVelocity() * rA.y,
                                           a->GetAngularVelocity() * rA.x};
    vB = b->GetLinearVelocity() + Vector2{-b->GetAngularVelocity() * rB.y,
                                           b->GetAngularVelocity() * rB.x};
    vRel = vB - vA;

    Vector2 tangent = {-n.y, n.x};
    float   vt      = Vector2::Dot(vRel, tangent);
    float   lambdaT = c.tangentMass * (-vt);

    // Coulomb friction cone clamp
    float maxFriction = c.friction * c.normalImpulseAccum;
    float oldT        = c.tangentImpulseAccum;
    c.tangentImpulseAccum = std::clamp(oldT + lambdaT, -maxFriction, maxFriction);
    float dT          = c.tangentImpulseAccum - oldT;

    Vector2 Pt = tangent * dT;
    a->ApplyImpulse(-Pt);
    b->ApplyImpulse( Pt);
    if (a->GetInvInertia() > 0) a->SetAngularVelocity(a->GetAngularVelocity() + a->GetInvInertia() * (-Vector2::Cross(rA, Pt)));
    if (b->GetInvInertia() > 0) b->SetAngularVelocity(b->GetAngularVelocity() + b->GetInvInertia() * ( Vector2::Cross(rB, Pt)));
}

// ==============================================================================
// SolvePosition — Baumgarte position correction
// ==============================================================================
void CollisionResolver::SolvePosition(ContactConstraint& c) {
    PhysicsBody* a = c.bodyA;
    PhysicsBody* b = c.bodyB;

    float pen = c.manifold.penetration - PhysicsConst::CONTACT_SLOP;
    if (pen <= 0) return;

    Vector2 n  = c.manifold.normal;
    Vector2 cp = c.manifold.contactPoint;
    Vector2 rA = cp - a->GetPosition();
    Vector2 rB = cp - b->GetPosition();

    float rACrossN = Vector2::Cross(rA, n);
    float rBCrossN = Vector2::Cross(rB, n);

    float denom = a->GetInvMass() + b->GetInvMass()
                + rACrossN * rACrossN * a->GetInvInertia()
                + rBCrossN * rBCrossN * b->GetInvInertia();

    if (denom < 1e-8f) return;

    float correction = PhysicsConst::BAUMGARTE_FACTOR * pen / denom;
    Vector2 corr = n * correction;

    if (a->GetBodyType() == BodyType::Dynamic)
        a->SetPosition(a->GetPosition() - corr * a->GetInvMass());
    if (b->GetBodyType() == BodyType::Dynamic)
        b->SetPosition(b->GetPosition() + corr * b->GetInvMass());
}

// ==============================================================================
// Resolve — Full solve pass
// ==============================================================================
void CollisionResolver::Resolve(std::vector<ContactConstraint>& contacts,
                                  int velIter, int posIter) {
    // Pre-solve with a fixed dt estimate — in PhysicsWorld we call this with real dt
    // Here we do a simplified pass without dt (warm-starting only)
    for (auto& c : contacts) {
        // PreSolve called by PhysicsWorld which has dt
    }

    // Velocity iterations
    for (int i = 0; i < velIter; ++i)
        for (auto& c : contacts)
            SolveVelocity(c);

    // Position iterations
    for (int i = 0; i < posIter; ++i)
        for (auto& c : contacts)
            SolvePosition(c);
}

} // namespace BADGE2D
