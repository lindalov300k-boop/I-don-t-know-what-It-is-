#pragma once
// ==============================================================================
// SoundClip.h — In-memory audio asset (decoded PCM)
// Loaded via SoundLoader (WAV via dr_wav, OGG via stb_vorbis, MP3 via dr_mp3).
// ==============================================================================

#include "../AudioTypes.h"
#include <vector>
#include <string>
#include <memory>
#include <cstdint>

namespace BADGE2D {

// ==============================================================================
// SoundClip — Fully decoded PCM audio in memory
// ==============================================================================
class SoundClip {
public:
    explicit SoundClip(SoundID id) : m_id(id) {}
    ~SoundClip() = default;

    // Metadata
    SoundID            GetID()           const { return m_id;           }
    const std::string& GetName()         const { return m_name;         }
    AudioFormat        GetFormat()       const { return m_format;       }
    int                GetSampleRate()   const { return m_sampleRate;   }
    int                GetChannelCount() const { return BADGE2D::GetChannelCount(m_format); }
    uint64_t           GetFrameCount()   const { return m_frameCount;   }
    double             GetDuration()     const {
        return (m_sampleRate > 0) ? (double)m_frameCount / m_sampleRate : 0.0;
    }

    // PCM data — interleaved f32 (always converted on load)
    const std::vector<float>& GetSamples() const { return m_samples; }
    const float*              GetData()    const { return m_samples.data(); }
    size_t                    GetDataSize()const { return m_samples.size() * sizeof(float); }

    // Read samples at any position for playback
    float GetSample(uint64_t frame, int channel) const;

    bool IsLoaded() const { return !m_samples.empty(); }
    bool IsValid()  const { return m_id != INVALID_SOUND && IsLoaded(); }

    // Loading flags
    bool        m_isLooping  = false;
    float       m_baseVolume = 1.0f;   // Baked gain from asset
    float       m_basePitch  = 1.0f;
    std::string m_filePath;

private:
    friend class SoundLoader;
    friend class AudioManager;

    SoundID              m_id         = INVALID_SOUND;
    std::string          m_name;
    AudioFormat          m_format     = AudioFormat::Stereo32F;
    int                  m_sampleRate = AudioConst::SAMPLE_RATE;
    uint64_t             m_frameCount = 0;
    std::vector<float>   m_samples;   // Interleaved float samples
};

// ==============================================================================
// SoundLoader — Decodes audio files to SoundClip
// Requires: dr_wav.h, stb_vorbis.h, dr_mp3.h in thirdparty/
// ==============================================================================
class SoundLoader {
public:
    // Load from file — format detected by extension (.wav .ogg .mp3 .flac)
    static std::shared_ptr<SoundClip> Load(const std::string& filepath, SoundID id);

    // Load from memory buffer
    static std::shared_ptr<SoundClip> LoadFromMemory(const uint8_t* data, size_t size,
                                                       const std::string& ext, SoundID id);

    // Generate procedural tones (useful for UI beeps, testing)
    static std::shared_ptr<SoundClip> GenerateSine(float frequency, float duration,
                                                     float amplitude, SoundID id,
                                                     int sampleRate = AudioConst::SAMPLE_RATE);
    static std::shared_ptr<SoundClip> GenerateNoise(float duration, float amplitude,
                                                      SoundID id,
                                                      int sampleRate = AudioConst::SAMPLE_RATE);
    static std::shared_ptr<SoundClip> GenerateSquare(float frequency, float duration,
                                                       float amplitude, SoundID id,
                                                       int sampleRate = AudioConst::SAMPLE_RATE);
private:
    static bool LoadWAV    (const std::string& path, SoundClip& clip);
    static bool LoadOGG    (const std::string& path, SoundClip& clip);
    static bool LoadMP3    (const std::string& path, SoundClip& clip);
    static void Normalize  (SoundClip& clip, int outputChannels);
};

} // namespace BADGE2D
