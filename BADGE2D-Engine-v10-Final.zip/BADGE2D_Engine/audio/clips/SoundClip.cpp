// ==============================================================================
// SoundClip.cpp — Audio asset loading & procedural generation
// ==============================================================================

// Third-party single-header implementations
#ifdef __has_include
  #if __has_include("../../thirdparty/dr_wav.h")
    #define DR_WAV_IMPLEMENTATION
    #include "../../thirdparty/dr_wav.h"
    #define BADGE2D_HAS_DR_WAV 1
  #endif
  #if __has_include("../../thirdparty/stb_vorbis.h") || \
      __has_include("../../thirdparty/stb_vorbis.c")
    #define STB_VORBIS_HEADER_ONLY
    #include "../../thirdparty/stb_vorbis.c"
    #undef STB_VORBIS_HEADER_ONLY
    #define BADGE2D_HAS_STB_VORBIS 1
  #endif
  #if __has_include("../../thirdparty/dr_mp3.h")
    #define DR_MP3_IMPLEMENTATION
    #include "../../thirdparty/dr_mp3.h"
    #define BADGE2D_HAS_DR_MP3 1
  #endif
#endif

#include "SoundClip.h"
#include "../../engine/Logging/Logger.h"
#include <cmath>
#include <random>
#include <algorithm>
#include <fstream>
#include <cstring>

namespace BADGE2D {

// ==============================================================================
// SoundClip::GetSample
// ==============================================================================
float SoundClip::GetSample(uint64_t frame, int channel) const {
    int ch = GetChannelCount();
    if (channel >= ch) channel = ch - 1;
    size_t idx = (size_t)(frame * ch + channel);
    return (idx < m_samples.size()) ? m_samples[idx] : 0.0f;
}

// ==============================================================================
// SoundLoader helpers
// ==============================================================================
static std::string GetExtension(const std::string& path) {
    auto pos = path.rfind('.');
    if (pos == std::string::npos) return "";
    std::string ext = path.substr(pos + 1);
    for (auto& c : ext) c = (char)tolower((unsigned char)c);
    return ext;
}

// Resample (simple linear) & convert to stereo float if needed
void SoundLoader::Normalize(SoundClip& clip, int outputChannels) {
    int srcCh = clip.GetChannelCount();
    // If already stereo float, nothing to do
    if (srcCh == outputChannels) return;

    if (srcCh == 1 && outputChannels == 2) {
        // Mono → stereo: duplicate each sample
        std::vector<float> stereo;
        stereo.reserve(clip.m_samples.size() * 2);
        for (float s : clip.m_samples) { stereo.push_back(s); stereo.push_back(s); }
        clip.m_samples = std::move(stereo);
        clip.m_format  = AudioFormat::Stereo32F;
    } else if (srcCh == 2 && outputChannels == 1) {
        // Stereo → mono: average channels
        std::vector<float> mono;
        mono.reserve(clip.m_samples.size() / 2);
        for (size_t i = 0; i + 1 < clip.m_samples.size(); i += 2)
            mono.push_back((clip.m_samples[i] + clip.m_samples[i+1]) * 0.5f);
        clip.m_samples = std::move(mono);
        clip.m_format  = AudioFormat::Mono32F;
    }
}

// ==============================================================================
// WAV loader (dr_wav)
// ==============================================================================
bool SoundLoader::LoadWAV(const std::string& path, SoundClip& clip) {
#ifdef BADGE2D_HAS_DR_WAV
    drwav wav;
    if (!drwav_init_file(&wav, path.c_str(), nullptr)) return false;

    uint64_t totalFrames = wav.totalPCMFrameCount;
    clip.m_sampleRate = (int)wav.sampleRate;
    clip.m_frameCount = totalFrames;
    clip.m_format     = (wav.channels > 1) ? AudioFormat::Stereo32F : AudioFormat::Mono32F;

    size_t totalSamples = (size_t)(totalFrames * wav.channels);
    clip.m_samples.resize(totalSamples);
    drwav_read_pcm_frames_f32(&wav, totalFrames, clip.m_samples.data());
    drwav_uninit(&wav);
    return true;
#else
    (void)path; (void)clip;
    LOG_WARN("[SoundLoader] dr_wav not available. Place dr_wav.h in thirdparty/.");
    return false;
#endif
}

// ==============================================================================
// OGG Vorbis loader (stb_vorbis)
// ==============================================================================
bool SoundLoader::LoadOGG(const std::string& path, SoundClip& clip) {
#ifdef BADGE2D_HAS_STB_VORBIS
    int channels = 0, sampleRate = 0;
    short* output = nullptr;
    int samples = stb_vorbis_decode_filename(path.c_str(), &channels, &sampleRate, &output);
    if (samples < 0 || !output) return false;

    clip.m_sampleRate = sampleRate;
    clip.m_frameCount = (uint64_t)samples;
    clip.m_format     = (channels > 1) ? AudioFormat::Stereo32F : AudioFormat::Mono32F;
    clip.m_samples.resize((size_t)samples * channels);
    for (size_t i = 0; i < clip.m_samples.size(); ++i)
        clip.m_samples[i] = output[i] / 32768.0f;
    free(output);
    return true;
#else
    (void)path; (void)clip;
    LOG_WARN("[SoundLoader] stb_vorbis not available. Place stb_vorbis.c in thirdparty/.");
    return false;
#endif
}

// ==============================================================================
// MP3 loader (dr_mp3)
// ==============================================================================
bool SoundLoader::LoadMP3(const std::string& path, SoundClip& clip) {
#ifdef BADGE2D_HAS_DR_MP3
    drmp3_config config;
    drmp3_uint64 totalFrames;
    float* pSamples = drmp3_open_file_and_read_pcm_frames_f32(
        path.c_str(), &config, &totalFrames, nullptr);
    if (!pSamples) return false;

    clip.m_sampleRate = (int)config.sampleRate;
    clip.m_frameCount = totalFrames;
    clip.m_format     = (config.channels > 1) ? AudioFormat::Stereo32F : AudioFormat::Mono32F;
    size_t count      = (size_t)(totalFrames * config.channels);
    clip.m_samples.assign(pSamples, pSamples + count);
    drmp3_free(pSamples, nullptr);
    return true;
#else
    (void)path; (void)clip;
    LOG_WARN("[SoundLoader] dr_mp3 not available. Place dr_mp3.h in thirdparty/.");
    return false;
#endif
}

// ==============================================================================
// Load from file
// ==============================================================================
std::shared_ptr<SoundClip> SoundLoader::Load(const std::string& filepath, SoundID id) {
    auto clip = std::make_shared<SoundClip>(id);
    clip->m_filePath = filepath;
    clip->m_name     = filepath.substr(filepath.rfind('/') + 1);

    bool ok = false;
    std::string ext = GetExtension(filepath);

    if      (ext == "wav")  ok = LoadWAV(filepath, *clip);
    else if (ext == "ogg")  ok = LoadOGG(filepath, *clip);
    else if (ext == "mp3")  ok = LoadMP3(filepath, *clip);
    else LOG_ERRORF("[SoundLoader] Unsupported format: .%s", ext.c_str());

    if (ok) {
        LOG_INFOF("[SoundLoader] Loaded '%s' %.2fs %dHz %dch",
                  clip->m_name.c_str(), clip->GetDuration(),
                  clip->m_sampleRate, clip->GetChannelCount());
    } else {
        LOG_ERRORF("[SoundLoader] Failed to load: %s", filepath.c_str());
    }
    return ok ? clip : nullptr;
}

std::shared_ptr<SoundClip> SoundLoader::LoadFromMemory(
    const uint8_t* data, size_t size, const std::string& ext, SoundID id) {
    // Write to temp file then load — simple but effective for now
    std::string tmpPath = "/tmp/badge2d_tmp_audio." + ext;
    std::ofstream f(tmpPath, std::ios::binary);
    f.write((const char*)data, (std::streamsize)size);
    f.close();
    return Load(tmpPath, id);
}

// ==============================================================================
// Procedural generators
// ==============================================================================
std::shared_ptr<SoundClip> SoundLoader::GenerateSine(
    float frequency, float duration, float amplitude, SoundID id, int sampleRate) {
    auto clip = std::make_shared<SoundClip>(id);
    clip->m_name       = "sine_" + std::to_string((int)frequency) + "hz";
    clip->m_sampleRate = sampleRate;
    clip->m_format     = AudioFormat::Mono32F;

    uint64_t frames = (uint64_t)((double)sampleRate * duration);
    clip->m_frameCount = frames;
    clip->m_samples.resize(frames);

    float phase = 0.0f;
    float inc   = 2.0f * 3.14159265f * frequency / (float)sampleRate;
    for (size_t i = 0; i < frames; ++i) {
        // Fade in/out 5ms to avoid clicks
        float env = 1.0f;
        float fadeFrames = 0.005f * sampleRate;
        if (i < (size_t)fadeFrames)       env = i / fadeFrames;
        if (i > frames - (size_t)fadeFrames) env = (float)(frames - i) / fadeFrames;
        clip->m_samples[i] = std::sin(phase) * amplitude * env;
        phase += inc;
        if (phase > 3.14159265f * 2.0f) phase -= 3.14159265f * 2.0f;
    }
    return clip;
}

std::shared_ptr<SoundClip> SoundLoader::GenerateNoise(
    float duration, float amplitude, SoundID id, int sampleRate) {
    auto clip = std::make_shared<SoundClip>(id);
    clip->m_name       = "noise";
    clip->m_sampleRate = sampleRate;
    clip->m_format     = AudioFormat::Mono32F;

    uint64_t frames = (uint64_t)((double)sampleRate * duration);
    clip->m_frameCount = frames;
    clip->m_samples.resize(frames);

    std::mt19937 rng(42);
    std::uniform_real_distribution<float> dist(-1.0f, 1.0f);
    for (auto& s : clip->m_samples)
        s = dist(rng) * amplitude;
    return clip;
}

std::shared_ptr<SoundClip> SoundLoader::GenerateSquare(
    float frequency, float duration, float amplitude, SoundID id, int sampleRate) {
    auto clip = std::make_shared<SoundClip>(id);
    clip->m_name       = "square_" + std::to_string((int)frequency) + "hz";
    clip->m_sampleRate = sampleRate;
    clip->m_format     = AudioFormat::Mono32F;

    uint64_t frames = (uint64_t)((double)sampleRate * duration);
    clip->m_frameCount = frames;
    clip->m_samples.resize(frames);

    float period = (float)sampleRate / frequency;
    for (size_t i = 0; i < frames; ++i) {
        float pos = std::fmod((float)i, period);
        clip->m_samples[i] = (pos < period * 0.5f ? amplitude : -amplitude);
    }
    return clip;
}

} // namespace BADGE2D
