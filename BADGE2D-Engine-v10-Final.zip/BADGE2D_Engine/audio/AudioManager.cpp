// ==============================================================================
// AudioManager.cpp
// ==============================================================================

#include "AudioManager.h"
#include "../engine/Logging/Logger.h"
#include <random>
#include <algorithm>

namespace BADGE2D {

AudioManager& AudioManager::Get() {
    static AudioManager instance;
    return instance;
}

// ==============================================================================
// Initialize
// ==============================================================================
bool AudioManager::Initialize() {
    if (m_initialized) return true;

    AudioDeviceSpec spec;
    spec.sampleRate   = AudioConst::SAMPLE_RATE;
    spec.channels     = 2;
    spec.bufferFrames = AudioConst::BUFFER_FRAMES;

    AudioMixer::Get().Initialize(spec.channels, spec.sampleRate);

    bool ok = AudioDevice::Get().Initialize(spec, [](float* output, uint32_t frames, int ch) {
        AudioMixer::Get().MixCallback(output, frames, ch);
    });

    m_musicA = std::make_unique<StreamingSource>(AudioMixer::Get().AllocChannel());
    m_musicB = std::make_unique<StreamingSource>(AudioMixer::Get().AllocChannel());
    if (auto* ch = AudioMixer::Get().GetChannel(m_musicA->GetChannelID()))
        m_musicA->m_channel = ch;
    if (auto* ch = AudioMixer::Get().GetChannel(m_musicB->GetChannelID()))
        m_musicB->m_channel = ch;

    m_initialized = ok;
    LOG_INFO("[AudioManager] Initialized.");
    return ok;
}

void AudioManager::Shutdown() {
    if (!m_initialized) return;
    StopMusic(0.0f);
    StopAll();
    AudioDevice::Get().Shutdown();
    AudioMixer::Get().Shutdown();
    UnloadAll();
    m_initialized = false;
    LOG_INFO("[AudioManager] Shutdown.");
}

void AudioManager::Update(double dt) {
    AudioMixer::Get().Update((float)dt);
    m_musicA->Update();
    m_musicB->Update();

    // Update crossfade
    if (m_crossfading) {
        m_crossfadeElapsed += (float)dt;
        float t = std::min(1.0f, m_crossfadeElapsed / m_crossfadeTime);
        m_musicA->SetVolume(m_musicVolume * (1.0f - t));
        m_musicB->SetVolume(m_musicVolume * t);
        if (t >= 1.0f) {
            m_musicA->Stop();
            m_crossfading = false;
        }
    }
}

// ==============================================================================
// Asset library
// ==============================================================================
SoundID AudioManager::LoadSound(const std::string& filepath, const std::string& name) {
    // Check if already loaded by path
    for (auto& [id, clip] : m_clips)
        if (clip->m_filePath == filepath) return id;

    SoundID id = NextSoundID();
    auto clip  = SoundLoader::Load(filepath, id);
    if (!clip) return INVALID_SOUND;

    m_clips[id] = clip;
    std::string key = name.empty() ? clip->m_name : name;
    m_nameToID[key] = id;
    return id;
}

SoundID AudioManager::GetSoundID(const std::string& name) const {
    auto it = m_nameToID.find(name);
    return (it != m_nameToID.end()) ? it->second : INVALID_SOUND;
}

SoundClip* AudioManager::GetClip(SoundID id) const {
    auto it = m_clips.find(id);
    return (it != m_clips.end()) ? it->second.get() : nullptr;
}

SoundClip* AudioManager::GetClip(const std::string& name) const {
    return GetClip(GetSoundID(name));
}

void AudioManager::UnloadSound(SoundID id) {
    auto it = m_clips.find(id);
    if (it == m_clips.end()) return;
    for (auto& [name, nid] : m_nameToID)
        if (nid == id) { m_nameToID.erase(name); break; }
    m_clips.erase(it);
}

void AudioManager::UnloadAll() {
    StopAll();
    m_clips.clear();
    m_nameToID.clear();
}

bool AudioManager::IsLoaded(SoundID id) const {
    return m_clips.find(id) != m_clips.end();
}

// ==============================================================================
// Procedural clips
// ==============================================================================
SoundID AudioManager::CreateSine(const std::string& name, float freq, float dur, float amp) {
    SoundID id = NextSoundID();
    auto clip  = SoundLoader::GenerateSine(freq, dur, amp, id);
    clip->m_name = name;
    m_clips[id]  = clip;
    m_nameToID[name] = id;
    return id;
}

SoundID AudioManager::CreateNoise(const std::string& name, float dur, float amp) {
    SoundID id = NextSoundID();
    auto clip  = SoundLoader::GenerateNoise(dur, amp, id);
    clip->m_name = name;
    m_clips[id]  = clip;
    m_nameToID[name] = id;
    return id;
}

SoundID AudioManager::CreateSquare(const std::string& name, float freq, float dur, float amp) {
    SoundID id = NextSoundID();
    auto clip  = SoundLoader::GenerateSquare(freq, dur, amp, id);
    clip->m_name = name;
    m_clips[id]  = clip;
    m_nameToID[name] = id;
    return id;
}

// ==============================================================================
// Playback
// ==============================================================================
ChannelID AudioManager::Play(SoundID id, AudioGroupID group,
                               float volume, float pitch, float pan) {
    auto* clip = GetClip(id);
    if (!clip) { LOG_WARNF("[AudioManager] Play: unknown SoundID %u", id); return INVALID_CHANNEL; }
    return AudioMixer::Get().PlayClip(m_clips[id], group, volume, pitch, pan, false);
}

ChannelID AudioManager::Play(const std::string& name, AudioGroupID group,
                               float volume, float pitch) {
    return Play(GetSoundID(name), group, volume, pitch, 0.0f);
}

ChannelID AudioManager::PlayLooping(SoundID id, AudioGroupID group, float volume) {
    auto* clip = GetClip(id);
    if (!clip) return INVALID_CHANNEL;
    return AudioMixer::Get().PlayClip(m_clips[id], group, volume, 1.0f, 0.0f, true);
}

ChannelID AudioManager::PlayAt(SoundID id, const Vector2& pos,
                                  AudioGroupID group, float volume, float pitch) {
    auto* clip = GetClip(id);
    if (!clip) return INVALID_CHANNEL;
    return AudioMixer::Get().PlaySpatial(m_clips[id], pos, group, volume, pitch);
}

ChannelID AudioManager::PlayVaried(SoundID id,
                                     float vMin, float vMax,
                                     float pMin, float pMax,
                                     AudioGroupID group) {
    auto* clip = GetClip(id);
    if (!clip) return INVALID_CHANNEL;

    std::uniform_real_distribution<float> vDist(vMin, vMax);
    std::uniform_real_distribution<float> pDist(pMin, pMax);
    float vol   = vDist(m_rng);
    float pitch = pDist(m_rng);
    return AudioMixer::Get().PlayClip(m_clips[id], group, vol, pitch, 0.0f, false);
}

// ==============================================================================
// Channel control
// ==============================================================================
void AudioManager::Stop   (ChannelID id) { if (auto* c = AudioMixer::Get().GetChannel(id)) c->Stop();   }
void AudioManager::Pause  (ChannelID id) { if (auto* c = AudioMixer::Get().GetChannel(id)) c->Pause();  }
void AudioManager::Resume (ChannelID id) { if (auto* c = AudioMixer::Get().GetChannel(id)) c->Resume(); }
void AudioManager::SetVolume(ChannelID id, float v)   { if (auto* c = AudioMixer::Get().GetChannel(id)) c->SetVolume(v); }
void AudioManager::FadeOut (ChannelID id, float dur)  { if (auto* c = AudioMixer::Get().GetChannel(id)) c->FadeOut(dur); }
bool AudioManager::IsPlaying(ChannelID id)  const     { auto* c = AudioMixer::Get().GetChannel(id); return c && c->IsPlaying(); }
void AudioManager::StopAll (AudioGroupID g)           { AudioMixer::Get().StopAll(g); }

// ==============================================================================
// Music
// ==============================================================================
bool AudioManager::PlayMusic(const std::string& filepath, bool looping,
                               float fadeIn, float volume) {
    m_musicVolume = volume;
    if (!m_musicA->Open(filepath)) return false;
    m_musicA->Play(looping);
    if (auto* ch = AudioMixer::Get().GetChannel(m_musicA->GetChannelID()))
        ch->SetGroup(AudioGroupID::Music);
    if (fadeIn > 0.0f) {
        if (auto* ch = AudioMixer::Get().GetChannel(m_musicA->GetChannelID())) {
            ch->SetVolume(0.0f);
            ch->FadeIn(fadeIn, volume);
        }
    } else {
        if (auto* ch = AudioMixer::Get().GetChannel(m_musicA->GetChannelID()))
            ch->SetVolume(volume);
    }
    LOG_INFOF("[AudioManager] Playing music: %s", filepath.c_str());
    return true;
}

void AudioManager::StopMusic(float fadeOut) {
    if (fadeOut > 0.0f) m_musicA->FadeOut(fadeOut);
    else                m_musicA->Stop();
}

void AudioManager::PauseMusic()  { m_musicA->Pause();  }
void AudioManager::ResumeMusic() { m_musicA->Resume(); }
void AudioManager::SetMusicVolume(float v) {
    m_musicVolume = v;
    if (auto* ch = AudioMixer::Get().GetChannel(m_musicA->GetChannelID()))
        ch->SetVolume(v);
}

bool AudioManager::IsMusicPlaying() const { return m_musicA->IsPlaying(); }
double AudioManager::GetMusicTime() const { return m_musicA->GetTime(); }

void AudioManager::CrossFade(const std::string& newTrack, float duration) {
    if (!m_musicB->Open(newTrack)) return;
    m_musicB->Play(true);
    if (auto* ch = AudioMixer::Get().GetChannel(m_musicB->GetChannelID())) {
        ch->SetGroup(AudioGroupID::Music);
        ch->SetVolume(0.0f);
    }
    m_crossfadeTime    = duration;
    m_crossfadeElapsed = 0.0f;
    m_crossfading      = true;
    std::swap(m_musicA, m_musicB);  // B is now fading out, A is new track
    LOG_INFOF("[AudioManager] CrossFade → %s (%.1fs)", newTrack.c_str(), duration);
}

} // namespace BADGE2D
