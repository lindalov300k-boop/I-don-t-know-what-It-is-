#pragma once
// ==============================================================================
// AudioChannel.h — One active playback voice
// Each playing sound gets a Channel. The mixer reads all active channels.
// ==============================================================================

#include "../AudioTypes.h"
#include "../clips/SoundClip.h"
#include "../../utilities/Math/Vector2.h"
#include <memory>
#include <functional>
#include <atomic>

namespace BADGE2D {

// ==============================================================================
// FadeState — Smooth volume transition
// ==============================================================================
struct FadeState {
    float    fromVolume = 1.0f;
    float    toVolume   = 1.0f;
    float    elapsed    = 0.0f;
    float    duration   = 0.0f;
    bool     active     = false;

    float GetVolume() const {
        if (!active || duration <= 0) return toVolume;
        float t = elapsed / duration;
        if (t >= 1.0f) return toVolume;
        return fromVolume + (toVolume - fromVolume) * t;  // Linear
    }
};

// ==============================================================================
// AudioChannel — One playback voice (lives on mixer thread during mix)
// ==============================================================================
class AudioChannel {
public:
    explicit AudioChannel(ChannelID id) : m_id(id) {}

    // ==============================================================================
    // Playback control
    // ==============================================================================
    void Play  (std::shared_ptr<SoundClip> clip, ChannelFlags flags = ChannelFlags::None);
    void Stop  ();
    void Pause ();
    void Resume();

    void  SetVolume  (float v)     { m_volume  = v; }
    void  SetPitch   (float p)     { m_pitch   = std::max(0.01f, p); }
    void  SetPan     (float pan)   { m_pan     = pan; }   // -1..1
    void  SetGroup   (AudioGroupID g){ m_group = g; }

    float GetVolume  () const { return m_volume; }
    float GetPitch   () const { return m_pitch;  }
    float GetPan     () const { return m_pan;    }

    // Fade volume over duration
    void FadeTo(float targetVolume, float duration);
    void FadeOut(float duration) { FadeTo(0.0f, duration); }
    void FadeIn (float duration, float targetVolume = 1.0f) { FadeTo(targetVolume, duration); }

    // ==============================================================================
    // Spatial
    // ==============================================================================
    void     SetPosition  (const Vector2& pos) { m_worldPos = pos; m_spatial = true; }
    void     SetSpatial   (bool s)             { m_spatial  = s; }
    void     SetMinDist   (float d)            { m_minDist  = d; }
    void     SetMaxDist   (float d)            { m_maxDist  = d; }
    void     SetRolloff   (float r)            { m_rolloff  = r; }
    Vector2  GetPosition  () const             { return m_worldPos; }

    // ==============================================================================
    // State queries
    // ==============================================================================
    ChannelID        GetID()           const { return m_id; }
    PlaybackState    GetState()        const { return m_state; }
    bool             IsPlaying()       const { return m_state == PlaybackState::Playing; }
    bool             IsPaused()        const { return m_state == PlaybackState::Paused; }
    bool             IsStopped()       const { return m_state == PlaybackState::Stopped; }
    bool             IsFree()          const { return m_state == PlaybackState::Stopped && !m_clip; }
    AudioGroupID     GetGroup()        const { return m_group; }
    ChannelFlags     GetFlags()        const { return m_flags; }
    SoundID          GetSoundID()      const { return m_clip ? m_clip->GetID() : INVALID_SOUND; }

    double           GetPlaybackTime() const;
    double           GetDuration()     const { return m_clip ? m_clip->GetDuration() : 0.0; }
    double           GetProgress()     const;  // 0..1

    // ==============================================================================
    // Mixer-side API (called on audio thread)
    // ==============================================================================
    // Mix frameCount stereo f32 frames into outputBuffer (interleaved L,R)
    void MixInto(float* outputBuffer, uint32_t frameCount,
                 int outputChannels, float groupVolume,
                 const Vector2& listenerPos);

    // Advance fade state (called from update thread)
    void UpdateFade(float dt);

    // Callback when playback ends naturally
    std::function<void(ChannelID)> OnFinished;

private:
    float ComputeSpatialGain(const Vector2& listenerPos,
                              float& outPanL, float& outPanR) const;

    ChannelID      m_id       = INVALID_CHANNEL;
    PlaybackState  m_state    = PlaybackState::Stopped;
    ChannelFlags   m_flags    = ChannelFlags::None;
    AudioGroupID   m_group    = AudioGroupID::SFX;

    std::shared_ptr<SoundClip> m_clip;

    // Playback position (fractional frame index for pitch shifting)
    double         m_playPos  = 0.0;     // In source frames
    float          m_volume   = 1.0f;
    float          m_pitch    = 1.0f;
    float          m_pan      = 0.0f;

    FadeState      m_fade;

    // Spatial
    bool           m_spatial  = false;
    Vector2        m_worldPos = {};
    float          m_minDist  = AudioConst::DEFAULT_MIN_DIST;
    float          m_maxDist  = AudioConst::DEFAULT_MAX_DIST;
    float          m_rolloff  = AudioConst::DEFAULT_ROLLOFF;
};

} // namespace BADGE2D
