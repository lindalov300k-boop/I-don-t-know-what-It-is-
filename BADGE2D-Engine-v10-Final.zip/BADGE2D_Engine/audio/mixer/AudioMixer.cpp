// ==============================================================================
// AudioMixer.cpp
// ==============================================================================

#include "AudioMixer.h"
#include "../../engine/Logging/Logger.h"
#include <cstring>
#include <algorithm>
#include <cmath>

namespace BADGE2D {

AudioMixer& AudioMixer::Get() {
    static AudioMixer instance;
    return instance;
}

void AudioMixer::Initialize(int outputChannels, int sampleRate) {
    if (m_initialized) return;
    m_outputChannels = outputChannels;
    m_sampleRate     = sampleRate;

    // Init channels with sequential IDs
    for (int i = 0; i < AudioConst::MAX_CHANNELS; ++i) {
        // placement: re-construct with ID
        new (&m_channels[i]) AudioChannel((ChannelID)(i + 1));
        m_channels[i].OnFinished = [this](ChannelID /*id*/) {
            // OneShot channels free themselves
        };
    }

    // Init groups
    for (int i = 0; i < (int)AudioGroupID::Count; ++i) {
        m_groups[i].id     = (AudioGroupID)i;
        m_groups[i].volume = 1.0f;
    }

    m_scratchBuffer.resize((size_t)(AudioConst::BUFFER_FRAMES * outputChannels * 2));
    m_initialized = true;
    LOG_INFOF("[AudioMixer] Initialized. Channels=%d OutputCh=%d SR=%d",
              AudioConst::MAX_CHANNELS, outputChannels, sampleRate);
}

void AudioMixer::Shutdown() {
    if (!m_initialized) return;
    StopAll();
    m_initialized = false;
    LOG_INFO("[AudioMixer] Shutdown.");
}

// ==============================================================================
// Channel allocation
// ==============================================================================
ChannelID AudioMixer::AllocChannel() {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& ch : m_channels) {
        if (ch.IsFree()) return ch.GetID();
    }
    // Steal oldest non-music channel
    for (auto& ch : m_channels) {
        if (!HasFlag(ch.GetFlags(), ChannelFlags::Streaming))
            return ch.GetID();
    }
    return INVALID_CHANNEL;
}

void AudioMixer::FreeChannel(ChannelID id) {
    if (auto* ch = GetChannel(id)) ch->Stop();
}

AudioChannel* AudioMixer::GetChannel(ChannelID id) {
    if (id == INVALID_CHANNEL || id > AudioConst::MAX_CHANNELS) return nullptr;
    return &m_channels[id - 1];
}

// ==============================================================================
// PlayClip
// ==============================================================================
ChannelID AudioMixer::PlayClip(std::shared_ptr<SoundClip> clip,
                                  AudioGroupID group, float volume,
                                  float pitch, float pan, bool looping) {
    if (!clip || !clip->IsValid()) return INVALID_CHANNEL;

    ChannelID id = AllocChannel();
    if (id == INVALID_CHANNEL) return INVALID_CHANNEL;

    auto* ch = GetChannel(id);
    ch->SetGroup(group);
    ch->SetVolume(volume);
    ch->SetPitch(pitch);
    ch->SetPan(pan);

    ChannelFlags flags = ChannelFlags::OneShot;
    if (looping) flags = flags | ChannelFlags::Looping;

    ch->Play(std::move(clip), flags);
    return id;
}

ChannelID AudioMixer::PlaySpatial(std::shared_ptr<SoundClip> clip,
                                    const Vector2& worldPos,
                                    AudioGroupID group, float volume, float pitch,
                                    float minDist, float maxDist) {
    if (!clip || !clip->IsValid()) return INVALID_CHANNEL;

    ChannelID id = AllocChannel();
    if (id == INVALID_CHANNEL) return INVALID_CHANNEL;

    auto* ch = GetChannel(id);
    ch->SetGroup(group);
    ch->SetVolume(volume);
    ch->SetPitch(pitch);
    ch->SetPosition(worldPos);
    ch->SetMinDist(minDist);
    ch->SetMaxDist(maxDist);
    ch->Play(std::move(clip), ChannelFlags::OneShot | ChannelFlags::Spatial);
    return id;
}

// ==============================================================================
// Bulk controls
// ==============================================================================
void AudioMixer::StopAll(AudioGroupID group) {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& ch : m_channels) {
        if (group == AudioGroupID::Count || ch.GetGroup() == group)
            ch.Stop();
    }
}

void AudioMixer::PauseAll(AudioGroupID group) {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& ch : m_channels) {
        if (group == AudioGroupID::Count || ch.GetGroup() == group)
            ch.Pause();
    }
}

void AudioMixer::ResumeAll(AudioGroupID group) {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& ch : m_channels) {
        if (group == AudioGroupID::Count || ch.GetGroup() == group)
            ch.Resume();
    }
}

// ==============================================================================
// Group volume
// ==============================================================================
void  AudioMixer::SetGroupVolume(AudioGroupID g, float v) {
    int i = (int)g;
    if (i >= 0 && i < (int)AudioGroupID::Count) m_groups[i].volume = std::clamp(v, 0.0f, 1.0f);
}

float AudioMixer::GetGroupVolume(AudioGroupID g) const {
    int i = (int)g;
    return (i >= 0 && i < (int)AudioGroupID::Count) ? m_groups[i].volume : 1.0f;
}

void AudioMixer::MuteGroup(AudioGroupID g, bool mute) {
    int i = (int)g;
    if (i >= 0 && i < (int)AudioGroupID::Count) m_groups[i].muted = mute;
}

bool AudioMixer::IsGroupMuted(AudioGroupID g) const {
    int i = (int)g;
    return (i >= 0 && i < (int)AudioGroupID::Count) && m_groups[i].muted;
}

int AudioMixer::GetActiveChannelCount() const {
    int count = 0;
    for (const auto& ch : m_channels)
        if (ch.IsPlaying()) ++count;
    return count;
}

// ==============================================================================
// Update — main thread, advance fades
// ==============================================================================
void AudioMixer::Update(float dt) {
    std::lock_guard<std::mutex> lock(m_mutex);
    for (auto& ch : m_channels)
        ch.UpdateFade(dt);
}

// ==============================================================================
// MixCallback — AUDIO THREAD
// ==============================================================================
void AudioMixer::MixCallback(float* output, uint32_t frameCount, int channels) {
    // Zero output
    memset(output, 0, frameCount * channels * sizeof(float));

    if (m_masterMute || m_masterVolume <= 0.0f) return;
    if (!m_initialized) return;

    // Mix all active channels
    {
        // Note: tryLock avoids deadlock if main thread holds mutex during frame
        std::unique_lock<std::mutex> lock(m_mutex, std::try_to_lock);
        if (!lock.owns_lock()) return;

        for (auto& ch : m_channels) {
            if (!ch.IsPlaying() && ch.GetState() != PlaybackState::Fading) continue;

            AudioGroupID gid = ch.GetGroup();
            float groupVol = 1.0f;
            if ((int)gid < (int)AudioGroupID::Count) {
                const auto& g = m_groups[(int)gid];
                if (g.muted) continue;
                groupVol = g.volume;
            }
            groupVol *= m_masterVolume;

            ch.MixInto(output, frameCount, channels, groupVol, m_listenerPos);
        }
    }

    // Soft clipping (tanh limiter) to prevent hard clipping
    for (uint32_t i = 0; i < frameCount * (uint32_t)channels; ++i) {
        float s = output[i];
        if (s > 0.9f || s < -0.9f)
            output[i] = std::tanh(s);
    }
}

} // namespace BADGE2D
