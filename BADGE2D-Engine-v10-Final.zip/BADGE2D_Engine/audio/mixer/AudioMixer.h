#pragma once
// ==============================================================================
// AudioMixer.h — Software mixer: owns all channels, groups, processes mix callback
// ==============================================================================

#include "AudioChannel.h"
#include "../AudioTypes.h"
#include "../../utilities/Math/Vector2.h"
#include <array>
#include <vector>
#include <mutex>
#include <memory>
#include <functional>

namespace BADGE2D {

// ==============================================================================
// MixGroup — One named audio group (SFX, Music, …)
// ==============================================================================
struct MixGroup {
    AudioGroupID  id       = AudioGroupID::SFX;
    float         volume   = 1.0f;
    float         pitch    = 1.0f;
    bool          muted    = false;
    bool          soloed   = false;
    int           maxVoices= 0;  // 0 = unlimited
};

// ==============================================================================
// AudioMixer
// ==============================================================================
class AudioMixer {
public:
    static AudioMixer& Get();

    void Initialize(int outputChannels, int sampleRate);
    void Shutdown();

    // ==============================================================================
    // Channel allocation
    // ==============================================================================
    // Allocate a free channel. Returns INVALID_CHANNEL if none available.
    ChannelID AllocChannel();
    void      FreeChannel (ChannelID id);
    AudioChannel* GetChannel(ChannelID id);

    // Quick-play: allocate + play in one call
    ChannelID PlayClip(std::shared_ptr<SoundClip> clip,
                        AudioGroupID group   = AudioGroupID::SFX,
                        float volume         = 1.0f,
                        float pitch          = 1.0f,
                        float pan            = 0.0f,
                        bool  looping        = false);

    ChannelID PlaySpatial(std::shared_ptr<SoundClip> clip,
                           const Vector2& worldPos,
                           AudioGroupID group = AudioGroupID::SFX,
                           float volume       = 1.0f,
                           float pitch        = 1.0f,
                           float minDist      = AudioConst::DEFAULT_MIN_DIST,
                           float maxDist      = AudioConst::DEFAULT_MAX_DIST);

    void StopAll  (AudioGroupID group = AudioGroupID::Count);  // Count = all groups
    void PauseAll (AudioGroupID group = AudioGroupID::Count);
    void ResumeAll(AudioGroupID group = AudioGroupID::Count);

    // ==============================================================================
    // Group volume / mute
    // ==============================================================================
    void  SetGroupVolume(AudioGroupID g, float v);
    float GetGroupVolume(AudioGroupID g) const;
    void  MuteGroup (AudioGroupID g, bool mute);
    bool  IsGroupMuted(AudioGroupID g) const;

    // ==============================================================================
    // Master
    // ==============================================================================
    void  SetMasterVolume(float v)  { m_masterVolume = v; }
    float GetMasterVolume()  const  { return m_masterVolume; }
    void  SetMasterMute  (bool m)   { m_masterMute   = m; }
    bool  GetMasterMute  ()  const  { return m_masterMute; }

    // ==============================================================================
    // Listener (for spatial audio)
    // ==============================================================================
    void    SetListenerPosition(const Vector2& pos) { m_listenerPos = pos; }
    Vector2 GetListenerPosition()            const  { return m_listenerPos; }

    // ==============================================================================
    // Statistics
    // ==============================================================================
    int GetActiveChannelCount() const;
    int GetTotalChannels()      const { return AudioConst::MAX_CHANNELS; }

    // ==============================================================================
    // Mix callback — called by AudioDevice on audio thread
    // ==============================================================================
    void MixCallback(float* output, uint32_t frameCount, int channels);

    // Update fade states — called from main thread
    void Update(float dt);

private:
    AudioMixer() = default;

    std::array<MixGroup, (int)AudioGroupID::Count>       m_groups;
    std::array<AudioChannel, AudioConst::MAX_CHANNELS>   m_channels = {
        // Default-initialise all channels with sequential IDs
        // Done at runtime in Initialize()
    };

    float     m_masterVolume = 1.0f;
    bool      m_masterMute   = false;
    Vector2   m_listenerPos  = {};
    int       m_outputChannels = 2;
    int       m_sampleRate     = AudioConst::SAMPLE_RATE;

    mutable std::mutex m_mutex;  // Protects channel state from audio/main thread races
    bool m_initialized = false;

    // Internal scratch buffer to avoid per-frame allocation
    std::vector<float> m_scratchBuffer;
};

} // namespace BADGE2D
