// ==============================================================================
// AudioChannel.cpp — Per-voice mixing with pitch, pan, fade, spatial
// ==============================================================================

#include "AudioChannel.h"
#include <cmath>
#include <algorithm>
#include <cstring>

namespace BADGE2D {

static constexpr float PI = 3.14159265f;

// ==============================================================================
// Playback control
// ==============================================================================
void AudioChannel::Play(std::shared_ptr<SoundClip> clip, ChannelFlags flags) {
    m_clip    = std::move(clip);
    m_flags   = flags;
    m_playPos = 0.0;
    m_state   = PlaybackState::Playing;
    m_fade    = {};
}

void AudioChannel::Stop() {
    m_state   = PlaybackState::Stopped;
    m_playPos = 0.0;
    m_clip    = nullptr;
}

void AudioChannel::Pause() {
    if (m_state == PlaybackState::Playing)
        m_state = PlaybackState::Paused;
}

void AudioChannel::Resume() {
    if (m_state == PlaybackState::Paused)
        m_state = PlaybackState::Playing;
}

void AudioChannel::FadeTo(float targetVolume, float duration) {
    m_fade.fromVolume = m_volume;
    m_fade.toVolume   = targetVolume;
    m_fade.duration   = duration;
    m_fade.elapsed    = 0.0f;
    m_fade.active     = true;
    m_state           = PlaybackState::Fading;
}

// ==============================================================================
// State queries
// ==============================================================================
double AudioChannel::GetPlaybackTime() const {
    if (!m_clip || m_clip->GetSampleRate() == 0) return 0.0;
    return m_playPos / m_clip->GetSampleRate();
}

double AudioChannel::GetProgress() const {
    double dur = GetDuration();
    return (dur > 0.0) ? GetPlaybackTime() / dur : 0.0;
}

// ==============================================================================
// Spatial gain + pan computation
// ==============================================================================
float AudioChannel::ComputeSpatialGain(const Vector2& listenerPos,
                                         float& outPanL, float& outPanR) const {
    if (!m_spatial) { outPanL = outPanR = 1.0f; return 1.0f; }

    float dx   = m_worldPos.x - listenerPos.x;
    float dy   = m_worldPos.y - listenerPos.y;
    float dist = std::sqrt(dx*dx + dy*dy);

    // Distance attenuation (inverse square with min/max clamp)
    float gain = 1.0f;
    if (dist <= m_minDist) {
        gain = 1.0f;
    } else if (dist >= m_maxDist) {
        gain = 0.0f;
    } else {
        float t = (dist - m_minDist) / (m_maxDist - m_minDist);
        gain = 1.0f / (1.0f + m_rolloff * t * t);
    }

    // Pan based on angle (simple panning: right = positive X)
    float normX = (dist > 0.001f) ? dx / dist : 0.0f;
    float angle = normX;  // -1..1 maps to full left..right
    // Equal-power panning
    float panAngle = (angle + 1.0f) * 0.5f * PI * 0.5f;
    outPanL = std::cos(panAngle) * std::sqrt(2.0f);
    outPanR = std::sin(panAngle) * std::sqrt(2.0f);

    return gain;
}

// ==============================================================================
// UpdateFade — called from main thread each frame
// ==============================================================================
void AudioChannel::UpdateFade(float dt) {
    if (!m_fade.active) return;
    m_fade.elapsed += dt;
    float t = m_fade.elapsed / m_fade.duration;
    if (t >= 1.0f) {
        m_volume      = m_fade.toVolume;
        m_fade.active = false;
        if (m_volume <= 0.0f && m_state == PlaybackState::Fading)
            Stop();
        else if (m_state == PlaybackState::Fading)
            m_state = PlaybackState::Playing;
    } else {
        m_volume = m_fade.fromVolume + (m_fade.toVolume - m_fade.fromVolume) * t;
    }
}

// ==============================================================================
// MixInto — AUDIO THREAD. Mix frameCount frames into outputBuffer
// Uses linear interpolation for pitch shifting.
// ==============================================================================
void AudioChannel::MixInto(float* outputBuffer, uint32_t frameCount,
                              int outputChannels, float groupVolume,
                              const Vector2& listenerPos) {
    if (!m_clip || m_state == PlaybackState::Stopped ||
        m_state == PlaybackState::Paused) return;

    const float*  srcData      = m_clip->GetData();
    const int     srcChannels  = m_clip->GetChannelCount();
    const uint64_t srcFrames   = m_clip->GetFrameCount();
    if (srcFrames == 0 || !srcData) return;

    // Source sample rate ratio vs output (pitch = 1.0 means normal speed)
    double srcRatio = (double)m_clip->GetSampleRate() /
                      (double)AudioConst::SAMPLE_RATE * m_pitch;

    // Final volume
    float panL, panR;
    float spatialGain = ComputeSpatialGain(listenerPos, panL, panR);
    float masterVol   = m_volume * groupVolume * spatialGain;

    // Pan from manual pan setting (additive to spatial)
    if (!m_spatial) {
        float panAngle = (m_pan + 1.0f) * 0.5f * PI * 0.5f;
        panL = std::cos(panAngle) * std::sqrt(2.0f);
        panR = std::sin(panAngle) * std::sqrt(2.0f);
    }

    for (uint32_t f = 0; f < frameCount; ++f) {
        uint64_t frame0 = (uint64_t)m_playPos;
        uint64_t frame1 = frame0 + 1;

        if (frame0 >= srcFrames) {
            if (HasFlag(m_flags, ChannelFlags::Looping)) {
                m_playPos = 0.0;
                frame0    = 0;
                frame1    = 1;
            } else {
                // Finished
                m_state = PlaybackState::Stopped;
                m_clip  = nullptr;
                if (OnFinished) OnFinished(m_id);
                return;
            }
        }

        float frac  = (float)(m_playPos - (double)frame0);
        if (frame1 >= srcFrames) frame1 = HasFlag(m_flags, ChannelFlags::Looping) ? 0 : frame0;

        // Linear interpolation across channels
        float sampleL, sampleR;
        if (srcChannels == 1) {
            float s0 = srcData[frame0];
            float s1 = srcData[frame1];
            sampleL  = sampleR = s0 + (s1 - s0) * frac;
        } else {
            float l0 = srcData[frame0 * 2    ], l1 = srcData[frame1 * 2    ];
            float r0 = srcData[frame0 * 2 + 1], r1 = srcData[frame1 * 2 + 1];
            sampleL  = l0 + (l1 - l0) * frac;
            sampleR  = r0 + (r1 - r0) * frac;
        }

        // Accumulate into output (interleaved stereo)
        int outIdx = (int)(f * outputChannels);
        if (outputChannels >= 2) {
            outputBuffer[outIdx    ] += sampleL * masterVol * panL;
            outputBuffer[outIdx + 1] += sampleR * masterVol * panR;
        } else {
            outputBuffer[outIdx] += (sampleL + sampleR) * 0.5f * masterVol;
        }

        m_playPos += srcRatio;
    }
}

} // namespace BADGE2D
