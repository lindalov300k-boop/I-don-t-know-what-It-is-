#pragma once
// ==============================================================================
// AudioTypes.h — Shared audio enumerations, IDs, and constants
// ==============================================================================

#include <cstdint>
#include <cfloat>

namespace BADGE2D {

using SoundID   = uint32_t;
using ChannelID = uint32_t;
using GroupID   = uint32_t;
using BusID     = uint32_t;

constexpr SoundID   INVALID_SOUND   = 0;
constexpr ChannelID INVALID_CHANNEL = 0;
constexpr GroupID   INVALID_GROUP   = 0;

// ==============================================================================
// AudioFormat — PCM sample format
// ==============================================================================
enum class AudioFormat {
    Mono8,
    Mono16,
    Stereo8,
    Stereo16,
    Mono32F,      // 32-bit float (miniaudio native)
    Stereo32F
};

inline int GetChannelCount(AudioFormat f) {
    switch (f) {
        case AudioFormat::Stereo8: case AudioFormat::Stereo16:
        case AudioFormat::Stereo32F: return 2;
        default: return 1;
    }
}

inline int GetBytesPerSample(AudioFormat f) {
    switch (f) {
        case AudioFormat::Mono8:   case AudioFormat::Stereo8:   return 1;
        case AudioFormat::Mono16:  case AudioFormat::Stereo16:  return 2;
        case AudioFormat::Mono32F: case AudioFormat::Stereo32F: return 4;
    }
    return 2;
}

// ==============================================================================
// PlaybackState
// ==============================================================================
enum class PlaybackState {
    Stopped,
    Playing,
    Paused,
    Fading
};

// ==============================================================================
// ChannelFlags
// ==============================================================================
enum class ChannelFlags : uint32_t {
    None      = 0,
    Looping   = (1 << 0),
    Streaming = (1 << 1),
    Spatial   = (1 << 2),
    OneShot   = (1 << 3),   // Auto-release when finished
    Paused    = (1 << 4)
};
inline ChannelFlags operator|(ChannelFlags a, ChannelFlags b) { return (ChannelFlags)((uint32_t)a|(uint32_t)b); }
inline ChannelFlags operator&(ChannelFlags a, ChannelFlags b) { return (ChannelFlags)((uint32_t)a&(uint32_t)b); }
inline bool HasFlag(ChannelFlags f, ChannelFlags bit) { return ((uint32_t)f & (uint32_t)bit) != 0; }

// ==============================================================================
// AudioGroup — named mix group (SFX, Music, Ambient, UI, Voice)
// ==============================================================================
enum class AudioGroupID : uint32_t {
    Master  = 0,
    Music   = 1,
    SFX     = 2,
    Ambient = 3,
    Voice   = 4,
    UI      = 5,
    Count   = 6
};

static constexpr const char* AudioGroupNames[] = {
    "Master", "Music", "SFX", "Ambient", "Voice", "UI"
};

// ==============================================================================
// AudioConstants
// ==============================================================================
namespace AudioConst {
    constexpr float MAX_VOLUME          = 1.0f;
    constexpr float DEFAULT_VOLUME      = 1.0f;
    constexpr float DEFAULT_PITCH       = 1.0f;
    constexpr float DEFAULT_ROLLOFF     = 1.0f;
    constexpr float DEFAULT_MAX_DIST    = 1000.0f;
    constexpr float DEFAULT_MIN_DIST    = 50.0f;
    constexpr float DEFAULT_FADE_TIME   = 0.5f;
    constexpr int   MAX_CHANNELS        = 256;
    constexpr int   MAX_STREAMING_CHNL  = 8;
    constexpr int   SAMPLE_RATE         = 44100;
    constexpr int   BUFFER_FRAMES       = 512;
}

} // namespace BADGE2D
