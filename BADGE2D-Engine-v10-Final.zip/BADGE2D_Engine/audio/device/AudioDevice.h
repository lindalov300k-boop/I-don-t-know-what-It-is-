#pragma once
// ==============================================================================
// AudioDevice.h — Low-level audio device abstraction (miniaudio backend)
// Initialises the playback device, owns the mix callback, exposes raw PCM push.
// ==============================================================================

#include "../AudioTypes.h"
#include <functional>
#include <cstddef>
#include <string>

namespace BADGE2D {

// ==============================================================================
// AudioDeviceSpec — Configuration passed to AudioDevice::Initialize
// ==============================================================================
struct AudioDeviceSpec {
    int         sampleRate    = AudioConst::SAMPLE_RATE;
    int         channels      = 2;       // Output channel count
    int         bufferFrames  = AudioConst::BUFFER_FRAMES;
    std::string deviceName    = "";      // Empty = default device
    bool        enableCapture = false;
};

// ==============================================================================
// AudioDevice — Wraps miniaudio ma_device
// The mix callback is provided externally by AudioMixer.
// ==============================================================================
class AudioDevice {
public:
    static AudioDevice& Get();

    // MixCallback: called on audio thread with (outputBuffer, frameCount, channels)
    // Must fill outputBuffer with interleaved f32 samples.
    using MixCallback = std::function<void(float* output, uint32_t frames, int channels)>;

    bool Initialize (const AudioDeviceSpec& spec, MixCallback callback);
    void Shutdown   ();
    bool IsRunning  () const { return m_running; }

    void Start();
    void Stop ();

    int  GetSampleRate()  const { return m_spec.sampleRate;  }
    int  GetChannels()    const { return m_spec.channels;    }
    int  GetBufferFrames()const { return m_spec.bufferFrames; }

    const std::string& GetDeviceName() const { return m_deviceName; }

    // Convert sample count to seconds
    double SamplesToSeconds(uint64_t samples) const {
        return (m_spec.sampleRate > 0)
            ? (double)samples / (double)m_spec.sampleRate : 0.0;
    }

private:
    AudioDevice() = default;

    AudioDeviceSpec  m_spec;
    MixCallback      m_callback;
    std::string      m_deviceName;
    bool             m_running    = false;
    bool             m_initialized= false;

    // miniaudio handle stored as opaque bytes to avoid header dependency
    // Actual ma_device lives in AudioDevice.cpp
};

} // namespace BADGE2D
