// ==============================================================================
// AudioDevice.cpp — miniaudio backend
// miniaudio is a single-header library. Place miniaudio.h in thirdparty/miniaudio/
// and define MINIAUDIO_IMPLEMENTATION in exactly one .cpp.
//
// If miniaudio is not present, the device runs in "null" mode (silence).
// ==============================================================================

#define MINIAUDIO_IMPLEMENTATION

#ifdef __has_include
  #if __has_include(<miniaudio/miniaudio.h>)
    #include <miniaudio/miniaudio.h>
    #define BADGE2D_HAS_MINIAUDIO 1
  #elif __has_include("../../thirdparty/miniaudio/miniaudio.h")
    #include "../../thirdparty/miniaudio/miniaudio.h"
    #define BADGE2D_HAS_MINIAUDIO 1
  #endif
#endif

#include "AudioDevice.h"
#include "../../engine/Logging/Logger.h"
#include <cstring>

namespace BADGE2D {

#ifdef BADGE2D_HAS_MINIAUDIO
// ==============================================================================
// miniaudio callback bridge
// ==============================================================================
struct MAContext {
    ma_device device;
    AudioDevice::MixCallback callback;
};

static MAContext* s_maCtx = nullptr;

static void ma_data_callback(ma_device* pDevice, void* pOutput,
                               const void* /*pInput*/, ma_uint32 frameCount) {
    (void)pDevice;
    if (s_maCtx && s_maCtx->callback)
        s_maCtx->callback((float*)pOutput, frameCount,
                           pDevice->playback.channels);
    else
        memset(pOutput, 0, frameCount * pDevice->playback.channels * sizeof(float));
}
#endif

// ==============================================================================
// AudioDevice
// ==============================================================================
AudioDevice& AudioDevice::Get() {
    static AudioDevice instance;
    return instance;
}

bool AudioDevice::Initialize(const AudioDeviceSpec& spec, MixCallback callback) {
    if (m_initialized) return true;
    m_spec     = spec;
    m_callback = std::move(callback);

#ifdef BADGE2D_HAS_MINIAUDIO
    s_maCtx = new MAContext();
    s_maCtx->callback = m_callback;

    ma_device_config cfg = ma_device_config_init(ma_device_type_playback);
    cfg.playback.format   = ma_format_f32;
    cfg.playback.channels = (ma_uint32)spec.channels;
    cfg.sampleRate        = (ma_uint32)spec.sampleRate;
    cfg.dataCallback      = ma_data_callback;
    cfg.periodSizeInFrames= (ma_uint32)spec.bufferFrames;

    if (ma_device_init(nullptr, &cfg, &s_maCtx->device) != MA_SUCCESS) {
        LOG_ERROR("[AudioDevice] Failed to init miniaudio device.");
        delete s_maCtx; s_maCtx = nullptr;
        m_initialized = true;  // Continue in null mode
        return true;
    }

    m_deviceName = s_maCtx->device.playback.name;
    LOG_INFOF("[AudioDevice] Initialized: '%s' %dHz %dch %d frames",
              m_deviceName.c_str(), spec.sampleRate, spec.channels, spec.bufferFrames);
    m_initialized = true;
    Start();
#else
    LOG_WARN("[AudioDevice] miniaudio not found — running in null (silent) mode.");
    m_deviceName = "Null Device";
    m_initialized = true;
#endif
    return true;
}

void AudioDevice::Start() {
#ifdef BADGE2D_HAS_MINIAUDIO
    if (s_maCtx && !m_running) {
        ma_device_start(&s_maCtx->device);
        m_running = true;
        LOG_INFO("[AudioDevice] Started.");
    }
#else
    m_running = true;
#endif
}

void AudioDevice::Stop() {
#ifdef BADGE2D_HAS_MINIAUDIO
    if (s_maCtx && m_running) {
        ma_device_stop(&s_maCtx->device);
        m_running = false;
    }
#else
    m_running = false;
#endif
}

void AudioDevice::Shutdown() {
    if (!m_initialized) return;
    Stop();
#ifdef BADGE2D_HAS_MINIAUDIO
    if (s_maCtx) {
        ma_device_uninit(&s_maCtx->device);
        delete s_maCtx; s_maCtx = nullptr;
    }
#endif
    m_initialized = false;
    LOG_INFO("[AudioDevice] Shutdown.");
}

} // namespace BADGE2D
