#pragma once
// ==============================================================================
// StreamingSource.h — Streaming audio playback (double-buffered ring buffer)
// For music and long ambient sounds that don't fit comfortably in RAM.
// ==============================================================================

#include "../AudioTypes.h"
#include "../mixer/AudioChannel.h"
#include <string>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <vector>
#include <memory>

namespace BADGE2D {

// ==============================================================================
// StreamingBuffer — Double-buffered PCM chunk ring
// ==============================================================================
struct StreamingBuffer {
    static constexpr int   BUFFER_COUNT    = 2;
    static constexpr int   FRAMES_PER_BUF  = 8192;

    struct Chunk {
        std::vector<float> data;
        int                frames     = 0;
        bool               ready      = false;
        bool               lastChunk  = false;
    };

    std::array<Chunk, BUFFER_COUNT> chunks;
    int   readIndex  = 0;  // Consumer (audio thread)
    int   writeIndex = 0;  // Producer (decode thread)
};

// ==============================================================================
// StreamingSource — Manages a background decode thread + streaming channel
// ==============================================================================
class StreamingSource {
public:
    explicit StreamingSource(ChannelID channelID);
    ~StreamingSource();

    bool Open  (const std::string& filepath);
    void Close ();

    void Play  (bool looping = false);
    void Stop  ();
    void Pause ();
    void Resume();

    void SetVolume(float v);
    void SetPitch (float p);
    void FadeIn   (float duration, float targetVolume = 1.0f);
    void FadeOut  (float duration);
    void CrossFadeTo(const std::string& filepath, float duration);

    bool        IsPlaying()    const { return m_playing.load();  }
    bool        IsPaused ()    const { return m_paused.load();   }
    ChannelID   GetChannelID() const { return m_channelID;       }
    double      GetTime    ()  const;   // Seconds into track

    // Update — called from main thread each frame.
    // Feeds decoded chunks to the channel's clip on-demand.
    void Update();

    std::string m_currentFile;

private:
    void DecodeThread();  // Background PCM decode worker

    ChannelID   m_channelID;
    AudioChannel* m_channel = nullptr;

    StreamingBuffer   m_ringBuffer;
    std::thread       m_decodeThread;
    std::mutex        m_bufMutex;
    std::condition_variable m_bufCV;

    std::atomic<bool> m_playing  {false};
    std::atomic<bool> m_paused   {false};
    std::atomic<bool> m_looping  {false};
    std::atomic<bool> m_shutdown {false};

    int      m_channels    = 2;
    int      m_sampleRate  = AudioConst::SAMPLE_RATE;
    uint64_t m_totalFrames = 0;
    uint64_t m_streamPos   = 0;  // Frames decoded so far

    // Accumulated PCM for the channel's rolling clip
    std::shared_ptr<SoundClip> m_streamClip;
};

} // namespace BADGE2D
