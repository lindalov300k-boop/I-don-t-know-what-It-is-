// ==============================================================================
// StreamingSource.cpp — Streaming audio implementation
// ==============================================================================

#include "StreamingSource.h"
#include "../clips/SoundClip.h"
#include "../../engine/Logging/Logger.h"
#include <cstring>
#include <algorithm>

namespace BADGE2D {

StreamingSource::StreamingSource(ChannelID channelID)
    : m_channelID(channelID) {}

StreamingSource::~StreamingSource() {
    Close();
}

bool StreamingSource::Open(const std::string& filepath) {
    Close();
    m_currentFile = filepath;

    // Pre-load a large chunk to validate the file + fill first buffer
    auto initial = SoundLoader::Load(filepath, 0);
    if (!initial || !initial->IsValid()) {
        LOG_ERRORF("[StreamingSource] Failed to open: %s", filepath.c_str());
        return false;
    }

    m_channels    = initial->GetChannelCount();
    m_sampleRate  = initial->GetSampleRate();
    m_totalFrames = initial->GetFrameCount();

    // For simplicity, full file is loaded into a shared clip.
    // True streaming (chunk-by-chunk decode) is hooked here for large files.
    m_streamClip = initial;
    LOG_INFOF("[StreamingSource] Opened '%s' %.2fs",
              filepath.c_str(), initial->GetDuration());
    return true;
}

void StreamingSource::Close() {
    Stop();
    m_shutdown.store(true);
    m_bufCV.notify_all();
    if (m_decodeThread.joinable()) m_decodeThread.join();
    m_shutdown.store(false);
    m_streamClip = nullptr;
    m_currentFile.clear();
}

void StreamingSource::Play(bool looping) {
    m_looping.store(looping);
    m_playing.store(true);
    m_paused.store(false);
    m_streamPos = 0;

    if (m_channel && m_streamClip) {
        ChannelFlags flags = ChannelFlags::Streaming;
        if (looping) flags = flags | ChannelFlags::Looping;
        m_channel->Play(m_streamClip, flags);
    }
}

void StreamingSource::Stop() {
    m_playing.store(false);
    m_paused.store(false);
    if (m_channel) m_channel->Stop();
}

void StreamingSource::Pause() {
    m_paused.store(true);
    if (m_channel) m_channel->Pause();
}

void StreamingSource::Resume() {
    if (!m_paused.load()) return;
    m_paused.store(false);
    if (m_channel) m_channel->Resume();
}

void StreamingSource::SetVolume(float v) {
    if (m_channel) m_channel->SetVolume(v);
}

void StreamingSource::SetPitch(float p) {
    if (m_channel) m_channel->SetPitch(p);
}

void StreamingSource::FadeIn(float duration, float targetVolume) {
    if (m_channel) m_channel->FadeIn(duration, targetVolume);
}

void StreamingSource::FadeOut(float duration) {
    if (m_channel) m_channel->FadeOut(duration);
}

void StreamingSource::CrossFadeTo(const std::string& filepath, float duration) {
    FadeOut(duration);
    // New source would start fade-in — handled by AudioManager
    LOG_DEBUGF("[StreamingSource] CrossFade → %s (%.1fs)", filepath.c_str(), duration);
}

double StreamingSource::GetTime() const {
    if (m_channel) return m_channel->GetPlaybackTime();
    return 0.0;
}

void StreamingSource::Update() {
    // In a true streaming implementation, this checks if more PCM is needed
    // and triggers decode. Since we pre-load, this is a no-op for now.
    if (!m_playing.load() || !m_channel) return;

    // Auto-restart looping
    if (m_looping.load() && m_channel->IsStopped()) {
        m_channel->Play(m_streamClip,
                        ChannelFlags::Streaming | ChannelFlags::Looping);
    }
}

void StreamingSource::DecodeThread() {
    // Placeholder for true streaming decode (chunk-by-chunk)
    // Full implementation would decode FRAMES_PER_BUF frames at a time
    // and swap double buffers.
}

} // namespace BADGE2D
