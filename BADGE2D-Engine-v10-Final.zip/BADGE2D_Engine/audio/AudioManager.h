#pragma once
// ==============================================================================
// AudioManager.h — Master audio IModule
// Owns asset library, streaming sources, mixer, device.
// Primary API for game code.
// ==============================================================================

#include "../engine/ModuleSystem/ModuleInterface.h"
#include "AudioTypes.h"
#include "device/AudioDevice.h"
#include "mixer/AudioMixer.h"
#include "clips/SoundClip.h"
#include "streaming/StreamingSource.h"
#include "../utilities/Math/Vector2.h"
#include <unordered_map>
#include <memory>
#include <string>
#include <functional>

namespace BADGE2D {

// ==============================================================================
// AudioManager
// ==============================================================================
class AudioManager : public IModule {
public:
    // IModule
    bool        Initialize()          override;
    void        Shutdown  ()          override;
    void        Update    (double dt) override;
    const char* GetName   ()    const override { return "AudioManager"; }
    uint32_t    GetInitOrder() const  override { return (uint32_t)ModuleInitOrder::Audio; }

    static AudioManager& Get();

    // ==============================================================================
    // Asset library — load and cache clips
    // ==============================================================================
    SoundID  LoadSound     (const std::string& filepath, const std::string& name = "");
    SoundID  GetSoundID    (const std::string& name) const;
    SoundClip* GetClip     (SoundID id) const;
    SoundClip* GetClip     (const std::string& name) const;
    void     UnloadSound   (SoundID id);
    void     UnloadAll     ();
    bool     IsLoaded      (SoundID id) const;

    // Procedural
    SoundID  CreateSine  (const std::string& name, float freq, float dur, float amp = 0.5f);
    SoundID  CreateNoise (const std::string& name, float dur,  float amp = 0.3f);
    SoundID  CreateSquare(const std::string& name, float freq, float dur, float amp = 0.3f);

    // ==============================================================================
    // One-shot playback
    // ==============================================================================
    ChannelID Play        (SoundID id,
                            AudioGroupID group = AudioGroupID::SFX,
                            float volume       = 1.0f,
                            float pitch        = 1.0f,
                            float pan          = 0.0f);

    ChannelID Play        (const std::string& name,
                            AudioGroupID group = AudioGroupID::SFX,
                            float volume       = 1.0f,
                            float pitch        = 1.0f);

    ChannelID PlayLooping (SoundID id,
                            AudioGroupID group = AudioGroupID::SFX,
                            float volume       = 1.0f);

    // 2D spatial
    ChannelID PlayAt      (SoundID id, const Vector2& pos,
                            AudioGroupID group = AudioGroupID::SFX,
                            float volume = 1.0f, float pitch = 1.0f);

    // Pitch/volume randomisation (great for repeated SFX like footsteps)
    ChannelID PlayVaried  (SoundID id,
                            float volumeMin = 0.8f, float volumeMax = 1.2f,
                            float pitchMin  = 0.9f, float pitchMax  = 1.1f,
                            AudioGroupID group = AudioGroupID::SFX);

    // ==============================================================================
    // Channel control
    // ==============================================================================
    void      Stop        (ChannelID id);
    void      Pause       (ChannelID id);
    void      Resume      (ChannelID id);
    void      SetVolume   (ChannelID id, float v);
    void      FadeOut     (ChannelID id, float duration);
    bool      IsPlaying   (ChannelID id) const;

    void      StopAll     (AudioGroupID group = AudioGroupID::Count);

    // ==============================================================================
    // Music (streaming layer)
    // ==============================================================================
    bool      PlayMusic      (const std::string& filepath,
                               bool looping   = true,
                               float fadeIn   = 0.0f,
                               float volume   = 1.0f);
    void      StopMusic      (float fadeOut   = 0.5f);
    void      PauseMusic     ();
    void      ResumeMusic    ();
    void      SetMusicVolume (float v);
    float     GetMusicVolume ()       const { return m_musicVolume; }
    bool      IsMusicPlaying ()       const;
    void      CrossFade      (const std::string& newTrack, float duration = 1.5f);
    double    GetMusicTime   ()       const;

    // ==============================================================================
    // Groups & master
    // ==============================================================================
    void  SetGroupVolume(AudioGroupID g, float v) { AudioMixer::Get().SetGroupVolume(g, v); }
    float GetGroupVolume(AudioGroupID g) const    { return AudioMixer::Get().GetGroupVolume(g); }
    void  MuteGroup     (AudioGroupID g, bool m)  { AudioMixer::Get().MuteGroup(g, m); }

    void  SetMasterVolume(float v)   { AudioMixer::Get().SetMasterVolume(v); }
    float GetMasterVolume()    const { return AudioMixer::Get().GetMasterVolume(); }
    void  SetMasterMute  (bool m)    { AudioMixer::Get().SetMasterMute(m); }

    // ==============================================================================
    // Listener (spatial audio)
    // ==============================================================================
    void    SetListenerPosition(const Vector2& pos) { AudioMixer::Get().SetListenerPosition(pos); }
    Vector2 GetListenerPosition()             const { return AudioMixer::Get().GetListenerPosition(); }

    // ==============================================================================
    // Stats
    // ==============================================================================
    int GetActiveChannels() const { return AudioMixer::Get().GetActiveChannelCount(); }
    int GetLoadedSounds()   const { return (int)m_clips.size(); }

private:
    AudioManager() = default;

    SoundID NextSoundID() { return ++m_nextSoundID; }

    std::unordered_map<SoundID,      std::shared_ptr<SoundClip>> m_clips;
    std::unordered_map<std::string,  SoundID>                    m_nameToID;

    // Music streaming
    std::unique_ptr<StreamingSource>  m_musicA;
    std::unique_ptr<StreamingSource>  m_musicB;
    float                             m_musicVolume   = 1.0f;
    bool                              m_crossfading   = false;
    float                             m_crossfadeTime = 0.0f;
    float                             m_crossfadeElapsed = 0.0f;

    SoundID   m_nextSoundID  = 0;
    bool      m_initialized  = false;

    std::mt19937  m_rng{std::random_device{}()};
};

} // namespace BADGE2D
