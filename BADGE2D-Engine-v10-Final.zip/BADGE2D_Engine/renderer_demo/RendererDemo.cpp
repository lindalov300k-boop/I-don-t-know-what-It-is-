// ==============================================================================
// RendererDemo.cpp — Phase 2 Renderer Integration Demo
//
// Demonstrates all renderer systems:
//   - GLFW window + OpenGL 4.1 context
//   - SpriteBatch (10k sprites, texture slots, tinting)
//   - Camera2D (zoom, pan, shake, world<->screen)
//   - TilemapLayer (static tile mesh with parallax)
//   - ParticleEmitter (fire effect)
//   - PostProcessor (bloom + vignette)
//   - Debug draw (lines, circles, rects)
// ==============================================================================

#include "../BADGE2D.h"
#include <cstdio>
#include <cmath>

using namespace BADGE2D;

// ==============================================================================
// DemoApp
// ==============================================================================
class DemoApp : public Application {
public:
    DemoApp() {
        m_config.windowTitle   = "BADGE2D Engine — Phase 2 Renderer Demo";
        m_config.windowWidth   = 1280;
        m_config.windowHeight  = 720;
        m_config.targetFPS     = 60;
        m_config.enableProfiling = true;
    }

    void OnConfigure(EngineConfig& cfg) override {
        // Register Renderer2D as an engine module
        Engine::Get().RegisterModule<Renderer2D>();
    }

    void OnInit() override {
        LOG_INFO("[Demo] Initializing renderer demo...");

        auto& renderer = Renderer2D::Get();

        // ================================================================
        // 1. Open window
        // ================================================================
        RenderDeviceSpec devSpec;
        devSpec.title  = m_config.windowTitle;
        devSpec.width  = m_config.windowWidth;
        devSpec.height = m_config.windowHeight;
        devSpec.vsync  = true;
        RenderDevice::Get().Initialize(devSpec);

        // Wire quit on window close
        RenderDevice::Get().OnClose = [this]{ Quit(); };
        RenderDevice::Get().OnKey = [this](int key, int, int action, int) {
            HandleKey(key, action);
        };
        RenderDevice::Get().OnMouseScroll = [this](double, double dy) {
            m_cameraController.scrollDelta = (float)dy;
        };

        // ================================================================
        // 2. Camera
        // ================================================================
        m_camera.SetViewportSize(1280, 720);
        m_camera.SetPosition({0, 0});
        m_camera.SetZoom(1.0f);
        m_cameraController = CameraController(&m_camera);
        renderer.SetCamera(&m_camera);

        // ================================================================
        // 3. Create fallback textures (normally loaded from assets)
        // ================================================================
        m_whiteTexture = TextureCache::Get().GetWhiteTexture();

        // Procedural checkerboard texture
        {
            uint8_t checker[16*16*4] = {};
            for (int y = 0; y < 16; ++y)
                for (int x = 0; x < 16; ++x) {
                    bool white = ((x/4 + y/4) % 2 == 0);
                    int i = (y * 16 + x) * 4;
                    checker[i+0] = white ? 200 : 60;
                    checker[i+1] = white ? 200 : 60;
                    checker[i+2] = white ? 200 : 80;
                    checker[i+3] = 255;
                }
            m_checkerTexture = std::make_shared<Texture2D>();
            TextureSpec ts; ts.genMipmaps = false; ts.magFilter = TextureFilter::Nearest;
            m_checkerTexture->LoadFromMemory(checker, 16, 16, 4, ts);
        }

        // ================================================================
        // 4. Tilemap
        // ================================================================
        TileSetDef tsdef;
        tsdef.texture    = m_whiteTexture;
        tsdef.tileWidth  = 32;
        tsdef.tileHeight = 32;
        tsdef.columns    = 1;
        m_tilesetID = renderer.GetTileRenderer().RegisterTileSet(tsdef);

        m_tilemap.name      = "ground";
        m_tilemap.tilesetID = m_tilesetID;
        m_tilemap.Resize(40, 20, 32.0f, 32.0f);
        m_tilemap.offset = {-640, -320};

        // Fill bottom half with tiles
        for (int row = 12; row < 20; ++row)
            for (int col = 0; col < 40; ++col)
                m_tilemap.SetTile(col, row, 1);

        // ================================================================
        // 5. Post-processing
        // ================================================================
        renderer.GetPostProcessor().AddBloom(0.75f, 1.5f);
        renderer.GetPostProcessor().AddVignette(0.80f, 0.4f);

        // ================================================================
        // 6. Particles — fire effect
        // ================================================================
        EmitterConfig fire;
        fire.emissionRate = 80.0f;
        fire.lifetimeMin  = 0.4f; fire.lifetimeMax = 0.9f;
        fire.speedMin     = 60.f; fire.speedMax    = 120.f;
        fire.angleMin     = Math::ToRadians(70.f);
        fire.angleMax     = Math::ToRadians(110.f);
        fire.sizeStartMin = 12.f; fire.sizeStartMax = 24.f;
        fire.sizeEndMin   = 0.f;  fire.sizeEndMax   = 0.f;
        fire.colorStart   = {1.0f, 0.5f, 0.0f, 1.0f};
        fire.colorEnd     = {1.0f, 0.0f, 0.0f, 0.0f};
        fire.gravity      = {0, 30.f};
        fire.drag         = 0.3f;
        fire.maxParticles = 300;

        m_fireEmitter = ParticleSystem::Get().CreateEmitter("fire", fire);
        m_fireEmitter->SetPosition({0, -80});
        m_fireEmitter->Play();

        LOG_INFO("[Demo] Init complete. Controls: WASD=pan, Scroll=zoom, Space=shake, Esc=quit");
    }

    void HandleKey(int key, int action) {
        // GLFW key constants (hard-coded to avoid GLFW header dependency here)
        constexpr int KEY_ESCAPE = 256;
        constexpr int KEY_SPACE  = 32;
        constexpr int KEY_W = 87; constexpr int KEY_S = 83;
        constexpr int KEY_A = 65; constexpr int KEY_D = 68;
        constexpr int PRESS = 1;  constexpr int RELEASE = 0;

        if (key == KEY_ESCAPE && action == PRESS) Quit();
        if (key == KEY_SPACE  && action == PRESS) {
            m_camera.AddShake(8.0f, 0.4f);
            LOG_DEBUG("[Demo] Camera shake!");
        }
        m_cameraController.keyUp    = (key == KEY_W && action != RELEASE);
        m_cameraController.keyDown  = (key == KEY_S && action != RELEASE);
        m_cameraController.keyLeft  = (key == KEY_A && action != RELEASE);
        m_cameraController.keyRight = (key == KEY_D && action != RELEASE);
    }

    void OnUpdate(double dt) override {
        // Quit if window closed
        if (RenderDevice::Get().ShouldClose()) { Quit(); return; }

        m_time += (float)dt;

        // Camera controller
        m_cameraController.Update((float)dt);

        // Update particles
        ParticleSystem::Get().UpdateAll((float)dt);

        // Animate fire position
        m_fireEmitter->SetPosition({std::sin(m_time * 1.2f) * 120.0f, -100.0f});

        // Animate sprites
        m_spriteAngle += (float)dt * 45.0f * Math::DEG2RAD;
    }

    void OnRender() override {
        auto& renderer = Renderer2D::Get();

        // Clear
        renderer.Clear({0.08f, 0.08f, 0.12f, 1.0f});

        // Begin frame (starts SpriteBatch + PostProcessor capture)
        renderer.BeginFrame();

        // --- Tilemap (behind sprites) ---
        renderer.DrawTilemap(m_tilemap);

        // --- Ground plane (solid quads) ---
        for (int i = -10; i <= 10; ++i) {
            float x = i * 64.0f;
            Color c = (i % 2 == 0) ? Color{0.3f,0.6f,0.3f,1} : Color{0.25f,0.55f,0.25f,1};
            renderer.DrawQuad({x, -200}, {60, 20}, c);
        }

        // --- Rotating sprite grid ---
        for (int y = -2; y <= 2; ++y) {
            for (int x = -4; x <= 4; ++x) {
                float wx = x * 80.0f;
                float wy = y * 80.0f + 40.0f;
                float rot = m_spriteAngle + (float)(x + y) * 0.3f;
                Color tint = {
                    0.5f + 0.5f * std::sin(m_time + x),
                    0.5f + 0.5f * std::cos(m_time * 0.7f + y),
                    0.8f, 1.0f
                };
                renderer.DrawSprite({wx, wy}, {48, 48}, m_checkerTexture, tint, rot);
            }
        }

        // --- Particles ---
        ParticleSystem::Get().RenderAll(renderer.GetSpriteBatch());

        // --- Debug draw ---
        renderer.GetSpriteBatch().DrawCircle({0, -200}, 80.0f, {0.2f,0.8f,0.2f,0.6f}, 24, 2.f);
        renderer.GetSpriteBatch().DrawLine({-400, -200}, {400, -200}, {1,1,1,0.3f}, 1.f);
        renderer.GetSpriteBatch().DrawRect({-60, -60, 120, 120}, {1,0.5f,0,0.8f}, 2.f);

        // --- HUD (camera-space) ---
        // (In a full engine, HUD uses a separate screen-space camera)

        // End frame (flushes batch, applies post-FX, swaps buffers)
        renderer.EndFrame();

        // Print stats every 5 seconds
        static float statTimer = 0;
        static int lastFramePrint = 0;
        statTimer += 0.016f;
        if ((int)(statTimer / 5.0f) != lastFramePrint) {
            lastFramePrint = (int)(statTimer / 5.0f);
            renderer.PrintStats();
        }
    }

    void OnShutdown() override {
        ParticleSystem::Get().Clear();
        m_checkerTexture.reset();
        m_whiteTexture.reset();
        RenderDevice::Get().Shutdown();
        LOG_INFO("[Demo] Shutdown complete.");
    }

private:
    Camera2D            m_camera;
    CameraController    m_cameraController{&m_camera};
    TilemapLayer        m_tilemap;
    uint32_t            m_tilesetID   = 0;
    ParticleEmitter*    m_fireEmitter = nullptr;
    std::shared_ptr<Texture2D> m_whiteTexture;
    std::shared_ptr<Texture2D> m_checkerTexture;

    float               m_time        = 0.0f;
    float               m_spriteAngle = 0.0f;
};

// ==============================================================================
// main
// ==============================================================================
int main() {
    printf("==============================================\n");
    printf("  BADGE2D Engine — Phase 2: Renderer Demo\n");
    printf("==============================================\n\n");
    printf("Controls:\n");
    printf("  WASD       — Pan camera\n");
    printf("  Scroll     — Zoom in/out\n");
    printf("  Space      — Camera shake\n");
    printf("  Esc        — Quit\n\n");

    DemoApp app;
    return app.Run();
}
