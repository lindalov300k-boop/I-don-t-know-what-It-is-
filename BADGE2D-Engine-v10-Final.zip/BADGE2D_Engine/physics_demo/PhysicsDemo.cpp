// ==============================================================================
// PhysicsDemo.cpp — Phase 3 Physics Sandbox
// Demonstrates: rigid bodies, shapes, joints, raycasts, debug draw, ECS sync
// ==============================================================================

#include "../BADGE2D.h"
#include "../physics/world/PhysicsWorld.h"
#include "../physics/world/PhysicsSystem.h"
#include "../physics/debug/PhysicsDebugDraw.h"
#include <cstdio>
#include <cmath>
#include <vector>

using namespace BADGE2D;

class PhysicsDemo : public Application {
public:
    PhysicsDemo() {
        m_config.windowTitle  = "BADGE2D — Phase 3: Physics Demo";
        m_config.windowWidth  = 1280;
        m_config.windowHeight = 720;
        m_config.targetFPS    = 60;
        m_config.enableProfiling = true;
    }

    void OnConfigure(EngineConfig&) override {
        Engine::Get().RegisterModule<Renderer2D>();
        Engine::Get().RegisterModule<PhysicsWorld>();
    }

    void OnInit() override {
        LOG_INFO("[PhysicsDemo] Initializing...");

        // Window
        RenderDeviceSpec spec;
        spec.title  = m_config.windowTitle;
        spec.width  = m_config.windowWidth;
        spec.height = m_config.windowHeight;
        spec.vsync  = true;
        RenderDevice::Get().Initialize(spec);
        RenderDevice::Get().OnKey = [this](int key, int, int action, int) {
            OnKey(key, action);
        };
        RenderDevice::Get().OnMouseScroll = [this](double, double dy) {
            m_camCtrl.scrollDelta = (float)dy;
        };
        RenderDevice::Get().OnMouseButton = [this](int btn, int action, int) {
            if (btn == 0 && action == 1) m_mouseDown = true;
            if (btn == 0 && action == 0) { m_mouseDown = false; m_grabbed = nullptr; }
        };
        RenderDevice::Get().OnMouseMove = [this](double x, double y) {
            m_mouseScreen = {(float)x, (float)y};
        };

        // Camera
        m_camera.SetViewportSize(1280, 720);
        m_camera.SetPosition({0, 0});
        m_camera.SetZoom(0.8f);
        m_camCtrl = CameraController(&m_camera);
        Renderer2D::Get().SetCamera(&m_camera);

        // Physics world
        PhysicsWorldConfig pcfg;
        pcfg.gravity = {0, -500.0f};
        pcfg.useSpacialHash = true;
        m_physics = std::make_unique<PhysicsWorld>(pcfg);
        m_physics->Initialize();

        // Collision callbacks
        m_physics->OnCollisionBegin = [](const CollisionBeginEvent& e) {
            LOG_DEBUGF("[Physics] Collision: body %u <-> body %u",
                       e.bodyA->GetID(), e.bodyB->GetID());
        };

        BuildScene();

        LOG_INFO("[PhysicsDemo] Ready. Controls:");
        LOG_INFO("  WASD/Scroll — camera  |  Space — spawn box  |  G — gravity flip");
        LOG_INFO("  1 — Domino chain  |  2 — Pendulum  |  3 — Spring bridge");
        LOG_INFO("  R — Reset scene  |  D — Debug draw  |  Esc — Quit");
    }

    void BuildScene() {
        m_physics->Step(0); // Warm init

        // Ground platform
        m_ground = m_physics->CreateBoxBody(BodyType::Static, {0, -300}, 1200, 40,
                                              PhysicsMaterial::Stone());
        m_ground->SetTag("ground");

        // Side walls
        m_physics->CreateBoxBody(BodyType::Static, {-620, 0}, 40, 700,
                                   PhysicsMaterial::Stone());
        m_physics->CreateBoxBody(BodyType::Static, { 620, 0}, 40, 700,
                                   PhysicsMaterial::Stone());

        // Staircase platforms (static)
        for (int i = 0; i < 5; ++i) {
            float x = -350.0f + i * 140.0f;
            float y = -200.0f + i * 60.0f;
            m_physics->CreateBoxBody(BodyType::Static, {x, y}, 120, 20,
                                       PhysicsMaterial::Wood());
        }

        // A pile of dynamic boxes
        for (int row = 0; row < 4; ++row)
            for (int col = 0; col < 3; ++col)
                m_physics->CreateBoxBody(BodyType::Dynamic,
                    {-100.0f + col*70.0f, -250.0f + row*60.0f},
                    50, 50, PhysicsMaterial::Wood());

        // Circles
        for (int i = 0; i < 5; ++i)
            m_physics->CreateCircleBody(BodyType::Dynamic,
                {200.0f + i*40.0f, 100.0f}, 20.0f + i*5.0f,
                PhysicsMaterial::Rubber());

        // A capsule-player placeholder
        m_player = m_physics->CreateCapsuleBody(BodyType::Dynamic,
                    {0, 200}, 80, 20, PhysicsMaterial::Wood());
        m_player->SetFixedRotation(true);
        m_player->SetTag("player");
        m_player->SetGravityScale(1.0f);

        // Trigger zone
        m_trigger = m_physics->CreateBoxBody(BodyType::Static, {300, -220}, 80, 40);
        m_trigger->SetTrigger(true);
        m_trigger->SetTag("trigger");
        m_trigger->OnTriggerEnter = [](PhysicsBody* other) {
            LOG_INFOF("[Trigger] Entered by body %u ('%s')",
                      other->GetID(), other->GetTag().c_str());
        };

        // Hinge pendulum
        {
            auto* pivot  = m_physics->CreateBoxBody(BodyType::Static,  {-400, 200}, 20, 20);
            auto* weight = m_physics->CreateBoxBody(BodyType::Dynamic, {-400, 50},  30, 30,
                                                      PhysicsMaterial::Metal());
            m_pendulumJoint = m_physics->CreateDistanceJoint(
                pivot, weight, pivot->GetPosition(), weight->GetPosition(), 150.0f);
            weight->ApplyImpulse({200, 0});
        }

        // Spring bridge
        {
            const int LINKS = 6;
            const float linkW = 60.0f, linkH = 15.0f;
            const float startX = 200.0f, startY = -50.0f;
            PhysicsBody* prev = nullptr;
            PhysicsBody* anchor = m_physics->CreateBoxBody(BodyType::Static,
                                    {startX - linkW, startY}, linkW, linkH);
            prev = anchor;

            for (int i = 0; i < LINKS; ++i) {
                float x = startX + i * (linkW + 4.0f);
                auto* link = m_physics->CreateBoxBody(BodyType::Dynamic, {x, startY},
                                                        linkW, linkH, PhysicsMaterial::Wood());
                m_physics->CreateHingeJoint(prev, link,
                    {prev->GetPosition().x + linkW*0.5f, startY});
                prev = link;
            }
            m_physics->CreateBoxBody(BodyType::Static,
                {startX + LINKS*(linkW+4.0f), startY}, linkW, linkH);
        }
    }

    void OnKey(int key, int action) {
        // GLFW key codes
        constexpr int KEY_ESC   = 256, KEY_SPC = 32,  KEY_R = 82;
        constexpr int KEY_G     = 71,  KEY_D   = 68,  KEY_1 = 49;
        constexpr int KEY_2     = 50,  KEY_3   = 51;
        constexpr int KEY_W     = 87,  KEY_A   = 65,  KEY_S = 83;
        constexpr int PRESS = 1, RELEASE = 0;

        if (key == KEY_ESC && action == PRESS) Quit();
        if (key == KEY_D   && action == PRESS) m_debugDraw = !m_debugDraw;
        if (key == KEY_G   && action == PRESS) {
            auto g = m_physics->GetGravity();
            m_physics->SetGravity({g.x, -g.y});
        }
        if (key == KEY_R && action == PRESS) {
            m_physics->Shutdown();
            m_physics->Initialize();
            BuildScene();
        }
        if (key == KEY_SPC && action == PRESS) {
            // Spawn box at camera center + some random offset
            Vector2 pos = m_camera.GetPosition() + Vector2{
                (float)(rand() % 200 - 100), 100.0f};
            m_physics->CreateBoxBody(BodyType::Dynamic, pos, 40, 40,
                                       PhysicsMaterial::Rubber());
        }

        m_camCtrl.keyUp    = (key == KEY_W && action != RELEASE);
        m_camCtrl.keyDown  = (key == KEY_S && action != RELEASE);
        m_camCtrl.keyLeft  = (key == KEY_A && action != RELEASE);
        m_camCtrl.keyRight = (key == KEY_D && action != RELEASE);
    }

    void OnUpdate(double dt) override {
        if (RenderDevice::Get().ShouldClose()) { Quit(); return; }
        m_time += (float)dt;
        m_camCtrl.Update((float)dt);

        // Mouse grab (kinematic drag with MouseJoint)
        if (m_mouseDown) {
            Vector2 worldPt = m_camera.ScreenToWorld(m_mouseScreen);
            if (!m_grabbed) {
                m_grabbed = m_physics->PointQuery(worldPt);
                if (m_grabbed && m_grabbed->GetBodyType() == BodyType::Dynamic) {
                    m_mouseJoint = m_physics->CreateMouseJoint(m_grabbed, worldPt, 300, 20);
                } else {
                    m_grabbed = nullptr;
                }
            } else if (m_mouseJoint) {
                m_mouseJoint->SetTarget(worldPt);
            }
        } else if (m_mouseJoint) {
            m_physics->DestroyJoint(m_mouseJoint);
            m_mouseJoint = nullptr;
            m_grabbed = nullptr;
        }
    }

    void OnFixedUpdate(double dt) override {
        m_physics->Step((float)dt);
    }

    void OnRender() override {
        auto& renderer = Renderer2D::Get();
        renderer.Clear({0.05f, 0.05f, 0.1f, 1.0f});
        renderer.BeginFrame();

        if (m_debugDraw) {
            m_debugRenderer.Draw(*m_physics, renderer.GetSpriteBatch(),
                DebugDrawFlags::Colliders | DebugDrawFlags::Velocities |
                DebugDrawFlags::AABBs | DebugDrawFlags::Joints);
        } else {
            // Simple colored quads for each body
            for (const auto& body : m_physics->GetBodies()) {
                Color c = (body->GetBodyType() == BodyType::Static)
                    ? Color{0.5f,0.5f,0.5f,1} : Color{0.3f,0.7f,1,1};
                if (body->IsTrigger()) c = {1,1,0,0.5f};
                AABB aabb = body->GetAABB();
                renderer.DrawQuad(body->GetPosition(),
                    {aabb.Width(), aabb.Height()}, c, body->GetRotation());
            }
        }

        // HUD
        auto& stats = m_physics->GetStats();
        // (In a full engine, text rendering would go here)

        renderer.EndFrame();
    }

    void OnShutdown() override {
        m_physics->Shutdown();
        RenderDevice::Get().Shutdown();
        LOG_INFO("[PhysicsDemo] Shutdown.");
    }

private:
    Camera2D         m_camera;
    CameraController m_camCtrl{&m_camera};

    std::unique_ptr<PhysicsWorld> m_physics;
    PhysicsDebugDraw m_debugRenderer;

    PhysicsBody*     m_ground        = nullptr;
    PhysicsBody*     m_player        = nullptr;
    PhysicsBody*     m_trigger       = nullptr;
    PhysicsBody*     m_grabbed       = nullptr;
    DistanceJoint*   m_pendulumJoint = nullptr;
    MouseJoint*      m_mouseJoint    = nullptr;

    Vector2          m_mouseScreen   = {};
    bool             m_mouseDown     = false;
    bool             m_debugDraw     = true;
    float            m_time          = 0.0f;
};

int main() {
    printf("======================================\n");
    printf("  BADGE2D Engine — Phase 3: Physics\n");
    printf("======================================\n\n");
    printf("Controls:\n");
    printf("  WASD / Scroll  — Camera pan/zoom\n");
    printf("  Space          — Spawn box\n");
    printf("  G              — Flip gravity\n");
    printf("  D              — Toggle debug draw\n");
    printf("  R              — Reset scene\n");
    printf("  LMB Drag       — Grab & throw bodies\n");
    printf("  Esc            — Quit\n\n");

    PhysicsDemo app;
    return app.Run();
}
