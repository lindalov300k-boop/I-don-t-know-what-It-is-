#pragma once
// ==============================================================================
// Components.h — All built-in engine component types
// ==============================================================================

#include "../../utilities/Math/MathUtils.h"
#include "../../utilities/Math/Vector2.h"
#include <string>
#include <vector>
#include <cstdint>
#include <functional>
#include <memory>
namespace BADGE2D { class Texture2D; }

namespace BADGE2D {

// ==============================================================================
// TransformComponent — Position, rotation, scale in world space
// ==============================================================================
struct TransformComponent {
    Vector2 position    = Vector2::Zero();
    float   rotation    = 0.0f;            // Radians
    Vector2 scale       = Vector2::One();
    Entity  parent      = NULL_ENTITY;     // Parent entity (0 = no parent)
    bool    dirty       = true;            // World matrix needs recalculation

    Transform2D ToTransform2D() const {
        return {position, rotation, scale};
    }
};

// ==============================================================================
// SpriteComponent — Rendering data for a 2D sprite
// ==============================================================================
struct SpriteComponent {
    uint32_t    textureID   = 0;       // Handle to loaded texture (legacy)
    std::shared_ptr<Texture2D> texture; // Smart-pointer asset (Phase 5+)
    Rect2D      uvRect      = {0,0,1,1}; // UV region in atlas (normalized)
    Color       tint        = Color::White();
    Vector2     pivot       = {0.5f, 0.5f};  // Pivot point (0-1, center = 0.5)
    Vector2     size        = {64, 64};       // Sprite size in pixels
    int         sortOrder   = 0;       // Render order (higher = front)
    bool        flipX       = false;
    bool        flipY       = false;
    bool        visible     = true;
};

// ==============================================================================
// CameraComponent — 2D camera view parameters
// ==============================================================================
struct CameraComponent {
    float    zoom           = 1.0f;
    float    rotation       = 0.0f;
    Vector2  viewport       = {1280, 720};
    Color    clearColor     = {0.1f, 0.1f, 0.15f, 1.0f};
    float    nearPlane      = -1.0f;
    float    farPlane       = 1.0f;
    bool     isMain         = false;
    bool     active         = true;

    // Returns world-to-screen matrix coefficients
    Rect2D GetViewBounds(const Vector2& worldPos) const {
        Vector2 halfSize = {viewport.x * 0.5f / zoom, viewport.y * 0.5f / zoom};
        return {worldPos.x - halfSize.x, worldPos.y - halfSize.y,
                halfSize.x * 2.0f,       halfSize.y * 2.0f};
    }
};

// ==============================================================================
// RigidBody2DComponent — Physics body
// ==============================================================================
enum class BodyType { Static, Kinematic, Dynamic };

struct RigidBody2DComponent {
    BodyType bodyType       = BodyType::Dynamic;
    Vector2  velocity       = Vector2::Zero();
    Vector2  force          = Vector2::Zero();
    float    angularVelocity = 0.0f;
    float    torque          = 0.0f;
    float    mass            = 1.0f;
    float    invMass         = 1.0f;   // Updated on mass change
    float    inertia         = 1.0f;
    float    linearDamping   = 0.0f;
    float    angularDamping  = 0.01f;
    float    gravityScale    = 1.0f;
    bool     fixedRotation   = false;
    bool     isSleeping      = false;

    void SetMass(float m) {
        mass    = m;
        invMass = (m > 0.0f && bodyType == BodyType::Dynamic) ? 1.0f / m : 0.0f;
    }
    void ApplyForce    (const Vector2& f)             { force += f; }
    void ApplyImpulse  (const Vector2& impulse)       { velocity += impulse * invMass; }
    void ApplyTorque   (float t)                      { torque += t; }
};

// ==============================================================================
// BoxCollider2DComponent
// ==============================================================================
struct BoxCollider2DComponent {
    Vector2 size    = {1.0f, 1.0f};
    Vector2 offset  = Vector2::Zero();
    float   density = 1.0f;
    float   friction = 0.5f;
    float   restitution = 0.3f;
    bool    isTrigger   = false;
    uint32_t layer      = 0;
    uint32_t mask       = 0xFFFFFFFF;
};

// ==============================================================================
// CircleCollider2DComponent
// ==============================================================================
struct CircleCollider2DComponent {
    float   radius      = 0.5f;
    Vector2 offset      = Vector2::Zero();
    float   density     = 1.0f;
    float   friction    = 0.5f;
    float   restitution = 0.3f;
    bool    isTrigger   = false;
    uint32_t layer      = 0;
    uint32_t mask       = 0xFFFFFFFF;
};

// ==============================================================================
// AnimationComponent
// ==============================================================================
struct AnimationComponent {
    std::string currentClip;
    float       time        = 0.0f;
    float       speed       = 1.0f;
    bool        playing     = true;
    bool        looping     = true;
    int         currentFrame= 0;
};

// ==============================================================================
// AudioSourceComponent
// ==============================================================================
struct AudioSourceComponent {
    uint32_t audioClipID = 0;
    float    volume      = 1.0f;
    float    pitch       = 1.0f;
    float    pan         = 0.0f;   // -1 left, 0 center, 1 right
    bool     looping     = false;
    bool     playOnStart = false;
    bool     is3D        = false;
    float    minDistance = 1.0f;
    float    maxDistance = 100.0f;
    bool     playing     = false;
};

// ==============================================================================
// ScriptComponent — Attaches a script to an entity
// ==============================================================================
struct ScriptComponent {
    std::string scriptName;
    void*       scriptInstance = nullptr;
    bool        enabled        = true;

    // Lifecycle callbacks (bound by scripting layer)
    std::function<void()>          OnStart;
    std::function<void(double dt)> OnUpdate;
    std::function<void()>          OnDestroy;
};


// ==============================================================================
// NameComponent — Human-readable entity name
// ==============================================================================
struct NameComponent {
    std::string name = "Entity";
};

// ==============================================================================
// TagComponent — Arbitrary string tags
// ==============================================================================
struct TagComponent {
    std::string              tag;   // Primary tag (convenient single-tag access)
    std::vector<std::string> tags;  // Multi-tag list

    void AddTag(const std::string& tag) {
        for (auto& t : tags) if (t == tag) return;
        tags.push_back(tag);
    }
    void RemoveTag(const std::string& tag) {
        tags.erase(std::remove(tags.begin(), tags.end(), tag), tags.end());
    }
    bool HasTag(const std::string& tag) const {
        for (auto& t : tags) if (t == tag) return true;
        return false;
    }
};

// ==============================================================================
// UIComponent — Marks entity as a UI element
// ==============================================================================
struct UIComponent {
    bool  anchored   = false;
    float anchorX    = 0.5f;
    float anchorY    = 0.5f;
    int   renderLayer = 100;
    bool  interactable = true;
    bool  visible    = true;
};

// ==============================================================================
// TilemapComponent
// ==============================================================================
struct TilemapComponent {
    uint32_t              tilesetID   = 0;
    int                   cols        = 0;
    int                   rows        = 0;
    float                 tileWidth   = 32.0f;
    float                 tileHeight  = 32.0f;
    std::vector<uint16_t> tiles;          // Flat row-major tile indices

    uint16_t GetTile(int col, int row) const {
        if (col < 0 || row < 0 || col >= cols || row >= rows) return 0;
        return tiles[row * cols + col];
    }
    void SetTile(int col, int row, uint16_t id) {
        if (col < 0 || row < 0 || col >= cols || row >= rows) return;
        tiles[row * cols + col] = id;
    }
};

} // namespace BADGE2D
