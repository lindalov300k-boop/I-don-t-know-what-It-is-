#pragma once
// ==============================================================================
// ComponentManager.h — Dense component storage with type registration
// ==============================================================================

#include "../entity/Entity.h"
#include <unordered_map>
#include <memory>
#include <typeindex>
#include <vector>
#include <cassert>

namespace BADGE2D {

// ==============================================================================
// IComponentArray — Type-erased base for component storage
// ==============================================================================
class IComponentArray {
public:
    virtual ~IComponentArray() = default;
    virtual void OnEntityDestroyed(Entity entity) = 0;
};

// ==============================================================================
// ComponentArray<T> — Packed dense array storage for one component type
// Maintains a dense array + sparse mapping for O(1) access.
// ==============================================================================
template<typename T>
class ComponentArray : public IComponentArray {
public:
    void Insert(Entity entity, T component) {
        assert(m_entityToIndex.find(entity) == m_entityToIndex.end()
               && "Component added to entity that already has it");

        size_t newIndex = m_size;
        m_entityToIndex[entity]    = newIndex;
        m_indexToEntity[newIndex]  = entity;

        if (m_components.size() <= newIndex)
            m_components.resize(newIndex + 1);

        m_components[newIndex] = std::move(component);
        ++m_size;
    }

    void Remove(Entity entity) {
        assert(m_entityToIndex.count(entity) && "Removing nonexistent component");

        size_t removedIndex     = m_entityToIndex[entity];
        size_t lastIndex        = m_size - 1;
        Entity lastEntity       = m_indexToEntity[lastIndex];

        // Move last element into the gap
        m_components[removedIndex]   = std::move(m_components[lastIndex]);
        m_entityToIndex[lastEntity]  = removedIndex;
        m_indexToEntity[removedIndex]= lastEntity;

        m_entityToIndex.erase(entity);
        m_indexToEntity.erase(lastIndex);
        --m_size;
    }

    T& Get(Entity entity) {
        assert(m_entityToIndex.count(entity) && "Accessing nonexistent component");
        return m_components[m_entityToIndex.at(entity)];
    }

    const T& Get(Entity entity) const {
        assert(m_entityToIndex.count(entity) && "Accessing nonexistent component");
        return m_components[m_entityToIndex.at(entity)];
    }

    bool Has(Entity entity) const {
        return m_entityToIndex.count(entity) > 0;
    }

    void OnEntityDestroyed(Entity entity) override {
        if (Has(entity)) Remove(entity);
    }

    // Iterate all components
    T*     Data()  { return m_components.data(); }
    size_t Count() const { return m_size; }

    std::vector<T>& Components() { return m_components; }

private:
    std::vector<T>                           m_components;
    std::unordered_map<Entity, size_t>       m_entityToIndex;
    std::unordered_map<size_t, Entity>       m_indexToEntity;
    size_t                                   m_size = 0;
};

// ==============================================================================
// ComponentRegistry — Assigns unique component type IDs
// ==============================================================================
class ComponentRegistry {
public:
    template<typename T>
    static uint32_t GetTypeID() {
        static uint32_t id = s_nextId++;
        assert(id < MAX_COMPONENTS && "Too many component types registered");
        return id;
    }

private:
    static inline uint32_t s_nextId = 0;
};

// ==============================================================================
// ComponentManager — Owns all component arrays
// ==============================================================================
class ComponentManager {
public:
    template<typename T>
    void RegisterComponent() {
        std::type_index key(typeid(T));
        assert(m_arrays.find(key) == m_arrays.end()
               && "Component type registered twice");
        m_arrays[key] = std::make_shared<ComponentArray<T>>();
    }

    template<typename T>
    void AddComponent(Entity entity, T component) {
        GetArray<T>()->Insert(entity, std::move(component));
    }

    template<typename T>
    void RemoveComponent(Entity entity) {
        GetArray<T>()->Remove(entity);
    }

    template<typename T>
    T& GetComponent(Entity entity) {
        return GetArray<T>()->Get(entity);
    }

    template<typename T>
    const T& GetComponent(Entity entity) const {
        return GetArrayConst<T>()->Get(entity);
    }

    template<typename T>
    bool HasComponent(Entity entity) const {
        auto* arr = GetArrayConst<T>();
        return arr && arr->Has(entity);
    }

    void OnEntityDestroyed(Entity entity) {
        for (auto& [type, array] : m_arrays)
            array->OnEntityDestroyed(entity);
    }

    template<typename T>
    ComponentArray<T>* GetArray() {
        auto it = m_arrays.find(std::type_index(typeid(T)));
        assert(it != m_arrays.end() && "Component type not registered");
        return static_cast<ComponentArray<T>*>(it->second.get());
    }

    template<typename T>
    const ComponentArray<T>* GetArrayConst() const {
        auto it = m_arrays.find(std::type_index(typeid(T)));
        if (it == m_arrays.end()) return nullptr;
        return static_cast<const ComponentArray<T>*>(it->second.get());
    }

private:
    std::unordered_map<std::type_index, std::shared_ptr<IComponentArray>> m_arrays;
};

} // namespace BADGE2D
