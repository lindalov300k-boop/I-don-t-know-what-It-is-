// ==============================================================================
// World.cpp
// ==============================================================================

#include "World.h"
#include "../../engine/Logging/Logger.h"

namespace BADGE2D {

World::World()  = default;
World::~World() { Clear(); }

Entity World::CreateEntity(const std::string& name) {
    Entity e = m_entities.CreateEntity();
    if (!name.empty()) SetName(e, name);
    return e;
}

void World::DestroyEntity(Entity entity) {
    m_entities.DestroyEntity(entity);
    m_components.DestroyEntity(entity);
}

bool World::IsAlive(Entity entity) const {
    return m_entities.IsAlive(entity);
}

void World::SetName(Entity entity, const std::string& name) {
    m_entities.SetName(entity, name);
}

const std::string& World::GetName(Entity entity) const {
    return m_entities.GetName(entity);
}

void World::UpdateSystems(double dt) {
    for (auto& sys : m_systems)
        sys->OnUpdate(*this, dt);
}

void World::FixedUpdateSystems(double dt) {
    for (auto& sys : m_systems)
        sys->OnFixedUpdate(*this, dt);
}

void World::RenderSystems() {
    for (auto& sys : m_systems)
        sys->OnRender(*this);
}

void World::Clear() {
    m_systems.clear();
    m_registeredComponents.clear();
}

} // namespace BADGE2D
