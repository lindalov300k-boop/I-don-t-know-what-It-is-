#pragma once
// ==============================================================================
// World.h — ECS World: unified facade for Entity/Component/System management
// The main interface game code uses.
// ==============================================================================

#include "../entity/Entity.h"
#include "../component/ComponentManager.h"
#include "../component/Components.h"
#include "../../engine/Logging/Logger.h"
#include <functional>
#include <string>

namespace BADGE2D {

// ==============================================================================
// ISystem — Base class for ECS systems
// ==============================================================================
class ISystem {
public:
    virtual ~ISystem() = default;
    virtual void OnUpdate     (World& world, double dt) {}
    virtual void OnFixedUpdate(World& world, double dt) {}
    virtual void OnRender     (World& world)            {}
    virtual const char* GetName() const = 0;

    ComponentMask  requiredMask;   // Set this in derived constructor
};

// ==============================================================================
// World — The ECS universe. One World per Scene.
// ==============================================================================
class World {
public:
    World();
    ~World();

    // ================================================================
    // Entity management
    // ================================================================
    Entity  CreateEntity (const std::string& name = "");
    void    DestroyEntity(Entity entity);
    bool    IsAlive      (Entity entity) const;
    void    SetName      (Entity entity, const std::string& name);
    const std::string& GetName(Entity entity) const;

    // ================================================================
    // Component operations
    // ================================================================
    template<typename T>
    T* AddComponent(Entity entity, T component = T{}) {
        EnsureRegistered<T>();
        m_components.AddComponent<T>(entity, std::move(component));
        m_entities.SetComponentBit(entity, ComponentRegistry::GetTypeID<T>());
        return &m_components.GetComponent<T>(entity);
    }

    template<typename T>
    void RemoveComponent(Entity entity) {
        m_components.RemoveComponent<T>(entity);
        m_entities.ClearComponentBit(entity, ComponentRegistry::GetTypeID<T>());
    }

    template<typename T>
    T& GetComponent(Entity entity) {
        return m_components.GetComponent<T>(entity);
    }

    template<typename T>
    const T& GetComponent(Entity entity) const {
        return m_components.GetComponent<T>(entity);
    }

    template<typename T>
    bool HasComponent(Entity entity) const {
        return m_components.HasComponent<T>(entity);
    }

    template<typename T>
    T* TryGetComponent(Entity entity) {
        if (!HasComponent<T>(entity)) return nullptr;
        return &m_components.GetComponent<T>(entity);
    }

    // ================================================================
    // Query — iterate all entities matching a set of components
    // ================================================================
    template<typename... ComponentTypes>
    void Each(std::function<void(Entity, ComponentTypes&...)> fn) {
        // Build required mask
        ComponentMask required;
        (required.set(ComponentRegistry::GetTypeID<ComponentTypes>()), ...);

        // Iterate entities
        // (In a production engine, archetypes accelerate this iteration)
        for (EntityIndex i = 1; i < m_entities.GetCapacity(); ++i) {
            Entity e = MakeEntity(i, 0);
            // Re-validate with actual generation
            // Simplified: check alive + mask superset
            // Full impl would use archetype storage
            if (!m_entities.IsAlive(MakeEntity(i, 0))) {
                // Try to find alive version (generation stored in record)
                // For now skip — full archetype impl handles this cleanly
                continue;
            }
            ComponentMask mask = m_entities.GetMask(e);
            if ((mask & required) == required) {
                fn(e, m_components.GetComponent<ComponentTypes>(e)...);
            }
        }
    }

    // ================================================================
    // Systems
    // ================================================================
    template<typename T, typename... Args>
    T* AddSystem(Args&&... args) {
        auto sys = std::make_unique<T>(std::forward<Args>(args)...);
        T* raw = sys.get();
        m_systems.push_back(std::move(sys));
        LOG_INFOF("[World] System registered: %s", raw->GetName());
        return raw;
    }

    void UpdateSystems(double dt);
    void FixedUpdateSystems(double dt);
    void RenderSystems();

    // ================================================================
    // Utility
    // ================================================================
    size_t GetEntityCount() const { return m_entities.GetAliveCount(); }
    void   Clear();

private:
    template<typename T>
    void EnsureRegistered() {
        auto id = ComponentRegistry::GetTypeID<T>();
        if (m_registeredComponents.size() <= id || !m_registeredComponents[id]) {
            m_components.RegisterComponent<T>();
            if (m_registeredComponents.size() <= id)
                m_registeredComponents.resize(id + 1, false);
            m_registeredComponents[id] = true;
        }
    }

    EntityManager                       m_entities;
    ComponentManager                    m_components;
    std::vector<std::unique_ptr<ISystem>> m_systems;
    std::vector<bool>                   m_registeredComponents;
};

} // namespace BADGE2D
