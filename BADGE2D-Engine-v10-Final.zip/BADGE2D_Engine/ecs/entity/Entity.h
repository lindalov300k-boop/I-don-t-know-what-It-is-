#pragma once
// ==============================================================================
// Entity.h — Entity ID management and EntityManager
// ==============================================================================

#include <cstdint>
#include <string>
#include <vector>
#include <queue>
#include <array>
#include <bitset>
#include <cassert>
#include <limits>

namespace BADGE2D {

// ==============================================================================
// Entity ID — 32 bits: upper 12 = generation, lower 20 = index
// ==============================================================================
using Entity     = uint32_t;
using EntityIndex = uint32_t;
using EntityGen   = uint16_t;

// Alias used throughout Phase 6-10 code
using EntityID = Entity;

constexpr Entity     NULL_ENTITY     = 0;
constexpr EntityID   INVALID_ENTITY  = 0;   // Same value as NULL_ENTITY
constexpr EntityIndex MAX_ENTITIES   = (1 << 20) - 1;  // ~1 million
constexpr uint32_t   MAX_COMPONENTS  = 64;

using ComponentMask = std::bitset<MAX_COMPONENTS>;

// ==============================================================================
// Entity packing helpers
// ==============================================================================
inline Entity MakeEntity(EntityIndex index, EntityGen gen) {
    return (static_cast<uint32_t>(gen) << 20) | (index & 0xFFFFF);
}
inline EntityIndex GetEntityIndex(Entity e) {
    return e & 0xFFFFF;
}
inline EntityGen GetEntityGen(Entity e) {
    return static_cast<EntityGen>(e >> 20);
}

// ==============================================================================
// EntityRecord — stores mask and optional name
// ==============================================================================
struct EntityRecord {
    ComponentMask mask;
    EntityGen     generation = 0;
    bool          alive      = false;
    std::string   name;
};

// ==============================================================================
// EntityManager — Allocates/destroys entities, tracks component masks
// ==============================================================================
class EntityManager {
public:
    EntityManager();

    // Create / destroy
    Entity       Create(const std::string& name = "");
    void         Destroy(Entity entity);
    bool         IsAlive(Entity entity) const;

    // Name
    void               SetName(Entity entity, const std::string& name);
    const std::string& GetName(Entity entity) const;

    // Component mask management
    void             SetComponentBit  (Entity entity, uint32_t componentId);
    void             ClearComponentBit(Entity entity, uint32_t componentId);
    bool             HasComponentBit  (Entity entity, uint32_t componentId) const;
    ComponentMask    GetMask          (Entity entity) const;

    size_t GetAliveCount()    const { return m_aliveCount; }
    size_t GetCapacity()      const { return m_records.size(); }

private:
    EntityRecord&       GetRecord(Entity entity);
    const EntityRecord& GetRecord(Entity entity) const;

    std::vector<EntityRecord>  m_records;
    std::queue<EntityIndex>    m_freeList;
    size_t                     m_aliveCount = 0;
};

} // namespace BADGE2D
