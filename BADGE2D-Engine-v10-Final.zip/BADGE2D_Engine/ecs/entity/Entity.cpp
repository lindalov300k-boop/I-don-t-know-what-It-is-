// ==============================================================================
// Entity.cpp — EntityManager implementation
// ==============================================================================

#include "Entity.h"
#include "../../engine/Logging/Logger.h"
#include <stdexcept>

namespace BADGE2D {

static const std::string UNNAMED = "<unnamed>";

EntityManager::EntityManager() {
    // Reserve slot 0 as NULL
    m_records.push_back({});   // index 0 = null entity
}

Entity EntityManager::Create(const std::string& name) {
    EntityIndex index;

    if (!m_freeList.empty()) {
        index = m_freeList.front();
        m_freeList.pop();
    } else {
        index = static_cast<EntityIndex>(m_records.size());
        if (index >= MAX_ENTITIES) {
            LOG_ERRORF("[EntityManager] Entity limit reached (%u)", MAX_ENTITIES);
            return NULL_ENTITY;
        }
        m_records.push_back({});
    }

    EntityRecord& rec = m_records[index];
    rec.mask  = {};
    rec.alive = true;
    rec.name  = name;
    // generation was already incremented on destroy (or starts at 0)

    ++m_aliveCount;

    Entity entity = MakeEntity(index, rec.generation);
    LOG_TRACEF("[EntityManager] Created entity %u (gen %u) '%s'",
               index, rec.generation, name.c_str());
    return entity;
}

void EntityManager::Destroy(Entity entity) {
    if (entity == NULL_ENTITY) return;
    EntityIndex index = GetEntityIndex(entity);

    if (!IsAlive(entity)) {
        LOG_WARNF("[EntityManager] Attempt to destroy dead entity %u", index);
        return;
    }

    EntityRecord& rec = m_records[index];
    rec.mask  = {};
    rec.alive = false;
    rec.name  = "";
    ++rec.generation;  // Invalidate old handles

    m_freeList.push(index);
    --m_aliveCount;
}

bool EntityManager::IsAlive(Entity entity) const {
    if (entity == NULL_ENTITY) return false;
    EntityIndex index = GetEntityIndex(entity);
    EntityGen   gen   = GetEntityGen(entity);

    if (index >= m_records.size()) return false;
    const EntityRecord& rec = m_records[index];
    return rec.alive && rec.generation == gen;
}

EntityRecord& EntityManager::GetRecord(Entity entity) {
    assert(IsAlive(entity) && "Accessing dead entity");
    return m_records[GetEntityIndex(entity)];
}

const EntityRecord& EntityManager::GetRecord(Entity entity) const {
    assert(IsAlive(entity) && "Accessing dead entity");
    return m_records[GetEntityIndex(entity)];
}

void EntityManager::SetName(Entity entity, const std::string& name) {
    GetRecord(entity).name = name;
}

const std::string& EntityManager::GetName(Entity entity) const {
    if (!IsAlive(entity)) return UNNAMED;
    return m_records[GetEntityIndex(entity)].name;
}

void EntityManager::SetComponentBit(Entity entity, uint32_t componentId) {
    assert(componentId < MAX_COMPONENTS);
    GetRecord(entity).mask.set(componentId);
}

void EntityManager::ClearComponentBit(Entity entity, uint32_t componentId) {
    assert(componentId < MAX_COMPONENTS);
    GetRecord(entity).mask.reset(componentId);
}

bool EntityManager::HasComponentBit(Entity entity, uint32_t componentId) const {
    if (!IsAlive(entity)) return false;
    assert(componentId < MAX_COMPONENTS);
    return m_records[GetEntityIndex(entity)].mask.test(componentId);
}

ComponentMask EntityManager::GetMask(Entity entity) const {
    if (!IsAlive(entity)) return {};
    return m_records[GetEntityIndex(entity)].mask;
}

} // namespace BADGE2D
