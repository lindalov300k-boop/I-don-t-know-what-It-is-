#pragma once
// ==============================================================================
// EditorCommand.h — Undo/redo command pattern for editor operations
// ==============================================================================

#include "../../ecs/system/World.h"
#include "../../ecs/component/Components.h"
#include "../../utilities/Math/Vector2.h"
#include "../../scene/manager/Scene.h"
#include <string>
#include <memory>
#include <functional>

namespace BADGE2D {

// ==============================================================================
// EditorCommand — Base class
// ==============================================================================
class EditorCommand {
public:
    virtual ~EditorCommand() = default;
    virtual void Execute() = 0;
    virtual void Undo()    = 0;
    virtual const std::string& GetLabel() const { return m_label; }
protected:
    std::string m_label = "Command";
};

// ==============================================================================
// CreateEntityCommand
// ==============================================================================
class CreateEntityCommand : public EditorCommand {
public:
    CreateEntityCommand(World* world, std::string name)
        : m_world(world), m_name(std::move(name)) { m_label = "Create Entity"; }

    void Execute() override {
        m_entity = m_world->CreateEntity();
        NameComponent nc; nc.name = m_name;
        m_world->AddComponent(m_entity, nc);
        TransformComponent tc; m_world->AddComponent(m_entity, tc);
    }
    void Undo() override { m_world->DestroyEntity(m_entity); }

    EntityID GetEntity() const { return m_entity; }

private:
    World*    m_world;
    std::string m_name;
    EntityID  m_entity = INVALID_ENTITY;
};

// ==============================================================================
// DeleteEntityCommand
// ==============================================================================
class DeleteEntityCommand : public EditorCommand {
public:
    DeleteEntityCommand(World* world, EntityID entity)
        : m_world(world), m_entity(entity) { m_label = "Delete Entity"; }

    void Execute() override {
        // Snapshot transform before deletion
        if (auto* tc = m_world->TryGetComponent<TransformComponent>(m_entity))
            m_savedTransform = *tc;
        if (auto* nc = m_world->TryGetComponent<NameComponent>(m_entity))
            m_savedName = nc->name;
        m_world->DestroyEntity(m_entity);
    }

    void Undo() override {
        m_entity = m_world->CreateEntity();
        NameComponent nc; nc.name = m_savedName;
        m_world->AddComponent(m_entity, nc);
        m_world->AddComponent(m_entity, m_savedTransform);
    }

private:
    World*             m_world;
    EntityID           m_entity;
    TransformComponent m_savedTransform;
    std::string        m_savedName;
};

// ==============================================================================
// MoveEntityCommand
// ==============================================================================
class MoveEntityCommand : public EditorCommand {
public:
    MoveEntityCommand(World* world, EntityID entity, Vector2 newPos)
        : m_world(world), m_entity(entity), m_newPos(newPos) {
        m_label = "Move Entity";
        if (auto* tc = world->TryGetComponent<TransformComponent>(entity))
            m_oldPos = tc->position;
    }

    void Execute() override {
        if (auto* tc = m_world->TryGetComponent<TransformComponent>(m_entity))
            tc->position = m_newPos;
    }
    void Undo() override {
        if (auto* tc = m_world->TryGetComponent<TransformComponent>(m_entity))
            tc->position = m_oldPos;
    }

private:
    World*    m_world;
    EntityID  m_entity;
    Vector2   m_oldPos, m_newPos;
};

// ==============================================================================
// ScaleEntityCommand
// ==============================================================================
class ScaleEntityCommand : public EditorCommand {
public:
    ScaleEntityCommand(World* world, EntityID entity, Vector2 newScale)
        : m_world(world), m_entity(entity), m_newScale(newScale) {
        m_label = "Scale Entity";
        if (auto* tc = world->TryGetComponent<TransformComponent>(entity))
            m_oldScale = tc->scale;
    }
    void Execute() override {
        if (auto* tc = m_world->TryGetComponent<TransformComponent>(m_entity))
            tc->scale = m_newScale;
    }
    void Undo() override {
        if (auto* tc = m_world->TryGetComponent<TransformComponent>(m_entity))
            tc->scale = m_oldScale;
    }
private:
    World*    m_world;
    EntityID  m_entity;
    Vector2   m_oldScale, m_newScale;
};

// ==============================================================================
// RotateEntityCommand
// ==============================================================================
class RotateEntityCommand : public EditorCommand {
public:
    RotateEntityCommand(World* world, EntityID entity, float newRot)
        : m_world(world), m_entity(entity), m_newRot(newRot) {
        m_label = "Rotate Entity";
        if (auto* tc = world->TryGetComponent<TransformComponent>(entity))
            m_oldRot = tc->rotation;
    }
    void Execute() override {
        if (auto* tc = m_world->TryGetComponent<TransformComponent>(m_entity))
            tc->rotation = m_newRot;
    }
    void Undo() override {
        if (auto* tc = m_world->TryGetComponent<TransformComponent>(m_entity))
            tc->rotation = m_oldRot;
    }
private:
    World*    m_world;
    EntityID  m_entity;
    float     m_oldRot = 0, m_newRot = 0;
};

// ==============================================================================
// LambdaCommand — Generic command from lambdas (great for one-offs)
// ==============================================================================
class LambdaCommand : public EditorCommand {
public:
    LambdaCommand(std::string label,
                  std::function<void()> exec,
                  std::function<void()> undo)
        : m_exec(std::move(exec)), m_undoFn(std::move(undo)) {
        m_label = std::move(label);
    }
    void Execute() override { if (m_exec)   m_exec();   }
    void Undo()    override { if (m_undoFn) m_undoFn(); }
private:
    std::function<void()> m_exec, m_undoFn;
};

} // namespace BADGE2D
