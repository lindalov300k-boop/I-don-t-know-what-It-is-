#include "../../utilities/Math/MathUtils.h"
// ==============================================================================
// TransformGizmo.cpp
// ==============================================================================

#include "../gizmos/TransformGizmo.h"
#include <cmath>
#include <algorithm>

namespace BADGE2D {

Vector2 TransformGizmo::GetPos() const {
    if (!m_scene || m_target == INVALID_ENTITY) return {};
    auto* tc = m_scene->GetWorld().TryGetComponent<TransformComponent>(m_target);
    return tc ? tc->position : Vector2{};
}
Vector2 TransformGizmo::GetScale() const {
    if (!m_scene || m_target == INVALID_ENTITY) return {1,1};
    auto* tc = m_scene->GetWorld().TryGetComponent<TransformComponent>(m_target);
    return tc ? tc->scale : Vector2{1,1};
}
float TransformGizmo::GetRot() const {
    if (!m_scene || m_target == INVALID_ENTITY) return 0;
    auto* tc = m_scene->GetWorld().TryGetComponent<TransformComponent>(m_target);
    return tc ? tc->rotation : 0.0f;
}
void TransformGizmo::SetPos  (const Vector2& p) {
    if (!m_scene || m_target == INVALID_ENTITY) return;
    if (auto* tc = m_scene->GetWorld().TryGetComponent<TransformComponent>(m_target)) tc->position = p;
}
void TransformGizmo::SetScale(const Vector2& s) {
    if (!m_scene || m_target == INVALID_ENTITY) return;
    if (auto* tc = m_scene->GetWorld().TryGetComponent<TransformComponent>(m_target)) tc->scale = s;
}
void TransformGizmo::SetRot  (float r) {
    if (!m_scene || m_target == INVALID_ENTITY) return;
    if (auto* tc = m_scene->GetWorld().TryGetComponent<TransformComponent>(m_target)) tc->rotation = r;
}

TransformGizmo::Handle TransformGizmo::HitTest(float mx, float my, float hs) {
    Vector2 pos = GetPos();
    // XY origin box
    if (std::abs(mx-pos.x)<hs && std::abs(my-pos.y)<hs) return Handle::XY;
    // X axis handle
    if (std::abs(mx-(pos.x+AXIS_LENGTH))<hs && std::abs(my-pos.y)<hs*2) return Handle::X;
    // Y axis handle
    if (std::abs(mx-pos.x)<hs*2 && std::abs(my-(pos.y+AXIS_LENGTH))<hs) return Handle::Y;
    return Handle::None;
}

bool TransformGizmo::Update(float mx, float my, bool mouseDown,
                               bool snapEnabled, float snapGrid) {
    if (m_target == INVALID_ENTITY || !m_scene) return false;

    auto Snap = [&](float v) {
        return snapEnabled ? std::round(v / snapGrid) * snapGrid : v;
    };

    if (!m_dragging && mouseDown) {
        m_activeHandle = HitTest(mx, my, HANDLE_SIZE);
        if (m_activeHandle != Handle::None) {
            m_dragging  = true;
            m_dragStart = {mx, my};
            m_origPos   = GetPos();
            m_origScale = GetScale();
            m_origRot   = GetRot();
        }
    }

    if (m_dragging && mouseDown) {
        float dx = mx - m_dragStart.x;
        float dy = my - m_dragStart.y;

        if (m_mode == GizmoMode::Translate) {
            Vector2 newPos = m_origPos;
            if (m_activeHandle == Handle::X || m_activeHandle == Handle::XY) newPos.x = Snap(m_origPos.x + dx);
            if (m_activeHandle == Handle::Y || m_activeHandle == Handle::XY) newPos.y = Snap(m_origPos.y + dy);
            SetPos(newPos);
        } else if (m_mode == GizmoMode::Scale) {
            Vector2 newScale = {
                std::max(0.01f, m_origScale.x + dx * 0.01f),
                std::max(0.01f, m_origScale.y - dy * 0.01f)
            };
            SetScale(newScale);
        } else if (m_mode == GizmoMode::Rotate) {
            Vector2 pos = GetPos();
            float angle = std::atan2(my - pos.y, mx - pos.x) * (180.0f / 3.14159265f);
            SetRot(Snap(angle));
        }
        return true;
    }

    if (!mouseDown) m_dragging = false;
    return m_dragging;
}

void TransformGizmo::Render(SpriteBatch& batch, float /*camX*/, float /*camY*/, float /*zoom*/) {
    if (m_target == INVALID_ENTITY) return;
    Vector2 pos = GetPos();

    Color red   = {1,0.2f,0.2f,1};
    Color green = {0.2f,1,0.2f,1};
    Color yellow= {1,1,0.2f,1};

    // X axis arrow
    batch.DrawLine({pos.x, pos.y}, {pos.x+AXIS_LENGTH, pos.y}, red, 2.0f);
    batch.DrawRectFill(Rect2D{pos.x+AXIS_LENGTH-6, pos.y-4, 8, 8}, red);
    // Y axis arrow
    batch.DrawLine({pos.x, pos.y}, {pos.x, pos.y+AXIS_LENGTH}, green, 2.0f);
    batch.DrawRectFill(Rect2D{pos.x-4, pos.y+AXIS_LENGTH-6, 8, 8}, green);
    // XY center box
    batch.DrawRectFill(Rect2D{pos.x-HANDLE_SIZE*0.5f, pos.y-HANDLE_SIZE*0.5f, HANDLE_SIZE, HANDLE_SIZE}, yellow);
}

} // namespace BADGE2D
