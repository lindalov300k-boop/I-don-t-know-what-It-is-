#pragma once
// ==============================================================================
// TransformGizmo.h — 2D transform gizmo (move/scale/rotate handles)
// Rendered over the viewport using SpriteBatch debug lines.
// ==============================================================================

#include "../../utilities/Math/Vector2.h"
#include "../../ecs/component/Components.h"
#include "../../scene/manager/Scene.h"
#include "../../renderer/sprites/SpriteBatch.h"

namespace BADGE2D {

// ==============================================================================
// GizmoMode
// ==============================================================================
enum class GizmoMode { Translate, Rotate, Scale };

// ==============================================================================
// TransformGizmo
// ==============================================================================
class TransformGizmo {
public:
    void SetMode   (GizmoMode m) { m_mode = m; }
    GizmoMode GetMode() const    { return m_mode; }

    void SetTargetEntity(EntityID e, Scene* scene) {
        m_target = e; m_scene = scene;
    }
    void ClearTarget() { m_target = INVALID_ENTITY; m_scene = nullptr; }

    // ---- Update (call with mouse position in world space) ----
    // Returns true if gizmo consumed the event (dragging a handle)
    bool Update(float worldMouseX, float worldMouseY, bool mouseDown,
                bool snapEnabled = false, float snapGrid = 1.0f);

    // ---- Render (call after scene render) ----
    void Render(SpriteBatch& batch, float camX, float camY, float zoom);

    bool IsDragging() const { return m_dragging; }

private:
    // Axis handle hit test
    enum class Handle { None, X, Y, XY, Rotate };
    Handle HitTest(float worldMouseX, float worldMouseY, float handleSize);

    // Current transform
    Vector2  GetPos()  const;
    Vector2  GetScale()const;
    float    GetRot()  const;
    void     SetPos   (const Vector2& p);
    void     SetScale (const Vector2& s);
    void     SetRot   (float r);

    GizmoMode  m_mode   = GizmoMode::Translate;
    EntityID   m_target = INVALID_ENTITY;
    Scene*     m_scene  = nullptr;

    Handle   m_activeHandle  = Handle::None;
    bool     m_dragging      = false;
    Vector2  m_dragStart;
    Vector2  m_origPos;
    Vector2  m_origScale;
    float    m_origRot       = 0;

    static constexpr float HANDLE_SIZE  = 12.0f;
    static constexpr float AXIS_LENGTH  = 80.0f;
};

} // namespace BADGE2D
