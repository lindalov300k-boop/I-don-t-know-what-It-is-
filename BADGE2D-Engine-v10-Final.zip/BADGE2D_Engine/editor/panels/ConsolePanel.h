#pragma once
// ConsolePanel.h — forward include
#include "EditorPanels.h"
