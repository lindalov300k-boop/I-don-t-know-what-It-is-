// ==============================================================================
// EditorPanels.cpp — ImGui panel implementations
// ==============================================================================

#include "EditorPanels.h"
#include "../core/EditorCore.h"
#include "../../engine/Logging/Logger.h"
#include "../../assets/manifest/AssetManifest.h"
#include "../../animation/Animator.h"

#ifdef BADGE2D_EDITOR_IMGUI
  #include <imgui.h>
#endif

namespace BADGE2D {

// ==============================================================================
// SceneHierarchyPanel
// ==============================================================================
void SceneHierarchyPanel::OnRender(EditorCore& editor) {
#ifdef BADGE2D_EDITOR_IMGUI
    if (!m_open) return;
    ImGui::Begin(GetTitle(), &m_open);

    Scene* scene = editor.GetEditScene();
    if (!scene) { ImGui::TextDisabled("No scene loaded."); ImGui::End(); return; }

    // Search bar
    static char searchBuf[128] = {};
    ImGui::SetNextItemWidth(-1);
    ImGui::InputText("##search", searchBuf, sizeof(searchBuf));
    m_searchFilter = searchBuf;

    ImGui::Separator();

    // Context menu — right-click empty space
    if (ImGui::BeginPopupContextWindow("##HierCtx", ImGuiPopupFlags_MouseButtonRight)) {
        if (ImGui::MenuItem("Create Empty Entity")) {
            editor.CreateEntity("Entity");
        }
        if (ImGui::BeginMenu("Create 2D Object")) {
            if (ImGui::MenuItem("Sprite")) {
                EntityID e = editor.CreateEntity("Sprite");
                SpriteComponent sc; scene->AddComponent(e, sc);
            }
            if (ImGui::MenuItem("Camera")) { editor.CreateEntity("Camera"); }
            ImGui::EndMenu();
        }
        ImGui::EndPopup();
    }

    // Entity list
    scene->GetWorld().Each<NameComponent>([&](EntityID id, NameComponent& nc) {
        if (!m_searchFilter.empty() &&
            nc.name.find(m_searchFilter) == std::string::npos) return;
        DrawEntityNode(editor, id, *scene);
    });

    ImGui::End();
#else
    (void)editor;
#endif
}

void SceneHierarchyPanel::DrawEntityNode(EditorCore& editor, EntityID id, Scene& scene) {
#ifdef BADGE2D_EDITOR_IMGUI
    auto* nc = scene.GetWorld().TryGetComponent<NameComponent>(id);
    std::string label = nc ? nc->name : "Entity_" + std::to_string(id);
    label += "##" + std::to_string(id);

    bool selected = editor.GetSelection().entity == id;
    ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_Leaf |
                                ImGuiTreeNodeFlags_SpanAvailWidth |
                                (selected ? ImGuiTreeNodeFlags_Selected : 0);

    bool open = ImGui::TreeNodeEx(label.c_str(), flags);

    if (ImGui::IsItemClicked()) editor.Select(id, &scene);

    if (ImGui::BeginPopupContextItem()) {
        if (ImGui::MenuItem("Delete"))    { editor.Execute(std::make_unique<DeleteEntityCommand>(&scene.GetWorld(), id)); }
        if (ImGui::MenuItem("Duplicate")) { editor.DuplicateSelected(); }
        ImGui::EndPopup();
    }
    if (open) ImGui::TreePop();
#else
    (void)editor; (void)id; (void)scene;
#endif
}

// ==============================================================================
// InspectorPanel
// ==============================================================================
void InspectorPanel::DrawComponentHeader(const char* name, bool& open) {
#ifdef BADGE2D_EDITOR_IMGUI
    ImGui::PushStyleColor(ImGuiCol_Header, {0.18f,0.18f,0.22f,1.0f});
    open = ImGui::CollapsingHeader(name, ImGuiTreeNodeFlags_DefaultOpen);
    ImGui::PopStyleColor();
#else
    (void)name; open = true;
#endif
}

void InspectorPanel::OnRender(EditorCore& editor) {
#ifdef BADGE2D_EDITOR_IMGUI
    if (!m_open) return;
    ImGui::Begin(GetTitle(), &m_open);

    const auto& sel = editor.GetSelection();
    if (!sel.IsEntity() || !sel.scene) {
        ImGui::TextDisabled("Nothing selected.");
        ImGui::End(); return;
    }

    EntityID e = sel.entity;
    Scene&   scene = *sel.scene;

    // Entity name header
    if (auto* nc = scene.GetWorld().TryGetComponent<NameComponent>(e)) {
        static char nameBuf[128];
        snprintf(nameBuf, sizeof(nameBuf), "%s", nc->name.c_str());
        if (ImGui::InputText("##name", nameBuf, sizeof(nameBuf))) nc->name = nameBuf;
    }
    ImGui::Separator();

    DrawTransform  (editor, e, scene);
    DrawSprite     (editor, e, scene);
    DrawPhysicsBody(editor, e, scene);
    DrawAnimator   (editor, e, scene);
    DrawAddComponent(editor, e, scene);

    ImGui::End();
#else
    (void)editor;
#endif
}

void InspectorPanel::DrawTransform(EditorCore& editor, EntityID e, Scene& scene) {
#ifdef BADGE2D_EDITOR_IMGUI
    auto* tc = scene.GetWorld().TryGetComponent<TransformComponent>(e);
    if (!tc) return;
    bool open = true;
    DrawComponentHeader("Transform", open);
    if (!open) return;

    float pos[2] = { tc->position.x, tc->position.y };
    if (ImGui::DragFloat2("Position", pos, 0.5f)) {
        editor.Execute(std::make_unique<MoveEntityCommand>(
            &scene.GetWorld(), e, Vector2{pos[0], pos[1]}));
    }
    float scl[2] = { tc->scale.x, tc->scale.y };
    if (ImGui::DragFloat2("Scale", scl, 0.01f, 0.01f, 100.0f)) {
        editor.Execute(std::make_unique<ScaleEntityCommand>(
            &scene.GetWorld(), e, Vector2{scl[0], scl[1]}));
    }
    float rot = tc->rotation;
    if (ImGui::DragFloat("Rotation", &rot, 0.5f, -360.0f, 360.0f, "%.1f°")) {
        editor.Execute(std::make_unique<RotateEntityCommand>(&scene.GetWorld(), e, rot));
    }
#else
    (void)editor; (void)e; (void)scene;
#endif
}

void InspectorPanel::DrawSprite(EditorCore& editor, EntityID e, Scene& scene) {
#ifdef BADGE2D_EDITOR_IMGUI
    auto* sc = scene.GetWorld().TryGetComponent<SpriteComponent>(e);
    if (!sc) return;
    bool open = true;
    DrawComponentHeader("Sprite", open);
    if (!open) return;

    float col[4] = { sc->tint.r, sc->tint.g, sc->tint.b, sc->tint.a };
    if (ImGui::ColorEdit4("Tint", col))
        sc->tint = { col[0], col[1], col[2], col[3] };

    float sz[2] = { sc->size.x, sc->size.y };
    if (ImGui::DragFloat2("Size", sz, 1.0f, 1, 4096)) sc->size = { sz[0], sz[1] };

    ImGui::Checkbox("Flip X", &sc->flipX); ImGui::SameLine();
    ImGui::Checkbox("Flip Y", &sc->flipY);
    // Texture slot — drag drop from asset browser
    ImGui::Button(sc->texture ? "Texture: <set>" : "Texture: (none)", {-1,0});
    if (ImGui::BeginDragDropTarget()) {
        // Accept texture drag
        ImGui::EndDragDropTarget();
    }
#else
    (void)editor; (void)e; (void)scene;
#endif
}

void InspectorPanel::DrawPhysicsBody(EditorCore& /*editor*/, EntityID e, Scene& scene) {
#ifdef BADGE2D_EDITOR_IMGUI
    auto* pb = scene.GetWorld().TryGetComponent<PhysicsBodyComponent>(e);
    if (!pb || !pb->body) return;
    bool open = true;
    DrawComponentHeader("Physics Body", open);
    if (!open) return;

    auto* body = pb->body;
    float mass = body->GetMass();
    ImGui::DragFloat("Mass",    &mass, 0.1f, 0.0f, 1000.0f);
    float friction = body->GetMaterial().friction;
    if (ImGui::DragFloat("Friction",    &friction,    0.01f, 0, 1)) {}
    float restitution = body->GetMaterial().restitution;
    if (ImGui::DragFloat("Restitution", &restitution, 0.01f, 0, 1)) {}
    bool isSensor = body->IsSensor();
    if (ImGui::Checkbox("Is Sensor", &isSensor)) {}
    bool isAwake = !body->IsSleeping();
    ImGui::Checkbox("Awake", &isAwake);
#else
    (void)e; (void)scene;
#endif
}

void InspectorPanel::DrawAnimator(EditorCore& /*editor*/, EntityID e, Scene& scene) {
#ifdef BADGE2D_EDITOR_IMGUI
    auto* ac = scene.GetWorld().TryGetComponent<AnimatorComponent>(e);
    if (!ac || !ac->stateMachine) return;
    bool open = true;
    DrawComponentHeader("Animator", open);
    if (!open) return;

    ImGui::Text("State: %s", ac->GetStateName().c_str());
    ImGui::Text("Transitioning: %s", ac->stateMachine->IsTransitioning() ? "yes" : "no");
    if (ac->stateMachine->IsTransitioning())
        ImGui::ProgressBar(ac->stateMachine->GetTransitionProgress(), {-1.0f, 0.0f});
#else
    (void)e; (void)scene;
#endif
}

void InspectorPanel::DrawAddComponent(EditorCore& /*editor*/, EntityID e, Scene& scene) {
#ifdef BADGE2D_EDITOR_IMGUI
    ImGui::Spacing();
    float w = ImGui::GetContentRegionAvail().x;
    ImGui::SetCursorPosX((w - 160) * 0.5f);
    if (ImGui::Button("+ Add Component", {160, 0})) ImGui::OpenPopup("AddComponentPopup");

    if (ImGui::BeginPopup("AddComponentPopup")) {
        if (ImGui::MenuItem("Sprite Component")) {
            SpriteComponent sc; scene.AddComponent(e, sc);
        }
        if (ImGui::MenuItem("Physics Body")) {
            // AttachBoxBody helper
        }
        if (ImGui::MenuItem("Animator")) {
            AnimatorComponent ac;
            ac.stateMachine = std::make_unique<AnimStateMachine>();
            scene.GetWorld().AddComponent(e, std::move(ac));
        }
        ImGui::EndPopup();
    }
#else
    (void)e; (void)scene;
#endif
}

// ==============================================================================
// AssetBrowserPanel
// ==============================================================================
void AssetBrowserPanel::OnRender(EditorCore& editor) {
#ifdef BADGE2D_EDITOR_IMGUI
    if (!m_open) return;
    ImGui::Begin(GetTitle(), &m_open);

    static char searchBuf[128] = {};
    ImGui::SetNextItemWidth(180);
    ImGui::InputText("##search", searchBuf, sizeof(searchBuf));
    m_searchFilter = searchBuf;
    ImGui::SameLine();

    const char* typeNames[] = { "All","Texture","Sound","Music","Font","AnimClip","Scene","Prefab","Shader" };
    static int filterIdx = 0;
    ImGui::SetNextItemWidth(100);
    if (ImGui::Combo("##type", &filterIdx, typeNames, 9))
        m_filterType = (AssetType)filterIdx;

    ImGui::Separator();

    auto assets = AssetManifest::Get().GetAll();
    for (auto* meta : assets) {
        if (m_filterType != AssetType::Unknown && meta->type != m_filterType) continue;
        if (!m_searchFilter.empty() && meta->name.find(m_searchFilter) == std::string::npos) continue;

        bool selected = (m_selectedAsset == meta->id);
        std::string label = GetAssetTypeName(meta->type) + std::string(" ") + meta->name;
        if (ImGui::Selectable(label.c_str(), selected)) {
            m_selectedAsset = meta->id;
            editor.Select(meta->id);
        }

        // Drag source for drag-drop into Inspector
        if (ImGui::BeginDragDropSource()) {
            ImGui::SetDragDropPayload("ASSET_ID", &meta->id, sizeof(AssetID));
            ImGui::Text("%s", meta->name.c_str());
            m_draggedAsset = meta->id;
            ImGui::EndDragDropSource();
        }

        ImGui::SameLine(ImGui::GetContentRegionAvail().x - 60);
        ImGui::TextDisabled("%.1f KB", meta->sizeBytes / 1024.0f);
    }

    if (ImGui::Button("Scan Assets")) {
        int n = AssetManifest::Get().Scan();
        LOG_INFOF("[AssetBrowser] Scanned: %d assets", n);
    }
    ImGui::End();
#else
    (void)editor;
#endif
}

// ==============================================================================
// ViewportPanel
// ==============================================================================
void ViewportPanel::OnRender(EditorCore& editor) {
#ifdef BADGE2D_EDITOR_IMGUI
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, {0, 0});
    ImGui::Begin(GetTitle(), &m_open, ImGuiWindowFlags_NoScrollbar);

    auto pos  = ImGui::GetCursorScreenPos();
    auto size = ImGui::GetContentRegionAvail();
    m_viewX = pos.x; m_viewY = pos.y;
    m_viewW = size.x; m_viewH = size.y;
    m_hovered = ImGui::IsWindowHovered();

    // Show scene framebuffer texture here
    // ImGui::Image((ImTextureID)(intptr_t)fbTexID, size);

    // Grid overlay
    if (editor.IsEditing() && editor.IsGridVisible()) {
        if (editor.GetEditScene()) DrawGrid(*editor.GetEditScene());
    }

    DrawStats();
    ImGui::End();
    ImGui::PopStyleVar();
#else
    (void)editor;
#endif
}

void ViewportPanel::DrawGrid(const Scene& /*scene*/) {
#ifdef BADGE2D_EDITOR_IMGUI
    auto* dl = ImGui::GetWindowDrawList();
    float gridSize = 32.0f;
    ImU32 gridColor = IM_COL32(80, 80, 80, 40);
    for (float x = m_viewX; x < m_viewX+m_viewW; x += gridSize)
        dl->AddLine({x, m_viewY}, {x, m_viewY+m_viewH}, gridColor);
    for (float y = m_viewY; y < m_viewY+m_viewH; y += gridSize)
        dl->AddLine({m_viewX, y}, {m_viewX+m_viewW, y}, gridColor);
    // Origin axes
    float cx = m_viewX + m_viewW*0.5f, cy = m_viewY + m_viewH*0.5f;
    dl->AddLine({cx, m_viewY}, {cx, m_viewY+m_viewH}, IM_COL32(80,80,200,80), 1.5f);
    dl->AddLine({m_viewX, cy}, {m_viewX+m_viewW, cy}, IM_COL32(200,80,80,80), 1.5f);
#endif
}

void ViewportPanel::DrawStats() {
#ifdef BADGE2D_EDITOR_IMGUI
    auto* dl = ImGui::GetWindowDrawList();
    char buf[128];
    snprintf(buf, sizeof(buf), "%.1f fps | %.2f ms", ImGui::GetIO().Framerate, 1000.0f/ImGui::GetIO().Framerate);
    dl->AddText({m_viewX+8, m_viewY+8}, IM_COL32(200,200,200,180), buf);
#endif
}

Vector2 ViewportPanel::ScreenToWorld(float sx, float sy, const Scene& scene) const {
    const auto& cam = const_cast<Scene&>(scene).GetCamera();
    float relX = sx - m_viewX - m_viewW * 0.5f;
    float relY = sy - m_viewY - m_viewH * 0.5f;
    float zoom = cam.GetZoom();
    return { cam.GetPosition().x + relX / zoom,
             cam.GetPosition().y + relY / zoom };
}

// ==============================================================================
// ConsolePanel
// ==============================================================================
void ConsolePanel::AddMessage(const std::string& msg, int level) {
    m_messages.push_back({ msg, level });
    if (m_messages.size() > 2000) m_messages.erase(m_messages.begin());
}

void ConsolePanel::OnRender(EditorCore& /*editor*/) {
#ifdef BADGE2D_EDITOR_IMGUI
    if (!m_open) return;
    ImGui::Begin(GetTitle(), &m_open);

    // Toolbar
    if (ImGui::Button("Clear")) m_messages.clear();
    ImGui::SameLine();
    ImGui::Checkbox("Info",  &m_filterInfo);  ImGui::SameLine();
    ImGui::Checkbox("Warn",  &m_filterWarn);  ImGui::SameLine();
    ImGui::Checkbox("Error", &m_filterError); ImGui::SameLine();

    static char searchBuf[128] = {};
    ImGui::SetNextItemWidth(-1);
    ImGui::InputText("##search", searchBuf, sizeof(searchBuf));
    m_searchFilter = searchBuf;

    ImGui::Separator();
    ImGui::BeginChild("##log");

    for (const auto& msg : m_messages) {
        if (msg.level == 0 && !m_filterInfo)  continue;
        if (msg.level == 1 && !m_filterWarn)  continue;
        if (msg.level == 2 && !m_filterError) continue;
        if (!m_searchFilter.empty() && msg.text.find(m_searchFilter)==std::string::npos) continue;

        ImVec4 col = (msg.level == 2) ? ImVec4(1.0f,0.4f,0.4f,1.0f) :
                     (msg.level == 1) ? ImVec4(1.0f,0.8f,0.2f,1.0f) :
                                        ImVec4(0.9f,0.9f,0.9f,1.0f);
        ImGui::TextColored(col, "%s", msg.text.c_str());
    }

    if (m_autoScroll && ImGui::GetScrollY() >= ImGui::GetScrollMaxY())
        ImGui::SetScrollHereY(1.0f);

    ImGui::EndChild();
    ImGui::End();
#endif
}

} // namespace BADGE2D
