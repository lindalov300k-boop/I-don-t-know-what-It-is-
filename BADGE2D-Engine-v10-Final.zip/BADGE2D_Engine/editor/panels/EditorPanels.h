#pragma once
// ==============================================================================
// EditorPanels.h — All editor panel definitions (ImGui-based)
// ==============================================================================

#include "../../scene/manager/Scene.h"
#include "../../ecs/component/Components.h"
#include "../../assets/AssetTypes.h"
#include "../../assets/manifest/AssetManifest.h"
#include <string>
#include <vector>
#include <functional>

namespace BADGE2D {

// Forward-declare EditorCore to avoid circular include
class EditorCore;

// ==============================================================================
// IEditorPanel — Base for all dockable panels
// ==============================================================================
class IEditorPanel {
public:
    virtual ~IEditorPanel() = default;
    virtual void OnRender (EditorCore& editor) = 0;
    virtual const char* GetTitle()       const = 0;
    bool  IsOpen()                       const { return m_open; }
    void  SetOpen(bool o)                      { m_open = o; }
public:
    bool m_open = true;  // direct access for ImGui checkbox
};

// ==============================================================================
// SceneHierarchyPanel — Entity tree
// ==============================================================================
class SceneHierarchyPanel : public IEditorPanel {
public:
    const char* GetTitle() const override { return "Hierarchy"; }
    void OnRender(EditorCore& editor) override;

private:
    void DrawEntityNode(EditorCore& editor, EntityID id, Scene& scene);
    std::string m_searchFilter;
    bool        m_contextMenu = false;
};

// ==============================================================================
// InspectorPanel — Component editor for selected entity
// ==============================================================================
class InspectorPanel : public IEditorPanel {
public:
    const char* GetTitle() const override { return "Inspector"; }
    void OnRender(EditorCore& editor) override;

private:
    void DrawTransform   (EditorCore& editor, EntityID e, Scene& scene);
    void DrawSprite      (EditorCore& editor, EntityID e, Scene& scene);
    void DrawPhysicsBody (EditorCore& editor, EntityID e, Scene& scene);
    void DrawAnimator    (EditorCore& editor, EntityID e, Scene& scene);
    void DrawAddComponent(EditorCore& editor, EntityID e, Scene& scene);
    void DrawComponentHeader(const char* name, bool& open);
};

// ==============================================================================
// AssetBrowserPanel — File system asset viewer
// ==============================================================================
class AssetBrowserPanel : public IEditorPanel {
public:
    const char* GetTitle() const override { return "Asset Browser"; }
    void OnRender(EditorCore& editor) override;

    // Drag-drop support
    AssetID GetDraggedAsset() const { return m_draggedAsset; }

private:
    std::string m_currentDir  = "assets/";
    std::string m_searchFilter;
    AssetType   m_filterType  = AssetType::Unknown;
    AssetID     m_draggedAsset = INVALID_ASSET;
    AssetID     m_selectedAsset = INVALID_ASSET;
};

// ==============================================================================
// ViewportPanel — Framebuffer preview + gizmo interaction
// ==============================================================================
class ViewportPanel : public IEditorPanel {
public:
    const char* GetTitle() const override { return "Viewport"; }
    void OnRender(EditorCore& editor) override;

    bool  IsHovered()   const { return m_hovered; }
    float GetViewX()    const { return m_viewX;   }
    float GetViewY()    const { return m_viewY;   }
    float GetViewW()    const { return m_viewW;   }
    float GetViewH()    const { return m_viewH;   }

    // Convert screen → world (via active scene camera)
    Vector2 ScreenToWorld(float sx, float sy, const Scene& scene) const;

private:
    void DrawGrid      (const Scene& scene);
    void DrawStats     ();
    void HandlePick    (EditorCore& editor, float mx, float my);

    float  m_viewX = 0, m_viewY = 0, m_viewW = 1280, m_viewH = 720;
    bool   m_hovered  = false;
    bool   m_panning  = false;
    float  m_panX = 0, m_panY = 0;
};

// ==============================================================================
// ConsolePanel — Log output viewer
// ==============================================================================
class ConsolePanel : public IEditorPanel {
public:
    const char* GetTitle() const override { return "Console"; }
    void OnRender(EditorCore& editor) override;

    void AddMessage(const std::string& msg, int level = 0); // 0=info 1=warn 2=error
    void Clear() { m_messages.clear(); }

private:
    struct LogMsg { std::string text; int level; };
    std::vector<LogMsg> m_messages;
    bool m_autoScroll  = true;
    bool m_filterInfo  = true;
    bool m_filterWarn  = true;
    bool m_filterError = true;
    std::string m_searchFilter;
};

} // namespace BADGE2D
