// ==============================================================================
// EditorCore.cpp
// ==============================================================================

#include "EditorCore.h"
#include "../../engine/Logging/Logger.h"
#include "../../scene/serialization/SceneSerializer.h"

// ImGui integration (optional — define BADGE2D_EDITOR_IMGUI to enable)
#ifdef BADGE2D_EDITOR_IMGUI
  #include <imgui.h>
  #include <imgui_impl_glfw.h>
  #include <imgui_impl_opengl3.h>
#endif

namespace BADGE2D {

EditorCore& EditorCore::Get() {
    static EditorCore instance;
    return instance;
}

bool EditorCore::Initialize() {
    if (m_initialized) return true;

    // Create panels
    m_hierarchy    = std::make_unique<SceneHierarchyPanel>();
    m_inspector    = std::make_unique<InspectorPanel>();
    m_assetBrowser = std::make_unique<AssetBrowserPanel>();
    m_viewport     = std::make_unique<ViewportPanel>();
    m_console      = std::make_unique<ConsolePanel>();
    m_gizmo        = std::make_unique<TransformGizmo>();

    InitImGui();
    NewScene("Untitled");

    m_initialized = true;
    LOG_INFO("[EditorCore] Initialized.");
    return true;
}

void EditorCore::Shutdown() {
    if (!m_initialized) return;
    ShutdownImGui();
    m_undoStack.clear();
    m_redoStack.clear();
    m_initialized = false;
    LOG_INFO("[EditorCore] Shutdown.");
}

void EditorCore::InitImGui() {
#ifdef BADGE2D_EDITOR_IMGUI
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
    io.ConfigFlags |= ImGuiConfigFlags_ViewportsEnable;
    ApplyEditorTheme();
    // ImGui_ImplGlfw_InitForOpenGL and ImGui_ImplOpenGL3_Init
    // called by RenderDevice after window creation
    m_imguiReady = true;
#endif
}

void EditorCore::ShutdownImGui() {
#ifdef BADGE2D_EDITOR_IMGUI
    if (!m_imguiReady) return;
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    m_imguiReady = false;
#endif
}

// ==============================================================================
// Update
// ==============================================================================
void EditorCore::Update(double dt) {
    if (!m_initialized) return;

    if (m_mode == EditorMode::Play && m_editScene) {
        m_editScene->OnUpdate(dt);
        m_editScene->OnFixedUpdate(dt * 60.0);  // 60Hz fixed step proxy
    }

    // Gizmo update
    if (m_selection.IsEntity() && m_viewport->IsHovered()) {
        // Mouse world position would come from InputManager + viewport transform
        // m_gizmo->Update(worldMX, worldMY, pressed, m_snapEnabled, m_snapGrid);
    }
}

// ==============================================================================
// Render
// ==============================================================================
void EditorCore::Render() {
    if (!m_initialized) return;
#ifdef BADGE2D_EDITOR_IMGUI
    if (!m_imguiReady) return;

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplGlfw_NewFrame();
    ImGui::NewFrame();

    RenderDockspace();
    RenderMenuBar();
    RenderToolbar();

    m_viewport->OnRender(*this);
    m_hierarchy->OnRender(*this);
    m_inspector->OnRender(*this);
    m_assetBrowser->OnRender(*this);
    m_console->OnRender(*this);

    if (OnRenderEditorUI) OnRenderEditorUI();

    RenderStatusBar();

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

    ImGuiIO& io = ImGui::GetIO();
    if (io.ConfigFlags & ImGuiConfigFlags_ViewportsEnable) {
        ImGui::UpdatePlatformWindows();
        ImGui::RenderPlatformWindowsDefault();
    }
#endif
}

// ==============================================================================
// Dockspace + MenuBar
// ==============================================================================
void EditorCore::RenderDockspace() {
#ifdef BADGE2D_EDITOR_IMGUI
    ImGuiWindowFlags flags =
        ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_NoTitleBar |
        ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBringToFrontOnFocus |
        ImGuiWindowFlags_NoNavFocus | ImGuiWindowFlags_MenuBar;

    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(vp->Pos);
    ImGui::SetNextWindowSize(vp->Size);
    ImGui::SetNextWindowViewport(vp->ID);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0);
    ImGui::Begin("DockSpace", nullptr, flags);
    ImGui::PopStyleVar(2);
    ImGui::DockSpace(ImGui::GetID("MainDockspace"), {0,0}, ImGuiDockNodeFlags_None);
    ImGui::End();
#endif
}

void EditorCore::RenderMenuBar() {
#ifdef BADGE2D_EDITOR_IMGUI
    if (ImGui::BeginMainMenuBar()) {
        if (ImGui::BeginMenu("File")) {
            if (ImGui::MenuItem("New Scene",  "Ctrl+N")) NewScene();
            if (ImGui::MenuItem("Open Scene", "Ctrl+O")) { /* file dialog */ }
            if (ImGui::MenuItem("Save Scene", "Ctrl+S")) SaveScene();
            ImGui::Separator();
            if (ImGui::MenuItem("Exit"))  { /* quit */ }
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Edit")) {
            if (ImGui::MenuItem("Undo", "Ctrl+Z", false, CanUndo())) Undo();
            if (ImGui::MenuItem("Redo", "Ctrl+Y", false, CanRedo())) Redo();
            ImGui::Separator();
            if (ImGui::MenuItem("Delete", "Del", false, m_selection.IsEntity())) DeleteSelected();
            if (ImGui::MenuItem("Duplicate","Ctrl+D",false,m_selection.IsEntity())) DuplicateSelected();
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("View")) {
            ImGui::MenuItem("Hierarchy",     "", &m_hierarchy->m_open);
            ImGui::MenuItem("Inspector",     "", &m_inspector->m_open);
            ImGui::MenuItem("Asset Browser", "", &m_assetBrowser->m_open);
            ImGui::MenuItem("Console",       "", &m_console->m_open);
            ImGui::Separator();
            ImGui::MenuItem("Grid",          "G", &m_gridVisible);
            ImGui::MenuItem("Snap",          "", &m_snapEnabled);
            ImGui::EndMenu();
        }
        ImGui::EndMainMenuBar();
    }
#endif
}

void EditorCore::RenderToolbar() {
#ifdef BADGE2D_EDITOR_IMGUI
    ImGui::SetNextWindowPos({ImGui::GetMainViewport()->Pos.x, ImGui::GetMainViewport()->Pos.y + 19});
    ImGui::SetNextWindowSize({ImGui::GetMainViewport()->Size.x, 36});
    ImGui::Begin("##Toolbar", nullptr,
        ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoDocking);

    // Play/Pause/Stop buttons
    const char* playLabel = (m_mode == EditorMode::Play) ? "⏸ Pause" : "▶ Play";
    if (ImGui::Button(playLabel, {80, 24})) {
        SetMode(m_mode == EditorMode::Play ? EditorMode::Paused : EditorMode::Play);
    }
    ImGui::SameLine();
    if (ImGui::Button("■ Stop", {70, 24})) SetMode(EditorMode::Edit);
    ImGui::SameLine();
    ImGui::Separator();
    ImGui::SameLine();

    // Gizmo mode
    if (ImGui::Button("W", {24,24})) m_gizmo->SetMode(GizmoMode::Translate);
    ImGui::SameLine();
    if (ImGui::Button("E", {24,24})) m_gizmo->SetMode(GizmoMode::Rotate);
    ImGui::SameLine();
    if (ImGui::Button("R", {24,24})) m_gizmo->SetMode(GizmoMode::Scale);
    ImGui::SameLine();
    ImGui::Separator(); ImGui::SameLine();

    // Snap toggle
    ImGui::Checkbox("Snap", &m_snapEnabled);
    if (m_snapEnabled) {
        ImGui::SameLine();
        ImGui::SetNextItemWidth(60);
        ImGui::DragFloat("##snap", &m_snapGrid, 0.5f, 0.5f, 128.0f, "%.1f");
    }
    ImGui::End();
#endif
}

void EditorCore::RenderStatusBar() {
#ifdef BADGE2D_EDITOR_IMGUI
    float h = 22;
    auto* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos({vp->Pos.x, vp->Pos.y + vp->Size.y - h});
    ImGui::SetNextWindowSize({vp->Size.x, h});
    ImGui::Begin("##Status", nullptr,
        ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoSavedSettings |
        ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_NoScrollbar);

    const char* modeStr = (m_mode==EditorMode::Play) ? "▶ PLAYING" :
                          (m_mode==EditorMode::Paused) ? "⏸ PAUSED" : "EDIT";
    ImGui::Text("%s | %s | Entities: %d",
                modeStr,
                m_editScene ? m_editScene->GetName().c_str() : "No Scene",
                m_editScene ? (int)m_editScene->GetWorld().GetEntityCount() : 0);
    ImGui::End();
#endif
}

void EditorCore::ApplyEditorTheme() {
#ifdef BADGE2D_EDITOR_IMGUI
    ImGui::StyleColorsDark();
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding    = 4;
    s.FrameRounding     = 3;
    s.GrabRounding      = 3;
    s.TabRounding       = 3;
    s.ScrollbarRounding = 3;
    s.FramePadding      = {6, 3};
    s.ItemSpacing       = {6, 4};
    s.WindowTitleAlign  = {0.5f, 0.5f};

    auto* colors = s.Colors;
    colors[ImGuiCol_WindowBg]      = {0.10f,0.10f,0.12f,0.97f};
    colors[ImGuiCol_FrameBg]       = {0.18f,0.18f,0.22f,0.95f};
    colors[ImGuiCol_TitleBgActive] = {0.14f,0.14f,0.17f,1.00f};
    colors[ImGuiCol_Button]        = {0.22f,0.22f,0.26f,0.95f};
    colors[ImGuiCol_ButtonHovered] = {0.35f,0.35f,0.40f,0.95f};
    colors[ImGuiCol_ButtonActive]  = {0.20f,0.48f,0.90f,1.00f};
    colors[ImGuiCol_Header]        = {0.20f,0.48f,0.90f,0.45f};
    colors[ImGuiCol_HeaderHovered] = {0.20f,0.48f,0.90f,0.65f};
    colors[ImGuiCol_CheckMark]     = {0.26f,0.79f,0.35f,1.00f};
    colors[ImGuiCol_SliderGrab]    = {0.26f,0.59f,0.98f,1.00f};
    colors[ImGuiCol_Tab]           = {0.14f,0.14f,0.17f,0.95f};
    colors[ImGuiCol_TabActive]     = {0.22f,0.22f,0.26f,1.00f};
    colors[ImGuiCol_TabHovered]    = {0.30f,0.30f,0.35f,0.95f};
    colors[ImGuiCol_DockingPreview]= {0.26f,0.59f,0.98f,0.50f};
#endif
}

// ==============================================================================
// Mode
// ==============================================================================
void EditorCore::SetMode(EditorMode m) {
    if (m_mode == m) return;
    EditorMode prev = m_mode;
    m_mode = m;
    if (m == EditorMode::Play && m_editScene)  m_editScene->OnResume();
    if (m == EditorMode::Edit && m_editScene)  m_editScene->OnPause();
    LOG_DEBUGF("[EditorCore] Mode: %s → %s",
               prev==EditorMode::Play?"Play":prev==EditorMode::Paused?"Paused":"Edit",
               m==EditorMode::Play?"Play":m==EditorMode::Paused?"Paused":"Edit");
}

// ==============================================================================
// Selection
// ==============================================================================
void EditorCore::Select(EntityID id, Scene* scene) {
    m_selection.type   = EditorSelection::Type::Entity;
    m_selection.entity = id;
    m_selection.scene  = scene;
    m_gizmo->SetTargetEntity(id, scene);
}

void EditorCore::Select(AssetID id) {
    m_selection.type  = EditorSelection::Type::Asset;
    m_selection.asset = id;
    m_gizmo->ClearTarget();
}

void EditorCore::ClearSelection() {
    m_selection.Clear();
    m_gizmo->ClearTarget();
}

// ==============================================================================
// Command stack
// ==============================================================================
void EditorCore::Execute(std::unique_ptr<EditorCommand> cmd) {
    cmd->Execute();
    m_undoStack.push_back(std::move(cmd));
    if ((int)m_undoStack.size() > MAX_UNDO) m_undoStack.erase(m_undoStack.begin());
    m_redoStack.clear();
}

void EditorCore::Undo() {
    if (m_undoStack.empty()) return;
    auto& cmd = m_undoStack.back();
    cmd->Undo();
    m_redoStack.push_back(std::move(cmd));
    m_undoStack.pop_back();
}

void EditorCore::Redo() {
    if (m_redoStack.empty()) return;
    auto& cmd = m_redoStack.back();
    cmd->Execute();
    m_undoStack.push_back(std::move(cmd));
    m_redoStack.pop_back();
}

bool EditorCore::CanUndo() const { return !m_undoStack.empty(); }
bool EditorCore::CanRedo() const { return !m_redoStack.empty(); }

const std::string& EditorCore::GetUndoLabel() const {
    static std::string empty = "Nothing to undo";
    return m_undoStack.empty() ? empty : m_undoStack.back()->GetLabel();
}

const std::string& EditorCore::GetRedoLabel() const {
    static std::string empty = "Nothing to redo";
    return m_redoStack.empty() ? empty : m_redoStack.back()->GetLabel();
}

// ==============================================================================
// Scene ops
// ==============================================================================
void EditorCore::NewScene(const std::string& name) {
    SceneSettings s; s.name = name; s.id = 1;
    m_editSceneOwned = std::make_unique<Scene>(std::move(s));
    m_editScene = m_editSceneOwned.get();
    m_editScene->OnLoad();
    m_editScenePath.clear();
    ClearSelection();
    m_undoStack.clear(); m_redoStack.clear();
    LOG_INFOF("[EditorCore] New scene: '%s'", name.c_str());
}

void EditorCore::OpenScene(const std::string& filepath) {
    if (m_editScene) { delete m_editScene; m_editScene = nullptr; }
    SceneSettings s; s.name = "Loaded"; s.id = 1;
    m_editSceneOwned = std::make_unique<Scene>(std::move(s));
    m_editScene = m_editSceneOwned.get();
    m_editScene->OnLoad();
    SceneSerializer::Get().LoadFromFile(*m_editScene, filepath);
    m_editScenePath = filepath;
    ClearSelection();
    LOG_INFOF("[EditorCore] Opened: %s", filepath.c_str());
}

void EditorCore::SaveScene() {
    if (!m_editScene) return;
    if (m_editScenePath.empty()) { m_editScenePath = m_editScene->GetName() + ".scene"; }
    SceneSerializer::Get().SaveToFile(*m_editScene, m_editScenePath);
}

void EditorCore::SaveSceneAs(const std::string& filepath) {
    m_editScenePath = filepath;
    SaveScene();
}

// ==============================================================================
// Entity ops
// ==============================================================================
EntityID EditorCore::CreateEntity(const std::string& name) {
    if (!m_editScene) return INVALID_ENTITY;
    auto cmd = std::make_unique<CreateEntityCommand>(&m_editScene->GetWorld(), name);
    EntityID id = INVALID_ENTITY;
    cmd->Execute();
    id = cmd->GetEntity();
    m_undoStack.push_back(std::move(cmd));
    m_redoStack.clear();
    return id;
}

void EditorCore::DuplicateSelected() {
    if (!m_selection.IsEntity() || !m_editScene) return;
    EntityID src = m_selection.entity;
    EntityID dst = CreateEntity("Entity_copy");
    if (auto* tc = m_editScene->GetWorld().TryGetComponent<TransformComponent>(src)) {
        TransformComponent copy = *tc;
        copy.position.x += 16;
        m_editScene->GetWorld().AddComponent(dst, copy);
    }
    Select(dst, m_editScene);
}

void EditorCore::DeleteSelected() {
    if (!m_selection.IsEntity() || !m_editScene) return;
    auto cmd = std::make_unique<DeleteEntityCommand>(&m_editScene->GetWorld(), m_selection.entity);
    Execute(std::move(cmd));
    ClearSelection();
}

} // namespace BADGE2D
