#pragma once
// ==============================================================================
// EditorCore.h — BADGE2D Scene Editor
// Runs as a separate Application subclass on top of the engine.
// Provides ImGui-based panels, gizmos, and a command-stack undo/redo system.
//
// Note: The editor hooks into the engine's OpenGL context via the same GLFW
// window. ImGui's OpenGL3 backend is initialised here.
// ==============================================================================

#include "../../engine/ModuleSystem/ModuleInterface.h"
#include "../../scene/manager/Scene.h"
#include "../../scene/manager/SceneManager.h"
#include "../commands/EditorCommand.h"
#include "../panels/SceneHierarchyPanel.h"
#include "../panels/InspectorPanel.h"
#include "../panels/AssetBrowserPanel.h"
#include "../panels/ViewportPanel.h"
#include "../panels/ConsolePanel.h"
#include "../gizmos/TransformGizmo.h"
#include <vector>
#include <memory>
#include <string>
#include <functional>

namespace BADGE2D {

// ==============================================================================
// EditorState — Global editor mode
// ==============================================================================
enum class EditorMode {
    Edit,      // Editing; game is paused
    Play,      // Running the game inside the editor
    Paused     // Game paused mid-play
};

// ==============================================================================
// EditorSelection — Currently selected entity/asset
// ==============================================================================
struct EditorSelection {
    enum class Type { None, Entity, Asset };
    Type      type     = Type::None;
    EntityID  entity   = INVALID_ENTITY;
    AssetID   asset    = INVALID_ASSET;
    Scene*    scene    = nullptr;

    bool IsEntity() const { return type == Type::Entity; }
    bool IsAsset()  const { return type == Type::Asset;  }
    void Clear()          { type = Type::None; entity = INVALID_ENTITY; }
};

// ==============================================================================
// EditorCore — Master editor module
// ==============================================================================
class EditorCore : public IModule {
public:
    bool        Initialize()          override;
    void        Shutdown  ()          override;
    void        Update    (double dt) override;
    void        Render    ()          override;
    const char* GetName   ()    const override { return "EditorCore"; }
    uint32_t    GetInitOrder() const  override { return (uint32_t)ModuleInitOrder::Editor; }

    static EditorCore& Get();

    // ---- Mode ----
    void        SetMode (EditorMode m);
    EditorMode  GetMode ()           const { return m_mode; }
    bool        IsEditing()          const { return m_mode == EditorMode::Edit; }
    bool        IsPlaying()          const { return m_mode == EditorMode::Play; }

    // ---- Selection ----
    void                    Select    (EntityID id, Scene* scene);
    void                    Select    (AssetID  id);
    void                    ClearSelection();
    const EditorSelection&  GetSelection()   const { return m_selection; }

    // ---- Command stack ----
    void  Execute(std::unique_ptr<EditorCommand> cmd);
    void  Undo();
    void  Redo();
    bool  CanUndo() const;
    bool  CanRedo() const;
    const std::string& GetUndoLabel() const;
    const std::string& GetRedoLabel() const;

    // ---- Scene ops ----
    void  NewScene  (const std::string& name = "NewScene");
    void  OpenScene (const std::string& filepath);
    void  SaveScene ();
    void  SaveSceneAs(const std::string& filepath);
    Scene* GetEditScene() { return m_editScene; }

    // ---- Entity ops ----
    EntityID CreateEntity(const std::string& name = "Entity");
    void     DuplicateSelected();
    void     DeleteSelected();

    // ---- Settings ----
    bool  GetSnapEnabled()   const { return m_snapEnabled; }
    float GetSnapGrid()      const { return m_snapGrid;    }
    void  SetSnap(bool e, float g) { m_snapEnabled = e; m_snapGrid = g; }

    bool  IsGridVisible()    const { return m_gridVisible; }
    void  SetGridVisible(bool v)   { m_gridVisible = v; }

    // ---- Panels ----
    SceneHierarchyPanel& GetHierarchy()    { return *m_hierarchy;  }
    InspectorPanel&      GetInspector()    { return *m_inspector;  }
    AssetBrowserPanel&   GetAssetBrowser() { return *m_assetBrowser;}
    ViewportPanel&       GetViewport()     { return *m_viewport;   }
    ConsolePanel&        GetConsole()      { return *m_console;    }

    // Hook for custom editor extensions
    std::function<void()> OnRenderEditorUI;

private:
    EditorCore() = default;

    void InitImGui();
    void ShutdownImGui();
    void RenderDockspace();
    void RenderMenuBar();
    void RenderToolbar();
    void RenderStatusBar();
    void ApplyEditorTheme();

    EditorMode       m_mode      = EditorMode::Edit;
    EditorSelection  m_selection;
    Scene*                       m_editScene = nullptr;
    std::unique_ptr<Scene>       m_editSceneOwned;
    std::string                  m_editScenePath;

    // Command stack
    std::vector<std::unique_ptr<EditorCommand>> m_undoStack;
    std::vector<std::unique_ptr<EditorCommand>> m_redoStack;
    static constexpr int MAX_UNDO = 200;

    // Panels
    std::unique_ptr<SceneHierarchyPanel> m_hierarchy;
    std::unique_ptr<InspectorPanel>      m_inspector;
    std::unique_ptr<AssetBrowserPanel>   m_assetBrowser;
    std::unique_ptr<ViewportPanel>       m_viewport;
    std::unique_ptr<ConsolePanel>        m_console;
    std::unique_ptr<TransformGizmo>      m_gizmo;

    // Editor settings
    bool  m_snapEnabled  = false;
    float m_snapGrid     = 16.0f;
    bool  m_gridVisible  = true;
    bool  m_imguiReady   = false;
    bool  m_initialized  = false;
};

} // namespace BADGE2D
