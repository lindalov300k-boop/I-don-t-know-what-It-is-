// ============================================================
//  BADGE Engine – ImportExport/ImportExportSystem.cs
//  Plugin-based importer/exporter for images, audio, video,
//  3D models, fonts, text, archives (ZIP).
//  ZipReader / ZipWriter fully implemented.
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;

namespace BADGE.Engine.ImportExport
{
    // ═══════════════════════════════════════════════════════
    //  Asset types
    // ═══════════════════════════════════════════════════════
    public enum AssetType
    {
        Image, Audio, Video, Model3D, Font, Text, Archive,
        Script, Material, Prefab, Scene, Animation, Shader, Unknown
    }

    public sealed class ImportedAsset
    {
        public string    SourcePath  { get; set; } = "";
        public string    Name        { get; set; } = "";
        public AssetType Type        { get; set; }
        public byte[]    RawData     { get; set; } = Array.Empty<byte>();
        public Dictionary<string, object> Metadata { get; } = new();
        public bool      Success     { get; set; }
        public string?   Error       { get; set; }
    }

    // ═══════════════════════════════════════════════════════
    //  Importer / Exporter plugin contracts
    // ═══════════════════════════════════════════════════════
    public interface IAssetImporter
    {
        string[] SupportedExtensions { get; }
        AssetType AssetType           { get; }
        ImportedAsset Import(string path);
        ImportedAsset ImportFromBytes(string name, byte[] data);
    }

    public interface IAssetExporter
    {
        string[] SupportedExtensions { get; }
        AssetType AssetType           { get; }
        bool Export(ImportedAsset asset, string outputPath);
        byte[] ExportToBytes(ImportedAsset asset, string extension);
    }

    // ═══════════════════════════════════════════════════════
    //  Format Registry
    // ═══════════════════════════════════════════════════════
    public sealed class FormatRegistry
    {
        private readonly List<IAssetImporter> _importers = new();
        private readonly List<IAssetExporter> _exporters = new();

        public void RegisterImporter(IAssetImporter imp) => _importers.Add(imp);
        public void RegisterExporter(IAssetExporter exp) => _exporters.Add(exp);

        public IAssetImporter? FindImporter(string path)
        {
            var ext = Path.GetExtension(path).ToLower();
            return _importers.FirstOrDefault(i => i.SupportedExtensions.Contains(ext));
        }

        public IAssetExporter? FindExporter(string extension)
        {
            var ext = extension.ToLower();
            return _exporters.FirstOrDefault(e => e.SupportedExtensions.Contains(ext));
        }

        public IEnumerable<string> AllImportableExtensions =>
            _importers.SelectMany(i => i.SupportedExtensions).Distinct();
        public IEnumerable<string> AllExportableExtensions =>
            _exporters.SelectMany(e => e.SupportedExtensions).Distinct();
    }

    // ═══════════════════════════════════════════════════════
    //  Built-in Importers
    // ═══════════════════════════════════════════════════════

    // Image (PNG/JPG/BMP/TGA/GIF) – raw bytes wrapper
    public sealed class ImageImporter : IAssetImporter
    {
        public string[] SupportedExtensions => new[]{".png",".jpg",".jpeg",".bmp",".tga",".gif",".webp"};
        public AssetType AssetType => AssetType.Image;

        public ImportedAsset Import(string path)
        {
            if (!File.Exists(path))
                return Fail(path, "File not found");
            var data = File.ReadAllBytes(path);
            return ImportFromBytes(Path.GetFileNameWithoutExtension(path), data);
        }

        public ImportedAsset ImportFromBytes(string name, byte[] data)
        {
            var a = new ImportedAsset
            {
                Name    = name,
                Type    = AssetType.Image,
                RawData = data,
                Success = data.Length > 0
            };
            // Detect dimensions from PNG IHDR or JPEG SOF0
            if (data.Length > 24 && data[0]==0x89 && data[1]==0x50) // PNG
            {
                a.Metadata["Width"]  = (data[16]<<24)|(data[17]<<16)|(data[18]<<8)|data[19];
                a.Metadata["Height"] = (data[20]<<24)|(data[21]<<16)|(data[22]<<8)|data[23];
                a.Metadata["Format"] = "PNG";
            }
            else if (data.Length > 3 && data[0]==0xFF && data[1]==0xD8)
            {
                a.Metadata["Format"] = "JPEG";
                // JPEG dimension search: find SOF0 (0xFFC0)
                for (int i=2; i<data.Length-8; i++)
                {
                    if (data[i]==0xFF && data[i+1]==0xC0)
                    {
                        a.Metadata["Height"] = (data[i+5]<<8)|data[i+6];
                        a.Metadata["Width"]  = (data[i+7]<<8)|data[i+8];
                        break;
                    }
                }
            }
            return a;
        }

        private static ImportedAsset Fail(string p, string err) =>
            new(){ SourcePath=p, Name=Path.GetFileName(p), Type=AssetType.Image, Success=false, Error=err };
    }

    // Audio importer (WAV/MP3/OGG/FLAC)
    public sealed class AudioImporter : IAssetImporter
    {
        public string[] SupportedExtensions => new[]{".wav",".mp3",".ogg",".flac",".aiff"};
        public AssetType AssetType => AssetType.Audio;

        public ImportedAsset Import(string path)
        {
            if (!File.Exists(path)) return Fail(path,"File not found");
            var data = File.ReadAllBytes(path);
            return ImportFromBytes(Path.GetFileNameWithoutExtension(path), data);
        }

        public ImportedAsset ImportFromBytes(string name, byte[] data)
        {
            var a = new ImportedAsset { Name=name, Type=AssetType.Audio, RawData=data };
            var ext = DetectAudioFormat(data);
            a.Metadata["Format"] = ext;

            // WAV header parse: channels, sample rate, bit depth
            if (ext == "WAV" && data.Length >= 44)
            {
                a.Metadata["Channels"]   = BitConverter.ToInt16(data, 22);
                a.Metadata["SampleRate"] = BitConverter.ToInt32(data, 24);
                a.Metadata["BitDepth"]   = BitConverter.ToInt16(data, 34);
                int dataSize = BitConverter.ToInt32(data, 40);
                int bytesPerSample = (int)a.Metadata["BitDepth"] / 8 * (int)a.Metadata["Channels"];
                if (bytesPerSample > 0)
                    a.Metadata["DurationSeconds"] = (float)dataSize / (int)a.Metadata["SampleRate"] / bytesPerSample;
            }
            a.Success = data.Length > 0;
            return a;
        }

        private static string DetectAudioFormat(byte[] d)
        {
            if (d.Length >= 4)
            {
                if (d[0]=='R'&&d[1]=='I'&&d[2]=='F'&&d[3]=='F') return "WAV";
                if (d[0]==0xFF&&(d[1]&0xE0)==0xE0) return "MP3";
                if (d[0]=='O'&&d[1]=='g'&&d[2]=='g'&&d[3]=='S') return "OGG";
                if (d[0]=='f'&&d[1]=='L'&&d[2]=='a'&&d[3]=='C') return "FLAC";
            }
            return "Unknown";
        }

        private static ImportedAsset Fail(string p, string e) =>
            new(){ SourcePath=p, Name=Path.GetFileName(p), Type=AssetType.Audio, Success=false, Error=e };
    }

    // 3D model importer (OBJ/FBX/GLTF)
    public sealed class ModelImporter : IAssetImporter
    {
        public string[] SupportedExtensions => new[]{".obj",".fbx",".gltf",".glb",".dae",".blend"};
        public AssetType AssetType => AssetType.Model3D;

        public ImportedAsset Import(string path)
        {
            if (!File.Exists(path)) return Fail(path,"File not found");
            var data = File.ReadAllBytes(path);
            return ImportFromBytes(Path.GetFileNameWithoutExtension(path), data);
        }

        public ImportedAsset ImportFromBytes(string name, byte[] data)
        {
            var a = new ImportedAsset { Name=name, Type=AssetType.Model3D, RawData=data };
            var format = DetectFormat(data);
            a.Metadata["Format"] = format;

            if (format == "OBJ")
            {
                // Parse OBJ: count vertices, faces
                string text = Encoding.UTF8.GetString(data);
                int verts = text.Split('\n').Count(l => l.StartsWith("v "));
                int faces = text.Split('\n').Count(l => l.StartsWith("f "));
                a.Metadata["VertexCount"] = verts;
                a.Metadata["FaceCount"]   = faces;
            }
            else if (format == "GLTF" || format == "GLB")
            {
                a.Metadata["Binary"] = format == "GLB";
            }

            a.Success = data.Length > 0;
            return a;
        }

        private static string DetectFormat(byte[] d)
        {
            if (d.Length < 4) return "Unknown";
            if (d[0]=='g'&&d[1]=='l'&&d[2]=='T'&&d[3]=='F') return "GLB";
            string header = Encoding.ASCII.GetString(d, 0, System.Math.Min(20, d.Length));
            if (header.Contains("FBX")) return "FBX";
            return "OBJ"; // default text-based
        }

        private static ImportedAsset Fail(string p, string e) =>
            new(){ SourcePath=p, Name=Path.GetFileName(p), Type=AssetType.Model3D, Success=false, Error=e };
    }

    // Text/Markdown importer
    public sealed class TextImporter : IAssetImporter
    {
        public string[] SupportedExtensions => new[]{".txt",".md",".rtf",".csv",".json",".yaml",".xml",".docx"};
        public AssetType AssetType => AssetType.Text;

        public ImportedAsset Import(string path)
        {
            if (!File.Exists(path)) return Fail(path,"Not found");
            var data = File.ReadAllBytes(path);
            return ImportFromBytes(Path.GetFileNameWithoutExtension(path), data);
        }

        public ImportedAsset ImportFromBytes(string name, byte[] data)
        {
            var a = new ImportedAsset { Name=name, Type=AssetType.Text, RawData=data, Success=true };
            // Try UTF-8 decode
            try
            {
                string text = Encoding.UTF8.GetString(data);
                a.Metadata["Text"]      = text;
                a.Metadata["LineCount"] = text.Split('\n').Length;
                a.Metadata["CharCount"] = text.Length;
            }
            catch { a.Metadata["Text"] = "[binary]"; }
            return a;
        }

        private static ImportedAsset Fail(string p, string e) =>
            new(){ SourcePath=p, Name=Path.GetFileName(p), Type=AssetType.Text, Success=false, Error=e };
    }

    // Font importer (TTF/OTF)
    public sealed class FontImporter : IAssetImporter
    {
        public string[] SupportedExtensions => new[]{".ttf",".otf",".woff",".woff2"};
        public AssetType AssetType => AssetType.Font;

        public ImportedAsset Import(string path)
        {
            if (!File.Exists(path)) return Fail(path,"Not found");
            var data = File.ReadAllBytes(path);
            return ImportFromBytes(Path.GetFileNameWithoutExtension(path), data);
        }

        public ImportedAsset ImportFromBytes(string name, byte[] data)
        {
            var a = new ImportedAsset { Name=name, Type=AssetType.Font, RawData=data, Success=true };
            // Detect font format from magic bytes
            string magic = data.Length >= 4 ? BitConverter.ToString(data,0,4) : "";
            a.Metadata["Format"] = magic == "00-01-00-00" ? "TTF" :
                                   data.Length >= 4 && data[0]=='O'&&data[1]=='T'&&data[2]=='T'&&data[3]=='O' ? "OTF" : "Unknown";
            return a;
        }

        private static ImportedAsset Fail(string p, string e) =>
            new(){ SourcePath=p, Name=Path.GetFileName(p), Type=AssetType.Font, Success=false, Error=e };
    }

    // ═══════════════════════════════════════════════════════
    //  Built-in Exporters
    // ═══════════════════════════════════════════════════════
    public sealed class RawExporter : IAssetExporter
    {
        public string[] SupportedExtensions => new[]{
            ".png",".jpg",".wav",".mp3",".ogg",".obj",".gltf",".glb",
            ".ttf",".otf",".txt",".md",".json",".bin"};
        public AssetType AssetType => AssetType.Unknown; // handles all

        public bool Export(ImportedAsset asset, string outputPath)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(outputPath) ?? ".");
                File.WriteAllBytes(outputPath, asset.RawData);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Export] Failed {outputPath}: {ex.Message}");
                return false;
            }
        }

        public byte[] ExportToBytes(ImportedAsset asset, string extension) => asset.RawData;
    }

    // ═══════════════════════════════════════════════════════
    //  ZIP Reader / Writer  (fully implemented)
    // ═══════════════════════════════════════════════════════
    public sealed class ZipReader : IDisposable
    {
        private ZipArchive _archive;
        private bool       _disposed;

        public ZipReader(string zipPath)
        {
            if (!File.Exists(zipPath)) throw new FileNotFoundException("ZIP not found", zipPath);
            _archive = ZipFile.OpenRead(zipPath);
        }

        public ZipReader(Stream stream)
        {
            _archive = new ZipArchive(stream, ZipArchiveMode.Read, leaveOpen: true);
        }

        public IReadOnlyList<string> Entries =>
            _archive.Entries.Select(e => e.FullName).ToList();

        public bool Contains(string path) =>
            _archive.GetEntry(path.Replace('\\','/')) != null;

        public byte[] ReadBytes(string entryPath)
        {
            var entry = _archive.GetEntry(entryPath.Replace('\\','/'))
                ?? throw new FileNotFoundException($"ZIP entry not found: {entryPath}");
            using var s = entry.Open();
            using var ms = new MemoryStream();
            s.CopyTo(ms);
            return ms.ToArray();
        }

        public string ReadText(string entryPath) =>
            Encoding.UTF8.GetString(ReadBytes(entryPath));

        public Stream OpenEntry(string entryPath)
        {
            var entry = _archive.GetEntry(entryPath.Replace('\\','/'))
                ?? throw new FileNotFoundException($"ZIP entry not found: {entryPath}");
            return entry.Open();
        }

        public void ExtractAll(string outputDir)
        {
            Directory.CreateDirectory(outputDir);
            _archive.ExtractToDirectory(outputDir, overwriteFiles: true);
        }

        public void ExtractEntry(string entryPath, string outputPath)
        {
            var data = ReadBytes(entryPath);
            Directory.CreateDirectory(Path.GetDirectoryName(outputPath) ?? ".");
            File.WriteAllBytes(outputPath, data);
        }

        public IEnumerable<string> EntriesInFolder(string folder) =>
            _archive.Entries
                .Where(e => e.FullName.StartsWith(folder.Replace('\\','/'),
                             StringComparison.OrdinalIgnoreCase))
                .Select(e => e.FullName);

        public void Dispose()
        {
            if (!_disposed) { _archive.Dispose(); _disposed = true; }
        }
    }

    public sealed class ZipWriter : IDisposable
    {
        private ZipArchive _archive;
        private bool       _disposed;

        public ZipWriter(string zipPath, bool append = false)
        {
            var mode = append && File.Exists(zipPath)
                ? ZipArchiveMode.Update : ZipArchiveMode.Create;
            _archive = ZipFile.Open(zipPath, mode);
        }

        public ZipWriter(Stream stream)
        {
            _archive = new ZipArchive(stream, ZipArchiveMode.Create, leaveOpen: true);
        }

        public void AddBytes(string entryPath, byte[] data,
            CompressionLevel level = CompressionLevel.Optimal)
        {
            var entry = _archive.CreateEntry(entryPath.Replace('\\','/'), level);
            using var s = entry.Open();
            s.Write(data, 0, data.Length);
        }

        public void AddText(string entryPath, string text,
            CompressionLevel level = CompressionLevel.Optimal)
            => AddBytes(entryPath, Encoding.UTF8.GetBytes(text), level);

        public void AddFile(string entryPath, string sourcePath,
            CompressionLevel level = CompressionLevel.Optimal)
        {
            if (!File.Exists(sourcePath))
                throw new FileNotFoundException("Source file not found", sourcePath);
            AddBytes(entryPath, File.ReadAllBytes(sourcePath), level);
        }

        public void AddDirectory(string sourceDir, string? zipRootFolder = null)
        {
            if (!Directory.Exists(sourceDir))
                throw new DirectoryNotFoundException($"Directory not found: {sourceDir}");

            foreach (var file in Directory.EnumerateFiles(sourceDir, "*", SearchOption.AllDirectories))
            {
                var rel = Path.GetRelativePath(sourceDir, file);
                var entry = zipRootFolder != null
                    ? Path.Combine(zipRootFolder, rel) : rel;
                AddFile(entry.Replace('\\','/'), file);
            }
        }

        public void Remove(string entryPath)
        {
            var entry = _archive.GetEntry(entryPath.Replace('\\','/'));
            entry?.Delete();
        }

        public void Dispose()
        {
            if (!_disposed) { _archive.Dispose(); _disposed = true; }
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Asset Importer/Exporter  (facade)
    // ═══════════════════════════════════════════════════════
    public sealed class AssetImporter
    {
        private readonly FormatRegistry _registry;

        public AssetImporter()
        {
            _registry = new FormatRegistry();
            // Register all built-in importers
            _registry.RegisterImporter(new ImageImporter());
            _registry.RegisterImporter(new AudioImporter());
            _registry.RegisterImporter(new ModelImporter());
            _registry.RegisterImporter(new TextImporter());
            _registry.RegisterImporter(new FontImporter());
        }

        public void RegisterPlugin(IAssetImporter plugin) => _registry.RegisterImporter(plugin);

        public ImportedAsset Import(string path)
        {
            var importer = _registry.FindImporter(path);
            if (importer == null)
                return new ImportedAsset
                { SourcePath=path, Name=Path.GetFileName(path), Success=false,
                  Error=$"No importer for extension '{Path.GetExtension(path)}'" };

            return importer.Import(path);
        }

        public List<ImportedAsset> ImportFromZip(string zipPath, string? folder = null)
        {
            var results = new List<ImportedAsset>();
            using var zip = new ZipReader(zipPath);
            var entries = folder != null ? zip.EntriesInFolder(folder) : zip.Entries;

            foreach (var entry in entries)
            {
                var importer = _registry.FindImporter(entry);
                if (importer == null) continue;
                try
                {
                    var data   = zip.ReadBytes(entry);
                    var result = importer.ImportFromBytes(
                        Path.GetFileNameWithoutExtension(entry), data);
                    result.SourcePath = $"{zipPath}::{entry}";
                    results.Add(result);
                }
                catch (Exception ex)
                {
                    results.Add(new ImportedAsset
                    { SourcePath=$"{zipPath}::{entry}", Success=false, Error=ex.Message });
                }
            }
            return results;
        }

        public FormatRegistry Registry => _registry;
    }

    public sealed class AssetExporter
    {
        private readonly FormatRegistry _registry;
        private readonly RawExporter    _raw = new();

        public AssetExporter()
        {
            _registry = new FormatRegistry();
            _registry.RegisterExporter(_raw);
        }

        public void RegisterPlugin(IAssetExporter plugin) => _registry.RegisterExporter(plugin);

        public bool Export(ImportedAsset asset, string outputPath)
        {
            var exp = _registry.FindExporter(Path.GetExtension(outputPath)) ?? _raw;
            return exp.Export(asset, outputPath);
        }

        public bool ExportToZip(IEnumerable<ImportedAsset> assets, string zipPath)
        {
            try
            {
                using var zip = new ZipWriter(zipPath);
                foreach (var a in assets)
                    if (a.RawData.Length > 0)
                        zip.AddBytes(a.Name, a.RawData);
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Export] ZIP failed: {ex.Message}");
                return false;
            }
        }
    }
}

    // ═══════════════════════════════════════════════════════
    //  Video Importer  (.mp4 / .webm / .avi / .mov / .mkv)
    // ═══════════════════════════════════════════════════════
    public sealed class VideoImporter : IAssetImporter
    {
        public string[] SupportedExtensions => new[] { ".mp4", ".webm", ".avi", ".mov", ".mkv", ".ogv" };
        public AssetType AssetType => AssetType.Video;

        public ImportedAsset Import(string path)
        {
            if (!File.Exists(path)) return Fail(path, "File not found");
            var data = File.ReadAllBytes(path);
            return ImportFromBytes(Path.GetFileNameWithoutExtension(path), data);
        }

        public ImportedAsset ImportFromBytes(string name, byte[] data)
        {
            var a = new ImportedAsset { Name = name, Type = AssetType.Video, RawData = data };
            if (data.Length < 8) { a.Success = false; a.Error = "File too small"; return a; }

            var format = DetectFormat(data);
            a.Metadata["Format"]   = format;
            a.Metadata["SizeBytes"]= data.Length;

            if (format == "MP4" || format == "MOV")
            {
                // Walk MP4 boxes to find ftyp/moov/mdat
                ParseMP4Boxes(data, a);
            }
            else if (format == "WEBM")
            {
                a.Metadata["Container"] = "WebM/Matroska";
                a.Metadata["Codec"]     = "VP8/VP9/AV1";
            }
            else if (format == "AVI")
            {
                // AVI RIFF structure — extract stream info
                if (data.Length >= 32)
                {
                    a.Metadata["Container"] = "AVI";
                    // AVI stream list starts at byte 12 ('LIST' chunk)
                    a.Metadata["Codec"] = "Unknown (AVI)";
                }
            }
            a.Success = true;
            return a;
        }

        private static string DetectFormat(byte[] d)
        {
            if (d.Length >= 12)
            {
                // MP4: ftyp box at offset 4 usually; check for common brands
                var ftyp = System.Text.Encoding.ASCII.GetString(d, 4, System.Math.Min(4, d.Length - 4));
                if (ftyp == "ftyp") return "MP4";

                // Check offset 0 for MP4 box size + 'ftyp'
                if (d[4] == 'f' && d[5] == 't' && d[6] == 'y' && d[7] == 'p')
                {
                    var brand = System.Text.Encoding.ASCII.GetString(d, 8, 4);
                    return brand.StartsWith("qt") ? "MOV" : "MP4";
                }
            }
            if (d[0] == 0x1A && d[1] == 0x45 && d[2] == 0xDF && d[3] == 0xA3) return "WEBM";
            if (d[0] == 'R' && d[1] == 'I' && d[2] == 'F' && d[3] == 'F' &&
                d[8] == 'A' && d[9] == 'V' && d[10] == 'I') return "AVI";
            if (d[0] == 0x00 && d[1] == 0x00 && d[2] == 0x00 && d[3] == 0x01) return "MPEG";
            return "Unknown";
        }

        private static void ParseMP4Boxes(byte[] data, ImportedAsset a)
        {
            int offset = 0;
            while (offset + 8 < data.Length)
            {
                long boxSize = (data[offset] << 24) | (data[offset+1] << 16) |
                               (data[offset+2] << 8) | data[offset+3];
                if (boxSize < 8 || boxSize > data.Length) break;
                var name = System.Text.Encoding.ASCII.GetString(data, offset + 4, 4);
                if (name == "moov") { a.Metadata["HasMoov"] = true; }
                if (name == "mdat") { a.Metadata["DataSize"] = boxSize; }
                if (name == "ftyp" && data.Length > offset + 12)
                    a.Metadata["Brand"] = System.Text.Encoding.ASCII.GetString(data, offset + 8, 4).Trim();
                offset += (int)boxSize;
            }
        }

        private static ImportedAsset Fail(string p, string e) =>
            new() { SourcePath = p, Name = Path.GetFileName(p), Type = AssetType.Video, Success = false, Error = e };
    }

    // ═══════════════════════════════════════════════════════
    //  Plugin Importers  (example custom plugin base)
    // ═══════════════════════════════════════════════════════

    /// <summary>
    /// Base class for writing third-party importer plugins.
    /// Derive from this, override SupportedExtensions + ImportFromBytes,
    /// then call AssetImporter.RegisterPlugin(new MyPlugin()).
    /// </summary>
    public abstract class PluginImporterBase : IAssetImporter
    {
        public abstract string[]  SupportedExtensions { get; }
        public abstract AssetType AssetType           { get; }
        public virtual  string    PluginName          => GetType().Name;
        public virtual  string    PluginVersion       => "1.0.0";

        public ImportedAsset Import(string path)
        {
            if (!File.Exists(path))
                return Failed(path, "File not found");
            try
            {
                var data = File.ReadAllBytes(path);
                return ImportFromBytes(Path.GetFileNameWithoutExtension(path), data);
            }
            catch (Exception ex)
            {
                return Failed(path, ex.Message);
            }
        }

        public abstract ImportedAsset ImportFromBytes(string name, byte[] data);

        protected ImportedAsset Success(string name, byte[] raw, AssetType type,
            Dictionary<string, object>? meta = null)
        {
            var a = new ImportedAsset { Name = name, RawData = raw, Type = type, Success = true };
            if (meta != null) foreach (var (k, v) in meta) a.Metadata[k] = v;
            return a;
        }

        protected ImportedAsset Failed(string path, string error) =>
            new() { SourcePath = path, Name = Path.GetFileName(path),
                    Type = AssetType, Success = false, Error = error };
    }

    /// <summary>Example: PSD (Photoshop) file plugin skeleton.</summary>
    public sealed class PSDPluginImporter : PluginImporterBase
    {
        public override string[]  SupportedExtensions => new[] { ".psd", ".psb" };
        public override AssetType AssetType           => AssetType.Image;

        public override ImportedAsset ImportFromBytes(string name, byte[] data)
        {
            // Real: use a PSD library (e.g. PsdPlugin, ImageSharp)
            if (data.Length < 26 || data[0] != '8' || data[1] != 'B' || data[2] != 'P' || data[3] != 'S')
                return Failed(name, "Not a valid PSD file");

            int channels = (data[12] << 8) | data[13];
            int height   = (data[14] << 24) | (data[15] << 16) | (data[16] << 8) | data[17];
            int width    = (data[18] << 24) | (data[19] << 16) | (data[20] << 8) | data[21];
            int depth    = (data[22] << 8) | data[23];

            return Success(name, data, AssetType.Image, new Dictionary<string, object>
            {
                ["Format"]   = "PSD",
                ["Width"]    = width,
                ["Height"]   = height,
                ["Channels"] = channels,
                ["BitDepth"] = depth,
                ["Version"]  = ((data[4] << 8) | data[5]) == 2 ? "PSB" : "PSD"
            });
        }
    }

    /// <summary>Example: SVG vector graphics plugin skeleton.</summary>
    public sealed class SVGPluginImporter : PluginImporterBase
    {
        public override string[]  SupportedExtensions => new[] { ".svg", ".svgz" };
        public override AssetType AssetType           => AssetType.Image;

        public override ImportedAsset ImportFromBytes(string name, byte[] data)
        {
            string text;
            if (data.Length >= 2 && data[0] == 0x1F && data[1] == 0x8B)
            {
                // SVGZ — decompress first
                using var ms  = new MemoryStream(data);
                using var gz  = new GZipStream(ms, CompressionMode.Decompress);
                using var out2 = new MemoryStream();
                gz.CopyTo(out2);
                text = Encoding.UTF8.GetString(out2.ToArray());
            }
            else text = Encoding.UTF8.GetString(data);

            var a = Success(name, data, AssetType.Image, new Dictionary<string, object>
            { ["Format"] = "SVG", ["IsVector"] = true });

            // Extract viewBox / width / height from SVG attributes
            var widthMatch  = System.Text.RegularExpressions.Regex.Match(text, @"width=""([^""]+)""");
            var heightMatch = System.Text.RegularExpressions.Regex.Match(text, @"height=""([^""]+)""");
            if (widthMatch.Success)  a.Metadata["Width"]  = widthMatch.Groups[1].Value;
            if (heightMatch.Success) a.Metadata["Height"] = heightMatch.Groups[1].Value;
            return a;
        }
    }
