using System;
using System.Collections.Generic;
using BADGE.Editor;

namespace BADGE.Engine.Editor
{
    // ── PBR channel set ───────────────────────────────────────
    public sealed class PbrChannels
    {
        public float  Metallic   { get; set; } = 0f;
        public float  Roughness  { get; set; } = 0.5f;
        public string? AlbedoTexture    { get; set; }
        public string? NormalTexture    { get; set; }
        public string? AOTexture        { get; set; }
        public string? EmissionTexture  { get; set; }
        public float[] EmissionColor    { get; set; } = { 0f, 0f, 0f };
    }

    public class MaterialProperty
    {
        public string Name  = string.Empty;
        public string Type  = string.Empty; // float, color, texture, vector
        public object Value = new();
    }

    public class MaterialAsset
    {
        public string Id         = string.Empty;
        public string Name       = string.Empty;
        public string ShaderName = string.Empty;
        public PbrChannels Pbr   = new();
        public Dictionary<string, MaterialProperty> Properties = new();
        public bool IsModified;
    }

    public class MaterialEditorSystem : IEditorModule
    {
        // ── Singleton ─────────────────────────────────────────
        private static MaterialEditorSystem? _instance;
        public static  MaterialEditorSystem   Instance => _instance ??= new MaterialEditorSystem();

        // ── IEditorModule ─────────────────────────────────────
        public string Name   => "Material Editor";
        public string Icon   => "🎨";
        public bool   IsOpen { get; set; }

        public void Open()  { IsOpen = true;  Console.WriteLine("[MaterialEditor] Opened."); }
        public void Close() { IsOpen = false; Console.WriteLine("[MaterialEditor] Closed."); }
        public void Update(float dt) { /* preview tick — no-op for now */ }

        public void DrawUI()
        {
            if (!IsOpen || _activeMaterial == null) return;
            Console.WriteLine($"[MaterialEditor] Drawing UI for: {_activeMaterial.Name}");
            Console.WriteLine($"  Metallic={_activeMaterial.Pbr.Metallic:F2}  Roughness={_activeMaterial.Pbr.Roughness:F2}");
        }

        public void OnShortcut(string shortcut)
        {
            if (shortcut == "Ctrl+S") SaveMaterial();
        }

        // ── State ─────────────────────────────────────────────
        private MaterialAsset?             _activeMaterial;
        private readonly List<MaterialAsset> _materials = new();

        // ── Operations ────────────────────────────────────────
        public void OpenMaterial(string materialPath)
        {
            _activeMaterial = new MaterialAsset
            {
                Id   = materialPath,
                Name = System.IO.Path.GetFileName(materialPath)
            };
            Console.WriteLine($"[MaterialEditor] Opened: {_activeMaterial.Name}");
        }

        // PBR channel setters
        public void SetMetallic(float v)  { if (_activeMaterial != null) _activeMaterial.Pbr.Metallic  = Math.Clamp(v, 0f, 1f); }
        public void SetRoughness(float v) { if (_activeMaterial != null) _activeMaterial.Pbr.Roughness = Math.Clamp(v, 0f, 1f); }
        public void SetNormalMap(string path)   { if (_activeMaterial != null) _activeMaterial.Pbr.NormalTexture   = path; }
        public void SetAlbedoMap(string path)   { if (_activeMaterial != null) _activeMaterial.Pbr.AlbedoTexture   = path; }
        public void SetAOMap(string path)       { if (_activeMaterial != null) _activeMaterial.Pbr.AOTexture        = path; }
        public void SetEmissionMap(string path) { if (_activeMaterial != null) _activeMaterial.Pbr.EmissionTexture  = path; }
        public void SetEmissionColor(float r, float g, float b)
        {
            if (_activeMaterial != null) _activeMaterial.Pbr.EmissionColor = new[] { r, g, b };
        }

        public void SetProperty(string name, object value)
        {
            if (_activeMaterial == null) return;
            _activeMaterial.Properties[name] = new MaterialProperty { Name = name, Value = value };
            _activeMaterial.IsModified = true;
        }

        public object? GetProperty(string name)
            => _activeMaterial?.Properties.TryGetValue(name, out var p) == true ? p.Value : null;

        public void AssignShader(string shaderName)
        {
            if (_activeMaterial == null) return;
            _activeMaterial.ShaderName = shaderName;
            Console.WriteLine($"[MaterialEditor] Assigned shader: {shaderName}");
        }

        public void SaveMaterial()
        {
            if (_activeMaterial == null) return;
            _activeMaterial.IsModified = false;
            Console.WriteLine($"[MaterialEditor] Saved: {_activeMaterial.Name}");
        }

        public void ImportMaterial(string path) => OpenMaterial(path);
        public void ExportMaterial(string path) => Console.WriteLine($"[MaterialEditor] Exported to: {path}");
    }
}

