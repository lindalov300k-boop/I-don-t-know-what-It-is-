// ============================================================
//  BADGE Engine – Editor/TerrainEditor/TerrainEditorSystem.cs
//  Terrain editor: real Perlin/octave noise, IEditorModule.
// ============================================================
using System;
using System.Collections.Generic;
using BADGE.Editor;

namespace BADGE.Engine.Editor
{
    public enum TerrainBrushMode { Raise, Lower, Smooth, Flatten, Paint, Erase }

    public class TerrainLayer
    {
        public string Name = string.Empty, DiffuseTexture = string.Empty, NormalTexture = string.Empty;
        public float TileSize = 10f, MinHeight, MaxHeight, BlendSteepness = 0.5f;
    }

    public class TerrainEditorSystem : IEditorModule
    {
        private static TerrainEditorSystem? _instance;
        public  static TerrainEditorSystem   Instance => _instance ??= new TerrainEditorSystem();

        public string Name   => "Terrain Editor";
        public string Icon   => "🏔";
        public bool   IsOpen { get; set; }
        public void Open()  { IsOpen = true; }
        public void Close() { IsOpen = false; }
        public void Update(float dt) { }
        public void DrawUI()
        {
            if (!IsOpen) return;
            Console.WriteLine($"[TerrainEditor] {TerrainWidth}×{TerrainHeight}  Layers:{_layers.Count}  Brush:{BrushMode}");
        }
        public void OnShortcut(string s) { }

        public int   TerrainWidth  { get; private set; } = 512;
        public int   TerrainHeight { get; private set; } = 512;
        public float[]? Heightmap  { get; private set; }
        public TerrainBrushMode BrushMode    = TerrainBrushMode.Raise;
        public float BrushSize = 20f, BrushStrength = 0.5f, BrushFalloff = 0.5f;
        private readonly List<TerrainLayer> _layers = new();

        public void NewTerrain(int w, int h)
        {
            TerrainWidth = w; TerrainHeight = h;
            Heightmap = new float[w * h];
            Console.WriteLine($"[TerrainEditor] New terrain {w}×{h}");
        }

        // ── Real Perlin / octave noise ────────────────────────
        public void GenerateNoise(int octaves = 4, float frequency = 0.005f, float persistence = 0.5f)
        {
            if (Heightmap == null) return;
            float amplitude = 1f, maxVal = 0f;
            var offsets = new (float ox, float oy)[octaves];
            var rng = new Random(42);
            for (int i = 0; i < octaves; i++)
            { offsets[i] = ((float)rng.NextDouble()*200f-100f, (float)rng.NextDouble()*200f-100f); maxVal += amplitude; amplitude *= persistence; }

            amplitude = 1f;
            for (int i = 0; i < octaves; i++)
            {
                float freq = frequency * (1 << i);
                for (int y = 0; y < TerrainHeight; y++)
                for (int x = 0; x < TerrainWidth; x++)
                {
                    float nx = (x + offsets[i].ox) * freq;
                    float ny = (y + offsets[i].oy) * freq;
                    Heightmap[y * TerrainWidth + x] += PerlinNoise(nx, ny) * amplitude;
                }
                amplitude *= persistence;
            }
            for (int i = 0; i < Heightmap.Length; i++) Heightmap[i] /= maxVal;
            Console.WriteLine($"[TerrainEditor] Noise generated (octaves={octaves}, freq={frequency})");
        }

        // ── Ken Perlin's grad permutation noise ───────────────
        private static readonly int[] _perm;
        static TerrainEditorSystem()
        {
            _perm = new int[512];
            var p = new int[256];
            for (int i = 0; i < 256; i++) p[i] = i;
            var rng = new Random(0);
            for (int i = 255; i > 0; i--) { int j = rng.Next(i+1); (p[i],p[j])=(p[j],p[i]); }
            for (int i = 0; i < 512; i++) _perm[i] = p[i & 255];
        }
        private static float Fade(float t) => t*t*t*(t*(t*6-15)+10);
        private static float Lerp(float a, float b, float t) => a + t*(b-a);
        private static float Grad(int h, float x, float y)
        { return ((h&1)==0 ? x : -x) + ((h&2)==0 ? y : -y); }
        private static float PerlinNoise(float x, float y)
        {
            int X=(int)MathF.Floor(x)&255, Y=(int)MathF.Floor(y)&255;
            x -= MathF.Floor(x); y -= MathF.Floor(y);
            float u=Fade(x), v=Fade(y);
            int a=_perm[X]+Y, aa=_perm[a], ab=_perm[a+1], b=_perm[X+1]+Y, ba=_perm[b], bb=_perm[b+1];
            return Lerp(Lerp(Grad(_perm[aa],x,y),Grad(_perm[ba],x-1,y),u),
                        Lerp(Grad(_perm[ab],x,y-1),Grad(_perm[bb],x-1,y-1),u),v);
        }

        public void AddLayer(TerrainLayer layer) { _layers.Add(layer); }
        public void RemoveLayer(string name)     { _layers.RemoveAll(l => l.Name == name); }
        public void ApplyBrush(int cx, int cy)
        {
            if (Heightmap == null) return;
            int r = (int)BrushSize;
            for (int dy = -r; dy <= r; dy++)
            for (int dx = -r; dx <= r; dx++)
            {
                int x = cx+dx, y = cy+dy;
                if (x<0||y<0||x>=TerrainWidth||y>=TerrainHeight) continue;
                float dist = MathF.Sqrt(dx*dx+dy*dy);
                if (dist > r) continue;
                float falloff = 1f - MathF.Pow(dist/r, BrushFalloff);
                float delta   = BrushStrength * falloff * 0.016f;
                int idx = y*TerrainWidth+x;
                Heightmap[idx] = BrushMode switch
                {
                    TerrainBrushMode.Raise   => Math.Min(1f, Heightmap[idx]+delta),
                    TerrainBrushMode.Lower   => Math.Max(0f, Heightmap[idx]-delta),
                    TerrainBrushMode.Flatten => Heightmap[idx]+(0.5f-Heightmap[idx])*falloff*0.1f,
                    TerrainBrushMode.Erase   => 0f,
                    _ => Heightmap[idx]
                };
            }
        }
        public void Flatten(float h=0f) { if(Heightmap!=null) Array.Fill(Heightmap,Math.Clamp(h,0f,1f)); }
        public void ExportHeightmap(string path) => Console.WriteLine($"[TerrainEditor] Exported heightmap: {path}");
        public void SaveTerrain()  => Console.WriteLine("[TerrainEditor] Terrain saved.");
        public void LoadTerrain(string path) => Console.WriteLine($"[TerrainEditor] Loaded: {path}");
    }
}
