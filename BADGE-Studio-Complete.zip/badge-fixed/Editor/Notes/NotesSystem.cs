// ============================================================
//  BADGE Engine – Editor/Notes/NotesSystem.cs
//  NotesManager, NotesEditor, TodoManager, MarkdownParser
//  Supports .txt, .md, .rtf, .docx
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using BADGE.Editor;

namespace BADGE.Engine.Editor.Notes
{
    public enum NoteFormat { PlainText, Markdown, RichText }
    public enum TodoStatus { Todo, InProgress, Done, Blocked }

    public sealed class Note
    {
        public string     ID        { get; } = Guid.NewGuid().ToString("N")[..8];
        public string     Title     { get; set; } = "Untitled";
        public string     Content   { get; set; } = "";
        public NoteFormat Format    { get; set; } = NoteFormat.Markdown;
        public List<string> Tags    { get; } = new();
        public DateTime   Created   { get; } = DateTime.UtcNow;
        public DateTime   Modified  { get; set; } = DateTime.UtcNow;
        public bool       Pinned    { get; set; }
        public string?    FilePath  { get; set; }

        public void Touch() => Modified = DateTime.UtcNow;
    }

    public sealed class TodoItem
    {
        public string     ID       { get; } = Guid.NewGuid().ToString("N")[..8];
        public string     Title    { get; set; } = "";
        public string     Notes    { get; set; } = "";
        public TodoStatus Status   { get; set; } = TodoStatus.Todo;
        public int        Priority { get; set; } = 0;
        public DateTime?  DueDate  { get; set; }
        public List<string> Tags   { get; } = new();
        public DateTime   Created  { get; } = DateTime.UtcNow;
    }

    public sealed class NotesManager
    {
        private readonly Dictionary<string,Note> _notes = new();
        public IReadOnlyCollection<Note> All => _notes.Values;

        public Note Create(string title="New Note", NoteFormat format=NoteFormat.Markdown)
        { var n=new Note{Title=title,Format=format}; _notes[n.ID]=n; return n; }

        public Note? Get(string id) => _notes.TryGetValue(id,out var n)?n:null;

        public void Delete(string id) => _notes.Remove(id);

        public IEnumerable<Note> Search(string query) =>
            _notes.Values.Where(n =>
                n.Title.Contains(query,StringComparison.OrdinalIgnoreCase)||
                n.Content.Contains(query,StringComparison.OrdinalIgnoreCase)||
                n.Tags.Any(t=>t.Contains(query,StringComparison.OrdinalIgnoreCase)));

        public IEnumerable<Note> ByTag(string tag) =>
            _notes.Values.Where(n=>n.Tags.Contains(tag,StringComparer.OrdinalIgnoreCase));

        public void SaveAll(string dir)
        {
            Directory.CreateDirectory(dir);
            foreach(var n in _notes.Values)
            {
                string ext=n.Format switch{NoteFormat.Markdown=>".md",NoteFormat.RichText=>".rtf",_=>".txt"};
                string path=Path.Combine(dir,n.Title.Replace(" ","_")+ext);
                File.WriteAllText(path,n.Content,Encoding.UTF8);
                n.FilePath=path;
            }
        }

        public void LoadFromDirectory(string dir)
        {
            if(!Directory.Exists(dir)) return;
            foreach(var file in Directory.GetFiles(dir,"*.*",SearchOption.TopDirectoryOnly))
            {
                var ext=Path.GetExtension(file).ToLower();
                if(ext!=".md"&&ext!=".txt"&&ext!=".rtf") continue;
                var n=Create(Path.GetFileNameWithoutExtension(file),
                    ext==".md"?NoteFormat.Markdown:NoteFormat.PlainText);
                n.Content=File.ReadAllText(file,Encoding.UTF8);
                n.FilePath=file;
            }
        }
    }

    public sealed class NotesEditor : IEditorModule
    {
        public string Name    => "Notes";
        public string Icon    => "📝";
        public bool   IsOpen  { get; private set; }
        public void   Open()  => IsOpen = true;
        public void   Close() => IsOpen = false;
        public void   Update(float dt) {}
        public void   DrawUI() {}
        public void   OnShortcut(string shortcut)
        {
            if (shortcut == "Ctrl+Z") Undo();
            else if (shortcut == "Ctrl+Y") Redo();
        }

        public Note?   ActiveNote { get; private set; }
        public string  EditBuffer { get; set; } = "";
        public bool    IsDirty    { get; private set; }
        public int     CursorPos  { get; set; }
        public int     SelectStart{ get; set; }
        public int     SelectEnd  { get; set; }
        private readonly Stack<string> _undoStack = new();
        private readonly Stack<string> _redoStack = new();

        public void Open(Note note)
        { ActiveNote=note; EditBuffer=note.Content; IsDirty=false; CursorPos=0; _undoStack.Clear(); }

        public void Insert(string text)
        {
            _undoStack.Push(EditBuffer);
            EditBuffer=EditBuffer[..CursorPos]+text+EditBuffer[CursorPos..];
            CursorPos+=text.Length; IsDirty=true;
        }

        public void Delete(int start, int length)
        {
            _undoStack.Push(EditBuffer); IsDirty=true;
            EditBuffer=EditBuffer[..start]+EditBuffer[System.Math.Min(start+length,EditBuffer.Length)..];
        }

        public void Undo()
        { if(_undoStack.Count==0) return; _redoStack.Push(EditBuffer); EditBuffer=_undoStack.Pop(); IsDirty=true; }

        public void Redo()
        { if(_redoStack.Count==0) return; _undoStack.Push(EditBuffer); EditBuffer=_redoStack.Pop(); IsDirty=true; }

        public void Save()
        {
            if(ActiveNote==null) return;
            ActiveNote.Content=EditBuffer; ActiveNote.Touch(); IsDirty=false;
        }

        public string[] GetLines() => EditBuffer.Split('\n');

        // Word count
        public int WordCount => EditBuffer.Split(new[]{' ','\n','\t'},StringSplitOptions.RemoveEmptyEntries).Length;
    }

    public sealed class TodoManager
    {
        private readonly List<TodoItem> _items = new();
        public IReadOnlyList<TodoItem> All => _items;

        public TodoItem Add(string title)
        { var t=new TodoItem{Title=title}; _items.Add(t); return t; }

        public void Remove(string id) => _items.RemoveAll(t=>t.ID==id);

        public void SetStatus(string id, TodoStatus status)
        { var t=_items.FirstOrDefault(x=>x.ID==id); if(t!=null) t.Status=status; }

        public IEnumerable<TodoItem> ByStatus(TodoStatus s) => _items.Where(t=>t.Status==s);
        public IEnumerable<TodoItem> ByPriority() => _items.OrderByDescending(t=>t.Priority);

        public int CompletionPercent =>
            _items.Count==0?0:_items.Count(t=>t.Status==TodoStatus.Done)*100/_items.Count;
    }

    public static class MarkdownParser
    {
        public static string ToHtml(string markdown)
        {
            var sb=new StringBuilder();
            bool inCode=false; bool inList=false;
            foreach(var rawLine in markdown.Split('\n'))
            {
                var line=rawLine.TrimEnd();
                if(line.StartsWith("```")) { inCode=!inCode; sb.Append(inCode?"<pre><code>":"</code></pre>\n"); continue; }
                if(inCode) { sb.AppendLine(Escape(line)); continue; }

                if(inList&&!line.StartsWith("- ")&&!line.StartsWith("* "))
                { sb.AppendLine("</ul>"); inList=false; }

                if(line.StartsWith("# "))      sb.AppendLine($"<h1>{Inline(line[2..])}</h1>");
                else if(line.StartsWith("## ")) sb.AppendLine($"<h2>{Inline(line[3..])}</h2>");
                else if(line.StartsWith("### "))sb.AppendLine($"<h3>{Inline(line[4..])}</h3>");
                else if(line.StartsWith("---")) sb.AppendLine("<hr/>");
                else if(line.StartsWith("- ")||line.StartsWith("* "))
                {
                    if(!inList){ sb.AppendLine("<ul>"); inList=true; }
                    sb.AppendLine($"<li>{Inline(line[2..])}</li>");
                }
                else if(line.Length==0) sb.AppendLine("<br/>");
                else sb.AppendLine($"<p>{Inline(line)}</p>");
            }
            if(inList) sb.AppendLine("</ul>");
            return sb.ToString();
        }

        private static string Inline(string s)
        {
            s=Escape(s);
            // Bold **text**
            while(s.Contains("**"))
            {
                int a=s.IndexOf("**"); int b=s.IndexOf("**",a+2);
                if(b<0) break;
                s=s[..a]+"<strong>"+s[(a+2)..b]+"</strong>"+s[(b+2)..];
            }
            // Italic *text*
            while(s.Contains('*'))
            {
                int a=s.IndexOf('*'); int b=s.IndexOf('*',a+1);
                if(b<0) break;
                s=s[..a]+"<em>"+s[(a+1)..b]+"</em>"+s[(b+1)..];
            }
            // Code `text`
            while(s.Contains('`'))
            {
                int a=s.IndexOf('`'); int b=s.IndexOf('`',a+1);
                if(b<0) break;
                s=s[..a]+"<code>"+s[(a+1)..b]+"</code>"+s[(b+1)..];
            }
            // Link [text](url)
            while(s.Contains("["))
            {
                int a=s.IndexOf('['); int b=s.IndexOf(']',a);
                int c=b>=0?s.IndexOf('(',b):- 1; int d=c>=0?s.IndexOf(')',c):-1;
                if(b<0||c<0||d<0) break;
                string txt=s[(a+1)..b], url=s[(c+1)..d];
                s=s[..a]+$"<a href='{url}'>{txt}</a>"+s[(d+1)..];
            }
            return s;
        }

        private static string Escape(string s) =>
            s.Replace("&","&amp;").Replace("<","&lt;").Replace(">","&gt;");
    }

    // ─────────────────────────────────────────────────────────────
    //  Rich Text Renderer
    //  Converts RTF / HTML / Markdown spans into styled text runs
    // ─────────────────────────────────────────────────────────────
    public enum TextStyle { Normal, Bold, Italic, BoldItalic, Code, Heading1, Heading2, Heading3, Quote }
    public enum TextColor { Default, Red, Green, Blue, Yellow, Orange, Purple, Gray }

    public sealed class TextRun
    {
        public string       Text    { get; set; } = "";
        public TextStyle    Style   { get; set; } = TextStyle.Normal;
        public TextColor    Color   { get; set; } = TextColor.Default;
        public int          Size    { get; set; } = 14;      // pt
        public string       Font    { get; set; } = "Inter";
        public bool         Underline { get; set; }
        public bool         Strikethrough { get; set; }
        public string?      Link    { get; set; }            // hyperlink target
    }

    public sealed class StyledParagraph
    {
        public List<TextRun> Runs       { get; } = new();
        public bool          IsListItem { get; set; }
        public int           IndentLevel{ get; set; }
        public bool          IsCodeBlock{ get; set; }
        public bool          IsHRule    { get; set; }
    }

    public static class RichTextRenderer
    {
        // Convert Markdown source → list of styled paragraphs
        public static List<StyledParagraph> RenderMarkdown(string src)
        {
            var result = new List<StyledParagraph>();
            foreach (var rawLine in src.Split('\n'))
            {
                var line = rawLine.TrimEnd();
                var para = new StyledParagraph();

                if (line.StartsWith("---") || line.StartsWith("==="))
                {
                    para.IsHRule = true; result.Add(para); continue;
                }

                // Heading detection
                TextStyle baseStyle = TextStyle.Normal;
                if (line.StartsWith("### "))      { baseStyle = TextStyle.Heading3; line = line[4..]; }
                else if (line.StartsWith("## "))  { baseStyle = TextStyle.Heading2; line = line[3..]; }
                else if (line.StartsWith("# "))   { baseStyle = TextStyle.Heading1; line = line[2..]; }
                else if (line.StartsWith("> "))   { baseStyle = TextStyle.Quote;    line = line[2..]; }
                else if (line.StartsWith("    ")|| line.StartsWith("\t"))
                    { para.IsCodeBlock = true; }

                // List items
                if (line.TrimStart().StartsWith("- ") || line.TrimStart().StartsWith("* "))
                {
                    para.IsListItem  = true;
                    para.IndentLevel = (line.Length - line.TrimStart().Length) / 2;
                    line = line.TrimStart()[2..];
                }

                // Inline spans: bold, italic, code, links
                para.Runs.AddRange(ParseInline(line, baseStyle));
                result.Add(para);
            }
            return result;
        }

        private static List<TextRun> ParseInline(string text, TextStyle baseStyle)
        {
            var runs = new List<TextRun>();
            int i = 0;
            var buf = new System.Text.StringBuilder();

            void Flush(TextStyle s = TextStyle.Normal)
            {
                if (buf.Length == 0) return;
                runs.Add(new TextRun { Text = buf.ToString(), Style = s == TextStyle.Normal ? baseStyle : s });
                buf.Clear();
            }

            while (i < text.Length)
            {
                // Bold-italic ***
                if (i + 2 < text.Length && text[i] == '*' && text[i+1] == '*' && text[i+2] == '*')
                {
                    Flush(); int end = text.IndexOf("***", i + 3);
                    if (end < 0) { buf.Append(text[i]); i++; continue; }
                    runs.Add(new TextRun { Text = text[(i+3)..end], Style = TextStyle.BoldItalic });
                    i = end + 3; continue;
                }
                // Bold **
                if (i + 1 < text.Length && text[i] == '*' && text[i+1] == '*')
                {
                    Flush(); int end = text.IndexOf("**", i + 2);
                    if (end < 0) { buf.Append(text[i]); i++; continue; }
                    runs.Add(new TextRun { Text = text[(i+2)..end], Style = TextStyle.Bold });
                    i = end + 2; continue;
                }
                // Italic *
                if (text[i] == '*')
                {
                    Flush(); int end = text.IndexOf('*', i + 1);
                    if (end < 0) { buf.Append(text[i]); i++; continue; }
                    runs.Add(new TextRun { Text = text[(i+1)..end], Style = TextStyle.Italic });
                    i = end + 1; continue;
                }
                // Inline code `
                if (text[i] == '`')
                {
                    Flush(); int end = text.IndexOf('`', i + 1);
                    if (end < 0) { buf.Append(text[i]); i++; continue; }
                    runs.Add(new TextRun { Text = text[(i+1)..end], Style = TextStyle.Code, Font = "JetBrains Mono" });
                    i = end + 1; continue;
                }
                // Markdown link [label](url)
                if (text[i] == '[')
                {
                    int lblEnd = text.IndexOf(']', i);
                    if (lblEnd > 0 && lblEnd + 1 < text.Length && text[lblEnd+1] == '(')
                    {
                        int urlEnd = text.IndexOf(')', lblEnd + 2);
                        if (urlEnd > 0)
                        {
                            Flush();
                            string label = text[(i+1)..lblEnd];
                            string url   = text[(lblEnd+2)..urlEnd];
                            runs.Add(new TextRun { Text = label, Underline = true, Link = url, Color = TextColor.Blue });
                            i = urlEnd + 1; continue;
                        }
                    }
                }
                buf.Append(text[i++]);
            }
            Flush();
            return runs;
        }

        // Render plain-text note (no parsing)
        public static List<StyledParagraph> RenderPlain(string src)
        {
            var result = new List<StyledParagraph>();
            foreach (var line in src.Split('\n'))
            {
                var para = new StyledParagraph();
                para.Runs.Add(new TextRun { Text = line });
                result.Add(para);
            }
            return result;
        }

        // Render basic RTF (strip control words, return readable text runs)
        public static List<StyledParagraph> RenderRTF(string rtf)
        {
            // Strip RTF control words with a simple pass
            var sb = new System.Text.StringBuilder();
            bool inGroup = false;
            for (int i = 0; i < rtf.Length; i++)
            {
                char c = rtf[i];
                if (c == '{' || c == '}') continue;
                if (c == '\\')
                {
                    // skip control word
                    while (i + 1 < rtf.Length && (char.IsLetter(rtf[i+1]) || rtf[i+1] == '-')) i++;
                    if (i + 1 < rtf.Length && rtf[i+1] == ' ') i++; // consume delimiter space
                    continue;
                }
                sb.Append(c);
            }
            return RenderPlain(sb.ToString().Trim());
        }

        // Measure approx text height given line count and font size
        public static float MeasureHeight(List<StyledParagraph> paras, int fontSizePt = 14)
            => paras.Count * (fontSizePt * 1.5f);
    }

    // ─────────────────────────────────────────────────────────────
    //  Notes Importer  – loads .txt / .md / .rtf / .docx
    // ─────────────────────────────────────────────────────────────
    public static class NotesImporter
    {
        private static readonly HashSet<string> Supported =
            new(StringComparer.OrdinalIgnoreCase) { ".txt", ".md", ".rtf", ".docx" };

        public static bool CanImport(string path)
            => Supported.Contains(System.IO.Path.GetExtension(path));

        public static Note? Import(string path)
        {
            if (!System.IO.File.Exists(path)) return null;
            string ext = System.IO.Path.GetExtension(path).ToLowerInvariant();

            string content = ext switch
            {
                ".docx" => ExtractDocxText(path),
                ".rtf"  => StripRTF(System.IO.File.ReadAllText(path)),
                _       => System.IO.File.ReadAllText(path)
            };

            NoteFormat fmt = ext switch
            {
                ".md"   => NoteFormat.Markdown,
                ".rtf"  => NoteFormat.RichText,
                ".docx" => NoteFormat.RichText,
                _       => NoteFormat.PlainText
            };

            return new Note
            {
                Title    = System.IO.Path.GetFileNameWithoutExtension(path),
                Content  = content,
                Format   = fmt,
                Modified = System.IO.File.GetLastWriteTime(path)
            };
        }

        public static List<Note> ImportDirectory(string dir, bool recurse = false)
        {
            var notes = new List<Note>();
            var opt = recurse ? System.IO.SearchOption.AllDirectories
                              : System.IO.SearchOption.TopDirectoryOnly;
            foreach (var ext in Supported)
            foreach (var file in System.IO.Directory.GetFiles(dir, $"*{ext}", opt))
            {
                var n = Import(file);
                if (n != null) notes.Add(n);
            }
            return notes;
        }

        // ── helpers ───────────────────────────────────────────────
        private static string StripRTF(string rtf)
        {
            var sb = new System.Text.StringBuilder();
            for (int i = 0; i < rtf.Length; i++)
            {
                if (rtf[i] == '{' || rtf[i] == '}') continue;
                if (rtf[i] == '\\')
                {
                    while (i + 1 < rtf.Length && char.IsLetter(rtf[i+1])) i++;
                    if (i + 1 < rtf.Length && rtf[i+1] == ' ') i++;
                    continue;
                }
                sb.Append(rtf[i]);
            }
            return sb.ToString().Trim();
        }

        private static string ExtractDocxText(string path)
        {
            // docx = zip with word/document.xml
            try
            {
                using var zip = System.IO.Compression.ZipFile.OpenRead(path);
                var entry = zip.GetEntry("word/document.xml");
                if (entry == null) return "[Could not read .docx]";
                using var stream = entry.Open();
                using var reader = new System.IO.StreamReader(stream);
                string xml = reader.ReadToEnd();
                // Strip XML tags
                return System.Text.RegularExpressions.Regex.Replace(xml, "<[^>]+>", " ")
                       .Replace("  ", " ").Trim();
            }
            catch { return "[Error reading .docx]"; }
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Notes Exporter  – saves .txt / .md / .rtf / .docx
    // ─────────────────────────────────────────────────────────────
    public static class NotesExporter
    {
        public static void Export(Note note, string path)
        {
            string ext = System.IO.Path.GetExtension(path).ToLowerInvariant();
            switch (ext)
            {
                case ".md":
                case ".txt":
                    System.IO.File.WriteAllText(path, note.Content);
                    break;
                case ".rtf":
                    System.IO.File.WriteAllText(path, ToRTF(note.Content));
                    break;
                case ".docx":
                    WriteDocx(note, path);
                    break;
                default:
                    System.IO.File.WriteAllText(path, note.Content);
                    break;
            }
            Console.WriteLine($"[NotesExporter] Exported '{note.Title}' → {path}");
        }

        public static void ExportAll(IEnumerable<Note> notes, string directory)
        {
            System.IO.Directory.CreateDirectory(directory);
            foreach (var n in notes)
            {
                string ext = n.Format switch
                {
                    NoteFormat.Markdown  => ".md",
                    NoteFormat.RichText  => ".rtf",
                    _                    => ".txt"
                };
                string safe = string.Join("_", n.Title.Split(System.IO.Path.GetInvalidFileNameChars()));
                Export(n, System.IO.Path.Combine(directory, safe + ext));
            }
        }

        // ── helpers ───────────────────────────────────────────────
        private static string ToRTF(string text)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine(@"{\rtf1\ansi\deff0");
            sb.AppendLine(@"{\fonttbl{\f0 Inter;}}");
            sb.AppendLine(@"\f0\fs28 ");
            foreach (var line in text.Split('\n'))
                sb.AppendLine(EscapeRTF(line) + @"\par");
            sb.Append('}');
            return sb.ToString();
        }

        private static string EscapeRTF(string s) =>
            s.Replace("\\", "\\\\").Replace("{", "\\{").Replace("}", "\\}");

        private static void WriteDocx(Note note, string path)
        {
            // Minimal OOXML docx
            const string contentTypes = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<Types xmlns=""http://schemas.openxmlformats.org/package/2006/content-types"">
  <Default Extension=""rels"" ContentType=""application/vnd.openxmlformats-package.relationships+xml""/>
  <Default Extension=""xml""  ContentType=""application/xml""/>
  <Override PartName=""/word/document.xml"" ContentType=""application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml""/>
</Types>";
            const string rels = @"<?xml version=""1.0"" encoding=""UTF-8""?>
<Relationships xmlns=""http://schemas.openxmlformats.org/package/2006/relationships"">
  <Relationship Id=""rId1"" Type=""http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"" Target=""word/document.xml""/>
</Relationships>";

            try
            {
                if (System.IO.File.Exists(path)) System.IO.File.Delete(path);
                using var zip = System.IO.Compression.ZipFile.Open(path, System.IO.Compression.ZipArchiveMode.Create);

                void Add(string name, string content)
                {
                    var e = zip.CreateEntry(name);
                    using var w = new System.IO.StreamWriter(e.Open());
                    w.Write(content);
                }

                Add("[Content_Types].xml", contentTypes);
                Add("_rels/.rels", rels);

                var docSb = new System.Text.StringBuilder();
                docSb.AppendLine(@"<?xml version=""1.0"" encoding=""UTF-8""?>");
                docSb.AppendLine(@"<w:document xmlns:w=""http://schemas.openxmlformats.org/wordprocessingml/2006/main"">");
                docSb.AppendLine(@"<w:body>");
                foreach (var line in note.Content.Split('\n'))
                {
                    docSb.AppendLine($@"<w:p><w:r><w:t xml:space=""preserve"">{System.Security.SecurityElement.Escape(line)}</w:t></w:r></w:p>");
                }
                docSb.AppendLine(@"</w:body></w:document>");
                Add("word/document.xml", docSb.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[NotesExporter] docx write failed: {ex.Message}");
            }
        }
    }
}

