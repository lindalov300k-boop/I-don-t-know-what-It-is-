// BADGE Engine – Scripting/ScriptRuntime.cs
// C# hot-reload scripting via dotnet CLI subprocess compilation
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using BADGE.Engine.Core;
using BADGE.Runtime;

namespace BADGE.Engine.Scripting
{
    public sealed class ScriptRuntime
    {
        private readonly Dictionary<string, CompiledScript> _scripts = new();
        private readonly List<IScript> _active = new();
        private FileSystemWatcher? _watcher;

        public bool HotReloadEnabled { get; set; } = true;
        public string ScriptsPath    { get; set; } = "Scripts";

        public event Action<string>? OnScriptReloaded;
        public event Action<string, string>? OnCompileError;

        public void Initialize()
        {
            if(!Directory.Exists(ScriptsPath)) Directory.CreateDirectory(ScriptsPath);
            if(HotReloadEnabled) WatchDirectory();
            Console.WriteLine("[Scripts] Runtime initialized (dotnet-CLI hot-reload)");
        }

        public bool Compile(string name, string source)
        {
            // Write source to temp project and compile with dotnet CLI
            var tmpDir = Path.Combine(Path.GetTempPath(), $"BADGE_Script_{name}_{Guid.NewGuid():N}");
            Directory.CreateDirectory(tmpDir);
            try
            {
                // Write source file
                File.WriteAllText(Path.Combine(tmpDir, $"{name}.cs"), source);
                // Write minimal csproj
                File.WriteAllText(Path.Combine(tmpDir, $"{name}.csproj"),
                    "<Project Sdk=\"Microsoft.NET.Sdk\"><PropertyGroup>" +
                    "<OutputType>Library</OutputType><TargetFramework>net8.0</TargetFramework>" +
                    "</PropertyGroup></Project>");

                var psi = new ProcessStartInfo("dotnet", $"build \"{Path.Combine(tmpDir, $"{name}.csproj")}\" -o \"{tmpDir}/out\" --nologo -v q")
                {
                    RedirectStandardOutput = true, RedirectStandardError = true,
                    UseShellExecute = false, CreateNoWindow = true
                };
                using var proc = Process.Start(psi);
                if (proc == null) { OnCompileError?.Invoke(name, "dotnet not found"); return false; }
                string stderr = proc.StandardError.ReadToEnd();
                proc.WaitForExit();

                if (proc.ExitCode != 0)
                {
                    OnCompileError?.Invoke(name, stderr);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"[Scripts] Compile error in '{name}':\n{stderr}");
                    Console.ResetColor();
                    return false;
                }

                var dllPath = Path.Combine(tmpDir, "out", $"{name}.dll");
                if (!File.Exists(dllPath)) { OnCompileError?.Invoke(name, "DLL not produced"); return false; }

                var asm = Assembly.LoadFile(dllPath);
                _scripts[name] = new CompiledScript(name, source, asm);
                Console.WriteLine($"[Scripts] Compiled: {name}");
                return true;
            }
            catch (Exception ex)
            {
                OnCompileError?.Invoke(name, ex.Message);
                return false;
            }
        }

        public bool CompileFile(string path)
        {
            if(!File.Exists(path)) return false;
            return Compile(Path.GetFileNameWithoutExtension(path), File.ReadAllText(path));
        }

        public IScript? Instantiate(string name)
        {
            if(!_scripts.TryGetValue(name, out var cs)) return null;
            foreach(var t in cs.Assembly.GetTypes())
                if(typeof(IScript).IsAssignableFrom(t) && !t.IsInterface)
                {
                    var inst = (IScript)Activator.CreateInstance(t)!;
                    _active.Add(inst);
                    inst.OnStart();
                    return inst;
                }
            return null;
        }

        public void Update(float dt)
        {
            foreach(var s in _active) s.OnUpdate(dt);
        }

        private void WatchDirectory()
        {
            if (!Directory.Exists(ScriptsPath)) return;
            _watcher = new FileSystemWatcher(ScriptsPath, "*.cs")
                { NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName, EnableRaisingEvents = true };
            _watcher.Changed += (_, e) =>
            {
                Console.WriteLine($"[Scripts] Hot-reload: {e.Name}");
                if(CompileFile(e.FullPath))
                    OnScriptReloaded?.Invoke(e.Name!);
            };
        }

        public void Shutdown()
        {
            _watcher?.Dispose();
            _active.Clear();
        }
    }

    public sealed class CompiledScript
    {
        public string Name      { get; }
        public string Source    { get; }
        public Assembly Assembly{ get; }
        public CompiledScript(string n, string s, Assembly a){Name=n;Source=s;Assembly=a;}
    }

    public interface IScript
    {
        void OnStart();
        void OnUpdate(float dt);
        void OnDestroy();
    }

    // Base class for user scripts (MonoBehaviour equivalent)
    public abstract class ScriptBehaviour : Components.Component, IScript
    {
        void IScript.OnStart()         => OnStart();
        void IScript.OnUpdate(float dt) => OnUpdate(dt);
        void IScript.OnDestroy()        => OnDestroy();
        public virtual void OnStart()  { }
        public virtual void OnUpdate(float dt) { }
        public virtual new void OnDestroy() { }
    }

    // ─── Script Compiler ─────────────────────────────────────
    /// <summary>
    /// Standalone compiler front-end. Wraps the dotnet CLI, provides
    /// syntax validation, assembly management, and diagnostic reporting.
    /// </summary>
    public sealed class ScriptCompiler
    {
        public string OutputDirectory { get; set; } = Path.Combine(Path.GetTempPath(), "BADGE_Scripts");
        public string TargetFramework { get; set; } = "net8.0";
        public bool   OptimizeRelease { get; set; }

        public event Action<CompileDiagnostic>? OnDiagnostic;

        public CompileResult Compile(string name, string source)
        {
            Directory.CreateDirectory(OutputDirectory);
            var tmpDir = Path.Combine(OutputDirectory, $"{name}_{Guid.NewGuid():N}");
            Directory.CreateDirectory(tmpDir);

            try
            {
                File.WriteAllText(Path.Combine(tmpDir, $"{name}.cs"), source);
                File.WriteAllText(Path.Combine(tmpDir, $"{name}.csproj"),
                    $"<Project Sdk=\"Microsoft.NET.Sdk\"><PropertyGroup>" +
                    $"<OutputType>Library</OutputType><TargetFramework>{TargetFramework}</TargetFramework>" +
                    (OptimizeRelease ? "<Optimize>true</Optimize>" : "") +
                    "</PropertyGroup></Project>");

                var args = $"build \"{Path.Combine(tmpDir, $"{name}.csproj")}\" " +
                           $"-o \"{Path.Combine(tmpDir, "out")}\" --nologo -v q";
                var psi = new ProcessStartInfo("dotnet", args)
                {
                    RedirectStandardOutput = true,
                    RedirectStandardError  = true,
                    UseShellExecute        = false,
                    CreateNoWindow         = true
                };

                using var proc = Process.Start(psi);
                if (proc == null)
                    return CompileResult.Failure(name, "dotnet CLI not found.");

                string stdout = proc.StandardOutput.ReadToEnd();
                string stderr = proc.StandardError.ReadToEnd();
                proc.WaitForExit();

                var diagnostics = ParseDiagnostics(name, stderr + stdout);
                foreach (var d in diagnostics) OnDiagnostic?.Invoke(d);

                if (proc.ExitCode != 0)
                    return CompileResult.Failure(name, stderr, diagnostics);

                var dllPath = Path.Combine(tmpDir, "out", $"{name}.dll");
                if (!File.Exists(dllPath))
                    return CompileResult.Failure(name, "DLL not produced.");

                var asm = Assembly.LoadFile(dllPath);
                return CompileResult.Success(name, source, asm, diagnostics);
            }
            catch (Exception ex)
            {
                return CompileResult.Failure(name, ex.Message);
            }
        }

        public CompileResult CompileFile(string filePath)
        {
            if (!File.Exists(filePath))
                return CompileResult.Failure(filePath, "File not found.");
            return Compile(Path.GetFileNameWithoutExtension(filePath), File.ReadAllText(filePath));
        }

        private static List<CompileDiagnostic> ParseDiagnostics(string source, string output)
        {
            var list = new List<CompileDiagnostic>();
            foreach (var line in output.Split('\n'))
            {
                var trimmed = line.Trim();
                if (trimmed.Contains(": error "))
                    list.Add(new CompileDiagnostic(source, DiagnosticSeverity.Error, trimmed));
                else if (trimmed.Contains(": warning "))
                    list.Add(new CompileDiagnostic(source, DiagnosticSeverity.Warning, trimmed));
            }
            return list;
        }
    }

    public sealed class CompileResult
    {
        public string                  Name        { get; }
        public bool                    IsSuccess   { get; }
        public string?                 Source      { get; }
        public Assembly?               Assembly    { get; }
        public string                  ErrorMessage{ get; }
        public List<CompileDiagnostic> Diagnostics { get; }

        private CompileResult(string name, bool ok, string? src, Assembly? asm, string err, List<CompileDiagnostic> diags)
        { Name=name; IsSuccess=ok; Source=src; Assembly=asm; ErrorMessage=err; Diagnostics=diags; }

        public static CompileResult Success(string n, string src, Assembly asm, List<CompileDiagnostic> diags) =>
            new(n, true, src, asm, "", diags);
        public static CompileResult Failure(string n, string err, List<CompileDiagnostic>? diags = null) =>
            new(n, false, null, null, err, diags ?? new());
    }

    public sealed class CompileDiagnostic
    {
        public string             Source   { get; }
        public DiagnosticSeverity Severity { get; }
        public string             Message  { get; }
        public CompileDiagnostic(string src, DiagnosticSeverity sev, string msg)
        { Source=src; Severity=sev; Message=msg; }
        public override string ToString() => $"[{Severity}] {Source}: {Message}";
    }

    public enum DiagnosticSeverity { Info, Warning, Error }

    // ─── Hot Reload ──────────────────────────────────────────
    /// <summary>
    /// Watches script directories and triggers recompilation + live
    /// component swap when source files are modified.
    /// </summary>
    public sealed class HotReload : IDisposable
    {
        private readonly ScriptCompiler           _compiler;
        private readonly ScriptRuntime            _runtime;
        private readonly List<FileSystemWatcher>  _watchers   = new();
        private readonly Dictionary<string, DateTime> _lastCompile = new();
        private          bool                     _enabled;
        private const    double                   DebounceMs = 300;

        public event Action<string>?       OnReloaded;
        public event Action<string,string>? OnReloadFailed;

        public HotReload(ScriptCompiler compiler, ScriptRuntime runtime)
        { _compiler = compiler; _runtime = runtime; }

        public bool Enabled
        {
            get => _enabled;
            set
            {
                if (_enabled == value) return;
                _enabled = value;
                if (!_enabled) StopAll();
            }
        }

        public void Watch(string directory, string filter = "*.cs")
        {
            if (!Directory.Exists(directory)) Directory.CreateDirectory(directory);
            var w = new FileSystemWatcher(directory, filter)
            {
                NotifyFilter        = NotifyFilters.LastWrite | NotifyFilters.FileName,
                EnableRaisingEvents = true,
                IncludeSubdirectories = true
            };
            w.Changed += OnChanged;
            w.Created += OnChanged;
            _watchers.Add(w);
            Console.WriteLine($"[HotReload] Watching: {directory}");
        }

        private void OnChanged(object _, FileSystemEventArgs e)
        {
            if (!Enabled) return;
            var now = DateTime.UtcNow;
            if (_lastCompile.TryGetValue(e.FullPath, out var last) &&
                (now - last).TotalMilliseconds < DebounceMs) return;
            _lastCompile[e.FullPath] = now;

            Console.WriteLine($"[HotReload] Detected change: {e.Name}");
            var result = _compiler.CompileFile(e.FullPath);
            if (result.IsSuccess)
            {
                OnReloaded?.Invoke(e.Name!);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"[HotReload] ✓ Reloaded: {e.Name}");
                Console.ResetColor();
            }
            else
            {
                OnReloadFailed?.Invoke(e.Name!, result.ErrorMessage);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"[HotReload] ✗ Failed: {e.Name}\n{result.ErrorMessage}");
                Console.ResetColor();
            }
        }

        private void StopAll() { foreach (var w in _watchers) w.EnableRaisingEvents = false; }

        public void Dispose()
        {
            foreach (var w in _watchers) { w.EnableRaisingEvents = false; w.Dispose(); }
            _watchers.Clear();
        }
    }

    // ─── Script Debugger ─────────────────────────────────────
    public sealed class ScriptDebugger
    {
        private readonly Dictionary<string, HashSet<int>>          _breakpoints = new();
        private readonly List<DebugFrame>                           _callStack   = new();
        private readonly Dictionary<string, object>                 _watchedVars = new();
        private          bool                                       _paused;
        private          string                                     _pauseReason = "";

        public bool         IsPaused        => _paused;
        public string       PauseReason     => _pauseReason;
        public IReadOnlyList<DebugFrame> CallStack => _callStack;
        public IReadOnlyDictionary<string, object> WatchedVariables => _watchedVars;

        public event Action<string, int>?  OnBreakpointHit;
        public event Action?               OnResumed;
        public event Action<Exception>?    OnException;

        public void SetBreakpoint(string file, int line)
        {
            if (!_breakpoints.ContainsKey(file)) _breakpoints[file] = new HashSet<int>();
            _breakpoints[file].Add(line);
            Console.WriteLine($"[Debugger] Breakpoint set: {file}:{line}");
        }

        public void RemoveBreakpoint(string file, int line) =>
            _breakpoints.GetValueOrDefault(file)?.Remove(line);

        public void ClearBreakpoints(string? file = null)
        {
            if (file == null) _breakpoints.Clear();
            else _breakpoints.Remove(file);
        }

        public bool CheckBreakpoint(string file, int line)
        {
            if (_breakpoints.TryGetValue(file, out var lines) && lines.Contains(line))
            {
                Pause($"Breakpoint at {file}:{line}");
                OnBreakpointHit?.Invoke(file, line);
                return true;
            }
            return false;
        }

        public void Pause(string reason = "Manual pause")
        {
            _paused = true;
            _pauseReason = reason;
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"[Debugger] Paused — {reason}");
            Console.ResetColor();
        }

        public void Resume()
        {
            _paused = false;
            _pauseReason = "";
            OnResumed?.Invoke();
        }

        public void PushFrame(string script, string method, int line) =>
            _callStack.Add(new DebugFrame(script, method, line));

        public void PopFrame()
        { if (_callStack.Count > 0) _callStack.RemoveAt(_callStack.Count - 1); }

        public void Watch(string varName, object value) => _watchedVars[varName] = value;
        public void Unwatch(string varName) => _watchedVars.Remove(varName);

        public void ReportException(Exception ex)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"[Debugger] Exception: {ex.Message}");
            Console.ResetColor();
            OnException?.Invoke(ex);
            Pause($"Exception: {ex.GetType().Name}");
        }

        public string GetCallStackString()
        {
            var sb = new StringBuilder();
            for (int i = _callStack.Count - 1; i >= 0; i--)
                sb.AppendLine($"  at {_callStack[i]}");
            return sb.ToString();
        }
    }

    public sealed class DebugFrame
    {
        public string Script { get; }
        public string Method { get; }
        public int    Line   { get; }
        public DebugFrame(string s, string m, int l) { Script=s; Method=m; Line=l; }
        public override string ToString() => $"{Script}.{Method} (line {Line})";
    }

    // ─── Script Templates ─────────────────────────────────────
    public static class ScriptTemplates
    {
        public static string MonoBehaviour(string className) => $@"using BADGE.Engine.Scripting;
using BADGE.Engine.Components;
using BADGE.Engine.Math;

/// <summary>Auto-generated BADGE script behaviour.</summary>
public class {className} : ScriptBehaviour
{{
    // Called once when the script starts
    public override void OnStart()
    {{
    }}

    // Called every frame
    public override void OnUpdate(float dt)
    {{
    }}
}}
";

        public static string Singleton(string className) => $@"using System;
using BADGE.Engine.Scripting;

public class {className} : ScriptBehaviour
{{
    public static {className}? Instance {{ get; private set; }}

    public override void OnStart()
    {{
        if (Instance != null) {{ GameObject.Destroy(GameObject); return; }}
        Instance = this;
    }}
}}
";

        public static string StateMachine(string className, params string[] states)
        {
            var stateEnum = string.Join(", ", states.Length > 0 ? states : new[]{"Idle","Running","Dead"});
            return $@"using BADGE.Engine.Scripting;
using BADGE.Engine.Components;

public class {className} : ScriptBehaviour
{{
    public enum State {{ {stateEnum} }}
    private State _state = State.{(states.Length > 0 ? states[0] : "Idle")};

    public void TransitionTo(State next)
    {{
        OnExit(_state);
        _state = next;
        OnEnter(_state);
    }}

    private void OnEnter(State s) {{ }}
    private void OnExit(State s)  {{ }}

    public override void OnUpdate(float dt)
    {{
        switch (_state)
        {{
{string.Join("\n", (states.Length > 0 ? states : new[]{"Idle","Running","Dead"}).Select(s => $"            case State.{s}: break;"))}
        }}
    }}
}}
";
        }

        public static string EventListener(string className, string eventName) => $@"using BADGE.Engine.Scripting;
using BADGE.Engine.Core;

public class {className} : ScriptBehaviour
{{
    public override void OnStart()
    {{
        // Subscribe to the '{eventName}' event
        // EventSystem.Instance.Subscribe(""{eventName}"", On{eventName});
    }}

    private void On{eventName}(object data)
    {{
        // Handle event here
    }}

    public override void OnDestroy()
    {{
        // EventSystem.Instance.Unsubscribe(""{eventName}"", On{eventName});
    }}
}}
";

        public static string InterfaceImpl(string className, string interfaceName) => $@"using BADGE.Engine.Scripting;

public class {className} : ScriptBehaviour, {interfaceName}
{{
    public override void OnStart() {{ }}
    // Implement {interfaceName} members here
}}
";

        public static IReadOnlyDictionary<string, Func<string, string>> All => new Dictionary<string, Func<string, string>>
        {
            ["MonoBehaviour"] = MonoBehaviour,
            ["Singleton"]     = Singleton,
            ["EventListener"] = n => EventListener(n, "MyEvent"),
        };
    }

    // ─── Script API ──────────────────────────────────────────
    /// <summary>
    /// Convenience API surface exposed to user scripts. Provides
    /// shorthand access to engine subsystems without requiring
    /// direct kernel references.
    /// </summary>
    public static class ScriptAPI
    {
        // ── Time ────────────────────────────────────────────
        public static float DeltaTime      => Runtime.Time.DeltaTime;
        public static float FixedDeltaTime => Runtime.Time.FixedDeltaTime;
        public static float TimeSinceStart => Runtime.Time.TotalTime;
        public static float TimeScale
        {
            get => Runtime.Time.TimeScale;
            set => Runtime.Time.TimeScale = value;
        }

        // ── Logging ─────────────────────────────────────────
        public static void Log(object msg)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"[Script] {msg}");
            Console.ResetColor();
        }

        public static void LogWarning(object msg)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"[Script] WARNING: {msg}");
            Console.ResetColor();
        }

        public static void LogError(object msg)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"[Script] ERROR: {msg}");
            Console.ResetColor();
        }

        // ── GameObject helpers ───────────────────────────────
        public static Components.GameObject Find(string name) => Components.GameObject.Find(name);

        public static Components.GameObject Instantiate(Components.GameObject prefab, Math.Vector3 pos) =>
            Components.GameObject.Instantiate(prefab, pos);

        public static void Destroy(Components.GameObject go) => Components.GameObject.Destroy(go);

        // ── Physics ──────────────────────────────────────────
        public static bool Raycast(Math.Ray ray, out Physics.RaycastHit hit, float maxDist = float.MaxValue) =>
            EngineKernel.Instance.Physics.Raycast(ray, out hit, maxDist);

        public static Components.GameObject[] OverlapSphere(Math.Vector3 center, float radius) =>
            EngineKernel.Instance.Physics.OverlapSphere(center, radius);

        // ── Audio ────────────────────────────────────────────
        public static void PlaySound(string path, Math.Vector3 position, float volume = 1f) =>
            EngineKernel.Instance.Audio.PlayAtPosition(path, position, volume);

        // ── Events ───────────────────────────────────────────
        public static void Emit(string eventName, object? data = null) =>
            EngineKernel.Instance.Events.Emit(eventName, data);

        public static void On(string eventName, Action<object?> handler) =>
            EngineKernel.Instance.Events.Subscribe(eventName, handler);

        public static void Off(string eventName, Action<object?> handler) =>
            EngineKernel.Instance.Events.Unsubscribe(eventName, handler);

        // ── Scene ────────────────────────────────────────────
        public static void LoadScene(string name) => EngineKernel.Instance.SceneManager.LoadScene(name);
        public static string CurrentScene => EngineKernel.Instance.SceneManager.ActiveScene?.Name ?? "";

        // ── Coroutine-like deferred execution ────────────────
        public static void DelayedCall(float seconds, Action callback)
        {
            // Registers a one-shot timer with the engine scheduler
            EngineKernel.Instance.Scheduler.Schedule(seconds, callback);
        }
    }
}

