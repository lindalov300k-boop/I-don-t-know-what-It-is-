// BADGE Engine – Security/Security.cs
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace BADGE.Engine.Security
{
    public sealed class AssetEncryption
    {
        private readonly byte[] _key;
        public AssetEncryption(string password)
        {
            _key = SHA256.HashData(Encoding.UTF8.GetBytes(password));
        }

        public byte[] Encrypt(byte[] data)
        {
            using var aes = Aes.Create();
            aes.Key = _key; aes.GenerateIV();
            using var enc = aes.CreateEncryptor();
            var cipher = enc.TransformFinalBlock(data, 0, data.Length);
            var result = new byte[aes.IV.Length + cipher.Length];
            aes.IV.CopyTo(result, 0);
            cipher.CopyTo(result, aes.IV.Length);
            return result;
        }

        public byte[] Decrypt(byte[] data)
        {
            using var aes = Aes.Create();
            aes.Key = _key;
            var iv = data[..16]; var cipher = data[16..];
            aes.IV = iv;
            using var dec = aes.CreateDecryptor();
            return dec.TransformFinalBlock(cipher, 0, cipher.Length);
        }

        public void EncryptFile(string src, string dst)
        {
            File.WriteAllBytes(dst, Encrypt(File.ReadAllBytes(src)));
        }
        public void DecryptFile(string src, string dst)
        {
            File.WriteAllBytes(dst, Decrypt(File.ReadAllBytes(src)));
        }
    }

    public static class Checksums
    {
        public static string SHA256File(string path)
        {
            using var sha = SHA256.Create();
            using var f = File.OpenRead(path);
            return Convert.ToHexString(sha.ComputeHash(f)).ToLower();
        }

        public static bool VerifyFile(string path, string expectedHash) =>
            SHA256File(path).Equals(expectedHash, StringComparison.OrdinalIgnoreCase);

        public static string MD5String(string s) =>
            Convert.ToHexString(MD5.HashData(Encoding.UTF8.GetBytes(s))).ToLower();
    }

    public static class AntiTamper
    {
        public static bool VerifyAssembly()
        {
            // In production: compare assembly hash to embedded expected hash
            return true;
        }
        public static void InstallGuard()
        {
            Console.WriteLine("[Security] Anti-tamper guard installed.");
        }
    }
}

    // ═══════════════════════════════════════════════════════
    //  Code Obfuscation
    // ═══════════════════════════════════════════════════════
    public static class CodeObfuscator
    {
        /// <summary>
        /// Obfuscates constant strings via XOR encoding at rest.
        /// In a shipping build, an IL post-processor (e.g. Obfuscar, dotfuscator)
        /// would rename symbols and flatten control flow.
        /// </summary>
        public static byte[] ObfuscateString(string s, byte key = 0xA3)
        {
            var bytes = Encoding.UTF8.GetBytes(s);
            for (int i = 0; i < bytes.Length; i++) bytes[i] ^= (byte)(key ^ (i & 0xFF));
            return bytes;
        }

        public static string DeobfuscateString(byte[] data, byte key = 0xA3)
        {
            var bytes = (byte[])data.Clone();
            for (int i = 0; i < bytes.Length; i++) bytes[i] ^= (byte)(key ^ (i & 0xFF));
            return Encoding.UTF8.GetString(bytes);
        }

        /// <summary>
        /// Scrambles an identifier using a seeded hash — used by the build pipeline
        /// to rename public API symbols before shipping.
        /// </summary>
        public static string ScrambleIdentifier(string name, int seed = 0xDEADBEEF)
        {
            uint h = (uint)seed;
            foreach (char c in name) { h ^= c; h = (h << 5) | (h >> 27); h *= 0x9E3779B9; }
            return $"_{h:X8}";
        }

        /// <summary>
        /// Minimal control-flow flattening simulation.
        /// Real: use Roslyn rewriter or IL transform in build pipeline.
        /// </summary>
        public static string FlattenControlFlow(string csharpSource)
        {
            // Marker for the build tool — real transformation is done at IL level
            const string marker = "// [BADGE-Obfuscated]";
            return csharpSource.StartsWith(marker) ? csharpSource : marker + "\n" + csharpSource;
        }

        /// <summary>
        /// Returns a list of suggestions for manual review.
        /// </summary>
        public static List<string> AuditPublicSymbols(string[] typeNames)
        {
            var warnings = new List<string>();
            foreach (var name in typeNames)
                if (!name.StartsWith("_") && !name.StartsWith("BADGE"))
                    warnings.Add($"Public symbol exposed in shipping build: {name}");
            return warnings;
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Extended Anti-Tamper System
    // ═══════════════════════════════════════════════════════
    public sealed class AntiTamperSystem
    {
        private readonly Dictionary<string, string> _expectedHashes = new();
        private readonly string                     _secretSalt;
        private bool _guardInstalled;

        public bool TamperDetected      { get; private set; }
        public event Action<TamperEvent>? OnTamperDetected;

        public AntiTamperSystem(string secretSalt = "BADGE-ENGINE-SALT-v1")
        {
            _secretSalt = secretSalt;
        }

        // ── Guard installation ────────────────────────────
        public void InstallGuard()
        {
            if (_guardInstalled) return;
            _guardInstalled = true;
            // 1. Register self-check hook on AppDomain
            AppDomain.CurrentDomain.AssemblyLoad += (_, args) =>
            {
                var asmName = args.LoadedAssembly.FullName ?? "";
                if (asmName.Contains("Harmony") || asmName.Contains("MonoMod") || asmName.Contains("HookGen"))
                {
                    TriggerTamper($"Suspicious assembly loaded: {asmName}", TamperType.PatchingFramework);
                }
            };

            // 2. Verify own assembly hash
            VerifyOwnAssembly();

            Console.WriteLine("[AntiTamper] Guard installed.");
        }

        // ── Asset integrity registration ──────────────────
        public void RegisterAssetHash(string assetPath, string sha256Hash)
        {
            _expectedHashes[NormalizePath(assetPath)] = sha256Hash.ToLower();
        }

        public void RegisterAssetsFromManifest(string manifestPath)
        {
            if (!File.Exists(manifestPath)) return;
            foreach (var line in File.ReadAllLines(manifestPath))
            {
                if (line.StartsWith("#") || string.IsNullOrWhiteSpace(line)) continue;
                var parts = line.Split("  ", 2, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length == 2) RegisterAssetHash(parts[1].Trim(), parts[0].Trim());
            }
            Console.WriteLine($"[AntiTamper] Registered {_expectedHashes.Count} asset hash(es).");
        }

        // ── Integrity verification ────────────────────────
        public bool VerifyAsset(string assetPath)
        {
            var key = NormalizePath(assetPath);
            if (!_expectedHashes.TryGetValue(key, out var expected)) return true; // not tracked
            if (!File.Exists(assetPath)) return false;

            var actual = ComputeFileSHA256(assetPath);
            if (actual != expected)
            {
                TriggerTamper($"Asset tampered: {assetPath}", TamperType.AssetModification);
                return false;
            }
            return true;
        }

        public int VerifyAllRegisteredAssets(string basePath)
        {
            int failures = 0;
            foreach (var (relativePath, _) in _expectedHashes)
            {
                var full = Path.Combine(basePath, relativePath);
                if (!VerifyAsset(full)) failures++;
            }
            if (failures == 0) Console.WriteLine("[AntiTamper] All assets verified OK.");
            else Console.WriteLine($"[AntiTamper] {failures} asset(s) FAILED integrity check.");
            return failures;
        }

        // ── Executable / assembly verification ───────────
        public void VerifyOwnAssembly()
        {
            try
            {
                var asmPath = typeof(AntiTamperSystem).Assembly.Location;
                if (string.IsNullOrEmpty(asmPath)) return; // single-file AOT — skip
                // Real: compare against embedded expected hash (baked at build time)
                // Simplified: compute and log
                var hash = ComputeFileSHA256(asmPath);
                Console.WriteLine($"[AntiTamper] Assembly hash: {hash[..16]}…");
            }
            catch { }
        }

        public bool VerifyExecutable(string exePath, string expectedHash)
        {
            if (!File.Exists(exePath)) return false;
            var actual = ComputeFileSHA256(exePath);
            if (!actual.Equals(expectedHash, StringComparison.OrdinalIgnoreCase))
            {
                TriggerTamper($"Executable tampered: {exePath}", TamperType.ExecutableModification);
                return false;
            }
            return true;
        }

        // ── Debugger / environment checks ─────────────────
        public bool IsDebuggerAttached()
        {
#if DEBUG
            return false; // allow in debug builds
#else
            if (System.Diagnostics.Debugger.IsAttached) return true;
            // On Linux/Windows: check /proc/self/status (TracerPid) or IsDebuggerPresent()
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
            {
                try
                {
                    foreach (var l in File.ReadLines("/proc/self/status"))
                        if (l.StartsWith("TracerPid:") && l.Split(':')[1].Trim() != "0") return true;
                }
                catch { }
            }
            return false;
#endif
        }

        public void CheckEnvironmentIntegrity()
        {
            if (IsDebuggerAttached())
                TriggerTamper("Debugger detected in shipping build.", TamperType.DebuggerAttached);
        }

        // ── HMAC signature verification for config/save files ─
        public byte[] SignData(byte[] data)
        {
            var key = SHA256.HashData(Encoding.UTF8.GetBytes(_secretSalt));
            using var hmac = new HMACSHA256(key);
            return hmac.ComputeHash(data);
        }

        public bool VerifySignedData(byte[] data, byte[] signature)
        {
            var expected = SignData(data);
            return CryptographicOperations.FixedTimeEquals(signature, expected);
        }

        public byte[] AppendSignature(byte[] data)
        {
            var sig    = SignData(data);
            var output = new byte[data.Length + sig.Length];
            data.CopyTo(output, 0);
            sig.CopyTo(output, data.Length);
            return output;
        }

        public bool VerifyAndStripSignature(ref byte[] data)
        {
            if (data.Length < 32) return false;
            var payload   = data[..^32];
            var signature = data[^32..];
            bool ok = VerifySignedData(payload, signature);
            if (ok) data = payload;
            return ok;
        }

        // ── Tamper response ───────────────────────────────
        private void TriggerTamper(string reason, TamperType type)
        {
            TamperDetected = true;
            var ev = new TamperEvent { Reason = reason, Type = type, Timestamp = DateTime.UtcNow };
            Console.WriteLine($"[AntiTamper] ⚠ TAMPER DETECTED — {reason}");
            OnTamperDetected?.Invoke(ev);
        }

        // ── Helpers ───────────────────────────────────────
        private static string ComputeFileSHA256(string path)
        {
            using var sha = SHA256.Create();
            using var fs  = File.OpenRead(path);
            return Convert.ToHexString(sha.ComputeHash(fs)).ToLower();
        }

        private static string NormalizePath(string p) => p.Replace('\\', '/').TrimStart('/');
    }

    public sealed class TamperEvent
    {
        public string     Reason    { get; set; } = "";
        public TamperType Type      { get; set; }
        public DateTime   Timestamp { get; set; }
    }

    public enum TamperType
    {
        AssetModification, ExecutableModification,
        ConfigModification, DebuggerAttached,
        PatchingFramework, MemoryTampering
    }

    // ═══════════════════════════════════════════════════════
    //  Build Integrity — verify a shipped build's manifest
    // ═══════════════════════════════════════════════════════
    public static class BuildIntegrity
    {
        /// <summary>
        /// Generates a SHA-256 manifest for all files in a build output directory.
        /// Called at the end of the build pipeline.
        /// </summary>
        public static string GenerateManifest(string buildRoot, string? projectName = null)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"# BADGE Build Integrity Manifest");
            if (projectName != null) sb.AppendLine($"# Project: {projectName}");
            sb.AppendLine($"# Generated: {DateTime.UtcNow:O}");
            sb.AppendLine($"# Root: {buildRoot}");
            sb.AppendLine();

            if (!Directory.Exists(buildRoot)) return sb.ToString();

            using var sha = SHA256.Create();
            foreach (var file in Directory.EnumerateFiles(buildRoot, "*", SearchOption.AllDirectories)
                                          .OrderBy(f => f))
            {
                var relative = Path.GetRelativePath(buildRoot, file).Replace('\\', '/');
                if (relative.EndsWith("build.sha256")) continue; // skip self

                using var fs   = File.OpenRead(file);
                var hash = Convert.ToHexString(sha.ComputeHash(fs)).ToLower();
                sb.AppendLine($"{hash}  {relative}");
                sha.Initialize();
            }
            return sb.ToString();
        }

        /// <summary>
        /// Saves the manifest to <buildRoot>/build.sha256.
        /// </summary>
        public static string WriteManifest(string buildRoot, string? projectName = null)
        {
            var content = GenerateManifest(buildRoot, projectName);
            var outPath = Path.Combine(buildRoot, "build.sha256");
            File.WriteAllText(outPath, content);
            Console.WriteLine($"[Integrity] Manifest written: {outPath} ({content.Split('\n').Length - 5} entries)");
            return outPath;
        }

        /// <summary>
        /// Verifies a build directory against a stored manifest.
        /// Returns list of failures (empty = all OK).
        /// </summary>
        public static List<IntegrityFailure> VerifyBuild(string buildRoot, string? manifestPath = null)
        {
            manifestPath ??= Path.Combine(buildRoot, "build.sha256");
            var failures = new List<IntegrityFailure>();

            if (!File.Exists(manifestPath))
            {
                failures.Add(new IntegrityFailure { Path = "build.sha256", Reason = "Manifest not found." });
                return failures;
            }

            var expected = new Dictionary<string, string>();
            foreach (var line in File.ReadAllLines(manifestPath))
            {
                if (line.StartsWith("#") || string.IsNullOrWhiteSpace(line)) continue;
                var parts = line.Split("  ", 2, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length == 2) expected[parts[1].Trim()] = parts[0].Trim();
            }

            using var sha = SHA256.Create();
            foreach (var (relativePath, expectedHash) in expected)
            {
                var fullPath = Path.Combine(buildRoot, relativePath);
                if (!File.Exists(fullPath))
                {
                    failures.Add(new IntegrityFailure { Path = relativePath, Reason = "File missing." });
                    continue;
                }
                using var fs = File.OpenRead(fullPath);
                var actual = Convert.ToHexString(sha.ComputeHash(fs)).ToLower();
                sha.Initialize();
                if (actual != expectedHash)
                    failures.Add(new IntegrityFailure
                    { Path = relativePath, Reason = "Hash mismatch.", Expected = expectedHash, Actual = actual });
            }

            if (failures.Count == 0)
                Console.WriteLine($"[Integrity] Build verified OK — {expected.Count} file(s) checked.");
            else
                Console.WriteLine($"[Integrity] {failures.Count} failure(s) out of {expected.Count} checked.");

            return failures;
        }

        /// <summary>
        /// Computes a single fingerprint for the entire build (hash of all hashes).
        /// Useful for version tracking or update server validation.
        /// </summary>
        public static string ComputeBuildFingerprint(string buildRoot)
        {
            var manifest = GenerateManifest(buildRoot);
            return Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(manifest))).ToLower();
        }
    }

    public sealed class IntegrityFailure
    {
        public string Path     { get; set; } = "";
        public string Reason   { get; set; } = "";
        public string? Expected { get; set; }
        public string? Actual   { get; set; }
    }

    // ═══════════════════════════════════════════════════════
    //  Extended Checksum Utilities
    // ═══════════════════════════════════════════════════════
    public static partial class Checksums
    {
        public static string SHA256Bytes(byte[] data) =>
            Convert.ToHexString(SHA256.HashData(data)).ToLower();

        public static string SHA512File(string path)
        {
            using var sha = SHA512.Create();
            using var f   = File.OpenRead(path);
            return Convert.ToHexString(sha.ComputeHash(f)).ToLower();
        }

        public static uint CRC32(byte[] data)
        {
            uint crc = 0xFFFFFFFF;
            foreach (byte b in data)
            {
                crc ^= b;
                for (int i = 0; i < 8; i++)
                    crc = (crc >> 1) ^ (0xEDB88320u & (uint)-(int)(crc & 1));
            }
            return ~crc;
        }

        public static uint CRC32File(string path) => CRC32(File.ReadAllBytes(path));

        public static bool VerifyDirectory(string dir, Dictionary<string, string> expectedHashes)
        {
            bool ok = true;
            foreach (var (rel, hash) in expectedHashes)
            {
                var full = Path.Combine(dir, rel);
                if (!File.Exists(full) || !VerifyFile(full, hash))
                {
                    Console.WriteLine($"[Checksum] FAIL: {rel}");
                    ok = false;
                }
            }
            return ok;
        }
    }
