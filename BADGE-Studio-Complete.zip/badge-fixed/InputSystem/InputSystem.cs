// BADGE Engine – InputSystem/InputSystem.cs
using System;
using System.Collections.Generic;
using BADGE.Engine.Math;
using BADGE.Runtime;

namespace BADGE.Engine.Input
{
    public enum KeyCode { None,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,
        Alpha0,Alpha1,Alpha2,Alpha3,Alpha4,Alpha5,Alpha6,Alpha7,Alpha8,Alpha9,
        F1,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,
        Space,Return,Escape,Backspace,Tab,LeftShift,RightShift,LeftControl,RightControl,
        LeftAlt,RightAlt,UpArrow,DownArrow,LeftArrow,RightArrow,
        Delete,Home,End,PageUp,PageDown,Insert,
        Keypad0,Keypad1,Keypad2,Keypad3,Keypad4,Keypad5,Keypad6,Keypad7,Keypad8,Keypad9 }

    public enum MouseButton { Left=0, Right=1, Middle=2 }
    public enum GamepadButton { A,B,X,Y,LB,RB,LT,RT,Start,Select,LS,RS,Up,Down,Left,Right }
    public enum GamepadAxis { LeftX,LeftY,RightX,RightY,LT,RT }

    public sealed class InputManager
    {
        private readonly HashSet<KeyCode> _held    = new();
        private readonly HashSet<KeyCode> _pressed = new();
        private readonly HashSet<KeyCode> _released= new();
        private readonly HashSet<MouseButton> _mbHeld    = new();
        private readonly HashSet<MouseButton> _mbPressed = new();
        private readonly HashSet<MouseButton> _mbReleased= new();
        private Vector2 _mousePos, _mouseDelta, _scroll;
        private readonly Dictionary<string,InputAxis> _axes = new();
        private readonly Dictionary<string,string> _bindings = new();
        private readonly List<GamepadState> _gamepads = new();
        private readonly Queue<char> _inputQueue = new();

        public bool anyKeyDown => _pressed.Count > 0;
        public Vector2 MousePosition => _mousePos;
        public Vector2 MouseDelta    => _mouseDelta;
        public Vector2 ScrollDelta   => _scroll;

        public InputManager()
        {
            // Default axes
            _axes["Horizontal"] = new InputAxis(KeyCode.D, KeyCode.A, KeyCode.RightArrow, KeyCode.LeftArrow);
            _axes["Vertical"]   = new InputAxis(KeyCode.W, KeyCode.S, KeyCode.UpArrow, KeyCode.DownArrow);
            _axes["Jump"]       = new InputAxis(KeyCode.Space);
            _axes["Fire1"]      = new InputAxis(KeyCode.LeftControl);
            _axes["Fire2"]      = new InputAxis(KeyCode.LeftAlt);
            // Default bindings
            _bindings["Jump"]   = "Space";
            _bindings["Attack"] = "MouseLeft";
        }

        public void Update()
        {
            _pressed.Clear(); _released.Clear();
            _mbPressed.Clear(); _mbReleased.Clear();
            _mouseDelta = Vector2.Zero; _scroll = Vector2.Zero;
            foreach(var ax in _axes.Values) ax.Update(_held);
        }

        // ── Keyboard ──────────────────────────────────────
        public bool GetKey(KeyCode key)        => _held.Contains(key);
        public bool GetKeyDown(KeyCode key)    => _pressed.Contains(key);
        public bool GetKeyUp(KeyCode key)      => _released.Contains(key);
        public bool GetKey(string name)        => _bindings.TryGetValue(name,out var k) && GetKey(Enum.Parse<KeyCode>(k));

        // ── Mouse ─────────────────────────────────────────
        public bool GetMouseButton(int btn)     => _mbHeld.Contains((MouseButton)btn);
        public bool GetMouseButtonDown(int btn) => _mbPressed.Contains((MouseButton)btn);
        public bool GetMouseButtonUp(int btn)   => _mbReleased.Contains((MouseButton)btn);

        // ── Axis ──────────────────────────────────────────
        public float GetAxis(string name)     => _axes.TryGetValue(name,out var a) ? a.Value : 0f;
        public float GetAxisRaw(string name)  => _axes.TryGetValue(name,out var a) ? a.RawValue : 0f;

        // ── Gamepad ───────────────────────────────────────
        public bool GetGamepadButton(int pad, GamepadButton btn) =>
            pad < _gamepads.Count && _gamepads[pad].Buttons[(int)btn];
        public float GetGamepadAxis(int pad, GamepadAxis axis) =>
            pad < _gamepads.Count ? _gamepads[pad].Axes[(int)axis] : 0f;

        // ── Touch ─────────────────────────────────────────
        public int TouchCount { get; private set; }
        public Touch GetTouch(int i) => Touches.Count>i ? Touches[i] : default;
        public List<Touch> Touches { get; } = new();

        // ── Input events (called by platform layer) ───────
        public void OnKeyDown(KeyCode k)  { _held.Add(k); _pressed.Add(k); }
        public void OnKeyUp(KeyCode k)    { _held.Remove(k); _released.Add(k); }
        public void OnMouseMove(float x, float y) { _mouseDelta=new Vector2(x,y)-_mousePos; _mousePos=new Vector2(x,y); }
        public void OnMouseDown(MouseButton b) { _mbHeld.Add(b); _mbPressed.Add(b); }
        public void OnMouseUp(MouseButton b)   { _mbHeld.Remove(b); _mbReleased.Add(b); }
        public void OnScroll(float x,float y)  { _scroll=new Vector2(x,y); }
        public void OnChar(char c) { _inputQueue.Enqueue(c); }
        public char? GetInputChar() => _inputQueue.Count>0 ? _inputQueue.Dequeue() : null;

        // ── Binding ───────────────────────────────────────
        public void SetBinding(string action, string key) => _bindings[action]=key;
        public string GetBinding(string action) => _bindings.TryGetValue(action,out var k)?k:"";

        // ── Cursor ────────────────────────────────────────
        public bool CursorVisible   { get; set; } = true;
        public bool CursorLocked    { get; set; }
        public void LockCursor()    { CursorLocked=true; CursorVisible=false; }
        public void UnlockCursor()  { CursorLocked=false; CursorVisible=true; }
    }

    public sealed class InputAxis
    {
        private readonly KeyCode _pos,_neg,_altPos,_altNeg;
        private readonly KeyCode _single;
        public float Value    { get; private set; }
        public float RawValue { get; private set; }
        public float Gravity  { get; set; } = 3f;
        public float Sensitivity{get;set;} = 3f;
        public bool  Snap     { get; set; } = true;

        public InputAxis(KeyCode pos,KeyCode neg=KeyCode.None,KeyCode altPos=KeyCode.None,KeyCode altNeg=KeyCode.None)
        { _pos=pos;_neg=neg;_altPos=altPos;_altNeg=altNeg;_single=pos; }

        public InputAxis(KeyCode single) { _single=single;_pos=single; }

        public void Update(HashSet<KeyCode> held)
        {
            float raw = 0;
            if(held.Contains(_pos)||held.Contains(_altPos))  raw += 1;
            if(held.Contains(_neg)||held.Contains(_altNeg))  raw -= 1;
            RawValue = raw;
            if(raw != 0) Value=MathHelper.MoveTowards(Value,raw,Sensitivity*Runtime.Time.DeltaTime);
            else         Value=MathHelper.MoveTowards(Value,0,Gravity*Runtime.Time.DeltaTime);
        }
    }

    public sealed class GamepadState
    {
        public bool[] Buttons { get; } = new bool[20];
        public float[] Axes   { get; } = new float[8];
    }

    public struct Touch
    {
        public int     FingerId;
        public Vector2 Position, DeltaPosition;
        public float   DeltaTime;
        public int     TapCount;
        public TouchPhase Phase;
        public float   Pressure, RadiusX, RadiusY;
    }

    public enum TouchPhase { Began, Moved, Stationary, Ended, Canceled }
}

// ============================================================
//  BADGE Engine – InputSystem Extensions
//  Stylus, VR Controllers, AR Input, Motion Sensors,
//  Gyroscope, Accelerometer, MIDI, Custom Hardware Plugins.
// ============================================================
namespace BADGE.Engine.Input
{
    // ═══════════════════════════════════════════════════════
    //  Stylus Input
    // ═══════════════════════════════════════════════════════
    public sealed class StylusInput
    {
        public bool    IsConnected  { get; private set; }
        public Vector2 Position     { get; private set; }
        public float   Pressure     { get; private set; }   // 0–1
        public float   TiltX        { get; private set; }   // degrees
        public float   TiltY        { get; private set; }
        public float   Azimuth      { get; private set; }   // radians, rotation around z-axis
        public float   Altitude     { get; private set; }   // radians, angle from surface
        public bool    BarrelButton { get; private set; }
        public bool    EraserButton { get; private set; }
        public bool    InRange      { get; private set; }   // hover without touch

        public StylusPhase Phase { get; private set; } = StylusPhase.None;

        // Called by platform layer (Wacom, Apple Pencil, Surface Pen, etc.)
        public void OnStylusEvent(StylusEventData ev)
        {
            IsConnected  = true;
            Position     = ev.Position;
            Pressure     = ev.Pressure;
            TiltX        = ev.TiltX;
            TiltY        = ev.TiltY;
            Azimuth      = ev.Azimuth;
            Altitude     = ev.Altitude;
            BarrelButton = ev.BarrelButton;
            EraserButton = ev.EraserButton;
            InRange      = ev.InRange;
            Phase        = ev.Phase;
        }

        public void Update() { /* Platform tick; Phase transitions managed by platform layer */ }
    }

    public enum StylusPhase { None, Hover, Began, Moved, Stationary, Ended, Canceled }

    public struct StylusEventData
    {
        public Vector2    Position;
        public float      Pressure, TiltX, TiltY, Azimuth, Altitude;
        public bool       BarrelButton, EraserButton, InRange;
        public StylusPhase Phase;
    }

    // ═══════════════════════════════════════════════════════
    //  VR Controller Input
    // ═══════════════════════════════════════════════════════
    public enum VRHand { Left = 0, Right = 1 }

    public sealed class VRControllerInput
    {
        private readonly VRControllerState[] _controllers = { new(), new() };

        public VRControllerState GetController(VRHand hand) => _controllers[(int)hand];

        // Called by OpenXR / OpenVR platform layer
        public void OnControllerUpdate(VRHand hand, VRControllerState state) =>
            _controllers[(int)hand] = state;

        // Helper accessors
        public bool   GetButton  (VRHand h, VRButton b)  => _controllers[(int)h].Buttons[(int)b];
        public bool   GetButtonDown(VRHand h, VRButton b) => _controllers[(int)h].ButtonsDown[(int)b];
        public bool   GetButtonUp  (VRHand h, VRButton b) => _controllers[(int)h].ButtonsUp[(int)b];
        public float  GetTrigger (VRHand h)               => _controllers[(int)h].Trigger;
        public float  GetGrip    (VRHand h)               => _controllers[(int)h].Grip;
        public Vector2 GetThumbstick(VRHand h)            => _controllers[(int)h].Thumbstick;
        public VRPose  GetPose   (VRHand h)               => _controllers[(int)h].Pose;

        public void ClearFrameState()
        {
            foreach (var c in _controllers)
                for (int i = 0; i < c.ButtonsDown.Length; i++)
                { c.ButtonsDown[i] = false; c.ButtonsUp[i] = false; }
        }
    }

    public sealed class VRControllerState
    {
        public bool[]   Buttons     { get; } = new bool[16];
        public bool[]   ButtonsDown { get; } = new bool[16];
        public bool[]   ButtonsUp   { get; } = new bool[16];
        public float    Trigger     { get; set; }
        public float    Grip        { get; set; }
        public Vector2  Thumbstick  { get; set; }
        public VRPose   Pose        { get; set; }
        public bool     IsTracked   { get; set; }
        public float    BatteryLevel{ get; set; } = 1f;
    }

    public enum VRButton
    {
        Trigger=0, Grip=1, Menu=2, System=3,
        ThumbstickClick=4, PrimaryButton=5, SecondaryButton=6,
        ThumbstickTouch=7, TriggerTouch=8, GripTouch=9
    }

    // Reuse VRPose from OutputSystem — forward declaration here for independence:
    public struct VRPose { public float PX,PY,PZ, RX,RY,RZ,RW; }

    // ═══════════════════════════════════════════════════════
    //  AR Input
    // ═══════════════════════════════════════════════════════
    public sealed class ARInput
    {
        public bool    IsAvailable   { get; private set; }
        public bool    IsTracking    { get; private set; }
        public ARTrackingState TrackingState { get; private set; } = ARTrackingState.Limited;

        private readonly List<ARPlane>       _planes    = new();
        private readonly List<ARRaycastHit>  _lastHits  = new();
        private readonly List<ARImageAnchor> _imageAnchors = new();

        public IReadOnlyList<ARPlane>       DetectedPlanes  => _planes;
        public IReadOnlyList<ARImageAnchor> ImageAnchors    => _imageAnchors;

        public void Initialize()
        {
            var arRuntime = Environment.GetEnvironmentVariable("AR_RUNTIME");
            IsAvailable = !string.IsNullOrEmpty(arRuntime);
            if (IsAvailable) Console.WriteLine($"[ARInput] Initialized ({arRuntime}).");
        }

        public void OnPlaneDetected(ARPlane plane) => _planes.Add(plane);
        public void OnPlaneUpdated(ARPlane plane)
        {
            var idx = _planes.FindIndex(p => p.Id == plane.Id);
            if (idx >= 0) _planes[idx] = plane;
        }

        public void OnImageTracked(ARImageAnchor anchor) => _imageAnchors.Add(anchor);
        public void OnTrackingStateChanged(ARTrackingState state) => TrackingState = state;

        /// <summary>Raycast against AR detected planes from screen point.</summary>
        public List<ARRaycastHit> Raycast(Vector2 screenPoint)
        {
            _lastHits.Clear();
            // Real: ARKit/ARCore raycast via platform bridge
            foreach (var plane in _planes)
            {
                // Simplified: check if screenPoint projects into plane bounds
                _lastHits.Add(new ARRaycastHit
                {
                    PlaneId   = plane.Id,
                    WorldPos  = new Vector3(screenPoint.X, 0, screenPoint.Y),
                    Distance  = 1f,
                    Alignment = plane.Alignment
                });
                break; // return closest only in simplified mode
            }
            return _lastHits;
        }
    }

    public enum ARTrackingState { NotAvailable, Limited, Normal }
    public enum ARPlaneAlignment { Horizontal, Vertical, NonAxis }

    public sealed class ARPlane
    {
        public string         Id        { get; set; } = Guid.NewGuid().ToString();
        public Vector3        Center    { get; set; }
        public Vector2        Extent    { get; set; }  // width, height
        public ARPlaneAlignment Alignment{ get; set; }
    }

    public struct ARRaycastHit
    {
        public string         PlaneId;
        public Vector3        WorldPos;
        public float          Distance;
        public ARPlaneAlignment Alignment;
    }

    public sealed class ARImageAnchor
    {
        public string   ReferenceImageName { get; set; } = "";
        public Vector3  Position           { get; set; }
        public float    EstimatedWidth     { get; set; }
        public bool     IsTracked          { get; set; }
    }

    // ═══════════════════════════════════════════════════════
    //  Motion Sensors — Gyroscope & Accelerometer
    // ═══════════════════════════════════════════════════════
    public sealed class GyroscopeInput
    {
        public bool    IsAvailable  { get; private set; }
        public bool    Enabled      { get; set; }

        /// <summary>Angular velocity in rad/s around x, y, z axes (device space).</summary>
        public Vector3 RotationRate { get; private set; }
        /// <summary>Attitude: device orientation as quaternion.</summary>
        public Vector4 Attitude     { get; private set; } = new(0, 0, 0, 1);
        public float   SampleInterval { get; set; } = 0.01f; // seconds

        public void OnGyroscopeUpdate(Vector3 rotationRate, Vector4 attitude)
        {
            RotationRate = rotationRate;
            Attitude     = attitude;
        }

        public void Initialize()
        {
            // Real: SystemDeviceGyroscope.IsAvailable / Input.gyro.enabled
            IsAvailable = true;
            Console.WriteLine("[Gyroscope] Initialized.");
        }
    }

    public sealed class AccelerometerInput
    {
        public bool    IsAvailable      { get; private set; }
        public bool    Enabled          { get; set; }

        /// <summary>Raw acceleration in m/s² including gravity.</summary>
        public Vector3 Acceleration     { get; private set; }
        /// <summary>Linear acceleration with gravity removed.</summary>
        public Vector3 LinearAcceleration { get; private set; }
        /// <summary>Gravity vector derived from low-pass filter.</summary>
        public Vector3 Gravity          { get; private set; }
        public float   SampleInterval   { get; set; } = 0.02f;

        private const float LPF_ALPHA = 0.1f;

        public void OnAccelerometerUpdate(Vector3 raw)
        {
            Acceleration = raw;
            // Simple low-pass filter for gravity separation
            Gravity = new Vector3(
                Gravity.X + LPF_ALPHA * (raw.X - Gravity.X),
                Gravity.Y + LPF_ALPHA * (raw.Y - Gravity.Y),
                Gravity.Z + LPF_ALPHA * (raw.Z - Gravity.Z));
            LinearAcceleration = raw - Gravity;
        }

        public void Initialize()
        {
            IsAvailable = true;
            Console.WriteLine("[Accelerometer] Initialized.");
        }
    }

    // ═══════════════════════════════════════════════════════
    //  MIDI Input
    // ═══════════════════════════════════════════════════════
    public sealed class MidiInput
    {
        public bool   IsAvailable { get; private set; }
        public string DeviceName  { get; private set; } = "";
        private readonly List<string>     _availableDevices = new();
        private readonly Queue<MidiEvent> _eventQueue       = new();

        public IReadOnlyList<string> AvailableDevices => _availableDevices;

        public event Action<MidiEvent>? OnMidiEvent;

        public void Initialize()
        {
            // Real: enumerate MIDI devices via platform MIDI API
            // (Windows: Windows.Devices.Midi, macOS: CoreMIDI, Linux: ALSA/RtMidi)
            _availableDevices.Add("Default MIDI In");
            IsAvailable = _availableDevices.Count > 0;
            Console.WriteLine($"[MIDI] {_availableDevices.Count} device(s) found.");
        }

        public bool Open(string deviceName)
        {
            DeviceName = deviceName;
            Console.WriteLine($"[MIDI] Opened '{deviceName}'.");
            return true;
        }

        public void Close() { DeviceName = ""; Console.WriteLine("[MIDI] Closed."); }

        // Called by platform MIDI callback
        public void ReceiveMessage(byte status, byte data1, byte data2)
        {
            var ev = new MidiEvent
            {
                Status    = status,
                Channel   = (byte)(status & 0x0F),
                Type      = (MidiMessageType)((status & 0xF0) >> 4),
                Data1     = data1,
                Data2     = data2,
                Timestamp = DateTime.UtcNow
            };
            _eventQueue.Enqueue(ev);
            OnMidiEvent?.Invoke(ev);
        }

        public bool TryGetEvent(out MidiEvent ev)
        {
            if (_eventQueue.Count > 0) { ev = _eventQueue.Dequeue(); return true; }
            ev = default;
            return false;
        }

        // Convenience
        public void SendNoteOn (string device, byte channel, byte note, byte velocity) =>
            Console.WriteLine($"[MIDI→{device}] NoteOn  ch={channel} note={note} vel={velocity}");
        public void SendNoteOff(string device, byte channel, byte note) =>
            Console.WriteLine($"[MIDI→{device}] NoteOff ch={channel} note={note}");
        public void SendCC     (string device, byte channel, byte cc, byte value) =>
            Console.WriteLine($"[MIDI→{device}] CC      ch={channel} cc={cc} val={value}");
    }

    public struct MidiEvent
    {
        public byte            Status, Channel, Data1, Data2;
        public MidiMessageType Type;
        public DateTime        Timestamp;
        // Helpers
        public byte  Note     => Data1;
        public byte  Velocity => Data2;
        public byte  CCNumber => Data1;
        public byte  CCValue  => Data2;
        public float NoteFrequency => 440f * MathF.Pow(2f, (Note - 69) / 12f);
    }

    public enum MidiMessageType
    {
        NoteOff = 0x8, NoteOn = 0x9, PolyPressure = 0xA, ControlChange = 0xB,
        ProgramChange = 0xC, ChannelPressure = 0xD, PitchBend = 0xE, System = 0xF
    }

    // ═══════════════════════════════════════════════════════
    //  Custom Hardware Plugin System
    //  Designed to support ANY input device through plugins.
    // ═══════════════════════════════════════════════════════
    public interface IInputPlugin
    {
        string Name        { get; }
        bool   IsConnected { get; }
        void   Initialize();
        void   Update(float dt);
        void   Shutdown();
        // Plugin exposes typed data via a generic slot
        bool   TryGetData<T>(string channel, out T? data);
    }

    public sealed class CustomInputManager
    {
        private readonly Dictionary<string, IInputPlugin> _plugins = new();

        public void RegisterPlugin(IInputPlugin plugin)
        {
            _plugins[plugin.Name] = plugin;
            plugin.Initialize();
            Console.WriteLine($"[CustomInput] Plugin '{plugin.Name}' registered.");
        }

        public void UnregisterPlugin(string name)
        {
            if (_plugins.TryGetValue(name, out var p)) { p.Shutdown(); _plugins.Remove(name); }
        }

        public T? GetData<T>(string pluginName, string channel)
        {
            if (_plugins.TryGetValue(pluginName, out var p) && p.TryGetData<T>(channel, out var d))
                return d;
            return default;
        }

        public bool IsPluginConnected(string name) =>
            _plugins.TryGetValue(name, out var p) && p.IsConnected;

        public void Update(float dt)
        {
            foreach (var p in _plugins.Values) p.Update(dt);
        }

        public IReadOnlyDictionary<string, IInputPlugin> Plugins => _plugins;
    }

    /// <summary>
    /// Example custom plugin skeleton — implement IInputPlugin per-device.
    /// </summary>
    public abstract class BaseInputPlugin : IInputPlugin
    {
        public abstract string Name        { get; }
        public virtual  bool   IsConnected { get; protected set; }
        private readonly Dictionary<string, object?> _channels = new();

        public abstract void Initialize();
        public abstract void Update(float dt);
        public virtual  void Shutdown() { IsConnected = false; }

        protected void SetChannel(string ch, object? val) => _channels[ch] = val;
        public bool TryGetData<T>(string channel, out T? data)
        {
            if (_channels.TryGetValue(channel, out var v) && v is T t) { data = t; return true; }
            data = default;
            return false;
        }
    }

    // ── Extended InputManager (adds all new subsystems) ──
    public static class InputExtensions
    {
        private static StylusInput?       _stylus;
        private static VRControllerInput? _vr;
        private static ARInput?           _ar;
        private static GyroscopeInput?    _gyro;
        private static AccelerometerInput?_accel;
        private static MidiInput?         _midi;
        private static CustomInputManager?_custom;

        public static StylusInput        Stylus  => _stylus  ??= new();
        public static VRControllerInput  VR      => _vr      ??= new();
        public static ARInput            AR      => _ar      ??= new();
        public static GyroscopeInput     Gyro    => _gyro    ??= new();
        public static AccelerometerInput Accel   => _accel   ??= new();
        public static MidiInput          MIDI    => _midi    ??= new();
        public static CustomInputManager Custom  => _custom  ??= new();

        public static void InitializeAll()
        {
            Gyro.Initialize();
            Accel.Initialize();
            MIDI.Initialize();
            AR.Initialize();
            Console.WriteLine("[Input] Extended input systems initialized.");
        }

        public static void UpdateAll(float dt)
        {
            Stylus.Update();
            VR.ClearFrameState();
            Custom.Update(dt);
        }
    }
}
