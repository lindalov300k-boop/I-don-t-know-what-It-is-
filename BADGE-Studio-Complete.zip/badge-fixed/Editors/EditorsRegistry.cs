// ============================================================
//  BADGE Engine – Editors/EditorsRegistry.cs
//  Top-level registry that discovers, registers, and manages
//  all editor modules in one place.
// ============================================================
using System;
using System.Collections.Generic;
using BADGE.Editor;

namespace BADGE.Editors
{
    /// <summary>
    /// Central catalogue of every editor module available in
    /// BADGE Studio.  On startup, call
    /// <see cref="RegisterAll"/> to install all built-in
    /// editors into the <see cref="EditorSystem"/>.
    /// </summary>
    public sealed class EditorsRegistry
    {
        private static EditorsRegistry? _instance;
        public  static EditorsRegistry   Instance => _instance ??= new();

        private readonly Dictionary<string, IEditorModule> _catalog = new();

        // ── Registration ─────────────────────────────────────

        public void Register(IEditorModule module)
        {
            _catalog[module.Name] = module;
            EditorSystem.Instance.RegisterModule(module);
        }

        /// <summary>
        /// Auto-register all BADGE built-in editor modules.
        /// Called once at engine boot.
        /// </summary>
        public void RegisterAll()
        {
            Register(new ModelEditorAdapter());
            Register(new SpriteEditorAdapter());
            Register(new AnimationEditorAdapter());
            Register(new AudioEditorAdapter());
            Register(new MaterialEditorAdapter());
            Register(new NodeGraphEditorAdapter());
            Register(new ShaderEditorAdapter());
            Register(new ParticleEditorAdapter());
            Register(new TerrainEditorAdapter());
            Register(new VoxelEditorAdapter());
            Register(new UIDesignerAdapter());
            Register(new PhysicsDebuggerAdapter());
            Register(new NotesAdapter());
            Register(new TerminalAdapter());

            Console.WriteLine($"[EditorsRegistry] {_catalog.Count} editors registered.");
        }

        public IEditorModule? Get(string name)
            => _catalog.TryGetValue(name, out var m) ? m : null;

        public IEnumerable<IEditorModule> All => _catalog.Values;

        // ── Adapter stubs (thin wrappers around existing systems) ─

        private abstract class NamedAdapter : IEditorModule
        {
            public abstract string Name  { get; }
            public abstract string Icon  { get; }
            public bool  IsOpen { get; set; }
            public void  Open()  { IsOpen=true;  Console.WriteLine($"[{Name}] Opened."); }
            public void  Close() { IsOpen=false; Console.WriteLine($"[{Name}] Closed."); }
            public void  Update(float dt) { }
            public void  DrawUI() => Console.WriteLine($"[{Name}] UI");
            public void  OnShortcut(string s) { }
        }

        private sealed class ModelEditorAdapter     : NamedAdapter { public override string Name=>"ModelEditor";     public override string Icon=>"🧊"; }
        private sealed class SpriteEditorAdapter    : NamedAdapter { public override string Name=>"SpriteEditor";    public override string Icon=>"🖼"; }
        private sealed class AnimationEditorAdapter : NamedAdapter { public override string Name=>"AnimationEditor"; public override string Icon=>"🎞"; }
        private sealed class AudioEditorAdapter     : NamedAdapter { public override string Name=>"AudioEditor";     public override string Icon=>"🎵"; }
        private sealed class MaterialEditorAdapter  : NamedAdapter { public override string Name=>"MaterialEditor";  public override string Icon=>"🎨"; }
        private sealed class NodeGraphEditorAdapter : NamedAdapter { public override string Name=>"NodeGraphEditor"; public override string Icon=>"🔗"; }
        private sealed class ShaderEditorAdapter    : NamedAdapter { public override string Name=>"ShaderEditor";    public override string Icon=>"✨"; }
        private sealed class ParticleEditorAdapter  : NamedAdapter { public override string Name=>"ParticleEditor";  public override string Icon=>"💫"; }
        private sealed class TerrainEditorAdapter   : NamedAdapter { public override string Name=>"TerrainEditor";   public override string Icon=>"🏔"; }
        private sealed class VoxelEditorAdapter     : NamedAdapter { public override string Name=>"VoxelEditor";     public override string Icon=>"🟫"; }
        private sealed class UIDesignerAdapter      : NamedAdapter { public override string Name=>"UIDesigner";      public override string Icon=>"📐"; }
        private sealed class PhysicsDebuggerAdapter : NamedAdapter { public override string Name=>"PhysicsDebugger"; public override string Icon=>"⚙"; }
        private sealed class NotesAdapter           : NamedAdapter { public override string Name=>"Notes";           public override string Icon=>"📝"; }
        private sealed class TerminalAdapter        : NamedAdapter { public override string Name=>"Terminal";        public override string Icon=>"💻"; }
    }
}
