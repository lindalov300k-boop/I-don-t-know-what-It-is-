// ============================================================
//  BADGE Engine – Networking/NetworkManager.cs
//  TCP/UDP game networking: server/client, lobby system,
//  reliable messaging, snapshot interpolation, and RPC dispatch.
// ============================================================
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BADGE.Networking
{
    public enum NetworkRole  { None, Server, Client }
    public enum PacketType   : byte { Ping, Pong, Connect, Disconnect, Snapshot, RPC, LobbyInfo, ChatMessage, Custom = 255 }
    public enum DeliveryMode { Unreliable, Reliable }

    // ── Packet ────────────────────────────────────────────────
    public sealed class Packet
    {
        public PacketType    Type     { get; set; }
        public DeliveryMode  Delivery { get; set; } = DeliveryMode.Unreliable;
        public int           SenderId { get; set; }
        public byte[]        Payload  { get; set; } = Array.Empty<byte>();
        public DateTime      Timestamp{ get; }      = DateTime.UtcNow;

        public static Packet FromString(PacketType type, string data, int senderId = 0)
            => new() { Type = type, SenderId = senderId, Payload = Encoding.UTF8.GetBytes(data) };

        public string PayloadAsString() => Encoding.UTF8.GetString(Payload);
    }

    // ── Remote peer ───────────────────────────────────────────
    public sealed class RemotePeer
    {
        public int         Id        { get; }
        public string      Name      { get; set; } = "Player";
        public IPEndPoint? EndPoint  { get; set; }
        public bool        IsReady   { get; set; }
        public DateTime    LastSeen  { get; set; } = DateTime.UtcNow;
        public float       Ping      { get; set; }   // ms
        public RemotePeer(int id) { Id = id; }
    }

    // ── Snapshot ──────────────────────────────────────────────
    public sealed class WorldSnapshot
    {
        public uint   Tick       { get; set; }
        public float  Timestamp  { get; set; }
        public List<EntityState> Entities { get; } = new();
    }

    public sealed class EntityState
    {
        public int    EntityId  { get; set; }
        public float  X, Y, Z;
        public float  RotX, RotY, RotZ, RotW;
        public byte[] ExtraData { get; set; } = Array.Empty<byte>();
    }

    // ── RPC registry ─────────────────────────────────────────
    public sealed class RPCRegistry
    {
        private readonly Dictionary<string, Action<Packet>> _handlers = new();

        public void Register(string name, Action<Packet> handler) => _handlers[name] = handler;

        public void Dispatch(string name, Packet packet)
        {
            if (_handlers.TryGetValue(name, out var h)) h(packet);
            else Console.WriteLine($"[RPC] No handler for '{name}'");
        }
    }

    // ── Lobby ─────────────────────────────────────────────────
    public sealed class Lobby
    {
        public string            Name       { get; set; } = "My Lobby";
        public int               MaxPlayers { get; set; } = 8;
        public bool              IsPublic   { get; set; } = true;
        public string            GameMode   { get; set; } = "default";
        public List<RemotePeer>  Players    { get; }      = new();

        public bool CanJoin  => Players.Count < MaxPlayers;
        public bool AllReady => Players.Count > 0 && Players.TrueForAll(p => p.IsReady);

        public void AddPlayer(RemotePeer peer)
        {
            if (!CanJoin) throw new InvalidOperationException("Lobby full.");
            Players.Add(peer);
            Console.WriteLine($"[Lobby] {peer.Name} joined ({Players.Count}/{MaxPlayers})");
        }

        public bool RemovePlayer(int id)
        {
            int removed = Players.RemoveAll(p => p.Id == id);
            return removed > 0;
        }
    }

    // ── Core manager ─────────────────────────────────────────
    public sealed class NetworkManager
    {
        // ── Singleton ─────────────────────────────────────────
        private static NetworkManager? _instance;
        public  static NetworkManager   Instance => _instance ??= new();

        // ── State ─────────────────────────────────────────────
        public NetworkRole Role       { get; private set; } = NetworkRole.None;
        public bool        IsOnline   => Role != NetworkRole.None;
        public int         LocalId    { get; private set; }
        public Lobby?      CurrentLobby { get; private set; }
        public RPCRegistry RPC        { get; }               = new();

        // ── Peers ─────────────────────────────────────────────
        private readonly ConcurrentDictionary<int, RemotePeer> _peers = new();
        public  IEnumerable<RemotePeer> Peers => _peers.Values;

        // ── Snapshot interpolation buffer ─────────────────────
        private readonly ConcurrentQueue<WorldSnapshot> _snapshots = new();
        private WorldSnapshot? _from, _to;

        // ── Socket ────────────────────────────────────────────
        private UdpClient?        _udp;
        private CancellationTokenSource? _cts;

        // ── Events ────────────────────────────────────────────
        public event Action<RemotePeer>? OnPeerConnected;
        public event Action<RemotePeer>? OnPeerDisconnected;
        public event Action<Packet>?     OnPacketReceived;

        // ── Server / Client lifecycle ─────────────────────────

        public void StartServer(int port = 7777)
        {
            if (IsOnline) throw new InvalidOperationException("Already online.");
            Role    = NetworkRole.Server;
            LocalId = 0;
            CurrentLobby = new Lobby();
            _udp    = new UdpClient(port);
            _cts    = new CancellationTokenSource();
            Task.Run(() => ReceiveLoop(_cts.Token));
            Console.WriteLine($"[NetworkManager] Server started on :{port}");
        }

        public void ConnectToServer(string host, int port = 7777)
        {
            if (IsOnline) throw new InvalidOperationException("Already online.");
            Role    = NetworkRole.Client;
            LocalId = new Random().Next(1, 9999);
            _udp    = new UdpClient();
            _udp.Connect(host, port);
            _cts    = new CancellationTokenSource();
            Task.Run(() => ReceiveLoop(_cts.Token));
            Send(Packet.FromString(PacketType.Connect, $"HELLO:{LocalId}"));
            Console.WriteLine($"[NetworkManager] Connecting to {host}:{port} as id={LocalId}");
        }

        public void Disconnect()
        {
            if (!IsOnline) return;
            Send(Packet.FromString(PacketType.Disconnect, "BYE"));
            _cts?.Cancel();
            _udp?.Close();
            _peers.Clear();
            Role = NetworkRole.None;
            Console.WriteLine("[NetworkManager] Disconnected.");
        }

        // ── Send ──────────────────────────────────────────────

        public void Send(Packet packet, IPEndPoint? target = null)
        {
            if (_udp == null) return;
            var data = SerializePacket(packet);
            try
            {
                if (target != null)
                    _udp.Send(data, data.Length, target);
                else
                    _udp.Send(data, data.Length);
            }
            catch (Exception ex) { Console.WriteLine($"[NetworkManager] Send error: {ex.Message}"); }
        }

        public void Broadcast(Packet packet)
        {
            foreach (var peer in _peers.Values)
                if (peer.EndPoint != null) Send(packet, peer.EndPoint);
        }

        public void SendRPC(string methodName, byte[] args)
        {
            var data = new byte[methodName.Length + 1 + args.Length];
            data[0] = (byte)methodName.Length;
            Encoding.ASCII.GetBytes(methodName).CopyTo(data, 1);
            args.CopyTo(data, methodName.Length + 1);
            Broadcast(new Packet { Type = PacketType.RPC, Payload = data });
        }

        // ── Snapshot ──────────────────────────────────────────

        public void PushSnapshot(WorldSnapshot snap) => _snapshots.Enqueue(snap);

        /// <summary>
        /// Returns an interpolated snapshot for the given render time.
        /// </summary>
        public WorldSnapshot? GetInterpolated(float renderTime)
        {
            while (_snapshots.TryPeek(out var next) && next.Timestamp <= renderTime)
            {
                _from = _to;
                _snapshots.TryDequeue(out _to);
            }
            if (_from == null || _to == null) return _to;

            float range = _to.Timestamp - _from.Timestamp;
            if (range <= 0) return _to;
            float t = (renderTime - _from.Timestamp) / range;

            var result = new WorldSnapshot { Tick = _to.Tick, Timestamp = renderTime };
            for (int i = 0; i < Math.Min(_from.Entities.Count, _to.Entities.Count); i++)
            {
                var a = _from.Entities[i];
                var b = _to.Entities[i];
                result.Entities.Add(new EntityState
                {
                    EntityId = b.EntityId,
                    X  = Lerp(a.X, b.X, t), Y = Lerp(a.Y, b.Y, t), Z = Lerp(a.Z, b.Z, t),
                    RotX = Lerp(a.RotX, b.RotX, t), RotY = Lerp(a.RotY, b.RotY, t),
                    RotZ = Lerp(a.RotZ, b.RotZ, t), RotW = Lerp(a.RotW, b.RotW, t),
                });
            }
            return result;
        }

        // ── Ping ──────────────────────────────────────────────

        public void PingAll()
        {
            var p = new Packet { Type = PacketType.Ping, SenderId = LocalId };
            Broadcast(p);
        }

        // ── Receive loop (background) ─────────────────────────

        private async Task ReceiveLoop(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested && _udp != null)
            {
                try
                {
                    var result = await _udp.ReceiveAsync(ct);
                    var packet = DeserializePacket(result.Buffer);
                    // SenderId is already decoded from wire bytes by DeserializePacket
                    HandlePacket(packet, result.RemoteEndPoint);
                    OnPacketReceived?.Invoke(packet);
                }
                catch (OperationCanceledException) { break; }
                catch (Exception ex) { Console.WriteLine($"[NetworkManager] Receive: {ex.Message}"); }
            }
        }

        private void HandlePacket(Packet packet, IPEndPoint remote)
        {
            switch (packet.Type)
            {
                case PacketType.Connect:
                    var peer = new RemotePeer(packet.SenderId) { EndPoint = remote };
                    _peers[peer.Id] = peer;
                    CurrentLobby?.AddPlayer(peer);
                    OnPeerConnected?.Invoke(peer);
                    break;

                case PacketType.Disconnect:
                    if (_peers.TryRemove(packet.SenderId, out var dp))
                    {
                        CurrentLobby?.RemovePlayer(dp.Id);
                        OnPeerDisconnected?.Invoke(dp);
                    }
                    break;

                case PacketType.Ping:
                    Send(new Packet { Type = PacketType.Pong, SenderId = LocalId }, remote);
                    break;

                case PacketType.RPC:
                    int nameLen = packet.Payload[0];
                    string name = Encoding.ASCII.GetString(packet.Payload, 1, nameLen);
                    RPC.Dispatch(name, packet);
                    break;

                case PacketType.Snapshot:
                    // deserialize snapshot — stub for custom layout
                    break;
            }
        }

        // ── Serialization ─────────────────────────────────────

        private static byte[] SerializePacket(Packet p)
        {
            var buf = new byte[4 + p.Payload.Length];
            buf[0] = (byte)p.Type;
            buf[1] = (byte)p.Delivery;
            buf[2] = (byte)(p.SenderId >> 8);
            buf[3] = (byte)(p.SenderId & 0xFF);
            p.Payload.CopyTo(buf, 4);
            return buf;
        }

        private static Packet DeserializePacket(byte[] buf)
        {
            var payload = new byte[Math.Max(0, buf.Length - 4)];
            if (payload.Length > 0) Buffer.BlockCopy(buf, 4, payload, 0, payload.Length);
            return new Packet
            {
                Type     = (PacketType)buf[0],
                Delivery = (DeliveryMode)buf[1],
                SenderId = (buf[2] << 8) | buf[3],
                Payload  = payload
            };
        }

        private static float Lerp(float a, float b, float t) => a + (b - a) * t;
    }
}
