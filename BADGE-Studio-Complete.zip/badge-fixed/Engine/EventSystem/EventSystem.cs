using System;
using System.Collections.Generic;

namespace BADGE.Engine.Core
{
    public class EventSystem
    {
        private static EventSystem _instance;
        public static EventSystem Instance => _instance ??= new EventSystem();

        private readonly Dictionary<string, List<Action<object>>> _listeners = new();
        private readonly Queue<(string eventName, object data)> _eventQueue = new();

        public void Subscribe(string eventName, Action<object> handler)
        {
            if (!_listeners.ContainsKey(eventName))
                _listeners[eventName] = new List<Action<object>>();
            _listeners[eventName].Add(handler);
        }

        public void Unsubscribe(string eventName, Action<object> handler)
        {
            if (_listeners.TryGetValue(eventName, out var list))
                list.Remove(handler);
        }

        public void Emit(string eventName, object data = null)
        {
            _eventQueue.Enqueue((eventName, data));
        }

        public void EmitImmediate(string eventName, object data = null)
        {
            if (_listeners.TryGetValue(eventName, out var list))
                foreach (var h in list) h?.Invoke(data);
        }

        public void ProcessQueue()
        {
            while (_eventQueue.Count > 0)
            {
                var (name, data) = _eventQueue.Dequeue();
                if (_listeners.TryGetValue(name, out var list))
                    foreach (var h in list) h?.Invoke(data);
            }
        }

        public void Clear()
        {
            _listeners.Clear();
            _eventQueue.Clear();
        }
    }
}
