// ============================================================
//  BADGE Engine – Boot/MemoryAllocator.cs
//  Pre-allocates fixed-size memory pools for components,
//  render buffers, audio buffers, and general scratch space.
//  Eliminates GC pressure during gameplay by recycling blocks.
// ============================================================
using System;
using System.Buffers;
using System.Collections.Generic;

namespace BADGE.Engine.Boot
{
    /// <summary>Represents a named, pre-allocated memory pool.</summary>
    public sealed class MemoryPool
    {
        public string Name        { get; }
        public int    BlockSize   { get; }          // bytes per block
        public int    BlockCount  { get; }
        public int    TotalBytes  => BlockSize * BlockCount;
        public int    FreeBlocks  { get; private set; }

        private readonly Stack<byte[]> _free;

        public MemoryPool(string name, int blockSize, int blockCount)
        {
            Name       = name;
            BlockSize  = blockSize;
            BlockCount = blockCount;
            FreeBlocks = blockCount;
            _free      = new Stack<byte[]>(blockCount);
            for (int i = 0; i < blockCount; i++)
                _free.Push(new byte[blockSize]);
        }

        /// <summary>Rent a block from the pool. Returns null when exhausted.</summary>
        public byte[]? Rent()
        {
            if (_free.Count == 0) return null;
            FreeBlocks--;
            return _free.Pop();
        }

        /// <summary>Return a block to the pool for re-use.</summary>
        public void Return(byte[] block)
        {
            Array.Clear(block, 0, block.Length);
            _free.Push(block);
            FreeBlocks++;
        }
    }

    /// <summary>
    /// Initialised once at boot.  Creates and owns all
    /// engine-wide memory pools.  Higher-level systems
    /// obtain pools by name via <see cref="Get"/>.
    /// </summary>
    public sealed class MemoryAllocator
    {
        // ── Singleton ─────────────────────────────────────────
        private static MemoryAllocator? _instance;
        public  static MemoryAllocator  Instance => _instance ??= new MemoryAllocator();

        // ── Pools ─────────────────────────────────────────────
        private readonly Dictionary<string, MemoryPool> _pools = new();
        public  bool IsInitialized { get; private set; }

        // ── Lifecycle ─────────────────────────────────────────

        public void Initialize()
        {
            if (IsInitialized) return;

            // Define default pools
            RegisterPool("component",  blockSize:  256,  blockCount: 4096);  // component data
            RegisterPool("render",     blockSize: 4096,  blockCount:  512);  // vertex/index scratch
            RegisterPool("audio",      blockSize: 8192,  blockCount:  256);  // PCM audio chunks
            RegisterPool("network",    blockSize: 1500,  blockCount:  128);  // MTU-sized packets
            RegisterPool("scratch",    blockSize: 1024,  blockCount: 2048);  // general scratch

            IsInitialized = true;

            long total = 0;
            foreach (var p in _pools.Values) total += p.TotalBytes;
            Console.WriteLine($"[MemoryAllocator] {_pools.Count} pools initialised " +
                              $"({total / 1024} KB pre-allocated).");
        }

        // ── Pool management ───────────────────────────────────

        public void RegisterPool(string name, int blockSize, int blockCount)
        {
            if (_pools.ContainsKey(name))
            {
                Console.WriteLine($"[MemoryAllocator] Pool '{name}' already registered.");
                return;
            }
            _pools[name] = new MemoryPool(name, blockSize, blockCount);
            Console.WriteLine($"[MemoryAllocator] Pool '{name}': " +
                              $"{blockCount}×{blockSize}B = {blockCount * blockSize / 1024} KB");
        }

        /// <summary>Get a named pool. Returns null if not found.</summary>
        public MemoryPool? Get(string name)
            => _pools.TryGetValue(name, out var p) ? p : null;

        // ── Stats ─────────────────────────────────────────────

        public void PrintStats()
        {
            Console.WriteLine("[MemoryAllocator] Pool stats:");
            foreach (var p in _pools.Values)
                Console.WriteLine($"  {p.Name,-12} free={p.FreeBlocks}/{p.BlockCount}  ({p.TotalBytes/1024} KB)");
        }
    }
}
