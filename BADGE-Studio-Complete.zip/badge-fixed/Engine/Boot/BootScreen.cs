// ============================================================
//  BADGE Engine – Boot/BootScreen.cs
//  Renders the BADGE Studio ASCII splash screen and progress
//  bar to the console output.
// ============================================================
using System;

namespace BADGE.Engine.Boot
{
    /// <summary>
    /// Renders the BADGE Studio splash and an animated boot
    /// progress bar. Completely self-contained; no dependencies
    /// on other engine systems so it can run before anything
    /// else is initialised.
    /// </summary>
    public sealed class BootScreen
    {
        // ── Configuration ─────────────────────────────────────
        public ConsoleColor AccentColor    { get; set; } = ConsoleColor.Yellow;
        public ConsoleColor SubtitleColor  { get; set; } = ConsoleColor.Cyan;
        public ConsoleColor ProgressColor  { get; set; } = ConsoleColor.Green;
        public int          ProgressWidth  { get; set; } = 40;

        // ── Banner lines ──────────────────────────────────────
        private static readonly string[] _banner =
        {
            @"  ██████╗  █████╗ ██████╗  ██████╗ ███████╗",
            @"  ██╔══██╗██╔══██╗██╔══██╗██╔════╝ ██╔════╝",
            @"  ██████╔╝███████║██║  ██║██║  ███╗█████╗  ",
            @"  ██╔══██╗██╔══██║██║  ██║██║   ██║██╔══╝  ",
            @"  ██████╔╝██║  ██║██████╔╝╚██████╔╝███████╗",
            @"  ╚═════╝ ╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚══════╝",
        };

        // ── Public API ────────────────────────────────────────

        /// <summary>Print the full splash banner and subtitle.</summary>
        public void Show()
        {
            Console.WriteLine();
            Console.ForegroundColor = AccentColor;
            foreach (var line in _banner)
                Console.WriteLine(line);
            Console.ResetColor();

            Console.ForegroundColor = SubtitleColor;
            Console.WriteLine("  BADGE Studio");
            Console.ResetColor();
            Console.WriteLine("  Basic Atlas Dimensional Game Engine  v1.0.0");
            Console.WriteLine();
        }

        /// <summary>
        /// Update the on-screen progress bar in-place.
        /// Call repeatedly as boot progresses (0.0 → 1.0).
        /// </summary>
        /// <param name="progress">Value between 0.0 and 1.0.</param>
        /// <param name="label">Short label shown beside the bar.</param>
        public void UpdateProgress(float progress, string label = "")
        {
            progress = Math.Clamp(progress, 0f, 1f);
            int filled = (int)(ProgressWidth * progress);

            Console.ForegroundColor = ProgressColor;
            Console.Write("  [");
            Console.Write(new string('█', filled));
            Console.Write(new string('░', ProgressWidth - filled));
            Console.Write($"]  {progress * 100,5:F1}%");
            Console.ResetColor();

            if (!string.IsNullOrWhiteSpace(label))
                Console.Write($"  {label}");

            // Pad to clear any leftover characters from a longer previous label
            int padNeeded = Math.Max(0, 30 - label.Length);
            Console.Write(new string(' ', padNeeded));
            Console.Write('\r');
        }

        /// <summary>Move past the progress bar line when boot finishes.</summary>
        public void Complete(string finalMessage = "Engine ready.")
        {
            UpdateProgress(1.0f, finalMessage);
            Console.WriteLine();
            Console.WriteLine();
        }
    }
}
