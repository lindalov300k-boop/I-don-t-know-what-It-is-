using System;
using System.Collections.Generic;

namespace BADGE.Engine.Core
{
    public interface IEngineModule
    {
        string Name { get; }
        void Initialize();
        void Update(float deltaTime);
        void Shutdown();
    }

    public class ModuleSystem
    {
        private static ModuleSystem _instance;
        public static ModuleSystem Instance => _instance ??= new ModuleSystem();

        private readonly List<IEngineModule> _modules = new();
        private readonly Dictionary<string, IEngineModule> _moduleMap = new();

        public void Register(IEngineModule module)
        {
            if (_moduleMap.ContainsKey(module.Name)) return;
            _modules.Add(module);
            _moduleMap[module.Name] = module;
            Console.WriteLine($"[ModuleSystem] Registered: {module.Name}");
        }

        public T Get<T>(string name) where T : class, IEngineModule
            => _moduleMap.TryGetValue(name, out var m) ? m as T : null;

        public void InitializeAll()
        {
            foreach (var m in _modules) m.Initialize();
        }

        public void UpdateAll(float deltaTime)
        {
            foreach (var m in _modules) m.Update(deltaTime);
        }

        public void ShutdownAll()
        {
            for (int i = _modules.Count - 1; i >= 0; i--)
                _modules[i].Shutdown();
        }
    }
}
