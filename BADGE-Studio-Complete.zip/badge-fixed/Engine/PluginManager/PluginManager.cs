using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace BADGE.Engine.Core
{
    public interface IPlugin
    {
        string Id { get; }
        string Version { get; }
        string Author { get; }
        void OnLoad();
        void OnUnload();
    }

    public class PluginManager
    {
        private static PluginManager _instance;
        public static PluginManager Instance => _instance ??= new PluginManager();

        private readonly Dictionary<string, IPlugin> _plugins = new();
        private readonly string _pluginDirectory = "Plugins";

        public IReadOnlyDictionary<string, IPlugin> Loaded => _plugins;

        public void LoadFromDirectory()
        {
            if (!Directory.Exists(_pluginDirectory)) return;
            foreach (var dll in Directory.GetFiles(_pluginDirectory, "*.dll"))
            {
                try
                {
                    var asm = Assembly.LoadFrom(dll);
                    foreach (var type in asm.GetExportedTypes())
                    {
                        if (typeof(IPlugin).IsAssignableFrom(type) && !type.IsAbstract)
                        {
                            var plugin = (IPlugin)Activator.CreateInstance(type);
                            RegisterPlugin(plugin);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[PluginManager] Failed to load {dll}: {ex.Message}");
                }
            }
        }

        public void RegisterPlugin(IPlugin plugin)
        {
            if (_plugins.ContainsKey(plugin.Id))
            {
                Console.WriteLine($"[PluginManager] Plugin already loaded: {plugin.Id}");
                return;
            }
            _plugins[plugin.Id] = plugin;
            plugin.OnLoad();
            Console.WriteLine($"[PluginManager] Loaded plugin: {plugin.Id} v{plugin.Version} by {plugin.Author}");
        }

        public void UnloadPlugin(string id)
        {
            if (_plugins.TryGetValue(id, out var p))
            {
                p.OnUnload();
                _plugins.Remove(id);
                Console.WriteLine($"[PluginManager] Unloaded: {id}");
            }
        }

        public void UnloadAll()
        {
            foreach (var p in _plugins.Values) p.OnUnload();
            _plugins.Clear();
        }
    }
}
