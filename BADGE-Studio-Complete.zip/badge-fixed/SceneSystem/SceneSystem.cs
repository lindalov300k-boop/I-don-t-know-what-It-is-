// ============================================================
//  BADGE Engine – SceneSystem/SceneSystem.cs
//  Full Scene, SceneManager, Prefab system.
// ============================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using BADGE.Engine.Components;
using BADGE.Engine.Core;
using BADGE.Engine.Math;
using BADGE.Engine.Rendering;


namespace BADGE.Engine.Scene
{
    // ═══════════════════════════════════════════════════════
    //  Scene
    // ═══════════════════════════════════════════════════════
    public sealed class Scene
    {
        public string Name       { get; set; }
        public string Path       { get; set; } = string.Empty;
        public bool   IsLoaded   { get; private set; }
        public bool   IsDirty    { get; private set; }

        private readonly List<GameObject> _rootObjects = new();
        private readonly List<GameObject> _toAdd       = new();
        private readonly List<GameObject> _toRemove    = new();
        private readonly Dictionary<string, GameObject> _nameIndex = new();
        private readonly Dictionary<string, List<GameObject>> _tagIndex = new();

        public IReadOnlyList<GameObject> RootObjects => _rootObjects;

        public Scene(string name) { Name = name; }

        // ── GameObject management ─────────────────────────
        public void AddGameObject(GameObject go)
        {
            if (go.Parent is null)
                _toAdd.Add(go);
            go.Scene = this;
            _nameIndex[go.Name] = go;
            if (!_tagIndex.ContainsKey(go.Tag)) _tagIndex[go.Tag] = new();
            _tagIndex[go.Tag].Add(go);
        }

        public void RemoveGameObject(GameObject go)
        {
            _toRemove.Add(go);
            _nameIndex.Remove(go.Name);
            _tagIndex.GetValueOrDefault(go.Tag)?.Remove(go);
        }

        public GameObject? FindGameObject(string name) =>
            _nameIndex.TryGetValue(name, out var go) ? go : null;

        public IEnumerable<GameObject> FindGameObjectsWithTag(string tag) =>
            _tagIndex.TryGetValue(tag, out var list) ? list : Enumerable.Empty<GameObject>();

        public IEnumerable<T> FindObjectsOfType<T>() where T : Component =>
            _rootObjects.SelectMany(g => g.GetComponents<T>());

        public T? FindObjectOfType<T>() where T : Component =>
            FindObjectsOfType<T>().FirstOrDefault();

        // ── Lifecycle ─────────────────────────────────────
        internal void OnLoad()
        {
            IsLoaded = true;
            foreach (var go in _rootObjects) go.Start();
        }

        internal void Update(float dt)
        {
            FlushQueues();
            foreach (var go in _rootObjects) go.Update(dt);
        }

        internal void FixedUpdate(float dt)
        {
            foreach (var go in _rootObjects) go.FixedUpdate(dt);
        }

        internal void LateUpdate(float dt)
        {
            foreach (var go in _rootObjects) go.LateUpdate(dt);
            IsDirty = false;
        }

        internal void Render(RenderPipeline r)
        {
            foreach (var go in _rootObjects) go.Render(r);
        }

        internal void OnUnload()
        {
            foreach (var go in _rootObjects) go.Destroy();
            _rootObjects.Clear(); _nameIndex.Clear(); _tagIndex.Clear();
            IsLoaded = false;
        }

        private void FlushQueues()
        {
            foreach (var go in _toRemove) { _rootObjects.Remove(go); go.Destroy(); }
            _toRemove.Clear();
            foreach (var go in _toAdd)    { _rootObjects.Add(go); go.Start(); IsDirty = true; }
            _toAdd.Clear();
        }

        // ── Serialization ─────────────────────────────────
        public void Save(string path)
        {
            var data = new SceneData
            {
                Name    = Name,
                Objects = _rootObjects.Select(SerializeGameObject).ToList()
            };
            System.IO.File.WriteAllText(path, System.Text.Json.JsonSerializer.Serialize(data, new System.Text.Json.JsonSerializerOptions{WriteIndented=true}));
            Path  = path;
            IsDirty = false;
            Console.WriteLine($"[Scene] Saved '{Name}' → {path}");
        }

        public static Scene Load(string path)
        {
            var json = System.IO.File.ReadAllText(path);
            var data = System.Text.Json.JsonSerializer.Deserialize<SceneData>(json)!;
            var scene = new Scene(data.Name) { Path = path };
            foreach (var od in data.Objects)
                scene.AddGameObject(DeserializeGameObject(od));
            Console.WriteLine($"[Scene] Loaded '{data.Name}' from {path}");
            return scene;
        }

        private static GameObjectData SerializeGameObject(GameObject go) => new()
        {
            Name = go.Name, Tag = go.Tag, Layer = go.Layer,
            Position = go.Transform.LocalPosition,
            Rotation = go.Transform.LocalRotation,
            Scale    = go.Transform.LocalScale,
            Children = go.Children.Select(c => SerializeGameObject(c)).ToList()
        };

        private static GameObject DeserializeGameObject(GameObjectData d)
        {
            var go = new GameObject(d.Name) { Tag = d.Tag, Layer = d.Layer };
            go.Transform.LocalPosition = d.Position;
            go.Transform.LocalRotation = d.Rotation;
            go.Transform.LocalScale    = d.Scale;
            foreach (var cd in d.Children)
            {
                var child = DeserializeGameObject(cd);
                child.Transform.SetParent(go.Transform);
            }
            return go;
        }

        private record SceneData { public string Name=""; public List<GameObjectData> Objects = new(); }
        private record GameObjectData
        {
            public string Name=""; public string Tag="Untagged"; public int Layer;
            public Vector3 Position, Scale; public Quaternion Rotation;
            public List<GameObjectData> Children = new();
        }
    }

    // ═══════════════════════════════════════════════════════
    //  SceneManager
    // ═══════════════════════════════════════════════════════
    public sealed class SceneManager
    {
        public Scene? ActiveScene { get; private set; }
        public IReadOnlyList<Scene> LoadedScenes => _loadedScenes;

        private readonly List<Scene>               _loadedScenes  = new();
        private readonly HashSet<GameObject>       _dontDestroySet= new();
        private readonly Dictionary<string, Scene> _sceneRegistry = new();

        public event Action<Scene>? OnSceneLoaded;
        public event Action<Scene>? OnSceneUnloaded;

        // ── Load ─────────────────────────────────────────
        public Scene LoadScene(string name, LoadSceneMode mode = LoadSceneMode.Single)
        {
            if (mode == LoadSceneMode.Single)
                UnloadAll();

            Scene scene;
            if (_sceneRegistry.TryGetValue(name, out var s))
                scene = s;
            else if (System.IO.File.Exists(name))
                scene = Scene.Load(name);
            else
                scene = new Scene(name);

            _loadedScenes.Add(scene);
            if (mode == LoadSceneMode.Single || ActiveScene is null)
                ActiveScene = scene;

            RestoreDontDestroyObjects(scene);
            scene.OnLoad();
            OnSceneLoaded?.Invoke(scene);
            EngineKernel.Instance.Events.EmitImmediate("scene.loaded", name);
            Console.WriteLine($"[SceneManager] Loaded scene '{name}'");
            return scene;
        }

        public async Task<Scene> LoadSceneAsync(string name, LoadSceneMode mode = LoadSceneMode.Single)
        {
            await Task.Yield();
            return LoadScene(name, mode);
        }

        public void UnloadScene(Scene scene)
        {
            PreserveDontDestroy(scene);
            scene.OnUnload();
            _loadedScenes.Remove(scene);
            if (ActiveScene == scene)
                ActiveScene = _loadedScenes.LastOrDefault();
            OnSceneUnloaded?.Invoke(scene);
            EngineKernel.Instance.Events.EmitImmediate("scene.unloaded", scene.Name);
        }

        public void RegisterScene(string name, Scene scene) => _sceneRegistry[name] = scene;

        // ── DontDestroyOnLoad ────────────────────────────
        public void DontDestroyOnLoad(GameObject go)
        {
            _dontDestroySet.Add(go);
        }

        private void PreserveDontDestroy(Scene scene)
        {
            foreach (var go in scene.RootObjects)
                if (_dontDestroySet.Contains(go))
                    scene.RemoveGameObject(go);
        }

        private void RestoreDontDestroyObjects(Scene scene)
        {
            foreach (var go in _dontDestroySet)
                scene.AddGameObject(go);
        }

        private void UnloadAll()
        {
            foreach (var s in _loadedScenes.ToList()) UnloadScene(s);
        }

        // ── Helpers ───────────────────────────────────────
        public GameObject? Find(string name) => ActiveScene?.FindGameObject(name);

        public IEnumerable<T> FindObjectsOfType<T>() where T : Component =>
            _loadedScenes.SelectMany(s => s.FindObjectsOfType<T>());

        public T? FindObjectOfType<T>() where T : Component =>
            FindObjectsOfType<T>().FirstOrDefault();

        public static void MoveGameObjectToScene(GameObject go, Scene scene)
        {
            go.Scene?.RemoveGameObject(go);
            scene.AddGameObject(go);
        }
    }

    public enum LoadSceneMode { Single, Additive }

    // ═══════════════════════════════════════════════════════
    //  Prefab System
    // ═══════════════════════════════════════════════════════
    public sealed class Prefab
    {
        public string Name     { get; }
        public string AssetPath{ get; }

        private readonly Func<GameObject> _factory;

        public Prefab(string name, Func<GameObject> factory, string assetPath = "")
        {
            Name = name; _factory = factory; AssetPath = assetPath;
        }

        public GameObject Instantiate(Vector3 position = default, Quaternion? rotation = null,
                                      Transform? parent = null)
        {
            var go = _factory();
            go.Transform.LocalPosition = position;
            go.Transform.LocalRotation = rotation ?? Quaternion.Identity;
            if (parent is not null) go.Transform.SetParent(parent);
            EngineKernel.Instance.SceneManager.ActiveScene?.AddGameObject(go);
            return go;
        }

        // Load from JSON file (same format as scene serialization)
        public static Prefab FromFile(string path)
        {
            var name = System.IO.Path.GetFileNameWithoutExtension(path);
            return new Prefab(name, () =>
            {
                var json = System.IO.File.ReadAllText(path);
                var go = System.Text.Json.JsonSerializer.Deserialize<GameObject>(json) ?? new GameObject(name);
                return go;
            }, path);
        }

        // Save to file
        public void Save(GameObject template, string path)
        {
            System.IO.File.WriteAllText(path, System.Text.Json.JsonSerializer.Serialize(template, new System.Text.Json.JsonSerializerOptions{WriteIndented=true}));
        }
    }

    // ═══════════════════════════════════════════════════════
    //  Object-level static helpers (Unity compat)
    // ═══════════════════════════════════════════════════════
    public static class Object
    {
        public static void Destroy(GameObject go, float delay = 0f)
        {
            if (delay > 0)
            {
                Task.Delay((int)(delay * 1000)).ContinueWith(_ =>
                    GameObject.Destroy(go));
            }
            else
            {
                GameObject.Destroy(go);
            }
        }

        public static void DontDestroyOnLoad(GameObject go) =>
            EngineKernel.Instance.SceneManager.DontDestroyOnLoad(go);

        public static T? FindObjectOfType<T>() where T : Component =>
            EngineKernel.Instance.SceneManager.FindObjectOfType<T>();

        public static IEnumerable<T> FindObjectsOfType<T>() where T : Component =>
            EngineKernel.Instance.SceneManager.FindObjectsOfType<T>();
    }
}

    // ═══════════════════════════════════════════════════════
    //  Layer System
    // ═══════════════════════════════════════════════════════
    public static class LayerMask
    {
        public const int MaxLayers = 32;
        private static readonly string[] _names = new string[MaxLayers];

        static LayerMask()
        {
            _names[0]  = "Default";
            _names[1]  = "TransparentFX";
            _names[2]  = "IgnoreRaycast";
            _names[3]  = "Water";
            _names[4]  = "UI";
            _names[5]  = "Player";
            _names[6]  = "Enemy";
            _names[7]  = "Environment";
            _names[8]  = "Trigger";
            _names[9]  = "Projectile";
        }

        public static int    GetMask  (params string[] layers) =>
            layers.Aggregate(0, (m, l) => { int i = NameToLayer(l); return i >= 0 ? m | (1 << i) : m; });

        public static int    NameToLayer(string name)
        {
            for (int i = 0; i < MaxLayers; i++)
                if (_names[i] == name) return i;
            return -1;
        }

        public static string LayerToName(int layer) =>
            (layer >= 0 && layer < MaxLayers) ? (_names[layer] ?? "") : "";

        public static bool   Contains(int mask, int layer) => (mask & (1 << layer)) != 0;
        public static int    Everything  => ~0;
        public static int    Nothing     => 0;

        public static void SetLayerName(int layer, string name)
        {
            if (layer >= 0 && layer < MaxLayers)
                _names[layer] = name;
        }

        // Collision matrix
        private static readonly bool[,] _collisions = new bool[MaxLayers, MaxLayers];
        static void InitCollisions() { for(int i=0;i<MaxLayers;i++) for(int j=0;j<MaxLayers;j++) _collisions[i,j]=true; }

        public static void SetLayerCollision(int a, int b, bool enabled)
        {
            if (a < MaxLayers && b < MaxLayers) { _collisions[a,b] = enabled; _collisions[b,a] = enabled; }
        }
        public static bool GetLayerCollision(int a, int b) =>
            a < MaxLayers && b < MaxLayers && _collisions[a,b];
    }

    // ═══════════════════════════════════════════════════════
    //  Level Streaming
    //  Loads/unloads sub-scenes (chunks/sectors) dynamically
    //  based on proximity to a focus point (e.g. camera/player).
    // ═══════════════════════════════════════════════════════
    public sealed class LevelStreamingManager
    {
        public sealed class StreamingLevel
        {
            public string   Name         { get; set; } = "";
            public string   Path         { get; set; } = "";
            public Vector3  Origin       { get; set; }   // world-space anchor
            public float    LoadRadius   { get; set; } = 100f;
            public float    UnloadRadius { get; set; } = 150f;
            public bool     IsLoaded     { get; internal set; }
            public bool     IsLoading    { get; internal set; }
            public bool     IsUnloading  { get; internal set; }
            public Scene?   Scene        { get; internal set; }
            public bool     AlwaysLoaded { get; set; }
            public float    Priority     { get; set; } = 1f;
        }

        public event Action<StreamingLevel>? OnLevelLoaded;
        public event Action<StreamingLevel>? OnLevelUnloaded;

        private readonly List<StreamingLevel>           _levels       = new();
        private readonly Dictionary<string, Task>       _loadTasks    = new();
        private readonly SceneManager                   _sceneManager;
        private Vector3                                 _focusPoint;

        public IReadOnlyList<StreamingLevel> Levels => _levels;

        public LevelStreamingManager(SceneManager sceneManager)
        {
            _sceneManager = sceneManager;
        }

        public void RegisterLevel(StreamingLevel level) => _levels.Add(level);

        public void UnregisterLevel(string name)
        {
            var lvl = _levels.FirstOrDefault(l => l.Name == name);
            if (lvl != null) { UnloadLevel(lvl); _levels.Remove(lvl); }
        }

        public void SetFocusPoint(Vector3 worldPos)
        {
            _focusPoint = worldPos;
        }

        public void Update()
        {
            foreach (var lvl in _levels)
            {
                if (lvl.AlwaysLoaded) { EnsureLoaded(lvl); continue; }

                float dist = Distance(_focusPoint, lvl.Origin);

                if (!lvl.IsLoaded && !lvl.IsLoading && dist <= lvl.LoadRadius)
                    _ = LoadLevelAsync(lvl);
                else if (lvl.IsLoaded && !lvl.IsUnloading && dist > lvl.UnloadRadius)
                    UnloadLevel(lvl);
            }
        }

        private void EnsureLoaded(StreamingLevel lvl)
        {
            if (!lvl.IsLoaded && !lvl.IsLoading)
                _ = LoadLevelAsync(lvl);
        }

        private async Task LoadLevelAsync(StreamingLevel lvl)
        {
            if (lvl.IsLoading || lvl.IsLoaded) return;
            lvl.IsLoading = true;
            Console.WriteLine($"[Streaming] Loading '{lvl.Name}'…");

            try
            {
                await Task.Yield(); // simulate async I/O frame gap
                var scene = await _sceneManager.LoadSceneAsync(lvl.Path, LoadSceneMode.Additive);
                lvl.Scene    = scene;
                lvl.IsLoaded = true;
                OnLevelLoaded?.Invoke(lvl);
                Console.WriteLine($"[Streaming] '{lvl.Name}' loaded.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Streaming] Failed to load '{lvl.Name}': {ex.Message}");
            }
            finally { lvl.IsLoading = false; }
        }

        private void UnloadLevel(StreamingLevel lvl)
        {
            if (!lvl.IsLoaded || lvl.IsUnloading) return;
            lvl.IsUnloading = true;
            Console.WriteLine($"[Streaming] Unloading '{lvl.Name}'…");
            if (lvl.Scene != null) _sceneManager.UnloadScene(lvl.Scene);
            lvl.Scene      = null;
            lvl.IsLoaded   = false;
            lvl.IsUnloading = false;
            OnLevelUnloaded?.Invoke(lvl);
            Console.WriteLine($"[Streaming] '{lvl.Name}' unloaded.");
        }

        // ── Grid-based sector streaming helper ───────────
        public static List<StreamingLevel> CreateGrid(
            int columns, int rows, float sectorSize,
            Func<int, int, string> nameFn, Func<int, int, string> pathFn,
            float loadRadius = -1f, float unloadRadius = -1f)
        {
            float lr = loadRadius  > 0 ? loadRadius  : sectorSize * 1.5f;
            float ur = unloadRadius> 0 ? unloadRadius: sectorSize * 2.0f;
            var levels = new List<StreamingLevel>();
            for (int row = 0; row < rows; row++)
            for (int col = 0; col < columns; col++)
                levels.Add(new StreamingLevel
                {
                    Name         = nameFn(col, row),
                    Path         = pathFn(col, row),
                    Origin       = new Vector3(col * sectorSize, 0, row * sectorSize),
                    LoadRadius   = lr,
                    UnloadRadius = ur
                });
            return levels;
        }

        private static float Distance(Vector3 a, Vector3 b)
        {
            float dx=a.X-b.X, dy=a.Y-b.Y, dz=a.Z-b.Z;
            return MathF.Sqrt(dx*dx+dy*dy+dz*dz);
        }
    }
}
