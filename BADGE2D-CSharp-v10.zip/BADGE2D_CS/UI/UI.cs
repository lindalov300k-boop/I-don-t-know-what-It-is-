// =============================================================================
// UI/UI.cs  —  Phase 9: UICanvas, 9 widget types, anchor layout, UIRenderer
// =============================================================================
using System;
using System.Collections.Generic;
using BADGE2D.Core;
using BADGE2D.Math;
using BADGE2D.Renderer;

namespace BADGE2D.UI
{
    // ─────────────────────────────────────────────────────────────────────────
    // Anchor + Layout
    // ─────────────────────────────────────────────────────────────────────────
    public enum Anchor
    {
        TopLeft, TopCenter, TopRight,
        MiddleLeft, MiddleCenter, MiddleRight,
        BottomLeft, BottomCenter, BottomRight,
        Stretch
    }

    public struct UILayout
    {
        public Anchor  Anchor;
        public Vector2 Offset;   // from anchor point
        public Vector2 Size;
        public float   Left, Right, Top, Bottom;   // used for Stretch

        public Rect2D Compute(Rect2D parentRect) {
            float pw = parentRect.W, ph = parentRect.H;
            float px = parentRect.X, py = parentRect.Y;

            if (Anchor == Anchor.Stretch)
                return new Rect2D(px + Left, py + Bottom, pw - Left - Right, ph - Bottom - Top);

            float ax = Anchor switch {
                Anchor.TopLeft or Anchor.MiddleLeft or Anchor.BottomLeft     => px,
                Anchor.TopCenter or Anchor.MiddleCenter or Anchor.BottomCenter => px + pw*0.5f,
                _                                                              => px + pw
            };
            float ay = Anchor switch {
                Anchor.BottomLeft or Anchor.BottomCenter or Anchor.BottomRight => py,
                Anchor.MiddleLeft or Anchor.MiddleCenter or Anchor.MiddleRight  => py + ph*0.5f,
                _                                                               => py + ph
            };
            float cx = Anchor switch {
                Anchor.TopLeft or Anchor.MiddleLeft or Anchor.BottomLeft       => 0,
                Anchor.TopCenter or Anchor.MiddleCenter or Anchor.BottomCenter  => Size.X*0.5f,
                _                                                               => Size.X
            };
            float cy = Anchor switch {
                Anchor.BottomLeft or Anchor.BottomCenter or Anchor.BottomRight => 0,
                Anchor.MiddleLeft or Anchor.MiddleCenter or Anchor.MiddleRight  => Size.Y*0.5f,
                _                                                               => Size.Y
            };
            return new Rect2D(ax + Offset.X - cx, ay + Offset.Y - cy, Size.X, Size.Y);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // UIElement  —  base class for all widgets
    // ─────────────────────────────────────────────────────────────────────────
    public abstract class UIElement
    {
        public string          Name         { get; set; } = "";
        public UILayout        Layout       { get; set; }
        public bool            Visible      { get; set; } = true;
        public bool            Interactable { get; set; } = true;
        public int             RenderLayer  { get; set; } = 0;
        public Color           Tint         { get; set; } = Color.White;
        public float           Alpha        { get; set; } = 1f;
        public UIElement?      Parent       { get; internal set; }
        public List<UIElement> Children     { get; }      = new();

        protected Rect2D _screenRect;
        public    Rect2D ScreenRect => _screenRect;

        public void AddChild(UIElement child) {
            child.Parent = this;
            Children.Add(child);
        }

        public void RemoveChild(UIElement child) {
            child.Parent = null;
            Children.Remove(child);
        }

        public void Layout_(Rect2D parentRect) {
            _screenRect = Layout.Compute(parentRect);
            foreach (var child in Children) child.Layout_(_screenRect);
        }

        public abstract void Render(UIRenderer renderer);

        public virtual void OnClick()         {}
        public virtual void OnHover()         {}
        public virtual void OnFocusGain()     {}
        public virtual void OnFocusLose()     {}
        public virtual void FeedChar(char c)  {}
        public virtual void FeedKey (Input.Key k) {}

        public IEnumerable<T> Each<T>() where T : UIElement {
            if (this is T t) yield return t;
            foreach (var child in Children)
                foreach (var sub in child.Each<T>()) yield return sub;
        }

        protected Color TintWithAlpha => Tint.WithAlpha(Tint.A * Alpha);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Widget 1: UIPanel
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class UIPanel : UIElement
    {
        public Color     BackgroundColor { get; set; } = new Color(0.15f, 0.15f, 0.15f, 0.9f);
        public float     BorderRadius    { get; set; } = 4f;
        public Color     BorderColor     { get; set; } = new Color(0.5f, 0.5f, 0.5f, 0.8f);
        public float     BorderWidth     { get; set; } = 1f;
        public Texture2D? Background     { get; set; }

        public override void Render(UIRenderer r) {
            if (!Visible) return;
            if (Background != null)
                r.DrawImage(_screenRect, Background, TintWithAlpha);
            else
                r.DrawRectFill(_screenRect, BackgroundColor.WithAlpha(BackgroundColor.A * Alpha));
            if (BorderWidth > 0)
                r.DrawRect(_screenRect, BorderColor.WithAlpha(BorderColor.A * Alpha), BorderWidth);
            foreach (var child in Children) child.Render(r);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Widget 2: UILabel
    // ─────────────────────────────────────────────────────────────────────────
    public enum TextAlign { Left, Center, Right }

    public sealed class UILabel : UIElement
    {
        public string     Text      { get; set; } = "";
        public Color      TextColor { get; set; } = Color.White;
        public float      FontSize  { get; set; } = 16f;
        public TextAlign  Align     { get; set; } = TextAlign.Left;
        public bool       Shadow    { get; set; }

        public override void Render(UIRenderer r) {
            if (!Visible) return;
            r.DrawText(_screenRect, Text, TextColor.WithAlpha(TextColor.A * Alpha), FontSize, Align);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Widget 3: UIButton
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class UIButton : UIElement
    {
        public string  Text            { get; set; } = "Button";
        public Color   NormalColor     { get; set; } = new Color(0.25f, 0.45f, 0.75f);
        public Color   HoverColor      { get; set; } = new Color(0.35f, 0.55f, 0.85f);
        public Color   PressedColor    { get; set; } = new Color(0.15f, 0.35f, 0.65f);
        public Color   DisabledColor   { get; set; } = new Color(0.4f,  0.4f,  0.4f);
        public Color   TextColor       { get; set; } = Color.White;
        public float   FontSize        { get; set; } = 14f;
        public Texture2D? Icon         { get; set; }

        public event Action? Clicked;

        private bool _hovered, _pressed;

        public override void OnClick()  { if (Interactable) { _pressed = false; Clicked?.Invoke(); } }
        public override void OnHover()  => _hovered = true;

        public override void Render(UIRenderer r) {
            if (!Visible) return;
            var col = !Interactable ? DisabledColor
                    : _pressed      ? PressedColor
                    : _hovered      ? HoverColor : NormalColor;
            r.DrawRectFill(_screenRect, col.WithAlpha(col.A * Alpha));
            r.DrawText(_screenRect, Text, TextColor.WithAlpha(TextColor.A * Alpha), FontSize, TextAlign.Center);
            _hovered = false;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Widget 4: UIImage
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class UIImage : UIElement
    {
        public Texture2D? Texture  { get; set; }
        public Rect2D?    UvRect   { get; set; }
        public bool       PreserveAspect { get; set; } = true;

        public override void Render(UIRenderer r) {
            if (!Visible || Texture == null) return;
            r.DrawImage(_screenRect, Texture, TintWithAlpha, UvRect);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Widget 5: UISlider
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class UISlider : UIElement
    {
        public float Min     { get; set; }
        public float Max     { get; set; } = 1f;
        public float Value   { get; set; } = 0.5f;
        public bool  Vertical{ get; set; }
        public Color TrackColor  { get; set; } = new Color(0.3f, 0.3f, 0.3f);
        public Color FillColor   { get; set; } = new Color(0.3f, 0.6f, 0.9f);
        public Color HandleColor { get; set; } = Color.White;

        public event Action<float>? OnValueChanged;

        public float Normalized => Max > Min ? (Value - Min) / (Max - Min) : 0f;

        public override void Render(UIRenderer r) {
            if (!Visible) return;
            r.DrawRectFill(_screenRect, TrackColor.WithAlpha(Alpha));
            float t = Normalized;
            var fill = Vertical
                ? new Rect2D(_screenRect.X, _screenRect.Y, _screenRect.W, _screenRect.H * t)
                : new Rect2D(_screenRect.X, _screenRect.Y, _screenRect.W * t, _screenRect.H);
            r.DrawRectFill(fill, FillColor.WithAlpha(Alpha));
            // Handle
            float hx = Vertical ? _screenRect.X + _screenRect.W * 0.5f - 8f : _screenRect.X + _screenRect.W * t - 8f;
            float hy = Vertical ? _screenRect.Y + _screenRect.H * t - 8f     : _screenRect.Y + _screenRect.H * 0.5f - 8f;
            r.DrawRectFill(new Rect2D(hx, hy, 16, 16), HandleColor.WithAlpha(Alpha));
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Widget 6: UICheckbox
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class UICheckbox : UIElement
    {
        public bool   Checked  { get; set; }
        public string Label    { get; set; } = "";
        public Color  CheckColor { get; set; } = new Color(0.2f, 0.7f, 0.2f);

        public event Action<bool>? OnChanged;

        public override void OnClick() {
            if (!Interactable) return;
            Checked = !Checked;
            OnChanged?.Invoke(Checked);
        }

        public override void Render(UIRenderer r) {
            if (!Visible) return;
            float sz = MathF.Min(_screenRect.W, _screenRect.H);
            var box = new Rect2D(_screenRect.X, _screenRect.Y + (_screenRect.H - sz) * 0.5f, sz, sz);
            r.DrawRect(box, Color.White.WithAlpha(Alpha), 2f);
            if (Checked) r.DrawRectFill(box.Inflate(-4), CheckColor.WithAlpha(Alpha));
            if (!string.IsNullOrEmpty(Label)) {
                var labelRect = new Rect2D(_screenRect.X + sz + 6, _screenRect.Y, _screenRect.W - sz - 6, _screenRect.H);
                r.DrawText(labelRect, Label, Color.White.WithAlpha(Alpha), 14f, TextAlign.Left);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Widget 7: UITextInput
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class UITextInput : UIElement
    {
        public string   Text        { get; set; } = "";
        public string   Placeholder { get; set; } = "";
        public int      MaxLength   { get; set; } = 256;
        public bool     Password    { get; set; }
        public bool     Focused     { get; private set; }
        public Color    BackColor   { get; set; } = new Color(0.1f, 0.1f, 0.1f, 0.9f);
        public Color    BorderActive { get; set; } = new Color(0.4f, 0.7f, 1f);
        public Color    BorderNormal { get; set; } = new Color(0.4f, 0.4f, 0.4f);

        public event Action<string>? OnSubmit;
        public event Action<string>? OnChanged;

        private float _cursorBlink;

        public override void OnFocusGain() => Focused = true;
        public override void OnFocusLose() => Focused = false;

        public override void FeedChar(char c) {
            if (!Focused || !Interactable) return;
            if (c == '\b') { if (Text.Length > 0) { Text = Text[..^1]; OnChanged?.Invoke(Text); } return; }
            if (c == '\r' || c == '\n') { OnSubmit?.Invoke(Text); return; }
            if (Text.Length < MaxLength) { Text += c; OnChanged?.Invoke(Text); }
        }

        public override void FeedKey(Input.Key k) {
            if (!Focused) return;
            if (k == Input.Key.Backspace && Text.Length > 0) { Text = Text[..^1]; OnChanged?.Invoke(Text); }
            else if (k == Input.Key.Enter || k == Input.Key.Enter) OnSubmit?.Invoke(Text);
        }

        public override void Render(UIRenderer r) {
            if (!Visible) return;
            r.DrawRectFill(_screenRect, BackColor.WithAlpha(Alpha));
            r.DrawRect(_screenRect, (Focused ? BorderActive : BorderNormal).WithAlpha(Alpha), Focused ? 2f : 1f);
            string display = Password ? new string('•', Text.Length) : Text;
            string shown   = string.IsNullOrEmpty(display) ? Placeholder : display;
            var    col     = string.IsNullOrEmpty(display) ? new Color(0.5f,0.5f,0.5f,Alpha) : Color.White.WithAlpha(Alpha);
            var    inner   = _screenRect.Inflate(-4);
            r.DrawText(inner, shown, col, 14f, TextAlign.Left);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Widget 8: UIProgressBar
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class UIProgressBar : UIElement
    {
        public float Value        { get; set; } = 0.5f;   // 0..1
        public Color TrackColor   { get; set; } = new Color(0.2f, 0.2f, 0.2f);
        public Color FillColor    { get; set; } = new Color(0.2f, 0.6f, 0.2f);
        public bool  ShowLabel    { get; set; } = true;
        public string? LabelFmt  { get; set; }   // e.g. "{0:P0}"

        public override void Render(UIRenderer r) {
            if (!Visible) return;
            r.DrawRectFill(_screenRect, TrackColor.WithAlpha(Alpha));
            var fill = new Rect2D(_screenRect.X, _screenRect.Y, _screenRect.W * Value, _screenRect.H);
            r.DrawRectFill(fill, FillColor.WithAlpha(Alpha));
            if (ShowLabel) {
                string label = LabelFmt != null ? string.Format(LabelFmt, Value) : $"{Value:P0}";
                r.DrawText(_screenRect, label, Color.White.WithAlpha(Alpha), 13f, TextAlign.Center);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Widget 9: UIScrollView
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class UIScrollView : UIElement
    {
        public float ScrollY      { get; set; }
        public float ContentHeight{ get; set; }
        public Color TrackColor   { get; set; } = new Color(0.1f, 0.1f, 0.1f);
        public Color ThumbColor   { get; set; } = new Color(0.5f, 0.5f, 0.5f);
        private const float ScrollbarWidth = 10f;

        public void Scroll(float delta) {
            ScrollY = MathUtils.Clamp(ScrollY + delta, 0f, MathF.Max(0f, ContentHeight - _screenRect.H));
        }

        public override void Render(UIRenderer r) {
            if (!Visible) return;
            r.DrawRectFill(_screenRect, TrackColor.WithAlpha(Alpha));
            r.PushScissor(_screenRect);
            foreach (var child in Children) {
                var orig = child.Layout;
                var mod = orig;
                mod.Offset = orig.Offset - new Vector2(0, ScrollY);
                child.Layout = mod;
                child.Layout_(_screenRect);
                child.Layout = orig;
                child.Render(r);
            }
            r.PopScissor();
            // Scrollbar
            float viewH = _screenRect.H;
            if (ContentHeight > viewH) {
                float ratio = viewH / ContentHeight;
                float thumbH = viewH * ratio;
                float thumbY = _screenRect.Y + (ScrollY / ContentHeight) * viewH;
                var trackRect = new Rect2D(_screenRect.Right - ScrollbarWidth, _screenRect.Y, ScrollbarWidth, viewH);
                var thumbRect = new Rect2D(trackRect.X + 2, thumbY, ScrollbarWidth - 4, thumbH);
                r.DrawRectFill(trackRect, new Color(0.2f,0.2f,0.2f,Alpha));
                r.DrawRectFill(thumbRect, ThumbColor.WithAlpha(Alpha));
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Rect2D extension for Inflate + Right property
    // ─────────────────────────────────────────────────────────────────────────
    internal static class Rect2DExt
    {
        public static Rect2D Inflate(this Rect2D r, float amount) =>
            new(r.X + amount, r.Y + amount, r.W - amount*2, r.H - amount*2);
        public static float Right(this Rect2D r) => r.X + r.W;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // UIRenderer  — wraps SpriteBatch for UI drawing
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class UIRenderer
    {
        private readonly SpriteBatch _batch;

        public UIRenderer(SpriteBatch batch) => _batch = batch;

        public void DrawRectFill(Rect2D r, Color c) =>
            _batch.DrawRectFill(r, c);

        public void DrawRect(Rect2D r, Color c, float thickness = 1f) =>
            _batch.DrawRect(r, c, thickness);

        public void DrawImage(Rect2D r, Texture2D tex, Color tint, Rect2D? uv = null) =>
            _batch.DrawSprite(r.Center, r.Size, tex, tint, uv);

        public void DrawText(Rect2D r, string text, Color color, float size, TextAlign align) {
            // Font rendering is pluggable — here we draw a placeholder rect
            // In production: SilkFont / FreeType / BitmapFont blit
            var textRect = new Rect2D(r.X + 2, r.Y + 2, r.W - 4, r.H - 4);
            _batch.DrawRect(textRect, color * 0.3f, 0.5f);
        }

        public void PushScissor(Rect2D r) =>
            _batch.PushScissor((int)r.X, (int)r.Y, (int)r.W, (int)r.H);

        public void PopScissor() => _batch.PopScissor();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // UICanvas  —  root container, processes input, dispatches focus
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class UICanvas : IModule
    {
        public string          Name        => "UICanvas";
        public ModuleInitOrder InitOrder   => ModuleInitOrder.UI;
        public bool            Initialized { get; private set; }

        private readonly List<UIElement>  _roots  = new();
        private          UIElement?       _focused;
        private          UIRenderer?      _renderer;

        public bool Initialize() {
            _renderer   = new UIRenderer(Renderer2D.Instance.Batch);
            Initialized = true;
            Log.Info("[UICanvas] Initialized");
            return true;
        }

        public void Shutdown() { _roots.Clear(); Initialized = false; }

        public T Add<T>(T element) where T : UIElement { _roots.Add(element); return element; }
        public void Remove(UIElement element) => _roots.Remove(element);
        public void Clear() => _roots.Clear();

        // ── Layout + Render ────────────────────────────────────────────────
        public void Layout(int viewportW, int viewportH) {
            var screen = new Rect2D(0, 0, viewportW, viewportH);
            foreach (var r in _roots) r.Layout_(screen);
        }

        public void Render() {
            if (_renderer == null) return;
            foreach (var r in _roots) if (r.Visible) r.Render(_renderer);
        }

        // ── Input dispatch ─────────────────────────────────────────────────
        public void FeedMousePos(float x, float y) {
            foreach (var r in _roots) HitTest(r, new Vector2(x, y));
        }

        public void FeedMouseClick(float x, float y) {
            var hit = FindHit(_roots, new Vector2(x, y));
            if (_focused != hit) { _focused?.OnFocusLose(); _focused = hit; _focused?.OnFocusGain(); }
            hit?.OnClick();
        }

        public void FeedChar(char c) {
            // Route to all focused TextInputs
            foreach (var r in _roots)
                foreach (var ti in r.Each<UITextInput>())
                    ti.FeedChar(c);
        }

        public void FeedKey(Input.Key k) {
            foreach (var r in _roots)
                foreach (var ti in r.Each<UITextInput>())
                    ti.FeedKey(k);
        }

        private static UIElement? FindHit(IEnumerable<UIElement> elements, Vector2 pos) {
            foreach (var e in elements) {
                if (!e.Visible || !e.Interactable) continue;
                if (e.ScreenRect.Contains(pos)) {
                    var deepChild = FindHit(e.Children, pos);
                    return deepChild ?? e;
                }
            }
            return null;
        }

        private static void HitTest(UIElement e, Vector2 pos) {
            if (!e.Visible) return;
            if (e.ScreenRect.Contains(pos)) e.OnHover();
            foreach (var child in e.Children) HitTest(child, pos);
        }

        public void Update(double _dt) {}
    }

    // Helper: Color * float scalar
    internal static class ColorExt {
        public static Color operator *(Color c, float s) => new(c.R*s, c.G*s, c.B*s, c.A*s);
    }
}
