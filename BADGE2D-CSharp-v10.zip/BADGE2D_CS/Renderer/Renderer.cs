// =============================================================================
// Renderer/Renderer.cs  —  Phase 2: OpenGL rendering via Silk.NET
// =============================================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using BADGE2D.Core;
using BADGE2D.Math;

// Silk.NET types used by name so callers don't need to reference Silk directly
// All GL calls are forwarded through the GL handle stored in RenderDevice.

namespace BADGE2D.Renderer
{
    // ─────────────────────────────────────────────────────────────────────────
    // RenderDevice  — owns the GL context handle + window
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class RenderDevice : IModule
    {
        public static RenderDevice Instance { get; } = new();
        private RenderDevice() {}

        public string          Name        => "RenderDevice";
        public ModuleInitOrder InitOrder   => ModuleInitOrder.Renderer;
        public bool            Initialized { get; private set; }

        // Silk.NET GL and Window objects (typed as dynamic to avoid hard dep at compile)
        // In real use: Silk.NET.OpenGL.GL and Silk.NET.Windowing.IWindow
        public dynamic? GL     { get; internal set; }
        public dynamic? Window { get; internal set; }

        public int ViewportWidth  { get; internal set; } = 1280;
        public int ViewportHeight { get; internal set; } = 720;

        public bool Initialize() { Initialized = true; return true; }
        public void Shutdown()   { Initialized = false; }

        public void Clear(Color color) {
            GL?.ClearColor(color.R, color.G, color.B, color.A);
            GL?.Clear(/* ColorBufferBit | DepthBufferBit */ 16640u);
        }

        public void SetViewport(int x, int y, int w, int h) {
            ViewportWidth  = w;
            ViewportHeight = h;
            GL?.Viewport(x, y, (uint)w, (uint)h);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Shader
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class Shader : IDisposable
    {
        private uint _program;

        public static Shader CreateSprite() => new(SpriteBatchVert, SpriteBatchFrag);
        public static Shader CreateLine()   => new(LineVert, LineFrag);

        public Shader(string vertSrc, string fragSrc) {
            var gl = RenderDevice.Instance.GL;
            if (gl == null) return;
            uint vert = CompileStage(gl, vertSrc, /* VertexShader */ 35633u);
            uint frag = CompileStage(gl, fragSrc, /* FragmentShader */ 35632u);
            _program  = gl.CreateProgram();
            gl.AttachShader(_program, vert);
            gl.AttachShader(_program, frag);
            gl.LinkProgram(_program);
            string log = gl.GetProgramInfoLog(_program);
            if (!string.IsNullOrWhiteSpace(log)) Log.Warning($"[Shader] Link: {log}");
            gl.DeleteShader(vert);
            gl.DeleteShader(frag);
        }

        private static uint CompileStage(dynamic gl, string src, uint type) {
            uint s = gl.CreateShader(type);
            gl.ShaderSource(s, src);
            gl.CompileShader(s);
            string log = gl.GetShaderInfoLog(s);
            if (!string.IsNullOrWhiteSpace(log)) Log.Warning($"[Shader] Compile: {log}");
            return s;
        }

        public void Use()                                    => RenderDevice.Instance.GL?.UseProgram(_program);
        public void SetInt    (string n, int   v)            => SetUniform(n, g => g.Uniform1(_program, g.GetUniformLocation(_program, n), v));
        public void SetFloat  (string n, float v)            => SetUniform(n, g => g.Uniform1(_program, g.GetUniformLocation(_program, n), v));
        public void SetVector2(string n, float x, float y)   => SetUniform(n, g => g.Uniform2(_program, g.GetUniformLocation(_program, n), x, y));
        public void SetVector4(string n, float x, float y, float z, float w) =>
            SetUniform(n, g => g.Uniform4(_program, g.GetUniformLocation(_program, n), x, y, z, w));
        public void SetMatrix4(string n, float[] m) {
            var gl = RenderDevice.Instance.GL;
            if (gl == null) return;
            int loc = gl.GetUniformLocation(_program, n);
            gl.UniformMatrix4(_program, (uint)loc, 1, false, m.AsSpan());
        }

        private void SetUniform(string name, Action<dynamic> fn) {
            var gl = RenderDevice.Instance.GL; if (gl == null) return; fn(gl); }

        public void Dispose() => RenderDevice.Instance.GL?.DeleteProgram(_program);

        // ── Built-in shader sources ────────────────────────────────────────
        public const string SpriteBatchVert = @"
#version 410 core
layout(location=0) in vec2  a_Pos;
layout(location=1) in vec2  a_UV;
layout(location=2) in vec4  a_Color;
layout(location=3) in float a_TexIdx;
out vec2  v_UV;
out vec4  v_Color;
out float v_TexIdx;
uniform mat4 u_VP;
void main(){
    gl_Position = u_VP * vec4(a_Pos, 0.0, 1.0);
    v_UV=a_UV; v_Color=a_Color; v_TexIdx=a_TexIdx;
}";

        public const string SpriteBatchFrag = @"
#version 410 core
in vec2  v_UV;
in vec4  v_Color;
in float v_TexIdx;
out vec4 fragColor;
uniform sampler2D u_Textures[16];
void main(){
    int idx = int(v_TexIdx);
    vec4 tex = texture(u_Textures[idx], v_UV);
    fragColor = tex * v_Color;
}";

        public const string LineVert = @"
#version 410 core
layout(location=0) in vec2 a_Pos;
layout(location=1) in vec4 a_Color;
out vec4 v_Color;
uniform mat4 u_VP;
void main(){ gl_Position = u_VP * vec4(a_Pos, 0.0, 1.0); v_Color=a_Color; }";

        public const string LineFrag = @"
#version 410 core
in vec4 v_Color;
out vec4 fragColor;
void main(){ fragColor = v_Color; }";
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Texture2D
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class Texture2D : IDisposable
    {
        public uint   GlId   { get; private set; }
        public int    Width  { get; private set; }
        public int    Height { get; private set; }
        public bool   Valid  => GlId != 0;
        public string Path   { get; private set; } = "";

        private static readonly Dictionary<string, Texture2D> _cache = new();

        public static Texture2D? Load(string path, bool useCache = true) {
            if (useCache && _cache.TryGetValue(path, out var cached)) return cached;
            var tex = new Texture2D();
            if (!tex.LoadFromFile(path)) return null;
            if (useCache) _cache[path] = tex;
            return tex;
        }

        public static Texture2D CreateWhite1x1() {
            var tex = new Texture2D();
            tex.LoadFromData(new byte[]{255,255,255,255}, 1, 1);
            return tex;
        }

        public bool LoadFromFile(string path) {
            // StbImageSharp: ImageResult.FromMemory / FromStream
            // For now, set up GL texture from raw RGBA bytes
            try {
                var fullPath = Platform.FileSystem.Resolve(path);
                if (!File.Exists(fullPath)) { Log.Error($"[Texture2D] File not found: {path}"); return false; }
                // stb_image via StbImageSharp
                using var stream = File.OpenRead(fullPath);
                var result = StbImageSharp.ImageResult.FromStream(stream,
                    StbImageSharp.ColorComponents.RedGreenBlueAlpha);
                LoadFromData(result.Data, result.Width, result.Height);
                Path = path;
                return true;
            } catch (Exception ex) {
                Log.Error($"[Texture2D] Load error '{path}': {ex.Message}");
                return false;
            }
        }

        public void LoadFromData(byte[] rgba, int width, int height) {
            var gl = RenderDevice.Instance.GL; if (gl == null) return;
            Width = width; Height = height;
            GlId = gl.GenTexture();
            gl.BindTexture(/* Texture2D */ 3553u, GlId);
            gl.TexImage2D(3553u, 0, /* RGBA8 */ 32856, (uint)width, (uint)height,
                0, /* RGBA */ 6408u, /* UByte */ 5121u, rgba.AsSpan());
            gl.TexParameter(3553u, /* MinFilter */ 10241u, /* Linear */ 9729);
            gl.TexParameter(3553u, /* MagFilter */ 10240u, /* Linear */ 9729);
            gl.TexParameter(3553u, /* WrapS */ 10242u, /* ClampToEdge */ 33071);
            gl.TexParameter(3553u, /* WrapT */ 10243u, /* ClampToEdge */ 33071);
            gl.BindTexture(3553u, 0u);
        }

        public void Bind(uint slot = 0) {
            var gl = RenderDevice.Instance.GL; if (gl == null) return;
            gl.ActiveTexture(33984u + slot);  // Texture0 + slot
            gl.BindTexture(3553u, GlId);
        }

        public void Dispose() {
            if (GlId != 0) { RenderDevice.Instance.GL?.DeleteTexture(GlId); GlId = 0; }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Camera2D
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class Camera2D
    {
        public Vector2 Position { get; set; } = Vector2.Zero;
        public float   Zoom     { get; set; } = 1f;
        public float   Rotation { get; set; } = 0f;
        public Color   ClearColor { get; set; } = new Color(0.1f,0.1f,0.15f);

        public Matrix4 GetViewProjection(int vpW, int vpH) {
            float hw = vpW * 0.5f / Zoom;
            float hh = vpH * 0.5f / Zoom;
            var proj = Matrix4.Ortho(Position.X - hw, Position.X + hw,
                                     Position.Y - hh, Position.Y + hh);
            if (MathF.Abs(Rotation) > 1e-6f)
                proj = Matrix4.Rotation2D(-Rotation) * proj;
            return proj;
        }

        public Vector2 ScreenToWorld(Vector2 screen, int vpW, int vpH) {
            float hw = vpW * 0.5f; float hh = vpH * 0.5f;
            var ndc = new Vector2((screen.X - hw) / hw, (screen.Y - hh) / hh);
            return new Vector2(
                Position.X + ndc.X * hw / Zoom,
                Position.Y - ndc.Y * hh / Zoom);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SpriteBatch  — batched quad renderer (up to 10 000 quads/batch)
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class SpriteBatch : IDisposable
    {
        private const int MaxQuads    = 10_000;
        private const int MaxVertices = MaxQuads * 4;
        private const int MaxIndices  = MaxQuads * 6;
        private const int MaxTexSlots = 16;

        // Vertex layout: pos.xy + uv.xy + color.rgba + texIdx  (9 floats)
        private const int FloatsPerVertex = 9;

        private readonly float[]    _verts     = new float[MaxVertices * FloatsPerVertex];
        private readonly uint[]     _texIds    = new uint[MaxTexSlots];
        private          int        _vtxCount  = 0;
        private          int        _quadCount = 0;
        private          int        _texSlot   = 0;

        private uint _vao, _vbo, _ibo;
        private readonly Shader    _shader;
        private readonly Texture2D _whiteTexture;

        public SpriteBatch() {
            _shader       = Shader.CreateSprite();
            _whiteTexture = Texture2D.CreateWhite1x1();
            InitGL();
        }

        private void InitGL() {
            var gl = RenderDevice.Instance.GL; if (gl == null) return;

            _vao = gl.GenVertexArray();
            gl.BindVertexArray(_vao);

            _vbo = gl.GenBuffer();
            gl.BindBuffer(/* ArrayBuffer */ 34962u, _vbo);
            gl.BufferData(34962u, (nuint)(MaxVertices * FloatsPerVertex * 4), 0, /* DynamicDraw */ 35048u);

            // Generate index buffer (static)
            var indices = new uint[MaxIndices];
            for (int i = 0, v = 0; i < MaxIndices; i += 6, v += 4) {
                indices[i+0] = (uint)v; indices[i+1] = (uint)(v+1); indices[i+2] = (uint)(v+2);
                indices[i+3] = (uint)v; indices[i+4] = (uint)(v+2); indices[i+5] = (uint)(v+3);
            }
            _ibo = gl.GenBuffer();
            gl.BindBuffer(/* ElementArrayBuffer */ 34963u, _ibo);
            gl.BufferData(34963u, indices.AsSpan(), /* StaticDraw */ 35044u);

            int stride = FloatsPerVertex * 4;
            gl.EnableVertexAttribArray(0); gl.VertexAttribPointer(0, 2, /* Float */5126u, false, (uint)stride, 0);
            gl.EnableVertexAttribArray(1); gl.VertexAttribPointer(1, 2, 5126u, false, (uint)stride, 2*4);
            gl.EnableVertexAttribArray(2); gl.VertexAttribPointer(2, 4, 5126u, false, (uint)stride, 4*4);
            gl.EnableVertexAttribArray(3); gl.VertexAttribPointer(3, 1, 5126u, false, (uint)stride, 8*4);
            gl.BindVertexArray(0);
        }

        public void Begin(Matrix4 viewProjection) {
            _shader.Use();
            _shader.SetMatrix4("u_VP", viewProjection.ToColumnMajor());
            // Bind texture samplers
            int[] slots = new int[MaxTexSlots];
            for (int i = 0; i < MaxTexSlots; i++) slots[i] = i;
            // gl.Uniform1iv("u_Textures", slots) — simplified
        }

        public void End() { Flush(); }

        private void Flush() {
            if (_quadCount == 0) return;
            var gl = RenderDevice.Instance.GL; if (gl == null) return;

            for (int i = 0; i < _texSlot; i++) {
                gl.ActiveTexture(33984u + (uint)i);
                gl.BindTexture(3553u, _texIds[i]);
            }

            gl.BindVertexArray(_vao);
            gl.BindBuffer(34962u, _vbo);
            gl.BufferSubData(34962u, 0, _verts.AsSpan(0, _vtxCount * FloatsPerVertex));
            gl.DrawElements(/* Triangles */ 4u, (uint)(_quadCount * 6), /* UnsignedInt */ 5125u, 0);
            gl.BindVertexArray(0);

            _quadCount = 0;
            _vtxCount  = 0;
            _texSlot   = 0;
        }

        // ── Public draw API ────────────────────────────────────────────────
        public void DrawQuad(Vector2 pos, Vector2 size, Color color, float rot = 0f) =>
            DrawQuad(pos, size, null, color, Vector2.Zero with { X=0.5f, Y=0.5f }, rot);

        public void DrawQuad(Vector2 pos, Vector2 size, Texture2D? tex, Color color,
                             Vector2? pivot = null, float rot = 0f,
                             Rect2D? uvRect = null) {
            if (_quadCount >= MaxQuads) Flush();

            var piv = pivot ?? new Vector2(0.5f, 0.5f);
            var uv  = uvRect ?? new Rect2D(0,0,1,1);
            var t   = tex ?? _whiteTexture;

            float texIdx = GetOrAddTexSlot(t.GlId);

            float x0 = -piv.X * size.X, y0 = -piv.Y * size.Y;
            float x1 =  (1f - piv.X) * size.X;
            float y1 =  (1f - piv.Y) * size.Y;

            // Quad corners (local space)
            Span<(float lx, float ly, float u, float v)> corners = stackalloc [] {
                (x0, y0, uv.X,      uv.Y),
                (x1, y0, uv.X+uv.W, uv.Y),
                (x1, y1, uv.X+uv.W, uv.Y+uv.H),
                (x0, y1, uv.X,      uv.Y+uv.H)
            };

            float c = MathF.Cos(rot), s = MathF.Sin(rot);
            int   vBase = _vtxCount * FloatsPerVertex;

            foreach (var (lx, ly, u, v) in corners) {
                float wx = rot != 0 ? lx*c - ly*s + pos.X : lx + pos.X;
                float wy = rot != 0 ? lx*s + ly*c + pos.Y : ly + pos.Y;
                _verts[vBase++] = wx;   _verts[vBase++] = wy;
                _verts[vBase++] = u;    _verts[vBase++] = v;
                _verts[vBase++] = color.R; _verts[vBase++] = color.G;
                _verts[vBase++] = color.B; _verts[vBase++] = color.A;
                _verts[vBase++] = texIdx;
                _vtxCount++;
            }
            _quadCount++;
        }

        public void DrawLine(Vector2 a, Vector2 b, Color color, float thickness = 1f) {
            Vector2 dir = (b - a).Normalized;
            Vector2 perp = new(-dir.Y * thickness * 0.5f, dir.X * thickness * 0.5f);
            DrawQuad(a + (b - a) * 0.5f, new Vector2(Vector2.Distance(a,b), thickness),
                     null, color, new Vector2(0.5f,0.5f),
                     MathF.Atan2(dir.Y, dir.X));
        }

        public void DrawRect(Rect2D r, Color color, float thickness = 1f) {
            DrawLine(new Vector2(r.X,    r.Y),    new Vector2(r.X+r.W, r.Y),    color, thickness);
            DrawLine(new Vector2(r.X+r.W,r.Y),    new Vector2(r.X+r.W, r.Y+r.H),color, thickness);
            DrawLine(new Vector2(r.X+r.W,r.Y+r.H),new Vector2(r.X,     r.Y+r.H),color, thickness);
            DrawLine(new Vector2(r.X,    r.Y+r.H),new Vector2(r.X,     r.Y),    color, thickness);
        }

        public void DrawRectFill(Rect2D r, Color color) =>
            DrawQuad(new Vector2(r.X + r.W*0.5f, r.Y + r.H*0.5f), new Vector2(r.W, r.H), color);

        public void DrawCircle(Vector2 center, float radius, Color color, int segments = 24) {
            float step = MathUtils.TwoPi / segments;
            for (int i = 0; i < segments; i++) {
                float a0 = i * step, a1 = (i+1) * step;
                var p0 = center + new Vector2(MathF.Cos(a0)*radius, MathF.Sin(a0)*radius);
                var p1 = center + new Vector2(MathF.Cos(a1)*radius, MathF.Sin(a1)*radius);
                DrawLine(p0, p1, color, 1f);
            }
        }

        public void DrawSprite(Vector2 pos, Vector2 size, Texture2D? tex,
                               Color tint, Rect2D? uvRect = null,
                               bool flipX = false, bool flipY = false,
                               float rotation = 0f, Vector2? pivot = null) {
            var uv = uvRect ?? new Rect2D(0,0,1,1);
            if (flipX) { uv.X = uv.X + uv.W; uv.W = -uv.W; }
            if (flipY) { uv.Y = uv.Y + uv.H; uv.H = -uv.H; }
            DrawQuad(pos, size, tex, tint, pivot, rotation, uv);
        }

        // Scissor clip support
        private readonly Stack<(int x,int y,int w,int h)> _scissorStack = new();
        public void PushScissor(int x, int y, int w, int h) {
            Flush();
            _scissorStack.Push((x,y,w,h));
            var gl = RenderDevice.Instance.GL; if (gl == null) return;
            gl.Enable(/* ScissorTest */ 3089u);
            gl.Scissor(x, y, (uint)w, (uint)h);
        }
        public void PopScissor() {
            Flush();
            _scissorStack.TryPop(out _);
            var gl = RenderDevice.Instance.GL; if (gl == null) return;
            if (_scissorStack.Count == 0) gl.Disable(3089u);
            else { var (x,y,w,h) = _scissorStack.Peek(); gl.Scissor(x,y,(uint)w,(uint)h); }
        }

        private float GetOrAddTexSlot(uint id) {
            for (int i = 0; i < _texSlot; i++) if (_texIds[i] == id) return i;
            if (_texSlot >= MaxTexSlots) Flush();
            _texIds[_texSlot] = id;
            return _texSlot++;
        }

        public void Dispose() {
            _shader.Dispose();
            _whiteTexture.Dispose();
            var gl = RenderDevice.Instance.GL; if (gl == null) return;
            gl.DeleteVertexArray(_vao);
            gl.DeleteBuffer(_vbo);
            gl.DeleteBuffer(_ibo);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Framebuffer
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class Framebuffer : IDisposable
    {
        private uint _fbo, _colorTex, _rbo;
        public  int  Width  { get; private set; }
        public  int  Height { get; private set; }
        public  uint ColorTextureId => _colorTex;

        public Framebuffer(int width, int height) { Resize(width, height); }

        public void Resize(int w, int h) {
            Width = w; Height = h;
            var gl = RenderDevice.Instance.GL; if (gl == null) return;
            if (_fbo != 0) { gl.DeleteFramebuffer(_fbo); gl.DeleteTexture(_colorTex); gl.DeleteRenderbuffer(_rbo); }
            _fbo      = gl.GenFramebuffer();
            _colorTex = gl.GenTexture();
            _rbo      = gl.GenRenderbuffer();
            gl.BindFramebuffer(/* Framebuffer */ 36160u, _fbo);
            gl.BindTexture(3553u, _colorTex);
            gl.TexImage2D(3553u, 0, 32856, (uint)w, (uint)h, 0, 6408u, 5121u, Span<byte>.Empty);
            gl.TexParameter(3553u, 10241u, 9729); gl.TexParameter(3553u, 10240u, 9729);
            gl.FramebufferTexture2D(36160u, /* ColorAttachment0 */ 36064u, 3553u, _colorTex, 0);
            gl.BindRenderbuffer(/* Renderbuffer */ 36161u, _rbo);
            gl.RenderbufferStorage(36161u, /* Depth24Stencil8 */ 35056u, (uint)w, (uint)h);
            gl.FramebufferRenderbuffer(36160u, /* DepthStencilAttachment */ 33306u, 36161u, _rbo);
            gl.BindFramebuffer(36160u, 0);
        }

        public void Bind()   => RenderDevice.Instance.GL?.BindFramebuffer(36160u, _fbo);
        public void Unbind() => RenderDevice.Instance.GL?.BindFramebuffer(36160u, 0u);

        public void Dispose() {
            var gl = RenderDevice.Instance.GL; if (gl == null) return;
            gl.DeleteFramebuffer(_fbo); gl.DeleteTexture(_colorTex); gl.DeleteRenderbuffer(_rbo);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Renderer2D  — IModule façade over SpriteBatch
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class Renderer2D : IModule
    {
        public static Renderer2D Instance { get; } = new();
        private Renderer2D() {}

        public string          Name        => "Renderer2D";
        public ModuleInitOrder InitOrder   => ModuleInitOrder.Renderer;
        public bool            Initialized { get; private set; }

        private SpriteBatch? _batch;
        private Camera2D     _activeCamera = new();

        public SpriteBatch Batch => _batch!;
        public Camera2D    Camera { get => _activeCamera; set => _activeCamera = value; }

        public bool Initialize() {
            _batch = new SpriteBatch();
            Initialized = true;
            Log.Info("[Renderer2D] Initialized");
            return true;
        }

        public void Shutdown() {
            _batch?.Dispose();
            Initialized = false;
        }

        public void BeginFrame() {
            var rd = RenderDevice.Instance;
            rd.Clear(_activeCamera.ClearColor);
            var vp = _activeCamera.GetViewProjection(rd.ViewportWidth, rd.ViewportHeight);
            _batch!.Begin(vp);
        }

        public void EndFrame() => _batch!.End();

        public void DrawSprite (Vector2 pos, Vector2 size, Texture2D? tex, Color tint,
                                Rect2D? uv=null, bool flipX=false, bool flipY=false, float rot=0f) =>
            _batch!.DrawSprite(pos, size, tex, tint, uv, flipX, flipY, rot);

        public void DrawLine  (Vector2 a, Vector2 b, Color c, float t=1f) => _batch!.DrawLine(a, b, c, t);
        public void DrawRect  (Rect2D r, Color c, float t=1f)             => _batch!.DrawRect(r, c, t);
        public void DrawRectFill(Rect2D r, Color c)                        => _batch!.DrawRectFill(r, c);
        public void DrawCircle(Vector2 o, float r, Color c)                => _batch!.DrawCircle(o, r, c);
        public void DrawFullscreenQuad(Color color) {
            var rd = RenderDevice.Instance;
            _batch!.DrawRectFill(new Rect2D(0,0,rd.ViewportWidth, rd.ViewportHeight), color);
        }
    }
}
