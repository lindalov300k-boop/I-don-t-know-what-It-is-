// =============================================================================
// Animation/Animation.cs  —  Phase 6: SpriteAnimation, AnimStateMachine, System
// =============================================================================
using System;
using System.Collections.Generic;
using BADGE2D.Core;
using BADGE2D.ECS;
using BADGE2D.ECS.Components;
using BADGE2D.Math;
using BADGE2D.Renderer;

namespace BADGE2D.Animation
{
    // ─────────────────────────────────────────────────────────────────────────
    // AnimationFrame
    // ─────────────────────────────────────────────────────────────────────────
    public struct AnimationFrame
    {
        public Rect2D     UvRect;
        public float      Duration;    // seconds
        public string?    EventName;   // optional event fired on this frame
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SpriteAnimation  —  a named sequence of frames
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class SpriteAnimation
    {
        public string               Name    { get; set; } = "";
        public List<AnimationFrame> Frames  { get; }      = new();
        public bool                 Loop    { get; set; } = true;
        public float                Speed   { get; set; } = 1f;
        public Texture2D?           Texture { get; set; }

        public float TotalDuration {
            get { float d = 0; foreach (var f in Frames) d += f.Duration; return d; }
        }

        // Build from a horizontal sprite sheet
        public static SpriteAnimation FromSheet(string name, Texture2D tex,
            int cols, int rows, int frameCount, float frameDuration,
            int startFrame = 0, bool loop = true)
        {
            var anim = new SpriteAnimation { Name = name, Texture = tex, Loop = loop };
            float fw = 1f / cols, fh = 1f / rows;
            for (int i = startFrame; i < startFrame + frameCount; i++) {
                int col = i % cols, row = i / cols;
                anim.Frames.Add(new AnimationFrame {
                    UvRect   = new Rect2D(col * fw, row * fh, fw, fh),
                    Duration = frameDuration
                });
            }
            return anim;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AnimPlayer  —  plays a single SpriteAnimation
    // ─────────────────────────────────────────────────────────────────────────
    internal sealed class AnimPlayer
    {
        private SpriteAnimation? _anim;
        private int              _frame;
        private float            _elapsed;
        private bool             _playing;

        public event Action<string>? OnFrameEvent;
        public event Action?         OnComplete;

        public int     CurrentFrame => _frame;
        public bool    IsPlaying    => _playing;
        public SpriteAnimation? Current => _anim;

        public void Play(SpriteAnimation anim, bool reset = true) {
            _anim    = anim;
            _playing = true;
            if (reset) { _frame = 0; _elapsed = 0f; }
        }

        public void Stop()  => _playing = false;
        public void Pause() => _playing = false;

        public AnimationFrame? Update(float dt) {
            if (!_playing || _anim == null || _anim.Frames.Count == 0) return null;
            _elapsed += dt * _anim.Speed;
            float frameDur = _anim.Frames[_frame].Duration;
            if (_elapsed >= frameDur) {
                _elapsed -= frameDur;
                string? ev = _anim.Frames[_frame].EventName;
                if (ev != null) OnFrameEvent?.Invoke(ev);
                _frame++;
                if (_frame >= _anim.Frames.Count) {
                    if (_anim.Loop) _frame = 0;
                    else            { _frame = _anim.Frames.Count - 1; _playing = false; OnComplete?.Invoke(); }
                }
            }
            return _anim.Frames[_frame];
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AnimCondition types
    // ─────────────────────────────────────────────────────────────────────────
    public enum AnimParamType  { Float, Bool, Int, Trigger }
    public enum AnimConditionOp { Greater, Less, Equal, NotEqual, True, False }

    public struct AnimParam
    {
        public string        Name;
        public AnimParamType Type;
        public float         FloatValue;
        public bool          BoolValue;
        public int           IntValue;
        public bool          TriggerFired;
    }

    public struct AnimCondition
    {
        public string          Param;
        public AnimConditionOp Op;
        public float           Threshold;

        public bool Evaluate(Dictionary<string, AnimParam> parms) {
            if (!parms.TryGetValue(Param, out var p)) return false;
            return Op switch {
                AnimConditionOp.Greater  => p.FloatValue > Threshold,
                AnimConditionOp.Less     => p.FloatValue < Threshold,
                AnimConditionOp.Equal    => MathF.Abs(p.FloatValue - Threshold) < 0.01f,
                AnimConditionOp.NotEqual => MathF.Abs(p.FloatValue - Threshold) >= 0.01f,
                AnimConditionOp.True     => p.BoolValue,
                AnimConditionOp.False    => !p.BoolValue,
                _                        => false
            };
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AnimTransition
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AnimTransition
    {
        public string            TargetState  { get; set; } = "";
        public List<AnimCondition> Conditions { get; }      = new();
        public float             FadeTime     { get; set; } = 0.1f;
        public bool              HasExitTime  { get; set; }
        public float             ExitTime     { get; set; } = 1f;  // normalized

        public bool CanFire(Dictionary<string, AnimParam> parms, float normalizedTime) {
            if (HasExitTime && normalizedTime < ExitTime) return false;
            foreach (var c in Conditions) if (!c.Evaluate(parms)) return false;
            return true;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AnimState
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AnimState
    {
        public string                Name        { get; set; } = "";
        public SpriteAnimation?      Animation   { get; set; }
        public float                 Speed        { get; set; } = 1f;
        public List<AnimTransition>  Transitions  { get; }     = new();

        public event Action? OnEnter;
        public event Action? OnExit;

        internal void FireEnter() => OnEnter?.Invoke();
        internal void FireExit()  => OnExit?.Invoke();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AnimStateMachine
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AnimStateMachine
    {
        private readonly Dictionary<string, AnimState>  _states = new();
        private readonly Dictionary<string, AnimParam>  _params = new();
        private          AnimState?                     _current;
        private          AnimState?                     _target;
        private          AnimPlayer                     _player = new();
        private          AnimPlayer                     _fadePlayer = new();
        private          float                          _fadeT, _fadeDur;
        private          bool                           _transitioning;

        public string CurrentStateName => _current?.Name ?? "";
        public bool   IsTransitioning  => _transitioning;
        public float  TransitionProgress => _fadeDur > 0 ? _fadeT / _fadeDur : 1f;
        public bool   IsInState(string name) => _current?.Name == name;

        public event Action<string, string>? OnStateChanged;  // (from, to)

        // ── Setup ──────────────────────────────────────────────────────────
        public AnimState AddState(string name, SpriteAnimation? anim = null) {
            var s = new AnimState { Name = name, Animation = anim };
            _states[name] = s;
            if (_current == null) { _current = s; if (anim != null) _player.Play(anim); }
            return s;
        }

        public void AddTransition(string from, string to, float fadeTime = 0.08f,
            params AnimCondition[] conditions)
        {
            if (!_states.TryGetValue(from, out var fromState)) return;
            var t = new AnimTransition { TargetState = to, FadeTime = fadeTime };
            t.Conditions.AddRange(conditions);
            fromState.Transitions.Add(t);
        }

        public void AddAnyTransition(string to, float fadeTime, params AnimCondition[] conds) {
            foreach (var s in _states.Values)
                if (s.Name != to) AddTransition(s.Name, to, fadeTime, conds);
        }

        // ── Parameters ────────────────────────────────────────────────────
        public void SetFloat  (string p, float v)  { GetOrCreate(p, AnimParamType.Float).FloatValue   = v; _params[p] = GetOrCreate(p, AnimParamType.Float) with { FloatValue = v }; }
        public void SetBool   (string p, bool  v)  { var x = GetOrCreateRef(p, AnimParamType.Bool);   x.BoolValue  = v; _params[p] = x; }
        public void SetInt    (string p, int   v)  { var x = GetOrCreateRef(p, AnimParamType.Int);    x.IntValue   = v; _params[p] = x; }
        public void SetTrigger(string p)           { var x = GetOrCreateRef(p, AnimParamType.Trigger);x.TriggerFired = true; _params[p] = x; }

        private AnimParam GetOrCreate(string p, AnimParamType type) =>
            _params.TryGetValue(p, out var v) ? v : new AnimParam { Name = p, Type = type };
        private AnimParam GetOrCreateRef(string p, AnimParamType type) =>
            _params.TryGetValue(p, out var v) ? v : new AnimParam { Name = p, Type = type };

        public void ForceState(string name) {
            if (!_states.TryGetValue(name, out var s)) return;
            _current?.FireExit(); _current = s; s.FireEnter();
            if (s.Animation != null) _player.Play(s.Animation);
            _transitioning = false;
        }

        // ── Update ────────────────────────────────────────────────────────
        public (Rect2D uv, Texture2D? tex) Update(float dt) {
            if (_current == null) return (new Rect2D(0,0,1,1), null);

            // Update fade
            if (_transitioning && _target != null) {
                _fadeT += dt;
                _fadePlayer.Update(dt);
                if (_fadeT >= _fadeDur) {
                    _current?.FireExit();
                    var from = _current?.Name ?? "";
                    _current = _target; _target = null; _transitioning = false;
                    _player = _fadePlayer; _fadePlayer = new AnimPlayer();
                    OnStateChanged?.Invoke(from, _current.Name);
                }
            }

            var frame = _player.Update(dt);
            if (frame == null) return (new Rect2D(0,0,1,1), _current.Animation?.Texture);

            // Check transitions
            if (!_transitioning) {
                float normTime = _current.Animation != null
                    ? (_player.CurrentFrame / (float)System.Math.Max(1, _current.Animation.Frames.Count))
                    : 0f;
                foreach (var tr in _current.Transitions) {
                    if (tr.CanFire(_params, normTime) && _states.TryGetValue(tr.TargetState, out var tgt)) {
                        _transitioning = true;
                        _fadeT = 0; _fadeDur = tr.FadeTime; _target = tgt;
                        _fadePlayer = new AnimPlayer();
                        if (tgt.Animation != null) _fadePlayer.Play(tgt.Animation);
                        tgt.FireEnter();
                        ClearTriggers();
                        break;
                    }
                }
            }

            return (frame.Value.UvRect, _current.Animation?.Texture);
        }

        private void ClearTriggers() {
            foreach (var k in new List<string>(_params.Keys)) {
                var p = _params[k];
                if (p.Type == AnimParamType.Trigger && p.TriggerFired) {
                    _params[k] = p with { TriggerFired = false };
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AnimatorSystem  —  ECS update system
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AnimatorSystem : ISystem
    {
        public string Name => "AnimatorSystem";

        public void OnUpdate(World world, double dt) {
            world.EachRef<AnimatorComponent, SpriteComponent>((e, ref var anim, ref var sprite) => {
                if (anim.StateMachine == null) return;
                var (uv, tex) = anim.StateMachine.Update((float)dt);
                sprite.UvRect = uv;
                // Texture2D ID assignment happens at higher level via TextureRegistry
            });
        }
    }
}
