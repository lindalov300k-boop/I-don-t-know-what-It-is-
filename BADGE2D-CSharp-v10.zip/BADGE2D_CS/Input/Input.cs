// =============================================================================
// Input/Input.cs  —  Phase 4: InputManager, ActionMap, keyboard/mouse/gamepad
// =============================================================================
using System;
using System.Collections.Generic;
using BADGE2D.Core;
using BADGE2D.Math;

namespace BADGE2D.Input
{
    // ─────────────────────────────────────────────────────────────────────────
    // Key / MouseButton / GamepadButton codes
    // ─────────────────────────────────────────────────────────────────────────
    public enum Key
    {
        Unknown=-1, Space=32, Apostrophe=39, Comma=44, Minus=45, Period=46, Slash=47,
        D0=48,D1,D2,D3,D4,D5,D6,D7,D8,D9,
        Semicolon=59, Equal=61,
        A=65,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,
        LeftBracket=91, Backslash=92, RightBracket=93, GraveAccent=96,
        Escape=256, Enter, Tab, Backspace, Insert, Delete,
        Right, Left, Down, Up,
        PageUp, PageDown, Home, End,
        CapsLock=280, ScrollLock, NumLock, PrintScreen, Pause,
        F1=290,F2,F3,F4,F5,F6,F7,F8,F9,F10,F11,F12,
        LeftShift=340, LeftControl, LeftAlt, LeftSuper,
        RightShift=344, RightControl, RightAlt, RightSuper,
        Menu=348
    }

    public enum MouseButton { Left=0, Right=1, Middle=2, X1=3, X2=4 }

    public enum GamepadButton
    {
        A=0, B, X, Y,
        LeftBumper, RightBumper,
        Back, Start, Guide,
        LeftThumb, RightThumb,
        DpadUp, DpadRight, DpadDown, DpadLeft
    }

    public enum GamepadAxis { LeftX=0, LeftY, RightX, RightY, LeftTrigger, RightTrigger }

    // ─────────────────────────────────────────────────────────────────────────
    // InputState  — snapshot of one frame's raw input
    // ─────────────────────────────────────────────────────────────────────────
    internal sealed class InputState
    {
        public readonly HashSet<Key>          KeysDown    = new();
        public readonly HashSet<MouseButton>  MouseDown   = new();
        public          Vector2               MousePos;
        public          Vector2               MouseDelta;
        public          float                 ScrollY;
        public readonly float[]               GamepadAxes = new float[6];
        public readonly HashSet<GamepadButton> PadDown    = new();

        public void CopyFrom(InputState src) {
            KeysDown.Clear();  foreach (var k in src.KeysDown)  KeysDown.Add(k);
            MouseDown.Clear(); foreach (var m in src.MouseDown) MouseDown.Add(m);
            MousePos = src.MousePos; MouseDelta = src.MouseDelta; ScrollY = src.ScrollY;
            Array.Copy(src.GamepadAxes, GamepadAxes, 6);
            PadDown.Clear(); foreach (var b in src.PadDown) PadDown.Add(b);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // InputManager
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class InputManager : IModule
    {
        public static InputManager Instance { get; } = new();
        private InputManager() {}

        public string          Name        => "InputManager";
        public ModuleInitOrder InitOrder   => ModuleInitOrder.Input;
        public bool            Initialized { get; private set; }

        private readonly InputState _cur  = new();
        private readonly InputState _prev = new();

        // ── IModule ────────────────────────────────────────────────────────
        public bool Initialize() { Initialized = true; Log.Info("[Input] Initialized"); return true; }
        public void Shutdown()   { Initialized = false; }

        // Called at start of each frame by the engine loop
        public void Update(double _dt) {
            _prev.CopyFrom(_cur);
            _cur.MouseDelta = Vector2.Zero;
            _cur.ScrollY    = 0f;
        }

        // ── Raw feed (called by Silk.NET callbacks) ────────────────────────
        public void FeedKeyDown  (Key k)         => _cur.KeysDown.Add(k);
        public void FeedKeyUp    (Key k)         => _cur.KeysDown.Remove(k);
        public void FeedMouseDown(MouseButton b) => _cur.MouseDown.Add(b);
        public void FeedMouseUp  (MouseButton b) => _cur.MouseDown.Remove(b);
        public void FeedMousePos (float x, float y) {
            _cur.MouseDelta = new Vector2(x, y) - _cur.MousePos;
            _cur.MousePos   = new Vector2(x, y);
        }
        public void FeedScroll   (float y)       => _cur.ScrollY += y;
        public void FeedPadAxis  (GamepadAxis a, float v) => _cur.GamepadAxes[(int)a] = v;
        public void FeedPadDown  (GamepadButton b) => _cur.PadDown.Add(b);
        public void FeedPadUp    (GamepadButton b) => _cur.PadDown.Remove(b);

        // ── Keyboard ──────────────────────────────────────────────────────
        public bool IsKeyDown    (Key k) => _cur.KeysDown.Contains(k);
        public bool IsKeyUp      (Key k) => !_cur.KeysDown.Contains(k);
        public bool IsKeyPressed (Key k) => _cur.KeysDown.Contains(k) && !_prev.KeysDown.Contains(k);
        public bool IsKeyReleased(Key k) => !_cur.KeysDown.Contains(k) && _prev.KeysDown.Contains(k);

        public Vector2 GetWASD() => new(
            (IsKeyDown(Key.D) ? 1f : 0f) - (IsKeyDown(Key.A) ? 1f : 0f),
            (IsKeyDown(Key.W) ? 1f : 0f) - (IsKeyDown(Key.S) ? 1f : 0f));

        public Vector2 GetArrows() => new(
            (IsKeyDown(Key.Right) ? 1f : 0f) - (IsKeyDown(Key.Left) ? 1f : 0f),
            (IsKeyDown(Key.Up)    ? 1f : 0f) - (IsKeyDown(Key.Down) ? 1f : 0f));

        // ── Mouse ─────────────────────────────────────────────────────────
        public bool    IsMouseDown    (MouseButton b) => _cur.MouseDown.Contains(b);
        public bool    IsMousePressed (MouseButton b) => _cur.MouseDown.Contains(b) && !_prev.MouseDown.Contains(b);
        public bool    IsMouseReleased(MouseButton b) => !_cur.MouseDown.Contains(b) && _prev.MouseDown.Contains(b);
        public Vector2 MousePosition  => _cur.MousePos;
        public Vector2 MouseDelta     => _cur.MouseDelta;
        public float   ScrollDelta    => _cur.ScrollY;

        // ── Gamepad ───────────────────────────────────────────────────────
        public float GetAxis      (GamepadAxis   a) => _cur.GamepadAxes[(int)a];
        public bool  IsPadDown    (GamepadButton b) => _cur.PadDown.Contains(b);
        public bool  IsPadPressed (GamepadButton b) => _cur.PadDown.Contains(b) && !_prev.PadDown.Contains(b);
        public bool  IsPadReleased(GamepadButton b) => !_cur.PadDown.Contains(b) && _prev.PadDown.Contains(b);
        public Vector2 LeftStick  => new(GetAxis(GamepadAxis.LeftX),  GetAxis(GamepadAxis.LeftY));
        public Vector2 RightStick => new(GetAxis(GamepadAxis.RightX), GetAxis(GamepadAxis.RightY));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ActionMap  —  named bindings to keys/buttons
    // ─────────────────────────────────────────────────────────────────────────
    public enum InputDeviceType { Keyboard, Gamepad, Mouse }

    public sealed class InputBinding
    {
        public InputDeviceType Device;
        public int             Code;     // Key, GamepadButton, MouseButton cast to int
        public GamepadAxis     Axis;
        public float           AxisDir;  // +1 / -1 for axis bindings
        public bool            IsAxis;

        public static InputBinding FromKey      (Key k)           => new() { Device=InputDeviceType.Keyboard, Code=(int)k };
        public static InputBinding FromPadButton(GamepadButton b)  => new() { Device=InputDeviceType.Gamepad,  Code=(int)b };
        public static InputBinding FromAxis     (GamepadAxis a, float dir) =>
            new() { Device=InputDeviceType.Gamepad, Axis=a, AxisDir=dir, IsAxis=true };
    }

    public sealed class ActionMap
    {
        private readonly Dictionary<string, List<InputBinding>> _actions  = new();
        private readonly Dictionary<string, float>              _axes     = new();

        public void BindKey      (string action, Key k)             => Bind(action, InputBinding.FromKey(k));
        public void BindPadButton(string action, GamepadButton b)    => Bind(action, InputBinding.FromPadButton(b));
        public void BindAxis     (string action, GamepadAxis a, float dir) => Bind(action, InputBinding.FromAxis(a, dir));
        public void BindKeyAxis  (string pos, string neg, Key kPos, Key kNeg) {
            BindKey(pos, kPos); BindKey(neg, kNeg);
        }

        private void Bind(string action, InputBinding binding) {
            if (!_actions.TryGetValue(action, out var list)) _actions[action] = list = new();
            list.Add(binding);
        }

        public void Update(InputManager inp) {
            _axes.Clear();
            foreach (var (name, bindings) in _actions) {
                float v = 0f;
                foreach (var b in bindings) {
                    if (b.IsAxis) {
                        v += inp.GetAxis(b.Axis) * b.AxisDir;
                    } else {
                        bool pressed = b.Device switch {
                            InputDeviceType.Keyboard => inp.IsKeyDown((Key)b.Code),
                            InputDeviceType.Gamepad  => inp.IsPadDown((GamepadButton)b.Code),
                            InputDeviceType.Mouse    => inp.IsMouseDown((MouseButton)b.Code),
                            _                        => false
                        };
                        if (pressed) v += 1f;
                    }
                }
                _axes[name] = MathUtils.Clamp(v, -1f, 1f);
            }
        }

        public bool  IsActionDown    (string action) => GetAxis(action) > 0.1f;
        public bool  IsActionPressed (string action, InputManager inp) =>
            _actions.TryGetValue(action, out var list) &&
            list.Exists(b => b.Device == InputDeviceType.Keyboard && inp.IsKeyPressed((Key)b.Code));
        public float GetAxis(string action) => _axes.TryGetValue(action, out var v) ? v : 0f;

        // ── Combos ────────────────────────────────────────────────────────
        private readonly List<(string[], Action)> _combos = new();
        public void RegisterCombo(string[] actions, Action callback) =>
            _combos.Add((actions, callback));
        public void CheckCombos() {
            foreach (var (acts, cb) in _combos)
                if (Array.TrueForAll(acts, a => IsActionDown(a))) cb();
        }
    }
}
