// =============================================================================
// Runtime/Application.cs  —  Application base, EngineLoop, Silk.NET bootstrap
// =============================================================================
using System;
using System.Reflection;
using BADGE2D.Assets;
using BADGE2D.Audio;
using BADGE2D.Core;
using BADGE2D.Events;
using BADGE2D.Input;
using BADGE2D.Math;
using BADGE2D.Platform;
using BADGE2D.Renderer;
using BADGE2D.Scene;
using BADGE2D.UI;
using Silk.NET.Input;
using Silk.NET.Maths;
using Silk.NET.OpenGL;
using Silk.NET.Windowing;

namespace BADGE2D.Runtime
{
    // ─────────────────────────────────────────────────────────────────────────
    // WindowConfig
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class WindowConfig
    {
        public string Title  { get; set; } = "BADGE2D Application";
        public int    Width  { get; set; } = 1280;
        public int    Height { get; set; } = 720;
        public bool   VSync  { get; set; } = true;
        public bool   Resizable { get; set; } = true;
        public bool   StartMaximized { get; set; }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Application  — game / editor entry point
    // ─────────────────────────────────────────────────────────────────────────
    public abstract class Application
    {
        protected WindowConfig WindowConfig { get; } = new();

        private IWindow?          _window;
        private GL?               _gl;
        private IInputContext?    _inputCtx;
        private readonly EngineTime _time = new();

        // ── Lifecycle hooks (override in game class) ───────────────────────
        protected virtual void Configure(WindowConfig cfg) {}
        protected virtual void OnInit()                    {}
        protected virtual void OnUpdate  (double dt)       {}
        protected virtual void OnRender  ()                {}
        protected virtual void OnShutdown()                {}
        protected virtual void OnResize  (int w, int h)   {}

        // ── Entry point ────────────────────────────────────────────────────
        public int Run() {
            Configure(WindowConfig);

            var opts = WindowOptions.Default with {
                Title  = WindowConfig.Title,
                Size   = new Vector2D<int>(WindowConfig.Width, WindowConfig.Height),
                VSync  = WindowConfig.VSync,
                API    = new GraphicsAPI(ContextAPI.OpenGL, new APIVersion(4, 1))
            };

            _window = Window.Create(opts);
            _window.Load    += OnLoad;
            _window.Update  += OnUpdateInternal;
            _window.Render  += OnRenderInternal;
            _window.Closing += OnClosingInternal;
            _window.Resize  += size => {
                _gl?.Viewport(0, 0, (uint)size.X, (uint)size.Y);
                RenderDevice.Instance.ViewportWidth  = size.X;
                RenderDevice.Instance.ViewportHeight = size.Y;
                OnResize(size.X, size.Y);
                UICanvas.Instance.Layout(size.X, size.Y);
            };

            _window.Run();
            _window.Dispose();
            return 0;
        }

        // ── Internal load ──────────────────────────────────────────────────
        private void OnLoad() {
            _gl = _window!.CreateOpenGL();
            _gl.Enable(EnableCap.Blend);
            _gl.BlendFunc(BlendingFactor.SrcAlpha, BlendingFactor.OneMinusSrcAlpha);

            // Wire up GL handle to RenderDevice
            RenderDevice.Instance.GL     = _gl;
            RenderDevice.Instance.Window = _window;
            RenderDevice.Instance.ViewportWidth  = WindowConfig.Width;
            RenderDevice.Instance.ViewportHeight = WindowConfig.Height;

            // Register and initialize all modules
            var modules = ModuleManager.Instance;
            modules.Register(JobSystem.Instance);
            modules.Register(InputManager.Instance);
            modules.Register(RenderDevice.Instance);
            modules.Register(Renderer2D.Instance);
            modules.Register(AudioMixer.Instance);
            modules.Register(SceneManager.Instance);
            modules.Register(AssetManager.Instance);
            modules.Register(UICanvas.Instance);
            modules.InitializeAll();

            // Wire Silk.NET input events → InputManager
            _inputCtx = _window.CreateInput();
            foreach (var kb in _inputCtx.Keyboards) {
                kb.KeyDown += (k, sc, _) => InputManager.Instance.FeedKeyDown(MapKey(k.Key));
                kb.KeyUp   += (k, sc, _) => InputManager.Instance.FeedKeyUp  (MapKey(k.Key));
                kb.KeyChar += (k, c)     => UICanvas.Instance.FeedChar(c);
            }
            foreach (var ms in _inputCtx.Mice) {
                ms.MouseDown   += (m, b) => { InputManager.Instance.FeedMouseDown(MapButton(b)); UICanvas.Instance.FeedMouseClick(m.Position.X, m.Position.Y); };
                ms.MouseUp     += (m, b) => InputManager.Instance.FeedMouseUp(MapButton(b));
                ms.MouseMove   += (m, p) => { InputManager.Instance.FeedMousePos(p.X, p.Y); UICanvas.Instance.FeedMousePos(p.X, p.Y); };
                ms.Scroll      += (m, s) => InputManager.Instance.FeedScroll(s.Y);
            }

            UICanvas.Instance.Layout(WindowConfig.Width, WindowConfig.Height);
            EventBus.Instance.Emit(new EngineStartedEvent());
            OnInit();
        }

        // ── Update loop ────────────────────────────────────────────────────
        private void OnUpdateInternal(double dt) {
            _time.Tick();
            InputManager.Instance.Update(dt);
            while (_time.ConsumeFixedStep()) {
                SceneManager.Instance.FixedUpdate(_time.FixedTimeStep);
                ModuleManager.Instance.FixedUpdateAll(_time.FixedTimeStep);
            }
            SceneManager.Instance.Update(dt);
            UICanvas.Instance.Update(dt);
            ModuleManager.Instance.UpdateAll(dt);
            OnUpdate(dt);
        }

        // ── Render loop ────────────────────────────────────────────────────
        private void OnRenderInternal(double _) {
            _gl!.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
            SceneManager.Instance.Render();
            UICanvas.Instance.Render();
            OnRender();
        }

        private void OnClosingInternal() {
            EventBus.Instance.Emit(new EngineShuttingDownEvent());
            OnShutdown();
            ModuleManager.Instance.ShutdownAll();
        }

        // ── Key mapping ────────────────────────────────────────────────────
        private static BADGE2D.Input.Key MapKey(Silk.NET.Input.Key k) =>
            Enum.TryParse<BADGE2D.Input.Key>(k.ToString(), out var mapped) ? mapped : BADGE2D.Input.Key.Unknown;

        private static BADGE2D.Input.MouseButton MapButton(Silk.NET.Input.MouseButton b) =>
            (BADGE2D.Input.MouseButton)(int)b;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EngineLoop  —  standalone fixed-step loop (for headless / test use)
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class EngineLoop
    {
        private readonly EngineTime _time = new();
        private bool _running;

        public void Run(Action<double> update, Action<double> fixedUpdate, Action render,
                        Func<bool> shouldQuit) {
            _running = true;
            while (_running && !shouldQuit()) {
                _time.Tick();
                while (_time.ConsumeFixedStep()) fixedUpdate(_time.FixedTimeStep);
                update(_time.DeltaTime);
                render();
            }
        }

        public void Stop() => _running = false;
    }
}
