// =============================================================================
// Editor/Editor.cs  —  Phase 10: EditorCore, Panels, Gizmos, Undo/Redo
// =============================================================================
using System;
using System.Collections.Generic;
using BADGE2D.Core;
using BADGE2D.ECS;
using BADGE2D.ECS.Components;
using BADGE2D.Math;
using BADGE2D.Renderer;
using BADGE2D.Scene;

namespace BADGE2D.Editor
{
    // ─────────────────────────────────────────────────────────────────────────
    // EditorMode
    // ─────────────────────────────────────────────────────────────────────────
    public enum EditorMode { Select, Translate, Rotate, Scale }
    public enum EditorPlayState { Stopped, Playing, Paused }

    // ─────────────────────────────────────────────────────────────────────────
    // IEditorCommand  — for undo / redo
    // ─────────────────────────────────────────────────────────────────────────
    public interface IEditorCommand
    {
        string Description { get; }
        void Execute();
        void Undo();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MoveEntityCommand
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class MoveEntityCommand : IEditorCommand
    {
        private readonly World   _world;
        private readonly Entity  _entity;
        private          Vector2 _newPos, _oldPos;

        public string Description => $"Move {_entity}";

        public MoveEntityCommand(World world, Entity entity, Vector2 newPos) {
            _world  = world; _entity = entity; _newPos = newPos;
            _oldPos = world.Has<TransformComponent>(entity)
                ? world.Get<TransformComponent>(entity).Position : Vector2.Zero;
        }

        public void Execute() { ref var tc = ref _world.Get<TransformComponent>(_entity); tc.Position = _newPos; tc.Dirty = true; }
        public void Undo()    { ref var tc = ref _world.Get<TransformComponent>(_entity); tc.Position = _oldPos; tc.Dirty = true; }
    }

    public sealed class RenameEntityCommand : IEditorCommand
    {
        private readonly World  _world;
        private readonly Entity _entity;
        private readonly string _newName, _oldName;

        public string Description => $"Rename {_entity}";

        public RenameEntityCommand(World world, Entity entity, string newName) {
            _world = world; _entity = entity; _newName = newName;
            _oldName = world.GetName(entity);
        }

        public void Execute() => _world.SetName(_entity, _newName);
        public void Undo()    => _world.SetName(_entity, _oldName);
    }

    public sealed class AddComponentCommand<T> : IEditorCommand where T : struct
    {
        private readonly World   _world;
        private readonly Entity  _entity;
        private readonly T       _component;

        public string Description => $"Add {typeof(T).Name}";

        public AddComponentCommand(World world, Entity entity, T component) {
            _world = world; _entity = entity; _component = component;
        }

        public void Execute() => _world.Add(_entity, _component);
        public void Undo()    => _world.Remove<T>(_entity);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CommandHistory  — undo / redo stack
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class CommandHistory
    {
        private readonly Stack<IEditorCommand> _undo = new();
        private readonly Stack<IEditorCommand> _redo = new();
        private const int MaxHistory = 200;

        public bool CanUndo => _undo.Count > 0;
        public bool CanRedo => _redo.Count > 0;

        public string? UndoDescription => CanUndo ? _undo.Peek().Description : null;
        public string? RedoDescription => CanRedo ? _redo.Peek().Description : null;

        public void Execute(IEditorCommand cmd) {
            cmd.Execute();
            _undo.Push(cmd);
            _redo.Clear();
            while (_undo.Count > MaxHistory) {
                var arr = _undo.ToArray();
                _undo.Clear();
                for (int i = 0; i < arr.Length - 1; i++) _undo.Push(arr[i]);
            }
        }

        public void Undo() { if (CanUndo) { var cmd = _undo.Pop(); cmd.Undo(); _redo.Push(cmd); } }
        public void Redo() { if (CanRedo) { var cmd = _redo.Pop(); cmd.Execute(); _undo.Push(cmd); } }
        public void Clear() { _undo.Clear(); _redo.Clear(); }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EditorSelection
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class EditorSelection
    {
        private readonly HashSet<Entity> _selected = new();

        public IReadOnlyCollection<Entity> Selected  => _selected;
        public bool                        HasSelection => _selected.Count > 0;
        public Entity?                     Primary  => _selected.Count > 0 ? _selected.GetEnumerator().Current : null;

        public event Action? Changed;

        public void Select  (Entity e, bool additive = false) {
            if (!additive) _selected.Clear();
            _selected.Add(e);
            Changed?.Invoke();
        }

        public void Deselect(Entity e) { _selected.Remove(e); Changed?.Invoke(); }
        public void Clear   ()         { _selected.Clear();   Changed?.Invoke(); }
        public bool IsSelected(Entity e) => _selected.Contains(e);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TransformGizmo
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class TransformGizmo
    {
        public EditorMode Mode          { get; set; } = EditorMode.Translate;
        public float      GizmoScale    { get; set; } = 60f;
        public bool       WorldSpace    { get; set; } = true;

        private static readonly Color AxisX = new(0.9f, 0.2f, 0.2f);
        private static readonly Color AxisY = new(0.2f, 0.9f, 0.2f);
        private static readonly Color Circle= new(0.9f, 0.8f, 0.1f);

        public void Draw(SpriteBatch batch, Entity entity, World world) {
            if (!world.Has<TransformComponent>(entity)) return;
            var tc = world.Get<TransformComponent>(entity);
            DrawGizmo(batch, tc.Position, GizmoScale, tc.Rotation);
        }

        private void DrawGizmo(SpriteBatch batch, Vector2 pos, float scale, float rotation) {
            switch (Mode) {
                case EditorMode.Translate:
                    batch.DrawLine(pos, pos + new Vector2(scale, 0),  AxisX, 3f);
                    batch.DrawLine(pos, pos + new Vector2(0, scale),   AxisY, 3f);
                    break;
                case EditorMode.Rotate:
                    batch.DrawCircle(pos, scale, Circle);
                    break;
                case EditorMode.Scale:
                    batch.DrawLine(pos, pos + new Vector2(scale, 0),  AxisX, 3f);
                    batch.DrawLine(pos, pos + new Vector2(0, scale),   AxisY, 3f);
                    batch.DrawRectFill(new Rect2D(pos.X+scale-6, pos.Y-6, 12, 12), AxisX);
                    batch.DrawRectFill(new Rect2D(pos.X-6, pos.Y+scale-6, 12, 12), AxisY);
                    break;
            }
        }

        public bool TryDrag(Entity entity, World world,
                             Vector2 worldMouseDelta, CommandHistory history) {
            if (!world.Has<TransformComponent>(entity)) return false;
            var tc = world.Get<TransformComponent>(entity);
            if (Mode == EditorMode.Translate) {
                var newPos = tc.Position + worldMouseDelta;
                history.Execute(new MoveEntityCommand(world, entity, newPos));
                return true;
            }
            return false;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EditorPanel (base)
    // ─────────────────────────────────────────────────────────────────────────
    public abstract class EditorPanel
    {
        public string  Title   { get; set; }
        public bool    Open    { get; set; } = true;
        public Rect2D  Rect    { get; set; }

        protected EditorPanel(string title) => Title = title;

        public abstract void Draw(EditorCore editor, SpriteBatch batch);

        protected void DrawPanelBg(SpriteBatch batch, Color bg) =>
            batch.DrawRectFill(Rect, bg);
        protected void DrawPanelBorder(SpriteBatch batch) =>
            batch.DrawRect(Rect, new Color(0.4f,0.4f,0.4f), 1f);
    }

    // Panel 1: SceneHierarchy
    public sealed class SceneHierarchyPanel : EditorPanel
    {
        public SceneHierarchyPanel() : base("Scene Hierarchy") {}

        public override void Draw(EditorCore editor, SpriteBatch batch) {
            if (!Open) return;
            DrawPanelBg(batch, new Color(0.12f, 0.12f, 0.12f, 0.95f));
            DrawPanelBorder(batch);
            if (editor.EditScene == null) return;

            float y = Rect.Y + 28f;
            editor.EditScene.World.Each<TransformComponent>((e, tc) => {
                bool selected = editor.Selection.IsSelected(e);
                var row = new Rect2D(Rect.X + 4, y, Rect.W - 8, 20);
                if (selected) batch.DrawRectFill(row, new Color(0.25f,0.45f,0.75f,0.8f));
                y += 22f;
            });
        }
    }

    // Panel 2: Inspector
    public sealed class InspectorPanel : EditorPanel
    {
        public InspectorPanel() : base("Inspector") {}

        public override void Draw(EditorCore editor, SpriteBatch batch) {
            if (!Open) return;
            DrawPanelBg(batch, new Color(0.11f, 0.11f, 0.11f, 0.95f));
            DrawPanelBorder(batch);
            if (!editor.Selection.HasSelection || editor.EditScene == null) return;

            foreach (var e in editor.Selection.Selected) {
                if (!editor.EditScene.World.Has<TransformComponent>(e)) continue;
                var tc = editor.EditScene.World.Get<TransformComponent>(e);
                // Draw transform fields (simplified — full impl uses ImGui or custom widgets)
                float y = Rect.Y + 30f;
                var labelColor = new Color(0.7f, 0.7f, 0.7f);
                batch.DrawRect(new Rect2D(Rect.X+4, y,    Rect.W-8, 16), labelColor, 0.5f); y += 20f;
                batch.DrawRect(new Rect2D(Rect.X+4, y,    Rect.W-8, 16), labelColor, 0.5f); y += 20f;
                batch.DrawRect(new Rect2D(Rect.X+4, y,    Rect.W-8, 16), labelColor, 0.5f);
            }
        }
    }

    // Panel 3: AssetBrowser
    public sealed class AssetBrowserPanel : EditorPanel
    {
        private string _currentDir = "Assets";

        public AssetBrowserPanel() : base("Asset Browser") {}

        public override void Draw(EditorCore editor, SpriteBatch batch) {
            if (!Open) return;
            DrawPanelBg(batch, new Color(0.10f, 0.10f, 0.10f, 0.95f));
            DrawPanelBorder(batch);
            // Draw grid of asset thumbnails
            float x = Rect.X + 8, y = Rect.Y + 30, cellSize = 64;
            foreach (var meta in Assets.AssetManager.Instance.Manifest.All.Values) {
                batch.DrawRect(new Rect2D(x, y, cellSize-4, cellSize-4),
                    new Color(0.3f,0.3f,0.3f), 1f);
                x += cellSize;
                if (x + cellSize > Rect.Right) { x = Rect.X + 8; y += cellSize; }
            }
        }
    }

    // Panel 4: Viewport
    public sealed class ViewportPanel : EditorPanel
    {
        public Camera2D Camera { get; } = new();
        private Framebuffer? _fb;

        public ViewportPanel() : base("Viewport") {}

        public void EnsureFramebuffer() {
            if (_fb == null || (int)Rect.W != _fb.Width || (int)Rect.H != _fb.Height) {
                _fb?.Dispose();
                if (Rect.W > 0 && Rect.H > 0)
                    _fb = new Framebuffer((int)Rect.W, (int)Rect.H);
            }
        }

        public void BeginCapture() { EnsureFramebuffer(); _fb?.Bind(); }
        public void EndCapture()   => _fb?.Unbind();
        public uint TextureId      => _fb?.ColorTextureId ?? 0;

        public override void Draw(EditorCore editor, SpriteBatch batch) {
            if (!Open) return;
            DrawPanelBorder(batch);
            // Draw gizmos for selected entities
            if (editor.EditScene == null) return;
            foreach (var e in editor.Selection.Selected)
                editor.Gizmo.Draw(batch, e, editor.EditScene.World);
        }
    }

    // Panel 5: Console
    public sealed class ConsolePanel : EditorPanel
    {
        private readonly List<(LogLevel level, string msg)> _messages = new();
        private const int MaxMessages = 500;

        public ConsolePanel() : base("Console") {}

        public void Append(LogLevel level, string msg) {
            _messages.Add((level, msg));
            if (_messages.Count > MaxMessages) _messages.RemoveAt(0);
        }

        public override void Draw(EditorCore editor, SpriteBatch batch) {
            if (!Open) return;
            DrawPanelBg(batch, new Color(0.08f, 0.08f, 0.08f, 0.95f));
            DrawPanelBorder(batch);
            float y = Rect.Bottom - 22f;
            for (int i = _messages.Count - 1; i >= 0 && y > Rect.Y; i--, y -= 18f) {
                var (lvl, msg) = _messages[i];
                var col = lvl switch {
                    LogLevel.Warning => new Color(1f, 0.8f, 0.1f),
                    LogLevel.Error   => new Color(1f, 0.3f, 0.3f),
                    LogLevel.Fatal   => Color.Magenta,
                    _                => new Color(0.8f, 0.8f, 0.8f)
                };
                batch.DrawRect(new Rect2D(Rect.X+4, y, Rect.W-8, 16), col * 0.4f, 0.5f);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EditorCore  —  IModule glue
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class EditorCore : IModule
    {
        public static EditorCore Instance { get; } = new();
        private EditorCore() {}

        public string          Name        => "Editor";
        public ModuleInitOrder InitOrder   => ModuleInitOrder.Editor;
        public bool            Initialized { get; private set; }

        public Scene.Scene?      EditScene  { get; private set; }
        public EditorSelection   Selection  { get; }   = new();
        public CommandHistory    History    { get; }   = new();
        public TransformGizmo    Gizmo      { get; }   = new();
        public EditorMode        Mode       { get => Gizmo.Mode; set => Gizmo.Mode = value; }
        public EditorPlayState   PlayState  { get; private set; } = EditorPlayState.Stopped;
        public bool              ShowGrid   { get; set; } = true;
        public bool              ShowGizmos { get; set; } = true;
        public float             GridSize   { get; set; } = 32f;

        // Panels
        public SceneHierarchyPanel HierarchyPanel { get; } = new();
        public InspectorPanel      InspectorPanel  { get; } = new();
        public AssetBrowserPanel   AssetPanel      { get; } = new();
        public ViewportPanel       ViewportPanel   { get; } = new();
        public ConsolePanel        ConsolePanel    { get; } = new();

        private List<EditorPanel> AllPanels => new() {
            HierarchyPanel, InspectorPanel, AssetPanel, ViewportPanel, ConsolePanel
        };

        public bool Initialize() {
            LayoutPanels(1280, 720);
            Initialized = true;
            Log.Info("[Editor] Initialized");
            return true;
        }

        public void Shutdown() { EditScene?.Unload(); Initialized = false; }

        public void OpenScene(Scene.Scene scene) {
            EditScene?.Unload();
            EditScene = scene;
            Selection.Clear();
            History.Clear();
        }

        public void CreateNewScene(string name = "New Scene") {
            var settings = new SceneSettings { Name = name, Id = (uint)new Random().Next() };
            var scene    = new Scene.Scene(settings);
            scene.Load();
            OpenScene(scene);
        }

        // ── Play state ────────────────────────────────────────────────────
        public void Play() {
            if (PlayState == EditorPlayState.Stopped) {
                // Would snapshot scene here for restore on stop
                PlayState = EditorPlayState.Playing;
                Log.Info("[Editor] Play");
            }
        }

        public void Pause() {
            if (PlayState == EditorPlayState.Playing) PlayState = EditorPlayState.Paused;
        }

        public void Stop() {
            if (PlayState != EditorPlayState.Stopped) {
                PlayState = EditorPlayState.Stopped;
                Log.Info("[Editor] Stop");
            }
        }

        // ── Input ─────────────────────────────────────────────────────────
        public void HandleKeyboardShortcuts(Input.InputManager inp) {
            if (inp.IsKeyDown(Input.Key.LeftControl)) {
                if (inp.IsKeyPressed(Input.Key.Z)) History.Undo();
                if (inp.IsKeyPressed(Input.Key.Y)) History.Redo();
                if (inp.IsKeyPressed(Input.Key.D)) DuplicateSelected();
            }
            if (inp.IsKeyPressed(Input.Key.W))      Mode = EditorMode.Translate;
            if (inp.IsKeyPressed(Input.Key.E))      Mode = EditorMode.Rotate;
            if (inp.IsKeyPressed(Input.Key.R))      Mode = EditorMode.Scale;
            if (inp.IsKeyPressed(Input.Key.Delete)) DeleteSelected();
        }

        // ── Entity operations ─────────────────────────────────────────────
        public Entity CreateEntity(string name = "Entity") {
            if (EditScene == null) throw new InvalidOperationException("No scene open");
            var e = EditScene.CreateEntity(name);
            Selection.Select(e);
            return e;
        }

        public void DeleteSelected() {
            if (EditScene == null) return;
            foreach (var e in new List<Entity>(Selection.Selected))
                EditScene.DestroyEntity(e);
            Selection.Clear();
        }

        public void DuplicateSelected() {
            if (EditScene == null) return;
            var originals = new List<Entity>(Selection.Selected);
            Selection.Clear();
            foreach (var e in originals) {
                var copy = EditScene.CreateEntity(EditScene.World.GetName(e) + "_copy");
                if (EditScene.World.Has<TransformComponent>(e)) {
                    var tc  = EditScene.World.Get<TransformComponent>(e);
                    tc.Position += new Vector2(16, 16);
                    EditScene.World.Add(copy, tc);
                }
                Selection.Select(copy, additive: true);
            }
        }

        // ── Layout ────────────────────────────────────────────────────────
        public void LayoutPanels(int w, int h) {
            float hierarchyW = 220, inspectorW = 260, assetH = 180, menuH = 24;
            float viewportW  = w - hierarchyW - inspectorW;

            HierarchyPanel.Rect = new Rect2D(0,          menuH, hierarchyW,          h - menuH - assetH);
            ViewportPanel .Rect = new Rect2D(hierarchyW, menuH, viewportW,            h - menuH - assetH);
            InspectorPanel.Rect = new Rect2D(w-inspectorW, menuH, inspectorW,         h - menuH - assetH);
            AssetPanel    .Rect = new Rect2D(0,            h-assetH, w,               assetH);
            ConsolePanel  .Rect = new Rect2D(hierarchyW,   h-assetH, viewportW,       assetH);
        }

        // ── Render (called from game loop) ─────────────────────────────────
        public void Render(SpriteBatch batch) {
            // Menu bar
            batch.DrawRectFill(new Rect2D(0, 0, 9999, 24), new Color(0.18f, 0.18f, 0.18f));
            // Grid overlay in viewport
            if (ShowGrid && EditScene != null) DrawGrid(batch);
            // Panels
            foreach (var p in AllPanels) p.Draw(this, batch);
        }

        private void DrawGrid(SpriteBatch batch) {
            var vp = ViewportPanel.Rect;
            var col = new Color(0.25f, 0.25f, 0.25f, 0.5f);
            for (float x = vp.X; x < vp.Right; x += GridSize)
                batch.DrawLine(new Vector2(x, vp.Y), new Vector2(x, vp.Top), col, 0.5f);
            for (float y = vp.Y; y < vp.Top; y += GridSize)
                batch.DrawLine(new Vector2(vp.X, y), new Vector2(vp.Right, y), col, 0.5f);
        }

        // Expose Rect extension properties needed inside editor
        private static class Extensions
        {
            public static float Right(Rect2D r) => r.X + r.W;
            public static float Top  (Rect2D r) => r.Y + r.H;
        }
    }
}

// Needed in editor for Rect2D.Right / .Top / .Bottom convenience
namespace BADGE2D.Editor
{
    internal static class Rect2DEditorExt
    {
        public static float Right (this Rect2D r) => r.X + r.W;
        public static float Top   (this Rect2D r) => r.Y + r.H;
        public static float Bottom(this Rect2D r) => r.Y;
        public static Color operator *(Color c, float s) => new(c.R*s, c.G*s, c.B*s, c.A*s);
    }
}
