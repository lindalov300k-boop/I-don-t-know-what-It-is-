// =============================================================================
// ECS/ECS.cs  —  Entity Component System: Entity, ComponentStore, World
// =============================================================================
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using BADGE2D.Core;
using BADGE2D.Math;

namespace BADGE2D.ECS
{
    // ─────────────────────────────────────────────────────────────────────────
    // Entity  — 32-bit ID: upper 12 bits = generation, lower 20 bits = index
    // ─────────────────────────────────────────────────────────────────────────
    public readonly struct Entity : IEquatable<Entity>
    {
        public readonly uint Id;

        public static readonly Entity Null    = default;
        public static readonly Entity Invalid = default;

        public Entity(uint id)          { Id = id; }
        public Entity(uint idx, ushort gen) { Id = (gen << 20) | (idx & 0xFFFFF); }

        public uint   Index      => Id & 0xFFFFF;
        public ushort Generation => (ushort)(Id >> 20);
        public bool   IsValid    => Id != 0;

        public bool Equals(Entity other)         => Id == other.Id;
        public override bool Equals(object? obj) => obj is Entity e && Equals(e);
        public override int  GetHashCode()        => (int)Id;
        public override string ToString()         => $"Entity({Index}:gen{Generation})";

        public static bool operator ==(Entity a, Entity b) => a.Id == b.Id;
        public static bool operator !=(Entity a, Entity b) => a.Id != b.Id;

        public static implicit operator uint(Entity e) => e.Id;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EntityManager  — allocates / recycles entity IDs
    // ─────────────────────────────────────────────────────────────────────────
    internal sealed class EntityManager
    {
        private const uint MaxEntities = (1u << 20) - 1;

        private readonly ushort[]            _generations  = new ushort[MaxEntities];
        private readonly bool[]              _alive        = new bool[MaxEntities];
        private readonly string[]            _names        = new string[MaxEntities];
        private readonly Queue<uint>         _freeList     = new();
        private          uint                _nextIndex    = 1;

        public int AliveCount { get; private set; }

        public Entity Create(string name = "Entity") {
            uint idx;
            if (_freeList.Count > 0) {
                idx = _freeList.Dequeue();
            } else {
                idx = _nextIndex++;
                if (idx >= MaxEntities) throw new InvalidOperationException("Entity limit reached");
            }
            _alive[idx]       = true;
            _names[idx]       = name;
            AliveCount++;
            return new Entity(idx, _generations[idx]);
        }

        public void Destroy(Entity e) {
            uint idx = e.Index;
            if (!_alive[idx]) return;
            _alive[idx] = false;
            _generations[idx]++;
            _freeList.Enqueue(idx);
            AliveCount--;
        }

        public bool  IsAlive(Entity e) => _alive[e.Index] && _generations[e.Index] == e.Generation;
        public string GetName(Entity e) => _names[e.Index];
        public void SetName(Entity e, string name) { _names[e.Index] = name; }

        public void ForEachAlive(Action<Entity> action) {
            for (uint i = 1; i < _nextIndex; i++)
                if (_alive[i]) action(new Entity(i, _generations[i]));
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ComponentStore<T>  — dense array keyed by entity index
    // ─────────────────────────────────────────────────────────────────────────
    internal sealed class ComponentStore<T> where T : struct
    {
        private static readonly uint MaxEntities = (1u << 20) - 1;

        private T[]    _data    = new T[1024];
        private bool[] _has     = new bool[1024];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void EnsureCapacity(uint idx) {
            if (idx < _data.Length) return;
            int newSize = System.Math.Max((int)idx + 1, _data.Length * 2);
            Array.Resize(ref _data, newSize);
            Array.Resize(ref _has,  newSize);
        }

        public void Add   (Entity e, T comp) { EnsureCapacity(e.Index); _data[e.Index] = comp; _has[e.Index] = true; }
        public void Remove(Entity e)         { if (e.Index < _has.Length) _has[e.Index] = false; }
        public bool Has   (Entity e)         => e.Index < _has.Length && _has[e.Index];

        public ref T Get(Entity e) {
            if (!_has[e.Index]) throw new InvalidOperationException(
                $"Entity {e} does not have component {typeof(T).Name}");
            return ref _data[e.Index];
        }

        public ref T TryGetRef(Entity e, out bool found) {
            if (e.Index < _has.Length && _has[e.Index]) { found = true; return ref _data[e.Index]; }
            found = false;
            // Return dummy — caller must check `found`
            return ref _data[0];
        }

        public void ForEach(Action<Entity, T> fn, EntityManager em) {
            for (uint i = 1; i < _has.Length && i < em.AliveCount + 1; i++) {
                if (_has[i]) fn(new Entity(i, 0), _data[i]);
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ISystem
    // ─────────────────────────────────────────────────────────────────────────
    public interface ISystem
    {
        string Name { get; }
        void OnUpdate     (World world, double dt) {}
        void OnFixedUpdate(World world, double dt) {}
        void OnRender     (World world)             {}
    }

    // ─────────────────────────────────────────────────────────────────────────
    // World  —  the ECS universe
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class World
    {
        private readonly EntityManager             _entities  = new();
        private readonly Dictionary<Type, object>  _stores    = new();
        private readonly List<ISystem>             _systems   = new();

        // ── Entity management ──────────────────────────────────────────────
        public Entity Create(string name = "Entity") => _entities.Create(name);
        public void   Destroy(Entity e)               => _entities.Destroy(e);
        public bool   IsAlive(Entity e)               => _entities.IsAlive(e);
        public string GetName(Entity e)               => _entities.GetName(e);
        public void   SetName(Entity e, string name)  => _entities.SetName(e, name);
        public int    EntityCount                     => _entities.AliveCount;

        // ── Component access ───────────────────────────────────────────────
        private ComponentStore<T> Store<T>() where T : struct {
            var type = typeof(T);
            if (!_stores.TryGetValue(type, out var store)) {
                store = new ComponentStore<T>();
                _stores[type] = store;
            }
            return (ComponentStore<T>)store;
        }

        public T  Add<T>   (Entity e, T comp = default) where T : struct { Store<T>().Add(e, comp); return comp; }
        public void Remove<T>(Entity e)                 where T : struct => Store<T>().Remove(e);
        public bool Has<T>   (Entity e)                 where T : struct => Store<T>().Has(e);
        public ref T Get<T>  (Entity e)                 where T : struct => ref Store<T>().Get(e);
        public T?  TryGet<T> (Entity e)                 where T : struct {
            ref var c = ref Store<T>().TryGetRef(e, out bool found);
            return found ? c : null;
        }

        // ── Query iteration ────────────────────────────────────────────────
        public void Each<T>(Action<Entity, T> fn) where T : struct {
            var store = Store<T>();
            _entities.ForEachAlive(e => {
                if (store.Has(e)) fn(e, store.Get(e));
            });
        }

        public void Each<T1, T2>(Action<Entity, T1, T2> fn)
            where T1 : struct where T2 : struct
        {
            var s1 = Store<T1>(); var s2 = Store<T2>();
            _entities.ForEachAlive(e => {
                if (s1.Has(e) && s2.Has(e)) fn(e, s1.Get(e), s2.Get(e));
            });
        }

        public void Each<T1, T2, T3>(Action<Entity, T1, T2, T3> fn)
            where T1 : struct where T2 : struct where T3 : struct
        {
            var s1 = Store<T1>(); var s2 = Store<T2>(); var s3 = Store<T3>();
            _entities.ForEachAlive(e => {
                if (s1.Has(e) && s2.Has(e) && s3.Has(e)) fn(e, s1.Get(e), s2.Get(e), s3.Get(e));
            });
        }

        // ref-based Each for mutation
        public void EachRef<T>(RefAction<Entity, T> fn) where T : struct {
            var store = Store<T>();
            _entities.ForEachAlive(e => {
                if (store.Has(e)) fn(e, ref store.Get(e));
            });
        }

        public void EachRef<T1,T2>(RefAction2<Entity,T1,T2> fn)
            where T1 : struct where T2 : struct
        {
            var s1 = Store<T1>(); var s2 = Store<T2>();
            _entities.ForEachAlive(e => {
                if (s1.Has(e) && s2.Has(e)) fn(e, ref s1.Get(e), ref s2.Get(e));
            });
        }

        // ── Systems ────────────────────────────────────────────────────────
        public T AddSystem<T>(T system) where T : ISystem { _systems.Add(system); return system; }

        public void UpdateSystems     (double dt) { foreach (var s in _systems) s.OnUpdate(this, dt);      }
        public void FixedUpdateSystems(double dt) { foreach (var s in _systems) s.OnFixedUpdate(this, dt); }
        public void RenderSystems     ()          { foreach (var s in _systems) s.OnRender(this);           }

        public void Clear() {
            _entities.ForEachAlive(e => _entities.Destroy(e));
            _stores.Clear();
            _systems.Clear();
        }
    }

    // Delegate helpers for ref params
    public delegate void RefAction <TArg, T>       (TArg a, ref T t);
    public delegate void RefAction2<TArg, T1, T2>  (TArg a, ref T1 t1, ref T2 t2);

    // =========================================================================
    // Built-in Components  (Phase 1 + all subsystem bridges)
    // =========================================================================
    namespace Components
    {
        // ── Core ──────────────────────────────────────────────────────────
        public struct NameComponent    { public string Name; }
        public struct TagComponent     { public string Tag;  public List<string>? Tags; }
        public struct ActiveComponent  { public bool Active; }

        // ── Rendering (Phase 2) ───────────────────────────────────────────
        public struct TransformComponent
        {
            public Vector2 Position;
            public float   Rotation;   // radians
            public Vector2 Scale;
            public Entity  Parent;
            public bool    Dirty;

            public static TransformComponent Default => new() {
                Scale = Vector2.One, Dirty = true
            };
        }

        public struct SpriteComponent
        {
            public uint    TextureId;
            public Rect2D  UvRect;
            public Color   Tint;
            public Vector2 Pivot;
            public Vector2 Size;
            public int     SortOrder;
            public bool    FlipX, FlipY, Visible;

            public static SpriteComponent Default => new() {
                UvRect = new Rect2D(0,0,1,1), Tint = Color.White,
                Pivot  = new Vector2(0.5f,0.5f), Size = new Vector2(64,64), Visible = true
            };
        }

        public struct CameraComponent
        {
            public float   Zoom;
            public float   Rotation;
            public Vector2 Viewport;
            public Color   ClearColor;
            public bool    IsMain;
            public bool    Active;

            public static CameraComponent Default => new() {
                Zoom = 1f, Viewport = new Vector2(1280, 720),
                ClearColor = new Color(0.1f, 0.1f, 0.15f),
                IsMain = false, Active = true
            };
        }

        // ── Physics (Phase 3) ─────────────────────────────────────────────
        public struct PhysicsBodyComponent
        {
            public Physics.PhysicsBody? Body;
            public bool SyncToECS;      // physics pos → TransformComponent
            public bool SyncFromECS;    // TransformComponent → physics pos (kinematic)
            public Vector2 PositionOffset;

            public static PhysicsBodyComponent Default => new() { SyncToECS = true };
        }

        // ── Animation (Phase 6) ───────────────────────────────────────────
        public struct AnimatorComponent
        {
            public Animation.AnimStateMachine? StateMachine;

            public void SetFloat  (string p, float f) => StateMachine?.SetFloat(p, f);
            public void SetBool   (string p, bool  b) => StateMachine?.SetBool(p, b);
            public void SetInt    (string p, int   i) => StateMachine?.SetInt(p, i);
            public void SetTrigger(string p)           => StateMachine?.SetTrigger(p);
            public void Play      (string state)       => StateMachine?.ForceState(state);
            public bool IsInState (string state) => StateMachine?.IsInState(state) ?? false;
            public string StateName => StateMachine?.CurrentStateName ?? "";
        }

        // ── Tilemap ───────────────────────────────────────────────────────
        public struct TilemapComponent
        {
            public uint      TilesetId;
            public int       Cols, Rows;
            public float     TileWidth, TileHeight;
            public ushort[]? Tiles;

            public ushort GetTile(int col, int row) {
                if (Tiles == null || col < 0 || row < 0 || col >= Cols || row >= Rows) return 0;
                return Tiles[row * Cols + col];
            }
            public void SetTile(int col, int row, ushort id) {
                if (Tiles == null || col < 0 || row < 0 || col >= Cols || row >= Rows) return;
                Tiles[row * Cols + col] = id;
            }
        }

        // ── UI (Phase 9) ──────────────────────────────────────────────────
        public struct UIComponent
        {
            public bool  Anchored, Interactable, Visible;
            public float AnchorX, AnchorY;
            public int   RenderLayer;
            public static UIComponent Default => new() { Interactable=true, Visible=true, RenderLayer=100 };
        }

        // ── Scripting ─────────────────────────────────────────────────────
        public struct ScriptComponent
        {
            public Action?         OnStart;
            public Action<double>? OnUpdate;
            public Action?         OnDestroy;
        }
    }
}
