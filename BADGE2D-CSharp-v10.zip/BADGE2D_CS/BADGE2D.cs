// =============================================================================
// BADGE2D.cs  —  Master include: one using covers the whole engine
//
// Usage in your game:
//   using BADGE2D;         // everything
//   using BADGE2D.Math;    // just math types
//   using BADGE2D.ECS;     // entity component system
//   etc.
// =============================================================================

// Pull all namespaces together so callers can write `using BADGE2D;`
// and access every subsystem without additional using directives.

global using BADGE2D.Math;          // Vector2, Color, Rect2D, Matrix4, MathUtils
global using BADGE2D.Core;          // Log, Logger, Profiler, EngineTime, IModule
global using BADGE2D.ECS;           // Entity, World, ISystem
global using BADGE2D.ECS.Components;// TransformComponent, SpriteComponent, etc.
global using BADGE2D.Platform;      // FileSystem, JobSystem
global using BADGE2D.Events;        // EventBus, built-in events
global using BADGE2D.Renderer;      // Texture2D, SpriteBatch, Renderer2D, Camera2D
global using BADGE2D.Physics;       // PhysicsWorld, PhysicsBody, PhysicsSystem
global using BADGE2D.Input;         // InputManager, ActionMap, Key, MouseButton
global using BADGE2D.Audio;         // AudioMixer, AudioClip, AudioSource
global using BADGE2D.Animation;     // AnimStateMachine, SpriteAnimation, AnimatorSystem
global using BADGE2D.Scene;         // Scene, SceneManager, SceneSerializer, Prefab
global using BADGE2D.Assets;        // AssetManager, AssetHandle<T>
global using BADGE2D.UI;            // UICanvas, UIPanel, UIButton, UILabel, etc.
global using BADGE2D.Editor;        // EditorCore, panels, gizmos, undo
global using BADGE2D.Runtime;       // Application, EngineLoop

// =============================================================================
// Version info
// =============================================================================
namespace BADGE2D
{
    public static class Engine
    {
        public const string Version    = "10.0.0-cs";
        public const string Language   = "C# 12 / .NET 8";
        public const string Renderer   = "OpenGL 4.1 (Silk.NET)";
        public const string PhysicsLib = "Built-in impulse-based (SAT)";
        public const string AudioLib   = "NAudio + NVorbis";

        /// <summary>
        /// Print engine info banner to the log.
        /// </summary>
        public static void PrintBanner() {
            Core.Log.Info("╔══════════════════════════════════════════════════════╗");
            Core.Log.Info("║   BADGE2D — Basic Atlas Dimensional Game Engine 2D  ║");
            Core.Log.Info($"║   Version {Version,-44}║");
            Core.Log.Info($"║   {Language,-52}║");
            Core.Log.Info("╚══════════════════════════════════════════════════════╝");
        }
    }
}
