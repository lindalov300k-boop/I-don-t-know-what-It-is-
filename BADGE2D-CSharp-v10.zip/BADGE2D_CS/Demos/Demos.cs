// =============================================================================
// Demos/Demos.cs  —  Four runnable demos (one per major subsystem)
// =============================================================================
using System;
using BADGE2D.Animation;
using BADGE2D.Assets;
using BADGE2D.Audio;
using BADGE2D.Core;
using BADGE2D.ECS.Components;
using BADGE2D.Editor;
using BADGE2D.Events;
using BADGE2D.Input;
using BADGE2D.Math;
using BADGE2D.Physics;
using BADGE2D.Renderer;
using BADGE2D.Runtime;
using BADGE2D.Scene;
using BADGE2D.UI;

namespace BADGE2D.Demos
{
    // =========================================================================
    // Demo 1: PhysicsDemo  —  stack of dynamic boxes, floor, mouse-click spawner
    // =========================================================================
    public sealed class PhysicsDemo : Application
    {
        private Scene.Scene? _scene;
        private PhysicsWorld? _physics;

        protected override void Configure(WindowConfig cfg) {
            cfg.Title = "BADGE2D — Physics Demo";
            cfg.Width = 1280; cfg.Height = 720;
        }

        protected override void OnInit() {
            AssetManager.Instance.SetRoot("Assets");

            var settings = new SceneSettings {
                Name = "PhysicsDemo", Id = 1,
                Gravity = new Vector2(0, -500f),
                ClearColor = new Color(0.08f, 0.08f, 0.12f)
            };
            _scene   = new Scene.Scene(settings);
            _scene.Load();
            _physics = _scene.Physics!;

            SceneManager.Instance.Register("physics", () => _scene);
            SceneManager.Instance.LoadScene("physics");

            // Floor
            var floor = _scene.CreateEntity("Floor", new Vector2(640, 50));
            PhysicsSystem.AttachBoxBody(_scene.World, floor, _physics, 1200, 40, BodyType.Static);
            var sc = SpriteComponent.Default;
            sc.Size = new Vector2(1200, 40);
            sc.Tint = new Color(0.4f, 0.6f, 0.4f);
            _scene.World.Add(floor, sc);

            // Stack of boxes
            for (int row = 0; row < 6; row++) {
                for (int col = 0; col < 4; col++) {
                    var box = _scene.CreateEntity($"Box_{row}_{col}",
                        new Vector2(520 + col * 52, 100 + row * 52));
                    PhysicsSystem.AttachBoxBody(_scene.World, box, _physics, 48, 48, BodyType.Dynamic);
                    var sp = SpriteComponent.Default;
                    sp.Size = new Vector2(48, 48);
                    sp.Tint = new Color(0.7f + col*0.07f, 0.3f, 0.3f + row*0.06f);
                    _scene.World.Add(box, sp);
                }
            }

            // Ball (circle)
            var ball = _scene.CreateEntity("Ball", new Vector2(640, 500));
            PhysicsSystem.AttachCircleBody(_scene.World, ball, _physics, 30, BodyType.Dynamic);
            var ballSp = SpriteComponent.Default;
            ballSp.Size = new Vector2(60, 60);
            ballSp.Tint = new Color(0.9f, 0.8f, 0.2f);
            _scene.World.Add(ball, ballSp);

            // Setup camera
            _scene.Camera.Position = new Vector2(640, 360);

            // UI overlay
            var hud = UICanvas.Instance.Add(new UIPanel {
                Layout = new UILayout { Anchor = Anchor.TopRight, Offset = new Vector2(-10, -10),
                    Size = new Vector2(200, 80) },
                BackgroundColor = new Color(0,0,0,0.6f)
            });
            var label = new UILabel {
                Text = "Click to spawn!\nLMB = Box  RMB = Ball",
                Layout = new UILayout { Anchor = Anchor.Stretch, Left=8, Right=8, Bottom=8, Top=8 },
                FontSize = 13f
            };
            hud.AddChild(label);

            Log.Info("[PhysicsDemo] Ready — click viewport to spawn objects");
        }

        protected override void OnUpdate(double dt) {
            var inp = InputManager.Instance;
            if (_scene == null || _physics == null) return;

            // Spawn on click
            if (inp.IsMousePressed(MouseButton.Left)) SpawnBox(inp.MousePosition, BodyType.Dynamic);
            if (inp.IsMousePressed(MouseButton.Right)) SpawnBall(inp.MousePosition);

            // Camera pan with arrow keys
            var move = inp.GetArrows() * (float)(300 * dt);
            _scene.Camera.Position += move;

            // Zoom with scroll
            _scene.Camera.Zoom = MathUtils.Clamp(
                _scene.Camera.Zoom + inp.ScrollDelta * 0.1f, 0.1f, 10f);

            // Quit
            if (inp.IsKeyPressed(Key.Escape))
                Environment.Exit(0);
        }

        private void SpawnBox(Vector2 screenPos, BodyType type) {
            var rng   = new Random();
            var world = _scene!.Camera.ScreenToWorld(screenPos,
                RenderDevice.Instance.ViewportWidth, RenderDevice.Instance.ViewportHeight);
            var e = _scene.CreateEntity("SpawnedBox", world);
            PhysicsSystem.AttachBoxBody(_scene.World, e, _physics!, 40, 40, type);
            var sp = SpriteComponent.Default;
            sp.Size = new Vector2(40, 40);
            sp.Tint = new Color((float)rng.NextDouble(), (float)rng.NextDouble(), (float)rng.NextDouble());
            _scene.World.Add(e, sp);
        }

        private void SpawnBall(Vector2 screenPos) {
            var world = _scene!.Camera.ScreenToWorld(screenPos,
                RenderDevice.Instance.ViewportWidth, RenderDevice.Instance.ViewportHeight);
            var e  = _scene.CreateEntity("SpawnedBall", world);
            PhysicsSystem.AttachCircleBody(_scene.World, e, _physics!, 24, BodyType.Dynamic);
            var sp = SpriteComponent.Default;
            sp.Size = new Vector2(48, 48);
            sp.Tint = Color.Cyan;
            _scene.World.Add(e, sp);
        }

        protected override void OnRender() {
            // Sprites rendered by SceneManager
        }

        protected override void OnShutdown() {
            _scene?.Unload();
        }
    }

    // =========================================================================
    // Demo 2: PlatformerDemo  —  WASD / arrows platformer with animation
    // =========================================================================
    public sealed class PlatformerDemo : Application
    {
        private Scene.Scene?  _scene;
        private ECS.Entity    _player;
        private PhysicsBody?  _playerBody;
        private ActionMap     _actions = new();
        private const float   MoveSpeed = 220f;
        private const float   JumpForce = 500f;
        private bool          _grounded;

        protected override void Configure(WindowConfig cfg) {
            cfg.Title = "BADGE2D — Platformer Demo";
        }

        protected override void OnInit() {
            var settings = new SceneSettings { Name = "Platformer", Id = 2,
                Gravity = new Vector2(0, -800f), ClearColor = new Color(0.15f, 0.22f, 0.35f) };
            _scene = new Scene.Scene(settings);
            _scene.Load();

            SceneManager.Instance.Register("plat", () => _scene);
            SceneManager.Instance.LoadScene("plat");

            // Actions
            _actions.BindKey("right", Key.D); _actions.BindKey("right", Key.Right);
            _actions.BindKey("left",  Key.A); _actions.BindKey("left",  Key.Left);
            _actions.BindKey("jump",  Key.W); _actions.BindKey("jump",  Key.Up);
            _actions.BindKey("jump",  Key.Space);

            // Ground + platforms
            CreatePlatform(640, 40, 1280, 40, Color.Green);
            CreatePlatform(300, 200, 260, 24, new Color(0.5f, 0.4f, 0.3f));
            CreatePlatform(700, 340, 260, 24, new Color(0.5f, 0.4f, 0.3f));
            CreatePlatform(200, 460, 200, 24, new Color(0.5f, 0.4f, 0.3f));

            // Player
            _player = _scene.CreateEntity("Player", new Vector2(200, 200));
            _playerBody = PhysicsSystem.AttachBoxBody(_scene.World, _player,
                _scene.Physics!, 28, 52, BodyType.Dynamic);
            _playerBody.FixedRotation = true;

            // Simple animation state machine
            var anim = new AnimStateMachine();
            anim.AddState("Idle",  null);
            anim.AddState("Run",   null);
            anim.AddState("Jump",  null);
            anim.AddTransition("Idle", "Run",  0.05f, new AnimCondition { Param="speed", Op=AnimConditionOp.Greater, Threshold=10f });
            anim.AddTransition("Run",  "Idle", 0.05f, new AnimCondition { Param="speed", Op=AnimConditionOp.Less,    Threshold=10f });
            anim.AddAnyTransition("Jump", 0.05f, new AnimCondition { Param="grounded", Op=AnimConditionOp.False });
            anim.AddTransition("Jump", "Idle", 0.08f, new AnimCondition { Param="grounded", Op=AnimConditionOp.True });
            _scene.World.Add(_player, new AnimatorComponent { StateMachine = anim });

            var sp = SpriteComponent.Default;
            sp.Size = new Vector2(36, 56);
            sp.Tint = new Color(0.4f, 0.6f, 0.9f);
            _scene.World.Add(_player, sp);

            _scene.Camera.Zoom = 1.2f;
            Log.Info("[PlatformerDemo] Ready — WASD/Arrows to move, Space/W to jump");
        }

        private void CreatePlatform(float x, float y, float w, float h, Color color) {
            var e = _scene!.CreateEntity("Platform", new Vector2(x, y));
            PhysicsSystem.AttachBoxBody(_scene.World, e, _scene.Physics!, w, h, BodyType.Static);
            var sp = SpriteComponent.Default;
            sp.Size = new Vector2(w, h); sp.Tint = color;
            _scene.World.Add(e, sp);
        }

        protected override void OnUpdate(double dt) {
            var inp = InputManager.Instance;
            _actions.Update(inp);

            if (_playerBody == null) return;

            float h = _actions.GetAxis("right") - _actions.GetAxis("left");
            var vel = _playerBody.LinearVelocity;
            _playerBody.LinearVelocity = new Vector2(h * MoveSpeed, vel.Y);

            // Ground check (simple: near-zero downward velocity + close to floor)
            _grounded = MathF.Abs(vel.Y) < 5f;

            if (_actions.IsActionPressed("jump", inp) && _grounded)
                _playerBody.ApplyImpulse(new Vector2(0, JumpForce));

            // Update anim params
            if (_scene != null && _scene.World.Has<AnimatorComponent>(_player)) {
                ref var ac = ref _scene.World.Get<AnimatorComponent>(_player);
                ac.SetFloat("speed", MathF.Abs(vel.X));
                ac.SetBool ("grounded", _grounded);
                if (h < -0.1f) { ref var sp = ref _scene.World.Get<SpriteComponent>(_player); sp.FlipX = true; }
                if (h >  0.1f) { ref var sp = ref _scene.World.Get<SpriteComponent>(_player); sp.FlipX = false; }
            }

            // Camera follow player
            if (_scene != null && _scene.World.Has<TransformComponent>(_player)) {
                var tc = _scene.World.Get<TransformComponent>(_player);
                _scene.Camera.Position = Vector2.Lerp(_scene.Camera.Position, tc.Position, (float)(dt * 5));
            }

            if (inp.IsKeyPressed(Key.Escape)) Environment.Exit(0);
        }

        protected override void OnShutdown() => _scene?.Unload();
    }

    // =========================================================================
    // Demo 3: UIDemo  —  all 9 widget types showcased
    // =========================================================================
    public sealed class UIDemo : Application
    {
        protected override void Configure(WindowConfig cfg) {
            cfg.Title = "BADGE2D — UI Demo";
        }

        protected override void OnInit() {
            var canvas = UICanvas.Instance;

            // Main panel
            var panel = canvas.Add(new UIPanel {
                Layout = new UILayout {
                    Anchor = Anchor.MiddleCenter,
                    Size   = new Vector2(600, 500)
                },
                BackgroundColor = new Color(0.15f, 0.15f, 0.18f, 0.97f)
            });

            // Title
            panel.AddChild(new UILabel {
                Text   = "BADGE2D — UI Framework Demo",
                Layout = new UILayout { Anchor = Anchor.TopCenter, Offset = new Vector2(0,-10), Size = new Vector2(580, 40) },
                FontSize = 22f, TextColor = new Color(0.9f, 0.9f, 0.4f)
            });

            // Button
            var btn = new UIButton {
                Text   = "Click Me!",
                Layout = new UILayout { Anchor = Anchor.TopLeft, Offset = new Vector2(20, -60), Size = new Vector2(140, 36) }
            };
            btn.Clicked += () => Log.Info("[UIDemo] Button clicked!");
            panel.AddChild(btn);

            // Checkbox
            var chk = new UICheckbox {
                Label  = "Enable VSync",
                Checked = true,
                Layout = new UILayout { Anchor = Anchor.TopLeft, Offset = new Vector2(20, -110), Size = new Vector2(180, 28) }
            };
            chk.OnChanged += v => Log.Info($"[UIDemo] VSync: {v}");
            panel.AddChild(chk);

            // Slider
            var slider = new UISlider {
                Min = 0, Max = 1, Value = 0.5f,
                Layout = new UILayout { Anchor = Anchor.TopLeft, Offset = new Vector2(20, -155), Size = new Vector2(250, 24) }
            };
            slider.OnValueChanged += v => Log.Info($"[UIDemo] Slider: {v:F2}");
            panel.AddChild(slider);

            // Progress bar
            panel.AddChild(new UIProgressBar {
                Value = 0.7f,
                Layout = new UILayout { Anchor = Anchor.TopLeft, Offset = new Vector2(20, -200), Size = new Vector2(250, 22) },
                FillColor = new Color(0.2f, 0.7f, 0.3f)
            });

            // Text input
            var ti = new UITextInput {
                Placeholder = "Type something...",
                Layout = new UILayout { Anchor = Anchor.TopLeft, Offset = new Vector2(20, -245), Size = new Vector2(250, 32) }
            };
            ti.OnSubmit += s => Log.Info($"[UIDemo] Submitted: '{s}'");
            panel.AddChild(ti);

            // Image placeholder
            panel.AddChild(new UIImage {
                Layout = new UILayout { Anchor = Anchor.TopRight, Offset = new Vector2(-20, -60), Size = new Vector2(120, 120) },
                Tint = new Color(0.6f, 0.3f, 0.8f)
            });

            // Scroll view with many labels
            var scroll = new UIScrollView {
                ContentHeight = 300,
                Layout = new UILayout { Anchor = Anchor.BottomLeft, Offset = new Vector2(20, 60), Size = new Vector2(260, 150) }
            };
            for (int i = 0; i < 12; i++) {
                scroll.AddChild(new UILabel {
                    Text   = $"  Scroll item {i+1}",
                    Layout = new UILayout { Anchor = Anchor.TopLeft, Offset = new Vector2(0, -(i*26)), Size = new Vector2(240, 22) }
                });
            }
            panel.AddChild(scroll);

            // Sub-panel
            panel.AddChild(new UIPanel {
                Layout = new UILayout { Anchor = Anchor.BottomRight, Offset = new Vector2(-20, 60), Size = new Vector2(160, 80) },
                BackgroundColor = new Color(0.1f, 0.2f, 0.35f, 0.9f),
                BorderColor = new Color(0.3f, 0.5f, 0.8f)
            });

            canvas.Layout(WindowConfig.Width, WindowConfig.Height);
            Log.Info("[UIDemo] All 9 widget types initialized");
        }

        protected override void OnUpdate(double dt) {
            if (InputManager.Instance.IsKeyPressed(Key.Escape)) Environment.Exit(0);
        }
    }

    // =========================================================================
    // Demo 4: EditorDemo  —  boots the full editor layout
    // =========================================================================
    public sealed class EditorDemo : Application
    {
        private EditorCore _editor = EditorCore.Instance;

        protected override void Configure(WindowConfig cfg) {
            cfg.Title = "BADGE2D Editor";
            cfg.Width = 1600; cfg.Height = 900;
        }

        protected override void OnInit() {
            _editor.Initialize();
            _editor.CreateNewScene("SampleScene");

            // Populate sample entities
            var scene = _editor.EditScene!;
            for (int i = 0; i < 5; i++) {
                var e = _editor.CreateEntity($"Entity_{i}");
                ref var tc = ref scene.World.Get<TransformComponent>(e);
                tc.Position = new Vector2(200 + i * 80, 300 + (i % 3) * 60);
            }

            Log.Info("[EditorDemo] Editor ready");
        }

        protected override void OnUpdate(double dt) {
            _editor.HandleKeyboardShortcuts(InputManager.Instance);
            if (InputManager.Instance.IsKeyPressed(Key.Escape)) Environment.Exit(0);
        }

        protected override void OnRender() {
            _editor.Render(Renderer2D.Instance.Batch);
        }

        protected override void OnResize(int w, int h) {
            _editor.LayoutPanels(w, h);
        }

        protected override void OnShutdown() {
            _editor.Shutdown();
        }
    }

    // =========================================================================
    // Program.Main  — choose demo via command-line arg
    // =========================================================================
    public static class Program
    {
        public static int Main(string[] args) {
            string demo = args.Length > 0 ? args[0].ToLower() : "physics";
            Application app = demo switch {
                "platformer" => new PlatformerDemo(),
                "ui"         => new UIDemo(),
                "editor"     => new EditorDemo(),
                _            => new PhysicsDemo()
            };
            return app.Run();
        }
    }
}
