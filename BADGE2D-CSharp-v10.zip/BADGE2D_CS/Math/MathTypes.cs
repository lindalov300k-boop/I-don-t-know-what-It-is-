// =============================================================================
// Math/MathTypes.cs  —  Core value types: Vector2, Color, Rect2D, Transform2D
// =============================================================================
using System;
using System.Runtime.CompilerServices;

namespace BADGE2D.Math
{
    // ─────────────────────────────────────────────────────────────────────────
    // Vector2  — 2D float vector
    // ─────────────────────────────────────────────────────────────────────────
    public struct Vector2 : IEquatable<Vector2>
    {
        public float X, Y;

        public Vector2(float x, float y) { X = x; Y = y; }
        public Vector2(float v)           { X = v; Y = v; }

        public static readonly Vector2 Zero  = new(0, 0);
        public static readonly Vector2 One   = new(1, 1);
        public static readonly Vector2 Up    = new(0, 1);
        public static readonly Vector2 Down  = new(0, -1);
        public static readonly Vector2 Left  = new(-1, 0);
        public static readonly Vector2 Right = new(1, 0);

        public float Length        => MathF.Sqrt(X * X + Y * Y);
        public float LengthSquared => X * X + Y * Y;

        public Vector2 Normalized {
            get {
                float len = Length;
                return len > 1e-6f ? new Vector2(X / len, Y / len) : Zero;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float Dot    (Vector2 a, Vector2 b) => a.X*b.X + a.Y*b.Y;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float Cross  (Vector2 a, Vector2 b) => a.X*b.Y - a.Y*b.X;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float Distance(Vector2 a, Vector2 b) => (a - b).Length;
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Vector2 Lerp(Vector2 a, Vector2 b, float t) =>
            new(a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t);
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Vector2 Min(Vector2 a, Vector2 b) =>
            new(MathF.Min(a.X, b.X), MathF.Min(a.Y, b.Y));
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Vector2 Max(Vector2 a, Vector2 b) =>
            new(MathF.Max(a.X, b.X), MathF.Max(a.Y, b.Y));

        public Vector2 Rotate(float radians) {
            float c = MathF.Cos(radians), s = MathF.Sin(radians);
            return new(X * c - Y * s, X * s + Y * c);
        }

        public static Vector2 operator +(Vector2 a, Vector2 b) => new(a.X+b.X, a.Y+b.Y);
        public static Vector2 operator -(Vector2 a, Vector2 b) => new(a.X-b.X, a.Y-b.Y);
        public static Vector2 operator *(Vector2 a, float   s) => new(a.X*s,   a.Y*s);
        public static Vector2 operator *(float   s, Vector2 a) => new(a.X*s,   a.Y*s);
        public static Vector2 operator /(Vector2 a, float   s) => new(a.X/s,   a.Y/s);
        public static Vector2 operator -(Vector2 a)            => new(-a.X,    -a.Y);
        public static bool    operator ==(Vector2 a, Vector2 b)=> a.X==b.X && a.Y==b.Y;
        public static bool    operator !=(Vector2 a, Vector2 b)=> !(a == b);

        public bool Equals(Vector2 other) => this == other;
        public override bool Equals(object? obj) => obj is Vector2 v && Equals(v);
        public override int  GetHashCode() => HashCode.Combine(X, Y);
        public override string ToString()  => $"({X:F3}, {Y:F3})";
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Color  — RGBA float [0..1]
    // ─────────────────────────────────────────────────────────────────────────
    public struct Color : IEquatable<Color>
    {
        public float R, G, B, A;

        public Color(float r, float g, float b, float a = 1f) { R=r; G=g; B=b; A=a; }

        public static readonly Color White   = new(1, 1, 1);
        public static readonly Color Black   = new(0, 0, 0);
        public static readonly Color Red     = new(1, 0, 0);
        public static readonly Color Green   = new(0, 1, 0);
        public static readonly Color Blue    = new(0, 0, 1);
        public static readonly Color Yellow  = new(1, 1, 0);
        public static readonly Color Cyan    = new(0, 1, 1);
        public static readonly Color Magenta = new(1, 0, 1);
        public static readonly Color Clear   = new(0, 0, 0, 0);

        public static Color Lerp(Color a, Color b, float t) => new(
            a.R + (b.R-a.R)*t, a.G + (b.G-a.G)*t,
            a.B + (b.B-a.B)*t, a.A + (b.A-a.A)*t);

        public static Color FromHex(uint hex) => new(
            ((hex >> 16) & 0xFF) / 255f,
            ((hex >>  8) & 0xFF) / 255f,
            ((hex      ) & 0xFF) / 255f,
            ((hex >> 24) & 0xFF) / 255f);

        public Color WithAlpha(float a) => new(R, G, B, a);

        public bool Equals(Color o) => R==o.R && G==o.G && B==o.B && A==o.A;
        public override bool Equals(object? obj) => obj is Color c && Equals(c);
        public override int  GetHashCode() => HashCode.Combine(R, G, B, A);
        public override string ToString()  => $"({R:F2},{G:F2},{B:F2},{A:F2})";
        public static bool operator ==(Color a, Color b) => a.Equals(b);
        public static bool operator !=(Color a, Color b) => !a.Equals(b);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Rect2D  — Axis-aligned rectangle (x, y, width, height)
    // ─────────────────────────────────────────────────────────────────────────
    public struct Rect2D
    {
        public float X, Y, W, H;

        public Rect2D(float x, float y, float w, float h) { X=x; Y=y; W=w; H=h; }

        public float Left   => X;
        public float Right  => X + W;
        public float Top    => Y + H;
        public float Bottom => Y;
        public Vector2 Min  => new(X, Y);
        public Vector2 Max  => new(X+W, Y+H);
        public Vector2 Center => new(X + W*0.5f, Y + H*0.5f);
        public Vector2 Size   => new(W, H);

        public bool Contains(Vector2 p) => p.X >= X && p.X <= X+W && p.Y >= Y && p.Y <= Y+H;

        public bool Overlaps(Rect2D o) =>
            X < o.X+o.W && X+W > o.X && Y < o.Y+o.H && Y+H > o.Y;

        public static Rect2D FromMinMax(Vector2 min, Vector2 max) =>
            new(min.X, min.Y, max.X - min.X, max.Y - min.Y);

        public override string ToString() => $"Rect({X:F1},{Y:F1} {W:F1}x{H:F1})";
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Transform2D  — Position + Rotation + Scale
    // ─────────────────────────────────────────────────────────────────────────
    public struct Transform2D
    {
        public Vector2 Position;
        public float   Rotation;   // radians
        public Vector2 Scale;

        public Transform2D(Vector2 pos, float rot = 0f, Vector2 scale = default)
        {
            Position = pos;
            Rotation = rot;
            Scale    = scale == default ? Vector2.One : scale;
        }

        public static readonly Transform2D Identity = new(Vector2.Zero, 0f, Vector2.One);

        public Vector2 TransformPoint(Vector2 local) {
            float c = MathF.Cos(Rotation), s = MathF.Sin(Rotation);
            var scaled = new Vector2(local.X * Scale.X, local.Y * Scale.Y);
            return new Vector2(
                scaled.X * c - scaled.Y * s + Position.X,
                scaled.X * s + scaled.Y * c + Position.Y);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Matrix4  — Row-major 4×4 float matrix (column-vector convention)
    // ─────────────────────────────────────────────────────────────────────────
    public struct Matrix4
    {
        public float M00,M01,M02,M03;
        public float M10,M11,M12,M13;
        public float M20,M21,M22,M23;
        public float M30,M31,M32,M33;

        public static readonly Matrix4 Identity = new() {
            M00=1,M11=1,M22=1,M33=1 };

        public static Matrix4 Ortho(float left, float right, float bottom, float top,
                                     float near = -1f, float far = 1f)
        {
            float rl = 1f/(right-left), tb = 1f/(top-bottom), fn = 1f/(far-near);
            return new Matrix4 {
                M00 =  2f*rl,
                M11 =  2f*tb,
                M22 = -2f*fn,
                M30 = -(right+left)*rl,
                M31 = -(top+bottom)*tb,
                M32 = -(far+near)*fn,
                M33 =  1f
            };
        }

        public static Matrix4 Translation(float x, float y) => new Matrix4 {
            M00=1,M11=1,M22=1,M33=1, M30=x, M31=y };

        public static Matrix4 Scale2D(float sx, float sy) => new Matrix4 {
            M00=sx, M11=sy, M22=1, M33=1 };

        public static Matrix4 Rotation2D(float radians) {
            float c = MathF.Cos(radians), s = MathF.Sin(radians);
            return new Matrix4 { M00=c,M01=s, M10=-s,M11=c, M22=1, M33=1 };
        }

        public static Matrix4 operator *(Matrix4 a, Matrix4 b) {
            Matrix4 r = default;
            r.M00 = a.M00*b.M00+a.M01*b.M10+a.M02*b.M20+a.M03*b.M30;
            r.M01 = a.M00*b.M01+a.M01*b.M11+a.M02*b.M21+a.M03*b.M31;
            r.M02 = a.M00*b.M02+a.M01*b.M12+a.M02*b.M22+a.M03*b.M32;
            r.M03 = a.M00*b.M03+a.M01*b.M13+a.M02*b.M23+a.M03*b.M33;
            r.M10 = a.M10*b.M00+a.M11*b.M10+a.M12*b.M20+a.M13*b.M30;
            r.M11 = a.M10*b.M01+a.M11*b.M11+a.M12*b.M21+a.M13*b.M31;
            r.M12 = a.M10*b.M02+a.M11*b.M12+a.M12*b.M22+a.M13*b.M32;
            r.M13 = a.M10*b.M03+a.M11*b.M13+a.M12*b.M23+a.M13*b.M33;
            r.M20 = a.M20*b.M00+a.M21*b.M10+a.M22*b.M20+a.M23*b.M30;
            r.M21 = a.M20*b.M01+a.M21*b.M11+a.M22*b.M21+a.M23*b.M31;
            r.M22 = a.M20*b.M02+a.M21*b.M12+a.M22*b.M22+a.M23*b.M32;
            r.M23 = a.M20*b.M03+a.M21*b.M13+a.M22*b.M23+a.M23*b.M33;
            r.M30 = a.M30*b.M00+a.M31*b.M10+a.M32*b.M20+a.M33*b.M30;
            r.M31 = a.M30*b.M01+a.M31*b.M11+a.M32*b.M21+a.M33*b.M31;
            r.M32 = a.M30*b.M02+a.M31*b.M12+a.M32*b.M22+a.M33*b.M32;
            r.M33 = a.M30*b.M03+a.M31*b.M13+a.M32*b.M23+a.M33*b.M33;
            return r;
        }

        // Column-major float array for OpenGL upload
        public float[] ToColumnMajor() => new float[] {
            M00,M10,M20,M30, M01,M11,M21,M31,
            M02,M12,M22,M32, M03,M13,M23,M33
        };
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MathUtils  — Helpers
    // ─────────────────────────────────────────────────────────────────────────
    public static class MathUtils
    {
        public const float Pi      = MathF.PI;
        public const float TwoPi   = MathF.PI * 2f;
        public const float HalfPi  = MathF.PI * 0.5f;
        public const float Deg2Rad = MathF.PI / 180f;
        public const float Rad2Deg = 180f / MathF.PI;

        public static float Clamp(float v, float lo, float hi)    => MathF.Max(lo, MathF.Min(hi, v));
        public static int   Clamp(int   v, int   lo, int   hi)    => System.Math.Max(lo, System.Math.Min(hi, v));
        public static float Lerp (float a, float b, float t)      => a + (b - a) * t;
        public static float InverseLerp(float a, float b, float v) => b - a < 1e-6f ? 0f : (v - a) / (b - a);
        public static float Remap(float v, float ia, float ib, float oa, float ob) =>
            Lerp(oa, ob, InverseLerp(ia, ib, v));
        public static float Snap(float v, float step) =>
            step < 1e-6f ? v : MathF.Round(v / step) * step;
        public static float SmoothStep(float edge0, float edge1, float x) {
            float t = Clamp((x - edge0) / (edge1 - edge0), 0f, 1f);
            return t * t * (3f - 2f * t);
        }
        public static bool  ApproxEqual(float a, float b, float eps = 1e-5f) =>
            MathF.Abs(a - b) < eps;
    }
}
