// =============================================================================
// Platform/Platform.cs  —  FileSystem, JobSystem, EventSystem
// =============================================================================
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using BADGE2D.Core;

namespace BADGE2D.Platform
{
    // ─────────────────────────────────────────────────────────────────────────
    // FileSystem
    // ─────────────────────────────────────────────────────────────────────────
    public static class FileSystem
    {
        public static string  RootPath { get; set; } = Directory.GetCurrentDirectory();

        public static string  Resolve(string relative) => Path.Combine(RootPath, relative);
        public static bool    Exists (string path)     => File.Exists(Resolve(path)) || Directory.Exists(Resolve(path));
        public static string  ReadAllText(string path) => File.ReadAllText(Resolve(path));
        public static byte[]  ReadAllBytes(string path)=> File.ReadAllBytes(Resolve(path));
        public static void    WriteAllText(string path, string text) {
            var full = Resolve(path);
            Directory.CreateDirectory(Path.GetDirectoryName(full)!);
            File.WriteAllText(full, text);
        }
        public static void    WriteAllBytes(string path, byte[] data) {
            var full = Resolve(path);
            Directory.CreateDirectory(Path.GetDirectoryName(full)!);
            File.WriteAllBytes(full, data);
        }
        public static IEnumerable<string> EnumerateFiles(string dir, string pattern = "*",
            SearchOption opt = SearchOption.AllDirectories) =>
            Directory.EnumerateFiles(Resolve(dir), pattern, opt);

        public static void CreateDirectory(string path) =>
            Directory.CreateDirectory(Resolve(path));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // JobSystem  — thin wrapper around .NET ThreadPool
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class JobSystem : IModule
    {
        public static JobSystem Instance { get; } = new();
        private JobSystem() {}

        public string          Name      => "JobSystem";
        public ModuleInitOrder InitOrder => ModuleInitOrder.Platform;
        public bool            Initialized { get; private set; }

        private int _workerCount = Environment.ProcessorCount;

        public bool Initialize() {
            ThreadPool.SetMinThreads(_workerCount, 2);
            ThreadPool.SetMaxThreads(_workerCount * 4, 8);
            Initialized = true;
            Log.Info($"[JobSystem] Initialized ({_workerCount} workers)");
            return true;
        }

        public void Shutdown() { Initialized = false; }

        // Fire-and-forget
        public static void Schedule(Action job) => Task.Run(job);

        // Task-based (awaitable)
        public static Task<T> ScheduleAsync<T>(Func<T> job) => Task.Run(job);
        public static Task    ScheduleAsync(Action job)     => Task.Run(job);

        // Parallel for-each
        public static void ParallelFor(int from, int to, Action<int> body) =>
            Parallel.For(from, to, body);
    }
}

// =============================================================================
// Events/EventSystem.cs  —  Typed event bus
// =============================================================================
namespace BADGE2D.Events
{
    public sealed class EventBus
    {
        public static EventBus Instance { get; } = new();
        private EventBus() {}

        private readonly Dictionary<Type, List<Delegate>> _handlers = new();

        public void Subscribe<T>(Action<T> handler) {
            var type = typeof(T);
            if (!_handlers.TryGetValue(type, out var list)) _handlers[type] = list = new();
            list.Add(handler);
        }

        public void Unsubscribe<T>(Action<T> handler) {
            if (_handlers.TryGetValue(typeof(T), out var list))
                list.Remove(handler);
        }

        public void Emit<T>(T evt) {
            if (!_handlers.TryGetValue(typeof(T), out var list)) return;
            foreach (var h in list.ToArray()) ((Action<T>)h)(evt);
        }

        public void Clear() => _handlers.Clear();
    }

    // Built-in engine events
    public record struct EngineStartedEvent();
    public record struct EngineShuttingDownEvent();
    public record struct WindowResizedEvent(int Width, int Height);
    public record struct SceneLoadedEvent(string Name);
    public record struct SceneUnloadedEvent(string Name);
    public record struct AssetLoadedEvent(uint Id, string Path);
    public record struct CollisionEnterEvent(ECS.Entity A, ECS.Entity B);
    public record struct CollisionExitEvent (ECS.Entity A, ECS.Entity B);
}
