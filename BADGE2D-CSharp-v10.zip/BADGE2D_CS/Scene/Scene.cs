// =============================================================================
// Scene/Scene.cs  —  Phase 7: Scene, SceneManager, SceneSerializer, Prefab
// =============================================================================
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using BADGE2D.Core;
using BADGE2D.ECS;
using BADGE2D.ECS.Components;
using BADGE2D.Events;
using BADGE2D.Math;
using BADGE2D.Physics;
using BADGE2D.Renderer;

namespace BADGE2D.Scene
{
    // ─────────────────────────────────────────────────────────────────────────
    // SceneSettings
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class SceneSettings
    {
        public string   Name        { get; set; } = "Untitled";
        public uint     Id          { get; set; }
        public Color    ClearColor  { get; set; } = new Color(0.1f, 0.1f, 0.15f);
        public Vector2  Gravity     { get; set; } = new(0, -980f);
        public bool     Physics2D   { get; set; } = true;
        public string   ScenePath   { get; set; } = "";
        public bool     Persistent  { get; set; }            // stays loaded across transitions
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Scene
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class Scene
    {
        public SceneSettings Settings { get; }
        public World          World   { get; } = new();
        public PhysicsWorld?  Physics { get; private set; }

        private readonly List<ISystem> _systems = new();
        private          bool          _loaded;

        public event Action? OnLoaded;
        public event Action? OnUnloaded;

        public Scene(SceneSettings settings) => Settings = settings;

        public void Load() {
            if (_loaded) return;
            if (Settings.Physics2D) {
                Physics = new PhysicsWorld(new PhysicsWorldConfig { Gravity = Settings.Gravity });
                World.AddSystem(new PhysicsSystem(Physics));
            }
            World.AddSystem(new Animation.AnimatorSystem());
            OnLoaded?.Invoke();
            _loaded = true;
            Log.Info($"[Scene] Loaded: '{Settings.Name}'");
        }

        public void Unload() {
            if (!_loaded) return;
            OnUnloaded?.Invoke();
            World.Clear();
            Physics?.Shutdown();
            _loaded = false;
            Log.Info($"[Scene] Unloaded: '{Settings.Name}'");
        }

        // ── Entity helpers ─────────────────────────────────────────────────
        public Entity CreateEntity(string name = "Entity") {
            var e = World.Create(name);
            World.Add(e, TransformComponent.Default);
            World.Add<ActiveComponent>(e, new ActiveComponent { Active = true });
            return e;
        }

        public Entity CreateEntity(string name, Vector2 pos, Vector2? scale = null) {
            var e = CreateEntity(name);
            ref var tc = ref World.Get<TransformComponent>(e);
            tc.Position = pos;
            if (scale.HasValue) tc.Scale = scale.Value;
            return e;
        }

        public void DestroyEntity(Entity e) => World.Destroy(e);

        // ── System helpers ─────────────────────────────────────────────────
        public T AddSystem<T>(T sys) where T : ISystem => World.AddSystem(sys);

        // ── Update ────────────────────────────────────────────────────────
        public void Update(double dt)      => World.UpdateSystems(dt);
        public void FixedUpdate(double dt) => World.FixedUpdateSystems(dt);
        public void Render()               => World.RenderSystems();

        // ── Camera ────────────────────────────────────────────────────────
        public Camera2D Camera { get; set; } = new();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TransitionType + Config
    // ─────────────────────────────────────────────────────────────────────────
    public enum TransitionType { None, Fade, Crossfade, Slide }

    public sealed class SceneTransitionConfig
    {
        public TransitionType Type     { get; set; } = TransitionType.Fade;
        public float          Duration { get; set; } = 0.4f;
        public Color          FadeColor{ get; set; } = Color.Black;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SceneManager
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class SceneManager : IModule
    {
        public static SceneManager Instance { get; } = new();
        private SceneManager() {}

        public string          Name        => "SceneManager";
        public ModuleInitOrder InitOrder   => ModuleInitOrder.Scene;
        public bool            Initialized { get; private set; }

        private readonly Dictionary<string, Func<Scene>> _factories   = new();
        private readonly List<Scene>                      _active      = new();
        private          Scene?                           _main;
        private          SceneTransitionConfig?           _pendingTrans;
        private          string?                          _pendingLoad;
        private          float                            _transElapsed;
        private          bool                             _transitioning;

        public Scene? MainScene  => _main;
        public bool   IsTransitioning => _transitioning;
        public float  TransitionProgress =>
            _pendingTrans != null ? _transElapsed / _pendingTrans.Duration : 1f;

        public bool Initialize() { Initialized = true; Log.Info("[SceneManager] Initialized"); return true; }
        public void Shutdown()   {
            foreach (var s in _active) s.Unload();
            _active.Clear(); Initialized = false;
        }

        public void Register(string name, Func<Scene> factory) => _factories[name] = factory;

        public void LoadScene(string name, SceneTransitionConfig? transition = null) {
            _pendingLoad  = name;
            _pendingTrans = transition;
            _transElapsed = 0f;
            if (transition == null) CommitLoad();
            else _transitioning = true;
        }

        private void CommitLoad() {
            if (_pendingLoad == null) return;
            // Unload non-persistent
            foreach (var s in new List<Scene>(_active))
                if (!s.Settings.Persistent) { s.Unload(); _active.Remove(s); }

            if (_factories.TryGetValue(_pendingLoad, out var factory)) {
                var scene = factory();
                scene.Load();
                _active.Add(scene);
                _main = scene;
                EventBus.Instance.Emit(new SceneLoadedEvent(_pendingLoad));
            } else {
                Log.Error($"[SceneManager] Scene not registered: '{_pendingLoad}'");
            }
            _pendingLoad = null;
            _transitioning = false;
        }

        public void LoadSceneAdditive(string name) {
            if (!_factories.TryGetValue(name, out var factory)) { Log.Error($"[SceneManager] Not registered: '{name}'"); return; }
            var scene = factory(); scene.Load(); _active.Add(scene);
        }

        public void Update(double dt) {
            if (_transitioning && _pendingTrans != null) {
                _transElapsed += (float)dt;
                if (_transElapsed >= _pendingTrans.Duration) CommitLoad();
            }
            foreach (var s in _active) s.Update(dt);
        }

        public void FixedUpdate(double dt) { foreach (var s in _active) s.FixedUpdate(dt); }

        public void Render() {
            foreach (var s in _active) {
                Renderer2D.Instance.Camera = s.Camera;
                Renderer2D.Instance.BeginFrame();
                s.Render();
                Renderer2D.Instance.EndFrame();
            }
            if (_transitioning && _pendingTrans != null && _pendingTrans.Type == TransitionType.Fade) {
                float t = TransitionProgress;
                float alpha = t < 0.5f ? t * 2f : (1f - t) * 2f;
                Renderer2D.Instance.DrawFullscreenQuad(_pendingTrans.FadeColor.WithAlpha(alpha));
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Prefab  — serializable entity template
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class Prefab
    {
        public string Name { get; set; } = "Prefab";

        // Component blueprints stored as JSON-friendly dicts
        public Dictionary<string, object> Components { get; set; } = new();

        // Instantiate into a scene
        public Entity Instantiate(Scene scene, Vector2? overridePos = null) {
            var e = scene.CreateEntity(Name);
            if (overridePos.HasValue) {
                ref var tc = ref scene.World.Get<TransformComponent>(e);
                tc.Position = overridePos.Value;
            }
            // Restore components from blueprints (implemented per-component)
            ApplyComponents(scene, e);
            return e;
        }

        protected virtual void ApplyComponents(Scene scene, Entity e) {}

        // ── Factory helpers ────────────────────────────────────────────────
        public static Prefab FromEntity(Scene scene, Entity e) {
            var p = new Prefab { Name = scene.World.GetName(e) };
            // Snapshot components — extended in subclasses
            return p;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SceneSerializer  —  JSON save / load
    // ─────────────────────────────────────────────────────────────────────────
    public static class SceneSerializer
    {
        private static readonly JsonSerializerOptions _opts = new() {
            WriteIndented  = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        public static void Save(Scene scene, string path) {
            var doc = new SceneDocument {
                Name      = scene.Settings.Name,
                SceneId   = scene.Settings.Id,
                ClearColor = new float[] { scene.Settings.ClearColor.R, scene.Settings.ClearColor.G,
                                           scene.Settings.ClearColor.B, scene.Settings.ClearColor.A },
                Entities  = CollectEntities(scene)
            };
            var json = JsonSerializer.Serialize(doc, _opts);
            Platform.FileSystem.WriteAllText(path, json);
            Log.Info($"[SceneSerializer] Saved '{scene.Settings.Name}' → {path}");
        }

        public static Scene? Load(string path, Action<Scene>? configure = null) {
            if (!File.Exists(Platform.FileSystem.Resolve(path))) {
                Log.Error($"[SceneSerializer] File not found: {path}"); return null;
            }
            var json = Platform.FileSystem.ReadAllText(path);
            var doc  = JsonSerializer.Deserialize<SceneDocument>(json, _opts);
            if (doc == null) return null;

            var settings = new SceneSettings {
                Name      = doc.Name ?? "Scene",
                Id        = doc.SceneId,
                ClearColor = doc.ClearColor != null && doc.ClearColor.Length == 4
                    ? new Color(doc.ClearColor[0], doc.ClearColor[1], doc.ClearColor[2], doc.ClearColor[3])
                    : Color.Black
            };
            var scene = new Scene(settings);
            configure?.Invoke(scene);
            scene.Load();
            RestoreEntities(scene, doc.Entities ?? new());
            Log.Info($"[SceneSerializer] Loaded '{settings.Name}' from {path}");
            return scene;
        }

        private static List<EntityDocument> CollectEntities(Scene scene) {
            var list = new List<EntityDocument>();
            scene.World.Each<TransformComponent>((e, tc) => {
                list.Add(new EntityDocument {
                    Id   = e.Id,
                    Name = scene.World.GetName(e),
                    Transform = new TransformDocument {
                        Px = tc.Position.X, Py = tc.Position.Y,
                        Rotation = tc.Rotation,
                        Sx = tc.Scale.X,    Sy = tc.Scale.Y
                    }
                });
            });
            return list;
        }

        private static void RestoreEntities(Scene scene, List<EntityDocument> docs) {
            foreach (var d in docs) {
                var e = scene.CreateEntity(d.Name ?? "Entity");
                ref var tc = ref scene.World.Get<TransformComponent>(e);
                tc.Position = new Vector2(d.Transform?.Px ?? 0, d.Transform?.Py ?? 0);
                tc.Rotation = d.Transform?.Rotation ?? 0;
                tc.Scale    = new Vector2(d.Transform?.Sx ?? 1, d.Transform?.Sy ?? 1);
            }
        }

        // ── JSON POCOs ─────────────────────────────────────────────────────
        private sealed class SceneDocument {
            public string?             Name       { get; set; }
            public uint                SceneId    { get; set; }
            public float[]?            ClearColor { get; set; }
            public List<EntityDocument>? Entities { get; set; }
        }

        private sealed class EntityDocument {
            public uint                Id        { get; set; }
            public string?             Name      { get; set; }
            public TransformDocument?  Transform { get; set; }
        }

        private sealed class TransformDocument {
            public float Px{get;set;} public float Py{get;set;}
            public float Rotation{get;set;}
            public float Sx{get;set;} public float Sy{get;set;}
        }
    }
}
