// =============================================================================
// Audio/Audio.cs  —  Phase 5: AudioMixer, SoundClip, AudioSource, spatial audio
// =============================================================================
using System;
using System.Collections.Generic;
using System.IO;
using BADGE2D.Core;
using BADGE2D.Math;

namespace BADGE2D.Audio
{
    // ─────────────────────────────────────────────────────────────────────────
    // AudioClip  — PCM audio data
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AudioClip
    {
        public string   Name       { get; set; } = "";
        public float[]  Samples    { get; set; } = Array.Empty<float>();
        public int      Channels   { get; set; } = 1;
        public int      SampleRate { get; set; } = 44100;
        public float    Duration   => Samples.Length / (float)(SampleRate * Channels);
        public bool     IsLoaded   => Samples.Length > 0;

        // Load via NAudio (WAV/MP3/OGG) or NVorbis (OGG)
        public static AudioClip? LoadFromFile(string path) {
            try {
                var fullPath = Platform.FileSystem.Resolve(path);
                if (!File.Exists(fullPath)) { Log.Error($"[Audio] File not found: {path}"); return null; }
                var clip = new AudioClip { Name = Path.GetFileNameWithoutExtension(path) };
                var ext = Path.GetExtension(path).ToLower();
                switch (ext) {
                    case ".wav": LoadWav(clip, fullPath); break;
                    case ".ogg": LoadOgg(clip, fullPath); break;
                    case ".mp3": LoadMp3(clip, fullPath); break;
                    default: Log.Warning($"[Audio] Unsupported format: {ext}"); return null;
                }
                return clip;
            } catch (Exception ex) {
                Log.Error($"[Audio] Load error '{path}': {ex.Message}"); return null;
            }
        }

        private static void LoadWav(AudioClip clip, string path) {
            // NAudio: WaveFileReader
            using var reader = new NAudio.Wave.WaveFileReader(path);
            clip.SampleRate = reader.WaveFormat.SampleRate;
            clip.Channels   = reader.WaveFormat.Channels;
            var provider = reader.ToSampleProvider();
            var all = new List<float>();
            var buf = new float[4096];
            int read;
            while ((read = provider.Read(buf, 0, buf.Length)) > 0) {
                for (int i = 0; i < read; i++) all.Add(buf[i]);
            }
            clip.Samples = all.ToArray();
        }

        private static void LoadOgg(AudioClip clip, string path) {
            // NVorbis
            using var vr = new NVorbis.VorbisReader(path);
            clip.SampleRate = vr.SampleRate;
            clip.Channels   = vr.Channels;
            var all = new List<float>();
            var buf = new float[4096];
            int read;
            while ((read = vr.ReadSamples(buf, 0, buf.Length)) > 0) {
                for (int i = 0; i < read; i++) all.Add(buf[i]);
            }
            clip.Samples = all.ToArray();
        }

        private static void LoadMp3(AudioClip clip, string path) {
            using var reader = new NAudio.Wave.Mp3FileReader(path);
            clip.SampleRate = reader.WaveFormat.SampleRate;
            clip.Channels   = reader.WaveFormat.Channels;
            var provider = reader.ToSampleProvider();
            var all = new List<float>();
            var buf = new float[4096];
            int read;
            while ((read = provider.Read(buf, 0, buf.Length)) > 0) {
                for (int i = 0; i < read; i++) all.Add(buf[i]);
            }
            clip.Samples = all.ToArray();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AudioSource  —  one playing / paused instance
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AudioSource
    {
        public AudioClip? Clip        { get; set; }
        public float      Volume      { get; set; } = 1f;
        public float      Pitch       { get; set; } = 1f;
        public float      Pan         { get; set; } = 0f;   // -1 left … +1 right
        public bool       Loop        { get; set; }
        public bool       IsPlaying   => _playing && Clip != null;
        public bool       IsPaused    { get; private set; }
        public string     BusName     { get; set; } = "Master";

        // Spatial
        public bool    Spatial        { get; set; }
        public Vector2 Position       { get; set; }
        public float   MinDistance    { get; set; } = 100f;
        public float   MaxDistance    { get; set; } = 1000f;
        public float   RolloffFactor  { get; set; } = 1f;

        internal int   _samplePos;
        internal bool  _playing;

        public void Play()  { if (Clip == null) return; _samplePos = 0; _playing = true; IsPaused = false; }
        public void Stop()  { _playing = false; IsPaused = false; _samplePos = 0; }
        public void Pause() { if (!_playing) return; _playing = false; IsPaused = true; }
        public void Resume(){ if (!IsPaused) return; _playing = true;  IsPaused = false; }

        public float ComputeSpatialVolume(Vector2 listenerPos) {
            if (!Spatial) return Volume;
            float dist = Vector2.Distance(Position, listenerPos);
            if (dist <= MinDistance) return Volume;
            if (dist >= MaxDistance) return 0f;
            float t = (dist - MinDistance) / (MaxDistance - MinDistance);
            return Volume * (1f - MathF.Pow(t, RolloffFactor));
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AudioBus  —  mixer channel with volume/effects chain
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AudioBus
    {
        public string Name   { get; }
        public float  Volume { get; set; } = 1f;
        public bool   Muted  { get; set; }

        public AudioBus(string name) => Name = name;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AudioDevice  —  NAudio WaveOut backend
    // ─────────────────────────────────────────────────────────────────────────
    internal sealed class AudioDevice : IDisposable
    {
        private NAudio.Wave.WaveOutEvent?    _waveOut;
        private AudioMixerWaveProvider?      _provider;

        public void Initialize(AudioMixerWaveProvider provider) {
            _provider = provider;
            _waveOut  = new NAudio.Wave.WaveOutEvent {
                NumberOfBuffers = 3,
                DesiredLatency  = 100
            };
            _waveOut.Init(provider);
            _waveOut.Play();
        }

        public void Dispose() { _waveOut?.Stop(); _waveOut?.Dispose(); }
    }

    // IWaveProvider that mixes all active AudioSources
    internal sealed class AudioMixerWaveProvider : NAudio.Wave.IWaveProvider
    {
        private readonly AudioMixer _mixer;
        public NAudio.Wave.WaveFormat WaveFormat { get; } =
            NAudio.Wave.WaveFormat.CreateIeeeFloatWaveFormat(44100, 2);

        public AudioMixerWaveProvider(AudioMixer mixer) => _mixer = mixer;

        public int Read(byte[] buffer, int offset, int count) {
            // Fill with silence
            Array.Clear(buffer, offset, count);
            var floatBuf = new float[count / 4];
            _mixer.MixInto(floatBuf);
            System.Buffer.BlockCopy(floatBuf, 0, buffer, offset, count);
            return count;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AudioMixer  —  IModule, owns sources, buses, and device
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AudioMixer : IModule
    {
        public static AudioMixer Instance { get; } = new();
        private AudioMixer() {}

        public string          Name        => "AudioMixer";
        public ModuleInitOrder InitOrder   => ModuleInitOrder.Audio;
        public bool            Initialized { get; private set; }

        private readonly List<AudioSource>              _sources = new();
        private readonly Dictionary<string, AudioBus>   _buses   = new();
        private          AudioDevice?                   _device;
        private readonly object                         _lock    = new();

        public  Vector2 ListenerPosition { get; set; }
        public  float   MasterVolume     { get; set; } = 1f;

        public bool Initialize() {
            _buses["Master"] = new AudioBus("Master");
            _buses["Music"]  = new AudioBus("Music")  { Volume = 0.7f };
            _buses["SFX"]    = new AudioBus("SFX");
            _buses["UI"]     = new AudioBus("UI");
            try {
                var provider = new AudioMixerWaveProvider(this);
                _device = new AudioDevice();
                _device.Initialize(provider);
            } catch (Exception ex) {
                Log.Warning($"[Audio] Device init failed (audio disabled): {ex.Message}");
            }
            Initialized = true;
            Log.Info("[AudioMixer] Initialized");
            return true;
        }

        public void Shutdown() {
            _device?.Dispose();
            lock (_lock) _sources.Clear();
            Initialized = false;
        }

        public void Update(double _dt) {
            lock (_lock) _sources.RemoveAll(s => !s.IsPlaying && !s.IsPaused && !s.Loop);
        }

        // ── API ────────────────────────────────────────────────────────────
        public AudioBus   GetBus   (string name) => _buses.TryGetValue(name, out var b) ? b : _buses["Master"];
        public AudioBus   AddBus   (string name) { var b = new AudioBus(name); _buses[name] = b; return b; }

        public AudioSource Play(AudioClip clip, float volume = 1f, bool loop = false,
                                string bus = "SFX", Vector2? pos = null) {
            var src = new AudioSource { Clip = clip, Volume = volume, Loop = loop, BusName = bus };
            if (pos.HasValue) { src.Spatial = true; src.Position = pos.Value; }
            src.Play();
            lock (_lock) _sources.Add(src);
            return src;
        }

        public void StopAll () { lock (_lock) foreach (var s in _sources) s.Stop();  }
        public void PauseAll() { lock (_lock) foreach (var s in _sources) s.Pause(); }

        public void SetBusVolume(string bus, float v) { if (_buses.TryGetValue(bus, out var b)) b.Volume = v; }
        public float GetBusVolume(string bus) => _buses.TryGetValue(bus, out var b) ? b.Volume : 1f;

        // ── Called by AudioMixerWaveProvider on audio thread ───────────────
        internal void MixInto(float[] buffer) {
            int sampleCount = buffer.Length;
            lock (_lock) {
                foreach (var src in _sources) {
                    if (!src.IsPlaying || src.Clip == null) continue;
                    var  bus  = GetBus(src.BusName);
                    if (bus.Muted) continue;
                    float vol = src.ComputeSpatialVolume(ListenerPosition) * bus.Volume * MasterVolume;
                    float pan = System.Math.Clamp(src.Pan, -1f, 1f);
                    float lv  = vol * (1f - MathF.Max(0f,  pan));
                    float rv  = vol * (1f - MathF.Max(0f, -pan));

                    var clips   = src.Clip.Samples;
                    int srcCh   = src.Clip.Channels;
                    for (int i = 0; i < sampleCount; i += 2) {
                        if (src._samplePos >= clips.Length) {
                            if (src.Loop) src._samplePos = 0;
                            else { src.Stop(); break; }
                        }
                        float sL = clips[src._samplePos];
                        float sR = srcCh > 1 && src._samplePos+1 < clips.Length
                            ? clips[src._samplePos + 1] : sL;
                        if (i   < sampleCount) buffer[i]   += sL * lv;
                        if (i+1 < sampleCount) buffer[i+1] += sR * rv;
                        src._samplePos += srcCh;
                    }
                }
            }
        }
    }
}
