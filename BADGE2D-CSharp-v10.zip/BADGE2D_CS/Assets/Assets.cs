// =============================================================================
// Assets/Assets.cs  —  Phase 8: AssetManager, Cache (LRU), Manifest, Loader
// =============================================================================
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using BADGE2D.Audio;
using BADGE2D.Core;
using BADGE2D.Renderer;

namespace BADGE2D.Assets
{
    // ─────────────────────────────────────────────────────────────────────────
    // AssetType + AssetID
    // ─────────────────────────────────────────────────────────────────────────
    public enum AssetType { Unknown, Texture, Sound, Music, Font, Shader, Scene, Data }
    public readonly struct AssetId : IEquatable<AssetId>
    {
        public readonly uint Value;
        public AssetId(uint v) => Value = v;
        public static readonly AssetId Invalid = default;
        public bool IsValid => Value != 0;
        public bool Equals(AssetId o) => Value == o.Value;
        public override bool Equals(object? obj) => obj is AssetId id && Equals(id);
        public override int GetHashCode() => (int)Value;
        public override string ToString()  => $"AssetId({Value})";
        public static bool operator ==(AssetId a, AssetId b) => a.Value == b.Value;
        public static bool operator !=(AssetId a, AssetId b) => a.Value != b.Value;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AssetHandle<T>  — type-safe ref-counted pointer
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AssetHandle<T> where T : class
    {
        public AssetId Id    { get; }
        public T?      Asset { get; internal set; }
        public bool    IsValid => Asset != null;

        public AssetHandle(AssetId id, T? asset) { Id = id; Asset = asset; }

        public T Require() => Asset ?? throw new InvalidOperationException(
            $"Asset {Id} of type {typeof(T).Name} is not loaded");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AssetMeta  — manifest entry
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AssetMeta
    {
        public AssetId   Id       { get; set; }
        public string    Name     { get; set; } = "";
        public string    Path     { get; set; } = "";
        public AssetType Type     { get; set; }
        public long      SizeBytes{ get; set; }
        public string    Hash     { get; set; } = "";
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AssetCache  — LRU with memory budget
    // ─────────────────────────────────────────────────────────────────────────
    internal sealed class AssetCache
    {
        private sealed class Entry { public AssetId Id; public object Asset = null!; public long Size; public bool Pinned; public long LastAccess; }

        private readonly Dictionary<AssetId, Entry>  _entries = new();
        private readonly LinkedList<AssetId>         _lru     = new();
        private long _usedBytes, _budgetBytes = 256 * 1024 * 1024;  // 256 MB
        private long _clock;
        private readonly object _lock = new();

        public long UsedBytes   => _usedBytes;
        public long BudgetBytes { get => _budgetBytes; set => _budgetBytes = value; }
        public float UsageRatio => _budgetBytes > 0 ? (float)_usedBytes / _budgetBytes : 0f;

        public void Store<T>(AssetId id, T asset, long sizeBytes = 0, bool pin = false) where T : class {
            lock (_lock) {
                if (_entries.ContainsKey(id)) { _entries[id].LastAccess = ++_clock; return; }
                var e = new Entry { Id=id, Asset=asset, Size=sizeBytes, Pinned=pin, LastAccess=++_clock };
                _entries[id] = e;
                _lru.AddLast(id);
                _usedBytes += sizeBytes;
                Evict();
            }
        }

        public T? Get<T>(AssetId id) where T : class {
            lock (_lock) {
                if (!_entries.TryGetValue(id, out var e)) return null;
                e.LastAccess = ++_clock;
                return e.Asset as T;
            }
        }

        public bool Has(AssetId id) { lock (_lock) return _entries.ContainsKey(id); }

        public void Pin  (AssetId id) { lock (_lock) { if (_entries.TryGetValue(id, out var e)) e.Pinned = true;  } }
        public void Unpin(AssetId id) { lock (_lock) { if (_entries.TryGetValue(id, out var e)) e.Pinned = false; } }

        public void Remove(AssetId id) {
            lock (_lock) {
                if (!_entries.TryGetValue(id, out var e)) return;
                _usedBytes -= e.Size;
                _entries.Remove(id);
                _lru.Remove(id);
            }
        }

        public void Clear() { lock (_lock) { _entries.Clear(); _lru.Clear(); _usedBytes = 0; } }

        private void Evict() {
            while (_usedBytes > _budgetBytes && _lru.Count > 0) {
                var oldest = _lru.First!.Value; _lru.RemoveFirst();
                if (_entries.TryGetValue(oldest, out var e) && !e.Pinned) {
                    _usedBytes -= e.Size;
                    _entries.Remove(oldest);
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AssetManifest
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AssetManifest
    {
        private readonly Dictionary<AssetId, AssetMeta>   _byId   = new();
        private readonly Dictionary<string,  AssetMeta>   _byName = new();
        private          uint _nextId = 1;
        private          string _root = "Assets";

        public void SetRoot(string path) => _root = path;

        public int Scan() {
            int count = 0;
            try {
                foreach (var file in Platform.FileSystem.EnumerateFiles(_root)) {
                    var rel  = Path.GetRelativePath(Platform.FileSystem.Resolve(_root), file);
                    var name = Path.GetFileNameWithoutExtension(rel);
                    if (_byName.ContainsKey(name)) continue;
                    var type = GuessType(file);
                    if (type == AssetType.Unknown) continue;
                    Register(name, rel, type);
                    count++;
                }
            } catch (Exception ex) { Log.Warning($"[AssetManifest] Scan error: {ex.Message}"); }
            Log.Info($"[AssetManifest] Scanned {count} assets");
            return count;
        }

        public AssetMeta Register(string name, string path, AssetType type) {
            var meta = new AssetMeta { Id=new AssetId(_nextId++), Name=name, Path=path, Type=type };
            _byId[meta.Id] = meta; _byName[name] = meta;
            return meta;
        }

        public AssetMeta? FindByName(string name) => _byName.TryGetValue(name, out var m) ? m : null;
        public AssetMeta? FindById  (AssetId id)  => _byId.TryGetValue(id, out var m)     ? m : null;
        public IReadOnlyDictionary<AssetId, AssetMeta> All => _byId;

        private static AssetType GuessType(string path) => Path.GetExtension(path).ToLower() switch {
            ".png" or ".jpg" or ".jpeg" or ".bmp" or ".tga" => AssetType.Texture,
            ".wav" or ".mp3" or ".ogg"                       => AssetType.Sound,
            ".ttf" or ".otf"                                 => AssetType.Font,
            ".scene" or ".json"                              => AssetType.Scene,
            _                                                => AssetType.Unknown
        };

        private const string ManifestFile = "asset_manifest.json";
        private static readonly JsonSerializerOptions _opts = new() { WriteIndented = true };

        public void Save() {
            var json = JsonSerializer.Serialize(_byId, _opts);
            Platform.FileSystem.WriteAllText(ManifestFile, json);
        }

        public void Load() {
            if (!Platform.FileSystem.Exists(ManifestFile)) return;
            try {
                var json = Platform.FileSystem.ReadAllText(ManifestFile);
                var dict = JsonSerializer.Deserialize<Dictionary<uint, AssetMeta>>(json, _opts);
                if (dict == null) return;
                foreach (var kv in dict) {
                    _byId[new AssetId(kv.Key)] = kv.Value;
                    _byName[kv.Value.Name]      = kv.Value;
                    if (kv.Key >= _nextId) _nextId = kv.Key + 1;
                }
            } catch (Exception ex) { Log.Warning($"[AssetManifest] Load error: {ex.Message}"); }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AssetLoader  —  sync + async loading with a worker pool
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AssetLoader
    {
        private readonly AssetManifest _manifest;
        private readonly AssetCache    _cache = new();

        public AssetLoader(AssetManifest manifest) => _manifest = manifest;

        // ── Sync load ─────────────────────────────────────────────────────
        public AssetHandle<Texture2D>? LoadTexture(string name) {
            var meta = _manifest.FindByName(name) ??
                       _manifest.Register(name, name, AssetType.Texture);
            if (_cache.Has(meta.Id)) {
                var cached = _cache.Get<Texture2D>(meta.Id);
                return new AssetHandle<Texture2D>(meta.Id, cached);
            }
            var tex = Texture2D.Load(meta.Path);
            if (tex != null) _cache.Store(meta.Id, tex, 0);
            return new AssetHandle<Texture2D>(meta.Id, tex);
        }

        public AssetHandle<AudioClip>? LoadSound(string name) {
            var meta = _manifest.FindByName(name) ??
                       _manifest.Register(name, name, AssetType.Sound);
            if (_cache.Has(meta.Id)) return new AssetHandle<AudioClip>(meta.Id, _cache.Get<AudioClip>(meta.Id));
            var clip = AudioClip.LoadFromFile(meta.Path);
            if (clip != null) _cache.Store(meta.Id, clip, 0);
            return new AssetHandle<AudioClip>(meta.Id, clip);
        }

        // ── Async load ────────────────────────────────────────────────────
        public Task<AssetHandle<Texture2D>?> LoadTextureAsync(string name) =>
            Task.Run(() => LoadTexture(name));

        public Task<AssetHandle<AudioClip>?> LoadSoundAsync(string name) =>
            Task.Run(() => LoadSound(name));

        // ── Batch preload ─────────────────────────────────────────────────
        public async Task PreloadBatchAsync(IEnumerable<string> names,
            Action<float>? progress = null, Action? onComplete = null)
        {
            var list = new List<string>(names);
            int done = 0;
            foreach (var name in list) {
                var meta = _manifest.FindByName(name);
                if (meta == null) continue;
                if (meta.Type == AssetType.Texture) await LoadTextureAsync(name);
                else if (meta.Type is AssetType.Sound or AssetType.Music) await LoadSoundAsync(name);
                done++;
                progress?.Invoke((float)done / list.Count);
            }
            onComplete?.Invoke();
        }

        public void Pin  (AssetId id) => _cache.Pin(id);
        public void Unpin(AssetId id) => _cache.Unpin(id);
        public void EvictAll()        => _cache.Clear();
        public float CacheUsage       => _cache.UsageRatio;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // AssetManager  —  IModule façade
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class AssetManager : IModule
    {
        public static AssetManager Instance { get; } = new();
        private AssetManager() {}

        public string          Name        => "AssetManager";
        public ModuleInitOrder InitOrder   => ModuleInitOrder.Assets;
        public bool            Initialized { get; private set; }

        public  AssetManifest Manifest { get; } = new();
        private AssetLoader?  _loader;

        public bool Initialize() {
            Manifest.Load();
            _loader = new AssetLoader(Manifest);
            Initialized = true;
            Log.Info("[AssetManager] Initialized");
            return true;
        }

        public void Shutdown() { _loader?.EvictAll(); Initialized = false; }

        public void SetRoot(string path) { Manifest.SetRoot(path); Manifest.Scan(); Manifest.Save(); }

        public AssetHandle<Texture2D>?  GetTexture(string name) => _loader?.LoadTexture(name);
        public AssetHandle<AudioClip>?  GetSound  (string name) => _loader?.LoadSound(name);

        public Task<AssetHandle<Texture2D>?>? GetTextureAsync(string name) => _loader?.LoadTextureAsync(name);
        public Task<AssetHandle<AudioClip>?>? GetSoundAsync  (string name) => _loader?.LoadSoundAsync(name);

        public Task PreloadBatchAsync(IEnumerable<string> names,
            Action<float>? progress = null, Action? onComplete = null) =>
            _loader?.PreloadBatchAsync(names, progress, onComplete) ?? Task.CompletedTask;

        public float CacheUsage => _loader?.CacheUsage ?? 0f;
    }
}
