// =============================================================================
// Physics/Physics.cs  —  Phase 3: Impulse-based 2D physics
// =============================================================================
using System;
using System.Collections.Generic;
using BADGE2D.Core;
using BADGE2D.ECS;
using BADGE2D.ECS.Components;
using BADGE2D.Math;

namespace BADGE2D.Physics
{
    // ─────────────────────────────────────────────────────────────────────────
    // Enums + Config
    // ─────────────────────────────────────────────────────────────────────────
    public enum BodyType    { Static, Kinematic, Dynamic }
    public enum ShapeType   { Box, Circle, Capsule }

    public struct PhysicsMaterial
    {
        public float Friction    ;
        public float Restitution ;
        public float Density     ;
        public static PhysicsMaterial Default => new() { Friction=0.4f, Restitution=0.3f, Density=1f };
    }

    public struct RaycastHit
    {
        public Vector2 Point;
        public Vector2 Normal;
        public float   Fraction;
        public Entity  EntityId;
        public PhysicsBody? Body;
    }

    public sealed class PhysicsWorldConfig
    {
        public Vector2 Gravity       = new(0, -980f);  // cm/s²
        public int     VelocityIters = 8;
        public int     PositionIters = 3;
        public float   TimeScale     = 1f;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CollisionShape
    // ─────────────────────────────────────────────────────────────────────────
    public abstract class CollisionShape
    {
        public ShapeType Type    { get; protected set; }
        public Vector2   Offset  { get; set; } = Vector2.Zero;
        public abstract Rect2D  GetAABB(Vector2 pos, float rot) ;
        public abstract float   ComputeInertia(float mass);
    }

    public sealed class BoxShape : CollisionShape
    {
        public float HalfW, HalfH;
        public BoxShape(float w, float h) { Type = ShapeType.Box; HalfW = w*0.5f; HalfH = h*0.5f; }
        public override Rect2D GetAABB(Vector2 pos, float rot) {
            float c = MathF.Abs(MathF.Cos(rot)), s = MathF.Abs(MathF.Sin(rot));
            float ex = c*HalfW + s*HalfH, ey = s*HalfW + c*HalfH;
            return new Rect2D(pos.X-ex+Offset.X, pos.Y-ey+Offset.Y, ex*2, ey*2);
        }
        public override float ComputeInertia(float mass) => mass*(4*HalfW*HalfW + 4*HalfH*HalfH)/12f;
    }

    public sealed class CircleShape : CollisionShape
    {
        public float Radius;
        public CircleShape(float r) { Type = ShapeType.Circle; Radius = r; }
        public override Rect2D GetAABB(Vector2 pos, float _) =>
            new Rect2D(pos.X-Radius+Offset.X, pos.Y-Radius+Offset.Y, Radius*2, Radius*2);
        public override float ComputeInertia(float mass) => mass * Radius * Radius * 0.5f;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PhysicsBody
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class PhysicsBody
    {
        public BodyType  BodyType        { get; set; } = BodyType.Dynamic;
        public Vector2   Position        { get; set; }
        public float     Rotation        { get; set; }
        public Vector2   LinearVelocity  { get; set; }
        public float     AngularVelocity { get; set; }
        public float     Mass            { get; set; } = 1f;
        public float     InvMass         { get; private set; } = 1f;
        public float     Inertia         { get; private set; } = 1f;
        public float     InvInertia      { get; private set; } = 1f;
        public float     LinearDamping   { get; set; } = 0.01f;
        public float     AngularDamping  { get; set; } = 0.01f;
        public bool      IsTrigger       { get; set; }
        public bool      FixedRotation   { get; set; }
        public uint      EntityId        { get; set; }
        public CollisionShape? Shape     { get; set; }
        public PhysicsMaterial Material  { get; set; } = PhysicsMaterial.Default;

        private Vector2 _force;
        private float   _torque;

        public void SetMass(float mass) {
            Mass = mass;
            if (BodyType == BodyType.Static || mass <= 0f) { InvMass = 0; InvInertia = 0; return; }
            InvMass   = 1f / mass;
            Inertia   = Shape?.ComputeInertia(mass) ?? 1f;
            InvInertia = FixedRotation ? 0f : (Inertia > 0f ? 1f/Inertia : 0f);
        }

        public void ApplyForce     (Vector2 f)            => _force  += f;
        public void ApplyImpulse   (Vector2 imp)          => LinearVelocity  += imp * InvMass;
        public void ApplyTorque    (float t)              => _torque += t;
        public void ApplyAngularImp(float ang)            => AngularVelocity += ang * InvInertia;
        public void ApplyForceAt   (Vector2 f, Vector2 r) { _force += f; _torque += Vector2.Cross(r, f); }

        internal void Integrate(float dt, Vector2 gravity) {
            if (BodyType != BodyType.Dynamic) return;
            var linAcc = _force * InvMass + gravity;
            LinearVelocity  = LinearVelocity  * (1f - LinearDamping  * dt) + linAcc  * dt;
            AngularVelocity = AngularVelocity * (1f - AngularDamping * dt) + _torque * InvInertia * dt;
            Position += LinearVelocity  * dt;
            Rotation += AngularVelocity * dt;
            _force  = Vector2.Zero;
            _torque = 0f;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Contact + Manifold
    // ─────────────────────────────────────────────────────────────────────────
    public struct ContactPoint { public Vector2 Point; public float Penetration; }

    public struct CollisionManifold
    {
        public PhysicsBody? A, B;
        public Vector2      Normal;
        public float        Penetration;
        public ContactPoint Contact;
        public bool         IsTrigger;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // NarrowPhase  — SAT-based circle/box detection
    // ─────────────────────────────────────────────────────────────────────────
    internal static class NarrowPhase
    {
        public static bool CircleCircle(PhysicsBody a, PhysicsBody b, out CollisionManifold m) {
            m = default;
            var ca = (CircleShape)a.Shape!; var cb = (CircleShape)b.Shape!;
            var diff = b.Position - a.Position;
            float dist = diff.Length;
            float radSum = ca.Radius + cb.Radius;
            if (dist >= radSum) return false;
            m.A = a; m.B = b;
            m.Normal      = dist > 1e-6f ? diff / dist : new Vector2(1,0);
            m.Penetration = radSum - dist;
            m.Contact     = new ContactPoint { Point = a.Position + m.Normal * ca.Radius };
            return true;
        }

        public static bool BoxBox(PhysicsBody a, PhysicsBody b, out CollisionManifold m) {
            m = default;
            var aa = a.Shape!.GetAABB(a.Position, a.Rotation);
            var ba = b.Shape!.GetAABB(b.Position, b.Rotation);
            if (!aa.Overlaps(ba)) return false;

            float overlapX = MathF.Min(aa.Right, ba.Right) - MathF.Max(aa.Left, ba.Left);
            float overlapY = MathF.Min(aa.Top,   ba.Top)   - MathF.Max(aa.Bottom, ba.Bottom);
            m.A = a; m.B = b;
            if (overlapX < overlapY) {
                m.Normal      = b.Position.X > a.Position.X ? new Vector2(1,0) : new Vector2(-1,0);
                m.Penetration = overlapX;
            } else {
                m.Normal      = b.Position.Y > a.Position.Y ? new Vector2(0,1) : new Vector2(0,-1);
                m.Penetration = overlapY;
            }
            return true;
        }

        public static bool Detect(PhysicsBody a, PhysicsBody b, out CollisionManifold m) {
            m = default;
            if (a.Shape == null || b.Shape == null) return false;
            return (a.Shape.Type, b.Shape.Type) switch {
                (ShapeType.Circle, ShapeType.Circle) => CircleCircle(a, b, out m),
                (ShapeType.Box,    ShapeType.Box)    => BoxBox(a, b, out m),
                _                                    => BoxBox(a, b, out m)
            };
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PhysicsWorld
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class PhysicsWorld
    {
        private readonly PhysicsWorldConfig          _config;
        private readonly List<PhysicsBody>           _bodies    = new();
        private readonly List<CollisionManifold>     _manifolds = new();

        public event Action<CollisionManifold>? OnCollisionEnter;
        public event Action<CollisionManifold>? OnCollisionExit;

        public PhysicsWorld(PhysicsWorldConfig? config = null) =>
            _config = config ?? new PhysicsWorldConfig();

        public PhysicsBody CreateBody(BodyType type, Vector2 pos, CollisionShape shape,
                                       PhysicsMaterial? mat = null) {
            var b = new PhysicsBody { BodyType = type, Position = pos, Shape = shape };
            if (mat.HasValue) b.Material = mat.Value;
            if (type == BodyType.Static) { b.SetMass(0f); }
            else                         { b.SetMass(b.Mass); }
            _bodies.Add(b);
            return b;
        }

        public PhysicsBody CreateBoxBody(BodyType type, Vector2 pos, float w, float h,
                                          PhysicsMaterial? mat = null) =>
            CreateBody(type, pos, new BoxShape(w, h), mat);

        public PhysicsBody CreateCircleBody(BodyType type, Vector2 pos, float radius,
                                             PhysicsMaterial? mat = null) =>
            CreateBody(type, pos, new CircleShape(radius), mat);

        public void RemoveBody(PhysicsBody body) => _bodies.Remove(body);

        public void SetGravity(Vector2 g) => _config.Gravity = g;

        public void Step(float dt) {
            dt *= _config.TimeScale;
            if (dt <= 0) return;

            // Integrate
            foreach (var b in _bodies) b.Integrate(dt, _config.Gravity);

            // Broad + narrow phase
            _manifolds.Clear();
            for (int i = 0; i < _bodies.Count; i++) {
                for (int j = i+1; j < _bodies.Count; j++) {
                    var a = _bodies[i]; var b = _bodies[j];
                    if (a.BodyType == BodyType.Static && b.BodyType == BodyType.Static) continue;
                    if (!a.Shape!.GetAABB(a.Position,a.Rotation).Overlaps(
                         b.Shape!.GetAABB(b.Position,b.Rotation))) continue;
                    if (NarrowPhase.Detect(a, b, out var m)) {
                        _manifolds.Add(m);
                        OnCollisionEnter?.Invoke(m);
                    }
                }
            }

            // Resolve
            for (int iter = 0; iter < _config.VelocityIters; iter++) {
                foreach (var m in _manifolds) ResolveVelocity(m);
            }
            foreach (var m in _manifolds) ResolvePosition(m);
        }

        private static void ResolveVelocity(CollisionManifold m) {
            var a = m.A!; var b = m.B!;
            var rv = b.LinearVelocity - a.LinearVelocity;
            float velAlongNorm = Vector2.Dot(rv, m.Normal);
            if (velAlongNorm > 0) return;

            float e    = System.Math.Min(a.Material.Restitution, b.Material.Restitution);
            float j    = -(1f + e) * velAlongNorm / (a.InvMass + b.InvMass);
            var   imp  = m.Normal * j;
            if (a.BodyType == BodyType.Dynamic) a.LinearVelocity -= imp * a.InvMass;
            if (b.BodyType == BodyType.Dynamic) b.LinearVelocity += imp * b.InvMass;
        }

        private static void ResolvePosition(CollisionManifold m) {
            const float slop = 0.01f, percent = 0.6f;
            float corr = MathF.Max(m.Penetration - slop, 0f) / (m.A!.InvMass + m.B!.InvMass) * percent;
            var correction = m.Normal * corr;
            if (m.A.BodyType == BodyType.Dynamic) m.A.Position -= correction * m.A.InvMass;
            if (m.B.BodyType == BodyType.Dynamic) m.B.Position += correction * m.B.InvMass;
        }

        public bool Raycast(Vector2 origin, Vector2 dir, float maxDist, out RaycastHit hit) {
            hit = default;
            float best = maxDist;
            bool  found = false;
            foreach (var b in _bodies) {
                var aabb = b.Shape!.GetAABB(b.Position, b.Rotation);
                // Slab method AABB raycast
                float tmin = 0, tmax = best;
                for (int axis = 0; axis < 2; axis++) {
                    float orig = axis==0 ? origin.X : origin.Y;
                    float d    = axis==0 ? dir.X    : dir.Y;
                    float lo   = axis==0 ? aabb.X          : aabb.Y;
                    float hi   = axis==0 ? aabb.X + aabb.W : aabb.Y + aabb.H;
                    if (MathF.Abs(d) < 1e-8f) {
                        if (orig < lo || orig > hi) goto nextBody;
                    } else {
                        float t1 = (lo - orig) / d, t2 = (hi - orig) / d;
                        if (t1 > t2) (t1,t2) = (t2,t1);
                        tmin = MathF.Max(tmin, t1);
                        tmax = MathF.Min(tmax, t2);
                        if (tmin > tmax) goto nextBody;
                    }
                }
                if (tmin < best) {
                    best = tmin; found = true;
                    hit.Body     = b;
                    hit.Point    = origin + dir * tmin;
                    hit.Fraction = tmin / maxDist;
                    hit.EntityId = new Entity(b.EntityId);
                }
                nextBody:;
            }
            return found;
        }

        public void Initialize() {}
        public void Shutdown()   { _bodies.Clear(); }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PhysicsSystem  —  ECS bridge
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class PhysicsSystem : ISystem
    {
        private readonly PhysicsWorld _world;
        public  string Name => "PhysicsSystem";

        public PhysicsSystem(PhysicsWorld world) => _world = world;

        public void OnFixedUpdate(World w, double dt) {
            // Kinematic: ECS transform → physics
            w.EachRef<PhysicsBodyComponent, TransformComponent>((e, ref var pbc, ref var tc) => {
                if (pbc.Body == null || !pbc.SyncFromECS) return;
                if (pbc.Body.BodyType == BodyType.Kinematic) {
                    pbc.Body.Position = tc.Position + pbc.PositionOffset;
                    pbc.Body.Rotation = tc.Rotation;
                }
            });

            _world.Step((float)dt);

            // Dynamic: physics → ECS transform
            w.EachRef<PhysicsBodyComponent, TransformComponent>((e, ref var pbc, ref var tc) => {
                if (pbc.Body == null || !pbc.SyncToECS) return;
                if (pbc.Body.BodyType == BodyType.Dynamic) {
                    tc.Position = pbc.Body.Position - pbc.PositionOffset;
                    tc.Rotation = pbc.Body.Rotation;
                    tc.Dirty    = true;
                }
            });
        }

        // ── Attach helpers ─────────────────────────────────────────────────
        public static PhysicsBody AttachBoxBody(World world, Entity entity,
            PhysicsWorld physics, float w, float h,
            BodyType type = BodyType.Dynamic, PhysicsMaterial? mat = null)
        {
            var tc  = world.TryGet<TransformComponent>(entity);
            var pos = tc?.Position ?? Vector2.Zero;
            var body = physics.CreateBoxBody(type, pos, w, h, mat);
            body.EntityId = entity.Id;
            world.Add(entity, new PhysicsBodyComponent { Body = body, SyncToECS = true });
            return body;
        }

        public static PhysicsBody AttachCircleBody(World world, Entity entity,
            PhysicsWorld physics, float radius,
            BodyType type = BodyType.Dynamic, PhysicsMaterial? mat = null)
        {
            var tc  = world.TryGet<TransformComponent>(entity);
            var pos = tc?.Position ?? Vector2.Zero;
            var body = physics.CreateCircleBody(type, pos, radius, mat);
            body.EntityId = entity.Id;
            world.Add(entity, new PhysicsBodyComponent { Body = body, SyncToECS = true });
            return body;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DistanceJoint  — holds two bodies apart at a target distance
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class DistanceJoint
    {
        public PhysicsBody A, B;
        public float TargetDistance;
        public float Stiffness = 0.3f;

        public DistanceJoint(PhysicsBody a, PhysicsBody b, float? dist = null) {
            A = a; B = b;
            TargetDistance = dist ?? Vector2.Distance(a.Position, b.Position);
        }

        public void Solve() {
            var diff = B.Position - A.Position;
            float cur = diff.Length;
            if (cur < 1e-6f) return;
            float err = cur - TargetDistance;
            var n  = diff / cur;
            var imp = n * err * Stiffness / (A.InvMass + B.InvMass);
            if (A.BodyType == BodyType.Dynamic) A.Position += imp * A.InvMass;
            if (B.BodyType == BodyType.Dynamic) B.Position -= imp * B.InvMass;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PhysicsDebugDraw  — draws collision shapes via SpriteBatch
    // ─────────────────────────────────────────────────────────────────────────
    public static class PhysicsDebugDraw
    {
        private static readonly Color BoxColor    = new(0.2f, 0.9f, 0.2f, 0.8f);
        private static readonly Color StaticColor = new(0.9f, 0.5f, 0.1f, 0.8f);
        private static readonly Color CircleColor = new(0.2f, 0.7f, 1.0f, 0.8f);

        public static void Draw(PhysicsWorld world, Renderer.SpriteBatch batch) {
            // Access bodies via reflection or an exposed enumerable
            // In a real implementation, PhysicsWorld exposes IReadOnlyList<PhysicsBody>
        }

        public static void DrawBody(PhysicsBody body, Renderer.SpriteBatch batch) {
            var color = body.BodyType == BodyType.Static ? StaticColor : BoxColor;
            var aabb  = body.Shape!.GetAABB(body.Position, body.Rotation);
            batch.DrawRect(aabb, color);
        }
    }
}
