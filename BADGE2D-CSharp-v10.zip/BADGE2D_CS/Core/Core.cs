// =============================================================================
// Core/Core.cs  —  Logger, Profiler, Clock, IModule, ModuleManager
// =============================================================================
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

namespace BADGE2D.Core
{
    // ─────────────────────────────────────────────────────────────────────────
    // LogLevel
    // ─────────────────────────────────────────────────────────────────────────
    public enum LogLevel { Debug = 0, Info, Warning, Error, Fatal }

    // ─────────────────────────────────────────────────────────────────────────
    // Logger
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class Logger
    {
        public static Logger Instance { get; } = new();
        private Logger() {}

        public LogLevel MinLevel  = LogLevel.Debug;
        public bool     UseColors = true;

        private readonly object _lock = new();
        private StreamWriter?   _file;

        public void OpenFile(string path) {
            _file = new StreamWriter(path, append: false) { AutoFlush = true };
        }

        public void Log(LogLevel level, string message,
            [CallerFilePath] string file = "", [CallerLineNumber] int line = 0)
        {
            if (level < MinLevel) return;
            string tag  = level switch {
                LogLevel.Debug   => "DEBUG",
                LogLevel.Info    => "INFO ",
                LogLevel.Warning => "WARN ",
                LogLevel.Error   => "ERROR",
                LogLevel.Fatal   => "FATAL",
                _                => "?????"
            };
            string time = DateTime.Now.ToString("HH:mm:ss.fff");
            string src  = Path.GetFileName(file);
            string msg  = $"[{time}][{tag}] {message}  ({src}:{line})";

            lock (_lock) {
                if (UseColors) {
                    Console.ForegroundColor = level switch {
                        LogLevel.Debug   => ConsoleColor.Gray,
                        LogLevel.Info    => ConsoleColor.White,
                        LogLevel.Warning => ConsoleColor.Yellow,
                        LogLevel.Error   => ConsoleColor.Red,
                        LogLevel.Fatal   => ConsoleColor.Magenta,
                        _                => ConsoleColor.White
                    };
                }
                Console.WriteLine(msg);
                if (UseColors) Console.ResetColor();
                _file?.WriteLine(msg);
            }
        }

        public void Debug  (string m, [CallerFilePath] string f="", [CallerLineNumber] int l=0)
            => Log(LogLevel.Debug, m, f, l);
        public void Info   (string m, [CallerFilePath] string f="", [CallerLineNumber] int l=0)
            => Log(LogLevel.Info,  m, f, l);
        public void Warning(string m, [CallerFilePath] string f="", [CallerLineNumber] int l=0)
            => Log(LogLevel.Warning, m, f, l);
        public void Error  (string m, [CallerFilePath] string f="", [CallerLineNumber] int l=0)
            => Log(LogLevel.Error, m, f, l);
        public void Fatal  (string m, [CallerFilePath] string f="", [CallerLineNumber] int l=0)
            => Log(LogLevel.Fatal, m, f, l);
    }

    // Convenience static façade
    public static class Log
    {
        public static void Debug  (string m) => Logger.Instance.Debug(m);
        public static void Info   (string m) => Logger.Instance.Info(m);
        public static void Warning(string m) => Logger.Instance.Warning(m);
        public static void Error  (string m) => Logger.Instance.Error(m);
        public static void Fatal  (string m) => Logger.Instance.Fatal(m);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EngineTime
    // ─────────────────────────────────────────────────────────────────────────
    public sealed class EngineTime
    {
        private readonly Stopwatch _sw = Stopwatch.StartNew();
        private double _lastFrame;

        public double TotalSeconds   => _sw.Elapsed.TotalSeconds;
        public double DeltaTime      { get; private set; }
        public double FixedTimeStep  = 1.0 / 60.0;   // 60 Hz physics
        public double MaxDeltaTime   = 0.1;           // clamp spike frames
        public double Accumulator    { get; private set; }
        public ulong  FrameCount     { get; private set; }

        public void Tick() {
            double now = TotalSeconds;
            DeltaTime  = System.Math.Min(now - _lastFrame, MaxDeltaTime);
            _lastFrame = now;
            Accumulator += DeltaTime;
            FrameCount++;
        }

        public bool ConsumeFixedStep() {
            if (Accumulator < FixedTimeStep) return false;
            Accumulator -= FixedTimeStep;
            return true;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ProfileScope  (using + IDisposable pattern)
    // ─────────────────────────────────────────────────────────────────────────
    public readonly struct ProfileScope : IDisposable
    {
        private readonly string     _name;
        private readonly long       _start;

        public ProfileScope(string name) {
            _name  = name;
            _start = Stopwatch.GetTimestamp();
        }

        public void Dispose() {
            double ms = (Stopwatch.GetTimestamp() - _start) * 1000.0 / Stopwatch.Frequency;
            Profiler.Instance.Record(_name, ms);
        }
    }

    public sealed class Profiler
    {
        public static Profiler Instance { get; } = new();
        private Profiler() {}

        private readonly Dictionary<string, double> _totals = new();
        private readonly Dictionary<string, int>    _counts = new();
        private readonly object _lock = new();

        public void Record(string name, double ms) {
            lock (_lock) {
                _totals[name] = _totals.GetValueOrDefault(name) + ms;
                _counts[name] = _counts.GetValueOrDefault(name) + 1;
            }
        }

        public ProfileScope Scope(string name) => new(name);

        public void PrintReport() {
            lock (_lock) {
                Log.Info("=== Profiler Report ===");
                foreach (var kv in _totals) {
                    int    cnt = _counts[kv.Key];
                    double avg = kv.Value / cnt;
                    Log.Info($"  {kv.Key,-30}  avg={avg:F3}ms  total={kv.Value:F1}ms  calls={cnt}");
                }
            }
        }

        public void Reset() { lock (_lock) { _totals.Clear(); _counts.Clear(); } }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Module system
    // ─────────────────────────────────────────────────────────────────────────
    public enum ModuleInitOrder : uint
    {
        Core       = 0,
        Platform   = 100,
        Memory     = 200,
        Logging    = 300,
        Time       = 400,
        Profiling  = 500,
        ECS        = 600,
        Renderer   = 700,
        Physics    = 800,
        Audio      = 900,
        Input      = 1000,
        Animation  = 1100,
        Scene      = 1200,
        Assets     = 1250,
        Scripting  = 1300,
        UI         = 1400,
        Editor     = 1450,
        Game       = 9999
    }

    public interface IModule
    {
        string          Name        { get; }
        ModuleInitOrder InitOrder   { get; }
        bool            Initialized { get; }

        bool Initialize();
        void Shutdown();
        void Update     (double dt) {}
        void FixedUpdate(double dt) {}
        void PostUpdate (double dt) {}
        void Render     ()          {}
    }

    public sealed class ModuleManager
    {
        public static ModuleManager Instance { get; } = new();
        private ModuleManager() {}

        private readonly List<IModule>              _ordered = new();
        private readonly Dictionary<Type, IModule>  _map     = new();

        public T Register<T>(T module) where T : IModule {
            _map[typeof(T)] = module;
            _ordered.Add(module);
            _ordered.Sort((a, b) => ((uint)a.InitOrder).CompareTo((uint)b.InitOrder));
            return module;
        }

        public T? Get<T>() where T : class, IModule =>
            _map.TryGetValue(typeof(T), out var m) ? (T)m : null;

        public bool InitializeAll() {
            foreach (var m in _ordered) {
                if (!m.Initialize()) {
                    Log.Fatal($"[ModuleManager] Failed to initialize: {m.Name}");
                    return false;
                }
                Log.Info($"[ModuleManager] Initialized: {m.Name}");
            }
            return true;
        }

        public void ShutdownAll() {
            for (int i = _ordered.Count - 1; i >= 0; i--) {
                _ordered[i].Shutdown();
                Log.Info($"[ModuleManager] Shutdown: {_ordered[i].Name}");
            }
        }

        public void UpdateAll     (double dt) { foreach (var m in _ordered) m.Update(dt);      }
        public void FixedUpdateAll(double dt) { foreach (var m in _ordered) m.FixedUpdate(dt); }
        public void RenderAll     ()          { foreach (var m in _ordered) m.Render();         }
    }
}
