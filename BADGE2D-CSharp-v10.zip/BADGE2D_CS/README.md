# BADGE2D Engine — C# Edition
**Version 10.0 · C# 12 · .NET 8 · OpenGL 4.1**

> A complete 2D game engine rebuilt from scratch in C# — all 10 phases of the C++ original, redesigned for idiomatic .NET with generics, async/await, events, and interfaces.

---

## Quick Start

### Prerequisites

| Tool | Version |
|------|---------|
| .NET SDK | 8.0+ |
| OpenGL driver | 4.1+ |

```bash
# Install dependencies
dotnet restore

# Build
dotnet build -c Release

# Run a demo
dotnet run -- physics       # Physics sandbox
dotnet run -- platformer    # Side-scroller with animation
dotnet run -- ui            # All 9 widget types
dotnet run -- editor        # Full editor layout
```

---

## Architecture

```
BADGE2D/
├── Math/           Vector2, Color, Rect2D, Matrix4, MathUtils
├── Core/           Logger, Profiler, EngineTime, IModule, ModuleManager
├── ECS/            Entity, World, ISystem, ComponentStore<T>, built-in components
├── Platform/       FileSystem, JobSystem, EventBus
├── Renderer/       Shader, Texture2D, SpriteBatch, Framebuffer, Renderer2D, Camera2D
├── Physics/        PhysicsWorld, PhysicsBody, SAT collision, joints, PhysicsSystem
├── Input/          InputManager, ActionMap, Key/Mouse/Gamepad
├── Audio/          AudioMixer, AudioClip, AudioSource, spatial audio (NAudio/NVorbis)
├── Animation/      SpriteAnimation, AnimStateMachine, AnimatorSystem
├── Scene/          Scene, SceneManager, SceneSerializer, Prefab
├── Assets/         AssetManager, AssetCache (LRU), AssetManifest, AssetLoader
├── UI/             UICanvas, 9 widget types, anchor layout, UIRenderer
├── Editor/         EditorCore, 5 panels, TransformGizmo, CommandHistory (undo/redo)
├── Runtime/        Application, EngineLoop (Silk.NET integration)
└── Demos/          PhysicsDemo, PlatformerDemo, UIDemo, EditorDemo
```

---

## Phases

| # | Module | C# Highlights |
|---|--------|--------------|
| 1 | Core + ECS | Generic `World`, struct components, `ref` iteration |
| 2 | Renderer | `SpriteBatch` with batched quads, `Texture2D` via StbImageSharp |
| 3 | Physics | Impulse-based, SAT AABB, `PhysicsSystem` ECS bridge |
| 4 | Input | `InputManager`, `ActionMap` with combos |
| 5 | Audio | `AudioMixer` via NAudio, `NVorbis` OGG, spatial rolloff |
| 6 | Animation | `AnimStateMachine`, cross-fade, `AnimatorSystem` |
| 7 | Scene | `SceneManager`, `SceneSerializer` (JSON), async transitions |
| 8 | Assets | `AssetManager`, LRU `AssetCache`, async batch preload |
| 9 | UI | 9 widgets: Panel, Label, Button, Image, Slider, Checkbox, TextInput, ProgressBar, ScrollView |
| 10 | Editor | Dockable panels, gizmos, `CommandHistory` undo/redo |

---

## Minimal Game Example

```csharp
using BADGE2D;
using BADGE2D.Runtime;

sealed class MyGame : Application
{
    private Scene.Scene? _scene;

    protected override void Configure(WindowConfig cfg) {
        cfg.Title = "My Game";
        cfg.Width = 1280; cfg.Height = 720;
    }

    protected override void OnInit() {
        _scene = new Scene.Scene(new SceneSettings {
            Name = "Level1", Id = 1,
            ClearColor = new Color(0.1f, 0.1f, 0.15f)
        });
        _scene.Load();

        SceneManager.Instance.Register("level1", () => _scene);
        SceneManager.Instance.LoadScene("level1");

        var player = _scene.CreateEntity("Player", new Vector2(400, 300));
        _scene.World.Add(player, SpriteComponent.Default);
    }

    protected override void OnUpdate(double dt) {
        var move = InputManager.Instance.GetWASD() * (float)(200 * dt);
        if (_scene != null)
            _scene.World.EachRef<TransformComponent>((e, ref var tc) => tc.Position += move);
    }
}

// Entry point
return new MyGame().Run();
```

---

## NuGet Packages

| Package | Purpose |
|---------|---------|
| `Silk.NET.OpenGL` | OpenGL 4.1 bindings |
| `Silk.NET.Windowing` | Cross-platform window + OpenGL context |
| `Silk.NET.Input` | Keyboard, mouse, gamepad via Silk |
| `StbImageSharp` | PNG/JPG/BMP/TGA texture loading |
| `NAudio` | WAV, MP3 audio playback (Windows/Linux) |
| `NVorbis` | OGG Vorbis audio decoding |
| `System.Text.Json` | Scene serialization |

```bash
dotnet add package Silk.NET.OpenGL    --version 2.21.0
dotnet add package Silk.NET.Windowing --version 2.21.0
dotnet add package Silk.NET.Input     --version 2.21.0
dotnet add package StbImageSharp      --version 2.30.0
dotnet add package NVorbis            --version 0.10.5
dotnet add package NAudio             --version 2.2.1
```

---

## Key Differences from the C++ Version

| Feature | C++ | C# |
|---------|-----|----|
| Memory | Manual / `unique_ptr` | GC + `IDisposable` |
| Generics | Templates | `List<T>`, `ComponentStore<T>` |
| Async | `std::future` | `async/await Task<T>` |
| Events | Function pointers | C# `event Action<T>` |
| ECS iteration | Lambda templates | `Action<Entity, T>` + `ref` |
| Serialization | Manual JSON | `System.Text.Json` |
| Window/GL | GLFW + GLAD | Silk.NET |
| Audio | miniaudio + dr_libs | NAudio + NVorbis |
| UI Font | FreeType stub | Pluggable `DrawText` |

---

## Platform Support

| Platform | Status |
|----------|--------|
| Windows (x64) | ✅ Full |
| macOS (arm64/x64) | ✅ Full (Silk.NET cross-platform) |
| Linux (x64) | ✅ Full |
